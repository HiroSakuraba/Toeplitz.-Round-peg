# Preconditioned Local Rough Toeplitz Certificate: Canonical Manifest

## Status

This package supersedes the earlier lower-regularity certificate using the direct perturbation estimate `36 delta` and `delta = 1/1000`.

Canonical constants:

- `rho = 1/20`
- `delta = 1/100`
- height-to-width ratio: `delta/rho = 1/5`

The old `delta = 1/1000` appears only in comparison remarks and is no longer the active theorem constant.

## Main theorem

If a planar Jordan curve contains four local graph arcs near the vertices of the model square, with graph height at most `delta = 1/100` over windows of half-width `rho = 1/20`, then the curve contains an inscribed Euclidean square with one vertex on each graph arc.

The proof uses the preconditioned map

```tex
G = J^{-1} F
```

rather than estimating the original square map `F` directly.

## Certified inequalities

- `det J = -32`
- `||G_0(t)-t||_infty <= rho^2/2 = 1/800`
- `||G_f(t)-G_0(t)||_infty <= (4+rho)delta + delta^2/2 = 811/20000`
- total error bound: `209/5000`
- boundary radius: `rho = 1/20 = 250/5000`
- margin: `41/5000 > 0`
- vertex distinctness lower bound: `2 - 2(rho+delta) = 47/25 > 0`

## Files

- `local_rough_toeplitz_certificate_preconditioned.tex` - paper-ready LaTeX source.
- `local_rough_toeplitz_certificate_preconditioned.pdf` - compiled PDF, 7 pages.
- `check_preconditioned_local_certificate.sh` - exact rational shell checker.
- `preconditioned_local_certificate_constants.json` - constants certificate.
- `preconditioned_local_certificate_shell_output.txt` - checker output.
- `local_rough_toeplitz_certificate_preconditioned_summary.md` - readable theorem summary.
- `preconditioned_certificate_changelog.md` - comparison against the previous direct-estimate certificate.

## Scope boundary

This is a local rough-curve certificate. It does not prove the universal Toeplitz conjecture. It proves that a curve satisfying the four certified graph-window hypotheses contains a square.

## Claim boundary

Machine/checker certified:

1. rational constants and margin inequalities;
2. determinant value used in the model seed;
3. preconditioned error bound ledger.

Pen-and-paper theorem dependencies:

1. the square-map characterization by diagonal midpoint, equal length, and perpendicularity;
2. Brouwer degree invariance under boundary-avoiding homotopy;
3. the graph-window-to-subarc interpretation for Jordan curves.
