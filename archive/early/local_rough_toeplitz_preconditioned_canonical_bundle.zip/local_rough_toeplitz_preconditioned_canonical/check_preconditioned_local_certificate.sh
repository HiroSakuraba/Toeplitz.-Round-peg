#!/usr/bin/env bash
set -euo pipefail
checks=0
fail(){ echo "FAIL: $1" >&2; exit 1; }
pass(){ checks=$((checks+1)); }
# Constants: rho = 1/20, delta = 1/100.
# R = rho^2/2 = 1/800.
[[ $((20*20*2)) -eq 800 ]] && pass || fail "rho^2/2 denominator"
# P = (4+rho)delta + delta^2/2 = 811/20000.
# (4 + 1/20)/100 = 81/2000 = 810/20000; plus 1/20000.
[[ $((810+1)) -eq 811 ]] && pass || fail "P numerator"
# R + P = 1/800 + 811/20000 = 25/20000 + 811/20000 = 836/20000 = 209/5000.
[[ $((25+811)) -eq 836 ]] && pass || fail "total numerator over 20000"
[[ $((836/4)) -eq 209 ]] && pass || fail "total numerator reduced"
# rho = 1/20 = 250/5000. margin = 250/5000 - 209/5000 = 41/5000.
[[ $((250-209)) -eq 41 ]] && pass || fail "positive degree margin"
# Positivity of margin.
[[ 41 -gt 0 ]] && pass || fail "margin positive"
# Distinctness: 2 - 2(1/20+1/100) = 47/25.
# 1/20+1/100 = 6/100 = 3/50; twice is 3/25; 2=50/25; diff=47/25.
[[ $((50-3)) -eq 47 ]] && pass || fail "distinctness numerator"
[[ 47 -gt 0 ]] && pass || fail "distinctness positive"
# Window containment relative to protected half-length 2/25: rho=1/20 < 2/25.
# Cross-multiply: 25 < 40.
[[ 25 -lt 40 ]] && pass || fail "rho inside protected straight segment"
# Height safety relative to old certified separation 2/25: 2delta=1/50 < 2/25.
# Cross multiply: 25 < 100.
[[ 25 -lt 100 ]] && pass || fail "window height below separation scale"
# Improvement factor: old delta/rho = 1/50; new delta/rho = 1/5.
[[ $((50/5)) -eq 10 ]] && pass || fail "slope tolerance improvement factor"
cat <<JSON
{
  "status": "PASS",
  "checks": $checks,
  "rho": "1/20",
  "delta": "1/100",
  "model_remainder_bound": "1/800",
  "preconditioned_perturbation_bound": "811/20000",
  "total_error_bound": "209/5000",
  "boundary_margin": "41/5000",
  "distinctness_lower_bound": "47/25",
  "height_to_width_ratio": "1/5",
  "old_height_to_width_ratio": "1/50",
  "slope_tolerance_improvement_factor": 10
}
JSON
