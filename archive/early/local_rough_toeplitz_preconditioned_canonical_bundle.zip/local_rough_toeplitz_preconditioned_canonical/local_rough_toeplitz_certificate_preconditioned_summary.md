# Preconditioned local rough Toeplitz certificate — v2

This revision replaces the previous unpreconditioned perturbation estimate

\[
\|F_f-F_0\| \le 36\delta
\]

with a preconditioned degree argument using

\[
G=J^{-1}F,
\]

where \(J=DF_0(0)\) is the planar model square-map Jacobian.

## Main certified constants

The canonical constants are now

\[
\rho=\frac1{20},\qquad \delta=\frac1{100}.
\]

The theorem applies to four local graph arcs

\[
\Gamma_i=\{p_i+t v_i+f_i(t)n_i: |t|\le \rho\},
\]

with

\[
\|f_i\|_\infty\le\delta.
\]

## Preconditioned model map

For the model square seed, the preconditioned map satisfies

\[
G_0(t)=t+R(t),
\]

with the certified sup-norm bound

\[
\|R(t)\|_\infty\le \frac{\rho^2}{2}
\]

on the cube \(\|t\|_\infty\le \rho\).

## Perturbation bound

If each graph perturbation has height at most \(\delta\), then

\[
\|G_f(t)-G_0(t)\|_\infty
\le
(4+\rho)\delta+\frac{\delta^2}{2}.
\]

For \(\rho=1/20\), \(\delta=1/100\), this becomes

\[
\frac{\rho^2}{2}=\frac1{800},
\]

\[
(4+\rho)\delta+\frac{\delta^2}{2}=\frac{811}{20000}.
\]

Thus the total displacement from the identity on the parameter cube is

\[
\frac1{800}+\frac{811}{20000}
=\frac{209}{5000}
<\frac1{20}=\rho.
\]

The certified boundary margin is

\[
\rho-\frac{\rho^2}{2}-(4+\rho)\delta-\frac{\delta^2}{2}
=\frac{41}{5000}>0.
\]

## Theorem statement

**Preconditioned local rough Toeplitz certificate.**  Let \(\Gamma\) be a planar Jordan curve. Suppose that, around the four model square vertices

\[
(1,1),\quad(-1,1),\quad(-1,-1),\quad(1,-1),
\]

it contains four graph arcs over the model tangent directions

\[
(1,0),\quad(0,1),\quad(0,-1),\quad(-1,0),
\]

with window radius \(\rho=1/20\) and graph height \(\delta=1/100\). Then \(\Gamma\) contains an inscribed Euclidean square with one vertex on each graph arc.

## Improvement over the previous version

The previous certified version used

\[
\delta=\frac1{1000},
\qquad
\frac{\delta}{\rho}=\frac1{50}.
\]

The preconditioned version uses

\[
\delta=\frac1{100},
\qquad
\frac{\delta}{\rho}=\frac15.
\]

So the local height-to-width tolerance improves by a factor of 10.

## Scope

This remains a local certificate theorem. It does not prove universal Toeplitz. Its contribution is that arbitrary curve behavior outside the four certified windows is irrelevant, while the local windows themselves may be merely continuous graphs.
