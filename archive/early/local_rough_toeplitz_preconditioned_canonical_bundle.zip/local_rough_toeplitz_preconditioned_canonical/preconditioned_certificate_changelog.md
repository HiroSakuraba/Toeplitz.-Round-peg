# Changelog: preconditioned local rough certificate

## Trigger

Claude identified that the earlier lower-regularity certificate used a loose perturbation estimate

\[
\|F_f-F_0\| \le 36\delta.
\]

This made the admissible graph height artificially small.

## Revision

The proof now preconditions the square map by the inverse model Jacobian:

\[
G=J^{-1}F.
\]

For the model seed, this gives

\[
G_0(t)=t+R(t),
\qquad
\|R(t)\|_\infty\le \rho^2/2.
\]

For graph perturbations of height at most \(\delta\), the preconditioned perturbation satisfies

\[
\|G_f(t)-G_0(t)\|_\infty
\le
(4+\rho)\delta+\delta^2/2.
\]

## New canonical constants

\[
\rho=1/20,
\qquad
\delta=1/100.
\]

The certified inequality is

\[
\rho^2/2+(4+\rho)\delta+\delta^2/2
=209/5000
<1/20=ho.
\]

The margin is

\[
41/5000>0.
\]

## Effect

The old local height-to-width ratio was

\[
\delta/\rho = 1/50.
\]

The new ratio is

\[
\delta/\rho = 1/5.
\]

So the certified tolerance improves by a factor of 10.

## Claim boundary

The result remains a local certificate for curves with four graph windows. It does not imply universal Toeplitz and does not remove the need for a recognition/search algorithm on arbitrary input curves.
