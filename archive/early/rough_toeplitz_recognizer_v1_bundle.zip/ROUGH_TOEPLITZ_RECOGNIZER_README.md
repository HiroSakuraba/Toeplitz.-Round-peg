# Rough Toeplitz Recognizer v1

Files:

- `rough_toeplitz_recognizer.py` — sampled-curve recognition prototype.
- `rough_toeplitz_demo_curve.json` — built-in demo curve exported as JSON.
- `rough_toeplitz_recognition_demo_result.json` — PASS output for the demo.
- `rough_toeplitz_recognition_algorithm_v1.md` — design note and theorem boundary.

Run:

```bash
python3 rough_toeplitz_recognizer.py \
  --output rough_toeplitz_recognition_demo_result.json \
  --write-demo rough_toeplitz_demo_curve.json
```

Or check an input curve:

```bash
python3 rough_toeplitz_recognizer.py input_curve.json -o result.json
```

Input format:

```json
{
  "points": [[x0, y0], [x1, y1], ...],
  "closed": true,
  "candidate": {"center": [0, 0], "scale": 1, "angle": 0}
}
```

The result is a recognition report for the preconditioned local rough Toeplitz certificate with canonical constants

```text
rho = 1/20
Delta = 1/100
```

A PASS is a sampled recognition result, not a full interval proof. It identifies windows suitable for a later exact/Arb certificate.
