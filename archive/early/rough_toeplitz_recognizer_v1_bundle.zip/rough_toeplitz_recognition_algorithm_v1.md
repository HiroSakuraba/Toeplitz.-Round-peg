# Rough Toeplitz Recognition Algorithm v1

## Purpose

This document turns the preconditioned local rough Toeplitz certificate into a practical recognition workflow.

The theorem-level input is a planar Jordan curve containing four graph windows near the model square

\[
p_1=(1,1),\quad p_2=(-1,1),\quad p_3=(-1,-1),\quad p_4=(1,-1),
\]

with model tangent directions

\[
v_1=(1,0),\quad v_2=(0,1),\quad v_3=(0,-1),\quad v_4=(-1,0).
\]

For each window, write local coordinates

\[
x_i(z)=(z-p_i)\cdot v_i,
\qquad
 y_i(z)=(z-p_i)\cdot n_i.
\]

The preconditioned certificate uses the constants

\[
\rho=\frac1{20},\qquad \delta=\frac1{100}.
\]

If the curve contains graph arcs

\[
\Gamma_i=\{p_i+t v_i+f_i(t)n_i: |t|\le \rho\},
\qquad
\|f_i\|_\infty\le\delta,
\]

then it contains a nondegenerate inscribed square with one vertex on each graph arc.

## What `rough_toeplitz_recognizer.py` does

The v1 recognizer is a sampled-curve prototype. Given a closed polygonal sample and a candidate similarity transform, it:

1. normalizes the curve into model-square coordinates;
2. checks each of the four model windows;
3. searches near each square vertex for a sampled arc crossing from \(-\rho\) to \(+\rho\) in the local tangent coordinate;
4. verifies sampled height bound \(|y_i|\le\delta\);
5. verifies monotonicity in the local tangent coordinate for the sampled window arc;
6. emits a JSON recognition report.

The candidate similarity has the form

\[
z_{\rm model}=R(-\theta)\frac{z-c}{s},
\]

where \(c\) is a center, \(s>0\) is a scale, and \(\theta\) is a rotation angle.

## Scope and claim boundary

A `PASS` from this tool is not yet an Arb-certified proof. It means the sampled data pass strict discrete checks and are plausible input for a later interval verifier.

The current tool is therefore a recognition layer, not the final certificate layer.

The theorem chain is:

\[
\text{sampled recognizer PASS}
\quad\Rightarrow\quad
\text{candidate graph windows found}
\quad\Rightarrow\quad
\text{run exact/interval checker}
\quad\Rightarrow\quad
\text{local rough Toeplitz theorem applies}.
\]

## Demo result

The included demo curve is a closed sampled curve with four protected local arcs satisfying the graph-window condition. Running

```bash
python3 rough_toeplitz_recognizer.py \
  --output rough_toeplitz_recognition_demo_result.json \
  --write-demo rough_toeplitz_demo_curve.json
```

produces:

```text
status: PASS
rho: 0.05  delta: 0.01  height/width: 0.2
p1: PASS max_abs_y=0.0030000000000000027 monotone=increasing
p2: PASS max_abs_y=0.0030000000000000027 monotone=increasing
p3: PASS max_abs_y=0.0030000000000000027 monotone=increasing
p4: PASS max_abs_y=0.0030000000000000027 monotone=increasing
```

## Recognition theorem behind the workflow

**Recognition theorem, informal.**  
Let \(\Gamma\) be a sampled polygonal curve and suppose a candidate similarity transform places four subarcs of \(\Gamma\) into the model windows. If a rigorous interval checker proves that each subarc is a graph over \([-\rho,\rho]\) and satisfies \(|f_i|\le\delta\), then the preconditioned local rough Toeplitz certificate proves that \(\Gamma\) has an inscribed square.

For the current constants, the theorem uses

\[
\rho=\frac1{20},\qquad \delta=\frac1{100},
\]

and the preconditioned inequality

\[
\frac{\rho^2}{2}+(4+\rho)\delta+\frac{\delta^2}{2}<\rho.
\]

Explicitly,

\[
\frac{\rho^2}{2}+(4+\rho)\delta+\frac{\delta^2}{2}
=\frac{209}{5000}
<\frac1{20}.
\]

## Next upgrade

The next version should split into two layers:

1. **Search layer:** heuristically locate candidate similarities and windows in sampled data.
2. **Certificate layer:** verify graphness, height bounds, ordering, and window isolation using exact rational arithmetic or Arb intervals.

The v1 recognizer handles the first part when a candidate similarity is supplied. The missing piece is automatic candidate search.
