#!/usr/bin/env python3
"""
rough_toeplitz_recognizer.py

Prototype recognizer for the preconditioned local rough Toeplitz certificate.

It tries to verify the four local graph-window hypotheses near the model square
vertices

    p1=( 1, 1), p2=(-1, 1), p3=(-1,-1), p4=( 1,-1)

with tangent directions

    v1=( 1, 0), v2=(0, 1), v3=(0,-1), v4=(-1,0)

and constants rho=1/20, delta=1/100 by default.

Scope:
  - This is a recognition/prototyping tool for sampled polygonal curves.
  - It is not yet an Arb/interval proof of the graph-window hypotheses.
  - A PASS means the sampled curve satisfies strict discrete checks that are
    intended to feed a later exact/interval checker.

Input JSON format:
{
  "points": [[x0,y0], [x1,y1], ...],
  "closed": true,
  "candidate": {"center": [cx, cy], "scale": s, "angle": theta}
}

The candidate similarity maps physical points z to model coordinates by

    z_model = R(-theta) (z - center) / scale.

If no input file is supplied, the script builds and checks a demo curve.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

Point = Tuple[float, float]

MODEL_WINDOWS = [
    {"name": "p1", "p": (1.0, 1.0), "v": (1.0, 0.0), "n": (0.0, 1.0)},
    {"name": "p2", "p": (-1.0, 1.0), "v": (0.0, 1.0), "n": (-1.0, 0.0)},
    {"name": "p3", "p": (-1.0, -1.0), "v": (0.0, -1.0), "n": (-1.0, 0.0)},
    {"name": "p4", "p": (1.0, -1.0), "v": (-1.0, 0.0), "n": (0.0, -1.0)},
]


@dataclass
class Similarity:
    center: Point = (0.0, 0.0)
    scale: float = 1.0
    angle: float = 0.0

    def to_model(self, z: Point) -> Point:
        if self.scale <= 0:
            raise ValueError("scale must be positive")
        x = (z[0] - self.center[0]) / self.scale
        y = (z[1] - self.center[1]) / self.scale
        c = math.cos(-self.angle)
        s = math.sin(-self.angle)
        return (c * x - s * y, s * x + c * y)


def dot(a: Point, b: Point) -> float:
    return a[0] * b[0] + a[1] * b[1]


def sub(a: Point, b: Point) -> Point:
    return (a[0] - b[0], a[1] - b[1])


def add(a: Point, b: Point) -> Point:
    return (a[0] + b[0], a[1] + b[1])


def mul(c: float, a: Point) -> Point:
    return (c * a[0], c * a[1])


def norm2(a: Point) -> float:
    return dot(a, a)


def local_coords(z: Point, p: Point, v: Point, n: Point) -> Point:
    dz = sub(z, p)
    return (dot(dz, v), dot(dz, n))


def unwrap_indices(center_idx: int, n: int, radius: int) -> List[int]:
    return [(center_idx + k) % n for k in range(-radius, radius + 1)]


def monotone_score(xs: List[float]) -> Tuple[bool, str, float]:
    """Return whether xs is monotone after choosing traversal direction."""
    if len(xs) < 2:
        return False, "too_few_points", 0.0
    inc_bad = 0
    dec_bad = 0
    inc_min_step = float("inf")
    dec_min_step = float("inf")
    for a, b in zip(xs, xs[1:]):
        d = b - a
        if d < -1e-12:
            inc_bad += 1
        else:
            inc_min_step = min(inc_min_step, d)
        if d > 1e-12:
            dec_bad += 1
        else:
            dec_min_step = min(dec_min_step, -d)
    if inc_bad == 0:
        return True, "increasing", 0.0 if inc_min_step == float("inf") else inc_min_step
    if dec_bad == 0:
        return True, "decreasing", 0.0 if dec_min_step == float("inf") else dec_min_step
    return False, f"not_monotone inc_bad={inc_bad} dec_bad={dec_bad}", 0.0


def certify_one_window(
    points: Sequence[Point],
    window: Dict,
    rho: float,
    delta: float,
    *,
    closed: bool = True,
    search_radius: int = 80,
    slack: float = 1e-9,
) -> Dict:
    p = window["p"]
    v = window["v"]
    nvec = window["n"]
    npts = len(points)
    coords = [local_coords(z, p, v, nvec) for z in points]
    closest_idx = min(range(npts), key=lambda i: norm2(sub(points[i], p)))

    best = None
    max_radius = min(search_radius, npts // 2 - 1 if closed else npts)

    # Try growing symmetric index intervals around closest point.
    for rad in range(2, max_radius + 1):
        idxs = unwrap_indices(closest_idx, npts, rad) if closed else list(range(max(0, closest_idx-rad), min(npts, closest_idx+rad+1)))
        xy = [coords[i] for i in idxs]
        xs = [c[0] for c in xy]
        ys = [c[1] for c in xy]
        max_abs_y = max(abs(y) for y in ys)
        min_x = min(xs)
        max_x = max(xs)
        covers = min_x <= -rho + slack and max_x >= rho - slack
        inside_height = max_abs_y <= delta + slack
        if covers and inside_height:
            # Trim to portion with |x|<=rho plus a small buffer, preserving order.
            # Here the demo curves are sampled inside a protected arc, so the interval itself should be monotone.
            ok_mono, mono_dir, min_step = monotone_score(xs)
            candidate = {
                "radius_indices": rad,
                "point_count": len(idxs),
                "min_x": min_x,
                "max_x": max_x,
                "max_abs_y": max_abs_y,
                "closest_idx": closest_idx,
                "closest_distance": math.sqrt(norm2(sub(points[closest_idx], p))),
                "monotone": ok_mono,
                "monotone_direction": mono_dir,
                "min_monotone_step": min_step,
                "indices": idxs,
            }
            if ok_mono:
                best = candidate
                break
            if best is None:
                best = candidate

    status = "PASS" if best is not None and best["monotone"] else "FAIL"
    if best is None:
        best = {
            "closest_idx": closest_idx,
            "closest_distance": math.sqrt(norm2(sub(points[closest_idx], p))),
            "min_x": None,
            "max_x": None,
            "max_abs_y": None,
            "monotone": False,
            "monotone_direction": "no_covering_interval_found",
        }
    best.update({
        "name": window["name"],
        "status": status,
        "rho": rho,
        "delta": delta,
        "height_margin": None if best["max_abs_y"] is None else delta - best["max_abs_y"],
        "left_cover_margin": None if best["min_x"] is None else -rho - best["min_x"],
        "right_cover_margin": None if best["max_x"] is None else best["max_x"] - rho,
    })
    return best


def certify_curve(
    points: Sequence[Point],
    sim: Similarity,
    rho: float = 1.0 / 20.0,
    delta: float = 1.0 / 100.0,
    *,
    closed: bool = True,
) -> Dict:
    model_points = [sim.to_model(p) for p in points]
    windows = [certify_one_window(model_points, w, rho, delta, closed=closed) for w in MODEL_WINDOWS]
    status = "PASS" if all(w["status"] == "PASS" for w in windows) else "FAIL"
    return {
        "status": status,
        "scope": "sampled-curve recognition prototype; not an interval proof",
        "constants": {"rho": rho, "delta": delta, "height_to_width": delta / rho},
        "candidate_similarity": {"center": sim.center, "scale": sim.scale, "angle": sim.angle},
        "theorem_if_interval_certified": "preconditioned local rough Toeplitz certificate",
        "windows": windows,
    }


def sample_segment(a: Point, b: Point, m: int) -> List[Point]:
    return [(a[0] + (b[0]-a[0])*j/m, a[1] + (b[1]-a[1])*j/m) for j in range(m)]


def sample_local_arc(p: Point, v: Point, nvec: Point, t0: float, t1: float, m: int, amp: float = 0.003) -> List[Point]:
    pts = []
    for j in range(m):
        u = j / (m - 1)
        t = t0 + (t1 - t0) * u
        # Smooth small normal wiggle. It vanishes at center and is safely below delta=0.01.
        f = amp * math.sin(math.pi * t / max(abs(t0), abs(t1)))
        pts.append(add(add(p, mul(t, v)), mul(f, nvec)))
    return pts


def build_demo_curve() -> List[Point]:
    """Build a sampled closed curve with four certified local windows and arbitrary exterior connectors."""
    rho_arc = 0.075  # > rho=0.05, < old protected 0.08 scale
    m_arc = 33
    pts: List[Point] = []

    # Local protected arcs in curve order.
    p1, v1, n1 = (1.0, 1.0), (1.0, 0.0), (0.0, 1.0)
    p2, v2, n2 = (-1.0, 1.0), (0.0, 1.0), (-1.0, 0.0)
    p3, v3, n3 = (-1.0, -1.0), (0.0, -1.0), (-1.0, 0.0)
    p4, v4, n4 = (1.0, -1.0), (-1.0, 0.0), (0.0, -1.0)

    a1 = sample_local_arc(p1, v1, n1, -rho_arc, rho_arc, m_arc)
    a2 = sample_local_arc(p2, v2, n2, -rho_arc, rho_arc, m_arc)
    a3 = sample_local_arc(p3, v3, n3, -rho_arc, rho_arc, m_arc)
    a4 = sample_local_arc(p4, v4, n4, -rho_arc, rho_arc, m_arc)

    # Connectors are deliberately outside the graph windows.
    connectors = [
        [(1.075, 1.0), (1.35, 1.45), (0.2, 1.62), (-1.0, 1.075)],
        [(-1.0, 1.075), (-1.45, 0.6), (-1.55, -0.3), (-1.0, -0.925)],
        [(-1.0, -0.925), (-0.2, -1.65), (1.45, -1.35), (1.075, -1.0)],
        [(1.075, -1.0), (1.65, -0.3), (1.55, 0.6), (0.925, 1.0)],
    ]

    def append_no_dup(seq: Sequence[Point]) -> None:
        for p in seq:
            if not pts or norm2(sub(pts[-1], p)) > 1e-20:
                pts.append(p)

    append_no_dup(a1)
    append_no_dup(connectors[0])
    append_no_dup(a2)
    append_no_dup(connectors[1])
    append_no_dup(a3)
    append_no_dup(connectors[2])
    append_no_dup(a4)
    append_no_dup(connectors[3])
    return pts


def load_input(path: str) -> Tuple[List[Point], Similarity, bool]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    points = [tuple(map(float, p)) for p in data["points"]]
    closed = bool(data.get("closed", True))
    cand = data.get("candidate", {})
    sim = Similarity(
        center=tuple(map(float, cand.get("center", [0.0, 0.0]))),
        scale=float(cand.get("scale", 1.0)),
        angle=float(cand.get("angle", 0.0)),
    )
    return points, sim, closed


def main() -> int:
    parser = argparse.ArgumentParser(description="Recognize local rough Toeplitz graph-window certificates in sampled curves.")
    parser.add_argument("input", nargs="?", help="Input JSON curve file. If omitted, use built-in demo curve.")
    parser.add_argument("--rho", type=float, default=1.0/20.0)
    parser.add_argument("--delta", type=float, default=1.0/100.0)
    parser.add_argument("--output", "-o", default="rough_toeplitz_recognition_result.json")
    parser.add_argument("--write-demo", help="Write the built-in demo curve to this JSON file.")
    args = parser.parse_args()

    if args.input:
        points, sim, closed = load_input(args.input)
    else:
        points = build_demo_curve()
        sim = Similarity()
        closed = True

    if args.write_demo:
        with open(args.write_demo, "w", encoding="utf-8") as f:
            json.dump({"points": points, "closed": closed, "candidate": {"center": [0,0], "scale": 1, "angle": 0}}, f, indent=2)

    result = certify_curve(points, sim, args.rho, args.delta, closed=closed)
    result["input_points"] = len(points)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2)

    print(f"status: {result['status']}")
    print(f"rho: {args.rho:g}  delta: {args.delta:g}  height/width: {args.delta/args.rho:g}")
    for w in result["windows"]:
        print(f"{w['name']}: {w['status']} max_abs_y={w['max_abs_y']} monotone={w['monotone_direction']}")
    print(f"wrote: {args.output}")
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
