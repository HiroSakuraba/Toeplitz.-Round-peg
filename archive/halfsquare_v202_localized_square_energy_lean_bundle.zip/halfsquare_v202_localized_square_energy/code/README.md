# Verification code

The current v202 verifier runs with:

    python3 code/verify_v202.py

It passed 75 exact checks of the new energy, localization constants, and moving-charge formulas. See [recorded output](../results/verify_v202_output.txt) and the [v202 proof audit](../notes/proof_audit_v202.md). The analytic locality theorem is proved in the notes.

The retained v201 verifier uses **exact arithmetic only** and requires SymPy. It was checked with Python 3 and SymPy 1.14.0:

    python3 code/verify_v201.py

It checks the real positive-form identities, the sign of the four-point deficit, the finite-point product formulas on an analytic univalent calibration, the global rotation factor, the explicit pair-width constant, the nonadditive block model, the local/global phase counterexample, Faber generating-function conventions, the clearance constant, and the v200 compactified Jacobian.

The written proofs establish the analytic, measure-theoretic, and topological claims. This script does not certify them by sampling.

The scripts in history/ are retained from earlier versions. Some use floating-point diagnostics. Their outputs in results/history/ are preserved records rather than a new full-suite run. The historical sources import NumPy, SciPy, SymPy, mpmath, and in one case Shapely; install those only if running the corresponding scripts. The new verifier needs only SymPy.

The two historical modules verify_slope_reversals.py and verify_backtracking_degree.py remain beside each other so their local import works.

No interval arithmetic is used in v201 or v202. Any future interval certification should use SageMath, in accordance with the project convention.
