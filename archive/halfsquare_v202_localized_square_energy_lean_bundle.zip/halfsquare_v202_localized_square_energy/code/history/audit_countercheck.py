#!/usr/bin/env python3
import cmath

# v199 Möbius tangent calibration.
# Correct straightened domain for G(z)=z/(1+z) is Re X < 1/2.
a=0.4

def H(X):
    return X/(1-a*X)

def Hp(X):
    return 1/(1-a*X)**2

# The T derivative vanishes.
for T in (10,100,1000,10000):
    print(T, abs(Hp(1j*T)))

# But q=1/T is a natural compactifying coordinate:
# H(i/q)=i/(q-ai), so derivative at q=0 is i/a^2.
q_derivative = 1j/(a*a)
print('compactified q-derivative =', q_derivative)
assert abs(q_derivative) > 0

# Finite-difference confirmation.
def Zq(q):
    if q == 0:
        return -1/a
    return H(1j/q)
for h in (1e-2,1e-3,1e-4,1e-5):
    fd=(Zq(h)-Zq(0))/h
    print('h=',h,'fd=',fd,'error=',abs(fd-q_derivative))
assert abs((Zq(1e-6)-Zq(0))/1e-6-q_derivative) < 1e-4
print('PASS')
