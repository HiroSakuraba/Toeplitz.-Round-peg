"""Exploratory checks only: rational identities and floating-point roots.

No interval certification is claimed. The proof uses local degree/inversion.
"""
from fractions import Fraction as Q
import numpy as np
from scipy.optimize import root


def radii_squared(x, y):
    return [(x + 1)**2 + y*y, x*x + (y + 1)**2,
            (x - 1)**2 + y*y, x*x + (y - 1)**2]


def rational_checks():
    checked = 0
    for a in range(-7, 8):
        for b in range(-7, 8):
            x, y = Q(a, 3), Q(b, 5)
            q = x*x + y*y
            if not q:
                continue
            R = radii_squared(x, y)
            if not all(R):
                continue
            X, Y = x/q, y/q
            Ri = radii_squared(X, Y)
            assert all(Ri[j] == R[j]/q for j in range(4))
            assert all(1/Ri[j] - 1/Ri[0] == q*(1/R[j] - 1/R[0])
                       for j in (1, 2, 3))
            def modulus_squared(xx, yy):
                qq = xx*xx + yy*yy
                return (qq*qq - 2*(xx*xx-yy*yy) + 1)/(qq*qq + 2*(xx*xx-yy*yy) + 1)
            assert modulus_squared(X, Y) == modulus_squared(x, y)
            checked += 1
    print(f'Exact rational inversion identities: {checked} shapes passed')


def chart(wbase, m):
    units = np.array([1, 1j, -1, -1j])
    ub = wbase + units
    phi_base = np.angle(ub)
    chi = np.array([float(j >= m) for j in range(4)])

    def parts(w, lam):
        u = w + units
        R = np.abs(u)**2
        phi = phi_base + np.angle(u/ub)
        D = 1/R[1:] - 1/R[0]
        C = phi[1:] - phi[0] + np.pi*(chi[1:]-chi[0])
        ix = -2*u.real/R**2
        iy = -2*u.imag/R**2
        px = -u.imag/R
        py = u.real/R
        Dx, Dy = ix[1:]-ix[0], iy[1:]-iy[0]
        Cx, Cy = px[1:]-px[0], py[1:]-py[0]
        jac = np.column_stack((lam*Dx-Cx, lam*Dy-Cy, D))
        return lam*D-C, jac
    return parts


def solve_at(wbase, lam_base, m, label=None):
    parts = chart(wbase, m)
    if label is None:
        label = np.rint(parts(wbase, lam_base)[0]/(2*np.pi)).astype(int)
    def residual(t):
        w = wbase + (t[0]+1j*t[1])/lam_base
        return parts(w, lam_base+t[2])[0]-2*np.pi*label
    def jacobian(t):
        w = wbase + (t[0]+1j*t[1])/lam_base
        return parts(w, lam_base+t[2])[1] @ np.diag([1/lam_base, 1/lam_base, 1])
    sol = root(residual, np.zeros(3), jac=jacobian, options={'xtol':1e-10})
    err = np.linalg.norm(residual(sol.x), ord=np.inf)
    assert err < 1e-6, (sol.message, err)
    w = wbase + (sol.x[0]+1j*sol.x[1])/lam_base
    lam = lam_base + sol.x[2]
    sign = int(np.sign(np.linalg.det(parts(w, lam)[1])))
    assert w.real > w.imag
    if m == 1:
        assert w.real + w.imag < 0
    if m == 3:
        assert w.real + w.imag > 0
    R = np.array(radii_squared(w.real, w.imag))
    theta = lam/R - np.pi*np.array([float(j >= m) for j in range(4)])
    assert min(theta) > 1
    return w, lam, label, err, sign


def pairing_checks():
    print('base, Lambda, phase signs, Lambda*shape correction, lambda correction, max residual')
    for wb, m in [(2+0.3j, 3), (0.4+0.15j, 3), (-0.2-1.5j, 1), (0.6-0.2j, 2)]:
        for lam0 in (2000., 10000., 50000.):
            w, lam, n, err0, sign0 = solve_at(wb, lam0, m)
            q = abs(w)**2
            wi, li = w/q, lam/q
            wp, lp, npair, err1, sign1 = solve_at(wi, li, m, n)
            assert np.array_equal(n, npair)
            assert sign0 == -sign1
            # The phase charts need not identify a global integer label.
            # These checks use one fixed chart around each local solution.
            print(f'{wb!s:>12}, {lam0:7.0f}, {sign0:+d}/{sign1:+d}, '
                  f'{lam*abs(wp-wi):9.4f}, {lp-li:9.4f}, {max(err0,err1):.2e}')


def two_time_checks():
    errors = []
    for w in (2+0.3j, 0.4+0.15j, -0.2-1.5j, 0.6-0.2j):
        a, b = w+1, w-1
        c = b/a
        rho, delta = abs(c), np.angle(c)
        assert abs(rho-1) > 1e-3
        denominator = rho**(-2)-1
        for magnitude in (10, 100, 1000):
            k = magnitude if denominator > 0 else -magnitude
            t = (delta+2*np.pi*k)/denominator
            s = t/rho**2
            assert s > 0 and t > 0 and s != t
            zs = np.exp(1j*s)/np.sqrt(s)
            zt = np.exp(1j*t)/np.sqrt(t)
            err = abs(a*zs-b*zt)/max(abs(a*zs),abs(b*zt))
            errors.append(err)
            assert err < 1e-9
    print(f'Two-time ratio formula: {len(errors)} floating-point examples passed; '
          f'max relative residual {max(errors):.2e}')


if __name__ == '__main__':
    rational_checks()
    pairing_checks()
    two_time_checks()
