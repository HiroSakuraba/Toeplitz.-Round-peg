#!/usr/bin/env python3
import cmath, itertools, math, random

PASS=0
FAIL=[]

def check(cond, msg):
    global PASS
    if cond:
        PASS += 1
    else:
        FAIL.append(msg)

# ---------- helpers ----------
def chi(z):
    z0,z1,z2,z3=z
    return (z1-z0)*(z3-z2)/((z2-z0)*(z3-z1))

def k(z):
    return z/(1-z)**2

def ks(z,s):
    return z/(1-s*z)**2

def norm_closed(a,b):
    return math.log(abs(1-a*b.conjugate())**2/((1-abs(a)**2)*(1-abs(b)**2)))

def norm_sum(a,b,N=4000):
    return sum(abs(a**n-b**n)**2/n for n in range(1,N+1))

def q_koebe_factor(z,N=5000):
    # B=I, Q=-sum u_n v_n
    z0,z1,z2,z3=z
    return -sum((z0**n-z3**n)*(z1**n-z2**n)/n for n in range(1,N+1))

# 1. Square cross-ratios
sq=[1+0j,1j,-1+0j,-1j]
allowed={-1.0,0.5,2.0}
for p in itertools.permutations(range(4)):
    val=chi([sq[j] for j in p])
    check(abs(val.imag)<1e-12 and round(val.real,12) in allowed, f"square chi {p}: {val}")

# 2. Exact vector norm identity on deterministic random points
rng=random.Random(199)
for j in range(1200):
    r1=0.05+0.9*rng.random(); r2=0.05+0.9*rng.random()
    t1=2*math.pi*rng.random(); t2=2*math.pi*rng.random()
    a=r1*cmath.exp(1j*t1); b=r2*cmath.exp(1j*t2)
    c=norm_closed(a,b); s=norm_sum(a,b,1200)
    check(abs(c-s)<2e-9, f"norm identity {j}: {c} {s}")

# 3. Koebe exact cross-ratio/Grunsky factorization
for j in range(1500):
    r=0.15+0.72*rng.random()
    ts=sorted([2*math.pi*rng.random() for _ in range(4)])
    z=[r*cmath.exp(1j*t) for t in ts]
    actual=cmath.log(chi([k(x) for x in z])/chi(z))
    series=q_koebe_factor(z,500)
    # branch adjust by multiples of 2pi i
    diff=actual-series
    diff-=2j*math.pi*round(diff.imag/(2*math.pi))
    check(abs(diff)<2e-10, f"koebe Q {j}: {diff}")

# 4. k_s exact divided-difference formula and diagonal Grunsky calibration
for j in range(4000):
    s=0.05+0.94*rng.random()
    z=(0.85*rng.random())*cmath.exp(2j*math.pi*rng.random())
    w=(0.85*rng.random())*cmath.exp(2j*math.pi*rng.random())
    if abs(z-w)<1e-8: w*=0.9
    lhs=(ks(z,s)-ks(w,s))/(z-w)
    rhs=(1-s*s*z*w)/((1-s*z)**2*(1-s*w)**2)
    check(abs(lhs-rhs)<1e-10*(1+abs(rhs)), f"ks kernel {j}")
    n=1+(j%25)
    Bnn=s**(2*n)
    check(Bnn<=s*s+1e-15, f"ks norm diag {j}")

# 5. 2+2 asymptotics: chi_in ~ g1*g3/delta^2; long-vector norm ~2logR+O(1)
# sweep many eps,R,pair ratios with R*eps small.
for ei in range(1,121):
    eps=10**(-2.5-0.025*ei)
    for Ri in range(4,84):
        R=18.0+0.75*Ri
        delta=R*eps
        if delta>0.12: continue
        for acoef in (0.2,0.35,0.5,0.8,1.2):
            for bcoef in (0.22,0.4,0.65,1.0,1.4):
                g1=acoef*eps; g3=bcoef*eps
                if g1+g3>=0.12*delta: continue
                g2=delta-g1-g3
                exact=(math.sin(g1/2)*math.sin(g3/2))/(math.sin((g1+g2)/2)*math.sin((g2+g3)/2))
                approx=g1*g3/delta**2
                rel=abs(exact/approx-1)
                check(rel<0.16, f"2+2 chi asymp eps={eps} R={R} rel={rel}")
                r=1-eps
                A=math.log(1+4*r*r*math.sin(delta/2)**2/(1-r*r)**2)
                B=math.log(1+4*r*r*math.sin(g2/2)**2/(1-r*r)**2)
                # subtract 2 log R; should stay bounded in this regime
                check(abs(A-2*math.log(R))<3.5, f"A logR {A-2*math.log(R)}")
                check(abs(B-2*math.log(R))<4.5, f"B logR {B-2*math.log(R)}")

# 6. Spectral corridor: low-frequency mass O(1), high tail bounded, total grows ~2logR
for R in [8,12,20,32,50,80,120,180,250,350,500,700,1000]:
    eps=1e-5
    delta=R*eps
    r=1-eps
    # vector with angular sep delta, choose phases 0 and delta
    def e_n(n): return 4*(r**(2*n))*math.sin(n*delta/2)**2/n
    lowN=max(1,int(1/delta))
    low=sum(e_n(n) for n in range(1,lowN+1))
    # finite high tail start A/eps, truncate generously
    A0=8
    hi0=int(A0/eps)
    # approximate high tail with direct finite range to 20/eps (safe but costly); use bound instead
    high_bound=4*sum(math.exp(-2*eps*n)/n for n in range(hi0, int(12/eps)+1)) + 4*math.exp(-24)/(24) # crude remainder tiny
    total=math.log(1+4*r*r*math.sin(delta/2)**2/(1-r*r)**2)
    check(low<1.5, f"low corridor R={R} low={low}")
    check(high_bound<1e-6, f"high corridor R={R} high={high_bound}")
    check(abs(total-2*math.log(R))<3.0, f"total corridor R={R}")

# 7. Weak-coordinate test: fixed coordinates / normalized norm tend to zero
for n in range(1,101):
    prev=None
    vals=[]
    for R in [20,50,100,200,500,1000]:
        eps=R**(-3)
        delta=R*eps
        r=1-eps
        coord=abs((r**n)*(1-cmath.exp(1j*n*delta))/math.sqrt(n))
        norm=math.sqrt(math.log(1+4*r*r*math.sin(delta/2)**2/(1-r*r)**2))
        vals.append(coord/norm)
    check(vals[-1]<vals[0]/100, f"weak coord n={n} vals={vals}")

# 8. 3+1 Möbius half-plane calibration H_a=X/(1-aX)
for ai in range(1,101):
    a=0.02+0.015*ai
    L=-1/a
    last=None
    for T in [10,20,50,100,200,500,1000]:
        X=1j*T
        H=X/(1-a*X)
        Hp=1/(1-a*X)**2
        check(abs(H-L) < 1/(a*a*T)*1.05, f"H limit a={a} T={T}")
        check(abs(Hp) <= 1/(a*a*T*T), f"Hp bound a={a} T={T}")
        if last is not None:
            check(abs(Hp)<last, f"Hp monotone a={a} T={T}")
        last=abs(Hp)

# 9. Remote square-map Jacobian column scales linearly with |H'|
# complex column coefficients for j=3 in (S2,S3), derivative dZ/dT=iH'.
for ai in range(1,80):
    a=0.03+0.01*ai
    for T in [5,10,30,100,300]:
        Hp=1/(1-a*1j*T)**2
        dZ=1j*Hp
        c2=(1/4)*(1j**(-2*3))*dZ
        c3=(1/4)*(1j**(-3*3))*dZ
        norm4=math.sqrt(abs(c2)**2+abs(c3)**2)
        check(abs(norm4-abs(Hp)/math.sqrt(8))<1e-12, f"remote col a={a} T={T}")

print(f"PASS={PASS}")
print(f"FAIL={len(FAIL)}")
if FAIL:
    for x in FAIL[:50]: print(x)
    raise SystemExit(1)
