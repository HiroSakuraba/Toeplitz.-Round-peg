"""Exact rational checks for the lifted limiting map in the continuation.

These are 81 zeros of an auxiliary limiting map, not 81 certified squares
on a particular curve. Analytic degree and boundary arguments do that work.
No interval arithmetic or floating-point root solver is used here.
"""
from fractions import Fraction as F
from itertools import product


def determinant(matrix):
    a = [list(row) for row in matrix]
    n = len(a)
    out = F(1)
    for k in range(n):
        pivot = next((i for i in range(k, n) if a[i][k]), None)
        if pivot is None:
            return F(0)
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            out = -out
        d = a[k][k]
        out *= d
        for i in range(k + 1, n):
            multiplier = a[i][k]/d
            for j in range(k + 1, n):
                a[i][j] -= multiplier*a[k][j]
    return out


def sign(x):
    return 1 if x > 0 else -1 if x < 0 else 0


def main():
    # Shape w=3/4, tau=1 gives four rational vertex radii.
    u = [(F(7,4),F(0)), (F(3,4),F(1)),
         (F(-1,4),F(0)), (F(3,4),F(-1))]
    rho = [F(7,4),F(5,4),F(1,4),F(5,4)]
    assert all(x*x+y*y == r*r for (x,y),r in zip(u,rho))
    radial_gradient = [[x/r,y/r,r] for (x,y),r in zip(u,rho)]
    phase_slope = [-2/r**3 for r in rho]
    DH = [[phase_slope[j]*radial_gradient[j][k]
           - phase_slope[0]*radial_gradient[0][k]
           for k in range(3)] for j in (1,2,3)]
    detH = determinant(DH)
    assert detH < 0

    lo, hi = F(1,20), F(39,20)
    nodes = [(F(0),lo), (F(1,3),lo+(hi-lo)*F(9,10)),
             (F(2,3),lo+(hi-lo)*F(1,10)), (F(1),hi)]
    branches = []
    for r in rho:
        roots = []
        for (ta,ra),(tb,rb) in zip(nodes,nodes[1:]):
            slope = (rb-ra)/(tb-ta)
            t = ta+(r-ra)/slope
            if ta < t < tb:
                assert ra+slope*(t-ta) == r
                roots.append((t,slope))
        assert len(roots) == 3
        assert [sign(slope) for _,slope in roots] == [1,-1,1]
        branches.append(roots)

    npositive = nnegative = 0
    for choices in product(*branches):
        slopes = [pair[1] for pair in choices]
        M = [[F(0) for _ in range(7)] for _ in range(7)]
        for j in range(4):
            M[j][j] = slopes[j]
            for k in range(3):
                M[j][4+k] = -radial_gradient[j][k]
        for row,j in enumerate((1,2,3),start=4):
            M[row][0] = -phase_slope[0]*slopes[0]
            M[row][j] = phase_slope[j]*slopes[j]
        detM = determinant(M)
        expected = detH
        for slope in slopes:
            expected *= slope
        assert detM == expected != 0
        npositive += detM > 0
        nnegative += detM < 0

    assert npositive == 40 and nnegative == 41
    assert npositive-nnegative == sign(detH)
    print('Exact profile Jacobian determinant:', detH)
    print('Each radial target has three crossings with signs +1, -1, +1.')
    print('Lifted limiting-map zeros checked:', npositive+nnegative)
    print('Positive degrees:', npositive)
    print('Negative degrees:', nnegative)
    print('Total degree:', npositive-nnegative)
    print('All 81 exact 7x7 determinant factorizations: PASS')
    print('Radial backtracking preserves the nonzero profile degree: PASS')
    print('These checks support the algebra; they do not certify a concrete curve square.')


if __name__ == '__main__':
    main()
