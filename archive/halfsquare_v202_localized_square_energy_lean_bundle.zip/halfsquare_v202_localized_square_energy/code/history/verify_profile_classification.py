"""Exact algebra for continuation_profile_classification.md.

Polynomial dictionaries check identities, not a finite sample of shapes.
Fraction-valued Taylor jets check the oscillating example at u=1.
These checks do not certify individual curve squares or prove the topological
and compactness arguments. No interval or floating-point arithmetic is used.
"""

from fractions import Fraction as F
from itertools import permutations
from math import factorial


class Poly:
    def __init__(self, n, terms):
        self.n = n
        self.terms = {e: F(c) for e, c in terms.items() if c}

    @classmethod
    def constant(cls, n, c):
        return cls(n, {(0,) * n: F(c)})

    @classmethod
    def variable(cls, n, j):
        e = [0] * n
        e[j] = 1
        return cls(n, {tuple(e): F(1)})

    def coerce(self, other):
        if isinstance(other, Poly):
            assert other.n == self.n
            return other
        return Poly.constant(self.n, other)

    def __add__(self, other):
        other = self.coerce(other)
        terms = dict(self.terms)
        for e, c in other.terms.items():
            terms[e] = terms.get(e, F(0)) + c
        return Poly(self.n, terms)

    __radd__ = __add__

    def __neg__(self):
        return Poly(self.n, {e: -c for e, c in self.terms.items()})

    def __sub__(self, other):
        return self + (-self.coerce(other))

    def __rsub__(self, other):
        return self.coerce(other) - self

    def __mul__(self, other):
        other = self.coerce(other)
        terms = {}
        for a, ca in self.terms.items():
            for b, cb in other.terms.items():
                e = tuple(x + y for x, y in zip(a, b))
                terms[e] = terms.get(e, F(0)) + ca * cb
        return Poly(self.n, terms)

    __rmul__ = __mul__

    def __pow__(self, exponent):
        assert isinstance(exponent, int) and exponent >= 0
        out = Poly.constant(self.n, 1)
        for _ in range(exponent):
            out = out * self
        return out

    def derivative(self, j):
        terms = {}
        for e, c in self.terms.items():
            if e[j]:
                power = list(e)
                power[j] -= 1
                terms[tuple(power)] = e[j] * c
        return Poly(self.n, terms)

    def evaluate(self, values):
        assert len(values) == self.n
        out = F(0)
        for e, c in self.terms.items():
            term = c
            for value, power in zip(values, e):
                term *= F(value) ** power
            out += term
        return out

    def __eq__(self, other):
        other = self.coerce(other)
        return self.terms == other.terms


def determinant(matrix):
    n = len(matrix)
    total = Poly.constant(matrix[0][0].n, 0)
    for perm in permutations(range(n)):
        inversions = sum(perm[i] > perm[j]
                         for i in range(n) for j in range(i + 1, n))
        term = Poly.constant(total.n, (-1) ** inversions)
        for i, j in enumerate(perm):
            term *= matrix[i][j]
        total += term
    return total


def jet_product(a, b, degree):
    return [sum((a[j] * b[k - j]
                 for j in range(k + 1)
                 if j < len(a) and k - j < len(b)), F(0))
            for k in range(degree + 1)]


def jet_reciprocal(a, degree):
    assert a[0] != 0
    out = [1 / a[0]]
    for k in range(1, degree + 1):
        out.append(-sum((a[j] * out[k - j]
                         for j in range(1, min(k, len(a) - 1) + 1)),
                        F(0)) / a[0])
    return out


def main():
    h = [Poly.variable(4, j) for j in range(4)]
    # Gradients of A+B, A+C, A-B, A-C, with columns A, B, C.
    du = [(1, 1, 0), (1, 0, 1), (1, -1, 0), (1, 0, -1)]
    jacobian = [[h[j] * du[j][k] - h[0] * du[0][k]
                 for k in range(3)] for j in (1, 2, 3)]
    phase_det = determinant(jacobian)
    expected = 2 * (h[1] * h[2] * h[3] + h[0] * h[1] * h[3]
                    - h[0] * h[2] * h[3] - h[0] * h[1] * h[2])
    assert phase_det == expected
    assert len(phase_det.terms) == 4
    print('Universal phase determinant polynomial: PASS (four cubic monomials)')

    x, y, tau = [Poly.variable(3, j) for j in range(3)]
    coordinates = [tau**2 * (1 + x**2 + y**2),
                   2 * tau**2 * x, 2 * tau**2 * y]
    coordinate_det = determinant([[entry.derivative(j) for j in range(3)]
                                  for entry in coordinates])
    assert coordinate_det == 8 * tau**5 * (1 - x**2 - y**2)
    print('Squared-radius coordinate determinant: PASS (8*tau^5*(1-x^2-y^2))')

    squared_radii = [F(4), F(7, 2), F(2), F(5, 2)]
    assert phase_det.evaluate([F(7, 3)] * 4) == 0
    assert phase_det.evaluate([2 / (u + 3) for u in squared_radii]) == 0
    print('Affine and shifted-log derivative examples: exact zero determinants')

    point = [F(3, 4), F(0), F(1)]
    A, B, C = [entry.evaluate(point) for entry in coordinates]
    radii2 = [A + B, A + C, A - B, A - C]
    det_power = phase_det.evaluate([-1 / u**2 for u in radii2])
    old_det = det_power * coordinate_det.evaluate(point)
    assert old_det == F(-19327352832, 133984375)
    print('Agreement with the earlier p=2 profile determinant:', old_det)

    # Formal jets at u=1, with z=u-1, through degree three.
    log_jet = [F(0), F(1), F(-1, 2), F(1, 3)]
    log_squared = jet_product(log_jet, log_jet, 3)
    log_cubed = jet_product(log_squared, log_jet, 3)
    sin_log_jet = [a - b / 6 for a, b in zip(log_jet, log_cubed)]
    numerator = list(sin_log_jet)
    numerator[0] += 3
    g_jet = jet_product(numerator, [F(1), F(-1), F(1), F(-1)], 3)
    assert g_jet == [F(3), F(-2), F(3, 2), F(-4, 3)]
    g_derivatives = [factorial(j) * g_jet[j] for j in range(1, 4)]
    assert g_derivatives == [F(-2), F(3), F(-8)]
    h_jet = [(j + 1) * g_jet[j + 1] for j in range(3)]
    k_jet = jet_reciprocal(h_jet, 2)
    assert k_jet == [F(-1, 2), F(-3, 4), F(-1, 8)]
    k_second = 2 * k_jet[2]
    leading_det = 2 * h_jet[0]**4 * k_second
    assert k_second == F(-1, 4) and leading_det == -8
    print("For g(u)=(3+sin(log u))/u, [g'(1),g''(1),g'''(1)]:",
          ', '.join(map(str, g_derivatives)))
    print("For k=1/g', k''(1):", k_second)
    print('det D(Psi_g)(1,B,0) / B^2 tends to:', leading_det)

    # Cone over the logarithmic relative-radius map, at w=2.
    # L3 and L5 are formal independent variables standing for log(3), log(5).
    L3, L5 = [Poly.variable(2, j) for j in range(2)]
    log_radii = [L3, L5 * F(1, 2), Poly.constant(2, 0), L5 * F(1, 2)]
    vertex_vectors = [(F(3), F(0)), (F(2), F(1)),
                      (F(1), F(0)), (F(2), F(-1))]
    log_gradients = [[v / (xx*xx + yy*yy) for v in (xx, yy)]
                     for xx, yy in vertex_vectors]
    cone_matrix = [[Poly.constant(2, log_gradients[j][k] - log_gradients[0][k])
                    for k in range(2)] + [log_radii[j] - log_radii[0]]
                   for j in (1, 2, 3)]
    cone_det = determinant(cone_matrix)
    assert cone_det == F(2, 75) * (9 * L3 - 5 * L5)
    assert 3**9 == 19683 and 5**5 == 3125 and 3**9 > 5**5
    print('Logarithmic cone determinant at w=2: (2/75)*log(19683/3125) > 0')
    print('Cone determinant identity and exact integer sign certificate: PASS')
    print('All polynomial identities and rational Taylor-jet checks: PASS')
    print('Analytic degree, classification, and compactness proofs are in the note.')


if __name__ == '__main__':
    main()
