"""Exact checks for continuation_slope_reversals.md.

The 243 zeros below belong to an auxiliary model after the phase homotopies.
They are not 243 certified squares on a concrete curve. Determinants are
linear combinations of log(3) and log(5); their two rational coefficients
are computed independently by exact Gaussian elimination.
"""

from fractions import Fraction as Q
from itertools import product

from verify_backtracking_degree import determinant, sign


def segment_slopes(nodes):
    return [(yb - ya) / (xb - xa)
            for (xa, ya), (xb, yb) in zip(nodes, nodes[1:])]


def crossings(nodes, target):
    out = []
    for (xa, ya), (xb, yb) in zip(nodes, nodes[1:]):
        slope = (yb - ya) / (xb - xa)
        root = xa + (target - ya) / slope
        if xa < root < xb:
            assert ya + slope * (root - xa) == target
            out.append((root, slope))
    return out


def matrix_coefficients(radial_slopes, pitch_slope):
    # At w=2, columns are four contacts, x, y, and the scale parameter v.
    vectors = [(Q(3), Q(0)), (Q(2), Q(1)),
               (Q(1), Q(0)), (Q(2), Q(-1))]
    gradients = [[c / (x*x + y*y) for c in (x, y)] for x, y in vectors]
    # D(w=2) = ((log(5))/2-log(3), -log(3), (log(5))/2-log(3)).
    D_coefficients = [(Q(-1), Q(1, 2)), (Q(-1), Q(0)), (Q(-1), Q(1, 2))]
    coefficients = []
    for logarithm in (0, 1):
        matrix = [[Q(0) for _ in range(7)] for _ in range(7)]
        for j in range(4):
            matrix[j][j] = radial_slopes[j]
            matrix[j][4] = gradients[j][0]
            matrix[j][5] = gradients[j][1]
            matrix[j][6] = Q(-1)
        for row, j in enumerate((1, 2, 3), start=4):
            matrix[row][4] = -(gradients[j][0] - gradients[0][0])
            matrix[row][5] = -(gradients[j][1] - gradients[0][1])
            matrix[row][6] = -pitch_slope * D_coefficients[j - 1][logarithm]
        coefficients.append(determinant(matrix))
    return coefficients


def trig_log_derivative(power, sine_coefficient, cosine_coefficient):
    # d/dT [T^p (A sin(log T) + B cos(log T))].
    return (power - 1,
            power * sine_coefficient - cosine_coefficient,
            sine_coefficient + power * cosine_coefficient)


def main():
    pitch_nodes = [(Q(0), Q(1, 2)), (Q(1, 3), Q(7, 5)),
                   (Q(2, 3), Q(3, 5)), (Q(1), Q(3, 2))]
    pitch_roots = crossings(pitch_nodes, Q(1))
    assert len(pitch_roots) == 3
    assert [sign(slope) for _, slope in pitch_roots] == [1, -1, 1]

    radial_nodes = [(Q(0), Q(2)), (Q(1, 3), Q(-7, 4)),
                    (Q(2, 3), Q(7, 4)), (Q(1), Q(-2))]
    radial_slopes = segment_slopes(radial_nodes)
    assert [sign(slope) for slope in radial_slopes] == [-1, 1, -1]

    # Exact analytic bounds: exp(3/2) > 1+3/2+(3/2)^2/2 > 3,
    # and exp(3) > 1+3+3^2/2 > 5. Thus every log-radius target
    # v-log|2+i^j| is between -3/2 and 1 for 0<v<1, so each
    # target has three crossings through the extrema +/-7/4.
    assert 1 + Q(3, 2) + Q(3, 2)**2 / 2 > 3
    assert 1 + Q(3) + Q(3)**2 / 2 > 5
    assert Q(-7, 4) < Q(-3, 2) and 1 < Q(7, 4)

    cone_coefficients = [Q(6, 25), Q(-2, 15)]
    assert cone_coefficients == [Q(2, 75)*9, -Q(2, 75)*5]
    assert 3**9 > 5**5  # J=(2/75)*log(3^9/5^5)>0.

    positive = negative = 0
    for _, pitch_slope in pitch_roots:
        for radial_choices in product(radial_slopes, repeat=4):
            multiplier = -pitch_slope
            for slope in radial_choices:
                multiplier *= slope
            observed = matrix_coefficients(radial_choices, pitch_slope)
            assert observed == [multiplier * c for c in cone_coefficients]
            positive += multiplier > 0
            negative += multiplier < 0
    assert (positive, negative) == (121, 122)
    assert positive - negative == -1
    print('Slope-level crossings: +1, -1, +1; total +1')
    print('Each log-radius target crosses: -1, +1, -1; total -1')
    print('Auxiliary model zeros:', positive + negative)
    print('Positive local degrees:', positive)
    print('Negative local degrees:', negative)
    print('Total degree:', positive - negative)
    print('All 243 determinant identities, both rational log coefficients: PASS')

    first = trig_log_derivative(Q(2), Q(2, 5), Q(-1, 5))
    second = trig_log_derivative(*first)
    assert first == (Q(1), Q(1), Q(0))
    assert second == (Q(0), Q(1), Q(1))
    print('Oscillating example: F_prime=T*sin(log T), F_double_prime=sin(log T)+cos(log T)')
    print('Exact differentiation of the oscillating model: PASS')

    first_area = Q(1, 64)
    tail_ratio = Q(1, 4)
    total_angle = first_area / (1 - tail_ratio)
    peak_times_tail_bound = Q(2) * total_angle
    assert total_angle == Q(1, 48)
    assert peak_times_tail_bound == Q(1, 24)
    assert 2 * peak_times_tail_bound < 1
    print('Spike example: total angular change 1/48; a(T)*delta(T) <= 1/24')
    print('Exact geometric-series bounds for the square-free arc: PASS')
    print('These checks verify algebra and model degree, not individual curve squares.')


if __name__ == '__main__':
    main()
