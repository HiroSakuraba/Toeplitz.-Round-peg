import math
from fractions import Fraction as F
import numpy as np
from scipy.optimize import root

# ------------------------------------------------------------
# Exact limiting map for f(t)=t^2
# ------------------------------------------------------------
# H = ((v+b)^2-(v-a)^2, (v+a)^2-(v-a)^2, (v-b)^2-(v-a)^2)
# determinant is -32*v*(a-b)*(a+b).
def det_quadratic(a,b,v):
    return -32*v*(a-b)*(a+b)

assert det_quadratic(F(1),F(1,2),F(3)) == F(-72)

# Finite-difference exact Jacobian check by symbolic-free rational algebra.
def H_quad(a,b,v):
    return np.array([
        float((v+b)*(v+b)-(v-a)*(v-a)),
        float((v+a)*(v+a)-(v-a)*(v-a)),
        float((v-b)*(v-b)-(v-a)*(v-a)),
    ])

# ------------------------------------------------------------
# Large-w / shrinking-window radial coordinates
# ------------------------------------------------------------
def tcoords(q,v,delta):
    vals=[]
    for j in range(4):
        vals.append(v-math.log(abs(1+delta*q*(1j**j)))/delta)
    return np.array(vals)

q0=1+0.5j
v0=3.0
ulim=np.array([2.0,3.5,4.0,2.5])
for delta in [0.05,0.02,0.01,0.005]:
    err=np.max(np.abs(tcoords(q0,v0,delta)-ulim))
    assert err < 2.0*delta

# ------------------------------------------------------------
# Exact local phase map for the quadratic shrinking-window model
# ------------------------------------------------------------
def phase_map(vars,A,delta):
    a,b,v=vars
    q=a+1j*b
    tc=tcoords(q,v,delta)
    phases=np.array([np.angle(1+delta*q*(1j**j)) for j in range(4)])
    Fv=A*tc*tc
    return np.array([
        Fv[j]-Fv[0]-(phases[j]-phases[0])
        for j in range(1,4)
    ]), tc

A=500.0
delta=0.01
pm,tc=phase_map([1,0.5,3],A,delta)
n=np.rint(pm/(2*math.pi)).astype(int)

def fun(x):
    return phase_map(x,A,delta)[0]-2*math.pi*n

sol=root(fun,[1,0.5,3],method="hybr",options={"xtol":1e-12,"maxfev":2000})
assert sol.success
assert np.linalg.norm(sol.fun)<2e-7

q=sol.x[0]+1j*sol.x[1]
v=sol.x[2]
tc=phase_map(sol.x,A,delta)[1]

# Exact square construction at arbitrary T0, psi.
T0=10.0
psi=0.37
common=math.exp(-T0-delta*v)*np.exp(1j*psi)
z=np.array([common*(1+delta*q*(1j**j)) for j in range(4)])
k1=z[1]-z[0]+1j*(z[3]-z[0])
k2=z[2]-z[0]-(1-1j)*(z[3]-z[0])
assert abs(k1)<1e-15
assert abs(k2)<1e-15

# Side/radius scaling: ell / e^{-T0} ~ sqrt(2)*delta*|q|.
ell=abs(z[1]-z[0])
ratio=ell/math.exp(-T0)
target=math.sqrt(2)*delta*abs(q)*math.exp(-delta*v)
assert abs(ratio-target)<1e-12

# ------------------------------------------------------------
# Spike-mass audit
# ------------------------------------------------------------
# Proposition-24 scaling: height 2^n, width 2^{-3n-4}.
for n0 in range(1,20):
    M=2.0**n0
    width=2.0**(-3*n0-4)
    mass=M*width
    assert abs(mass-2.0**(-2*n0-4))<1e-30

# Divergent-mass example: M_n=2^{3n}, delta_n=2^{-2n}.
masses=[]
for n0 in range(1,12):
    M=2.0**(3*n0)
    width=2.0**(-2*n0)
    masses.append(M*width)
assert all(masses[i+1]>masses[i] for i in range(len(masses)-1))
assert masses[-1]>1000

print("v149 exact quadratic limiting determinant det=-72: PASS")
print("v149 shrinking-window log-radius asymptotics: PASS")
print("v149 exact phase-lattice numerical root: PASS")
print("v149 exact square reconstruction from shrinking-window coordinates: PASS")
print("v149 side/radius ~ delta scaling: PASS")
print("v149 Proposition-24 spike mass tends to zero: PASS")
print("v149 divergent height-times-width example: PASS")
print("numerical root q =",q)
print("numerical root v =",v)
print("normalized log radii =",tc.tolist())
print("lattice target n =",n.tolist())
print("phase residual =",float(np.linalg.norm(sol.fun)))
