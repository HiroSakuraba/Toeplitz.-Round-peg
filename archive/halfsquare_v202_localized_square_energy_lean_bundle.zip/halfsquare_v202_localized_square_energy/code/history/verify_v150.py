import math
from fractions import Fraction as F
import numpy as np

# ------------------------------------------------------------
# Affine leading: K_g determinant checks
# ------------------------------------------------------------
def Q_and_Qv(g,gp,a,b,v):
    us=[v-a,v+b,v+a,v-b]
    Q=g(us[0])-g(us[1])+g(us[2])-g(us[3])
    Qv=gp(us[0])-gp(us[1])+gp(us[2])-gp(us[3])
    return Q,Qv

# cubic secondary: Qv = 6(a^2-b^2)
a=1.0; b=0.5; v=0.0
_,qv=Q_and_Qv(lambda t:t**3,lambda t:3*t*t,a,b,v)
assert abs(qv-4.5)<1e-12
detK=-2*qv
assert abs(detK+9)<1e-12

# quadratic secondary is invisible at two-scale order
rng=np.random.default_rng(20260907)
for _ in range(10000):
    a,b,v=rng.normal(size=3)
    _,qv=Q_and_Qv(lambda t:t*t,lambda t:2*t,a,b,v)
    assert abs(qv)<1e-10

# ------------------------------------------------------------
# Exact quadratic full Jacobian formula
# ------------------------------------------------------------
def J_quad(A,B,a,b,v):
    return np.array([
        [A+B*(-2*a+2*v), A+B*(2*b+2*v), 2*B*(a+b)],
        [2*A+4*B*v,     0.0,            4*B*a],
        [A+B*(-2*a+2*v), -A+B*(2*b-2*v), 2*B*(a-b)],
    ],float)

for A,B,a,b,v in [
    (1000.0,10.0,1.0,0.5,3.0),
    (5000.0,30.0,0.8,0.2,-1.0),
    (200.0,5.0,1.2,-0.4,2.0),
]:
    J=J_quad(A,B,a,b,v)
    det=np.linalg.det(J)
    expected=-16*B**2*(A+2*B*v)*(a-b)*(a+b)
    assert abs(det-expected) <= 1e-7*max(1,abs(expected))

# weak singular-value scale ~ B^2/A
ratios=[]
for A,B in [(1e6,1e3),(1e8,1e4),(1e10,1e5)]:
    s=np.linalg.svd(J_quad(A,B,1.0,0.5,3.0),compute_uv=False)
    ratios.append(s[-1]/(B*B/A))
assert max(ratios)/min(ratios) < 1.05
assert 3.0 < ratios[0] < 4.0

# Exact transformed quadratic map derivative Y3 along fixed Y1,Y2.
# Formula:
# dY3/dv = 8 B^2 p q / (-A+B(p+q-2v))
for A,B,p,q,v in [
    (1000.0,10.0,1.5,0.5,3.0),
    (10000.0,20.0,1.2,0.7,-2.0),
]:
    denom=-A+B*(p+q-2*v)
    val=8*B*B*p*q/denom
    assert math.isfinite(val)
    assert abs(val) > 0

# ------------------------------------------------------------
# Shifted-log leading: exact normal functional and kernel derivative
# ------------------------------------------------------------
def log_secondary_normal(g,a,b,s):
    xs=[s-a,s+b,s+a,s-b]
    assert min(xs)>0
    vals=[g(x) for x in xs]
    Q=xs[0]*vals[0]-xs[1]*vals[1]+xs[2]*vals[2]-xs[3]*vals[3]
    return Q/xs[0]

def kernel_derivative_formula(gp,a,b,s):
    xs=[s-a,s+b,s+a,s-b]
    return (xs[0]**2*gp(xs[0])-xs[1]**2*gp(xs[1])
            +xs[2]**2*gp(xs[2])-xs[3]**2*gp(xs[3]))/xs[0]

# Invisible tangent-family checks: constant, log x, 1/x.
for _ in range(1000):
    aa=float(rng.uniform(0.05,0.8))
    bb=float(rng.uniform(0.05,0.8))
    ss=float(rng.uniform(max(aa,bb)+0.5,4.0))
    vals=[
        kernel_derivative_formula(lambda x:0.0,aa,bb,ss),
        kernel_derivative_formula(lambda x:1/x,aa,bb,ss),
        kernel_derivative_formula(lambda x:-1/(x*x),aa,bb,ss),
    ]
    assert max(abs(z) for z in vals)<1e-9

# Linear secondary g(x)=x is regular at (1,1/2,3).
aa=1.0; bb=0.5; ss=3.0
vd=kernel_derivative_formula(lambda x:1.0,aa,bb,ss)
assert abs(vd-0.75)<1e-12

# Exact determinant for K=(log(x1/x0),log(x3/x0),N_g), g=x:
# -4(a^2-b^2)/((s-a)^2(s-b)(s+b))
det_exact=-4*(aa*aa-bb*bb)/((ss-aa)**2*(ss-bb)*(ss+bb))
assert abs(det_exact+3/35)<1e-12

# Numerical finite-difference determinant agrees.
def K_log_linear(a,b,s):
    x0=s-a; x1=s+b; x2=s+a; x3=s-b
    H1=math.log(x1/x0)
    H3=math.log(x3/x0)
    N=(x0*x0-x1*x1+x2*x2-x3*x3)/x0
    return np.array([H1,H3,N],float)

eps=1e-6
x=np.array([aa,bb,ss],float)
J=np.zeros((3,3))
for j in range(3):
    e=np.zeros(3); e[j]=eps
    J[:,j]=(K_log_linear(*(x+e))-K_log_linear(*(x-e)))/(2*eps)
det_num=np.linalg.det(J)
assert abs(det_num-det_exact)<1e-8

print("v150 affine cubic-secondary regular determinant = -9: PASS")
print("v150 quadratic-secondary two-scale invisibility stress audit: PASS")
print("v150 exact affine+quadratic Jacobian formula: PASS")
print("v150 quadratic weak singular scale sigma_min ~ B^2/A: PASS")
print("v150 exact dY3/dv third-scale formula audit: PASS")
print("v150 shifted-log invisible tangent-family checks: PASS")
print("v150 shifted-log linear-secondary kernel restoration: PASS")
print("v150 exact shifted-log regular determinant = -3/35: PASS")
