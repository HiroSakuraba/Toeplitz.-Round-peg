import math
import sympy as sp
import numpy as np

# ------------------------------------------------------------
# Exact polynomial relative phase map
# ------------------------------------------------------------
a,b,v,A,B,C,D,t = sp.symbols("a b v A B C D t", real=True)
u=[v-a,v+b,v+a,v-b]

def H(expr):
    z=[sp.expand(expr.subs(t,x)) for x in u]
    return sp.Matrix([z[1]-z[0],z[2]-z[0],z[3]-z[0]])

L=sp.Matrix([[1,0,0],[0,0,1],[-1,1,-1]])
assert L.det()==-1

Ht=L*H(t)
Ht2=L*H(t**2)
Ht3=L*H(t**3)

p=a+b
q=a-b
assert all(sp.simplify(x-y)==0 for x,y in zip(Ht,sp.Matrix([p,q,0])))
assert all(sp.simplify(x-y)==0 for x,y in zip(
    Ht2,
    sp.Matrix([p*(2*v-q),q*(2*v-p),2*p*q])
))
assert sp.simplify(Ht3[2]-6*p*q*v)==0

# ------------------------------------------------------------
# Third-scale determinant classification checks
# ------------------------------------------------------------
theta=sp.symbols("theta", positive=True)
Qv3=sp.diff(Ht3[2],v)
assert sp.simplify(Qv3-6*p*q)==0

# Pure cubic cancellation: -8 theta pq + (1-theta)*6 alpha pq = 0
alpha=sp.simplify(8*theta/(6*(1-theta)))
assert sp.simplify(alpha-4*theta/(3*(1-theta)))==0

rho=sp.symbols("rho", positive=True)
theta_r=1/(1+rho)
alpha_r=sp.simplify(4*theta_r/(3*(1-theta_r)))
assert sp.simplify(alpha_r-4/(3*rho))==0
assert sp.solve(sp.Eq(alpha_r,1),rho)==[sp.Rational(4,3)]

# ------------------------------------------------------------
# Nonlinear flattening limit, tested numerically
# ------------------------------------------------------------
def rel_components(A0,B0,C0,a0,b0,v0):
    p0=a0+b0
    q0=a0-b0
    # g=t^3
    G1=(v0+b0)**3-(v0-a0)**3
    G3=(v0-b0)**3-(v0-a0)**3
    Qg=(v0-a0)**3-(v0+b0)**3+(v0+a0)**3-(v0-b0)**3
    Y1=A0*p0+B0*p0*(2*v0-q0)+C0*G1
    Y2=A0*q0+B0*q0*(2*v0-p0)+C0*G3
    Y3=2*B0*p0*q0+C0*Qg
    E=B0*B0/A0+C0
    Z=(Y3-2*B0*(Y1/A0)*(Y2/A0))/E
    th=(B0*B0/A0)/E
    R=-2*th*p0*q0*(4*v0-p0-q0)+(1-th)*Qg
    return Y1/A0,Y2/A0,Z,p0,q0,R,th

errs=[]
for A0 in [1e5,1e7,1e9]:
    B0=A0**0.7
    C0=0.8*(B0*B0/A0)
    X1,X2,Z,p0,q0,R,th=rel_components(A0,B0,C0,1.0,0.3,2.0)
    errs.append(abs(X1-p0)+abs(X2-q0)+abs(Z-R))
assert errs[-1] < errs[0]/10

# ------------------------------------------------------------
# Shifted-log Taylor coefficients
# ------------------------------------------------------------
# c_k = 2^(k-1)/k * B^(k-1)/A^(k-2)
def coeff(k,A0,B0):
    return (2**(k-1)/k)*(B0**(k-1))/(A0**(k-2))

A0=30.0
B0=2.0
assert abs(coeff(1,A0,B0)-A0)<1e-12
assert abs(coeff(2,A0,B0)-B0)<1e-12
assert abs(coeff(3,A0,B0)-4*B0*B0/(3*A0))<1e-12
assert abs(coeff(4,A0,B0)-2*B0**3/A0**2)<1e-12
assert abs(coeff(5,A0,B0)-16*B0**4/(5*A0**3))<1e-12

# Numerical Taylor audit of the exact shifted log.
eps=2*B0/A0
def exact_log(x):
    return -(A0/eps)*math.log(1-eps*x)
for x in [0.05,0.1,-0.08]:
    trunc=sum(coeff(k,A0,B0)*x**k for k in range(1,6))
    assert abs(exact_log(x)-trunc)<2e-7

# ------------------------------------------------------------
# Exact cubic/quartic determinant audit
# ------------------------------------------------------------
expr=A*t+B*t**2+C*t**3+D*t**4
J=H(expr).jacobian([a,b,v])
det=sp.factor(J.det())

# Test asymptotic:
# C = 4/3 B^2/A, D=d B^3/A^2,
# det / B^3 -> 48(d-2) v(a^2-b^2)
def det_eval(A0,B0,d0,a0,b0,v0):
    C0=4*B0*B0/(3*A0)
    D0=d0*B0**3/A0**2
    return float(det.subs({A:A0,B:B0,C:C0,D:D0,a:a0,b:b0,v:v0}))

for d0 in [0.5,1.0,3.0]:
    target=48*(d0-2)*2.0*(1.0**2-0.4**2)
    vals=[]
    for A0 in [1e5,1e7]:
        B0=A0**0.6
        vals.append(det_eval(A0,B0,d0,1.0,0.4,2.0)/(B0**3))
    assert abs(vals[-1]-target) < abs(vals[0]-target)+1e-8
    assert abs(vals[-1]-target) < 0.03*max(1,abs(target))

# At d=2 the B^3 coefficient cancels.
vals=[]
for A0 in [1e5,1e7,1e9]:
    B0=A0**0.6
    vals.append(abs(det_eval(A0,B0,2.0,1.0,0.4,2.0))/(B0**3))
assert vals[-1] < vals[0]/10

print("v151 exact GL(3,Z) phase coordinate audit: PASS")
print("v151 exact affine/quadratic/cubic transformed components: PASS")
print("v151 third-scale tuned-cubic coefficient classification: PASS")
print("v151 unique pure-cubic resonance rho=4/3: PASS")
print("v151 nonlinear quadratic-surface flattening convergence: PASS")
print("v151 shifted-log Taylor coefficients through degree 5: PASS")
print("v151 exact shifted-log Taylor numerical audit: PASS")
print("v151 quartic determinant asymptotic and d=2 resonance: PASS")
