import math
import sympy as sp

# ------------------------------------------------------------
# 1. Exact raw relative-phase Jacobian identity
# ------------------------------------------------------------
d0,d1,d2,d3 = sp.symbols('d0 d1 d2 d3', nonzero=True)
M = sp.Matrix([
    [d0,       d1,  d1-d0],
    [d2+d0,     0,  d2-d0],
    [d0,      -d3,  d3-d0],
])
detM = sp.factor(M.det())
expected = 2*d0*d1*d2*d3*(1/d3 - 1/d2 + 1/d1 - 1/d0)
assert sp.simplify(detM-expected) == 0

# ------------------------------------------------------------
# 2. Exact shifted-log phase-surface identity
# ------------------------------------------------------------
z0,z1,z2,z3 = sp.symbols('z0 z1 z2 z3', positive=True)
# h=-log z, so exp(-H_j)=z_j/z_0.
Rminus = 1 + z2/z0 - z1/z0 - z3/z0
assert sp.simplify(Rminus.subs(z2, z1+z3-z0)) == 0

# ------------------------------------------------------------
# 3. Shifted-log coefficient formula and reciprocal-slope jet
# ------------------------------------------------------------
t,A,B,d = sp.symbols('t A B d', nonzero=True)

def cstar(k):
    return sp.Rational(2)**(k-1)/k * B**(k-1)/A**(k-2)

def Sm(m):
    return B**(m-1)/A**(m-2)

for k in range(1,9):
    # Direct coefficient from -A^2/(2B) log(1-2Bt/A)
    expr = -(A**2/(2*B))*sp.log(1-2*B*t/A)
    ck = sp.expand(expr.series(t,0,k+1).removeO()).coeff(t,k)
    assert sp.simplify(ck-cstar(k)) == 0

# If degrees <m are log-tuned and c_m=d*S_m, the first nonlinear
# coefficient of 1/f' is exactly -m(c_m-c_m*)/A^2 at t^(m-1).
for m in range(3,9):
    f = sum(cstar(k)*t**k for k in range(1,m)) + d*Sm(m)*t**m
    invslope = sp.series(1/sp.diff(f,t), t, 0, m).removeO().expand()
    coeff = sp.simplify(invslope.coeff(t,m-1))
    target = sp.simplify(-m*(d*Sm(m)-cstar(m))/A**2)
    assert sp.simplify(coeff-target) == 0
    # All intermediate reciprocal-slope powers t^2,...,t^(m-2) vanish.
    for j in range(2,m-1):
        assert sp.simplify(invslope.coeff(t,j)) == 0

# ------------------------------------------------------------
# 4. General determinant asymptotic coefficient; quartic recovery
# ------------------------------------------------------------
a,b,v = sp.symbols('a b v', real=True)
u = [v-a, v+b, v+a, v-b]

def P(j):
    return sp.expand(u[1]**j + u[3]**j - u[0]**j - u[2]**j)

assert sp.simplify(P(2) + 2*(a-b)*(a+b)) == 0
assert sp.simplify(P(3) + 6*v*(a-b)*(a+b)) == 0

# m=4 gives +48(d-2) B^3 v(a^2-b^2).
m=4
quartic_lead = sp.factor(-2*m*A**2*(d*Sm(m)-cstar(m))*P(m-1))
quartic_expected = 48*(d-2)*B**3*v*(a**2-b**2)
assert sp.simplify(quartic_lead-quartic_expected) == 0

# ------------------------------------------------------------
# 5. Numerical moving-log flattening convergence
# ------------------------------------------------------------
def H_values(fun,a0,b0,v0):
    us=[v0-a0,v0+b0,v0+a0,v0-b0]
    vals=[fun(x) for x in us]
    return [vals[1]-vals[0],vals[2]-vals[0],vals[3]-vals[0]]

def flatten(A0,B0,S0,a0,b0,v0,gfun):
    lam=2*B0/A0
    L=A0/lam
    def ref(x):
        return -L*math.log1p(-lam*x)
    def full(x):
        return ref(x)+S0*gfun(x)
    y=H_values(full,a0,b0,v0)
    x=[yy/L for yy in y]
    R=1+math.exp(-x[1])-math.exp(-x[0])-math.exp(-x[2])
    return (y[0]/A0,y[2]/A0,(L/S0)*R)

def qraw(gfun,a0,b0,v0):
    us=[v0-a0,v0+b0,v0+a0,v0-b0]
    vals=[gfun(x) for x in us]
    return vals[0]-vals[1]+vals[2]-vals[3]

errs=[]
for A0 in [1e4,1e6,1e8]:
    B0=A0**0.8
    S0=B0**3/A0**2
    a0,b0,v0=1.0,0.35,1.7
    gfun=lambda x: x**4 + 0.3*x**3
    X1,X3,Z=flatten(A0,B0,S0,a0,b0,v0,gfun)
    p0=a0+b0
    q0=a0-b0
    target=(p0,q0,-qraw(gfun,a0,b0,v0))
    errs.append(abs(X1-target[0])+abs(X3-target[1])+abs(Z-target[2]))
assert errs[-1] < errs[0]/7

# ------------------------------------------------------------
# 6. Quartic block-rigidity numerical test
# ------------------------------------------------------------
# Residual at S4: gamma*t^3 + (d-2)*t^4 after subtracting exact log.
def quartic_residual_limit(gamma,d0,a0,b0,v0):
    gfun=lambda x: gamma*x**3+(d0-2)*x**4
    return -qraw(gfun,a0,b0,v0)

assert abs(quartic_residual_limit(0.0,2.0,1.0,0.4,2.0)) < 1e-15
assert abs(quartic_residual_limit(0.2,2.0,1.0,0.4,2.0)) > 1e-6
assert abs(quartic_residual_limit(0.0,2.3,1.0,0.4,2.0)) > 1e-6


# ------------------------------------------------------------
# 7. Exact shifted-log renormalization law under a nested zoom
# ------------------------------------------------------------
delta,t0,s = sp.symbols('delta t0 s', positive=True)
lam = 2*B/A
A1 = sp.simplify(delta*A/(1-lam*t0))
B1 = sp.simplify(delta**2*B/(1-lam*t0)**2)
lam1 = sp.simplify(2*B1/A1)
M0 = sp.simplify(A**2/(2*B))
M1 = sp.simplify(A1**2/(2*B1))
assert sp.simplify(M1-M0) == 0
assert sp.simplify(lam1 - delta*lam/(1-lam*t0)) == 0
# Equality of derivatives of L(t0+delta*s)-L(t0) and the re-fitted log.
deriv_old_zoom = sp.simplify(delta*A/(1-lam*(t0+delta*s)))
deriv_refit = sp.simplify(A1/(1-lam1*s))
assert sp.simplify(deriv_old_zoom-deriv_refit) == 0
# Reciprocal-slope linear coefficient beta=-2B/A^2 is invariant.
beta0 = sp.simplify(-2*B/A**2)
beta1 = sp.simplify(-2*B1/A1**2)
assert sp.simplify(beta1-beta0) == 0

print('v152 exact reciprocal-slope Jacobian identity: PASS')
print('v152 exact moving shifted-log phase-surface identity: PASS')
print('v152 shifted-log coefficients through degree 8: PASS')
print('v152 all-order reciprocal-slope jet cancellation m=3..8: PASS')
print('v152 general determinant coefficient and quartic d=2 recovery: PASS')
print('v152 moving-log nonlinear flattening convergence: PASS')
print('v152 quartic block-rigidity residual test: PASS')
print('v152 exact nested-window shifted-log renormalization law: PASS')
