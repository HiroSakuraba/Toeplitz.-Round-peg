import math
import random
import sympy as sp

# ------------------------------------------------------------
# 1. Reciprocal-slope parameterization of shifted logarithms
# ------------------------------------------------------------
t, alpha, beta, t0, delta, s = sp.symbols('t alpha beta t0 delta s', nonzero=True)
L = sp.log((alpha + beta*t)/alpha)/beta
assert sp.simplify(sp.diff(L, t) - 1/(alpha + beta*t)) == 0

# ------------------------------------------------------------
# 2. Exact nested-window law in reciprocal-slope coordinates
# ------------------------------------------------------------
# L~(s)=L(t0+delta*s)-L(t0). Its reciprocal derivative is affine
# with invariant slope beta.
r_zoom = sp.simplify(1 / sp.diff(L.subs(t, t0 + delta*s) - L.subs(t, t0), s))
expected_zoom = sp.simplify((alpha + beta*t0)/delta + beta*s)
assert sp.simplify(r_zoom - expected_zoom) == 0

# ------------------------------------------------------------
# 3. Difference of two shifted logs: derivative numerator is affine
# ------------------------------------------------------------
a1,b1,a2,b2 = sp.symbols('a1 b1 a2 b2', nonzero=True)
r1 = a1 + b1*t
r2 = a2 + b2*t
hprime = sp.simplify(1/r1 - 1/r2)
expected_hprime = sp.simplify((r2-r1)/(r1*r2))
assert sp.simplify(hprime-expected_hprime) == 0
num, den = sp.fraction(sp.factor(hprime))
assert sp.Poly(num, t).degree() <= 1

# ------------------------------------------------------------
# 4. Stable coherence lemma, randomized audit
# ------------------------------------------------------------
def log_model(a,b,x):
    # value normalized to L(0)=0; stable near b=0
    if abs(b) < 1e-14 * max(1.0, abs(a)):
        return x/a
    y = b*x/a
    return math.log1p(y)/b

def optimal_sup_difference(a1,b1,a2,b2,R):
    # h=L1-L2. h' vanishes only where (r2-r1)=0, so extrema are
    # endpoints plus at most one interior critical point.
    pts=[-R,R]
    db=b2-b1
    da=a2-a1
    if abs(db)>1e-30:
        x=-da/db
        if -R < x < R:
            pts.append(x)
    vals=[log_model(a1,b1,x)-log_model(a2,b2,x) for x in pts]
    # Best additive constant is midrange; epsilon is half oscillation.
    return 0.5*(max(vals)-min(vals))

random.seed(153)
for _ in range(3000):
    R = 10**random.uniform(-0.5,0.5)
    # alpha positive; choose |beta|R <= theta alpha, theta<0.45
    a_1 = 10**random.uniform(-6,1)
    a_2 = 10**random.uniform(-6,1)
    th1 = random.uniform(-0.44,0.44)
    th2 = random.uniform(-0.44,0.44)
    b_1 = th1*a_1/R
    b_2 = th2*a_2/R
    eps = optimal_sup_difference(a_1,b_1,a_2,b_2,R)

    r1max=max(abs(a_1-b_1*R),abs(a_1+b_1*R))
    r2max=max(abs(a_2-b_2*R),abs(a_2+b_2*R))

    beta_bound = 8*eps*r1max*r2max/(R*R) + 1e-24
    alpha_bound = 12*eps*r1max*r2max/R + 1e-24
    sup_bound = 20*eps*r1max*r2max/R + 1e-24

    assert abs(b_2-b_1) <= beta_bound*(1+1e-9) + 1e-18
    assert abs(a_2-a_1) <= alpha_bound*(1+1e-9) + 1e-18
    # affine reciprocal-line difference reaches its max at endpoints
    dmax=max(abs((a_2-a_1)+(b_2-b_1)*(-R)),
             abs((a_2-a_1)+(b_2-b_1)*R))
    assert dmax <= sup_bound*(1+1e-9) + 1e-18

# ------------------------------------------------------------
# 5. Near-affine corollary in A=1/alpha coordinates
# ------------------------------------------------------------
for _ in range(1000):
    R = 1.0
    theta = 0.4
    A1 = 10**random.uniform(2,8)
    A2 = 10**random.uniform(2,8)
    aa1=1/A1
    aa2=1/A2
    bb1=random.uniform(-theta,theta)*aa1/R
    bb2=random.uniform(-theta,theta)*aa2/R
    eps=optimal_sup_difference(aa1,bb1,aa2,bb2,R)
    C=(1+theta)**2
    assert abs(A1-A2) <= 12*C*eps/R*(1+1e-8) + 1e-8
    assert A1*A2*abs(bb1-bb2) <= 8*C*eps/(R*R)*(1+1e-8) + 1e-8

# ------------------------------------------------------------
# 6. Parent/child coordinate transport: beta is exactly invariant
# ------------------------------------------------------------
ap,bp,ac,bc = sp.symbols('ap bp ac bc', nonzero=True)
r_parent_child_coords = sp.simplify((ap + bp*(t0+delta*s))/delta)
assert sp.simplify(sp.diff(r_parent_child_coords,s)-bp) == 0
assert sp.simplify(r_parent_child_coords.subs(s,0)-(ap+bp*t0)/delta) == 0

# ------------------------------------------------------------
# 7. Ill-conditioning of raw pole b=-alpha/beta vs stable beta
# ------------------------------------------------------------
# A tiny beta change can move the pole macroscopically while changing phase
# by very little on a fixed interval.
a=1e-6
be1=-1e-12
be2=-1.001e-12
pole1=-a/be1
pole2=-a/be2
eps=optimal_sup_difference(a,be1,a,be2,1.0)
assert abs(pole2-pole1) > 900
assert eps < 1e-3

print('v153 reciprocal-slope shifted-log parameterization: PASS')
print('v153 exact nested-window beta invariance: PASS')
print('v153 affine numerator identity for log differences: PASS')
print('v153 stable reciprocal-line coherence randomized audit: PASS')
print('v153 near-affine A/beta coherence corollary: PASS')
print('v153 parent-child coordinate transport identity: PASS')
print('v153 raw-pole ill-conditioning example: PASS')
