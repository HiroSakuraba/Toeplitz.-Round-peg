#!/usr/bin/env python3
import math
import numpy as np
import sympy as sp

print('v154 verifier')

# 1. Q_g exact formulas for quadratic/cubic.
t,v,a,b=sp.symbols('t v a b', real=True)
c0,c1,c2,c3=sp.symbols('c0 c1 c2 c3', real=True)

def Q(expr):
    return sp.expand(expr.subs(t,v-a)-expr.subs(t,v+b)+expr.subs(t,v+a)-expr.subs(t,v-b))

q2=c0+c1*t+c2*t**2
q3=q2+c3*t**3
Q2=sp.factor(Q(q2))
Q3=sp.factor(Q(q3))
assert sp.simplify(Q2-2*c2*(a*a-b*b))==0
assert sp.simplify(Q3-2*(a*a-b*b)*(c2+3*c3*v))==0
print('[1] Q_g polynomial formulas: PASS')

# 2. Exact derivative remainder identity.
A,B,da,db=sp.symbols('A B da db', nonzero=True, real=True)
D=A/(1-2*B*t/A)
Dp=(A+da)/(1-2*(B+db)*t/(A+da))
rem=sp.factor(sp.simplify(Dp-D-da-2*db*t))
claimed=4*t**2*(2*A*B*db + A*db**2 - B**2*da - 2*B**2*db*t - 2*B*db**2*t)/((A-2*B*t)*(A+da-2*(B+db)*t))
assert sp.simplify(rem-claimed)==0
print('[2] exact quadratic-absorption derivative identity: PASS')

# 3. Numerical absorption asymptotics.
def L(A,B,t):
    if abs(B) < 1e-30:
        return A*t
    return -(A*A/(2*B))*np.log(1-(2*B/A)*t)

ratios=[]
for k in [3,4,5,6,7]:
    A0=10.0**k
    B0=A0**0.62
    S=A0**0.37
    daa=0.63*S
    dbb=-0.41*S
    xs=np.linspace(-0.7,0.7,2001)
    diff=L(A0+daa,B0+dbb,xs)-L(A0,B0,xs)-(daa*xs+dbb*xs*xs)
    ratios.append(float(np.max(np.abs(diff))/S))
assert ratios[-1] < ratios[0]
assert ratios[-1] < 5e-3
print('[3] numerical quadratic absorption: PASS', ratios)

# 4. Affine covariance of P2 exactly.
s,t0,delta=sp.symbols('s t0 delta', real=True)
poly=c0+c1*t+c2*t**2
comp=sp.expand(poly.subs(t,t0+delta*s))
assert sp.Poly(comp,s).degree() <= 2
print('[4] affine covariance of quadratic gauge: PASS')

# 5. Three-anchor quadratic interpolation Lebesgue constant.
xx=sp.symbols('xx', real=True)
lm=xx*(xx-1)/2
l0=1-xx**2
lp=xx*(xx+1)/2
# On [0,1], lm<=0 and l0,lp>=0, so the Lebesgue function is 1+x-x^2.
leb=sp.expand(-lm+l0+lp)
assert sp.simplify(leb-(1+xx-xx**2))==0
assert sp.simplify(leb.subs(xx,sp.Rational(1,2))-sp.Rational(5,4))==0
print('[5] three-anchor Lebesgue constant 5/4: PASS')

# 6. Strip-degree sign crossing example for g=t^3.
# Q = 6 v (a^2-b^2). choose a=1,b=1/2, v=-1,+1.
coef=6*(1.0-0.25)
qm=coef*(-1.0)
qp=coef*(1.0)
assert qm < 0 < qp
print('[6] continuous strip sign-crossing example: PASS', qm, qp)

# 7. Concentration toy: shrinking continuous tent packet, sup norm 1.
def tent(x,center,width):
    z=np.abs((x-center)/width)
    return np.maximum(1-z,0.0)

for n in [20,40,80,160]:
    width=1.0/n
    x1=0.5
    x2=0.5+0.5*width
    jump=abs(tent(np.array([x1]),0.5,width)[0]-tent(np.array([x2]),0.5,width)[0])
    assert jump >= 0.49
    assert abs(x2-x1) <= 1.0/n
print('[7] shrinking fixed-amplitude concentration toy: PASS')

# 8. Fixed-depth retained mass still diverges.
etas=[0.3,0.2,0.4,0.15]
prod=math.prod(etas)
vals=[prod*(10.0**k) for k in [2,3,4,5]]
assert vals[-1] > vals[0]
assert vals[-1] > 1e2
print('[8] fixed-depth diverging mass retention: PASS', vals)

print('ALL 8 CHECKS PASS')
