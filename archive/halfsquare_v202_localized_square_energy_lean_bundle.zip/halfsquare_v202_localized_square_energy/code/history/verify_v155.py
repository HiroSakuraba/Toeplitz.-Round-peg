#!/usr/bin/env python3
import math
import random
import numpy as np

# ------------------------------------------------------------
# 1. Exact identity Delta^3 = Q(v+step)-Q(v)
# ------------------------------------------------------------
def Q(f, a, b, v):
    return f(v-a) - f(v+b) + f(v+a) - f(v-b)

def d3(f, x, s):
    return -f(x) + 3*f(x+s) - 3*f(x+2*s) + f(x+3*s)

for coeffs in [
    [1.2, -0.7, 0.3, 2.1, -0.4],
    [0.0, 2.0, -1.0, 0.5],
    [3.0, -4.0, 1.0, 0.2, -0.1, 0.03],
]:
    def f(x, c=coeffs):
        return sum(a*x**k for k, a in enumerate(c))
    for x in np.linspace(-0.5, 0.2, 5):
        for s in [0.03, 0.08, 0.15]:
            lhs = d3(f, x, s)
            rhs = Q(f, s, 0.0, x+2*s) - Q(f, s, 0.0, x+s)
            assert abs(lhs-rhs) < 1e-10
print("1. third-difference/Q identity: PASS")

# ------------------------------------------------------------
# 2. Quadratics are annihilated exactly
# ------------------------------------------------------------
for _ in range(100):
    c0, c1, c2 = [random.uniform(-5,5) for _ in range(3)]
    f = lambda x, c0=c0,c1=c1,c2=c2: c0+c1*x+c2*x*x
    x = random.uniform(-1, 0.5)
    s = random.uniform(1e-4, 0.15)
    assert abs(d3(f,x,s)) < 1e-10
print("2. quadratic annihilation: PASS")

# ------------------------------------------------------------
# 3. Critical zoom of exact shifted log tends to unit affine slope
# ------------------------------------------------------------
def L(A,B,t):
    if abs(B) < 1e-15:
        return A*t
    return -(A*A/(2*B))*math.log(1-(2*B/A)*t)

seq = [
    (1e4, 20.0, 30.0),
    (1e5, 50.0, 100.0),
    (1e6, 200.0, 1000.0),
    (1e7, 500.0, 5000.0),
]
errs = []
for A,B,S in seq:
    assert S/A < 0.01
    rho=S/A
    t0=0.21
    es=[]
    for s in np.linspace(-2,2,41):
        val=(L(A,B,t0+rho*s)-L(A,B,t0))/S
        es.append(abs(val-s))
    errs.append(max(es))
assert errs[-1] < errs[0]
assert errs[-1] < 5e-4
print("3. exact shifted-log critical zoom: PASS", errs)

# ------------------------------------------------------------
# 4. Parent log variation is S at rho=S/A
# ------------------------------------------------------------
for A,B,S in seq:
    rho=S/A
    t0=-0.17
    inc=L(A,B,t0+rho)-L(A,B,t0)
    assert abs(inc/S - 1.0) < 0.02
print("4. critical phase-balance scaling: PASS")

# ------------------------------------------------------------
# 5. Q stability under small coordinate perturbations
#    Bound by four times the first modulus at the maximum sample shift.
# ------------------------------------------------------------
def pwlin(xs, ys):
    def f(x):
        return float(np.interp(x, xs, ys))
    return f

def omega_grid(f, r, lo=-2.0, hi=2.0, N=3001):
    xs=np.linspace(lo,hi,N)
    ys=np.array([f(x) for x in xs])
    # crude but conservative enlarged-radius numerical estimate
    step=(hi-lo)/(N-1)
    m=max(1,int(math.ceil(r/step))+2)
    best=0.0
    for k in range(1,m+1):
        if k < len(ys):
            best=max(best,float(np.max(np.abs(ys[k:]-ys[:-k]))))
    return best

random.seed(4)
for _ in range(50):
    xs=np.linspace(-2,2,101)
    ys=np.cumsum(np.random.default_rng(_).normal(0,0.08,len(xs)))
    ys=np.clip(ys,-1,1)
    f=pwlin(xs,ys)
    a=random.uniform(0.2,0.5)
    b=random.uniform(-0.15,0.15)
    v=random.uniform(-0.7,0.7)
    da=random.uniform(-0.005,0.005)
    db=random.uniform(-0.005,0.005)
    # each Q sample argument moves by at most |da|+|db|
    rr=abs(da)+abs(db)+1e-6
    lhs=abs(Q(f,a+da,b+db,v)-Q(f,a,b,v))
    om=omega_grid(f,rr)
    assert lhs <= 4.05*om + 1e-8
print("5. Q/modulus stability: PASS")

# ------------------------------------------------------------
# 6. Concentrated packets: roughness at K*S/A stays O(1)
# ------------------------------------------------------------
def tent(x,w):
    return max(0.0, 1.0-abs(x)/w)

K=2.0
vals=[]
for A,S in [(1e4,100),(1e5,300),(1e6,1000)]:
    eps=S/A
    w=0.5*eps
    f=lambda x,w=w: tent(x,w)
    # points 0 and w already differ by 1 and are within K eps
    rough=abs(f(0)-f(w))
    vals.append(rough)
assert min(vals) > 0.99
print("6. concentrated critical roughness: PASS", vals)

# ------------------------------------------------------------
# 7. Smooth profiles have critical roughness -> 0
# ------------------------------------------------------------
vals=[]
for A,S in [(1e4,100),(1e5,300),(1e6,1000),(1e7,3000)]:
    eps=S/A
    # Lipschitz constant <= 3 on [-1,1]
    rough_bound=3*K*eps
    vals.append(rough_bound)
assert vals[-1] < vals[0]
assert vals[-1] < 0.002
print("7. smooth critical roughness decay: PASS", vals)

print("v155 verifier: ALL CHECKS PASS")
