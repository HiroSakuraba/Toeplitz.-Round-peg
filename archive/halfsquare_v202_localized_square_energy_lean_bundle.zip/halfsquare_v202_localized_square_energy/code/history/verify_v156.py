#!/usr/bin/env python3
import math
import random
import numpy as np

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------
def bisect_inverse(f, x, lo=-5.0, hi=5.0, iters=120):
    flo=f(lo)-x
    fhi=f(hi)-x
    if flo > 0 or fhi < 0:
        raise ValueError("inverse bracket failed")
    for _ in range(iters):
        mid=(lo+hi)/2
        if f(mid) < x:
            lo=mid
        else:
            hi=mid
    return (lo+hi)/2

def H(f, a, b, v):
    u0=v-a; u1=v+b; u2=v+a; u3=v-b
    return np.array([
        f(u1)-f(u0),
        f(u2)-f(u0),
        f(u3)-f(u0),
    ], dtype=float)

def root_from_fg(f, g, x, y1, y2):
    u0=g(x)
    u1=g(x+y1)
    u2=g(x+y2)
    u3=u0+u2-u1
    return f(u3)-x

def phase_chart(f, g, x, y1, y2):
    u0=g(x)
    u1=g(x+y1)
    u2=g(x+y2)
    u3=u0+u2-u1
    v=(u0+u2)/2
    a=(u2-u0)/2
    b=(u1-u3)/2
    return a,b,v,u0,u1,u2,u3

def R_beta(beta, y1, y2):
    if abs(beta) < 1e-7:
        # stable two-term expansion at affine limit
        d=y2-y1
        return d + beta*y1*d
    # direct formula is safe on ranges used below
    return math.log(1.0 + math.exp(beta*y2)-math.exp(beta*y1))/beta

# ------------------------------------------------------------
# 1. Exact triangularization for nonlinear monotone profile
# ------------------------------------------------------------
def f_cub(t):
    return t + 0.25*t**3

def g_cub(x):
    return bisect_inverse(f_cub,x,-4,4)

rng=random.Random(156)
for _ in range(100):
    x=rng.uniform(-0.5,0.5)
    y1=rng.uniform(0.08,0.25)
    y2=y1+rng.uniform(0.2,0.55)
    a,b,v,*us=phase_chart(f_cub,g_cub,x,y1,y2)
    hv=H(f_cub,a,b,v)
    R=root_from_fg(f_cub,g_cub,x,y1,y2)
    assert np.max(np.abs(hv-np.array([y1,y2,R]))) < 3e-12
    assert a > 0 and abs(b) < a
print("1. exact phase-root triangularization: PASS")

# ------------------------------------------------------------
# 2. Affine root is base-phase independent and equals y2-y1
# ------------------------------------------------------------
f_aff=lambda t: 2.3*t-0.7
g_aff=lambda x: (x+0.7)/2.3
for y1,y2 in [(0.2,0.7),(0.15,0.9),(0.5,1.3)]:
    vals=[root_from_fg(f_aff,g_aff,x,y1,y2) for x in np.linspace(-1,1,9)]
    assert max(vals)-min(vals) < 2e-12
    assert max(abs(v-(y2-y1)) for v in vals) < 2e-12
print("2. affine root law: PASS")

# ------------------------------------------------------------
# 3. Shifted-log root is independent of x and matches Sigma_beta
# ------------------------------------------------------------
a_log=1.7
beta_true=1/a_log
b_pole=-3.0
c_off=0.4
f_log=lambda t: a_log*math.log(t-b_pole)+c_off
g_log=lambda x: b_pole+math.exp((x-c_off)/a_log)
for y1,y2 in [(0.2,0.7),(0.35,1.0),(0.1,0.55)]:
    expected=R_beta(beta_true,y1,y2)
    vals=[root_from_fg(f_log,g_log,x,y1,y2) for x in np.linspace(-0.5,1.0,11)]
    assert max(vals)-min(vals) < 5e-12
    assert max(abs(v-expected) for v in vals) < 5e-12
    # exact exceptional-surface relation
    r=vals[0]
    defect=math.exp(beta_true*y1)+math.exp(beta_true*r)-1-math.exp(beta_true*y2)
    assert abs(defect) < 5e-12
print("3. shifted-log one-parameter phase surface: PASS")

# ------------------------------------------------------------
# 4. Nonexceptional monotone cubic has visible base-phase root drift
# ------------------------------------------------------------
y1,y2=0.2,0.7
xs=np.linspace(-0.6,0.9,31)
roots=[root_from_fg(f_cub,g_cub,x,y1,y2) for x in xs]
drift=max(roots)-min(roots)
assert drift > 0.06
print("4. nonexceptional cubic root drift: PASS", drift)

# ------------------------------------------------------------
# 5. Robust Poincare-Miranda face margins under oscillatory C0 perturbation
#    Use the LIMIT chart Theta_f, so perturbing profile need not be monotone.
# ------------------------------------------------------------
xm=-0.5; xp=0.5; y1c=0.2; y2c=0.7
Rm=root_from_fg(f_cub,g_cub,xm,y1c,y2c)
Rp=root_from_fg(f_cub,g_cub,xp,y1c,y2c)
assert Rm > Rp
# orient x faces so lower root first
xlo,xhi=xp,xm
Rlo,Rhi=Rp,Rm
half_y1=0.01
half_y2=0.01
eps=0.003
f_pert=lambda t: f_cub(t)+eps*math.sin(37*t)

# Choose a third target lying uniformly between the two x-face root values
# across the whole y1/y2 rectangle, as in the proof.
low_face=[]
high_face=[]
for yy1 in np.linspace(y1c-half_y1,y1c+half_y1,9):
    for yy2 in np.linspace(y2c-half_y2,y2c+half_y2,9):
        low_face.append(root_from_fg(f_cub,g_cub,xlo,yy1,yy2))
        high_face.append(root_from_fg(f_cub,g_cub,xhi,yy1,yy2))
max_low=max(low_face)
min_high=min(high_face)
assert min_high > max_low
yt3=(max_low+min_high)/2

# first/second face signs using fixed limit chart
# error in each H component is <= 2 eps
assert half_y1 > 2*eps
assert half_y2 > 2*eps
assert (Rhi-Rlo)/2 > 2*eps

for yy2 in [y2c-half_y2,y2c,y2c+half_y2]:
    for xx in [xlo,xhi]:
        # y1 low/high faces
        for yy1,sgn in [(y1c-half_y1,-1),(y1c+half_y1,+1)]:
            a,b,v,*_=phase_chart(f_cub,g_cub,xx,yy1,yy2)
            val=H(f_pert,a,b,v)[0]-y1c
            assert val*sgn > 0
for yy1 in [y1c-half_y1,y1c,y1c+half_y1]:
    for xx in [xlo,xhi]:
        for yy2,sgn in [(y2c-half_y2,-1),(y2c+half_y2,+1)]:
            a,b,v,*_=phase_chart(f_cub,g_cub,xx,yy1,yy2)
            val=H(f_pert,a,b,v)[1]-y2c
            assert val*sgn > 0
# third coordinate signs at x faces near center in y1,y2
for yy1 in np.linspace(y1c-half_y1,y1c+half_y1,5):
    for yy2 in np.linspace(y2c-half_y2,y2c+half_y2,5):
        a,b,v,*_=phase_chart(f_cub,g_cub,xlo,yy1,yy2)
        vlo=H(f_pert,a,b,v)[2]-yt3
        a,b,v,*_=phase_chart(f_cub,g_cub,xhi,yy1,yy2)
        vhi=H(f_pert,a,b,v)[2]-yt3
        assert vlo < 0 and vhi > 0
print("5. robust phase-cell face signs under oscillatory perturbation: PASS")

# ------------------------------------------------------------
# 6. R_beta is strictly increasing over wide beta range
# ------------------------------------------------------------
for y1,y2 in [(0.2,0.7),(0.4,1.1),(0.1,1.5),(0.8,1.0)]:
    betas=np.linspace(-8,8,801)
    vals=[R_beta(float(b),y1,y2) for b in betas]
    # numerical formula near beta=0 uses series; allow tiny tolerance
    assert all(vals[i+1] > vals[i]-2e-8 for i in range(len(vals)-1))
    assert vals[-1] > vals[0]
print("6. exceptional root monotonicity in beta: PASS")

# ------------------------------------------------------------
# 7. Affine-limit derivative dR/dbeta = y1*(y2-y1)
# ------------------------------------------------------------
for y1,y2 in [(0.2,0.7),(0.4,1.1),(0.1,1.5)]:
    h=1e-5
    num=(R_beta(h,y1,y2)-R_beta(-h,y1,y2))/(2*h)
    exact=y1*(y2-y1)
    assert abs(num-exact) < 2e-5
print("7. affine-limit beta sensitivity: PASS")

# ------------------------------------------------------------
# 8. Recover beta from one root measurement by scalar inversion
# ------------------------------------------------------------
def invert_beta(root,y1,y2,lo=-20,hi=20):
    for _ in range(100):
        mid=(lo+hi)/2
        if R_beta(mid,y1,y2) < root:
            lo=mid
        else:
            hi=mid
    return (lo+hi)/2

for beta in [-3,-1,-0.2,0.0,0.15,0.8,2.5]:
    y1,y2=0.25,0.85
    root=R_beta(beta,y1,y2)
    bhat=invert_beta(root,y1,y2)
    assert abs(bhat-beta) < 2e-5
print("8. beta recovery from one root: PASS")

# ------------------------------------------------------------
# 9. v153/v152 beta equals reciprocal-slope coefficient of exact log
# ------------------------------------------------------------
def Lprime(A,B,t):
    return A/(1-(2*B/A)*t)
for A,B in [(100,3),(500,-4),(1000,25)]:
    beta=-2*B/(A*A)
    ts=np.array([-0.5,0.0,0.4])
    rs=np.array([1/Lprime(A,B,t) for t in ts])
    # fit r=alpha+beta*t from endpoints
    bhat=(rs[-1]-rs[0])/(ts[-1]-ts[0])
    assert abs(bhat-beta) < 1e-14
print("9. reciprocal-slope beta identity: PASS")

# ------------------------------------------------------------
# 10. High-phase lattice mesh enters a fixed root-drift phase cell
# ------------------------------------------------------------
center=np.array([y1c,y2c,yt3])
half=np.array([0.02,0.02,0.01])
for S in [2e3,1e4,5e4]:
    mesh=2*math.pi/S
    m=np.round(center/mesh)
    lattice=m*mesh
    assert np.all(np.abs(lattice-center) <= mesh/2 + 1e-15)
    if S >= 1e4:
        assert np.all(np.abs(lattice-center) < half)
print("10. normalized lattice enters fixed phase cell: PASS")

print("v156 verifier: ALL CHECKS PASS")
