import math
import numpy as np
from scipy.optimize import root
from scipy.integrate import quad


def contact_map(f, u0, u1, u2):
    u3 = u0 + u2 - u1
    return np.array([
        f(u1) - f(u0),
        f(u2) - f(u0),
        f(u3) - f(u0),
    ], dtype=float)


def plateau_f(t):
    # Continuous nondecreasing profile with plateau [0,1].
    if t <= 0.0:
        return t
    if t <= 1.0:
        return 0.0
    return t - 1.0


def nonmono_f(t):
    return t + 2.0 * math.sin(3.0 * t)


def bisect(fun, lo, hi, n=100):
    flo = fun(lo)
    fhi = fun(hi)
    assert flo * fhi <= 0
    for _ in range(n):
        mid = 0.5 * (lo + hi)
        fm = fun(mid)
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return 0.5 * (lo + hi)


def check_contact_coordinates():
    rng = np.random.default_rng(123)
    for _ in range(200):
        u0 = rng.uniform(-4.0, -1.0)
        u2 = rng.uniform(1.0, 4.0)
        u1 = rng.uniform(u0 + 1e-3, u2 - 1e-3)
        v = 0.5 * (u0 + u2)
        A = 0.5 * (u2 - u0)
        B = u1 - v
        u3 = v - B
        assert A > 0 and abs(B) < A
        assert abs(u3 - (u0 + u2 - u1)) < 1e-12
        assert u0 < u3 < u2
    return True


def plateau_box_data():
    a, b, z = 0.0, 1.0, 0.0
    r_minus, r_plus = -0.15, -0.05
    s_minus, s_plus = 1.40, 1.60
    d0 = plateau_f(r_plus) - plateau_f(r_minus)
    d2 = plateau_f(s_plus) - plateau_f(s_minus)
    sig_minus = r_minus + s_minus - a - b
    sig_plus = r_plus + s_plus - a - b
    gamma = plateau_f(b + sig_minus) - z
    tau1 = z - 0.5 * (plateau_f(r_minus) + plateau_f(r_plus))
    lower2 = plateau_f(s_minus) - plateau_f(r_minus)
    upper2 = plateau_f(s_plus) - plateau_f(r_plus)
    tau2 = 0.5 * (lower2 + upper2)
    lower3 = z - plateau_f(r_minus)
    upper3 = z + gamma - plateau_f(r_plus)
    tau3 = 0.5 * (lower3 + upper3)
    margins = np.array([d0 / 2.0, (d2 - d0) / 2.0, (gamma - d0) / 2.0])
    return {
        "a": a, "b": b, "z": z,
        "r_minus": r_minus, "r_plus": r_plus,
        "s_minus": s_minus, "s_plus": s_plus,
        "d0": d0, "d2": d2,
        "sig_minus": sig_minus, "sig_plus": sig_plus,
        "gamma": gamma,
        "tau": np.array([tau1, tau2, tau3]),
        "margins": margins,
    }


def check_plateau_faces():
    D = plateau_box_data()
    assert D["d0"] > 0
    assert D["d2"] > D["d0"]
    assert 0 < D["sig_minus"] <= D["sig_plus"] < 1.0
    assert D["gamma"] > D["d0"]
    assert np.all(D["margins"] > 0)

    tau = D["tau"]
    grid = np.linspace(0, 1, 101)

    # E1 on u0 faces, varying u1 and u2.
    for u1 in np.linspace(D["a"], D["b"], 21):
        for u2 in np.linspace(D["s_minus"], D["s_plus"], 11):
            e_lo = contact_map(plateau_f, D["r_minus"], u1, u2)[0] - tau[0]
            e_hi = contact_map(plateau_f, D["r_plus"], u1, u2)[0] - tau[0]
            assert e_lo > 0 and e_hi < 0

    # E2 on u2 faces, varying u0,u1.
    for u0 in np.linspace(D["r_minus"], D["r_plus"], 21):
        for u1 in np.linspace(D["a"], D["b"], 11):
            e_lo = contact_map(plateau_f, u0, u1, D["s_minus"])[1] - tau[1]
            e_hi = contact_map(plateau_f, u0, u1, D["s_plus"])[1] - tau[1]
            assert e_lo < 0 and e_hi > 0

    # E3 on u1=b and u1=a faces, varying u0,u2.
    for u0 in np.linspace(D["r_minus"], D["r_plus"], 31):
        for u2 in np.linspace(D["s_minus"], D["s_plus"], 31):
            e_b = contact_map(plateau_f, u0, D["b"], u2)[2] - tau[2]
            e_a = contact_map(plateau_f, u0, D["a"], u2)[2] - tau[2]
            assert e_b < 0 and e_a > 0
    return True


def check_random_targets_attained():
    D = plateau_box_data()
    rng = np.random.default_rng(321)
    tau0 = D["tau"]
    radii = 0.3 * D["margins"]

    successes = 0
    for _ in range(100):
        y1, y2, y3 = tau0 + rng.uniform(-1.0, 1.0, 3) * radii

        # In this explicit plateau box, every target in the tested protected
        # subcell lands on the u3>1 branch, where the solution is elementary.
        u0 = -y1
        u2 = 1.0 + u0 + y2
        u1 = u0 + y2 - y3
        u3 = u0 + u2 - u1

        inside = (
            D["r_minus"] < u0 < D["r_plus"]
            and D["a"] < u1 < D["b"]
            and D["s_minus"] < u2 < D["s_plus"]
            and u3 > 1.0
        )
        if inside:
            err = np.linalg.norm(contact_map(plateau_f, u0, u1, u2) - np.array([y1,y2,y3]), ord=np.inf)
            if err < 1e-12:
                successes += 1
    assert successes == 100, successes
    return successes


def find_return_arch():
    # Find positive b with f(b)=f(0)=0 for f=t+2 sin(3t).
    a = 0.0
    fun = lambda t: nonmono_f(t) - nonmono_f(a)
    # There is a sign change between 1.1 and 1.6 for this profile.
    b = bisect(fun, 1.1, 1.6)
    return a, b


def check_return_arch_identity():
    a, b = find_return_arch()
    d = b - a
    assert abs(nonmono_f(a) - nonmono_f(b)) < 1e-10
    assert d <= 4.0 + 1e-12

    rng = np.random.default_rng(456)
    for _ in range(100):
        u0 = rng.uniform(-5.0, -2.0)
        u2 = rng.uniform(3.0, 6.0)
        Ha = contact_map(nonmono_f, u0, a, u2)
        Hb = contact_map(nonmono_f, u0, b, u2)
        assert abs(Ha[0] - Hb[0]) < 1e-10
        assert abs(Ha[1] - Hb[1]) < 1e-12
        x = u0 + u2 - b
        delta = nonmono_f(x + d) - nonmono_f(x)
        assert abs((Ha[2] - Hb[2]) - delta) < 1e-10
    return d


def check_averaging_identity():
    a, b = find_return_arch()
    d = b - a
    C = 2.0
    h = lambda t: 2.0 * math.sin(3.0 * t)
    Delta = lambda t: nonmono_f(t + d) - nonmono_f(t)

    rng = np.random.default_rng(789)
    for L in [5.0, 7.5, 10.0, 20.0]:
        for X in rng.uniform(-20.0, 20.0, 10):
            lhs = quad(Delta, X, X + L, epsabs=1e-10, epsrel=1e-10)[0] / L
            boundary = (
                quad(h, X + L, X + L + d, epsabs=1e-10, epsrel=1e-10)[0]
                - quad(h, X, X + d, epsabs=1e-10, epsrel=1e-10)[0]
            ) / L
            rhs = d + boundary
            assert abs(lhs - rhs) < 1e-9
            assert abs(lhs - d) <= (2.0 * C * d / L) + 1e-9
            if L > 4.0:
                assert lhs > 0.0
    return True


def check_discrete_telescoping():
    a, b = find_return_arch()
    d = b - a
    h = lambda t: 2.0 * math.sin(3.0 * t)
    Delta = lambda t: nonmono_f(t + d) - nonmono_f(t)
    rng = np.random.default_rng(111)
    for _ in range(100):
        t = rng.uniform(-10, 10)
        N = int(rng.integers(1, 100))
        lhs = sum(Delta(t + k * d) for k in range(N))
        rhs = N * d + h(t + N * d) - h(t)
        assert abs(lhs - rhs) < 1e-9
    return True


def running_max_grid(f, xs):
    vals = np.array([f(float(x)) for x in xs])
    return np.maximum.accumulate(vals)


def check_running_record_bound():
    C = 2.0
    xs = np.linspace(-30, 30, 20001)
    M = running_max_grid(nonmono_f, xs)
    # Grid running max begins at finite left endpoint, but for this specific
    # profile the left endpoint is already far enough for the bound on the grid.
    assert np.max(np.abs(M - xs)) <= C + 2e-2
    assert np.all(np.diff(M) >= -1e-12)
    return True


def main():
    results = []
    results.append(("contact_coordinates", check_contact_coordinates()))
    results.append(("plateau_faces", check_plateau_faces()))
    results.append(("random_plateau_targets", check_random_targets_attained()))
    d = check_return_arch_identity()
    results.append(("return_arch_identity", d))
    results.append(("averaging_identity", check_averaging_identity()))
    results.append(("discrete_telescoping", check_discrete_telescoping()))
    results.append(("running_record_bound", check_running_record_bound()))

    print("v157 verifier: PASS")
    for name, val in results:
        print(f"  {name}: {val}")


if __name__ == "__main__":
    main()
