#!/usr/bin/env python3
"""Independent numerical/algebraic checks for v158.

These checks verify the exact identities and a concrete piecewise-linear
return-arch example used to audit the two-channel theorem.  They are not a
proof of the Toeplitz conjecture.
"""

from __future__ import annotations

import math
import random
from typing import Callable


def f(t: float) -> float:
    """Balanced PL profile with a genuine return arch [-1,1] at level 1."""
    if t <= -2.0:
        return t
    if t <= -1.0:
        return 3.0 * t + 4.0
    if t <= 0.0:
        return -2.0 * t - 1.0
    if t <= 1.0:
        return 2.0 * t - 1.0
    return t


def h(t: float) -> float:
    return f(t) - t


def delta(d: float, x: float) -> float:
    return f(x + d) - f(x)


def phi(u0: float, u1: float, u2: float):
    u3 = u0 + u2 - u1
    return (
        f(u1) - f(u0),
        f(u2) - f(u1),
        f(u3) - f(u0),
    )


def L(y: float) -> float:
    # Left tail of the audit profile is the identity for y <= -2.
    assert y <= -2.0 + 1e-12
    return y


def R(y: float) -> float:
    # Right tail is the identity for y >= 1.  We stay much farther right.
    assert y >= 2.0 - 1e-12
    return y


def contacts(r1: float, r2: float, s: float):
    u0 = L(f(s) - r1)
    u1 = s
    u2 = R(f(s) + r2)
    return u0, u1, u2


def W(r1: float, r2: float, s: float) -> float:
    u0, u1, u2 = contacts(r1, r2, s)
    return phi(u0, u1, u2)[2]


def numeric_integral(g: Callable[[float], float], a: float, b: float, n: int = 200000) -> float:
    step = (b - a) / n
    total = 0.5 * (g(a) + g(b))
    for k in range(1, n):
        total += g(a + k * step)
    return total * step


def check(name: str, cond: bool, detail: str = ""):
    if not cond:
        raise AssertionError(f"FAIL: {name}: {detail}")
    print(f"PASS: {name}" + (f" — {detail}" if detail else ""))


def main():
    # 1. Balanced displacement and arch geometry.
    xs = [(-20.0 + 40.0 * k / 20000.0) for k in range(20001)]
    max_disp = max(abs(h(x)) for x in xs)
    check("balanced displacement", max_disp <= 2.0 + 1e-12, f"max |f(t)-t| = {max_disp:.12g}")

    arch_xs = [-1.0 + 2.0 * k / 20000.0 for k in range(20001)]
    arch_max = max(f(x) for x in arch_xs)
    arch_min = min(f(x) for x in arch_xs)
    check(
        "return arch and depth",
        abs(f(-1.0) - 1.0) < 1e-12
        and abs(f(1.0) - 1.0) < 1e-12
        and arch_max <= 1.0 + 1e-12
        and abs(arch_min + 1.0) < 2e-4,
        f"z=1, d=2, D={1.0-arch_min:.12g}",
    )

    # 2. Exact triangularization on random channel parameters.
    rng = random.Random(158)
    worst1 = 0.0
    worst2 = 0.0
    worst_order = 1e9
    for _ in range(5000):
        r1 = 10.8 + 0.4 * rng.random()
        r2 = 12.8 + 0.4 * rng.random()
        s = -1.0 + 2.0 * rng.random()
        u0, u1, u2 = contacts(r1, r2, s)
        out = phi(u0, u1, u2)
        worst1 = max(worst1, abs(out[0] - r1))
        worst2 = max(worst2, abs(out[1] - r2))
        worst_order = min(worst_order, u1 - u0, u2 - u1)
    check(
        "exact two-channel triangularization",
        worst1 < 1e-11 and worst2 < 1e-11 and worst_order > 0,
        f"max errors=({worst1:.3e},{worst2:.3e}), min order gap={worst_order:.6g}",
    )

    # 3. Exact endpoint defect formula.
    worst_defect = 0.0
    min_gap = 1e9
    for _ in range(5000):
        r1 = 10.8 + 0.4 * rng.random()
        r2 = 12.8 + 0.4 * rng.random()
        x = L(1.0 - r1) + R(1.0 + r2) - 1.0
        lhs = W(r1, r2, -1.0) - W(r1, r2, 1.0)
        rhs = delta(2.0, x)
        worst_defect = max(worst_defect, abs(lhs - rhs))
        min_gap = min(min_gap, lhs)
    check(
        "endpoint gap equals translation defect",
        worst_defect < 1e-11 and min_gap > 1.9,
        f"max identity error={worst_defect:.3e}, min endpoint gap={min_gap:.6g}",
    )

    # 4. A common vertical slab really is crossed throughout a parameter box.
    # Central endpoint values are 15 and 13, so (13.5,14.5) is protected.
    targets = [13.55, 13.8, 14.0, 14.2, 14.45]
    all_cross = True
    lower_max = -1e9
    upper_min = 1e9
    for _ in range(1000):
        r1 = 10.9 + 0.2 * rng.random()
        r2 = 12.9 + 0.2 * rng.random()
        wb = W(r1, r2, 1.0)
        wa = W(r1, r2, -1.0)
        lower_max = max(lower_max, wb)
        upper_min = min(upper_min, wa)
        for t in targets:
            if not (wb < t < wa):
                all_cross = False
    check(
        "protected common vertical slab",
        all_cross and lower_max < upper_min,
        f"sup lower endpoint={lower_max:.6g}, inf upper endpoint={upper_min:.6g}",
    )

    # 5. Central concrete configuration.
    p, q, b = -10.0, 14.0, 1.0
    x0 = p + q - b
    central_gap = delta(2.0, x0)
    check(
        "central channel-sum separation",
        abs(x0 - 3.0) < 1e-12 and abs(central_gap - 2.0) < 1e-12,
        f"x=p+q-b={x0:g}, Delta_2(x)={central_gap:g}",
    )

    # 6. v157 long-scale average identity on the same profile.
    # For L=100 the theoretical lower bound is d(1-4/L)=1.92.
    X, Llen, d = -50.0, 100.0, 2.0
    avg = numeric_integral(lambda t: delta(d, t), X, X + Llen, n=50000) / Llen
    check(
        "positive-mean translation defect",
        avg >= d * (1.0 - 4.0 / Llen) - 2e-4,
        f"average={avg:.9g}, guaranteed lower bound={d*(1-4/Llen):.9g}",
    )

    # 7. Tail rays make the channel sumset all of R: audit on random targets.
    P, Q = -10.0, 10.0
    ok = True
    max_reconstruction_error = 0.0
    for _ in range(10000):
        target = -1000.0 + 2000.0 * rng.random()  # desired p+q
        # choose q >= Q large enough, then p=target-q <= P
        qv = max(Q, target - P) + 1.0
        pv = target - qv
        ok = ok and pv <= P + 1e-12 and qv >= Q - 1e-12
        max_reconstruction_error = max(max_reconstruction_error, abs((pv + qv) - target))
    check(
        "opposite channel rays have full additive sumset",
        ok and max_reconstruction_error < 1e-10,
        f"max reconstruction error={max_reconstruction_error:.3e}",
    )

    # 8. One channel ray plus an unbounded opposite set also fills R.
    # Use a sparse unbounded set {10,20,30,...}; for any target choose q big enough.
    ok = True
    for _ in range(10000):
        target = -1000.0 + 2000.0 * rng.random()
        n = max(1, math.ceil((target - P) / 10.0) + 1)
        qv = 10.0 * n
        pv = target - qv
        ok = ok and pv <= P + 1e-12 and qv >= 10.0
    check("one ray + unbounded opposite channels fills R", ok)

    print("\nAll 8 v158 verifier groups passed.")


if __name__ == "__main__":
    main()
