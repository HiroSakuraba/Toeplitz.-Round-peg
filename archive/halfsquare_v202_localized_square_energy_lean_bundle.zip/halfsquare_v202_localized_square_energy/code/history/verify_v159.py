from fractions import Fraction
from collections import defaultdict
import random, math


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)

# -----------------------------------------------------------------------------
# 1. Exact endpoint translation identity on a generic continuous test function.
# -----------------------------------------------------------------------------
def fnum(t):
    return t + 1.3*math.sin(1.7*t) + 0.35*math.sin(4.1*t)

random.seed(159)
for _ in range(1000):
    a = random.uniform(-2,2)
    d = random.uniform(0.05,2.5)
    b = a+d
    u = random.uniform(-8,-1)
    v = random.uniform(1,8)
    x = u+v-b
    lhs = (fnum(u+v-a)-fnum(u)) - (fnum(u+v-b)-fnum(u))
    rhs = fnum(x+d)-fnum(x)
    check(abs(lhs-rhs) < 1e-11, 'endpoint translation identity failed')
print('PASS 1: exact endpoint translation identity')

# -----------------------------------------------------------------------------
# 2. Product degree = 1 for folded 1D crossings.
#    Piecewise-linear balanced test profile with three roots on each side.
# -----------------------------------------------------------------------------
pts = [
    (Fraction(-8), Fraction(-8)),
    (Fraction(-6), Fraction(-4)),
    (Fraction(-9,2), Fraction(-13,2)),
    (Fraction(-3), Fraction(-3)),
    (Fraction(0), Fraction(2)),
    (Fraction(2), Fraction(0)),
    (Fraction(4), Fraction(4)),
    (Fraction(6), Fraction(8)),
    (Fraction(15,2), Fraction(11,2)),
    (Fraction(9), Fraction(9)),
]

def fpl(x):
    x = Fraction(x)
    if x <= pts[0][0] or x >= pts[-1][0]:
        return x
    for (x0,y0),(x1,y1) in zip(pts[:-1],pts[1:]):
        if x0 <= x <= x1:
            return y0 + (y1-y0)*(x-x0)/(x1-x0)
    raise RuntimeError

def roots_level(y):
    y = Fraction(y)
    roots = {}
    for (x0,y0),(x1,y1) in zip(pts[:-1],pts[1:]):
        if y0 == y1:
            continue
        if (y-y0)*(y-y1) <= 0:
            t = (y-y0)/(y1-y0)
            if 0 <= t <= 1:
                x = x0 + t*(x1-x0)
                slope = (y1-y0)/(x1-x0)
                # test levels below avoid vertices, so no ambiguity here
                roots[x] = 1 if slope > 0 else -1
    return sorted(roots.items())

alpha = Fraction(-5)
beta = Fraction(7)
ru = roots_level(alpha)
rv = roots_level(beta)
check([s for _,s in ru] == [1,-1,1], 'left signs not +,-,+')
check([s for _,s in rv] == [1,-1,1], 'right signs not +,-,+')
check(sum(s for _,s in ru) == 1, 'left degree != 1')
check(sum(s for _,s in rv) == 1, 'right degree != 1')
check(sum(eu*ev for _,eu in ru for _,ev in rv) == 1, 'product degree != 1')
print('PASS 2: folded scalar crossing degrees and normalized product degree are +1')

# -----------------------------------------------------------------------------
# 3. Exact finite-branch endpoint-current data for the test return arch.
# -----------------------------------------------------------------------------
a = Fraction(0)
b = Fraction(3)
d = b-a
carriers = []
for u,eu in ru:
    for v,ev in rv:
        w = eu*ev
        x = u+v-b
        B = fpl(x)-alpha
        A = fpl(x+d)-alpha
        check(A-B == fpl(x+d)-fpl(x), 'carrier defect mismatch')
        carriers.append((w,B,A,x))
check(sum(w for w,_,_,_ in carriers) == 1, 'endpoint total degree != 1')
print('PASS 3: finite-branch carrier defects and total degree')

# -----------------------------------------------------------------------------
# 4. Boundary current equals derivative of interval coverage.
#    We check the jump of the coverage multiplicity at every endpoint.
# -----------------------------------------------------------------------------
def oriented_cover(B,A,c):
    if B < A:
        return 1 if B < c < A else 0
    if A < B:
        return -1 if A < c < B else 0
    return 0

boundary = defaultdict(int)
for w,B,A,_ in carriers:
    boundary[A] += w
    boundary[B] -= w

endpoints = sorted(set([B for _,B,_,_ in carriers] + [A for _,_,A,_ in carriers]))
# coverage on each complementary interval
samples = []
allcuts = [endpoints[0]-1] + endpoints + [endpoints[-1]+1]
for lo,hi in zip(allcuts[:-1],allcuts[1:]):
    if lo < hi:
        c = (lo+hi)/2
        mult = sum(w*oriented_cover(B,A,c) for w,B,A,_ in carriers)
        samples.append((c,mult))
# jump in coverage crossing endpoint p equals -boundary[p] with our convention
for p in endpoints:
    eps = Fraction(1,10**6)
    left = sum(w*oriented_cover(B,A,p-eps) for w,B,A,_ in carriers)
    right = sum(w*oriented_cover(B,A,p+eps) for w,B,A,_ in carriers)
    check(right-left == -boundary[p], f'boundary/coverage mismatch at {p}')
check(any(mult != 0 for _,mult in samples), 'test current unexpectedly zero')
print('PASS 4: oriented interval current and endpoint boundary agree')

# -----------------------------------------------------------------------------
# 5. Critical audit counterexample: same-direction intervals can cancel.
# -----------------------------------------------------------------------------
motif = [(+1, Fraction(0), Fraction(1)),
         (-1, Fraction(0), Fraction(2)),
         (+1, Fraction(1), Fraction(2))]
check(sum(w for w,_,_ in motif) == 1, 'motif total coefficient should be 1')
for k in range(-10,31):
    c = Fraction(k,10)
    if c in {Fraction(0),Fraction(1),Fraction(2)}:
        continue
    cov = sum(w*oriented_cover(B,A,c) for w,B,A in motif)
    check(cov == 0, f'motif does not cancel at {c}')
mb = defaultdict(int)
for w,B,A in motif:
    mb[A] += w
    mb[B] -= w
check(all(v==0 for v in mb.values()), 'motif endpoint current nonzero')
print('PASS 5: +,-,+ same-direction cancellation motif is real')

# -----------------------------------------------------------------------------
# 6. Cycle decomposition sanity check for zero-boundary integer interval currents.
#    Construct two explicit directed cycles, convert one edge to negative weight,
#    and verify zero boundary / zero coverage.
# -----------------------------------------------------------------------------
# Oriented-current carriers can use signed weights. These four produce two
# subdivisions that cancel identically.
cycle_current = [
    (+1, Fraction(0), Fraction(1)),
    (+1, Fraction(1), Fraction(3)),
    (-1, Fraction(0), Fraction(3)),
    (+2, Fraction(4), Fraction(5)),
    (+2, Fraction(5), Fraction(6)),
    (-2, Fraction(4), Fraction(6)),
]
cb = defaultdict(int)
for w,B,A in cycle_current:
    cb[A] += w
    cb[B] -= w
check(all(v==0 for v in cb.values()), 'cycle current boundary nonzero')
for k in range(-10,71):
    c=Fraction(k,10)
    if c in {Fraction(0),Fraction(1),Fraction(3),Fraction(4),Fraction(5),Fraction(6)}:
        continue
    cov=sum(w*oriented_cover(B,A,c) for w,B,A in cycle_current)
    check(cov==0, 'cycle current coverage nonzero')
print('PASS 6: zero current decomposes through directed subdivision cycles')

# -----------------------------------------------------------------------------
# 7. Pair-sum localization under |f(t)-t| <= 2 for all actual PL endpoint roots.
# -----------------------------------------------------------------------------
center = alpha+beta-b
for u,_ in ru:
    check(abs(u-alpha) <= 2, 'left root outside balanced strip')
for v,_ in rv:
    check(abs(v-beta) <= 2, 'right root outside balanced strip')
for w,B,A,x in carriers:
    check(abs(x-center) <= 4, 'pair sum outside radius-4 localization')
print('PASS 7: pair-sum localization radius 4')

# -----------------------------------------------------------------------------
# 8. First-moment identity: zero interval current => weighted total length 0.
#    Verify motif and cycle examples; verify nonzero test current has nonzero or
#    at least unconstrained moment and a nonzero endpoint distribution.
# -----------------------------------------------------------------------------
for cur in [motif, cycle_current]:
    moment = sum(w*(A-B) for w,B,A in cur)
    check(moment == 0, 'zero current first moment failed')
actual_moment = sum(w*(A-B) for w,B,A,_ in carriers)
actual_boundary_nonzero = any(v != 0 for v in boundary.values())
check(actual_boundary_nonzero, 'actual folded test should be detected')
print('PASS 8: moment identities and nonzero folded-test current')

# -----------------------------------------------------------------------------
# 9. Generic endpoint-separation criterion: distinct endpoints imply nonzero
#    boundary current whenever every endpoint atom occurs only once.
# -----------------------------------------------------------------------------
synthetic = [(+1,Fraction(0),Fraction(1)),
             (-1,Fraction(2),Fraction(4)),
             (+1,Fraction(5),Fraction(8))]
sb=defaultdict(int)
for w,B,A in synthetic:
    sb[A]+=w; sb[B]-=w
check(len([v for v in sb.values() if v]) == 6, 'synthetic endpoints should all survive')
print('PASS 9: generic distinct endpoint values cannot cancel')

print(f'actual folded test: {len(ru)} x {len(rv)} = {len(carriers)} endpoint carriers')
print(f'actual folded current first moment = {float(actual_moment):.12g} ({actual_moment})')

# -----------------------------------------------------------------------------
# 10. C^0 orientation algebra behind the same-type collision lemma.
#     If rho1*s1 = rho2*s2 and rho1*t1 = rho2*t2, then product signs agree.
# -----------------------------------------------------------------------------
signs=(-1,1)
count=0
for rho1 in signs:
    for rho2 in signs:
        for s1 in signs:
            for s2 in signs:
                for t1 in signs:
                    for t2 in signs:
                        if rho1*s1 == rho2*s2 and rho1*t1 == rho2*t2:
                            check((s1*t1)==(s2*t2), 'same-type collision sign lemma failed')
                            count += 1
check(count>0, 'orientation test vacuous')
print(f'PASS 10: same-type collision orientation lemma ({count} sign cases)')

# -----------------------------------------------------------------------------
# 11. Minimal +,-,+ cancellation necessarily uses opposite-sign same-type
#     endpoint collisions, exactly what Theorem 13.1 forbids in a regular
#     locally monotone chamber.
# -----------------------------------------------------------------------------
# motif: I1=[0,1], -I2=-[0,2], I3=[1,2]
# required endpoint matches are B1=B2, A1=B3, A3=A2.
B1,A1=Fraction(0),Fraction(1)
B2,A2=Fraction(0),Fraction(2)
B3,A3=Fraction(1),Fraction(2)
check(B1==B2 and A1==B3 and A3==A2, 'minimal cycle endpoint matches wrong')
# B1=B2 joins weights + and -, A3=A2 joins + and -.
check((+1)*(-1)==-1 and (+1)*(-1)==-1, 'minimal cycle should switch degree signs')
print('PASS 11: minimal cancellation cycle requires forbidden opposite-sign B=B / A=A matches')

print('\nALL 11 V159 CHECKS PASSED')
