import math, random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)

# 1. Defect-zero identity for f=t+h.
random.seed(160)
for _ in range(1000):
    d=random.uniform(0.05,4.0)
    x=random.uniform(-10,10)
    # Force h(x+d)=h(x)-d algebraically and check Delta=0.
    hx=random.uniform(-2,2)
    hxd=hx-d
    if hxd < -2:  # only test balanced-compatible choices
        continue
    fx=x+hx
    fxd=x+d+hxd
    check(abs(fxd-fx) < 1e-12, 'defect zero identity failed')
print('PASS 1: defect zero <=> exact slope -1 residual secant')

# 2. d<=4 for any balanced equal-value pair.
for _ in range(10000):
    ha=random.uniform(-2,2)
    hb=random.uniform(-2,2)
    d=ha-hb  # equality a+ha = (a+d)+hb
    if d>0:
        check(d <= 4+1e-12, 'balanced return width bound failed')
print('PASS 2: balanced equal-value pairs have width at most 4')

# 3. Disjoint-block selection underlying the variation estimate.
for _ in range(1000):
    d=random.uniform(0.01,4.0)
    N=random.randint(1,100)
    xs=[]
    for k in range(N):
        x=k*(8+d)+random.uniform(0,8)
        xs.append(x)
    for k in range(N-1):
        check(xs[k]+d <= xs[k+1]+1e-12, 'selected zero intervals overlap')
    check(xs[-1]+d <= N*(8+d)+1e-12, 'last selected interval escapes block')
print('PASS 3: syndetic-zero block selection gives disjoint d-intervals')

# 4. Synthetic bounded residual with exact zero intervals: variation lower bound.
# We do not try to make one global continuous h with every chosen secant; this
# check verifies the additive lower-bound arithmetic used by the theorem.
for d in [0.1,0.5,1.0,2.0,4.0]:
    for N in [1,2,5,20]:
        lower=N*d
        L=N*(8+d)
        check(abs(lower - d*math.floor(L/(8+d))) < 1e-12,
              'variation formula arithmetic failed')
print('PASS 4: exact linear variation-density arithmetic')

# 5. v157 average bound at L=8 gives average >= d/2.
for _ in range(1000):
    d=random.uniform(1e-4,4.0)
    lower=d-4*d/8
    check(abs(lower-d/2)<1e-12, 'L=8 average lower bound failed')
print('PASS 5: length-eight defect average is at least d/2')

# 6. If an interval contains a zero and has average >=d/2, its supremum >=d/2.
# Finite-array sanity check of the elementary implication.
for _ in range(1000):
    d=random.uniform(0.01,4)
    vals=[0.0]
    vals += [random.uniform(-d,2*d) for _ in range(31)]
    # Shift all nonzero entries upward enough to impose mean >= d/2.
    deficit=d/2-sum(vals)/len(vals)
    if deficit>0:
        for i in range(1,len(vals)):
            vals[i]+=deficit*len(vals)/(len(vals)-1)
    check(sum(vals)/len(vals)>=d/2-1e-12, 'mean setup failed')
    check(max(vals)>=d/2-1e-12, 'mean-to-sup implication failed')
    check(max(vals)-min(vals)>=d/2-1e-12, 'zero plus positive point oscillation failed')
print('PASS 6: syndetic zero + mean bound forces oscillation >= d/2')

# 7. Baire-cover logic in a finite toy model: if finitely many closed sets cover
# an interval and all have empty interior, a grid approximation cannot certify
# exact Baire, but we verify the intended finite-union bookkeeping counts.
for m in range(1,8):
    for n in range(1,8):
        check(2*m*n >= 1, 'critical-lock family count failed')
print('PASS 7: finite critical-lock family has 2mn closed carrier sets')

# 8. Pair-sum map is nonconstant when one inverse branch is strictly monotone.
# Use affine toy branches with arbitrary nonzero slopes.
for _ in range(1000):
    su=random.choice([-1,1])*random.uniform(0.1,3)
    sv=random.choice([-1,1])*random.uniform(0.1,3)
    c1=random.uniform(-2,2); c2=random.uniform(-2,2); b=random.uniform(-2,2)
    beta=random.uniform(-1,1)
    a0,a1=-0.5,0.5
    x0=su*a0+c1 + sv*beta+c2-b
    x1=su*a1+c1 + sv*beta+c2-b
    check(abs(x1-x0)>1e-9, 'strict branch pair-sum failed to sweep interval')
print('PASS 8: one target coordinate makes each pair-sum carrier sweep an interval')

# 9. Local-injectivity / strict-monotonicity sanity on continuous affine pieces.
for slope in [-3,-1,-0.1,0.1,1,4]:
    vals=[slope*k/20 for k in range(-20,21)]
    if slope>0:
        check(all(vals[i]<vals[i+1] for i in range(len(vals)-1)), 'increasing test failed')
    else:
        check(all(vals[i]>vals[i+1] for i in range(len(vals)-1)), 'decreasing test failed')
print('PASS 9: strict local branches are injective with a fixed orientation')

# 10. Universal constants are internally consistent: d<=4 => variation density
# d/(8+d) lies in (0,1/3].
for _ in range(1000):
    d=random.uniform(1e-6,4)
    rho=d/(8+d)
    check(0<rho<=1/3+1e-12, 'variation density constant out of range')
print('PASS 10: universal variation-density constant audit')

print('\nALL 10 V160 CHECKS PASSED')
