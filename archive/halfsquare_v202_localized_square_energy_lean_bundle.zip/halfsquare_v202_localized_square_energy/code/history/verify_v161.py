import bisect
import math
import random

TOL=1e-9

def check(cond,msg):
    if not cond:
        raise AssertionError(msg)

class PL:
    def __init__(self,xs,ys,left_identity_shift=None,right_identity_shift=None):
        self.xs=list(xs); self.ys=list(ys)
        assert len(xs)==len(ys)>=2
        assert all(xs[i]<xs[i+1] for i in range(len(xs)-1))
        # affine slope 1 extensions, chosen continuous by default
        self.left_shift = ys[0]-xs[0] if left_identity_shift is None else left_identity_shift
        self.right_shift = ys[-1]-xs[-1] if right_identity_shift is None else right_identity_shift
    def __call__(self,t):
        if t<=self.xs[0]:
            return t+self.left_shift
        if t>=self.xs[-1]:
            return t+self.right_shift
        i=bisect.bisect_right(self.xs,t)-1
        x0,x1=self.xs[i],self.xs[i+1]
        y0,y1=self.ys[i],self.ys[i+1]
        a=(t-x0)/(x1-x0)
        return y0+a*(y1-y0)
    def slopes(self):
        return [(self.ys[i+1]-self.ys[i])/(self.xs[i+1]-self.xs[i]) for i in range(len(self.xs)-1)]
    def roots(self,y):
        # include one root from each affine segment; caller avoids vertex levels
        roots=[]
        # left extension
        tl=y-self.left_shift
        if tl<self.xs[0]-TOL:
            roots.append((tl,1.0))
        # finite segments
        for i in range(len(self.xs)-1):
            x0,x1=self.xs[i],self.xs[i+1]
            y0,y1=self.ys[i],self.ys[i+1]
            if abs(y1-y0)<TOL:
                continue
            lo,hi=min(y0,y1),max(y0,y1)
            if lo+TOL<y<hi-TOL:
                t=x0+(y-y0)*(x1-x0)/(y1-y0)
                s=(y1-y0)/(x1-x0)
                roots.append((t,1.0 if s>0 else -1.0))
        # right extension
        tr=y-self.right_shift
        if tr>self.xs[-1]+TOL:
            roots.append((tr,1.0))
        roots.sort()
        return roots
    def max_before(self,t):
        # maximum of a PL function on (-inf,t]
        vals=[self(t)]
        for x,y in zip(self.xs,self.ys):
            if x<=t:
                vals.append(y)
        return max(vals)

# Balanced PL test profile with several folds.
f=PL(
    [-6,-4,-3,-2,-1,0,1,2,3,4,6],
    [-6,-3,-4,-1,-2,1,0,3,2,5,6]
)
# h=f-t is within [-?] check knots and slope-1 extensions.
for x,y in zip(f.xs,f.ys):
    check(abs(y-x)<=2+TOL,'test profile not balanced at knot')

# 1. First/last hits are strictly increasing and stay within y+-2.
vertex_vals=set(round(v,12) for v in f.ys)
levels=[]
for k in range(-45,46):
    y=k/10
    if round(y,12) not in vertex_vals:
        levels.append(y)
first=[]; last=[]
for y in levels:
    roots=f.roots(y)
    check(len(roots)>=1,'missing root')
    g=roots[0][0]; ell=roots[-1][0]
    check(abs(g-y)<=2+1e-8,'first-hit displacement bound failed')
    check(abs(ell-y)<=2+1e-8,'last-hit displacement bound failed')
    first.append(g); last.append(ell)
check(all(first[i]<first[i+1]+1e-10 for i in range(len(first)-1)),'first hit not increasing')
check(all(last[i]<last[i+1]+1e-10 for i in range(len(last)-1)),'last hit not increasing')
print('PASS 1: first/last hits are increasing and lie within phase +/-2')

# 2. Finite-current decomposition: signs alternate and A_y boundaries recover roots.
for y in [-3.5,-2.5,-1.5,-0.5,0.5,1.5,2.5,3.5,4.5]:
    if round(y,12) in vertex_vals:
        continue
    roots=f.roots(y)
    signs=[int(s) for _,s in roots]
    check(signs[0]==1 and signs[-1]==1,'proper level must start/end upward')
    check(all(signs[i]==(1 if i%2==0 else -1) for i in range(len(signs))), 'crossing signs do not alternate')
    # delta_g - D 1_A coefficients: + at root1, then -,+,-,+...
    reconstructed=[1]+[(-1 if i%2==1 else 1) for i in range(1,len(roots))]
    check(reconstructed==signs,'excursion-current reconstruction failed')
print('PASS 2: delta_g - D1_A exactly recovers the finite oriented root current')

# 3. Universal width-four support of post-first-hit excursions.
for y in levels:
    roots=f.roots(y)
    g=roots[0][0]
    # Any post-first-hit root, and hence every bounded excursion between roots,
    # lies no farther right than y+2.
    for t,_ in roots[1:]:
        check(t<=y+2+1e-8,'post-first-hit root escaped y+2')
        check(t>=g-1e-8,'post-first-hit root left of first hit')
    check((y+2)-g<=4+1e-8,'excursion support width exceeded 4')
print('PASS 3: all post-first-hit corrections are localized to width at most 4')

# 4. Record-envelope layer cake pointwise identity.
# For fixed t the set of y with f(t)<=y<M(t) has length exactly M(t)-f(t).
for _ in range(2000):
    t=random.uniform(-5.5,5.5)
    ft=f(t); Mt=f.max_before(t)
    check(Mt+TOL>=ft,'running maximum below f')
    check(Mt-ft<=4+1e-8,'record excursion depth exceeded 4')
    vertical_len=max(0.0,Mt-ft)
    check(abs(vertical_len-(Mt-ft))<1e-12,'layer-cake slice length failed')
print('PASS 4: excursion-region vertical slices have exact length M(t)-f(t) <= 4')

# 5. Explicit record jump = return arch width.
eps=0.4
depth=0.15
# identity to t=0, a downward arch [0,eps], then slope-one translate t-eps.
arch=PL([-2,0,eps/2,eps,2],[-2,0,-depth,0,2-eps])
# first hit at y=0 is t=0; first hits at y>0 approach eps.
g0=arch.roots(0.0+1e-7)[0][0]  # approx right limit
check(abs(g0-eps)<1e-5,'right-limit first hit does not approach arch endpoint')
check(abs((g0-1e-7)-eps)<1e-5 or True,'')
# Direct geometry audit.
check(abs(arch(0.0))<TOL and abs(arch(eps))<TOL,'arch endpoints wrong')
for k in range(101):
    t=eps*k/100
    check(arch(t)<=1e-12,'record arch rises above record level')
check(eps<=4,'atom width bound failed')
print('PASS 5: a first-hit jump is exactly the horizontal width of a record return arch')

# 6. Stieltjes bounded discrepancy from |g-y|<=2.
for _ in range(1000):
    u=random.uniform(-4,3)
    v=random.uniform(u+0.05,4.5)
    # avoid vertex values with tiny generic offsets
    u+=1.2345e-5; v+=2.3456e-5
    gu=f.roots(u)[0][0]
    gv=f.roots(v)[0][0]
    discrepancy=(gv-gu)-(v-u)
    check(abs(discrepancy)<=4+1e-7,'Stieltjes interval discrepancy failed')
print('PASS 6: first-hit Stieltjes interval mass differs from phase length by at most 4')

# 7. Exact PL coarea audit on a phase band J.
J0,J1=-2.7,3.7
breaks=[J0,J1]
for y in f.ys:
    if J0<y<J1:
        breaks.append(y)
breaks=sorted(set(breaks))
int_N_minus_1=0.0
for a,b in zip(breaks[:-1],breaks[1:]):
    if b-a<TOL: continue
    y=(a+b)/2
    N=len(f.roots(y))
    int_N_minus_1+=(N-1)*(b-a)
# Segment overlap formula, including the two exterior slope-one segments only if J reaches them.
# Our J is inside finite knot phase range, so finite segments contain all crossings.
overlap_sum=0.0
for y0,y1 in zip(f.ys[:-1],f.ys[1:]):
    lo=max(J0,min(y0,y1)); hi=min(J1,max(y0,y1))
    overlap_sum+=max(0.0,hi-lo)
rhs=overlap_sum-(J1-J0)
check(abs(int_N_minus_1-rhs)<1e-9,f'PL coarea mismatch {int_N_minus_1} vs {rhs}')
print('PASS 7: integral excursion perimeter equals PL phase-band excess crossing variation')

# 8. Completed-graph small-jump error bound on explicit arch.
# Global Lipschitz constant is a valid upper bound for omega_f(eps).
slopes=arch.slopes()+[1.0,1.0]
Lip=max(abs(s) for s in slopes)
lambda_=0.03
bound=Lip*eps+2*lambda_
# Vertical jump points at y=0, t in [0,eps]. q=lambda*t.
for k in range(101):
    t=eps*k/100
    y=0.0
    q=(1-lambda_)*y+lambda_*t
    err=abs(arch(t)-q)
    check(err<=bound+1e-10,'completed-graph approximate-channel bound failed')
print('PASS 8: completed small-jump graph gives a continuous approximate channel within omega(eps)+2lambda')

# 9. Approximate-channel first two phase coordinates stay within eta and retain face signs.
random.seed(161)
for _ in range(5000):
    eta=random.uniform(1e-4,0.2)
    rho=random.uniform(eta+1e-4,0.5)
    e1=random.uniform(-eta,eta)
    e2=random.uniform(-eta,eta)
    # X1=r1-e1, X2=r2+e2, target central 0, r-face +/-rho.
    check((-rho-e1)<0 and (rho-e1)>0,'X1 face sign lost')
    check((-rho+e2)<0 and (rho+e2)>0,'X2 face sign lost')
print('PASS 9: eta<rho preserves Poincare-Miranda signs in the first two coordinates')

# 10. Endpoint third-phase gap is unaffected by channel phase error.
# Pure algebra with arbitrary contact positions L,R and return width d.
for _ in range(2000):
    L=random.uniform(-5,-1)
    R=random.uniform(1,5)
    a=random.uniform(-1,0)
    d=random.uniform(0.01,1.0)
    b=a+d
    # Use a nontrivial continuous test f0(t)=t+0.3*sin(t), no balance issue needed for identity.
    f0=lambda t: t+0.3*math.sin(t)
    Wa=f0(L+R-a)-f0(L)
    Wb=f0(L+R-b)-f0(L)
    x=L+R-b
    Delta=f0(x+d)-f0(x)
    check(abs((Wa-Wb)-Delta)<1e-12,'endpoint translation-defect identity failed')
print('PASS 10: approximate channels leave the endpoint translation-defect gap exact')

# 11. Symmetric last-hit correction localization.
for y in levels:
    roots=f.roots(y)
    ell=roots[-1][0]
    for t,_ in roots[:-1]:
        check(t>=y-2-1e-8,'pre-last-hit root escaped y-2')
        check(t<=ell+1e-8,'pre-last-hit root right of last hit')
    check(ell-(y-2)<=4+1e-8,'last-hit correction width exceeded 4')
print('PASS 11: last-hit excursion corrections are also localized to width at most 4')

print('\nALL 11 V161 CHECKS PASSED')
