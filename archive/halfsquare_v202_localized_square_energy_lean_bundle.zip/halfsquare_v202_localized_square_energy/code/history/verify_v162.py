import bisect, math

TOL=1e-10

def check(cond,msg):
    if not cond:
        raise AssertionError(msg)

class PL:
    def __init__(self, pts):
        pts=sorted(pts)
        xs=[]; ys=[]
        for x,y in pts:
            if xs and abs(x-xs[-1])<1e-15:
                ys[-1]=y
            else:
                xs.append(float(x)); ys.append(float(y))
        self.xs=xs; self.ys=ys
        assert all(xs[i]<xs[i+1] for i in range(len(xs)-1))
        self.left_shift=ys[0]-xs[0]
        self.right_shift=ys[-1]-xs[-1]
    def __call__(self,x):
        if x<=self.xs[0]: return x+self.left_shift
        if x>=self.xs[-1]: return x+self.right_shift
        i=bisect.bisect_right(self.xs,x)-1
        x0,x1=self.xs[i],self.xs[i+1]
        y0,y1=self.ys[i],self.ys[i+1]
        t=(x-x0)/(x1-x0)
        return y0+t*(y1-y0)


def seq(n):
    a=2.0**(-n)
    ell=2.0**(-4*n-4)
    b=a+ell
    m=0.5*(a+b)
    alpha=1.0/n
    return a,b,m,ell,alpha


def build_f(N):
    pts=[(-1.0,-1.0),(0.0,0.0)]
    # Source region near 0: infinitely many (in limit) negative excursions at level 0.
    prev=0.0
    for n in range(N,1,-1):
        a,b,m,ell,alpha=seq(n)
        if a>prev:
            q=0.5*(prev+a)
            pts.append((q,q/4.0))
        pts += [(a,0.0),(m,-ell),(b,0.0)]
        prev=b
    q=0.5*(prev+0.5)
    pts += [(q,q/4.0),(0.5,0.5),(1.0,1.0)]
    # Shifted target region near 1: translation map values 1 +/- 1/n.
    for n in range(N,1,-1):
        a,b,m,ell,alpha=seq(n)
        pts += [(1.0+a,1.0+alpha),(1.0+b,1.0-alpha)]
    pts += [(1.5,1.5),(2.0,2.0)]
    return PL(pts)

N=10
f=build_f(N)

# 1. Persistence intervals are disjoint and widths are summable.
ints=[]
for n in range(2,N+1):
    a,b,m,ell,alpha=seq(n)
    ints.append((a,b,ell))
for i,(a,b,ell) in enumerate(ints):
    for j,(c,d,ell2) in enumerate(ints):
        if i<j:
            check(b<=c or d<=a, 'persistence intervals overlap')
geom_tail=sum(seq(n)[3] for n in range(2,500))
check(geom_tail<1e-3,'width budget unexpectedly large')
print('PASS 1: vanishing-persistence excursion widths are disjoint and summable')

# 2. Balanced condition at all PL knots implies it on every segment by convexity.
for x,y in zip(f.xs,f.ys):
    check(abs(y-x)<=2+TOL, f'balanced bound failed at {x}: {y-x}')
print('PASS 2: explicit finite approximants satisfy |f(t)-t| <= 2')

# 3. Each source interval is a genuine below-zero excursion, with positive gaps.
for n in range(2,N+1):
    a,b,m,ell,alpha=seq(n)
    check(abs(f(a))<1e-9 and abs(f(b))<1e-9,'source excursion endpoints not at level 0')
    check(f(m)<0,'source excursion does not go below level 0')
# sample mid-gaps
for n in range(2,N):
    a,b,_,_,_=seq(n)
    a2,b2,_,_,_=seq(n+1)
    q=0.5*(b2+a)
    check(f(q)>0,'gap between source excursions is not positive')
print('PASS 3: level-0 excursion slice has the prescribed tiny components')

# 4. Third-phase translation map Phi(u)=f(u+1)-f(u) straddles c=1 on every pair.
for n in range(2,N+1):
    a,b,m,ell,alpha=seq(n)
    pa=f(a+1.0)-f(a)
    pb=f(b+1.0)-f(b)
    check(abs(pa-(1+alpha))<1e-8,'Phi(a_n) mismatch')
    check(abs(pb-(1-alpha))<1e-8,'Phi(b_n) mismatch')
    check(pb<1<pa,'translation values do not straddle critical threshold')
print('PASS 4: every vanishing excursion contributes across the same third-phase threshold c=1')

# 5. Source flat tail goes to zero geometrically.
def flat_tail(M, top=10000):
    return sum(seq(n)[3] for n in range(M+1, top))
for M in [4,8,12,20]:
    exact=flat_tail(M)
    # geometric ratio 1/16 for ell_n
    ell_next=seq(M+1)[3]
    bound=ell_next/(1-1/16)
    check(exact<=bound*(1+1e-10),'geometric flat-tail bound failed')
check(flat_tail(20)<1e-25,'flat tail did not become tiny')
print('PASS 5: flat norm of the discarded source boundary is bounded by a geometric tail -> 0')

# 6. Nevertheless threshold pushforward degree at c=1 grows one unit per tiny excursion.
for M in [5,10,20,40,60]:
    count=0
    for n in range(2,M+1):
        a,b,_,_,_=seq(n)
        pa=1+1/n; pb=1-1/n
        # correction current -delta_a + delta_b; below c=1 only b contributes.
        count += (1 if pb<1 else 0) - (1 if pa<1 else 0)
    check(count==M-1,'critical threshold count mismatch')
print('PASS 6: persistence truncation fails maximally at the critical image: threshold index grows like N')

# 7. Smooth test phi(z)=z also diverges harmonically under the continuous nonlinear pushforward.
for M in [10,20,40,60]:
    action=sum((1-1/n)-(1+1/n) for n in range(2,M+1))
    harmonic=-2*sum(1/n for n in range(2,M+1))
    check(abs(action-harmonic)<1e-12,'smooth-test action mismatch')
check(abs(sum((1-1/n)-(1+1/n) for n in range(2,61)))>7.0,
      'harmonic divergence too small for audit')
print('PASS 7: even distributional pushforward need not converge under a merely continuous third-phase map')

# 8. Away from the critical image {1}, threshold contributions eventually vanish exactly.
for c in [0.85,0.9,1.1,1.15]:
    nonzero=[]
    for n in range(2,200):
        pa=1+1/n; pb=1-1/n
        v=(1 if pb<c else 0)-(1 if pa<c else 0)
        if v!=0: nonzero.append(n)
    # condition is |c-1| < 1/n; hence only finitely many n.
    check(len(nonzero)<20,'too many off-critical nonzero tail contributions')
    if nonzero:
        check(max(nonzero) <= math.floor(1/abs(c-1))+1,'off-critical stabilization scale wrong')
print('PASS 8: every fixed threshold c != 1 stabilizes after finitely many persistence scales')

# 9. Persistence core and critical image in the model are K={0}, Phi(K)={1}.
for n in [10,20,40,80]:
    a,b,_,ell,_=seq(n)
    check(max(abs(a),abs(b))<2**(-n+1),'component does not converge to core 0')
check(abs(f(1.0)-f(0.0)-1.0)<1e-12,'critical image value Phi(0)=1 failed')
print('PASS 9: the unique vanishing-persistence core point maps to the unique bad threshold')

# 10. Abstract single-current stabilization lemma on a toy continuous map.
# I_n cluster at 0; Phi(x)=x.  Any compact target set bounded away from 0 is eventually untouched.
for c in [0.05,0.2,0.7]:
    eps0=abs(c)/4
    for n in range(2,100):
        a,b,_,ell,_=seq(n)
        if ell<eps0 and b<c/2:
            # both endpoint images under identity lie below c, so oriented threshold contribution is zero
            val=(1 if a<c else 0)-(1 if b<c else 0)
            check(val==0,'toy persistence stabilization failed')
print('PASS 10: single-current C0 stabilization away from Phi(K) is exact')

# 11. Pair-current edge-straddling principle used in the pair theorem.
# A nonzero alternating 2x2 threshold contribution forces at least one column or row to straddle c.
bits=[0,1]
for A in bits:
  for B in bits:
    for C in bits:
      for D in bits:
        second=A-B-C+D
        if second!=0:
            rowdiff=(A!=C) or (B!=D)
            coldiff=(A!=B) or (C!=D)
            check(rowdiff and coldiff,'nonzero pair second difference without a threshold-straddling edge')
print('PASS 11: any nonzero pair-current threshold contribution exposes a straddling edge')

# 12. Modulus deterioration is explicit: target oscillation 2/n occurs across ell_n=2^(-4n-4).
for n in [5,10,20,40,60]:
    ell=seq(n)[3]
    osc=2/n
    check(osc>math.sqrt(ell), 'example unexpectedly satisfies a strong Holder-type bound')
print('PASS 12: the counterexample necessarily lives in the rough-modulus branch isolated by v161')

print('\nALL 12 V162 CHECKS PASSED')
