#!/usr/bin/env python3
import math
import random

random.seed(163)

# Helpers -----------------------------------------------------------------

def pl_eval(xs, ys, x):
    if x <= xs[0]:
        i = 0
    elif x >= xs[-1]:
        i = len(xs)-2
    else:
        lo, hi = 0, len(xs)-1
        while hi-lo > 1:
            mid=(lo+hi)//2
            if xs[mid] <= x:
                lo=mid
            else:
                hi=mid
        i=lo
    t=(x-xs[i])/(xs[i+1]-xs[i])
    return ys[i]*(1-t)+ys[i+1]*t

def lipschitz_constant(xs, ys):
    return max(abs((ys[i+1]-ys[i])/(xs[i+1]-xs[i])) for i in range(len(xs)-1))

def psi(f,u,v,s):
    return (f(u), f(v), f(u+v-s)-f(u))

# 1. Random PL profiles: third coordinate cell oscillation ----------------
for trial in range(300):
    xs=[-6+i*0.25 for i in range(49)]
    hs=[random.uniform(-1.5,1.5) for _ in xs]
    ys=[x+h for x,h in zip(xs,hs)]
    L=lipschitz_constant(xs,ys)
    f=lambda x, xs=xs,ys=ys: pl_eval(xs,ys,x)
    r=random.uniform(1e-3,0.09)
    u=random.uniform(-2.0,0.0)
    v=random.uniform(0.5,2.5)
    up=u+random.uniform(-r,r)
    vp=v+random.uniform(-r,r)
    s=random.uniform(-0.5,0.5)
    # Stay in interpolation range.
    if not (-6 <= u+v-s <= 6 and -6 <= up+vp-s <= 6):
        continue
    c=psi(f,u,v,s)[2]
    cp=psi(f,up,vp,s)[2]
    # omega(2r)+omega(r) <= 3 L r for an L-Lipschitz PL function.
    assert abs(c-cp) <= 3*L*r + 1e-10
print("PASS 1: randomized PL third-coordinate oscillation obeys the cellwise modulus/Lipschitz bound")

# 2. Image box volume: sides omega(r), omega(r), <=2 omega(2r) ------------
for _ in range(100):
    omr=random.uniform(0.001,2)
    om2=max(omr,random.uniform(omr,3))
    vol=omr*omr*(om2+omr)
    assert vol <= 2*om2**3 + 1e-14
print("PASS 2: image-cell containing box has volume <= 2 omega(2r)^3")

# 3. Global covering algebra ----------------------------------------------
for _ in range(100):
    Nm=random.randint(1,100)
    Np=random.randint(1,100)
    Lm=random.uniform(0.1,10)
    Lp=random.uniform(0.1,10)
    r=random.uniform(1e-3,0.1)
    om=random.uniform(1e-4,1)
    exact=2*om**3*(Nm*(1+math.ceil(Lp/r))+Np*(1+math.ceil(Lm/r)))
    CJ=2+max(Lm,Lp)
    coarse=2*CJ*om**3*(Nm+Np)/r
    assert exact <= coarse + 1e-9
print("PASS 3: exact critical-image cover is bounded by the covering-pressure form")

# 4. Universal exponent arithmetic ----------------------------------------
# N_K <= C/r => volume scale <= const * omega^3/r^2.
# omega ~ r^gamma decays iff 3 gamma - 2 > 0.
assert abs((2/3)*3-2) < 1e-14
print("PASS 4: worst-case one-dimensional core gives the sharp covering exponent gamma=2/3")

# 5. gamma > 2/3 gives decay ----------------------------------------------
for gamma in [0.67,0.7,0.75,0.9,1.0]:
    vals=[(10.0**(-k))**(3*gamma-2) for k in range(1,8)]
    assert vals[-1] < vals[0]
print("PASS 5: tested Holder exponents gamma>2/3 force the target-volume upper bound to decay")

# 6. gamma <= 2/3 does not force decay ------------------------------------
for gamma in [0.2,0.5,0.6,2/3]:
    vals=[(10.0**(-k))**(3*gamma-2) for k in range(1,8)]
    assert vals[-1] >= vals[0]-1e-12
print("PASS 6: the covering estimate alone does not close exponents gamma<=2/3")

# 7. Dimension tradeoff ----------------------------------------------------
for _ in range(100):
    d=random.uniform(0,1)
    gamma=(d+1)/3 + random.uniform(0.01,0.2)
    assert 3*gamma-d-1 > 0
print("PASS 7: thin-core closure condition is exactly 3 gamma > d+1")

# 8. Saturation entropy exponent ------------------------------------------
for gamma in [0.4,0.5,0.6,2/3]:
    exponent=3*gamma-1
    if exponent>0:
        r1,r2=1e-2,1e-5
        lower1=r1**(-exponent)
        lower2=r2**(-exponent)
        assert lower2>lower1
print("PASS 8: Holder saturation forces core covering growth N_K(r) >= c r^{-(3 gamma-1)}")

# 9. Finite-stage Cantor sumsets ------------------------------------------
def cantor_intervals(n):
    ints=[(0.0,1.0)]
    for _ in range(n):
        nxt=[]
        for a,b in ints:
            L=(b-a)/3
            nxt.append((a,a+L))
            nxt.append((b-L,b))
        ints=nxt
    return ints

def merge_intervals(ints, tol=1e-12):
    ints=sorted(ints)
    out=[]
    for a,b in ints:
        if not out or a > out[-1][1]+tol:
            out.append([a,b])
        else:
            out[-1][1]=max(out[-1][1],b)
    return [(a,b) for a,b in out]

for n in range(1,7):
    C=cantor_intervals(n)
    sums=[(a+c,b+d) for a,b in C for c,d in C]
    M=merge_intervals(sums)
    assert len(M)==1 and abs(M[0][0])<1e-12 and abs(M[0][1]-2)<1e-12
print("PASS 9: every tested finite-stage middle-thirds Cantor thickening has sumset [0,2]")

# 10. Cantor scalar saturation vs 3D parameterized saturation -------------
dC=math.log(2)/math.log(3)
assert 2-dC > 0
print("PASS 10: a Lipschitz map with middle-thirds Cantor core has positive decay exponent 2-d_C despite C+C=[0,2]")

# 11. v162 counterexample is rougher than every positive Holder power -------
for gamma in [0.05,0.1,0.25,0.5,0.75,1.0]:
    ratios=[]
    for n in [4,8,12,16,20,40,80]:
        ell=2**(-4*n-4)
        osc=2/n
        ratios.append(osc/(ell**gamma))
    assert ratios[-1] > 10*ratios[0]
print("PASS 11: the v162 critical-target example violates every tested positive Holder scaling at its tiny excursions")

# 12. Li-Pan arithmetic ----------------------------------------------------
for alpha in [0.5001,0.51,0.6,0.75,1.0]:
    p=1/alpha
    assert p < 2
print("PASS 12: alpha>1/2 implies p=1/alpha<2, matching the Li-Pan Holder corollary")

print("\nALL 12 V163 CHECKS PASSED")
