#!/usr/bin/env python3
"""Structural verifier for halfsquare v164.

These checks audit identities and scaling algebra. They are not proofs of the
underlying topological statements.
"""

from __future__ import annotations
import math
import random
import numpy as np

RNG = random.Random(164)


def pwl_eval(xs, ys, x):
    return float(np.interp(x, xs, ys))


def make_balanced_profile(seed=164):
    rng = np.random.default_rng(seed)
    xs = np.linspace(-8.0, 8.0, 513)
    # bounded continuous residual with several frequencies, then normalize to |h|<=1.7
    phases = rng.uniform(0, 2*np.pi, 5)
    h = (
        0.8*np.sin(1.7*xs + phases[0])
        + 0.45*np.sin(4.3*xs + phases[1])
        + 0.25*np.sin(11.1*xs + phases[2])
        + 0.18*np.sin(23.7*xs + phases[3])
        + 0.12*np.sin(41.0*xs + phases[4])
    )
    h *= 1.7 / max(1e-12, np.max(np.abs(h)))
    ys = xs + h
    return xs, ys


def local_modulus(xs, ys, radius, lo=-6.0, hi=6.0):
    # exact enough on the PWL mesh for audit: check mesh pairs within radius
    mask = (xs >= lo) & (xs <= hi)
    xx = xs[mask]
    yy = ys[mask]
    best = 0.0
    j = 0
    for i in range(len(xx)):
        while j < len(xx) and xx[j] - xx[i] <= radius + 1e-12:
            j += 1
        if j > i:
            vals = yy[i:j]
            best = max(best, float(np.max(vals) - np.min(vals)))
    return best


def check_triad_identity():
    xs, ys = make_balanced_profile()
    f = lambda t: pwl_eval(xs, ys, t)
    max_err = 0.0
    for _ in range(500):
        r = RNG.uniform(0.03, 0.12)
        u0 = RNG.uniform(-3.0, -1.0)
        v0 = RNG.uniform(1.0, 3.0)
        s = RNG.uniform(-0.5, 0.5)
        w0 = u0 + v0 - s
        lam = local_modulus(xs, ys, 2*r)
        if lam <= 1e-12:
            continue
        x = RNG.random()
        y = RNG.random()
        F = (f(u0+r*x)-f(u0))/lam
        G = (f(v0+r*y)-f(v0))/lam
        H = (f(w0+r*(x+y))-f(w0))/lam
        T = np.array([F, G, H-F])
        raw = np.array([
            f(u0+r*x)-f(u0),
            f(v0+r*y)-f(v0),
            (f(u0+r*x+v0+r*y-s)-f(u0+r*x))
            - (f(u0+v0-s)-f(u0)),
        ])/lam
        max_err = max(max_err, float(np.max(np.abs(T-raw))))
    assert max_err < 5e-12, max_err
    return max_err


def check_cell_oscillation():
    xs, ys = make_balanced_profile(165)
    f = lambda t: pwl_eval(xs, ys, t)
    worst_ratio = 0.0
    for _ in range(200):
        r = RNG.uniform(0.03, 0.10)
        u0 = RNG.uniform(-2.5, -0.5)
        v0 = RNG.uniform(0.5, 2.5)
        s = RNG.uniform(-0.4, 0.4)
        lam = local_modulus(xs, ys, 2*r)
        vals1, vals2, vals3 = [], [], []
        for x in np.linspace(0, 1, 9):
            for y in np.linspace(0, 1, 9):
                u = u0+r*x
                v = v0+r*y
                vals1.append(f(u))
                vals2.append(f(v))
                vals3.append(f(u+v-s)-f(u))
        osc1 = max(vals1)-min(vals1)
        osc2 = max(vals2)-min(vals2)
        osc3 = max(vals3)-min(vals3)
        if lam > 0:
            worst_ratio = max(worst_ratio, osc1/lam, osc2/lam, osc3/(2*lam))
    # mesh modulus estimate is approximate; leave a modest audit tolerance
    assert worst_ratio < 1.12, worst_ratio
    return worst_ratio



def check_pressure_floor_algebra():
    # If V <= 2*Cj*P then P >= V/(2*Cj).
    worst = 0.0
    for _ in range(5000):
        Cj = RNG.uniform(1.0, 10.0)
        V = RNG.uniform(1e-4, 5.0)
        p0 = V/(2*Cj)
        P = p0*RNG.uniform(1.0, 20.0)
        assert V <= 2*Cj*P*(1+1e-12)
        worst = max(worst, p0/P)
    return worst


def check_witness_volume_algebra():
    # q >= V/(N*m); after lambda scaling and m <= Cj/r,
    # q/lambda^3 >= V/(Cj*P).
    worst_slack = float("inf")
    for _ in range(5000):
        r = 10**RNG.uniform(-5, -1)
        Cj = RNG.uniform(2.0, 8.0)
        N = RNG.uniform(1.0, 1000.0)
        lam = 10**RNG.uniform(-4, -0.1)
        P = N*lam**3/r
        m = RNG.uniform(1.0, Cj/r)
        V = RNG.uniform(1e-6, 1.0)
        lhs = V/(N*m*lam**3)
        rhs = V/(Cj*P)
        assert lhs + 1e-12 >= rhs
        worst_slack = min(worst_slack, lhs/max(rhs,1e-300))
    return worst_slack

def check_pressure_algebra():
    # Random positive synthetic values satisfying p0 <= P <= Pstar and N(rho)>=N(r)
    p0, pstar = 0.7, 5.5
    worst = 0.0
    for _ in range(10000):
        r = 10**RNG.uniform(-5, -1)
        theta = 10**RNG.uniform(-4, 0)
        rho = r*theta
        Nr = RNG.uniform(1, 1000)
        Nrho = Nr * RNG.uniform(1, 30)
        Pr = RNG.uniform(p0, pstar)
        Prho = RNG.uniform(p0, pstar)
        wr = (Pr*r/Nr)**(1/3)
        wrho = (Prho*rho/Nrho)**(1/3)
        rhs = (pstar/p0)**(1/3) * theta**(1/3)
        ratio = wrho/wr
        worst = max(worst, ratio/rhs)
        assert ratio <= rhs*(1+1e-12)
    return worst


def check_entropy_improvement():
    p0, pstar = 1.0, 7.0
    worst = 0.0
    for d in [0.0, 0.25, 0.5, 0.75, 1.0]:
        cd = 0.4
        for _ in range(1000):
            theta = 10**RNG.uniform(-5, 0)
            # Extremal ratios from the theorem.
            ratio = ((pstar/(p0*cd))*theta**(d+1))**(1/3)
            rhs = (pstar/(p0*cd))**(1/3)*theta**((d+1)/3)
            worst = max(worst, abs(ratio-rhs))
    assert worst < 1e-12
    return worst


def check_critical_line():
    errs = []
    for d in np.linspace(0, 1, 21):
        gamma = (d+1)/3
        exponent = 3*gamma-d-1
        errs.append(abs(exponent))
    m = max(errs)
    assert m < 1e-12
    return m


def check_pressure_spike():
    CK = 3.0
    ratios = []
    for P in [1, 8, 64, 512, 4096]:
        lower = (P/CK)**(1/3)
        ratios.append(lower)
    assert all(ratios[i+1] > ratios[i] for i in range(len(ratios)-1))
    return ratios[-1]


def check_identity_disappears():
    # Saturation lower bound omega(2r)>=c r^(2/3) implies r/omega <= c^-1 r^(1/3).
    c = 0.2
    vals = []
    for k in range(2, 12):
        r = 10**(-k)
        omega_lower = c*r**(2/3)
        vals.append(r/omega_lower)
    assert vals[-1] < vals[0]
    assert vals[-1] < 0.01
    return vals[-1]


def tent(x):
    return 1.0 - abs(2*x-1.0)


def preimages_tent(a, tol=1e-12):
    if a < -tol or a > 1+tol:
        return []
    if abs(a-1) <= tol:
        return [0.5]
    if abs(a) <= tol:
        return [0.0, 1.0]
    return [a/2.0, 1.0-a/2.0]


def check_finite_fiber_formula():
    # F=G=tent, H(t)=sin(pi*t/2). Every sampled regular (a,b) has <=4 third values.
    max_card = 0
    for a in np.linspace(0.05, 0.95, 19):
        for b in np.linspace(0.05, 0.95, 19):
            xs = preimages_tent(float(a))
            ys = preimages_tent(float(b))
            fiber = {round(math.sin(math.pi*(x+y)/2)-a, 12) for x in xs for y in ys}
            max_card = max(max_card, len(fiber))
            assert len(fiber) <= 4
    return max_card


def check_piecewise_linear_voxel_scaling():
    # T built from PWL/tent patches is a finite union of surface pieces. A voxelized
    # occupied-volume proxy should decay as resolution increases.
    def H(t):
        return 0.35*math.sin(2*math.pi*t) + 0.2*t
    fracs = []
    for n in [24, 40, 64, 96]:
        pts = []
        for i in range(n+1):
            x = i/n
            Fx = tent(x)
            for j in range(n+1):
                y = j/n
                Gy = tent(y)
                pts.append((Fx, Gy, H(x+y)-Fx))
        arr = np.array(pts)
        # normalize fixed bounding box to n bins per coordinate
        lo = np.array([0.0, 0.0, -1.4])
        hi = np.array([1.0, 1.0, 1.0])
        q = np.floor((arr-lo)/(hi-lo)*n).astype(int)
        q = np.clip(q, 0, n-1)
        occ = len({tuple(row) for row in q})
        fracs.append(occ/(n**3))
    assert fracs[-1] < fracs[0]*0.6, fracs
    return fracs


def check_li_pan_arithmetic():
    vals = [0.51, 0.55, 0.6, 0.75, 1.0]
    ps = [1/a for a in vals]
    assert all(p < 2 for p in ps)
    return max(ps)


def main():
    checks = []
    checks.append(("exact three-patch identity", check_triad_identity()))
    checks.append(("cell oscillation bound ratio", check_cell_oscillation()))
    checks.append(("pressure floor algebra", check_pressure_floor_algebra()))
    checks.append(("witness normalized-volume algebra", check_witness_volume_algebra()))
    checks.append(("pressure modulus-ratio bound", check_pressure_algebra()))
    checks.append(("local entropy exponent algebra", check_entropy_improvement()))
    checks.append(("critical line residual", check_critical_line()))
    checks.append(("pressure-spike lower roughness", check_pressure_spike()))
    checks.append(("background identity normalized remainder", check_identity_disappears()))
    checks.append(("finite level-fiber cardinality", check_finite_fiber_formula()))
    checks.append(("PWL voxel occupied fractions", check_piecewise_linear_voxel_scaling()))
    checks.append(("Li-Pan p<2 arithmetic max p", check_li_pan_arithmetic()))

    print("v164 structural verifier")
    print("========================")
    for name, value in checks:
        print(f"PASS | {name}: {value}")
    print(f"PASS | {len(checks)} grouped checks")


if __name__ == "__main__":
    main()
