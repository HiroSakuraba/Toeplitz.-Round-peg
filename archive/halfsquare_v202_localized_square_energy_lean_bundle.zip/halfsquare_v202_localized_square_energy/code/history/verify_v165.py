#!/usr/bin/env python3
"""Consistency audit for halfsquare v165.

These checks validate finite-mesh identities, covering logic, and exponent
algebra used in the handoff.  They are not proofs of the Toeplitz conjecture.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass

import numpy as np

RNG = random.Random(165)


@dataclass
class PL:
    x: np.ndarray
    y: np.ndarray

    def __call__(self, t: float) -> float:
        return float(np.interp(t, self.x, self.y))

    def roots(self, level: float):
        out = []
        for i in range(len(self.x)-1):
            x0,x1 = self.x[i], self.x[i+1]
            y0,y1 = self.y[i], self.y[i+1]
            if y0 == y1:
                if abs(level-y0) < 1e-12:
                    out.extend([float(x0), float(x1)])
                continue
            lo,hi = sorted((y0,y1))
            if level < lo-1e-12 or level > hi+1e-12:
                continue
            t = (level-y0)/(y1-y0)
            if -1e-12 <= t <= 1+1e-12:
                out.append(float(x0+t*(x1-x0)))
        # dedupe shared knots
        out = sorted(out)
        ded = []
        for z in out:
            if not ded or abs(z-ded[-1]) > 1e-9:
                ded.append(z)
        return ded

    def osc_interval(self, a: float, b: float) -> float:
        pts = [a,b]
        mask = (self.x>a+1e-15) & (self.x<b-1e-15)
        pts += [float(z) for z in self.x[mask]]
        vals = [self(z) for z in pts]
        return max(vals)-min(vals)

    def modulus(self, r: float, samples: int=2500) -> float:
        # dense sampled upper approximation; enough for verifier examples.
        grid = np.linspace(0,1,samples)
        vals = np.interp(grid,self.x,self.y)
        step = grid[1]-grid[0]
        k = max(1,int(math.ceil(r/step)))
        best = 0.0
        for lag in range(1,min(k+1,len(grid))):
            best = max(best,float(np.max(np.abs(vals[lag:]-vals[:-lag]))))
        return best


def random_pl(n=41):
    x=np.linspace(0,1,n)
    y=np.cumsum(np.array([RNG.uniform(-1,1) for _ in range(n)]))
    y=(y-y.mean())/(np.std(y)+1e-12)
    return PL(x,y)


def mesh_intervals(r: float):
    pts=[0.0]
    while pts[-1] < 1-1e-14:
        pts.append(min(1.0,pts[-1]+r))
    return list(zip(pts[:-1],pts[1:]))


def image_range(pl:PL, I):
    a,b=I
    pts=[a,b]
    mask=(pl.x>a+1e-15)&(pl.x<b-1e-15)
    pts += [float(z) for z in pl.x[mask]]
    vals=[pl(z) for z in pts]
    return min(vals),max(vals)


def counted_cells(pl:PL, level:float, r:float):
    cells=[]
    for I in mesh_intervals(r):
        lo,hi=image_range(pl,I)
        if lo-1e-12 <= level <= hi+1e-12:
            cells.append(I)
    return cells


def check_mesh_indicatrix_identity():
    for _ in range(6):
        f=random_pl()
        r=RNG.choice([0.05,0.08,0.1,0.125,0.2])
        cells=mesh_intervals(r)
        sumosc=sum(image_range(f,I)[1]-image_range(f,I)[0] for I in cells)
        # integral of count is exactly sum of image interval lengths.
        # Numerically integrate count as an independent check.
        lo=min(f.y)-0.1; hi=max(f.y)+0.1
        levels=np.linspace(lo,hi,1501)
        counts=np.array([len(counted_cells(f,float(a),r)) for a in levels])
        approx=np.trapezoid(counts,levels)
        assert abs(approx-sumosc) < 0.05*max(1.0,sumosc)
    return True


def check_I_upper_bound():
    for _ in range(30):
        f=random_pl()
        r=RNG.choice([0.04,0.05,0.08,0.1,0.2])
        cells=mesh_intervals(r)
        I=sum(image_range(f,C)[1]-image_range(f,C)[0] for C in cells)
        w=max(f.osc_interval(max(0,i/1000-r),i/1000) for i in range(1,1001))
        # safer exact mesh-cell upper modulus surrogate: every cell osc <= global sampled omega(r)
        w=max(w,max(image_range(f,C)[1]-image_range(f,C)[0] for C in cells))
        assert I <= len(cells)*w + 1e-10
        assert len(cells) <= 2/r + 1e-9
    return True


def cell_contains(I,x):
    return I[0]-1e-10 <= x <= I[1]+1e-10


def check_root_coverage():
    for _ in range(25):
        f=random_pl()
        r=RNG.choice([0.05,0.1,0.125])
        level=RNG.uniform(float(np.min(f.y)),float(np.max(f.y)))
        roots=f.roots(level)
        cells=counted_cells(f,level,r)
        for z in roots:
            assert any(cell_contains(I,z) for I in cells)
    return True


def check_sum_coverage():
    for _ in range(20):
        F=random_pl(); G=random_pl()
        r=RNG.choice([0.05,0.1])
        a=RNG.uniform(float(np.min(F.y)),float(np.max(F.y)))
        b=RNG.uniform(float(np.min(G.y)),float(np.max(G.y)))
        rootsF=F.roots(a); rootsG=G.roots(b)
        cellsF=counted_cells(F,a,r); cellsG=counted_cells(G,b,r)
        sumcells=[(I[0]+J[0],I[1]+J[1]) for I in cellsF for J in cellsG]
        for x in rootsF:
            for y in rootsG:
                z=x+y
                assert any(cell_contains(K,z) for K in sumcells)
                assert all((K[1]-K[0]) <= 2*r+1e-10 for K in sumcells)
    return True


def check_exponent_budget():
    # If sum > 2, C*r^(sum-2) -> 0.
    for _ in range(100):
        a,b,c=[RNG.uniform(0.05,1.0) for _ in range(3)]
        if a+b+c <= 2.05:
            continue
        e=a+b+c-2
        vals=[10.0*(10.0**(-k))**e for k in (1,3,6,9)]
        assert vals[-1] < vals[0]
    return True


def check_equality_saturation_algebra():
    # alpha = 2-beta-gamma in the lower modulus formula.
    for _ in range(100):
        b=RNG.uniform(0.1,0.9)
        c=RNG.uniform(0.1,0.9)
        if b+c >= 1.9:
            continue
        a=2-b-c
        assert abs((2-b-c)-a) < 1e-12
        # indicatrix exponent 1-b-c = a-1
        assert abs((1-b-c)-(a-1)) < 1e-12
    return True


def check_critical_arithmetic():
    a=2/3
    assert abs(3*a-2) < 1e-12
    assert abs((1-a)-1/3) < 1e-12
    assert abs((2-a)-4/3) < 1e-12
    return True


def check_hereditary_formula():
    for _ in range(100):
        kappa=10**RNG.uniform(-3,-0.1)
        delta=10**RNG.uniform(-4,-0.31)
        c=(kappa/4)**(1/3)
        q=c*delta**(2/3)
        assert q**3 >= (kappa/4)*delta**2*(1-1e-12)
    return True


def check_pressure_inheritance():
    for _ in range(100):
        d=RNG.uniform(0,1)
        delta=10**RNG.uniform(-4,-0.1)
        cd=RNG.uniform(0.2,1)
        kappa=RNG.uniform(0.01,1)
        nratio=cd*delta**(-d)
        wratio=(kappa/4)**(1/3)*delta**(2/3)
        pratio=nratio*wratio**3/delta
        target=cd*(kappa/4)*delta**(1-d)
        assert abs(pratio-target) <= 1e-10*max(1,target)
    return True


def check_asymmetric_examples():
    # alpha_F=1 forces alpha_G+alpha_H<=1.
    for beta in (0.2,0.4,0.7):
        allowed=1-beta
        assert 1+beta+allowed <= 2+1e-12
        assert 1+beta+(allowed+0.01) > 2
    return True


def check_graph_grid_exponents():
    # I ~ r^-1/3 -> Q ~ I/r ~ r^-4/3.
    for r in (1e-1,1e-2,1e-4):
        I=r**(-1/3)
        Q=I/r
        expected=r**(-4/3)
        assert abs(Q/expected-1) < 1e-12
    return True


def check_pointwise_critical_pair_counts():
    # Critical equality: product lower r^-gamma plus one-side upper r^(beta-1)
    # forces opposite lower r^(alpha-1).
    for _ in range(100):
        a=RNG.uniform(0.1,0.9)
        b=RNG.uniform(0.1,0.9)
        g=2-a-b
        if not (0.05 < g < 1):
            continue
        assert abs(-g-(b-1) - (a-1)) < 1e-12
        assert abs(-g-(a-1) - (b-1)) < 1e-12
    return True


def main():
    checks=[
        ("mesh indicatrix identity",check_mesh_indicatrix_identity),
        ("I_F mesh upper bound",check_I_upper_bound),
        ("exact PL root coverage",check_root_coverage),
        ("pairwise root-sum coverage",check_sum_coverage),
        ("Holder exponent budget",check_exponent_budget),
        ("critical equality saturation algebra",check_equality_saturation_algebra),
        ("2/3-1/3-4/3 arithmetic",check_critical_arithmetic),
        ("hereditary 2/3 lower modulus",check_hereditary_formula),
        ("pressure inheritance algebra",check_pressure_inheritance),
        ("asymmetric regularity examples",check_asymmetric_examples),
        ("critical graph-grid scaling",check_graph_grid_exponents),
        ("simultaneous critical pair-count exponents",check_pointwise_critical_pair_counts),
    ]
    for name,fn in checks:
        fn()
        print(f"PASS  {name}")
    print(f"\nAll {len(checks)} v165 grouped checks passed.")

if __name__=='__main__':
    main()
