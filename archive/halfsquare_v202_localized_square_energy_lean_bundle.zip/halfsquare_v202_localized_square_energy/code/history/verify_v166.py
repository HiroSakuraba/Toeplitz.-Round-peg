#!/usr/bin/env python3
"""Structural verifier for v166.

This checks algebraic exponents, the critical cover scaling, the standard
positive-box-dimension convergent-sequence example, and density-tangent bounds.
It is an audit helper, not a computer proof of the topological theorems.
"""
from __future__ import annotations
import math


def cover_number_sequence(p: float, r: float, nmax: int = 2_000_000) -> int:
    # S_p={0} U {n^-p}.  Count occupied r-bins up to a large cutoff; the tail
    # below r is in O(1) bins.
    seen = set()
    n = 1
    while n <= nmax:
        x = n ** (-p)
        seen.add(int(x / r))
        if x < r and n > 100:
            break
        n += 1
    seen.add(0)
    return len(seen)


def smith_volterra_intervals(stage: int):
    # Construct remaining intervals after removing middle intervals of length
    # 1/4, 1/16 (two copies), 1/64 (four copies), ... . Total removed = 1/2.
    intervals = [(0.0, 1.0)]
    for k in range(1, stage + 1):
        rem = 4.0 ** (-k)
        new = []
        for a, b in intervals:
            mid = (a + b) / 2
            left_end = mid - rem / 2
            right_start = mid + rem / 2
            new.append((a, left_end))
            new.append((right_start, b))
        intervals = new
    return intervals


def length_intersection(intervals, a, b):
    total = 0.0
    for x, y in intervals:
        total += max(0.0, min(y, b) - max(x, a))
    return total


def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"FAIL {name}: {detail}")
    print(f"PASS {name}: {detail}")


def main():
    # 1. Critical-line identity.
    for d in [0.0, 0.2, 0.5, 0.8, 1.0]:
        alpha = (d + 1.0) / 3.0
        check("critical_line", abs((3*alpha - 1) - d) < 1e-12,
              f"d={d:.2f}, alpha={alpha:.6f}")

    # 2. Full fixed point.
    alpha = 2/3
    d = 3*alpha - 1
    check("two_thirds_gives_d1", abs(d-1) < 1e-12, f"d={d}")

    # 3. Cell volume exponent: m~1/r and image-cell volume~r^(3a),
    # total per K-cover interval scales r^(3a-1)=r^d.
    for alpha in [1/3, 0.4, 0.5, 2/3]:
        d = 3*alpha - 1
        r = 1e-5
        lhs = (1/r) * r**(3*alpha)
        rhs = r**d
        check("cover_exponent", abs(lhs/rhs - 1) < 1e-10,
              f"alpha={alpha:.6f}, d={d:.6f}")

    # 4. Convergent sequence example S_p has box exponent 1/(p+1).
    # Numerical regression is crude but should be close over dyadic-ish scales.
    p = 2.0
    rs = [2.0**(-k) for k in range(8, 17)]
    vals = [(math.log(1/r), math.log(cover_number_sequence(p, r))) for r in rs]
    mx = sum(x for x,_ in vals)/len(vals)
    my = sum(y for _,y in vals)/len(vals)
    slope = sum((x-mx)*(y-my) for x,y in vals)/sum((x-mx)**2 for x,_ in vals)
    check("sequence_box_dimension", abs(slope - 1/3) < 0.06,
          f"estimated={slope:.4f}, theory=0.3333")

    # 5. Naive symmetric child exponent from product multiplicity would be
    # phi(d)=(d+1)/6; its fixed point is only 1/5, illustrating the ascent stall.
    def phi(d): return (d+1)/6
    check("naive_entropy_fixed_point", abs(phi(0.2)-0.2) < 1e-12,
          "phi(d)=(d+1)/6 stalls at d=1/5")
    check("naive_not_ascent_above_one_fifth", phi(0.6) < 0.6,
          f"phi(0.6)={phi(0.6):.4f}")

    # 6. Smith-Volterra stage lengths converge to 1/2: positive measure with
    # nowhere-dense limiting carrier is consistent with v166 (not contradiction).
    ints = smith_volterra_intervals(10)
    total = sum(b-a for a,b in ints)
    check("fat_nowhere_dense_model", abs(total-0.5) < 2e-3,
          f"stage10 remaining length={total:.6f}")

    # 7. Density blow-up numerical illustration: choose a point in the interior
    # of a retained stage-10 interval.  Finite-stage model has exact density 1
    # below its distance to endpoints.
    a,b = ints[len(ints)//3]
    x = (a+b)/2
    R = (b-a)/4
    mass = length_intersection(ints, x-R, x+R)
    eps = 1 - mass/(2*R)
    check("density_blowup_model", eps < 1e-12,
          f"finite-stage epsilon={eps:.3e}")

    # 8. Density covering inequality N >= measure/rho.
    R = 0.01
    eps = 0.02
    rho = 1e-4
    lower = 2*(1-eps)*R/rho
    check("density_covering_law", lower > 190,
          f"N_rho >= {lower:.1f}")

    # 9. Critical null-source scaling: for alpha=2/3, source carrier cover
    # length sum enters target volume linearly because 3a-1=1.
    alpha = 2/3
    check("critical_lusin_exponent", abs(3*alpha-1-1) < 1e-12,
          "target-volume bound is linear in carrier length")

    # 10. Subcritical example: d=.4 corresponds alpha=.4666..., and the
    # Hausdorff carrier threshold exactly recovers d on the critical line.
    d0 = 0.4
    alpha0 = (d0+1)/3
    check("hausdorff_upgrade_matches_pressure_d",
          abs(3*alpha0-1-d0) < 1e-12,
          f"alpha={alpha0:.6f}, threshold={3*alpha0-1:.6f}")

    print("\nAll v166 structural checks passed.")


if __name__ == "__main__":
    main()
