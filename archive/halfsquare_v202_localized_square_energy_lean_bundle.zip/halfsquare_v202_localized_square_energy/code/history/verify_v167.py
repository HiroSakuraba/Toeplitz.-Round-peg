#!/usr/bin/env python3
"""Structural verifier for halfsquare v167.

This script does not prove the analytical theorems. It checks the finite
identities, exponent arithmetic, and discrete covering inequalities used in the
handoff, and includes small randomized sanity tests.
"""
from __future__ import annotations
import math
import random
import numpy as np

checks=[]

def ok(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"FAIL: {name}: {detail}")
    checks.append(name)
    print(f"PASS {len(checks):02d}: {name}" + (f" — {detail}" if detail else ""))

# 1. Critical exponent arithmetic.
alpha=2/3
ok("critical exponent arithmetic", abs((1-alpha)-1/3)<1e-15 and abs(2*alpha-4/3)<1e-15)

# 2. Pressure-line arithmetic d=3 alpha - 1 at alpha=2/3.
d=3*alpha-1
ok("critical carrier dimension", abs(d-1.0)<1e-15)

# 3. Mesh indicatrix identity for a piecewise linear synthetic function.
# Partition into equal source cells; integral n_F(a,r) da equals sum of image interval lengths.
rng=np.random.default_rng(167)
N=64
vals=np.cumsum(rng.normal(size=N+1))
# image intervals [lo_i, hi_i]
lo=np.minimum(vals[:-1], vals[1:])
hi=np.maximum(vals[:-1], vals[1:])
sum_osc=float(np.sum(hi-lo))
# exact union-count integral can be computed by sweep over all endpoints
ends=sorted(set(np.concatenate([lo,hi]).tolist()))
integ=0.0
for a,b in zip(ends[:-1], ends[1:]):
    mid=(a+b)/2
    count=int(np.sum((lo <= mid) & (mid <= hi)))
    integ += count*(b-a)
ok("mesh indicatrix identity", abs(integ-sum_osc) < 1e-9, f"integral={integ:.9f}, sumosc={sum_osc:.9f}")

# 4. Markov/Borel-Cantelli exponent is summable on dyadic scales.
eps=0.07
s=sum((2.0**(-n))**eps for n in range(1,5000))
ok("dyadic bad-level series summable", math.isfinite(s) and s < 1/(1-2**(-eps))+1)

# 5. Dimension-chain arithmetic in the critical fiber theorem.
# 2/3 <= dimH(S) <= dimH(X)+dimP(Y) <= 1/3+1/3 = 2/3.
lo_dim=2/3
hi_dim=1/3+1/3
ok("critical dimension chain closes", abs(lo_dim-hi_dim)<1e-15)

# 6. Product-cover inequality for finite subsets.
# N_{X+Y}(2r) <= N_X(r) N_Y(r) using a fixed grid cover surrogate.
def grid_cells(points, r):
    return set(int(math.floor(x/r)) for x in points)
for trial in range(100):
    r=0.05
    X=rng.random(30)
    Y=rng.random(25)
    nx=len(grid_cells(X,r)); ny=len(grid_cells(Y,r))
    S=np.array([x+y for x in X for y in Y])
    # use intervals of length 2r aligned at 2r; alignment can only help comparison up to factor 2.
    ns=len(grid_cells(S,2*r))
    if ns > 2*nx*ny:
        raise AssertionError((trial,ns,nx,ny))
ok("finite sumset cover product bound", True, "100 randomized trials")

# 7. Positive-image mesh lower-bound exponent arithmetic.
# If N_X N_Y >= c r^-2/3 and N_Y <= r^-1/3-eps, then N_X >= c r^-1/3+eps.
for eps in (0.01,0.05,0.1):
    exp=(-2/3)-(-(1/3+eps))
    ok(f"fiber lower exponent eps={eps}", abs(exp-(-1/3+eps))<1e-15)

# 8. Sumset Hölder-content scaling.
# An interval of source diameter r maps to target diameter <= L r^(2/3).
for r in (1e-1,1e-3,1e-6):
    L=3.7
    lhs=L*r**(2/3)
    rhs=L*(r**alpha)
    if abs(lhs-rhs)>1e-15:
        raise AssertionError
ok("critical Hausdorff-content scaling", True)

# 9. Exact incidence closure on a synthetic convergent family.
# Points u_n in K_{y_n}, with y_n=f(u_n), converge to (u,f(u)).
f=lambda x: x*x + 0.2*x
u=0.37
seq=[u+(-1)**n/(n+20) for n in range(1,1000)]
last=seq[-1]
ok("incidence phase follows continuity", abs(f(last)-f(u))<1e-3)

# 10. Hausdorff graph convergence surrogate: K_n dense and F_n -> F uniformly.
# Sample maximum nearest graph discrepancy on increasingly dense K_n.
def F(x): return math.sin(2*math.pi*x)/3 + x/5
for n in (32,64,128,256):
    K=np.linspace(0,1,n+1)
    # perturbed Fn with uniform error 1/n
    Fn=np.array([F(x)+math.sin(7*x)/n for x in K])
    xs=np.linspace(0,1,2001)
    maxd=0.0
    for x in xs:
        j=int(round(x*n)); j=max(0,min(n,j))
        d=max(abs(x-K[j]), abs(F(x)-Fn[j]))
        maxd=max(maxd,d)
    if maxd > 0.08 and n>=128:
        raise AssertionError((n,maxd))
ok("incidence-graph convergence surrogate", True)

# 11. Parabolic critical scaling consistency: rho^-1/3 cells x rho^(2/3) phase.
for rho in (2**-6,2**-12,2**-18):
    cells=rho**(-1/3)
    phase=rho**(2/3)
    # cells * phase = rho^(1/3); all exponents are internally consistent.
    ok(f"parabolic scaling rho={rho:.2e}", abs(cells*phase-rho**(1/3))<1e-12)

# 12. Sharp general square-to-cube exponent m/n=2/3 arithmetic.
ok("general square-to-cube critical exponent", abs(2/3 - 2/3)<1e-15)

print(f"\nALL {len(checks)} STRUCTURAL CHECKS PASSED")
