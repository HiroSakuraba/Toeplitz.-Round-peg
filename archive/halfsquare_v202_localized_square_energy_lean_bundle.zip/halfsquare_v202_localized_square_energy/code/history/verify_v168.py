import math
import random

ALPHA = 2/3


def cantor_points(n):
    pts = [0.0]
    for _ in range(n):
        pts = [x/8 for x in pts] + [7/8 + x/8 for x in pts]
    return sorted(pts)


def cantor_intervals(n):
    ints=[(0.0,1.0)]
    for _ in range(n):
        nxt=[]
        for a,b in ints:
            L=b-a
            nxt.append((a,a+L/8))
            nxt.append((a+7*L/8,b))
        ints=nxt
    return ints


def dist_to_stage_cantor(x,n=9):
    ints=cantor_intervals(n)
    best=1e9
    for a,b in ints:
        if a <= x <= b:
            return 0.0
        best=min(best,abs(x-a),abs(x-b))
    return best


def F_stage(x,n=9):
    return -(dist_to_stage_cantor(x,n)**ALPHA)


def f_stage(x,eps,n=9):
    return eps*x + F_stage(x,n)

checks=[]

def ok(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"FAIL {name}: {detail}")
    checks.append((name, detail))

# 1. Dimension arithmetic
ok("01 critical Cantor dimension", abs(math.log(2)/math.log(8)-1/3)<1e-15)

# 2. Holder power inequality randomized
for _ in range(5000):
    u=random.random(); v=random.random()
    lhs=abs(u**ALPHA-v**ALPHA)
    rhs=abs(u-v)**ALPHA + 1e-14
    if lhs>rhs:
        raise AssertionError((u,v,lhs,rhs))
ok("02 alpha-power Holder inequality", True, "5000 random pairs")

# 3. Distance-profile Holder surrogate on a deep stage
for _ in range(1000):
    x=random.random(); y=random.random()
    lhs=abs(F_stage(x)-F_stage(y))
    rhs=abs(x-y)**ALPHA + 2e-12
    if lhs>rhs:
        raise AssertionError((x,y,lhs,rhs))
ok("03 distance-profile Holder bound", True, "1000 random pairs")

# 4. Gap midpoint beats tilt for small scales
# Parent P=[0,L], c=0 (a symbolic left point), central gap midpoint L/2.
eps=0.2
passed=0
for n in range(1,20):
    L=8**(-n)
    upper=eps*L/2 - (3*L/8)**ALPHA
    if upper < 0:
        passed += 1
ok("04 gap midpoint sublevel inequality", passed>=15, f"negative at {passed}/19 tested scales")

# 5. Width scaling of construction gaps
for n in range(1,12):
    L=8**(-n)
    gap=3*L/4
    if not gap < 8**(-(n-1)):
        raise AssertionError
ok("05 persistence witness widths vanish", True)

# 6. f_eps restricted to C is injective (finite stage endpoints)
eps=1e-3
# Use representative left endpoints at stage 7.
intervals=cantor_intervals(7)
reps=sorted(a for a,b in intervals)
vals=[eps*x for x in reps]
ok("06 phase shear injective on Cantor representatives", all(vals[i]<vals[i+1] for i in range(len(vals)-1)), f"{len(vals)} reps")

# 7. Critical covering exponent
for n in range(1,10):
    rho=8**(-n)
    count=2**n
    expected=rho**(-1/3)
    if abs(count/expected-1)>1e-12:
        raise AssertionError((n,count,expected))
ok("07 rho^-1/3 covering arithmetic", True)

# 8. Phase band is o(rho^(2/3)) when epsilon=rho
ratios=[]
for n in range(1,12):
    rho=8**(-n)
    ratios.append(rho/(rho**(2/3)))
ok("08 hidden phase band subcritical", ratios[-1] < 0.02 and all(ratios[i+1]<ratios[i] for i in range(len(ratios)-1)), f"last ratio={ratios[-1]:.3e}")

# 9. Secondary tangent exactly recovers c on C (symbolic finite reps)
eps=3e-7
errs=[]
for c in reps[::max(1,len(reps)//50)]:
    # Exact Cantor points have distance zero in the limiting model.
    sec=(eps*c - 0.0)/eps
    errs.append(abs(sec-c))
ok("09 secondary shear tangent", max(errs, default=0.0)<1e-14, f"max error={max(errs, default=0.0):.1e}")

# 10. Uniform convergence norm is <= epsilon
for eps in [1e-1,1e-3,1e-6]:
    # f_eps-F = eps*x on [0,1]
    okv=max(abs(eps*x) for x in [i/1000 for i in range(1001)])
    if okv > eps*(1+1e-12):
        raise AssertionError
ok("10 uniform convergence bound", True)

# 11. Lattice slab count formula
for _ in range(5000):
    S=10**random.uniform(0,6)
    sigma=10**random.uniform(-8,1)
    h=1/S
    # number of integer lattice slabs intersecting arbitrary interval is <= ceil(sigma/h)+2
    # test explicit random offset
    a=random.uniform(-10,10)
    b=a+sigma
    lo=math.floor(a/h)-2
    hi=math.ceil(b/h)+2
    cnt=sum(1 for k in range(lo,hi+1) if a <= k*h <= b)
    bound=math.ceil(S*sigma)+2
    if cnt>bound:
        raise AssertionError((S,sigma,cnt,bound))
ok("11 lattice slab count", True, "5000 random intervals")

# 12. Three visibility regimes arithmetic examples
examples=[(1e6,1e-9,"sub"),(1e6,3e-6,"bounded"),(1e6,1e-2,"visible")]
xis=[S*s for S,s,_ in examples]
ok("12 visibility trichotomy arithmetic", xis[0]<1e-2 and 1<xis[1]<10 and xis[2]>1e3, f"Xi={xis}")

print("v168 structural verifier")
for name, detail in checks:
    print(f"PASS {name}" + (f" — {detail}" if detail else ""))
print(f"\nALL {len(checks)} STRUCTURAL CHECKS PASSED")
