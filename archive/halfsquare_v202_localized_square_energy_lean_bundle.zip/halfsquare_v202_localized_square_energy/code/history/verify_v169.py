import math
import random
from typing import List, Tuple


def stair(y: float, h: float, c: float, delta: float) -> float:
    # Transition centers are c + k h. Reduce to one center.
    k = math.floor((y - c) / h + 0.5)
    m = c + k * h
    if y < m - delta:
        # plateau from previous transition to this one
        return c + (k - 0.5) * h
    if y <= m + delta:
        return c + (k - 0.5) * h + h * (y - (m - delta)) / (2 * delta)
    return c + (k + 0.5) * h


def circ_residue(y: float, h: float) -> float:
    return y % h


def circular_gaps(residues: List[float], h: float) -> List[Tuple[float, float, float]]:
    if not residues:
        return [(0.0, h, h)]
    r = sorted(set(x % h for x in residues))
    gaps = []
    for i, x in enumerate(r):
        y = r[(i + 1) % len(r)]
        if i + 1 == len(r):
            y += h
        gaps.append((x, y, y - x))
    return gaps


def choose_transition_gap(Y: List[float], h: float):
    gaps = circular_gaps([circ_residue(y, h) for y in Y], h)
    x, y, g = max(gaps, key=lambda t: t[2])
    c = ((x + y) / 2.0) % h
    delta = max(1e-10, g / 5.0)
    return c, delta, g


def dist_to_translate_lattice(v: float, tau: float, h: float) -> float:
    z = (v - tau) / h
    return abs(z - round(z)) * h


def H(vals):
    # vals = f(u0),f(u1),f(u2),f(u3)
    u0,u1,u2,u3 = vals
    return (u1-u0, u2-u0, u3-u0)


def check_staircase_random():
    rng = random.Random(16901)
    for _ in range(300):
        h = 10 ** rng.uniform(-2, 1)
        c = rng.uniform(-h, h)
        delta = rng.uniform(0.02, 0.45) * h
        # equivariance + error
        for _ in range(200):
            y = rng.uniform(-10*h, 10*h)
            p = stair(y, h, c, delta)
            p2 = stair(y+h, h, c, delta)
            assert abs((p2-p)-h) < 2e-10*max(1,h)
            assert abs(p-y) <= h/2 + 2e-10*max(1,h)
        # monotonicity on grid
        xs = [(-4*h)+i*(8*h)/2000 for i in range(2001)]
        ps = [stair(x,h,c,delta) for x in xs]
        assert all(ps[i+1] + 1e-11 >= ps[i] for i in range(len(ps)-1))
    return True


def check_finite_set_snapping():
    rng = random.Random(16902)
    for npts in [1,2,3,7,20,100]:
        for _ in range(80):
            h = rng.uniform(0.2, 3.0)
            Y = [rng.uniform(-5*h,5*h) for _ in range(npts)]
            c,delta,g = choose_transition_gap(Y,h)
            # shrink delta slightly to ensure no selected point is in ramp
            delta = min(delta, 0.49*g)
            tau = c + h/2
            for y in Y:
                p = stair(y,h,c,delta)
                assert dist_to_translate_lattice(p,tau,h) < 2e-9*max(1,h)
                assert abs(p-y) <= h/2 + 2e-9*max(1,h)
    return True


def check_sublattice_one_level():
    rng = random.Random(16903)
    for _ in range(300):
        h = rng.uniform(0.2, 4.0)
        width = rng.uniform(0.01,0.85)*h
        a = rng.uniform(-5*h,5*h)
        Y = [a+rng.random()*width for _ in range(80)]
        c,delta,g = choose_transition_gap(Y,h)
        # Use a narrow ramp inside the largest complement gap.
        delta = g/6
        tau = c+h/2
        snapped = [round((stair(y,h,c,delta)-tau)/h) for y in Y]
        # largest-gap transition cuts outside the minimal occupied arc for width<h;
        # all lifts should land on one absolute plateau value.
        vals = [stair(y,h,c,delta) for y in Y]
        assert max(vals)-min(vals) < 2e-8*max(1,h)
    return True


def check_level_count():
    rng = random.Random(16904)
    for M in [1,2,3,5,10]:
        for _ in range(100):
            h = rng.uniform(0.1,2.0)
            width = rng.uniform(0.01,M)*h
            a = rng.uniform(-3*h,3*h)
            Y = [a+rng.random()*width for _ in range(200)]
            c,delta,g = choose_transition_gap(Y,h)
            tau = c+h/2
            ks = set(round((stair(y,h,c,delta)-tau)/h) for y in Y)
            assert len(ks) <= math.ceil(width/h)+2
    return True


def check_phase_map_bound():
    rng = random.Random(16905)
    for _ in range(5000):
        h = rng.uniform(1e-3,2.0)
        c = rng.uniform(-h,h)
        delta = rng.uniform(0.01,0.49)*h
        vals = [rng.uniform(-20*h,20*h) for _ in range(4)]
        tvals = [stair(v,h,c,delta) for v in vals]
        h0 = H(vals); h1 = H(tvals)
        assert max(abs(a-b) for a,b in zip(h0,h1)) <= h + 2e-10*max(1,h)
    return True


def check_secondary_mesh():
    for Xi in [2,5,10,100,1000]:
        h = 1.0
        sigma = Xi*h
        hs = h/sigma
        assert abs(hs - 1/Xi) < 1e-15
        Delta = 0.73
        n = math.floor(Delta/hs)-1
        assert n >= 0
        if Xi >= 100:
            assert n > 50
    return True


def check_residue_saturation_measure_model():
    # Interval of length h is residue-saturated and has measure exactly h.
    for h in [0.1,0.7,1.0,3.2]:
        Y0,Y1 = 2.3,2.3+h
        measure = Y1-Y0
        assert abs(measure-h) < 1e-12
        # sample residues cover circle at sample resolution
        rs = sorted(((Y0+i*h/10000) % h) for i in range(10001))
        max_gap = max(rs[i+1]-rs[i] for i in range(len(rs)-1))
        assert max_gap < h/1000
    return True


def main():
    checks = [
        ("staircase equivariance/monotonicity/error", check_staircase_random),
        ("finite-set residue-gap snapping", check_finite_set_snapping),
        ("sub-lattice one-level collapse", check_sublattice_one_level),
        ("bounded snapped-level count", check_level_count),
        ("relative phase-map perturbation <= h", check_phase_map_bound),
        ("secondary mesh = 1/Xi", check_secondary_mesh),
        ("residue-saturated interval model", check_residue_saturation_measure_model),
    ]
    for name, fn in checks:
        fn()
        print(f"PASS: {name}")
    print(f"ALL {len(checks)} GROUPED CHECKS PASSED")

if __name__ == '__main__':
    main()
