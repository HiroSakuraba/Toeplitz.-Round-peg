import math
import random


def pl_eval(points, x):
    if x <= points[0][0]:
        return points[0][1]
    if x >= points[-1][0]:
        return points[-1][1]
    lo, hi = 0, len(points)-1
    while hi-lo > 1:
        m=(lo+hi)//2
        if points[m][0] <= x:
            lo=m
        else:
            hi=m
    x0,y0=points[lo]; x1,y1=points[hi]
    t=(x-x0)/(x1-x0)
    return y0+t*(y1-y0)


def check_graph_anti_rectangle():
    # Diagonal has full x/y projections but a singleton vertical fiber.
    xs=[i/100 for i in range(101)]
    graph={(round(x,8),round(x,8)) for x in xs}
    xproj={p[0] for p in graph}; yproj={p[1] for p in graph}
    assert len(xproj)==101 and len(yproj)==101
    # No sampled 2x2 Cartesian rectangle can be contained in the graph.
    for i in [0,20,50,80]:
        for j in [10,30,70,100]:
            if i==j: continue
            x1=xs[i]; x2=xs[j]
            y1=x1; y2=x2
            corners={(round(x1,8),round(y1,8)),(round(x1,8),round(y2,8)),
                     (round(x2,8),round(y1,8)),(round(x2,8),round(y2,8))}
            assert not corners.issubset(graph)
    return True


def check_residue_saturated_range():
    # Compact secondary model q(x)=x: Y=[0,1] is residue-saturated mod 1.
    q=lambda x:x
    vals=[q(i/10000) for i in range(10001)]
    assert abs(max(vals)-min(vals)-1.0)<1e-12
    # Residues sample the full circle to grid resolution.
    residues=sorted(v%1.0 for v in vals[:-1])
    maxgap=max(residues[i+1]-residues[i] for i in range(len(residues)-1))
    wrap=1.0-residues[-1]+residues[0]
    assert max(maxgap,wrap)<2e-4
    return True


def check_midpoint_two_sided_room():
    rng=random.Random(17003)
    for _ in range(500):
        # monotone affine model is enough to audit constants in Lemma 5.1
        a=rng.uniform(-4,4)
        slope=rng.choice([-1,1])*rng.uniform(1.0,5.0)
        q=lambda x:a+slope*x
        xminus=0.0; xplus=1.0; xstar=0.5
        if slope<0:
            # orient by -q
            qq=lambda x:-q(x)
        else:
            qq=q
        assert qq(xstar)-qq(xminus)>=0.5
        assert qq(xplus)-qq(xstar)>=0.5
    return True


def make_arch(d, D):
    a=0.5-d/2
    b=0.5+d/2
    pts=[
        (0.0,0.0),
        (0.40,0.40),
        (a,0.50),
        (0.50,0.50-D),
        (b,0.50),
        (0.60,0.60),
        (1.0,1.0),
    ]
    return pts,a,b


def check_shallow_arch_and_band_signs():
    # Audit the exact endpoint inequalities used in Theorem 8.1.
    for n in range(6,16):
        d=2.0**(-n)
        D=2.0**(-n-3)
        pts,a,b=make_arch(d,D)
        q=lambda x:pl_eval(pts,x)
        z=0.5
        eta=1/16
        alpha=z-eta; beta=z+eta
        assert D<1/32
        assert abs(q(a)-z)<1e-12 and abs(q(b)-z)<1e-12
        assert q(0.40)<alpha-D and q(a)>alpha
        assert q(b)<beta-D and q(0.60)>beta
        # Sample every phase in the two bands: endpoint signs remain opposite.
        for j in range(51):
            y=(alpha-D)+j*D/50
            assert (q(0.40)-y)*(q(a)-y)<0
            y2=(beta-D)+j*D/50
            assert (q(b)-y2)*(q(0.60)-y2)<0
    return True


def check_first_two_product_degree_sign_model():
    # In separated scalar equations, product of two nonzero 1D crossing degrees
    # has magnitude 1. We audit orientations on the PL arch model.
    d=2**-10; D=2**-13
    pts,a,b=make_arch(d,D)
    q=lambda x:pl_eval(pts,x)
    z=.5; eta=1/16
    alpha=z-eta; beta=z+eta
    # left scalar goes negative -> positive, right scalar negative -> positive
    left_sign=(math.copysign(1,q(a)-alpha)-math.copysign(1,q(.40)-alpha))/2
    right_sign=(math.copysign(1,q(.60)-beta)-math.copysign(1,q(b)-beta))/2
    assert abs(left_sign)==1 and abs(right_sign)==1
    assert abs(left_sign*right_sign)==1
    return True


def check_translation_defect_identity():
    rng=random.Random(17006)
    for _ in range(10000):
        # Smooth arbitrary test profile
        A=rng.uniform(-2,2); B=rng.uniform(-1,1); C=rng.uniform(-.4,.4)
        q=lambda x:A*x+B*math.sin(1.7*x)+C*math.cos(.6*x)
        a=rng.uniform(-1,1)
        d=rng.uniform(.001,.5)
        b=a+d
        u=rng.uniform(-2,0); v=rng.uniform(0,2)
        Ca=q(u+v-a)-q(u)
        Cb=q(u+v-b)-q(u)
        x=u+v-b
        defect=q(x+d)-q(x)
        assert abs((Ca-Cb)-defect)<2e-12
    return True


def check_non_equicontinuous_visible_model():
    # q_n=sin(n x) is bounded but loses equicontinuity: O(1) phase change on O(1/n).
    for n in [50,100,200,500,1000]:
        x=0.0
        xp=math.pi/(2*n)
        q=lambda t:math.sin(n*t)
        assert abs(xp-x)<0.04
        assert abs(q(xp)-q(x))>0.99
    return True


def check_uniform_compact_model_graph_recovery():
    # q_n -> q uniformly and dense persistence samples P_n -> I.
    q=lambda x:x
    for n in [20,50,100,250]:
        qn=lambda x,n=n: x + math.sin(2*math.pi*x)/(20*n)
        P=[i/n for i in range(n+1)]
        # every target x is within 1/n of P; phase error is controlled too
        for x in [0.07,0.234,0.5,0.811,0.97]:
            p=min(P,key=lambda t:abs(t-x))
            assert abs(p-x)<=1/n+1e-12
            assert abs(qn(p)-q(x)) <= 1/n + 1/(20*n)+1e-12
    return True


def check_two_copy_architecture_identity():
    rng=random.Random(17009)
    for _ in range(5000):
        s=rng.uniform(-.5,.5)
        x=rng.uniform(0,1); y=rng.uniform(0,1)
        q=lambda t: .7*t + .2*math.sin(2.3*t) - .05*math.cos(.9*t)
        T=(q(x),q(y),q(x+y-s)-q(x))
        F=q(x); G=q(y); H=q(x+y-s)
        T2=(F,G,H-F)
        assert max(abs(a-b) for a,b in zip(T,T2))<1e-14
    return True


def main():
    checks=[
        ("graph anti-rectangle counterexample",check_graph_anti_rectangle),
        ("residue saturation gives one full phase range in compact model",check_residue_saturated_range),
        ("two-sided midpoint phase room",check_midpoint_two_sided_room),
        ("shallow return arch robust band signs",check_shallow_arch_and_band_signs),
        ("first-two separated product degree magnitude",check_first_two_product_degree_sign_model),
        ("return-face translation-defect identity",check_translation_defect_identity),
        ("loss of equicontinuity is lattice-visible",check_non_equicontinuous_visible_model),
        ("compact incidence graph recovery model",check_uniform_compact_model_graph_recovery),
        ("two-copy map has v164 three-patch architecture",check_two_copy_architecture_identity),
    ]
    for name,fn in checks:
        fn(); print(f"PASS: {name}")
    print(f"ALL {len(checks)} GROUPED CHECKS PASSED")

if __name__=='__main__':
    main()
