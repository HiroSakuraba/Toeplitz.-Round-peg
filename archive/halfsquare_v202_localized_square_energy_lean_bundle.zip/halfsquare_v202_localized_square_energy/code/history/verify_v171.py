#!/usr/bin/env python3
"""Structural verifier for v171.

Checks the explicit PL counterexample and the main finite-resolution formulas.
This is not a proof assistant; theorem proofs are in the handoff.
"""
import math
import random


def q(t, d):
    if t <= 0.0:
        return t
    if t <= d/2:
        return -2*t
    if t <= d:
        return 2*t - 2*d
    if t <= d + 0.5:
        return 2*(t-d)
    return t - d + 0.5


def third_phase(s, d):
    y = q(s, d)
    u = y - 1.0
    v = d + (y + 1.0)/2.0
    w = u + v - s
    return q(w, d) - q(u, d), u, v, w


def assert_close(a,b,tol=1e-11):
    assert abs(a-b) <= tol, (a,b)


checks=[]

# 1. continuity at all breakpoints
for d in [0.2,0.1,0.01]:
    pts=[0,d/2,d,d+0.5]
    eps=1e-10
    for x in pts:
        # direct formula is continuous; compare tiny one-sided samples
        assert abs(q(x-eps,d)-q(x+eps,d)) < 1e-7
checks.append('PL continuity')

# 2. balanced bound on a broad numerical interval
for d in [0.2,0.1,0.01,0.001]:
    for k in range(-10000,10001):
        t=-3 + 6*k/10000
        assert abs(q(t,d)-t) <= 0.5000000001
checks.append('balanced |q-t| <= 1/2')

# 3. return arch width/depth
for d in [0.2,0.1,0.01]:
    vals=[q(d*k/2000,d) for k in range(2001)]
    assert_close(q(0,d),0)
    assert_close(q(d,d),0)
    assert max(vals) <= 1e-12
    assert_close(min(vals),-d,1e-9)
checks.append('return arch width/depth d')

# 4. exact first-two increment equations
for d in [0.2,0.1,0.01]:
    for k in range(1001):
        s=d*k/1000
        y=q(s,d)
        u=y-1
        v=d+(y+1)/2
        assert_close(q(s,d)-q(u,d),1)
        assert_close(q(v,d)-q(s,d),1)
        assert_close(q(v,d)-q(u,d),2)
checks.append('first two lattice phases (1,2)')

# 5. third contact remains on left linear piece
for d in [0.2,0.1,0.01]:
    for k in range(1001):
        s=d*k/1000
        c,u,v,w=third_phase(s,d)
        assert w < 0
checks.append('third contact lies in left linear branch')

# 6. exact third-phase formula and range
for d in [0.2,0.1,0.01]:
    vals=[]
    for k in range(2001):
        s=d*k/2000
        y=q(s,d)
        c,_,_,_=third_phase(s,d)
        expected=0.5+0.5*y+d-s
        assert_close(c,expected)
        vals.append(c)
    assert abs(min(vals)-0.5) < 1e-10
    assert abs(max(vals)-(0.5+d)) < 1e-10
checks.append('third phase = [1/2,1/2+d]')

# 7. no third lattice point for d<1/4
for d in [0.24,0.2,0.1,0.01,0.001]:
    for k in range(2001):
        s=d*k/2000
        c,_,_,_=third_phase(s,d)
        assert min(abs(c-m) for m in range(-2,3)) > 0.25 - 1e-10
checks.append('no integer third target')

# 8. endpoint translation defect = d
for d in [0.2,0.1,0.01,0.001]:
    x=-0.5
    assert_close(q(x+d,d)-q(x,d),d)
checks.append('endpoint translation defect Upsilon=d')

# 9. clearance/current-width ratio diverges
ratios=[]
for d in [1e-1,1e-2,1e-3,1e-4]:
    clearance=0.5-d
    ratios.append(clearance/d)
assert all(ratios[i+1] > ratios[i] for i in range(len(ratios)-1))
assert ratios[-1] > 1000
checks.append('lattice clearance / Upsilon -> infinity')

# 10. side-room criterion sign test on random admissible data
random.seed(1)
for _ in range(5000):
    D=random.uniform(1e-4,0.2)
    m1=random.uniform(0.1,1.5)
    m2=random.uniform(D+0.01,1.5)
    Lm=m1+D+random.uniform(0.01,1)
    Lp=m2+random.uniform(0.01,1)
    z=random.uniform(-2,2)
    qL=z-Lm
    qR=z+Lp
    # worst endpoint levels across q(s) in [z-D,z]
    left_low=z-D-m1
    left_high=z-m1
    right_low=z-D+m2
    right_high=z+m2
    assert qL < left_low and z > left_high
    assert z < right_low and qR > right_high
checks.append('side-room criterion endpoint signs')

# 11. compactness bound demonstration with a common Lipschitz modulus
for d in [1e-1,1e-2,1e-3,1e-4]:
    # q_d has global Lipschitz constant <=2 except a slope -2: exactly 2.
    sup=0.0
    for k in range(-1000,1000):
        x=-1+2*k/1000
        sup=max(sup,abs(q(x+d,d)-q(x,d)))
    assert sup <= 2*d + 1e-10
checks.append('equicontinuity implies Upsilon->0')

# 12. current is nonzero at real thresholds but has zero lattice shadow
for d in [0.2,0.1,0.01]:
    # single oriented interval [0.5,0.5+d]
    c=0.5+d/2
    assert 0.5 < c < 0.5+d
    for m in range(-3,4):
        assert not (0.5 < m < 0.5+d)
checks.append('nonzero real-threshold current, zero lattice shadow')

print('v171 verifier: PASS')
for i,c in enumerate(checks,1):
    print(f'{i:02d}. PASS - {c}')
