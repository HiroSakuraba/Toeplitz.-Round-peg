#!/usr/bin/env python3
import math
import numpy as np

checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))

# 1. contact order algebra: u3=u0+u2-u1 is always below u2 if u1>u0.
rng=np.random.default_rng(172)
ok=True
for _ in range(1000):
    u0=rng.uniform(-5,5)
    u1=u0+rng.uniform(0.01,3)
    u2=u1+rng.uniform(0.01,3)
    u3=u0+u2-u1
    ok &= (u0 < u3 < u2)
ck("contact-order correction", ok)

# 2. mixed-difference factorization.
ok=True
for _ in range(1000):
    vals=rng.normal(size=4)
    e0,e1,e2,e3=vals
    R=e0+e3-e1-e2
    d0=e1-e0
    d2=e3-e2
    ok &= abs(R-(d2-d0))<1e-12
ck("R=d(y+2)-d(y) algebra", ok)

# 3. analytic continuous bounded example e=A*tanh(y): R changes sign and zero at -3/2.
for A in (0.2,0.8,1.7):
    def e(y): return A*math.tanh(y)
    def R(y): return e(y)+e(y+3)-e(y+1)-e(y+2)
    ck(f"tanh resonance A={A}", abs(R(-1.5))<1e-12 and R(-3)>0 and R(0)<0)

# 4. 2-periodic inverse defect is identically resonant.
def ep(y): return 0.3*math.sin(math.pi*y)+0.1*math.cos(2*math.pi*y)
def Rp(y): return ep(y)+ep(y+3)-ep(y+1)-ep(y+2)
ys=np.linspace(-5,5,1001)
ck("2-periodic defect gives R identically zero", max(abs(Rp(y)) for y in ys)<1e-11)

# 5. Exact 0132 target from a monotone inverse g=y+A*tanh(y) at y=-1.5.
A=0.4
def g(y): return y+A*math.tanh(y)
y=-1.5
x=[g(y+j) for j in range(4)]
res=x[0]+x[3]-x[1]-x[2]
ck("0132 additive relation at resonance", abs(res)<1e-12 and x[0]<x[1]<x[2]<x[3])

# 6. Long-interval integral identity, numerical check with bounded e=0.7*sin(.37y)+.2*cos(1.3y).
def e2(y): return 0.7*math.sin(0.37*y)+0.2*math.cos(1.3*y)
def d2(y): return e2(y+1)-e2(y)
def RR(y): return d2(y+2)-d2(y)
X=-2.3; L=17.4
N=300000
xx=np.linspace(X,X+L,N+1)
rv=np.array([RR(float(t)) for t in xx])
lhs=np.trapezoid(rv,xx)
xx1=np.linspace(X+L,X+L+2,40001)
xx0=np.linspace(X,X+2,40001)
rhs=np.trapezoid([d2(float(t)) for t in xx1],xx1)-np.trapezoid([d2(float(t)) for t in xx0],xx0)
ck("long-interval boundary identity", abs(lhs-rhs)<2e-6)

# 7. Bound |integral R| <= 8B for same example, B=.9.
ck("8B integral bound", abs(lhs) <= 8*0.9 + 1e-9)

# 8. Finite sign-trap estimate on a synthetic bounded sequence sampled at integers.
# If R>=delta for too many consecutive phase points, p must exceed its allowed range.
B=2.0; delta=0.25
maxK=math.floor(2*B/delta)
# Algebraic range bound: 2 delta K <= 4B.
ck("finite sign-trap algebra", 2*delta*maxK <= 4*B+1e-12 and 2*delta*(maxK+1)>4*B)

# 9. Jump formula algebra for random nonnegative jump sizes.
ok=True
for _ in range(1000):
    J=rng.random(4)
    dR=J[0]+J[3]-J[1]-J[2]
    ok &= abs(dR-(J[0]+J[3]-J[1]-J[2]))<1e-15
    if abs(dR)>=0.4:
        ok &= max(J)>=abs(dR)/4-1e-15
ck("jump formula and carrier lower bound", ok)

# 10. Stronger sign-switch consequence: |Delta R|>=2delta => some J>=delta/2.
ok=True
for _ in range(100000):
    J=rng.random(4)*3
    dR=J[0]+J[3]-J[1]-J[2]
    if abs(dR)>=2*delta:
        ok &= max(J)>=delta/2-1e-12
ck("cleared sign switch forces macroscopic arch", ok)

# 11. Balanced translated arch bound: if |q(t)-t|<=B and q(a)=z then |a-z|<=B,
# translated profile Q(t)=q(a+t)-z obeys |Q(t)-t|<=2B.
ok=True
for _ in range(1000):
    h0=rng.uniform(-B,B)  # a-z = -h(a)
    ht=rng.uniform(-B,B)
    diff=h0+ht  # representative translated residual sign convention; magnitude <=2B
    ok &= abs(diff)<=2*B+1e-12
ck("translated balanced bound <=2B", ok)

# 12. v171 local half-integer cylinder does not contradict global theorem:
# affine tails q=t+c have inverse g=y-c and R=0 exactly.
for c in (-0.5,0.0,0.37):
    def ga(y): return y-c
    def Ra(y): return ga(y)+ga(y+3)-ga(y+1)-ga(y+2)
    ck(f"affine-tail global resonance c={c}", abs(Ra(17.2))<1e-12)

print("v172 verifier")
failed=0
for i,(name,passed) in enumerate(checks,1):
    print(f"{i:02d}. {'PASS' if passed else 'FAIL'} - {name}")
    failed += (not passed)
print(f"\n{len(checks)-failed}/{len(checks)} checks passed")
raise SystemExit(1 if failed else 0)
