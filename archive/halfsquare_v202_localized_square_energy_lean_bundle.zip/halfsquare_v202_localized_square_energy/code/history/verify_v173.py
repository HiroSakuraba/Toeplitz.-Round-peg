#!/usr/bin/env python3
import math
import numpy as np

checks=[]
def ok(name, cond, detail=""):
    checks.append((name,bool(cond),detail))

# 1. Algebra R = L(y+2)-L(y) and P shift identity on a smooth bounded defect.
def g0(y):
    return y + 0.17*math.sin(0.73*y) + 0.06*math.sin(1.91*y)

def L0(y): return g0(y+1)-g0(y)
def R0(y): return g0(y)+g0(y+3)-g0(y+1)-g0(y+2)
def P0(y): return g0(y+2)-g0(y)
ys=np.linspace(-9,9,501)
err1=max(abs(R0(y)-(L0(y+2)-L0(y))) for y in ys)
err2=max(abs((P0(y+2)-P0(y))-(R0(y)+R0(y+1))) for y in ys)
ok("R = L(y+2)-L(y)",err1<1e-12,f"maxerr={err1:.3e}")
ok("P shift identity",err2<1e-12,f"maxerr={err2:.3e}")

# 2. Exact 2-periodic resonant manifold: nonaffine example.
a=0.2
# a*pi < 1, so g increasing.
def gp(y): return y+a*math.sin(math.pi*y)
def Rp(y): return gp(y)+gp(y+3)-gp(y+1)-gp(y+2)
err=max(abs(Rp(y)) for y in ys)
ok("nonaffine 2-periodic defect has R=0",err<1e-12,f"maxerr={err:.3e}")
ok("nonaffine resonant g is increasing",a*math.pi<1)

# 3. Eventual one-sign model e=A exp(-y): R>0 and tends to 0, translated defect -> 0.
A=0.2
def gt(y): return y + A*math.exp(-y)
def Rt(y): return gt(y)+gt(y+3)-gt(y+1)-gt(y+2)
ys_tail=np.linspace(0,12,241)
vals=np.array([Rt(y) for y in ys_tail])
ok("eventual-sign model has R>0",np.all(vals>0),f"min={vals.min():.3e}")
ok("eventual-sign model R decays",vals[-1] < vals[0]*1e-4,f"R0={vals[0]:.3e}, R12={vals[-1]:.3e}")
# translated first-hit displacement e(t+2n) -> 0
for t in [-1.3,0.0,0.7,1.9]:
    seq=[gt(t+2*n)-(t+2*n) for n in range(2,9)]
    ok(f"tail displacement converges at t={t}",abs(seq[-1])<abs(seq[0]))

# 4. Explicit vanishing-plateau first-hit family.
E=np.array([0.0,0.0,0.1,0.2])
P=4

def make_g_eps(eps):
    s=1-eps/2
    def g(y):
        # left-continuous convention: interval n<y<=n+1
        n_floor=math.floor(y)
        if abs(y-n_floor)<1e-12:
            n=n_floor-1
        else:
            n=n_floor
        return n + eps*E[n%P] + s*(y-n)
    return g,s

for eps in [0.2,0.05,0.01]:
    g,s=make_g_eps(eps)
    # jump widths after cells n=0..3
    jumps=[]
    for n in range(4):
        left=n + eps*E[n%P] + s
        right=n+1 + eps*E[(n+1)%P]
        jumps.append(right-left)
    ok(f"all jumps positive eps={eps}",min(jumps)>0,f"jumps={jumps}")
    # sampled exact R values in all cell interiors
    vals=[]
    for n in range(4):
        y=n+0.37
        vals.append(g(y)+g(y+3)-g(y+1)-g(y+2))
    target=eps*np.array([0.1,-0.3,-0.1,0.3])
    err=max(abs(np.array(vals)-target))
    ok(f"staircase R cycle eps={eps}",err<1e-12 and min(abs(np.array(vals)))>0,f"vals={vals}")
    # uniform displacement bound by eps/2 sampled densely
    grid=np.linspace(-4,4,4001)
    sup=max(abs(g(y)-y) for y in grid)
    ok(f"g_eps -> identity bound eps={eps}",sup<=eps/2+1e-10,f"sup={sup:.6g}")

# 5. Compact near-resonance identities on a simple constructed profile.
# Use q(t)=t + small bounded smooth perturbation; invert numerically and verify translated identity.
def q_smooth(t): return t + 0.08*math.sin(t)
# strictly increasing since derivative >= .92
def inv_q(y):
    lo=y-0.2; hi=y+0.2
    for _ in range(80):
        mid=(lo+hi)/2
        if q_smooth(mid)<y: lo=mid
        else: hi=mid
    return (lo+hi)/2

def R_s(y):
    g=inv_q
    return g(y)+g(y+3)-g(y+1)-g(y+2)
def rho_s(y):
    g=inv_q
    w=g(y)+g(y+3)-g(y+1)
    return q_smooth(w)-(y+2)
for y in [-2.1,0.4,3.2]:
    x=inv_q(y+2)
    r=R_s(y)
    Qr=q_smooth(x+r)-(y+2)
    ok(f"translated near-resonance identity y={y}",abs(Qr-rho_s(y))<1e-12)

# 6. Additive 0132 relation algebra in r=0 case.
a0=-2.4; b0=-1.1; d0=b0-a0 # a+d-b=0 -> d=b-a
ok("0132 additive tangent relation",abs(a0+d0-b0)<1e-12 and a0<b0<0<d0)

# 7. Simple-arch branch coalescence IVT toy model.
# At top: left positive, right negative. At bottom they coalesce positive.
# Right branch therefore crosses zero.
theta=np.linspace(0,1,501) # 0=bottom,1=top
S_common=0.4
S_L=S_common + 0.6*theta  # top +1.0
S_R=S_common - 0.9*theta  # top -0.5
ok("simple-arch top signs opposite",S_L[-1]>0>S_R[-1])
ok("simple-arch branches coalesce",abs(S_L[0]-S_R[0])<1e-12)
ok("simple-arch one branch crosses zero",np.min(np.abs(S_R))<2e-3)

# Print
passed=sum(v for _,v,_ in checks)
for i,(name,v,detail) in enumerate(checks,1):
    print(f"{i:02d}. {'PASS' if v else 'FAIL'} - {name}" + (f" [{detail}]" if detail else ""))
print(f"\n{passed}/{len(checks)} checks passed")
if passed != len(checks):
    raise SystemExit(1)
