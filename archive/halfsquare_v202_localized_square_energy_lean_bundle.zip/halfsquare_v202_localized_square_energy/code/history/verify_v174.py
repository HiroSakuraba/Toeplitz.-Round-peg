from __future__ import annotations

import itertools
import math
import random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


def mixed(vals):
    # phase-indexed x0,x1,x2,x3 -> additive x0+x3-x1-x2
    x0,x1,x2,x3 = vals
    return x0+x3-x1-x2


checks=[]

# 1. v173 plateau staircase: the first-hit defect skips zero, but the plateau
# product fills it exactly.
E=[0.0,0.0,0.1,0.2]
eps=0.1

def alevel(n):
    return n + eps*(E[(n-1)%4]-0.5)

def blevel(n):
    return n + eps*E[n%4]

for n in (1,3):
    a=[alevel(n+j) for j in range(4)]
    b=[blevel(n+j) for j in range(4)]
    Rm=mixed(a)
    Rp=mixed(b)
    check(Rm*Rp<0, f"expected sign skip at n={n}")
    t=-Rm/(Rp-Rm)
    x=[(1-t)*a[j]+t*b[j] for j in range(4)]
    check(0<t<1, "interpolation parameter must be interior")
    check(abs(mixed(x))<1e-12, "plateau interpolation failed")
checks.append("v173 plateau staircase sign skips are exactly filled by plateau fibers")

# 2. General monotone interval interpolation algebra.
random.seed(174)
for _ in range(2000):
    # Generate ordered level intervals.
    a=[]; b=[]
    x=-5.0
    for j in range(4):
        x += random.uniform(0.3,1.2)
        aj=x
        bj=aj+random.uniform(0.0,0.5)
        a.append(aj); b.append(bj)
        x=bj
    Rm=mixed(a); Rp=mixed(b)
    if Rm*Rp<0:
        t=-Rm/(Rp-Rm)
        xx=[(1-t)*a[j]+t*b[j] for j in range(4)]
        check(abs(mixed(xx))<1e-11, "interval interpolation algebra")
checks.append("monotone level-fiber interpolation is exact whenever one-sided defects straddle zero")

# 3. Running-record envelope bound on a rough balanced example.
B=0.6
N=20001
lo,hi=-20.0,20.0
step=(hi-lo)/(N-1)
M=-10**9
for i in range(N):
    t=lo+i*step
    q=t+0.4*math.sin(1.7*t)+0.2*math.sin(4.3*t)
    check(abs(q-t)<=B+1e-12, "q bound")
    M=max(M,q)
    check(M>=t-B-1e-9, "record envelope lower bound")
    check(M<=t+B+1e-9, "record envelope upper bound")
checks.append("running-record envelope preserves the balance bound on a rough test profile")

# 4. Excursion-deficit phase formula.
for _ in range(1000):
    y=random.uniform(-3,3)
    d=[random.uniform(0,2) for _ in range(4)]
    q0=y-d[0]
    q1=y+1-d[1]
    q2=y+2-d[2]  # geometric x3
    q3=y+3-d[3]  # geometric x2
    H=(q1-q0,q3-q0,q2-q0)
    Hf=(1+d[0]-d[1],3+d[0]-d[3],2+d[0]-d[2])
    check(max(abs(a-b) for a,b in zip(H,Hf))<1e-12, "deficit phase formula")
    if max(d)-min(d)<1e-12:
        check(H==(1.0,3.0,2.0), "equal deficits must give exact target")
checks.append("excursion deficits reproduce the exact (1,3,2) phase error formula")

# 5. Common-depth slice algebra: any synchronized points automatically have
# consecutive actual phases; additive zero is the only remaining equation.
for _ in range(200):
    y=random.uniform(-2,2); depth=random.uniform(0,1)
    phases=[y+j-depth for j in range(4)]
    check(abs((phases[1]-phases[0])-1)<1e-12, "phase 1")
    check(abs((phases[2]-phases[0])-2)<1e-12, "phase 2")
    check(abs((phases[3]-phases[0])-3)<1e-12, "phase 3")
checks.append("common excursion depth preserves exact consecutive lattice phases")

# 6. Equal-depth simple-tent theorem, randomized.
# Symmetric tents with fixed centers and widths w_j(d)=W_j(1-d/D).
for _ in range(5000):
    D=random.uniform(0.2,3.0)
    W=[random.uniform(0.01,2.0) for _ in range(4)]
    C=random.uniform(-2.0,2.0)
    def vals(d):
        w=[W[j]*(1-d/D) for j in range(4)]
        out=[]
        for sig in itertools.product((-1,1), repeat=4):
            v=C+sum((1,-1,-1,1)[j]*sig[j]*w[j]/2 for j in range(4))
            out.append(v)
        return out
    v0=vals(0.0)
    if min(v0)<=0<=max(v0):
        # At bottom every branch equals C.  If C != 0, a top branch of
        # opposite sign must cross.  For affine branch values it is enough to
        # verify the endpoint sign product.
        if abs(C)<1e-14:
            continue
        desired=min(v0) if C>0 else max(v0)
        check(desired*C<=0, "equal-depth crossing logic")
checks.append("random equal-depth simple tents obey the branch-crossing theorem")

# 7. Unequal-depth explicit model: top convex hull straddles zero while every
# synchronized branch keeps one nonzero sign until the shallowest bottom.
C=-0.6608978677929342
W=[0.15044483216697024,0.78917697133121,0.7413595899383292,0.9137436541638764]
D=[1.0,7.11541438766307,2.2000860417813355,4.200234546952954]
coef=[1,-1,-1,1]

def branch_value(sig,d):
    return C+sum(coef[j]*sig[j]*W[j]*(1-d/D[j])/2 for j in range(4))

v0=[]; v1=[]
for sig in itertools.product((-1,1),repeat=4):
    a=branch_value(sig,0.0); b=branch_value(sig,1.0)
    v0.append(a); v1.append(b)
    check(a*b>0, f"branch crossed zero unexpectedly: {sig}, {a}, {b}")
check(min(v0)<0<max(v0), "top convex hull must straddle zero")
check(min(abs(v) for v in v0+v1)>0.10, "explicit model margin")
checks.append("explicit unequal-depth four-tent model straddles zero but has no branch root before the first bottom")

# 8. Shallowest-bottom survival inequality on explicit model.
w_bottom=[W[j]*(1-1.0/D[j]) if D[j]>1 else 0.0 for j in range(4)]
rhs=0.5*sum(w_bottom)
check(abs(C)<rhs, "survival inequality failed")
checks.append("explicit unequal-depth model satisfies the shallowest-bottom residual-width inequality")

# 9. Generic convex-hull persistence lemma for finitely many continuous affine
# branch functions: if zero is inside at d=0 and no branch hits zero, it stays
# inside through the interval.
for _ in range(2000):
    # Generate affine functions with fixed sign on [0,1], at least one of each.
    fs=[]
    for sign in (-1,1):
        for k in range(3):
            a=sign*random.uniform(.2,2)
            b=sign*random.uniform(.2,2)
            fs.append((a,b))
    for d in (0,.1,.25,.5,.75,.9,1):
        vv=[(1-d)*a+d*b for a,b in fs]
        check(min(vv)<0<max(vv), "convex hull should retain zero")
checks.append("finite-branch convex hull cannot lose zero without a branch zero")

# 10. Deficit spread and lattice clearance comparison.
for _ in range(5000):
    d=[random.uniform(0,5) for _ in range(4)]
    clearance=max(abs(d[j]-d[0]) for j in (1,2,3))
    spread=max(d)-min(d)
    check(clearance<=spread+1e-12, "clearance <= spread")
    check(spread<=2*clearance+1e-12, "spread <= 2 clearance")
checks.append("deficit spread is quantitatively equivalent to sup-norm phase clearance")

print(f"v174 verifier: {len(checks)}/{len(checks)} grouped checks PASS")
for i,c in enumerate(checks,1):
    print(f"{i:02d}. PASS — {c}")
