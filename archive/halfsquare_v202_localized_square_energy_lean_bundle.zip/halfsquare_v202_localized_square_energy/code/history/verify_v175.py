from __future__ import annotations

import itertools
import math
import random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


checks=[]
random.seed(175)

# ---------------------------------------------------------------------------
# 1. Universal equal-level width bound for balanced profiles on a concrete
#    rough family q=t+h, |h|<=B.  We numerically find approximate equal-level
#    pairs and verify they never exceed 2B (with mesh tolerance).
# ---------------------------------------------------------------------------
B=1.0

def qrough(t):
    return t + 0.55*math.sin(1.7*t) + 0.35*math.sin(4.1*t)

xs=[-10+i*0.002 for i in range(10001)]
# qrough has |h|<=.9 < B.
for x in xs[::500]:
    check(abs(qrough(x)-x)<=B+1e-12, "balance bound rough profile")
# analytic implication is b-a = h(a)-h(b), so test random synthetic equal-level
# data by constructing h(a),h(b) in [-B,B] with b-a=h(a)-h(b).
for _ in range(5000):
    ha=random.uniform(-B,B); hb=random.uniform(-B,B)
    width=ha-hb
    if width>=0:
        check(width<=2*B+1e-12, "equal-level width <=2B")
checks.append("balanced equal-level pairs obey the universal 2B width bound")

# ---------------------------------------------------------------------------
# 2. Explicit bottom-relocation co-return arch.
# q points: identity to 0; lower arch top 0 at x=0 and x=1, bottom -0.5 at .4;
# then rises to identity-like tail.  The bottom level -0.5 has previous hit
# p=-0.5 and q>-0.5 on (p,.4).
# ---------------------------------------------------------------------------
pts=[(-2.0,-2.0),(-0.5,-0.5),(0.0,0.0),(0.4,-0.5),(1.0,0.0),(2.0,2.0)]

def plq(x):
    if x<=pts[0][0]:
        return x
    if x>=pts[-1][0]:
        return x
    for (x0,y0),(x1,y1) in zip(pts[:-1],pts[1:]):
        if x0<=x<=x1:
            t=(x-x0)/(x1-x0)
            return y0+t*(y1-y0)
    raise RuntimeError

p=-0.5; m=0.4; a=0.0; D=0.5
check(abs(plq(p)+0.5)<1e-12 and abs(plq(m)+0.5)<1e-12, "relocation equal level")
for k in range(1,100):
    x=p+(m-p)*k/100
    check(plq(x)>-0.5-1e-12, "co-return interior must lie above bottom level")
check(p<a<m, "relocation point lies left of lower-arch top endpoint")
check((m-p)>(m-a), "relocation width dominates left half of lower arch")
checks.append("strict lower bottom produces the predicted upper co-return relocation arch")

# ---------------------------------------------------------------------------
# 3. Inverse-modulus lower bound on relocation width for the PL example.
# Global Lipschitz constant of the listed segments is 2, hence omega(r)=2r.
# r_omega(D)=D/2=.25, while relocation width=.9.
# ---------------------------------------------------------------------------
L=2.0
r_inv=D/L
check(m-p>=r_inv-1e-12, "inverse modulus relocation bound")
checks.append("relocation width exceeds inverse-modulus scale at the shallow depth")

# ---------------------------------------------------------------------------
# 4. Hypercube sign-edge lemma.  Any connected cube with both signs contains
#    an adjacent opposite-sign pair.
# ---------------------------------------------------------------------------
for dim in range(1,7):
    vertices=list(itertools.product((0,1), repeat=dim))
    for _ in range(200):
        signs={v: random.choice((-1,1)) for v in vertices}
        if len(set(signs.values()))<2:
            continue
        found=False
        for v in vertices:
            for j in range(dim):
                w=list(v); w[j]^=1; w=tuple(w)
                if signs[v]*signs[w]<0:
                    found=True; break
            if found: break
        check(found, "opposite signs on connected hypercube require a sign edge")
checks.append("shallowest-bottom branch cube always contains an adjacent sign-changing edge")

# ---------------------------------------------------------------------------
# 5. Deterministic common-jump skip example: a common jump can destroy a
#    straddle without either regulated branch attaining zero.
# ---------------------------------------------------------------------------
# Before d=.4: A=-.5+.2d, B=.5-.2d, so they straddle.
# At .4 both jump by +1.0; after that both remain positive and gap shrinks.
def A_skip(d):
    base=-0.5+0.2*d
    if d>=0.4:
        base+=1.0
    return base

def B_skip(d):
    base=0.5-0.2*d
    if d>=0.4:
        base+=1.0
    return base

check(A_skip(0)<0<B_skip(0), "initial skip example straddle")
check(abs((A_skip(.4+1e-9)-A_skip(.4-1e-9))-1.0)<1e-6, "common jump A")
check(abs((B_skip(.4+1e-9)-B_skip(.4-1e-9))-1.0)<1e-6, "common jump B")
check(A_skip(.4+1e-9)>0 and B_skip(.4+1e-9)>0, "jump skips zero")
checks.append("common relocation jump can genuinely skip a real root")

# ---------------------------------------------------------------------------
# 6. No-jump collapsing-gap example forces arbitrarily small clearance.
# ---------------------------------------------------------------------------
for d in (0.0,.5,.9,.99,.999):
    A=-(1-d); Bv=(1-d)
    check(A<0<Bv, "no-jump example straddles")
check(min(abs(-(1-.9999)),abs(1-.9999))<1e-3, "clearance tends to zero")
checks.append("without a common jump, a collapsing opposite-sign gap forces smaller clearance")

# ---------------------------------------------------------------------------
# 7. Simultaneous common jump decomposition: with at most 3 shared contacts,
#    net jump eta forces one coordinate jump >= eta/3.
# ---------------------------------------------------------------------------
for _ in range(10000):
    jumps=[random.uniform(-3,3) for _ in range(3)]
    coeff=[random.choice((-1,1)) for _ in range(3)]
    total=sum(c*j for c,j in zip(coeff,jumps))
    if abs(total)>1e-12:
        check(max(abs(j) for j in jumps)+1e-12>=abs(total)/3, "eta/3 jump bound")
checks.append("large common additive jump forces a shared contact jump of at least one third its size")

# ---------------------------------------------------------------------------
# 8. Spatial defect to phase defect conversion on a Lipschitz profile.
# q=t+0.1 sin t is L=1.1 Lipschitz.  For arbitrary contacts, predicted fourth
# w=x3-E differs from x3 by exactly E, and phase error <=L|E|.
# ---------------------------------------------------------------------------
def qlip(x):
    return x+0.1*math.sin(x)
Lq=1.1
for _ in range(5000):
    x0=random.uniform(-5,5)
    x1=x0+random.uniform(.5,1.5)
    x2=x1+random.uniform(.5,1.5)
    x3=x2+random.uniform(.5,1.5)
    E=x0+x3-x1-x2
    w=x1+x2-x0
    check(abs((w-x3)+E)<1e-12, "w-x3=-E")
    check(abs(qlip(w)-qlip(x3))<=Lq*abs(E)+1e-12, "phase error controlled by spatial defect")
checks.append("small spatial parallelogram defect gives proportionally small phase defect")

# ---------------------------------------------------------------------------
# 9. Consecutive phase gap under an L-Lipschitz modulus: |dx|>=1/L.
# ---------------------------------------------------------------------------
for _ in range(5000):
    Lr=random.uniform(1,10)
    dx=random.uniform(0,1/Lr)
    # If dx<1/L, Lipschitz variation is <1, so a phase difference of 1 is impossible.
    check(Lr*dx<=1+1e-12, "Lipschitz gap logic")
checks.append("common modulus gives a positive spatial separation for consecutive exact phase levels")

# ---------------------------------------------------------------------------
# 10. Residual width versus remaining depth on symmetric tents.
# For a tent with side slope s, at depth d below top, residual width is
# 2*(D-d)/s and omega(r)=s r, so D-d <= omega(width) trivially (indeed factor 2).
# ---------------------------------------------------------------------------
for _ in range(5000):
    s=random.uniform(.2,5)
    D=random.uniform(.1,4)
    d=random.uniform(0,D)
    w=2*(D-d)/s
    check(D-d<=s*w+1e-12, "remaining depth <= omega(residual width)")
checks.append("residual deeper-arch width controls the remaining phase-depth mismatch")

# ---------------------------------------------------------------------------
# 11. Record-arch depth bound D<=4B from balance and equal-level width<=2B.
# Synthetic extremal algebra check.
# ---------------------------------------------------------------------------
for _ in range(5000):
    width=random.uniform(0,2*B)
    left_half=random.uniform(0,width)
    hdiff=random.uniform(-2*B,2*B)
    Dalg=-left_half+hdiff  # q(a)-q(m)=(a-m)+(h(a)-h(m))
    if Dalg>=0:
        check(Dalg<=4*B+1e-12, "depth <=4B")
checks.append("balanced record arches have depth bounded by 4B")

# ---------------------------------------------------------------------------
# 12. First-hit jump budget algebra: on a phase interval length <=4B,
# g(y2)-g(y1)<=6B for |g-y|<=B.
# ---------------------------------------------------------------------------
for _ in range(5000):
    Lphase=random.uniform(0,4*B)
    e1=random.uniform(-B,B); e2=random.uniform(-B,B)
    delta=Lphase+e2-e1
    if delta>=0:  # monotone-compatible displacement
        check(delta<=6*B+1e-12, "first-hit total variation <=6B")
checks.append("first-hit relocation jumps have finite total budget on a bounded depth window")

# ---------------------------------------------------------------------------
# 13. Half-clearance numerical logic on abstract regulated pairs.
# If no branch comes within eta and no common jump reaches eta, signs cannot
# change.  With terminal gap <2eta this is impossible.
# ---------------------------------------------------------------------------
for _ in range(5000):
    eta=random.uniform(.01,1)
    # Start safely outside eta.
    A=-random.uniform(eta,3*eta)
    Bv=random.uniform(eta,3*eta)
    # Apply a sequence of common jumps each strictly smaller than eta, rejecting
    # any sequence that would create a near-zero value; then signs must remain.
    for _k in range(10):
        jump=random.uniform(-.99*eta,.99*eta)
        A2=A+jump; B2=Bv+jump
        if min(abs(A2),abs(B2))<=eta:
            continue
        check((A<0)==(A2<0), "small common jump cannot flip sign while eta-clear")
        check((Bv>0)==(B2>0), "small common jump cannot flip sign while eta-clear")
        A,Bv=A2,B2
checks.append("eta-clear straddle cannot be destroyed by sub-eta common jumps")

# ---------------------------------------------------------------------------
# 14. Concrete v174 unequal-depth model: verify the v175 sign edge and
#     quantitative gamma*/6, gamma*/2 thresholds at D*=1.
# ---------------------------------------------------------------------------
C=-0.6608978677929342
W=[0.15044483216697024,0.78917697133121,0.7413595899383292,0.9137436541638764]
D4=[1.0,7.11541438766307,2.2000860417813355,4.200234546952954]
coef4=[1,-1,-1,1]
dstar=1.0
ww=[W[j]*(1-dstar/D4[j]) if D4[j]>dstar else 0.0 for j in range(4)]
def vv(sig):
    return C+sum(coef4[j]*sig[j]*ww[j]/2 for j in range(4))
verts={sig:vv(sig) for sig in itertools.product((-1,1),repeat=4)}
gamma=min(abs(v) for v in verts.values())
check(abs(gamma-0.1758615026267012)<1e-12, "v174 gamma star")
found=False
for sig,v in verts.items():
    for j in range(4):
        sig2=list(sig); sig2[j]*=-1; sig2=tuple(sig2)
        if v*verts[sig2]<0:
            found=True
            break
    if found: break
check(found, "v174 model must have adjacent sign edge")
check(gamma/6>0.029 and gamma/2<0.088, "quantitative v175 thresholds")
checks.append("v174 unequal-depth model has the advertised sign edge and quantitative post-bottom thresholds")

print(f"v175 verifier: {len(checks)}/{len(checks)} grouped checks PASS")
for i,c in enumerate(checks,1):
    print(f"{i:02d}. PASS — {c}")
