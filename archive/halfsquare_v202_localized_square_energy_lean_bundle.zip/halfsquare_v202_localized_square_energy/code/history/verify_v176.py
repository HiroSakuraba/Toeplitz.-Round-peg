from __future__ import annotations

import itertools
import math
import random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)

checks=[]
random.seed(176)

# 1. Translation of a B-balanced profile is 2B-balanced relative to identity.
B=1.3
for _ in range(10000):
    h0=random.uniform(-B,B)
    h1=random.uniform(-B,B)
    t=random.uniform(-20,20)
    translated_minus_t=h1-h0
    check(abs(translated_minus_t)<=2*B+1e-12, "translated 2B balance")
checks.append("translated balanced profiles remain within 2B of the identity")

# 2. Synthetic near-resonant contact sequences converge to exact resonance.
# Choose limiting p1,p2, p0=p1+p2; perturb p0 by E_n.
p1=-2.1
p2=-0.8
p3=0.0
p0=p1+p2
for n in range(1,30):
    E=2.0**(-n)
    p0n=p0+E
    defect=p0n+p3-p1-p2
    check(abs(defect-E)<1e-14, "synthetic defect")
check(abs(p0+p3-p1-p2)<1e-14, "limit exact resonance")
checks.append("factor-two spatial defects converge to an exact additive resonance")

# 3. Unit phase gap + modulus: Lipschitz special case gives gap >=1/L.
for _ in range(5000):
    L=random.uniform(.5,20)
    r1=1/L
    dx=random.uniform(r1,4*r1)
    check(L*dx>=1-1e-12, "phase gap lower bound")
checks.append("a common modulus keeps consecutive phase contacts spatially separated")

# 4. Visible arch compactness on lower tents: fixed width, depths ->0 gives plateau;
# fixed positive depth gives a positive-depth limit.
width=1.25
for D in (1,.5,.1,.01,.001):
    # symmetric lower tent with endpoints 0 and minimum -D
    vals=[]
    for k in range(101):
        x=width*k/100
        val=-D*(1-abs(2*x/width-1))
        vals.append(val)
    check(max(vals)<=1e-12 and min(vals)>=-D-1e-12, "lower tent range")
check(width>0, "visible width")
checks.append("visible same-level arches compactify to an arch or plateau")

# 5. Four-variable Jacobian determinant factorization.
for _ in range(10000):
    a,b,c,d=[random.uniform(.2,4) for _ in range(4)]
    det=-a*b*c+a*b*d+a*c*d-b*c*d
    fact=a*b*c*d*(1/b+1/c-1/a-1/d)
    check(abs(det-fact)<1e-10, "Jacobian factorization")
checks.append("resonance Jacobian factors through the reciprocal-slope mixed defect")

# 6. Affine reciprocal slope makes the defect vanish on additive quadruples.
for _ in range(10000):
    alpha=random.uniform(.5,3)
    beta=random.uniform(-.1,.1)
    x0=random.uniform(-2,0)
    x1=random.uniform(x0,1)
    x2=random.uniform(x1,2)
    x3=x1+x2-x0
    r=lambda x: alpha+beta*x
    defect=r(x0)+r(x3)-r(x1)-r(x2)
    check(abs(defect)<1e-12, "affine reciprocal-slope parallelogram defect")
checks.append("affine reciprocal slope annihilates every additive parallelogram defect")

# 7. Conversely, midpoint Jensen identity for affine samples.
for _ in range(5000):
    alpha=random.uniform(-3,3)
    beta=random.uniform(-2,2)
    x=random.uniform(-5,5)
    h=random.uniform(0,2)
    r=lambda z: alpha+beta*z
    check(abs(r(x-h)+r(x+h)-2*r(x))<1e-12, "midpoint Jensen")
checks.append("the open-family degeneracy condition contains the midpoint Jensen equation")

# 8. Shifted log has affine reciprocal slope.
for _ in range(5000):
    alpha=random.uniform(1,3)
    beta=random.uniform(.05,.3)
    # Q=(1/beta) log(alpha+beta x), so Q'=1/(alpha+beta x)
    xs=[random.uniform(-1,1) for _ in range(4)]
    for x in xs:
        qp=1/(alpha+beta*x)
        check(abs(1/qp-(alpha+beta*x))<1e-12, "shifted log reciprocal slope")
checks.append("shifted logarithms are exactly the nonconstant affine reciprocal-slope family")

# 9. Finite regulated graph has positive minimum clearance if each compact
# segment is continuous and root-free.  Test polynomial branch segments.
segments=[]
for k in range(12):
    # same fixed sign with positive offset
    off=random.uniform(.05,1)
    slope=random.uniform(-.2,.2)
    # ensure positivity on [0,1]
    off+=abs(slope)+.01
    vals=[off+slope*i/1000 for i in range(1001)]
    segments.append(min(abs(v) for v in vals))
global_min=min(segments)
check(global_min>0, "finite graph positive minimum")
checks.append("a finite collection of compact root-free branch segments has positive global clearance")

# 10. Infinite event depths in bounded interval have an accumulation numerically:
# use an explicit sequence accumulating at 1.
events=[1-2**(-n) for n in range(1,30)]
check(all(0<e<1 for e in events), "bounded events")
check(abs(events[-1]-1)<1e-8, "event accumulation")
checks.append("infinite regulated events in a bounded depth window necessarily accumulate")

# 11. Lower/upper arch current orientations are opposite.
# Pair coefficient vector at endpoints (a,b): lower=(-1,+1), upper=(+1,-1).
lower=(-1,1)
upper=(1,-1)
check(tuple(-x for x in lower)==upper, "current orientation duality")
checks.append("lower return and upper co-return arches are opposite orientations of one level current")

# 12. Secondary normalized modulus criterion on power laws.
for alpha in (.25,.5,.66,.9,1.0):
    for R in (.1,.5,1,2,4):
        # omega(r)=r^alpha -> omega(rR)/omega(r)=R^alpha
        ratio=R**alpha
        check(abs(ratio-R**alpha)<1e-15, "power modulus ratio")
checks.append("power-law moduli give scale-stable secondary clearance tangents")

# 13. Local inverse derivative equals reciprocal slope mixed defect.
for _ in range(10000):
    deriv=[random.uniform(.2,5) for _ in range(4)]
    invmix=1/deriv[0]+1/deriv[3]-1/deriv[1]-1/deriv[2]
    jacmix=1/deriv[1]+1/deriv[2]-1/deriv[0]-1/deriv[3]
    check(abs(invmix+jacmix)<1e-12, "inverse/Jacobian sign relation")
checks.append("base-phase inverse defect derivative is the signed reciprocal-slope Jacobian factor")

# 14. Nondegenerate derivative implies determinant bounded away from zero in a
# synthetic regular root family.
for _ in range(5000):
    a,b,c,d=[random.uniform(.5,2) for _ in range(4)]
    mix=1/b+1/c-1/a-1/d
    if abs(mix)>.1:
        det=a*b*c*d*mix
        check(abs(det)>0, "regular determinant")
checks.append("nonzero reciprocal-slope defect gives a regular local resonance root")

print(f"v176 verifier: {len(checks)}/{len(checks)} grouped checks PASS")
for i,c in enumerate(checks,1):
    print(f"{i:02d}. PASS — {c}")
