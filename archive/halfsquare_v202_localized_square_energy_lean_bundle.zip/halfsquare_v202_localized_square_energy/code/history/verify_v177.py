from __future__ import annotations

import math
import random


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)


checks=[]
random.seed(177)

# Basic finite-difference helper.
def dd12(f, c):
    return f(c)+f(c+3)-f(c+1)-f(c+2)

# 1. Quartic polynomial realizes a quadratic touching defect exactly.
def p4(c):
    return (11/24)*c*c - .25*c**3 + (1/24)*c**4
for _ in range(5000):
    c=random.uniform(-5,5)
    check(abs(dd12(p4,c)-c*c)<1e-9, "quartic fold finite difference")
checks.append("quartic inverse perturbation has exact defect c^2")

# 2. Quintic polynomial realizes a cubic crossing defect exactly.
def p5(c):
    return -(3/8)*c*c + (11/24)*c**3 - (3/16)*c**4 + (1/40)*c**5
for _ in range(5000):
    c=random.uniform(-3,3)
    check(abs(dd12(p5,c)-c**3)<1e-8, "quintic crossing finite difference")
checks.append("quintic inverse perturbation has exact defect c^3")

# 3. Determinant zero does not imply zero one-dimensional degree:
# c^3 has derivative zero at zero but opposite signs on opposite sides.
eps=1e-3
check((-eps)**3<0<(eps)**3, "cubic sign crossing")
check(abs(3*0.0**2)==0, "cubic derivative zero")
checks.append("zero derivative can coexist with a sign-changing nonzero-degree root")

# 4. Quadratic fold is touching and has zero scalar local degree.
check((-eps)**2>0 and eps**2>0, "quadratic touching")
checks.append("quadratic root is non-sign-changing")

# 5. Explicit root-free fold perturbation S_n=lambda*c^2+mu.
lam=.07
for mu in (1e-1,1e-2,1e-4,1e-7):
    for k in range(-200,201):
        c=k/40
        S=lam*c*c+mu
        check(S>0, "root-free fold")
checks.append("positive vertical perturbations remove the local quadratic resonance")

# 6. Universal fold scaling is exactly 1+t^2 in the model.
for mu in (1e-2,1e-5,1e-8):
    rho=math.sqrt(mu/lam)
    for k in range(-100,101):
        t=k/20
        S=lam*(rho*t)**2+mu
        check(abs(S/mu-(1+t*t))<1e-10, "fold scaling")
checks.append("quadratic clearance blow-up gives the universal tangent 1+t^2")

# 7. Reciprocal-slope derivative scaling gives t.
for mu in (1e-2,1e-5,1e-8):
    rho=math.sqrt(mu/lam)
    denom=2*math.sqrt(lam*mu)
    for k in range(-100,101):
        t=k/20
        deriv=2*lam*rho*t
        check(abs(deriv/denom-t)<1e-10, "fold derivative scaling")
checks.append("fold derivative / reciprocal-slope defect has universal tangent t")

# 8. Local inverse model remains increasing on a relevant compact phase range
# for a sufficiently small perturbation.
lam_small=.01
for mu in (0,1e-4,1e-3):
    def dp4(c):
        return (11/12)*c - .75*c*c + (1/6)*c**3
    # derivative of x_n = c + lam*p4 + mu*c^2/4
    vals=[]
    for k in range(801):
        c=-.5+4*k/800
        xp=1+lam_small*dp4(c)+(mu/2)*c
        vals.append(xp)
    check(min(vals)>0, "local model monotonicity")
checks.append("the explicit fold is realized by a smooth locally increasing inverse")

# 9. Phase-gap derivative algebra and slope synchronization.
for _ in range(5000):
    r1=random.uniform(.2,3)
    r2=random.uniform(.2,3)
    r3=random.uniform(.2,3)
    # impose base degeneracy by r0=r1+r2-r3, retry if nonpositive
    r0=r1+r2-r3
    if r0<=.05:
        continue
    dc=r0+r3-r1-r2
    du=r3-r1
    dv=r3-r2
    check(abs(dc)<1e-12, "base degeneracy")
    if abs(du)<1e-10 and abs(dv)<1e-10:
        check(abs(r0-r3)<1e-10, "slope synchronization")
checks.append("full first-order phase-gap degeneracy synchronizes all four reciprocal slopes")

# 10. If all four reciprocal slopes agree, all three first derivatives vanish.
for _ in range(1000):
    r=random.uniform(.1,10)
    dc=r+r-r-r
    du=r-r
    dv=r-r
    check(dc==0 and du==0 and dv==0, "synchronized slopes")
checks.append("equal reciprocal slopes annihilate base and gap first derivatives")

# 11. 2-periodic inverse displacement gives exact consecutive resonance.
for epsp in (.01,.1,.2):
    def x(c):
        return c+epsp*math.sin(math.pi*c)
    for _ in range(5000):
        c=random.uniform(-20,20)
        check(abs(x(c+2)-x(c)-2)<1e-11, "2-translation")
        check(abs(dd12(x,c))<1e-11, "2-periodic resonance")
checks.append("2-periodic inverse displacement gives exact consecutive resonance for every base phase")

# 12. That resonant family is not affine: second derivative is nonzero.
epsp=.1
for c in (.25,.5,.75):
    xpp=-epsp*math.pi**2*math.sin(math.pi*c)
    check(abs(xpp)>1e-3, "non-affine periodic inverse")
checks.append("base-phase resonance spread is strictly larger than the affine/log family")

# 13. Global sign-rigidity discrete analogue: a nondecreasing two-sided sequence
# with bounded partial sums must be zero.  Test finite windows synthetically.
# Any nonzero constant-sign monotone sample causes partial sums to grow.
for a0 in (.01,.1,1.0):
    seq=[a0+0.001*k for k in range(100)]
    sums=[]
    s=0
    for a in seq:
        s+=a
        sums.append(s)
    check(sums[-1]>100*a0*.9, "positive monotone sums grow")
checks.append("one-signed two-step spacing drift is incompatible with bounded displacement over long ranges")

# 14. Quantitative chain bound N*mu <= 2B in the ideal lower-bound model.
for _ in range(5000):
    B=random.uniform(.5,5)
    mu=random.uniform(.001,.2)
    N=int((2*B)/mu)
    check(N*mu<=2*B+1e-12, "chain bound")
checks.append("root-free one-sign continuation has O(B/mu) lattice-period length")

# 15. v176 determinant factor equals -product(slopes)*S'.
for _ in range(5000):
    slopes=[random.uniform(.2,4) for _ in range(4)]
    a,b,c,d=slopes
    Sprime=1/a+1/d-1/b-1/c
    det=a*b*c*d*(1/b+1/c-1/a-1/d)
    check(abs(det + a*b*c*d*Sprime)<1e-10, "det/Sprime relation")
checks.append("Jacobian determinant is the signed product times the scalar-defect derivative")

# 16. Fine-mesh fold unfolding toy model: A=mu+kappa*c^2+tau*u.
# A nearby sufficiently fine gap point can put the fold minimum below zero.
for mu in (1e-2,1e-3,1e-4):
    kappa=1.3
    tau=.7
    h=mu*1e-2
    target=-2*mu/tau
    u=round(target/h)*h
    A0=mu+tau*u
    check(A0<0, "gap-unfolded fold minimum")
    r=.2
    Ab=mu+kappa*r*r+tau*u
    check(Ab>0, "positive fold boundary")
checks.append("a phase-gap mesh much finer than clearance unfolds a transverse fold to exact roots")

print(f"v177 verifier: {len(checks)}/{len(checks)} grouped checks PASS")
for i,msg in enumerate(checks,1):
    print(f"{i:02d}. PASS — {msg}")
