import math

checks=[]
def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"FAIL {name}: {detail}")
    checks.append((name, detail))

# 1. Exact width/midpoint identity.
M=0.37; W=0.22
Sp=M+W/2; Sm=M-W/2
check("midpoint_identity", abs((Sp+Sm)/2-M)<1e-15 and abs((Sp-Sm)-W)<1e-15)

# 2. Width criterion.
M=0.1; W=0.25
check("width_forces_nonpositive_branch", M-W/2 <= 0)

# 3. Morse capture scaling: model S+- = a +/- gamma sqrt(eta) + b eta.
gamma=1.7; b=0.4
for a in [1e-2,1e-4,1e-6]:
    eta=(2.0*a/gamma)**2
    slow=a-gamma*math.sqrt(eta)+b*eta
    check(f"morse_capture_{a:g}", slow<0, f"eta={eta}, Sminus={slow}")

# 4. Joint tangent convergence.
gamma=1.3; b=0.7
for a in [1e-2,1e-4,1e-6]:
    t=0.8
    eta=a*a*t
    val=(a-gamma*math.sqrt(eta)+b*eta)/a
    target=1-gamma*math.sqrt(t)
    check(f"joint_tangent_{a:g}", abs(val-target) < 2*b*a*t + 1e-12,
          f"val={val}, target={target}")

# 5. Fold event clearance: S = mu + k d^2.
mu=1e-8; k=2.0; theta=3.0
d=theta*math.sqrt(mu)
a=mu+k*d*d
check("fold_scale_event_clearance", abs(a/mu-(1+k*theta*theta))<1e-12)

# 6. Far-in-fold-units but d -> 0: a ~ k d^2.
for d in [1e-2,1e-3,1e-4]:
    mu=d**6 # sqrt(mu)=d^3 << d
    a=mu+k*d*d
    check(f"far_fold_units_{d:g}", abs(a/(k*d*d)-1) < d**2,
          f"ratio={a/(k*d*d)}")

# 7. Opening order law eta ~ a^m.
for m in [0.4,0.5,0.75,1.0,2.0,4.0]:
    a=1e-6
    eta=a**m
    width=eta**(1/m)
    check(f"opening_order_{m}", abs(width-a) < 1e-12)

# 8. Critical threshold m=1/2 via eta_cap/d ~ d^(2m-1).
d=1e-6
for m,expected in [(0.4,">1"),(0.5,"=1"),(0.75,"<1"),(2.0,"<1")]:
    ratio=d**(2*m-1)
    if expected==">1": cond=ratio>1
    elif expected=="=1": cond=abs(ratio-1)<1e-12
    else: cond=ratio<1
    check(f"threshold_{m}", cond, f"ratio={ratio}")

# 9. Morse at fold-scale: capture / rho = mu^(3/2).
for mu in [1e-2,1e-4,1e-8]:
    rho=math.sqrt(mu); cap=mu**2
    check(f"morse_subfold_{mu:g}", cap/rho < math.sqrt(mu), f"ratio={cap/rho}")

# 10. Sharp cusp m=1/3: root depth d^(2/3) exceeds d.
for d in [1e-2,1e-4,1e-8]:
    root_depth=d**(2/3)
    check(f"sharp_cusp_escape_{d:g}", root_depth>d,
          f"root_depth={root_depth}, d={d}")

# 11. Concrete cusp Q*-Q=|x|^(1/3): W=2 eta^3.
for d in [1e-2,1e-3,1e-4]:
    a=d*d
    W_at_center=2*d**3
    check(f"cusp_width_at_fold_center_{d:g}", W_at_center/a < 2.1*d,
          f"W/a={W_at_center/a}")

# 12. Plateau criterion.
for a in [0.1,0.01]:
    W0=2.2*a
    M=a
    check(f"plateau_span_{a:g}", M-W0/2 < 0)

# 13. Event polarity algebra.
sigma=1
xold=-0.2; xcmp=-0.5
Sold=0.3
Scmp=Sold+sigma*(xcmp-xold)
check("favorable_polarity", Scmp < Sold and abs(Scmp-(0.3-0.3))<1e-12)

sigma=-1
xold=-0.2; xcmp=-0.5
Sold=0.3
Scmp=Sold+sigma*(xcmp-xold)
check("unfavorable_polarity", Scmp > Sold)

# 14. Capture exponent for Morse event far in fold units: d^4 << d.
for d in [1e-1,1e-2,1e-3]:
    check(f"morse_d4_capture_{d:g}", d**4 < d**2 < d)

print(f"PASS {len(checks)}/{len(checks)} checks")
for i,(name,detail) in enumerate(checks,1):
    print(f"{i:02d}. {name}: PASS" + (f" -- {detail}" if detail else ""))
