import math

checks=[]
def check(name, cond, detail=""):
    if not cond:
        raise AssertionError(f"FAIL {name}: {detail}")
    checks.append((name, detail))

# 1. Contact order: distinct phase labels cannot collide.
levels=[0,1,2,3]
check("distinct_phase_labels", len(set(levels))==4)

# 2. IVT toy selected branch: unrelated branches do not alter selected S.
def S(t): return 1.0-2.0*t
check("selected_ivt_sign_change", S(0)>0 and S(1)<0 and abs(S(0.5))<1e-15)

# 3. C3 Morse constants.
lam=1.7; M=2.0
r=lam/(2*M)
depth_bound=lam**3/(16*M**2)
check("morse_r_positive", r>0)
check("morse_depth_positive", depth_bound>0)

# 4. Concrete balanced profile q=t+2 sin t at its first local maximum.
q=lambda t: t+2*math.sin(t)
xstar=2*math.pi/3
actual_curv=abs(-2*math.sin(xstar))
check("concrete_curvature_margin", actual_curv>lam, f"|q''|={actual_curv}")
actual_drop=q(xstar)-q(xstar+r)
check("concrete_depth_bound", actual_drop>=depth_bound,
      f"drop={actual_drop}, bound={depth_bound}")

# 5. First same-level return for q=t+2 sin t, found by bisection.
target=q(xstar)
lo=xstar+1e-8
# locate a sign change after the local maximum
prev=lo; fprev=q(prev)-target
hi=None
for k in range(1,20000):
    t=xstar+0.001*k
    ft=q(t)-target
    if fprev<0<=ft:
        hi=t; lo=prev; break
    prev=t; fprev=ft
check("return_bracket_found", hi is not None)
for _ in range(80):
    mid=(lo+hi)/2
    if q(mid)-target>=0: hi=mid
    else: lo=mid
z=(lo+hi)/2
check("return_width_bound", z-xstar>r, f"width={z-xstar}, r={r}")

# 6. Shrinking-arch roughness certificate: M >= lambda/d.
for d in [1e-1,1e-2,1e-3]:
    required=lam/d
    check(f"roughness_certificate_{d:g}", required*d>=lam-1e-15)

# 7. Event count bound in a balanced window.
B=2.0; H=0.01
L=3+H+2*B
# Use a safe separation delta below lambda/M.
delta=lam/(2*M)
Nbound=1+math.ceil(L/delta)
check("finite_event_count", Nbound<100, f"L={L}, delta={delta}, N<={Nbound}")

# 8. High event multiplicity forces q''' growth.
for N in [10,100,1000]:
    lower=2*lam*(N-1)/L
    check(f"event_multiplicity_roughness_{N}", lower>0,
          f"||q'''|| lower bound={lower}")

# 9. v178 Morse capture scale remains microscopic as clearance goes to zero.
for a in [1e-2,1e-4,1e-6]:
    cap=a*a
    check(f"capture_shrinks_{a:g}", cap<a)

# 10. Uniform Morse relocation does NOT shrink with a.
for a in [1e-2,1e-4,1e-8]:
    check(f"relocation_macroscopic_{a:g}", r/a>1)

print(f"PASS {len(checks)}/{len(checks)} checks")
for i,(name,detail) in enumerate(checks,1):
    print(f"{i:02d}. {name}: PASS" + (f" -- {detail}" if detail else ""))
