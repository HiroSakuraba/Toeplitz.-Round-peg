#!/usr/bin/env python3
"""Structural verifier for v180 global audit.

The checks are deliberately elementary and independent of the open conjecture.
They audit algebraic identities, finite polygon models, and scaling examples used
in the v180 handoff / endpoint note.
"""
from __future__ import annotations

import math
import random
from dataclasses import dataclass
from typing import List, Tuple

import sympy as sp

Point = Tuple[float, float]
TOL = 1e-9


def det(a: Point, b: Point) -> float:
    return a[0]*b[1] - a[1]*b[0]


def alpha_integral_polyline(P: List[Point]) -> float:
    # Integral 1/2(x dy - y dx) on straight segments.
    return 0.5 * sum(det(P[i], P[i+1]) for i in range(len(P)-1))


def chord_closed_area(P: List[Point]) -> float:
    return alpha_integral_polyline(P) + 0.5*det(P[-1], P[0])


def v2_vertices_sq(P: List[Point]) -> float:
    """Exact 2-variation squared of a polygonal path, using vertex DP.

    For a piecewise affine path and p=2, interior points of a straight edge are
    unnecessary in an optimizing partition (convexity), so it is enough to
    optimize over vertex subsequences.
    """
    n = len(P)
    dp = [-1e300]*n
    dp[0] = 0.0
    for j in range(1, n):
        best = -1e300
        for i in range(j):
            dx = P[j][0]-P[i][0]
            dy = P[j][1]-P[i][1]
            best = max(best, dp[i] + dx*dx + dy*dy)
        dp[j] = best
    return dp[-1]


def line_crossings_xaxis(P: List[Point]) -> int:
    # Strict interior crossings of y=0, ignoring endpoints and generic no-zero interiors.
    n = 0
    for i in range(len(P)-1):
        y0, y1 = P[i][1], P[i+1][1]
        if y0*y1 < 0:
            n += 1
    return n


def simple_x_monotone_polyline(m: int, amp: float = 0.7) -> List[Point]:
    # Endpoints on x-axis, interior vertices alternate sign; x-monotone => simple.
    P = [(0.0, 0.0)]
    for j in range(1, m+1):
        x = j/(m+1)
        y = amp * (1.0 if j % 2 else -1.0) * (0.75 + 0.25*math.sin(0.7*j))
        P.append((x, y))
    P.append((1.0, 0.0))
    return P


def test(name: str, cond: bool, detail: str = "") -> None:
    if not cond:
        raise AssertionError(f"FAIL: {name}: {detail}")
    print(f"PASS: {name}" + (f" -- {detail}" if detail else ""))


def main() -> None:
    # 1. Symmetric-area/Liouville exact-form identity.
    x, y, dx, dy = sp.symbols('x y dx dy', real=True)
    alpha = sp.Rational(1,2)*(x*dy-y*dx)
    rhs = sp.Rational(1,2)*(x*dy+y*dx) - alpha
    test("Liouville exact-form identity", sp.simplify(rhs-y*dx) == 0)

    # 2. Radial pullback identity gamma^* alpha = 1/2 e^{-2T} F'(T)dT.
    T = sp.symbols('T', real=True)
    F = sp.Function('F')(T)
    X = sp.exp(-T)*sp.cos(F)
    Y = sp.exp(-T)*sp.sin(F)
    radial_alpha = sp.simplify(sp.Rational(1,2)*(X*sp.diff(Y,T)-Y*sp.diff(X,T)))
    target = sp.Rational(1,2)*sp.exp(-2*T)*sp.diff(F,T)
    test("radial area pullback", sp.simplify(radial_alpha-target) == 0)

    # 3. BV smoothing algebra identity at the differential-symbol level.
    Px, Py, Hx, Hy, dPx, dPy, dHx, dHy = sp.symbols(
        'Px Py Hx Hy dPx dPy dHx dHy', real=True)
    # alpha(P+H)-alpha(P)
    lhs = sp.Rational(1,2)*((Px+Hx)*(dPy+dHy)-(Py+Hy)*(dPx+dHx) - (Px*dPy-Py*dPx))
    # Pointwise integrand before integration by parts.
    raw = sp.Rational(1,2)*(Px*dHy-Py*dHx + Hx*dPy-Hy*dPx + Hx*dHy-Hy*dHx)
    test("smoothing expansion algebra", sp.expand(lhs-raw) == 0)

    # 4. Polygonal 2-var area inequality on many simple x-monotone arcs.
    worst_ratio = 0.0
    for m in range(2, 30):
        P = simple_x_monotone_polyline(m)
        area = abs(chord_closed_area(P))
        v2sq = v2_vertices_sq(P)
        ratio = area/(math.pi*v2sq) if v2sq > 0 else 0.0
        worst_ratio = max(worst_ratio, ratio)
        if area > math.pi*v2sq + 1e-10:
            raise AssertionError((m, area, v2sq))
    test("simple-arc area <= pi * 2-var^2", True, f"worst sampled ratio={worst_ratio:.6f}")

    # 5. Random x-monotone simple arcs.
    rng = random.Random(20260908)
    worst_rand = 0.0
    for _ in range(500):
        m = rng.randint(3, 18)
        xs = [0.0] + sorted(rng.random() for _ in range(m)) + [1.0]
        ys = [0.0] + [rng.uniform(-1.2,1.2) for _ in range(m)] + [0.0]
        # perturb exact zero interiors away from zero, preserving x-monotone simplicity
        ys = [ys[0]] + [(yy if abs(yy)>1e-6 else 0.01) for yy in ys[1:-1]] + [ys[-1]]
        P = list(zip(xs,ys))
        area = abs(chord_closed_area(P))
        v2sq = v2_vertices_sq(P)
        worst_rand = max(worst_rand, area/(math.pi*v2sq))
        assert area <= math.pi*v2sq + 1e-9
    test("random simple-arc p=2 audit", True, f"500 samples, worst ratio={worst_rand:.6f}")

    # 6. Chord-crossing estimate |closed area| <= pi(N+1)r^2.
    worst_cross = 0.0
    for m in range(2, 30):
        P = simple_x_monotone_polyline(m, amp=0.5)
        area = abs(chord_closed_area(P))
        N = line_crossings_xaxis(P)
        diameter = max(math.dist(a,b) for a in P for b in P)
        bound = math.pi*(N+1)*diameter*diameter
        worst_cross = max(worst_cross, area/bound)
        assert area <= bound + 1e-9
    test("endpoint-line crossing area bound", True, f"worst sampled ratio={worst_cross:.6f}")

    # 7. No local scalar budget: balanced triangular dents.
    # amplitude a_n=1/n, half-width w_n=1/n^3 gives infinite fold count and
    # harmonic total variation, but summable excursion area.
    for N in [10, 100, 1000, 10000]:
        amps = [1.0/n for n in range(1,N+1)]
        widths = [1.0/(n**3) for n in range(1,N+1)]
        sup_amp = max(amps)
        total_var = 2.0*sum(amps)
        excursion_area = sum(a*w for a,w in zip(amps,widths))  # constant factors irrelevant
        # slope on a triangular side ~ a/w = n^2, exceeds background slope for n>=2
        folds = sum(1 for n in range(2,N+1) if (1.0/n)/(1.0/n**3) > 1.0)
        assert sup_amp <= 1.0+TOL
        assert excursion_area < 1.1
        assert folds == max(0,N-1)
        if N == 10000:
            test("balanced dents: unbounded fold/variation budget", total_var > 15.0,
                 f"N={N}, variation~{total_var:.3f}, excursion area~{excursion_area:.6f}")

    # 8. Primitive-spike normalization: fixed area on shrinking diameter => r^-2 anomaly.
    eps = 0.25
    vals = [eps/(r*r) for r in [0.2,0.1,0.05,0.025]]
    test("primitive anomaly scales like r^-2", all(vals[i+1] > 3.9*vals[i] for i in range(len(vals)-1)),
         f"values={[round(v,2) for v in vals]}")

    # 9. Crossing lower bound implied by area anomaly.
    # If closed area >= eps/2, N >= eps/(2*pi*r^2)-1.
    lower = [eps/(2*math.pi*r*r)-1 for r in [0.1,0.05,0.025]]
    test("area anomaly forces diverging line crossings", lower[0] < lower[1] < lower[2] and lower[2] > 20,
         f"lower bounds={[round(v,1) for v in lower]}")

    # 10. Radial normalized primitive asymptotic on an explicit local profile.
    # F(Tn+delta*t)-F(Tn)=A f(t), alpha increment integral exactly weighted by e^-2T.
    # Numerically verify (2e^{2Tn}/A) DeltaArea -> f(t) as delta -> 0.
    # Choose f(t)=sin(t), F'=A/delta cos((T-Tn)/delta).
    Tn = 3.0
    A = 17.0
    tval = 0.9
    errors = []
    for delta in [0.1,0.05,0.02,0.01,0.005]:
        # integrate in scaled u variable: normalized = integral_0^t exp(-2 delta u) cos(u) du
        # since factor 2e^{2Tn}/A cancels 1/2 A.
        u = sp.symbols('u', real=True)
        expr = sp.integrate(sp.exp(-2*delta*u)*sp.cos(u),(u,0,tval))
        val = float(expr.evalf())
        errors.append(abs(val-math.sin(tval)))
    test("radial profile is primitive blow-up", errors[-1] < errors[0]/10,
         f"errors={[f'{e:.3e}' for e in errors]}")

    # 11. Polygonal interpolation p=2 vertex variation is bounded by any path variation
    # sampled on the same vertex times: finite combinatorial sanity check. Here we insert
    # intermediate detours between vertices; the full sampled path must have >= interpolant V2.
    for _ in range(100):
        verts = [(0.0,0.0)]
        full = [(0.0,0.0)]
        for j in range(1,8):
            nxt = (float(j), rng.uniform(-1,1))
            prev = verts[-1]
            # sampled original detours through a midpoint before hitting nxt
            mid = ((prev[0]+nxt[0])/2, (prev[1]+nxt[1])/2 + rng.uniform(-0.5,0.5))
            full.extend([mid,nxt])
            verts.append(nxt)
        assert v2_vertices_sq(verts) <= v2_vertices_sq(full) + 1e-9
    test("polygon interpolation 2-var sanity", True, "100 detoured sampled paths")

    # 12. Exact-form chord integral formula.
    for _ in range(100):
        p = (rng.uniform(-2,2),rng.uniform(-2,2))
        q = (rng.uniform(-2,2),rng.uniform(-2,2))
        val = alpha_integral_polyline([q,p])
        expected = 0.5*det(q,p)
        assert abs(val-expected) < 1e-12
    test("straight-chord alpha formula", True)

    print("\nSUMMARY: 12/12 grouped checks passed.")


if __name__ == '__main__':
    main()
