#!/usr/bin/env python3
"""Finite structural verifier for v181 endpoint referee audit.

This does not prove the theorem. It checks algebraic identities, the endpoint-line
component telescoping identity on explicit models, and the finite polygon
inequalities used in the revised proof.
"""
from __future__ import annotations

import math
import random
from typing import List, Tuple

Point = Tuple[float, float]


def det(a: Point, b: Point) -> float:
    return a[0]*b[1] - a[1]*b[0]


def alpha_segment(a: Point, b: Point) -> float:
    return 0.5*det(a,b)


def alpha_poly(P: List[Point]) -> float:
    return sum(alpha_segment(P[i],P[i+1]) for i in range(len(P)-1))


def closed_area(P: List[Point]) -> float:
    return alpha_poly(P) + alpha_segment(P[-1],P[0])


def v2sq_vertices(P: List[Point]) -> float:
    # exact for a polygonal path: optimize over vertex subsequences
    n=len(P)
    dp=[-1e300]*n
    dp[0]=0.0
    for j in range(1,n):
        dp[j]=max(dp[i] + (P[j][0]-P[i][0])**2 + (P[j][1]-P[i][1])**2
                  for i in range(j))
    return dp[-1]


def diam(P: List[Point]) -> float:
    return max(math.dist(a,b) for a in P for b in P)


def check(name: str, cond: bool, detail: str=""):
    if not cond:
        raise AssertionError(f"FAIL {name}: {detail}")
    print(f"PASS: {name}" + (f" -- {detail}" if detail else ""))


def rotate_translate(P: List[Point], th: float, tx: float, ty: float) -> List[Point]:
    c,s=math.cos(th),math.sin(th)
    return [(c*x-s*y+tx, s*x+c*y+ty) for x,y in P]


def main():
    rng=random.Random(181_2026)

    # 1 exact-form identity y dx = 1/2 d(xy)-alpha, checked on segment endpoints.
    for _ in range(200):
        a=(rng.uniform(-3,3),rng.uniform(-3,3))
        b=(rng.uniform(-3,3),rng.uniform(-3,3))
        # integral y dx on straight segment = avg(y)*Delta x
        ydx=0.5*(a[1]+b[1])*(b[0]-a[0])
        rhs=0.5*(b[0]*b[1]-a[0]*a[1]) - alpha_segment(a,b)
        assert abs(ydx-rhs)<1e-11
    check("Liouville/symmetric-area exact-form identity", True)

    # 2 endpoint-line decomposition with genuine line subsegments where alpha is nonzero.
    # Endpoint line is y=1; alpha restricted there is -1/2 dx.
    Pline=[(0,1),(1,1),(1.5,2),(2,1),(3,1),(3.5,2.5),(4,1),(6,1)]
    total=closed_area(Pline)
    loop1=closed_area([(1,1),(1.5,2),(2,1)])
    loop2=closed_area([(3,1),(3.5,2.5),(4,1)])
    check("endpoint-line telescoping with line subsegments",
          abs(total-(loop1+loop2))<1e-12,
          f"total={total:.6f}, loops={loop1+loop2:.6f}")

    # 3 theorem 2.1 on the same example.
    check("explicit chord-area <= pi V2^2",
          abs(total) <= math.pi*v2sq_vertices(Pline)+1e-12)

    # 4 random x-monotone simple arcs, then arbitrary rigid motions.
    worst=0.0
    for _ in range(1000):
        m=rng.randint(2,20)
        xs=[0.0]+sorted(rng.random() for _ in range(m))+[1.0]
        ys=[0.0]+[rng.uniform(-2,2) for _ in range(m)]+[0.0]
        Q=list(zip(xs,ys))
        Q=rotate_translate(Q,rng.uniform(-math.pi,math.pi),rng.uniform(-2,2),rng.uniform(-2,2))
        A=abs(closed_area(Q)); V=v2sq_vertices(Q)
        worst=max(worst,A/(math.pi*V) if V else 0.0)
        assert A <= math.pi*V+1e-9
    check("1000 rigid-motion random simple arcs", True, f"worst ratio={worst:.6f}")

    # 5 diameter pairs from disjoint subarcs fit in one partition budget: finite model.
    # Use the two off-line excursions from P.
    D1=diam(Pline[1:4]); D2=diam(Pline[4:7])
    check("sum subarc diameters squared <= V2^2",
          D1*D1+D2*D2 <= v2sq_vertices(Pline)+1e-12,
          f"sumD2={D1*D1+D2*D2:.6f}, V2sq={v2sq_vertices(Pline):.6f}")

    # 6 chord primitive bound formula.
    for _ in range(200):
        a=(rng.uniform(-4,4),rng.uniform(-4,4))
        b=(rng.uniform(-4,4),rng.uniform(-4,4))
        R=max(math.hypot(*a),math.hypot(*b))
        chord=abs(alpha_segment(b,a))
        assert chord <= 0.5*R*math.dist(a,b)+1e-12
    check("straight chord term <= R|p-q|/2", True)

    # 7 interpolation p=2 variation does not increase: detoured sampled paths.
    for _ in range(300):
        verts=[(0.0,0.0)]
        full=[(0.0,0.0)]
        for j in range(1,10):
            nxt=(float(j),rng.uniform(-1,1))
            prev=verts[-1]
            # two detour points before nxt
            p1=((2*prev[0]+nxt[0])/3,(2*prev[1]+nxt[1])/3+rng.uniform(-.7,.7))
            p2=((prev[0]+2*nxt[0])/3,(prev[1]+2*nxt[1])/3+rng.uniform(-.7,.7))
            full.extend([p1,p2,nxt]); verts.append(nxt)
        assert v2sq_vertices(verts)<=v2sq_vertices(full)+1e-9
    check("polygonal interpolation variation sanity", True, "300 detoured paths")

    # 8 primitive stability algebra on random polygonal P,H, numerically compare bound.
    # S=P+H at common vertices. The BV bound applies to piecewise linear paths.
    for _ in range(300):
        n=8
        Pbv=[(rng.uniform(-2,2),rng.uniform(-2,2)) for _ in range(n)]
        H=[(0.0,0.0)]
        for i in range(1,n):
            H.append((H[-1][0]+rng.uniform(-.03,.03),H[-1][1]+rng.uniform(-.03,.03)))
        S=[(Pbv[i][0]+H[i][0],Pbv[i][1]+H[i][1]) for i in range(n)]
        eta=sum(math.dist(H[i],H[i+1]) for i in range(n-1))
        R=max(math.hypot(*p) for p in Pbv)
        # compare all prefix primitives
        for j in range(1,n):
            diff=abs(alpha_poly(S[:j+1])-alpha_poly(Pbv[:j+1]))
            assert diff <= 1.5*R*eta+0.5*eta*eta+1e-9
    check("1-variation primitive stability finite models", True)

    # 9 uniform convergence on one period + increment convergence => lift convergence.
    # synthetic primitives f_n(s)=f(s)+1/n*sin(2pi s), increment L_n=L+1/n.
    L=2.3
    for K in [1,3,10]:
        n=500
        err=0.0
        for k in range(-K,K+1):
            for j in range(101):
                s=j/101
                fn=k*(L+1/n) + (s*s + math.sin(2*math.pi*s)/n)
                f=k*L+s*s
                err=max(err,abs(fn-f))
        assert err <= (K+1)/n+1e-12
    check("one-period convergence lifts locally uniformly", True)

    # 10 area inequality is translation/rotation invariant for closed loop expression.
    base=[(0,0),(.2,.8),(.5,-.5),(.8,.9),(1,0)]
    A0=closed_area(base); V0=v2sq_vertices(base)
    for _ in range(100):
        Q=rotate_translate(base,rng.uniform(-math.pi,math.pi),rng.uniform(-10,10),rng.uniform(-10,10))
        assert abs(closed_area(Q)-A0)<1e-9
        assert abs(v2sq_vertices(Q)-V0)<1e-9
    check("closed-area and V2 rigid-motion invariance", True)

    # 11 stress many endpoint-line crossings.
    for m in [10,30,100,300]:
        Q=[(0.0,1.0)]
        for j in range(1,m+1):
            x=j/(m+1)
            y=1.0 + (0.4 if j%2 else -0.4)
            Q.append((x,y))
        Q.append((1.0,1.0))
        A=abs(closed_area(Q)); V=v2sq_vertices(Q)
        assert A <= math.pi*V+1e-9
    check("high crossing-count simple arcs", True)

    # 12 explicit local estimate architecture: shrinking oscillatory subarcs with summable V2 tails.
    # Tail control sequence sum_{k>=n} 4^{-k} -> 0.
    tails=[]
    for n in range(1,10):
        tails.append(sum(4.0**(-k) for k in range(n,100)))
    check("model local V2 control vanishes", all(tails[i+1]<tails[i] for i in range(len(tails)-1)) and tails[-1]<1e-5)

    # 13 exact area/chord telescoping survives nonzero affine-line primitive under translation.
    for ty in [-3.2,0.7,5.0]:
        Q=[(x,y+ty-1) for x,y in Pline]  # endpoint line y=ty
        T=closed_area(Q)
        L1=closed_area(Q[1:4]); L2=closed_area(Q[4:7])
        assert abs(T-(L1+L2))<1e-10
    check("telescoping independent of line offset", True)

    # 14 v180 false shortcut check: uniform closeness alone does not imply 2-var convergence.
    # Sawtooth amplitude eps, frequency ~eps^-2 has sup norm eps but vertex 2-var O(1).
    vals=[]
    for N in [20,80,320]:
        eps=N**-0.5
        Q=[(j/(2*N), eps*(1 if j%2 else -1)) for j in range(2*N+1)]
        vals.append((eps,v2sq_vertices(Q)))
    check("uniform convergence does not imply 2-var convergence",
          vals[-1][0]<vals[0][0]/3 and vals[-1][1]>0.5,
          f"samples={[(round(e,4),round(v,3)) for e,v in vals]}")

    # 15 theorem only needs primitive subsequence, not full primitive sequence.
    # Logical finite model: bounded equicontinuous sequence alternating two limits has convergent subsequences.
    seq=[1 if n%2 else -1 for n in range(20)]
    even=seq[::2]; odd=seq[1::2]
    check("Arzela-Ascoli subsequence suffices logically", len(set(even))==1 and len(set(odd))==1)

    print("\nSUMMARY: 15/15 grouped checks passed.")

if __name__=='__main__':
    main()
