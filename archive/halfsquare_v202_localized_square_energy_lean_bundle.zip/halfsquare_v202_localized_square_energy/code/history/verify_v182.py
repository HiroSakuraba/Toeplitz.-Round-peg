import math, random
from pathlib import Path


def area_closed(vertices):
    # signed integral of alpha around polygonal arc plus closing chord
    s=0.0
    n=len(vertices)
    for i in range(n):
        x1,y1=vertices[i]
        x2,y2=vertices[(i+1)%n]
        s += x1*y2-y1*x2
    return 0.5*s


def v2_sq(vertices):
    # exact for affine polygonal interpolation: optimal partition may be taken at vertices
    n=len(vertices)
    dp=[-1e300]*n
    dp[0]=0.0
    for j in range(1,n):
        xj,yj=vertices[j]
        best=-1e300
        for i in range(j):
            xi,yi=vertices[i]
            val=dp[i]+(xj-xi)**2+(yj-yi)**2
            if val>best: best=val
        dp[j]=best
    return dp[-1]


def random_x_monotone_arc(N=30, amp=1.0):
    xs=[i/(N-1) for i in range(N)]
    ys=[0.0]
    for i in range(1,N-1):
        # mixture of oscillation and noise; x monotonicity guarantees injectivity
        y=amp*(0.65*math.sin(2*math.pi*(random.randint(1,8))*xs[i]) + 0.35*random.uniform(-1,1))
        ys.append(y)
    ys.append(0.0)
    return list(zip(xs,ys))


def deterministic_weave(N=41, amp=1.0):
    xs=[i/(N-1) for i in range(N)]
    ys=[]
    for i,x in enumerate(xs):
        if i in (0,N-1): ys.append(0.0)
        else: ys.append(amp*((-1)**i)*(0.5+0.5*math.sin(math.pi*x)))
    return list(zip(xs,ys))


def check_area_bound(vertices, tol=1e-10):
    A=abs(area_closed(vertices))
    V=v2_sq(vertices)
    return A <= (math.pi/4)*V + tol, A, V, A/V if V else 0.0


def test_random_area_bound(trials=3000):
    worst=(0,None)
    for _ in range(trials):
        N=random.randint(4,35)
        arc=random_x_monotone_arc(N, amp=10**random.uniform(-1,0.5))
        ok,A,V,r=check_area_bound(arc)
        if not ok:
            raise AssertionError((A,V,r,arc))
        if r>worst[0]: worst=(r,arc)
    return worst[0]


def test_weaves():
    vals=[]
    for N in [5,9,17,33,65,129]:
        arc=deterministic_weave(N)
        ok,A,V,r=check_area_bound(arc)
        assert ok
        vals.append((N,A,V,r))
    return vals


def test_similarity_scaling():
    arc=random_x_monotone_arc(17,0.8)
    A=abs(area_closed(arc)); V=v2_sq(arc)
    for s in [0.01,0.2,2,11.3]:
        ar2=[(s*x,s*y) for x,y in arc]
        A2=abs(area_closed(ar2)); V2=v2_sq(ar2)
        assert abs(A2-s*s*A) < 1e-8*(1+s*s*A)
        assert abs(V2-s*s*V) < 1e-8*(1+s*s*V)


def primitive_alpha(vertices):
    vals=[0.0]
    a=0.0
    for (x1,y1),(x2,y2) in zip(vertices[:-1],vertices[1:]):
        a += 0.5*(x1*y2-y1*x2)
        vals.append(a)
    return vals


def perturb(vertices, eta=1e-5):
    # tiny vertex perturbation, endpoints fixed
    out=[vertices[0]]
    for x,y in vertices[1:-1]:
        out.append((x+eta*random.uniform(-1,1),y+eta*random.uniform(-1,1)))
    out.append(vertices[-1])
    return out


def total_variation_diff(P,S):
    # same vertex parameterization: upper bound on 1-var of affine difference
    H=[(sx-px,sy-py) for (px,py),(sx,sy) in zip(P,S)]
    tv=0.0
    for (x1,y1),(x2,y2) in zip(H[:-1],H[1:]):
        tv += math.hypot(x2-x1,y2-y1)
    return tv, max(math.hypot(x,y) for x,y in H)


def test_primitive_stability(trials=1000):
    worst=0.0
    for _ in range(trials):
        P=random_x_monotone_arc(random.randint(5,25),random.uniform(.1,2))
        S=perturb(P,10**random.uniform(-8,-4))
        AP=primitive_alpha(P); AS=primitive_alpha(S)
        err=max(abs(a-b) for a,b in zip(AP,AS))
        tv,supH=total_variation_diff(P,S)
        R=max(math.hypot(x,y) for x,y in P)
        # v181 lemma bound; supH <= tv because basepoint diff=0
        bd=1.5*R*tv+0.5*tv*tv
        if err>bd+1e-12:
            raise AssertionError((err,bd,tv,R))
        worst=max(worst, err/(bd+1e-300))
    return worst


def main():
    random.seed(182)
    worst=test_random_area_bound()
    weaves=test_weaves()
    test_similarity_scaling()
    prim=test_primitive_stability()
    print('v182 verifier')
    print('PASS random simple x-monotone area bound trials=3000')
    print('worst observed |area|/V2^2 =',worst,'; pi/4 =',math.pi/4)
    print('PASS deterministic many-crossing weaves:')
    for row in weaves: print(' ',row)
    print('PASS similarity scaling of area and V2^2')
    print('PASS primitive stability trials=1000; worst ratio to bound =',prim)
    print('ALL CHECKS PASS')

if __name__=='__main__': main()
