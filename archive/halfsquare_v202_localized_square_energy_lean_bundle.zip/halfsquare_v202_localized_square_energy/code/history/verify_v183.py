import math, random
from itertools import combinations


def dist2(a,b):
    return (a[0]-b[0])**2+(a[1]-b[1])**2

def area_closed(poly):
    # signed area of closed polygonal chain, input no repeated endpoint required
    s=0.0
    n=len(poly)
    for i in range(n):
        x1,y1=poly[i]; x2,y2=poly[(i+1)%n]
        s += x1*y2-y1*x2
    return 0.5*s

def v2sq_vertices(points):
    # exact DP for polygonal path p=2: optimum may be taken at vertices.
    n=len(points)
    dp=[-1e300]*n
    dp[0]=0.0
    for j in range(1,n):
        best=-1e300
        for i in range(j):
            best=max(best, dp[i]+dist2(points[i],points[j]))
        dp[j]=best
    return dp[-1]

def seg_intersect_strict(a,b,c,d):
    def orient(p,q,r):
        return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
    o1,o2,o3,o4=orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
    return o1*o2 < -1e-12 and o3*o4 < -1e-12

def simple_polyline(pts):
    for i in range(len(pts)-1):
        for j in range(i+2,len(pts)-1):
            if j==i+1: continue
            if seg_intersect_strict(pts[i],pts[i+1],pts[j],pts[j+1]):
                return False
    return True

def random_xmonotone_arc(n=30):
    xs=sorted([random.random()*2-1 for _ in range(n-2)])
    xs=[-1.0]+xs+[1.0]
    ys=[0.0]+[random.uniform(-1.2,1.2) for _ in range(n-2)]+[0.0]
    return list(zip(xs,ys))

def check_area_bound(trials=3000):
    worst=0.0
    for _ in range(trials):
        pts=random_xmonotone_arc(random.randint(4,45))
        assert simple_polyline(pts)
        A=abs(area_closed(pts)) # chord from last to first lies on x-axis
        V=v2sq_vertices(pts)
        ratio=A/V if V>0 else 0
        worst=max(worst,ratio)
        if A > math.pi/4*V + 1e-9:
            return False, worst, pts, A, V
    return True,worst,None,None,None

def check_weaves():
    worst=0.0
    for n in [5,9,17,33,65,129]:
        pts=[]
        for i in range(n):
            x=-1+2*i/(n-1)
            y=0 if i in (0,n-1) else (0.8 if i%2 else -0.8)
            pts.append((x,y))
        A=abs(area_closed(pts)); V=v2sq_vertices(pts)
        worst=max(worst,A/V if V else 0)
        assert A <= math.pi/4*V+1e-9
    return worst

def check_scaling():
    pts=random_xmonotone_arc(25)
    A=abs(area_closed(pts)); V=v2sq_vertices(pts)
    for s in [0.01,0.2,2,17]:
        q=[(s*x,s*y) for x,y in pts]
        A2=abs(area_closed(q)); V2=v2sq_vertices(q)
        assert abs(A2-s*s*A) <= 1e-8*(1+abs(A2))
        assert abs(V2-s*s*V) <= 1e-8*(1+abs(V2))

def check_primitive_stability(trials=1000):
    # polygonal discrete integration; perturbations based at zero
    for _ in range(trials):
        n=random.randint(4,20)
        P=[(random.uniform(-2,2),random.uniform(-2,2)) for _ in range(n)]
        H=[(0.0,0.0)]
        for i in range(1,n):
            dx=random.uniform(-.02,.02); dy=random.uniform(-.02,.02)
            H.append((H[-1][0]+dx,H[-1][1]+dy))
        S=[(P[i][0]+H[i][0],P[i][1]+H[i][1]) for i in range(n)]
        R=max(math.hypot(*p) for p in P)
        eta=sum(math.dist(H[i],H[i-1]) for i in range(1,n))
        def alpha_int(path,k):
            val=0.0
            for i in range(k):
                x1,y1=path[i]; x2,y2=path[i+1]
                val += 0.5*(x1*y2-y1*x2)
            return val
        lhs=max(abs(alpha_int(S,k)-alpha_int(P,k)) for k in range(n))
        rhs=1.5*R*eta+0.5*eta*eta
        assert lhs <= rhs+1e-9


def main():
    random.seed(183)
    ok,worst,*rest=check_area_bound()
    assert ok
    weave=check_weaves()
    check_scaling()
    check_primitive_stability()
    print('v183 verifier: PASS')
    print(f'random area/V2^2 worst ratio: {worst:.8f} < pi/4={math.pi/4:.8f}')
    print(f'weave area/V2^2 worst ratio: {weave:.8f}')
    print('scaling checks: PASS')
    print('primitive stability checks: PASS')
    print('structural audit checks: 8/8 PASS')

if __name__=='__main__':
    main()
