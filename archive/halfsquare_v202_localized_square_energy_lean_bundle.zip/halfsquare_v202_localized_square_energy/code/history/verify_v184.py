import math
import random
from pathlib import Path

import numpy as np


def signed_closed_area(points):
    p = np.asarray(points, dtype=float)
    q = np.vstack([p, p[0]])
    return 0.5 * np.sum(q[:-1,0]*q[1:,1] - q[:-1,1]*q[1:,0])


def v2sq_vertices(points):
    """Exact 2-variation^2 over the vertex set via dynamic programming."""
    p = np.asarray(points, dtype=float)
    n = len(p)
    dp = np.full(n, -np.inf)
    dp[0] = 0.0
    for j in range(1, n):
        d = p[j] - p[:j]
        sq = np.einsum('ij,ij->i', d, d)
        dp[j] = np.max(dp[:j] + sq)
    return float(dp[-1])


def diameter(points):
    p = np.asarray(points, dtype=float)
    best = 0.0
    for i in range(len(p)):
        d = p[i+1:] - p[i]
        if len(d):
            best = max(best, float(np.sqrt(np.max(np.einsum('ij,ij->i', d, d)))))
    return best


def polyline_length(points):
    p = np.asarray(points, dtype=float)
    return float(np.linalg.norm(np.diff(p, axis=0), axis=1).sum())


def winding_number(points, z=(0.0, 0.0)):
    p = np.asarray(points, dtype=float) - np.asarray(z, dtype=float)
    q = np.vstack([p, p[0]])
    ang = 0.0
    for a,b in zip(q[:-1], q[1:]):
        cross = a[0]*b[1]-a[1]*b[0]
        dot = a[0]*b[0]+a[1]*b[1]
        ang += math.atan2(cross, dot)
    return int(round(ang/(2*math.pi)))


def spiral(N, pts_per_turn=16):
    # Simple monotone-radius spiral, endpoints on positive x-axis.
    # r0=N^-1/2, r1=r0/2, theta=0..2pi N.
    r0 = N**-0.5
    r1 = 0.5*r0
    m = N*pts_per_turn
    th = np.linspace(0.0, 2*math.pi*N, m+1)
    r = r0 + (r1-r0)*(th/(2*math.pi*N))
    p = np.column_stack([r*np.cos(th), r*np.sin(th)])
    return p


def random_monotone_graph(n=50):
    # x strictly increasing => polygonal graph is simple.
    x = np.linspace(0, 1, n)
    y = [0.0]
    for _ in range(n-2):
        y.append(y[-1] + random.uniform(-0.25, 0.25))
    y.append(random.uniform(-0.1,0.1))
    y = np.asarray(y)
    # random rigid scale/rotation/translation
    pts = np.column_stack([x,y])
    ang = random.uniform(0,2*math.pi)
    R = np.array([[math.cos(ang),-math.sin(ang)],[math.sin(ang),math.cos(ang)]])
    sc = 10**random.uniform(-1.0,1.0)
    tr = np.array([random.uniform(-2,2), random.uniform(-2,2)])
    return sc*(pts@R.T)+tr


def check_area_bound(points, tol=1e-9):
    area = abs(signed_closed_area(points))
    v2 = v2sq_vertices(points)
    return area <= (math.pi/4)*v2 + tol, area, v2


def main():
    random.seed(184)
    np.random.seed(184)
    out=[]
    out.append('v184 verifier')
    out.append('============')

    # 1. Random simple graph arcs.
    worst_ratio=0.0
    for _ in range(1000):
        pts=random_monotone_graph(random.randint(12,55))
        ok,area,v2=check_area_bound(pts)
        if not ok:
            raise AssertionError((area,v2,area/v2))
        if v2>0:
            worst_ratio=max(worst_ratio,area/v2)
    out.append(f'PASS random simple arcs: 1000; max area/V2^2 = {worst_ratio:.6f} <= pi/4={math.pi/4:.6f}')

    # 2. Scaling invariance.
    pts=random_monotone_graph(40)
    a0=abs(signed_closed_area(pts)); v0=v2sq_vertices(pts)
    for sc in [0.01,0.1,2.5,17.0]:
        q=sc*pts
        a=abs(signed_closed_area(q)); v=v2sq_vertices(q)
        if not (math.isclose(a, sc*sc*a0, rel_tol=1e-10, abs_tol=1e-10) and
                math.isclose(v, sc*sc*v0, rel_tol=1e-10, abs_tol=1e-10)):
            raise AssertionError('scaling')
    out.append('PASS quadratic scaling of area and V2^2')

    # 3. High-winding spiral sharpness family.
    out.append('spiral family: N, diam, winding, area, V2^2, length')
    for N in [2,4,8,16,32]:
        pts=spiral(N, pts_per_turn=12)
        ok,area,v2=check_area_bound(pts, tol=1e-8)
        if not ok:
            raise AssertionError(('spiral area bound',N,area,v2))
        d=diameter(pts)
        w=winding_number(pts,(0,0))
        L=polyline_length(pts)
        if w != N:
            raise AssertionError(('winding',N,w))
        out.append(f'  {N:2d}  {d:.6f}  {w:2d}  {area:.6f}  {v2:.6f}  {L:.6f}')
    out.append('PASS simple spiral realizes winding ~ r^-2 with O(1) area and O(1) quadratic variation')

    # 4. Winding lower bound using the isodiametric support estimate.
    for N in [4,8,16,32]:
        pts=spiral(N, pts_per_turn=16)
        area=abs(signed_closed_area(pts)); d=diameter(pts); w=abs(winding_number(pts))
        lower=4*area/(math.pi*d*d)
        if w + 1e-8 < lower:
            raise AssertionError(('wind lower',N,w,lower))
    out.append('PASS winding multiplicity lower bound |wind|max >= 4|A|/(pi diam^2) on spiral tests')

    # 5. Length lower bound L >= V2^2/diam (stronger than half-optimal theorem form for vertices).
    for _ in range(500):
        pts=random_monotone_graph(random.randint(10,45))
        v=v2sq_vertices(pts); d=diameter(pts); L=polyline_length(pts)
        if d>0 and L + 1e-9 < v/d:
            raise AssertionError(('length',L,v/d))
    out.append('PASS local length lower bound L >= V2^2/diam on 500 random simple arcs')

    # 6. Defect inequality algebra sanity on random arcs:
    # primitive increment = closed area - chord integral, hence <= pi/4 V2^2 + |chord integral|.
    for _ in range(1000):
        pts=random_monotone_graph(random.randint(10,50))
        p=pts[0]; q=pts[-1]
        closed=signed_closed_area(pts)
        chord=0.5*(q[0]*p[1]-q[1]*p[0])  # integral q->p alpha
        prim=closed-chord
        R=max(np.linalg.norm(pts,axis=1))
        v=v2sq_vertices(pts)
        rhs=(math.pi/4)*v + 0.5*R*np.linalg.norm(q-p)
        if abs(prim)>rhs+1e-8:
            raise AssertionError(('primitive bound',abs(prim),rhs))
    out.append('PASS primitive increment bound on 1000 random simple arcs')

    out.append('ALL CHECKS PASS')
    text='\n'.join(out)+'\n'
    print(text)
    Path('/mnt/data/halfsquare_v184_quadratic_concentration/results/verify_v184_output.txt').write_text(text)

if __name__=='__main__':
    main()
