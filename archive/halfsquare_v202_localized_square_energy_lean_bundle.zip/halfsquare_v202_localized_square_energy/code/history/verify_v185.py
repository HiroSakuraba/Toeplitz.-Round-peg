import math
import random
import numpy as np
from shapely.geometry import LineString


def root_spiral(theta, a=1.0, shift=0.0):
    r = a / math.sqrt(theta + shift)
    return np.array([r*math.cos(theta), r*math.sin(theta)], dtype=float)


def double_spiral_polygon(N, samples_per_turn=80, a=1.0):
    # Critical dyadic block: theta1 = 2 theta0, with N turns.
    theta0 = 2*math.pi*N
    theta1 = theta0 + 2*math.pi*N
    M = N*samples_per_turn + 1
    th = np.linspace(theta0, theta1, M)
    A = np.array([root_spiral(float(t), a, 0.0) for t in th])
    B = np.array([root_spiral(float(t), a, math.pi) for t in th])
    pts = np.vstack([A, B[::-1], A[0:1]])
    return th, A, B, pts


def signed_winding(points, z=np.array([0.0,0.0])):
    pts = np.asarray(points)
    total = 0.0
    for p,q in zip(pts[:-1], pts[1:]):
        a = p-z; b=q-z
        total += math.atan2(np.cross(a,b), np.dot(a,b))
    return total/(2*math.pi)


def ray_intersections(polyline, phi):
    # Rotate by -phi. Count transverse crossings of y=0 with x>0.
    c,s = math.cos(phi), math.sin(phi)
    R = np.array([[c,s],[-s,c]])
    P = np.asarray(polyline) @ R.T
    out=[]
    for i,(p,q) in enumerate(zip(P[:-1], P[1:])):
        y1,y2=p[1],q[1]
        # Half-open convention; phi chosen generic, so no vertices near 0.
        if (y1 < 0 < y2) or (y2 < 0 < y1):
            t = -y1/(y2-y1)
            x = p[0]+t*(q[0]-p[0])
            if x>0:
                sign = 1 if y2>y1 else -1
                out.append((x,sign,i))
    out.sort()
    return out


def check_combinatorial_run_bound(trials=10000):
    # Generate alternating sign crossing sequences with A algebraic excess N.
    # Verify number of A/B label transitions >= 2N-4 whenever B cancels to within 1.
    for _ in range(trials):
        m=random.randint(8,100)
        first=random.choice([1,-1])
        signs=[first*((-1)**i) for i in range(m)]
        labels=[random.choice(['A','B']) for _ in range(m)]
        IA=sum(s for s,l in zip(signs,labels) if l=='A')
        IB=sum(s for s,l in zip(signs,labels) if l=='B')
        if abs(IA)<3 or abs(IA+IB)>1: continue
        N=abs(IA)+1  # theorem only knows |IA| >= N-1; choose maximal compatible N
        # Count runs/transitions
        T=sum(labels[i]!=labels[i-1] for i in range(1,m))
        if T < 2*N-4:
            # This bound also uses |IB| >= N-2, which follows here.
            if abs(IB) >= N-2:
                raise AssertionError((signs,labels,IA,IB,N,T))
    return True


def check_spiral_family():
    rows=[]
    for N in [8,16,32,64,128]:
        th,A,B,poly=double_spiral_polygon(N, samples_per_turn=30)
        ls=LineString(poly)
        if not ls.is_simple:
            raise AssertionError(f'double spiral not simple N={N}')
        # A closed by its radial chord
        Aclosed=np.vstack([A,A[0:1]])
        wA=signed_winding(Aclosed)
        fullw=signed_winding(poly)
        # B plus opposite chord: B is oriented inner->outer in full polygon.
        Boriented=B[::-1]
        Bclosed=np.vstack([Boriented,Boriented[0:1]])
        wB=signed_winding(Bclosed)
        if abs(wA-N)>0.1:
            raise AssertionError((N,wA))
        if abs((wA+wB)-fullw)>0.2:
            raise AssertionError((N,wA,wB,fullw))
        # Common-angle inter-side gap at midblock.
        tm=0.5*(th[0]+th[-1])
        rA=1/math.sqrt(tm)
        rB=1/math.sqrt(tm+math.pi)
        gap=rA-rB
        cubic_ratio=gap/(rA**3)
        # tends pi/2 for a=1
        rows.append((N,rA,gap,cubic_ratio,wA,wB,fullw))
        if not (0.8 < cubic_ratio/(math.pi/2) < 1.2):
            raise AssertionError((N,cubic_ratio))
        # Generic-ray crossings should alternate A/B radially in the strip model.
        phi=0.371
        ia=ray_intersections(A,phi)
        ib=ray_intersections(B,phi)
        merged=sorted([(x,'A',sgn) for x,sgn,_ in ia]+[(x,'B',sgn) for x,sgn,_ in ib])
        transitions=sum(merged[i][1]!=merged[i-1][1] for i in range(1,len(merged)))
        if transitions < 2*N-6:
            raise AssertionError((N,len(ia),len(ib),transitions))
        # Minimum A/B radial transition should be O(r^3)
        gaps=[]
        for i in range(1,len(merged)):
            if merged[i][1]!=merged[i-1][1]:
                gaps.append(merged[i][0]-merged[i-1][0])
        if not gaps:
            raise AssertionError('no gaps')
        min_gap=min(gaps)
        rout=1/math.sqrt(th[0])
        scaled=min_gap/(rout**3)
        if scaled>10:
            raise AssertionError((N,min_gap,rout,scaled))
    return rows


def check_area_calibration():
    for N in [10,50,200,1000]:
        th0=2*math.pi*N
        th1=4*math.pi*N
        area=0.5*math.log(th1/th0)
        if abs(area-0.5*math.log(2))>1e-12:
            raise AssertionError(area)
        r=1/math.sqrt(th0)
        if abs(N*r*r-1/(2*math.pi))>1e-12:
            raise AssertionError((N,r))
    return True

if __name__=='__main__':
    print('v185 verifier')
    print('combinatorial run bound:', check_combinatorial_run_bound())
    rows=check_spiral_family()
    print('double root-spiral family: PASS')
    for row in rows:
        N,r,g,cr,wA,wB,wC=row
        print(f'N={N:3d} r_mid={r:.6g} gap={g:.3e} gap/r^3={cr:.6f} windingA={wA:.3f} windingB={wB:.3f} full={wC:.3f}')
    print('area calibration:', check_area_calibration())
    print('ALL CHECKS PASS')
