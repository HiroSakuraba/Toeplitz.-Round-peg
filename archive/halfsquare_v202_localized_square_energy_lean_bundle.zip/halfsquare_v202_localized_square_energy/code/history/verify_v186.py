import math
import numpy as np
from scipy.optimize import least_squares
import sympy as sp

print('v186 verification')

# 1. symbolic power-law obstruction coefficient
e=sp.symbols('e', positive=True)
beta=sp.symbols('beta', positive=True)
a,b,c=sp.symbols('a b c', real=True)
u=a*e+b*e**2+c*e**3
I=sp.I
FA=(1+e*u)**(-beta)*sp.exp(I*u)
FB=(1+e*(u+sp.pi))**(-beta)*sp.exp(I*u)
PA=sp.series((FA-1)/e,e,0,3).removeO().expand()
PB=sp.series((FB-1)/e,e,0,3).removeO().expand()
def ck(expr,k): return sp.expand(expr).coeff(e,k)
def PAG(aa,bb,cc,k): return sp.simplify(ck(PA.subs({a:aa,b:bb,c:cc}),k))
def PBG(aa,bb,cc,k): return sp.simplify(ck(PB.subs({a:aa,b:bb,c:cc}),k))

x=sp.symbols('x', real=True)
a1=x+beta*sp.pi
p0,p1,q0,q1=sp.symbols('p0 p1 q0 q1', real=True)
r0,r1,s0,s1=sp.symbols('r0 r1 s0 s1', real=True)
R01=sp.simplify(PBG(x,q0,0,1)-PAG(x,p0,0,1)-I*(PAG(a1,p1,0,1)-PAG(x,p0,0,1)))
R11=sp.simplify(PBG(a1,q1,0,1)-PAG(a1,p1,0,1)-I*(PAG(a1,p1,0,1)-PAG(x,p0,0,1)))
# first-order solution, with common gauge p
p=sp.symbols('p', real=True)
subs1={
 p0:p,
 p1:p-sp.pi**2*beta*(beta+1)/2,
 q0:p-beta**2*(sp.pi**2/2+sp.pi),
 q1:p-sp.pi**2*beta*(beta+1)/2 + beta**2*(sp.pi**2-2*sp.pi)/2,
}
R02=sp.simplify(PBG(x,q0,s0,2)-PAG(x,p0,r0,2)-I*(PAG(a1,p1,r1,2)-PAG(x,p0,r0,2))).subs(subs1)
R12=sp.simplify(PBG(a1,q1,s1,2)-PAG(a1,p1,r1,2)-I*(PAG(a1,p1,r1,2)-PAG(x,p0,r0,2))).subs(subs1)
obstruction=sp.factor(sp.re(R12)-sp.re(R02))
expected=sp.pi**2*beta**2*(beta+1)
assert sp.simplify(obstruction-expected)==0
print('1 symbolic obstruction:', obstruction)

# 2. critical beta=1/2 constants
crit=sp.simplify(expected.subs(beta,sp.Rational(1,2)))
assert crit==3*sp.pi**2/8
print('2 critical coefficient:', crit)

# 3. critical cubic gap law and seventh-order defect
# r=a*T^-1/2; half-turn gap ~ (pi/(2 a^2)) r^3
# mismatch ~ (3pi^2/(8 a^6)) r^7
for aval in [0.7,1.0,2.0]:
    T=1e5
    r=aval*T**-0.5
    gap_exact=aval*T**-0.5-aval*(T+math.pi)**-0.5
    gap_as=(math.pi/(2*aval**2))*r**3
    assert abs(gap_exact/gap_as-1)<1e-4
print('3 cubic gap law OK')

# 4. numerical optimized local-square residual ~ (3pi^2/(8 sqrt2)) T^-7/2 for a=1

def A(th): return th**-0.5*np.exp(1j*th)
def B(th): return (th+np.pi)**-0.5*np.exp(1j*th)
def best_local(T):
    delta=np.pi/(2*T)
    def rr(v):
        t0,t1,s0,s1=v
        z0=A(t0); z1=A(t1); side=z1-z0
        d3=B(s0)-(z0+1j*side)
        d2=B(s1)-(z1+1j*side)
        return np.array([d3.real,d3.imag,d2.real,d2.imag])
    W=10/T
    x0=np.array([T,T+delta,T,T+delta])
    res=least_squares(rr,x0,bounds=(np.full(4,T-W),np.full(4,T+W)),max_nfev=2500,
                      xtol=1e-13,ftol=1e-13,gtol=1e-13)
    return np.linalg.norm(res.fun)
C=3*math.pi**2/(8*math.sqrt(2))
ratios=[]
for T in [80.,120.,180.,250.]:
    err=best_local(T)
    ratios.append(err*T**3.5/C)
print('4 normalized residual ratios:', ratios)
assert all(0.85<q<1.08 for q in ratios[-3:])

# 5. straight-line / monotone-upper-graph counterexample to two-strand forcing
# lower y=0; upper y=1+eps*x on [0,L]. Any square with two vertices on lower
# has horizontal lower side, hence horizontal upper side, requiring equal upper heights.
eps=0.01
for x0 in [0.,1.,5.]:
    for x1 in [x0+0.1,x0+1.0]:
        assert abs((1+eps*x1)-(1+eps*x0))>0
print('5 two-strand forcing counterexample check OK')

# 6. half-turn layer lattice: combined A/B radii on a ray correspond to theta+pi*m.
# quadrature ray is offset by pi/2, so exact equal-radius centered-square matching is impossible.
for m in range(-5,6):
    for n in range(-5,6):
        assert abs((m-n)*math.pi-math.pi/2)>1e-12
print('6 quadrature half-step residue OK')

print('ALL V186 CHECKS PASS')
