import math
import numpy as np
import sympy as sp
from scipy.optimize import root

# 1. Symbolic Jacobian factorization
x,y,s=sp.symbols('x y s', real=True)
W=[(x+s,y),(x,y+s),(x-s,y),(x,y-s)]
H=[1/(X*X+Y*Y) for X,Y in W]
G=sp.Matrix([H[1]-H[0],H[2]-H[0],H[3]-H[0]])
J=sp.factor(G.jacobian([x,y,s]).det())
expected=sp.factor(-128*s**3*(x-y)*(x+y)*(s**2-x**2-y**2)/sp.prod([(X*X+Y*Y)**2 for X,Y in W]))
assert sp.simplify(J-expected)==0
print('[1/8] symbolic det DG factorization: PASS')

ref={x:sp.Rational(1,3),y:sp.Rational(2,3),s:1}
Jref=sp.factor(J.subs(ref))
assert Jref == sp.Rational(1594323,135200)
print('[2/8] exact reference determinant:',Jref,'PASS')

# 2. Critical layer equivalence by direct construction
# If Psi(z)=m*pi and q=a^2/|z|^2, then q-arg(z)=m*pi.
a=1.0
for phi in [0.2,0.9,1.7]:
    for m in [20,21,40]:
        q=phi+math.pi*m
        r=a/math.sqrt(q)
        z=r*np.exp(1j*phi)
        psi=a*a/(abs(z)**2)-phi
        assert abs(psi-math.pi*m)<1e-11
print('[3/8] critical phase-lattice/radial-layer equivalence: PASS')

# 3. Numerical lattice matching at decreasing rho
ystar=np.array([1/3,2/3,1.0],float)
def shape_w(u):
    cx,cy,ss=u
    return np.array([cx+ss+1j*cy,
                     cx+1j*(cy+ss),
                     cx-ss+1j*cy,
                     cx+1j*(cy-ss)],complex)

def phase_diffs(u,rho):
    w=shape_w(u)
    L=a*a/(rho*rho)
    psi=L/(np.abs(w)**2)-np.angle(w)
    return psi[1:]-psi[0]

def solve(rho):
    D0=phase_diffs(ystar,rho)
    k=np.rint(D0/math.pi).astype(int)
    target=math.pi*k
    sol=root(lambda u: phase_diffs(u,rho)-target, ystar, tol=1e-12)
    assert sol.success
    u=sol.x
    w=shape_w(u)
    L=a*a/rho**2
    base=L/(abs(w[0])**2)-np.angle(w[0])
    m0=int(round(base/math.pi))
    theta=base-m0*math.pi
    z=rho*np.exp(1j*theta)*w
    # use unwrapped local angle theta+arg(w), which is legitimate for this local construction
    phi=theta+np.angle(w)
    q=a*a/(np.abs(z)**2)
    m=np.rint((q-phi)/math.pi).astype(int)
    laterr=np.max(np.abs(q-phi-math.pi*m))
    # square residuals
    f1=z[0]+z[2]-z[1]-z[3]
    f2=(z[2]-z[1])-1j*(z[1]-z[0])
    sqerr=math.sqrt(abs(f1)**2+abs(f2)**2)
    return u,m,laterr,sqerr

rhos=[0.1,0.05,0.025,0.0125]
ratios=[]
for rho in rhos:
    u,m,le,se=solve(rho)
    assert le<1e-8 and se<1e-10
    ratios.append(np.linalg.norm(u-ystar)/(rho*rho))
    print(f'    rho={rho:.4g}  ||du||/rho^2={ratios[-1]:.6g}  m={tuple(int(v) for v in m)}')
print('[4/8] exact numerical phase-lattice squares: PASS')

assert max(ratios)<20
print('[5/8] normalized shape correction O(rho^2): PASS')

# 4. Physical correction scale rho*du = O(rho^3)
physical=[rhos[i]*ratios[i]*(rhos[i]**2) for i in range(len(rhos))]
scaled=[physical[i]/rhos[i]**3 for i in range(len(rhos))]
assert max(scaled)<20
print('[6/8] physical vertex correction O(rho^3): PASS')

# 5. Rotation covariance of phase: Psi(e^{i theta}z)=Psi(z)-theta mod pi
z0=0.37+0.22j
theta=0.731
psi0=a*a/abs(z0)**2-np.angle(z0)
psi1=a*a/abs(np.exp(1j*theta)*z0)**2-(np.angle(z0)+theta)
assert abs((psi1-psi0)+theta)<1e-12
print('[7/8] common rotation shifts all phases equally: PASS')

# 6. Generic nonsingularity conditions checked away from three loci
for pt in [(0.2,0.5,1.0),(0.3,-0.6,1.2),(0.8,0.1,1.4)]:
    val=float(J.subs({x:pt[0],y:pt[1],s:pt[2]}))
    assert abs(val)>1e-6
print('[8/8] generic off-center shape nonsingularity: PASS')

print('ALL v187 CHECKS PASSED')
