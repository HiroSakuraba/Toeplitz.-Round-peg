#!/usr/bin/env python3
import math
import random
import sympy as sp

checks=[]
def ck(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond:
        raise AssertionError(f'{name}: {detail}')

# symbols
x,y,s=sp.symbols('x y s', real=True)
h0,h1,h2,h3=sp.symbols('h0 h1 h2 h3', nonzero=True)
q0=(x+s)**2+y**2
q1=x**2+(y+s)**2
q2=(x-s)**2+y**2
q3=x**2+(y-s)**2
qs=[q0,q1,q2,q3]
hs=[h0,h1,h2,h3]
vars=[x,y,s]

# Direct Jacobian with independent h'(q_j)
rows=[]
for j in (1,2,3):
    rows.append([hs[j]*sp.diff(qs[j],v)-hs[0]*sp.diff(q0,v) for v in vars])
J=sp.Matrix(rows)
det_direct=sp.expand(J.det())
det_formula=16*s*(x*x+y*y-s*s)*(h0*h1*h2-h0*h1*h3+h0*h2*h3-h1*h2*h3)
ck('general determinant polynomial identity', sp.expand(det_direct-det_formula)==0)

reciprocal_formula=16*s*(x*x+y*y-s*s)*(h0*h1*h2*h3)*(1/h3-1/h2+1/h1-1/h0)
ck('reciprocal-slope determinant identity', sp.simplify(det_formula-reciprocal_formula)==0)

# canonical h(q)=1/q specialization
subs_inv={h0:-1/q0**2,h1:-1/q1**2,h2:-1/q2**2,h3:-1/q3**2}
det_inv=sp.factor(det_formula.subs(subs_inv))
v187=-128*s**3*(x-y)*(x+y)*(s*s-x*x-y*y)/(q0**2*q1**2*q2**2*q3**2)
ck('canonical 1/q specializes to v187 factor', sp.factor(det_inv-v187)==0)

# exact reference value from v187
ref={x:sp.Rational(1,3), y:sp.Rational(2,3), s:sp.Integer(1)}
refval=sp.simplify(det_inv.subs(ref))
ck('v187 reference determinant exact', refval==sp.Rational(1594323,135200), str(refval))

# Affine and logarithmic leading laws have affine reciprocal derivative.
q=sp.symbols('q', positive=True)
A,B,alpha,beta=sp.symbols('A B alpha beta', nonzero=True)
h_aff=A*q+B
R_aff=sp.simplify(1/sp.diff(h_aff,q))
ck('affine h has affine reciprocal derivative', sp.diff(R_aff,q,2)==0)

h_log=A*sp.log(alpha+beta*q)+B
R_log=sp.simplify(1/sp.diff(h_log,q))
ck('log h has affine reciprocal derivative', sp.simplify(sp.diff(R_log,q,2))==0)

# A nonexceptional power law h=q^p except p=1/log limit: choose p=-1 canonical.
R_inv=sp.simplify(1/sp.diff(1/q,q))
ck('critical reciprocal derivative non-affine', sp.simplify(sp.diff(R_inv,q,2))!=0, str(sp.diff(R_inv,q,2)))

# Midpoint identity -> R''=0 via Taylor symbolic coefficient
a,m=sp.symbols('a m', real=True)
R0,R1,R2,R3,R4=sp.symbols('R0 R1 R2 R3 R4')
# formal Taylor up to fourth order
Rp=R0+R1*a+R2*a**2/2+R3*a**3/6+R4*a**4/24
Rm=R0-R1*a+R2*a**2/2-R3*a**3/6+R4*a**4/24
mid=sp.expand(Rp+Rm-2*R0)
ck('midpoint defect leading coefficient is R2 a^2', sp.expand(mid).coeff(a,2)==R2)

# Critical corrugation scaling: normalized radial displacement is O(1/L), physical O(rho^3)
# Solve L/r^2 - theta + eps*sin(L theta)=pi n. Linearized dr ≈ -e / d(L/r^2)/dr = e*r^3/(2L?)
# At normalized r~1 derivative magnitude ~2L, so |dr| <= C/L. physical rho*dr and L=a^2/rho^2 => O(rho^3).
for rho in [0.2,0.1,0.05,0.025]:
    Lval=1.0/(rho*rho)
    normalized=1.0/Lval
    physical=rho*normalized
    ratio=physical/(rho**3)
    ck(f'cubic displacement scaling rho={rho}', abs(ratio-1.0)<1e-12, f'ratio={ratio}')

# Naive transverse quadratic cost N*(r^3)^2 with N~r^-2 is r^4.
for r in [0.2,0.1,0.05,0.025]:
    N=r**-2
    cost=N*(r**3)**2
    ck(f'cubic corrugation quadratic cost rho={r}', abs(cost-r**4)<1e-12)

# Subleading phase error correction scales E/L -> 0 for representative E=L^alpha, alpha<1.
for alpha_exp in [0.0,0.25,0.5,0.9]:
    vals=[]
    for Lval in [1e2,1e4,1e6]:
        E=Lval**alpha_exp
        vals.append((E+1)/Lval)
    ck(f'subleading correction decreases alpha={alpha_exp}', vals[-1] < vals[0], str(vals))

# Random numerical consistency checks for general determinant against direct numerical Jacobian formula.
fdet=sp.lambdify((x,y,s,h0,h1,h2,h3),det_formula,'math')
for k in range(200):
    xv=random.uniform(-1.5,1.5)
    yv=random.uniform(-1.5,1.5)
    sv=random.uniform(0.2,1.5)
    hv=[random.choice([-1,1])*random.uniform(0.2,2.0) for _ in range(4)]
    # direct 3x3 numeric matrix
    qgrad=[
        [2*(xv+sv),2*yv,2*(xv+sv)],
        [2*xv,2*(yv+sv),2*(yv+sv)],
        [2*(xv-sv),2*yv,-2*(xv-sv)],
        [2*xv,2*(yv-sv),-2*(yv-sv)],
    ]
    M=[]
    for j in [1,2,3]:
        M.append([hv[j]*qgrad[j][i]-hv[0]*qgrad[0][i] for i in range(3)])
    # 3x3 determinant
    d=(M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])
       -M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])
       +M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0]))
    df=fdet(xv,yv,sv,*hv)
    if abs(d-df)>1e-8*(1+abs(d)+abs(df)):
        raise AssertionError((d,df,xv,yv,sv,hv))
ck('200 random determinant evaluations', True)

passed=sum(v for _,v,_ in checks)
print(f'PASS {passed}/{len(checks)} checks')
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL'), name, (f'-- {detail}' if detail else ''))
