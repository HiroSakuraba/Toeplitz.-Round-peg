#!/usr/bin/env python3
import math
import numpy as np

checks=[]
def ck(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond:
        raise AssertionError(f'{name}: {detail}')

def cross2(a,b):
    return float(a[0]*b[1]-a[1]*b[0])

def polygon_area(poly):
    return 0.5*sum(cross2(poly[i],poly[(i+1)%len(poly)]) for i in range(len(poly)))

def winding(poly,z):
    z=np.asarray(z,float)
    ang=0.0
    for i in range(len(poly)):
        a=poly[i]-z
        b=poly[(i+1)%len(poly)]-z
        ang += math.atan2(cross2(a,b), float(a@b))
    return ang/(2*math.pi)

def rainbow(N,samples=80):
    q=[1-j/(3*N) for j in range(N+1)]
    lam=N**-0.5
    pts=[]
    for j in range(N):
        c=(q[j]-q[j+1])/2
        a=(q[j]+q[j+1])/2
        for k in range(samples+1):
            if pts and k==0: continue
            th=math.pi*k/samples
            pts.append((c+a*math.cos(th), a*math.sin(th)))
        if j<N-1:
            rr=q[j+1]
            for k in range(1,samples+1):
                th=math.pi+math.pi*k/samples
                pts.append((rr*math.cos(th), rr*math.sin(th)))
    return np.asarray(pts,float)*lam,q,lam

def analytic_area(N):
    q=[1-j/(3*N) for j in range(N+1)]
    lam=N**-0.5
    A=0.0
    for j in range(N):
        a=(q[j]+q[j+1])/2
        A += 0.5*math.pi*(a*lam)**2
        if j<N-1:
            A += 0.5*math.pi*(q[j+1]*lam)**2
    return A

# 1. Exact scale relation lambda^2 N = 1.
for N in [8,16,32,64,128]:
    lam=N**-0.5
    ck(f'critical scaling N lambda^2 =1 N={N}', abs(N*lam*lam-1)<1e-14)

# 2. The critical rainbow has winding exactly N at a common upper point.
for N in [4,8,16,32,64]:
    poly,q,lam=rainbow(N,80)
    w=winding(poly,(0.0,0.2*lam))
    ck(f'rainbow winding N={N}', abs(w-N)<1e-8, f'w={w}')

# 3. Chord-closed area remains order one and approaches the analytic lobe sum.
areas=[]
for N in [8,16,32,64,128]:
    poly,q,lam=rainbow(N,100)
    Ap=polygon_area(poly)
    Aa=analytic_area(N)
    areas.append(Ap)
    ck(f'area matches lobe sum N={N}', abs(Ap-Aa)<8e-4, f'poly={Ap}, analytic={Aa}')
ck('area packet stays nonvanishing', min(areas)>2.0, str(areas))
limit=19*math.pi/27
ck('area approaches 19pi/27', abs(areas[-1]-limit)<0.03, f'last={areas[-1]}, limit={limit}')

# 4. Upper cap intervals are strictly nested.
for N in [8,32,128]:
    q=[1-j/(3*N) for j in range(N+1)]
    ok=True
    for j in range(N-1):
        outer=(-q[j+1],q[j])
        inner=(-q[j+2],q[j+1])
        ok &= outer[0] < inner[0] < inner[1] < outer[1]
    ck(f'upper chord intervals nested N={N}', ok)

# 5. The common point lies inside every upper half-disk.
for N in [8,32,128]:
    q=[1-j/(3*N) for j in range(N+1)]
    y0=0.2
    ok=True
    for j in range(N):
        c=(q[j]-q[j+1])/2
        a=(q[j]+q[j+1])/2
        ok &= c*c+y0*y0 < a*a
    ck(f'common upper point in all caps N={N}', ok)

# 6. Normal-ray crossing gaps have the predicted lambda^3/3 asymptotic.
for N in [32,64,128,256,512]:
    q=[1-j/(3*N) for j in range(N+1)]
    lam=N**-0.5
    ys=[lam*math.sqrt(q[j]*q[j+1]) for j in range(N)]
    ratios=[(ys[j]-ys[j+1])/(lam**3) for j in range(N-1)]
    ck(f'cubic normal spacing N={N}', max(abs(x-1/3) for x in ratios)<2e-4,
       f'range=({min(ratios)},{max(ratios)})')

# 7. Diameter scale is Theta(lambda); a cheap bounding-box diameter suffices.
for N in [16,64,256]:
    poly,q,lam=rainbow(N,40)
    spanx=float(poly[:,0].max()-poly[:,0].min())
    spany=float(poly[:,1].max()-poly[:,1].min())
    # both spans are bounded above/below by fixed multiples of lambda
    ck(f'packet spans scale lambda N={N}', 1.2*lam<spanx<2.2*lam and 1.2*lam<spany<2.2*lam,
       f'spanx/lambda={spanx/lam}, spany/lambda={spany/lam}')

# 8. Positive-area averaging constant: if A>0 in a hull of area <= pi r^2/4,
#    average positive multiplicity >=4A/(pi r^2). Check algebra numerically.
for A,r in [(0.5,0.1),(1.0,0.05),(2.0,0.2)]:
    hull=math.pi*r*r/4
    lower=A/hull
    ck(f'multiplicity constant A={A},r={r}', abs(lower-4*A/(math.pi*r*r))<1e-12)

# 9. Fixed anisotropic affine distortion creates order-r radial deviation.
#    Circle radius R -> ellipse semiaxes R and 2R. Best concentric circle in sup radial norm
#    has error at least (2R-R)/2 = R/2.
for R in [1.0,0.1,0.01]:
    err=(2*R-R)/2
    ck(f'anisotropy gives order-r radial error R={R}', abs(err/R-0.5)<1e-12)

# 10. r^-2 depth + bounded span algebraically forces an r^3 pigeonhole gap.
for r in [0.2,0.1,0.05,0.025]:
    C=3.0
    N=max(3,int(C/r**2))
    gap=r/(N-1)
    ck(f'cubic pigeonhole scaling r={r}', gap <= (1/C+0.02)*r**3,
       f'gap/r^3={gap/r**3}')

print(f'PASS {len(checks)}/{len(checks)} checks')
for name,ok,detail in checks:
    print('PASS',name,(f'-- {detail}' if detail else ''))
