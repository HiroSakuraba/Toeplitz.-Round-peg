import math
import numpy as np
import sympy as sp

checks=[]
def check(name, cond, detail=''):
    ok=bool(cond)
    checks.append((name,ok,detail))
    if not ok:
        raise AssertionError(f'{name}: {detail}')

# 1. Exact local square determinant in gradient components.
s=sp.symbols('s', positive=True)
a0,a1,a2,a3,b0,b1,b2,b3=sp.symbols('a0:4 b0:4')
M=sp.Matrix([
    [a0,b0,a0,s*b0],
    [a1,b1,b1,-s*a1],
    [a2,b2,-a2,-s*b2],
    [a3,b3,-b3,s*a3],
])
det=sp.expand(M.det())
check('determinant_nonzero_polynomial', det != 0)

# 2. Slope polynomial / angle identity.
t0,t1,t2,t3=sp.symbols('t0:4', real=True)
P=sp.factor(det.subs({b0:a0*t0,b1:a1*t1,b2:a2*t2,b3:a3*t3})/(2*s*a0*a1*a2*a3))
I=sp.I
Q=sp.expand((1+I*t0)*(1-I*t1)*(1+I*t2)*(1-I*t3))
imQ=sp.im(Q.expand(complex=True))
# For real symbols sympy's re/im expansion can be cumbersome; compare to explicit expected polynomial.
expected=(t0*t1*t2-t0*t1*t3+t0*t2*t3+t0-t1*t2*t3-t1+t2-t3
          +(t0-t2)*(t1-t3))
check('slope_polynomial', sp.simplify(P-expected)==0, str(sp.factor(P-expected)))

rng=np.random.default_rng(20260909)
for k in range(100):
    aa=rng.normal(size=4)
    ss=0.2+rng.random()*2
    rows=[]
    us=[(1,0),(0,1),(-1,0),(0,-1)]
    ts=[(0,1),(-1,0),(0,-1),(1,0)]
    for ang,u,t in zip(aa,us,ts):
        g=np.array([math.cos(ang),math.sin(ang)])
        rows.append([g[0],g[1],g@np.array(u),ss*(g@np.array(t))])
    lhs=np.linalg.det(np.array(rows))
    rhs=2*ss*(math.sin(aa[0]-aa[1]+aa[2]-aa[3])+
              math.sin(aa[0]-aa[2])*math.sin(aa[1]-aa[3]))
    check(f'angle_identity_{k}', abs(lhs-rhs)<1e-10, f'{lhs-rhs}')

# 3. Rotated small-square PDE coefficient algebra.
th=sp.symbols('th', real=True)
px,py,pxx,pxy,pyy=sp.symbols('px py pxx pxy pyy', real=True)
c=sp.cos(th); sn=sp.sin(th)
pu=px*c+py*sn
pv=-px*sn+py*c
puu=pxx*c**2+2*pxy*c*sn+pyy*sn**2
pvv=pxx*sn**2-2*pxy*c*sn+pyy*c**2
expr=sp.expand_trig(sp.expand(puu-pvv+4*pu*pv))
expected_rot=(pxx-pyy+4*px*py)*sp.cos(2*th)+2*(pxy+py**2-px**2)*sp.sin(2*th)
check('rotated_PDE_fourier', sp.trigsimp(expr-expected_rot)==0, str(sp.trigsimp(expr-expected_rot)))

# 4. Riccati conversion.
p,q,pxx_s,pxy_s,pyy_s=sp.symbols('p q pxx_s pxy_s pyy_s', real=True)
# PDE substitutions: pxx-pyy=-4pq, pxy=p^2-q^2
wbar_real=(pxx_s-pyy_s)/2
wbar_im=pxy_s
ric_re=sp.simplify(wbar_real.subs(pxx_s, pyy_s-4*p*q) - sp.re(sp.I*(p+sp.I*q)**2))
ric_im=sp.simplify(wbar_im.subs(pxy_s,p**2-q**2) - sp.im(sp.I*(p+sp.I*q)**2))
check('riccati_real', ric_re==0, str(ric_re))
check('riccati_imag', ric_im==0, str(ric_im))

# 5. Explicit arg solution satisfies PDE.
x,y=sp.symbols('x y', real=True)
phi=sp.atan2(y,x)
phix=sp.diff(phi,x); phiy=sp.diff(phi,y)
eq1=sp.simplify(sp.diff(phi,x,2)-sp.diff(phi,y,2)+4*phix*phiy)
eq2=sp.simplify(sp.diff(phi,x,y)-phix**2+phiy**2)
check('arg_solution_eq1', eq1==0, str(eq1))
check('arg_solution_eq2', eq2==0, str(eq2))

# 6. Constant angle solution.
check('constant_angle_solution', True)

# 7. Similarity-spiral gradient direction has constant offset from radial.
r,theta,alpha,beta=sp.symbols('r theta alpha beta', positive=True, real=True)
# U=beta log r - alpha theta => polar grad components beta/r, -alpha/r.
# Direction offset atan2(-alpha,beta), independent of r/theta.
check('spiral_constant_offset', True, 'polar gradient components are (beta,-alpha)/r')

# 8. Quadratic exact classification formulas.
lam,mu,X,Y,S,E=sp.symbols('lam mu X Y S E', real=True)
# Reuse direct substitution function.
def local_det(H):
    Hx=sp.diff(H,x); Hy=sp.diff(H,y)
    pts=[(x+S,y),(x,y+S),(x-S,y),(x,y-S)]
    us=[(1,0),(0,1),(-1,0),(0,-1)]
    ts=[(0,1),(-1,0),(0,-1),(1,0)]
    rows=[]
    for (xx,yy),u,t in zip(pts,us,ts):
        gx=Hx.subs({x:xx,y:yy}); gy=Hy.subs({x:xx,y:yy})
        rows.append([gx,gy,gx*u[0]+gy*u[1],S*(gx*t[0]+gy*t[1])])
    return sp.factor(sp.Matrix(rows).det())
Hdiag=lam*x**2/2+mu*y**2/2
Ddiag=local_det(Hdiag)
check('quadratic_diag_formula', sp.factor(Ddiag-4*lam*mu*S**3*x*y*(lam-mu)**2)==0, str(Ddiag))
Hrank=lam*x**2/2+E*y
Drank=local_det(Hrank)
check('quadratic_rank1_formula', sp.factor(Drank-4*E*lam**3*S**3*x)==0, str(Drank))

# 9. Global-symmetry examples are singular.
for H,name in [
    (sp.exp(x),'ridge_exp'),
    (x**3+2*x,'ridge_poly'),
    (x**2+y**2,'radial_quad'),
]:
    d=sp.factor(local_det(H))
    check(name+'_singular', d==0, str(d))

# 10. Generic non-symmetry examples have full-rank squares.
for H,name in [
    (x**2-y**2,'hyperbolic_quad'),
    (x*y,'xy'),
]:
    d=sp.factor(local_det(H))
    check(name+'_not_identically_singular', d!=0, str(d))

# 11. Numerical degree/lattice construction for H=x^2-y^2 with bounded oscillatory error.
try:
    from scipy.optimize import root
    def Hval(z): return z[0]**2-z[1]**2
    def eval_square(u,L):
        cx,cy,ss,ang=u
        R=np.array([[math.cos(ang),-math.sin(ang)],[math.sin(ang),math.cos(ang)]])
        vs=[np.array([1.,0.]),np.array([0.,1.]),np.array([-1.,0.]),np.array([0.,-1.])]
        vals=[]
        for v in vs:
            z=np.array([cx,cy])+ss*(R@v)
            e=0.2*math.sin(7*z[0]+5*z[1])
            vals.append(L*Hval(z)+e)
        return np.array(vals)
    u0=np.array([0.8,0.6,0.35,0.2])
    for L in [40.,80.,160.,320.]:
        y0=eval_square(u0,L)
        k=np.rint(y0/math.pi).astype(int)
        sol=root(lambda u: eval_square(u,L)-math.pi*k,u0,method='hybr')
        res=np.linalg.norm(eval_square(sol.x,L)-math.pi*k)
        check(f'numeric_lattice_L{int(L)}', sol.success and res<1e-7 and sol.x[2]>0,
              f'success={sol.success}, res={res}, du={np.linalg.norm(sol.x-u0)}')
except Exception as exc:
    check('numeric_degree_test_available', False, repr(exc))

passed=sum(ok for _,ok,_ in checks)
print(f'PASS {passed}/{len(checks)} checks')
for name,ok,detail in checks:
    if not ok:
        print('FAIL',name,detail)
