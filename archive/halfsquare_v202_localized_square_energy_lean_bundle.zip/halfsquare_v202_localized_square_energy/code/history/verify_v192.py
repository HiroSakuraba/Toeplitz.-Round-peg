#!/usr/bin/env python3
import cmath
import math
import random

TOL = 2e-9
checks = 0


def check(cond, msg):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(msg)


def close(a, b, tol=TOL):
    return abs(a-b) <= tol * max(1.0, abs(a), abs(b))


def dft4(Z):
    return [sum(Z[j] * (1j) ** (-k*j) for j in range(4))/4 for k in range(4)]


def phi(r, z):
    return (r + z)/(1 + r*z)


def invphi(r, w):
    return (w-r)/(1-r*w)


def U(s):
    return 1j*s/(1-1j*s)


def G(z):
    return z/(1+z)


def cayley_real_to_circle(x):
    return (x-1j)/(x+1j)

# 1. Four-point DFT: square <=> modes 2 and 3 vanish (positive order).
rng = random.Random(192)
for _ in range(24):
    c = rng.uniform(-2, 2) + 1j*rng.uniform(-2, 2)
    a = rng.uniform(0.2, 2.0) * cmath.exp(1j*rng.uniform(-math.pi, math.pi))
    Z = [c + a*(1j)**j for j in range(4)]
    H = dft4(Z)
    check(abs(H[2]) < 1e-11, "square mode 2")
    check(abs(H[3]) < 1e-11, "square mode 3")
    check(close(H[0], c, 1e-11), "square center mode")
    check(close(H[1], a, 1e-11), "square shape mode")

# 2. Canonical real-line quartet and cross-ratio formula.
# x=(-1,-t,t,1), lambda=((x1-x0)(x3-x2))/((x2-x0)(x3-x1))=((1-t)/(1+t))^2.
for j in range(1, 21):
    t = j/22
    x = [-1.0, -t, t, 1.0]
    lam = ((x[1]-x[0])*(x[3]-x[2]))/((x[2]-x[0])*(x[3]-x[1]))
    check(close(lam, ((1-t)/(1+t))**2, 1e-12), "cross-ratio formula")
    q = [cayley_real_to_circle(xx) for xx in x]
    for qq in q:
        check(close(abs(qq), 1.0, 1e-12), "Cayley boundary point")

# 3. Exact disk-automorphism inverse on Abel circles.
for r in [0.7, 0.9, 0.97, 0.995]:
    for t in [-0.2, -0.07, 0.03, 0.15]:
        w = r*cmath.exp(1j*t)
        u = invphi(r, w)
        check(close(phi(r, u), w, 1e-11), "phi inverse")

# 4. Hyperbolic/horocycle scaling limit: t=(1-r^2)s.
for r in [0.99, 0.999, 0.9999]:
    d = 1-r*r
    for s in [-3.0, -1.0, -0.2, 0.3, 1.4, 4.0]:
        w = r*cmath.exp(1j*d*s)
        u = invphi(r, w)
        err = abs(u-U(s))
        # first-order convergence; 0.9999 should be very tight, earlier values looser
        check(err < 0.20*(1-r) * (1+abs(s))**2 + 2e-4, "horocycle scaling")

# 5. Limiting horocycle and regular blow-up line map.
for s in [-10,-4,-1,-0.1,0,0.2,1.3,5,11]:
    u = U(s)
    check(close(abs(u+0.5), 0.5, 1e-11), "horocycle equation")
    check(close(G(u), 1j*s, 1e-11), "G straightens horocycle")

# 6. Identity-map normalized blow-up is exactly z/(1+r z).
for r in [0.5,0.9,0.99]:
    for z in [0.1+0.2j, -0.3+0.1j, 0.4j]:
        Fr = (phi(r,z)-r)/(1-r*r)
        check(close(Fr, z/(1+r*z), 1e-11), "identity blow-up")

# 7. Power-law tangent formula f_alpha=1-(1-z)^alpha.
def F_power_finite(r, z, alpha):
    X = (1-z)/(1+r*z)
    return (1-X**alpha)/(alpha*(1+r))

def F_power_limit(z, alpha):
    X = (1-z)/(1+z)
    return (1-X**alpha)/(2*alpha)

for alpha in [0.5, 0.8, 1.0, 1.4, 1.8]:
    for z in [0.1+0.1j, -0.2+0.15j, 0.25j]:
        if alpha == 1.0:
            check(close(F_power_limit(z,alpha), G(z), 1e-11), "alpha=1 regular tangent")
        val = F_power_finite(0.99999,z,alpha)
        check(abs(val-F_power_limit(z,alpha)) < 2e-4, "power tangent convergence")

# 8. Low normalized coefficients from pre-Schwarzian/Schwarzian formulas.
# For the power tangent, b2=-alpha and b3=(1+2 alpha^2)/3.
for alpha in [0.4,0.7,1.0,1.3,1.8]:
    h = 1e-5
    # use analytic formula relation rather than unstable finite differences
    b2 = -alpha
    b3 = (1+2*alpha*alpha)/3
    schwarz_coeff = b3-b2*b2
    check(close(schwarz_coeff, (1-alpha*alpha)/3, 1e-12), "power Schwarzian coefficient")

# 9. Möbius tangent model F_c maps the horocycle to a circle and contains an exact square.
def F_c(z,c):
    return z/(1+c*z)

phi0 = -3*math.pi/4
for c in [0.0, 0.25, 0.5, 0.8, 0.95]:
    d = 1-c
    svals = [math.tan((phi0+j*math.pi/2)/2)/d for j in range(4)]
    check(all(svals[j] < svals[j+1] for j in range(3)), "ordered horocycle square parameters")
    Z = [F_c(U(s),c) for s in svals]
    H = dft4(Z)
    check(abs(H[2]) < 2e-10, "Mobius escape square mode 2")
    check(abs(H[3]) < 2e-10, "Mobius escape square mode 3")
    # exact escape law: max |s| = (1+sqrt(2))/(1-c)
    check(close(max(abs(s) for s in svals), (1+math.sqrt(2))/d, 1e-11), "Mobius spectral-position escape law")
    # coefficient defect from regular baseline begins at d2=1-c.
    check(close(abs((-c)-(-1)), d, 1e-12), "Mobius b2 defect")

# 10. Exact local coefficient identities for C_a f, tested on power maps along real a.
# b2=-a + A P/2; b3=a^2-a A P + A^2 Q/6; b3-b2^2=A^2 S/6.
for alpha in [0.5,0.9,1.2,1.7]:
    for a in [0.4,0.8,0.95]:
        A = 1-a*a
        P = (1-alpha)/(1-a)
        # f'''/f' = (alpha-1)(alpha-2)/(1-a)^2 for f=1-(1-z)^alpha
        Q = (alpha-1)*(alpha-2)/(1-a)**2
        S = (1-alpha*alpha)/(2*(1-a)**2)
        b2 = -a + A*P/2
        b3 = a*a - a*A*P + A*A*Q/6
        check(close(b3-b2*b2, A*A*S/6, 2e-11), "Schwarzian coefficient identity")

# 11. Crude universal ultralocal constant calculation.
# If delta <= eps/100 and r>=1/2, log derivative oscillation L <= 0.035.
eta = math.exp(0.035)-1
check(eta < 1/(1+2*math.sqrt(2)), "ultralocal tube contradiction margin")

# 12. Bieberbach tail helper for finite spectral detection.
def tail_bound(rho,N):
    return sum((n+1)*rho**n for n in range(N+1, 5000))
for rho, target in [(0.7,1e-3),(0.8,2e-3),(0.9,1e-2)]:
    N=1
    while tail_bound(rho,N) >= target:
        N += 1
        if N>1000:
            raise RuntimeError("tail search failed")
    check(tail_bound(rho,N)<target, "finite spectral tail")
    check(N==1 or tail_bound(rho,N-1)>=target, "minimal tail index")

print(f"v192 verifier: PASS ({checks}/{checks} checks)")
print(f"ultralocal eta bound = {eta:.8f} < square threshold {1/(1+2*math.sqrt(2)):.8f}")
print("Möbius model confirms: spectral defect -> 0 only by sending the horocycle square to |s| -> infinity.")
