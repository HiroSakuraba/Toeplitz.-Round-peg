#!/usr/bin/env python3
import cmath
import math
import random

TOL = 2e-10
checks = 0


def check(cond, msg):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(msg)


def close(a, b, tol=TOL):
    return abs(a-b) <= tol * max(1.0, abs(a), abs(b))


def dft4(vals):
    return [sum(vals[j] * (1j) ** (-k*j) for j in range(4))/4 for k in range(4)]


def phi(r, u):
    return (r+u)/(1+r*u)


def phi_inv(r, z):
    return (z-r)/(1-r*z)


def G(r, u):
    return u/(1+r*u)


def pseudohyp(z,w):
    return abs((z-w)/(1-z*w.conjugate()))


def hypdist(z,w):
    p=pseudohyp(z,w)
    return 2*math.atanh(p)


def circle_dft_error(ts):
    q=[cmath.exp(1j*t)-1 for t in ts]
    h=dft4(q)
    return math.sqrt(abs(h[2])**2+abs(h[3])**2)

# 1. DFT square identities and real-vector range lemma.
for m in range(80):
    c=(0.3-0.01*m)+1j*(0.2+0.003*m)
    a=(1.0+0.004*m)*cmath.exp(1j*(0.07*m))
    z=[c+a*(1j)**j for j in range(4)]
    h=dft4(z)
    check(abs(h[2]) < 1e-10 and abs(h[3]) < 1e-10, "square DFT modes")

rng=random.Random(193)
for _ in range(200):
    xs=[rng.uniform(-2,3) for _ in range(4)]
    delta=max(xs)-min(xs)
    h=dft4(xs)
    E=math.sqrt(abs(h[2])**2+abs(h[3])**2)
    check(E+1e-12 >= delta/4, "real DFT range bound")

# 2. Short circular arc lemma, randomized and adversarial duplicate limits.
for delta in [0.5,0.4,0.25,0.125,0.05,0.01]:
    patterns=[
        [-delta/2, delta/2, 0, 0],
        [-delta/2, delta/2, -delta/2, delta/2],
        [-delta/2, delta/2, -delta/2+1e-9, delta/2-1e-9],
        [-delta/2, -delta/3, delta/4, delta/2],
    ]
    for ts in patterns:
        E=circle_dft_error(ts)
        check(E+1e-12 >= delta/8, "circular arc delta/8")
        if delta <= 0.125:
            check(E+1e-12 >= 9*delta/40, "circular arc 9/40")

for _ in range(160):
    delta=rng.uniform(1e-4,0.5)
    mids=[rng.uniform(-delta/2,delta/2) for _ in range(2)]
    ts=[-delta/2,delta/2]+mids
    rng.shuffle(ts)
    E=circle_dft_error(ts)
    check(E+1e-12 >= delta/8, "random circular arc bound")

# 3. Exact automorphism/baseline identities and hyperbolic formula.
for r in [0.5,0.7,0.9,0.99,0.999]:
    A=1-r*r
    for t in [-0.3,-0.05,0.01,0.2]:
        z=r*cmath.exp(1j*t)
        u=phi_inv(r,z)
        check(abs(phi(r,u)-z)<1e-11, "phi inverse")
        lhs=G(r,u)
        rhs=r*(cmath.exp(1j*t)-1)/A
        check(abs(lhs-rhs)<1e-10, "baseline identity")
        d=hypdist(r+0j,z)
        formula=2*math.asinh(2*r*abs(math.sin(t/2))/A)
        check(close(d,formula,1e-9), "hyperbolic distance formula")

# 4. rho bound in terms of R.
for _ in range(180):
    r=rng.uniform(0.5,0.9999)
    eps=1-r
    R=10**rng.uniform(-1,3)
    delta=min(R*eps,0.45)
    # redefine actual R if clipped
    Ract=delta/eps
    t=delta/2
    u=phi_inv(r,r*cmath.exp(1j*t))
    rh=abs(u)
    x=Ract/4
    rhobar=x/math.sqrt(1+x*x)
    check(rh <= rhobar+1e-12, "rho <= rhobar")
    check(1-rhobar+1e-12 >= 8/(Ract*Ract+16), "rho gap bound")

# 5. Improved floor contradiction constants.
check(3/(40*math.sqrt(2)) > 33/640, "floor constant gap")
for rho in [j/1600 for j in range(0,101)]: # through 1/16
    factor=(3-2*rho)/(1-rho)**2
    check(factor < 3.3+1e-12, "coefficient factor < 33/10")

# At R<=1/4, upper spectral capacity < lower required mass.
for R in [0.001,0.01,0.05,0.1,0.2,0.249999]:
    rho=R/4
    upper=rho*rho*(3-2*rho)/(1-rho)**2
    lower=3*R/(40*math.sqrt(2))
    check(upper < lower, "R<=1/4 contradiction")

# 6. Spectral corridor definitions and tail formulas.
c0=1/(24*math.sqrt(2))

def rhobar(R):
    x=R/4
    return x/math.sqrt(1+x*x)

def low_sum(N):
    if N<2:
        return 0.0
    return (N+1)*(N+2)/2-3

def tail_sum(x,N):
    # sum n>N of (n+1)x^n
    m=N+1
    return (x**m)*((m+1)-m*x)/(1-x)**2

def Nminus(R):
    target=c0*R/4
    n=1
    while low_sum(n+1)<=target:
        n+=1
    return n

def Nplus(R):
    x=rhobar(R)
    target=c0*R/4
    # binary search
    lo=1
    hi=2
    while tail_sum(x,hi)>target:
        hi*=2
        if hi>10**12:
            raise RuntimeError("Nplus search too large")
    while lo+1<hi:
        mid=(lo+hi)//2
        if tail_sum(x,mid)<=target:
            hi=mid
        else:
            lo=mid
    return hi

for R in [10,100,1e3,1e4]:
    nm=Nminus(R)
    np_=Nplus(R)
    check(low_sum(nm)<=c0*R/4+1e-12, "Nminus low cap")
    check(tail_sum(rhobar(R),np_)<=c0*R/4*(1+1e-12), "Nplus tail cap")
    check(np_>nm, "corridor nonempty")

# asymptotic sanity: Nminus/sqrt(R) bounded away from 0/infinity at large R
for R in [1e4,1e5,1e6]:
    nm=Nminus(R)
    ratio=nm/math.sqrt(R)
    check(0.05 < ratio < 0.25, "Nminus theta sqrtR")

# Explicit O(R^2 log R) envelope used in notes (not claimed optimized).
for R in [0.25,0.5,1,2,4,10,100,1000]:
    N=math.ceil(2*(R*R+16)*math.log(R+2))
    check(tail_sum(rhobar(R),N) <= c0*R/4, "explicit high cutoff envelope")

# 7. Cauchy-Schwarz energy inequality and log denominator.
for R in [0.25,0.5,1,2,10,100,1000]:
    rb=rhobar(R)
    logupper=math.log((R*R+16)/8)
    exactL=-math.log(1-rb)-rb
    check(exactL <= logupper+1e-12, "log upper for harmonic sum")
    bound=R*R/(1152*logupper)
    check(bound>0, "energy lower positive")

# Random finite sequences: W^2 <= E*L_partial.
for _ in range(120):
    rho=rng.uniform(0.05,0.98)
    N=rng.randint(5,80)
    ds=[0,0]+[(rng.uniform(-1,1)+1j*rng.uniform(-1,1)) for _ in range(2,N+1)]
    W=sum(abs(ds[n])*rho**n for n in range(2,N+1))
    E=sum(n*abs(ds[n])**2*rho**n for n in range(2,N+1))
    L=sum(rho**n/n for n in range(2,N+1))
    check(W*W <= E*L+1e-10, "Cauchy Schwarz spectral energy")

# 8. Modulus telescoping and critical rainbow.
for N in [2,3,10,50,100,1000]:
    qs=[1-j/(3*N) for j in range(N+1)]
    mods=[math.log(qs[j]/qs[j+1])/math.pi for j in range(N)]
    total=sum(mods)
    target=math.log(1.5)/math.pi
    check(close(total,target,1e-11), "rainbow modulus telescope")

# 9. Möbius calibration has zero Schwarzian and runaway scale law.
# M_c(z)=z/(1+cz); derivatives yield S=0 exactly. Numeric finite differences are avoided;
# verify coefficient identity b3-b2^2=0 and position law.
for c in [0,0.2,0.7,0.9,0.99,0.999]:
    b2=-c
    b3=c*c
    check(abs(b3-b2*b2)<1e-15, "Mobius Schwarzian coefficient locus")
    if c<1:
        smax=(1+math.sqrt(2))/(1-c)
        check(close((1-c)*smax,1+math.sqrt(2),1e-12), "Mobius runaway position law")

# 10. Symbolic-style derivative-strain identity tested numerically for explicit univalent polynomials.
# f(z)=z+a z^2 with |a| small. Integrands are checked pointwise under change of variables.
for acoef in [0.03+0.02j,-0.05+0.01j,0.08-0.03j]:
    def fp(z):
        return 1+2*acoef*z
    for r in [0.55,0.8,0.95]:
        A=1-r*r
        for u in [0.1+0.05j,-0.2+0.1j,0.3j,-0.35+0.02j]:
            z=phi(r,u)
            phip=A/(1+r*u)**2
            Dp=(1/(1+r*u)**2)*(fp(z)/fp(r)-1)
            lhs=abs(Dp)**2
            rhs=(abs(fp(z)-fp(r))**2/(A*A*abs(fp(r))**2))*abs(phip)**2
            # rhs is the z-integrand times Jacobian density relative to dA_u
            check(close(lhs,rhs,1e-10), "strain change-of-vars density")

print(f"v193 verifier: {checks}/{checks} checks pass")
