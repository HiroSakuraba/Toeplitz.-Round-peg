#!/usr/bin/env python3
import cmath
import math
import random

TOL=2e-9
checks=0

def ck(name,cond,detail=''):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(f'{name} FAIL {detail}')

def close(a,b,tol=TOL):
    return abs(a-b) <= tol*max(1.0,abs(a),abs(b))

def beta(a,b):
    return abs((a-b)/(1-a.conjugate()*b))

def phi(a,u):
    return (a+u)/(1+a.conjugate()*u)

def disk_params(r,q):
    den=1-r*r*q*q
    C=r*(1-q*q)/den
    S=q*(1-r*r)/den
    dp=(1-r)*(1-q)/(1+r*q)
    dm=(1-r)*(1+q)/(1-r*q)
    return C,S,dp,dm

def q_exact(r,delta):
    H=2*r*math.sin(delta/4)/(1-r*r)
    rho=H/math.sqrt(1+H*H)
    return math.sqrt(rho),rho,H

rng=random.Random(194)

# 1. Exact pseudohyperbolic disk formulas.
for _ in range(300):
    r=rng.uniform(0.05,0.995)
    q=rng.uniform(0.02,0.995)
    C,S,dp,dm=disk_params(r,q)
    zp=(r+q)/(1+r*q)
    zm=(r-q)/(1-r*q)
    ck('center-radius intercept +',close(C+S,zp,1e-10))
    ck('center-radius intercept -',close(C-S,zm,1e-10))
    ck('outer depth',close(1-zp,dp,1e-10))
    ck('inner depth',close(1-zm,dm,1e-10))
    # random boundary points via automorphism must lie on Euclidean circle
    th=rng.uniform(0,2*math.pi)
    z=phi(r,q*cmath.exp(1j*th))
    ck('boundary circle',close(abs(z-C),S,2e-9),f'{r=} {q=} {z=} {C=} {S=}')

# 2. Exact rho formula from extreme Abel parameter.
for _ in range(200):
    r=rng.uniform(0.5,0.9999)
    delta=rng.uniform(1e-5,0.45)
    q,rho,H=q_exact(r,delta)
    t=delta/2
    z=r*cmath.exp(1j*t)
    u=(z-r)/(1-r*z)
    ck('rho extreme formula',close(abs(u),rho,2e-9),f'{abs(u)=} {rho=}')
    ck('q sqrt rho',close(q*q,rho,1e-12))

# 3. Parabolic tangent disk law over finite X.
for X in [0.02,0.1,0.5,1,2,4,10,50]:
    for eps in [1e-5,3e-7,1e-8]:
        R=math.sqrt(X/eps)
        delta=R*eps
        r=1-eps
        q,_,_=q_exact(r,delta)
        C,S,_,_=disk_params(r,q)
        Ct=4/(X+4)
        St=X/(X+4)
        # error decreases with eps; loose finite-eps envelope
        err=80*math.sqrt(eps/X) if X>0 else 1
        ck('parabolic C limit',abs(C-Ct)<max(2e-5,err),f'{X=} {eps=} {C=} {Ct=}')
        ck('parabolic S limit',abs(S-St)<max(2e-5,err),f'{X=} {eps=} {S=} {St=}')
        ck('limit tangent identity',close(Ct+St,1,1e-14))

# subparabolic and superparabolic asymptotic samples
for eps in [1e-8,1e-10]:
    # R=eps^-0.4 => runaway, X=eps^0.2 -> 0
    R=eps**(-0.4); delta=R*eps; r=1-eps
    q,_,_=q_exact(r,delta); C,S,_,_=disk_params(r,q)
    ck('subparabolic local C',C>0.9)
    ck('subparabolic local S',S<0.1)
    # R=eps^-0.6 => X=eps^-0.2 -> infinity
    R=eps**(-0.6); delta=R*eps; r=1-eps
    q,_,_=q_exact(r,delta); C,S,_,_=disk_params(r,q)
    ck('superparabolic C',C<0.15)
    ck('superparabolic S',S>0.85)

# 4. Uniform separation and infinite-overlap parabolic sequence.
for k in range(8,25):
    eps=2.0**(-k)
    a=1-eps
    b=1-eps/2
    sep=beta(a+0j,b+0j)
    ck('consecutive sep >1/3',sep>=1/3-2e-15, f'{k=} {sep=}')
    ck('exact sep formula',close(sep,1/(3-eps),1e-10))
    delta=math.sqrt(eps)
    q,_,_=q_exact(a,delta)
    # fixed x=0.8 lies in all sufficiently large natural disks
    x=0.8+0j
    if k>=9:
        ck('fixed point in strain disk',beta(a+0j,x)<q,f'{k=} {beta(a+0j,x)=} {q=}')

# convergence to B(4/5,1/5)
for k in [10,12,16,20,24,30]:
    eps=2.0**(-k); r=1-eps; delta=math.sqrt(eps)
    q,_,_=q_exact(r,delta); C,S,_,_=disk_params(r,q)
    ck('parabolic seq center',abs(C-0.8)<0.01)
    ck('parabolic seq radius',abs(S-0.2)<0.01)

# 5. Mean-variance Pythagoras for random analytic polynomials on Euclidean disks.
# Expand g around C: g(C+w)=sum c_n w^n. Orthogonality gives exact formulas.
for _ in range(180):
    C=(rng.uniform(-0.4,0.4)+1j*rng.uniform(-0.4,0.4))
    S=rng.uniform(0.05,0.3)
    coeff=[rng.uniform(-1,1)+1j*rng.uniform(-1,1) for _ in range(6)]
    # choose an arbitrary a inside the disk
    a=C+0.7*S*cmath.exp(1j*rng.uniform(0,2*math.pi))
    ga=sum(coeff[n]*(a-C)**n for n in range(len(coeff)))
    gC=coeff[0]
    area=math.pi*S*S
    variance=math.pi*sum(abs(coeff[n])**2*S**(2*n+2)/(n+1) for n in range(1,len(coeff)))
    total=variance+area*abs(gC-ga)**2
    # Direct coefficient integral after subtracting ga: constant coeff c0-ga plus n>=1 terms.
    direct=area*abs(coeff[0]-ga)**2 + variance
    ck('variance transport pythagoras',close(total,direct,2e-12))

# 6. Cusp model checks: finite-area exponent and explicit normalized lower-bound scaling.
for alpha in [0.2,0.4,0.6,0.8]:
    ck('cusp A2 exponent',2*alpha-2>-2)
    for k in [12,16,20,24]:
        eps=2.0**(-k); r=1-eps; delta=math.sqrt(eps); R=eps**-0.5
        q,_,_=q_exact(r,delta); C,S,_,_=disk_params(r,q)
        # K=B(.8,.05) inclusion follows if distance between centers + .05 < S
        ck('fixed K inside strain disk',abs(C-0.8)+0.05<S, f'{alpha=} {k=} {C=} {S=}')
        fpa=alpha*eps**(alpha-1)
        # uniform derivative bound on K: |1-z| >= .15
        M=alpha*(0.15)**(alpha-1)
        if fpa>=2*M:
            # normalized lower bound from area(K)/4, denominator <= 4 eps^2 |fpa|^2
            Elower=math.pi/(6400*eps*eps)
            ck('cusp E lower matches R4',close(Elower,math.pi*R**4/6400,1e-12))

# 7. Separated-center sampling theorem numerical sanity for monomials on a radial separated sequence.
eta=1/3
q0=math.tanh(0.5*math.atanh(eta))
Csample=(1+q0)**4/(math.pi*q0*q0)
centers=[1-2.0**(-k) for k in range(2,12)]
for n in range(0,10):
    # g(z)=z^n, integral_D |g|^2 dA = pi/(n+1)
    lhs=sum((1-a*a)**2*(a**(2*n)) for a in centers)
    rhs=Csample*math.pi/(n+1)
    ck('sampling monomial sanity',lhs<=rhs+1e-10,f'{n=} {lhs=} {rhs=}')

# 8. Koebe approximants saturate arbitrarily long initial coefficient blocks.
for N in [5,10,25,50,100]:
    eta_block=0.02
    # ensure s^(N-1)>=1-eta_block
    s=(1-eta_block)**(1/max(1,N-1))
    for n in range(1,N+1):
        b=n*s**(n-1)
        ck('Koebe block near saturation',b+1e-12 >= (1-eta_block)*n,f'{N=} {n=} {s=} {b=}')
    # pole 1/s is outside unit disk
    ck('Koebe approximant pole outside',1/s>1)

# 9. v193 variance-rich summability constant algebra.
for R in [1,2,10,100,1000]:
    logden=math.log((R*R+16)/8)
    ck('positive v193 log',logden>0)
    # If V >= L/2 and overlap M, summing gives coefficient 2304/pi in normalized expression.
    coeff=2304/math.pi
    ck('variance sum coeff positive',coeff>700 and coeff<740)

print(f'v194 verifier: {checks}/{checks} checks pass')
