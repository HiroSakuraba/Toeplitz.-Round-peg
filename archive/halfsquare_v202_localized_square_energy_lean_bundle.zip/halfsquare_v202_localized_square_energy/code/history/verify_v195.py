#!/usr/bin/env python3
import cmath, math, random

random.seed(195)
passed = 0
failed = 0
failures = []

def check(cond, msg):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        failures.append(msg)

def dft4(vals, k):
    return sum(vals[j] * (1j ** (-k*j)) for j in range(4)) / 4.0

def inv_phi_r(z, r):
    return (z-r)/(1-r*z)

def u_formula(t, r):
    return r*(cmath.exp(1j*t)-1)/(1-r*r*cmath.exp(1j*t))

# 1. Largest-gap center geometry, 400 random quartets.
for _ in range(400):
    xs = [0.0, random.random(), random.random(), 1.0]
    xs.sort()
    # Rescale to a small packet.
    delta = random.uniform(1e-4, 0.12)
    xs = [delta*x for x in xs]
    gaps = [xs[i+1]-xs[i] for i in range(3)]
    m = max(range(3), key=lambda i: gaps[i])
    y = (xs[m]+xs[m+1])/2
    ts = [x-y for x in xs]
    check(max(ts)-min(ts) >= delta*(1-1e-12), "range lost under recenter")
    check(min(abs(t) for t in ts) + 1e-14 >= delta/6, "gap center distance < delta/6")
    check(max(abs(t) for t in ts) <= delta*(1+1e-12), "gap center exceeds packet")

# 2. Exact preimage formulas and |1+u| bound, 800 checks.
for _ in range(200):
    r = random.uniform(0.5, 0.9999)
    eps = 1-r
    R = random.uniform(100, 5000)
    delta = min(R*eps, 0.12)
    # Require actual R=delta/eps still large after cap.
    Ract = delta/eps
    if Ract < 20:
        continue
    # construct a t safely away from zero per gap-center theorem
    mag = random.uniform(delta/6, delta)
    t = mag if random.random() < 0.5 else -mag
    z = r*cmath.exp(1j*t)
    u1 = inv_phi_r(z, r)
    u2 = u_formula(t, r)
    check(abs(u1-u2) < 1e-11, "inverse Mobius formula mismatch")
    lhs = abs(1+u1)
    rhs = 12*math.pi/Ract
    check(lhs <= rhs*(1+1e-10), f"boundary closeness failed: {lhs} > {rhs}")
    for n in (1,2,3,5):
        check(abs(u1**n - (-1)**n) <= n*abs(1+u1)*(1+1e-10), "power telescoping failed")

# 3. DFT baseline gap for arbitrary labels/range, 400 random quartets.
for _ in range(400):
    delta = random.uniform(1e-5, 0.12)
    vals = [-delta/2, delta/2, random.uniform(-delta/2, delta/2), random.uniform(-delta/2, delta/2)]
    random.shuffle(vals)
    lin = math.sqrt(abs(dft4(vals,2))**2 + abs(dft4(vals,3))**2)
    check(lin + 1e-14 >= delta/4, "real-vector DFT gap failed")
    q = [cmath.exp(1j*t)-1 for t in vals]
    qgap = math.sqrt(abs(dft4(q,2))**2 + abs(dft4(q,3))**2)
    check(qgap + 1e-14 >= delta/8, "circular-arc DFT gap failed")

# 4. Moment O(n/R) bound after actual largest-gap normalization.
for _ in range(200):
    r = random.uniform(0.8, 0.99999)
    eps = 1-r
    Rtarget = random.uniform(100, 3000)
    delta = min(Rtarget*eps, 0.1)
    R = delta/eps
    if R < 30:
        continue
    a = random.uniform(0.05, 0.3)
    b = random.uniform(a+0.05, 0.65)
    xs = [0.0, a*delta, b*delta, delta]
    gaps = [xs[i+1]-xs[i] for i in range(3)]
    m = max(range(3), key=lambda i: gaps[i])
    y = (xs[m]+xs[m+1])/2
    ts = [x-y for x in xs]
    # arbitrary square labels: shuffle the parameter assignment
    random.shuffle(ts)
    us = [u_formula(t,r) for t in ts]
    for n in (1,2,5,10):
        for k in (2,3):
            M = dft4([u**n for u in us], k)
            check(abs(M) <= (12*math.pi*n/R)*(1+1e-9), "moment n/R bound failed")

# 5. Low-block asymptotic estimate: for large R, N=R^(2/3)/64 contributes < R/48.
for R in [1e4, 3e4, 1e5, 3e5, 1e6, 3e6, 1e7]:
    N = int(R**(2/3)/64)
    if N < 2:
        continue
    s = sum(n*(n+1) for n in range(2, N+1))
    low = 12*math.pi*math.sqrt(2)*s/R
    check(low <= R/48, f"low block constant failed R={R}, N={N}, low/R={low/R}")

# 6. Transport-rich threshold tends to zero in all three illustrative runaway scalings.
def q_rho_from_r_delta(r, delta):
    H = 2*r*math.sin(delta/4)/(1-r*r)
    rho = H/math.sqrt(1+H*H)
    return math.sqrt(rho)

def disk_CS(r,q):
    den = 1-r*r*q*q
    C = r*(1-q*q)/den
    S = q*(1-r*r)/den
    return C,S

def tr_threshold(r,R,S):
    return (1-r*r)*R/(48*S*math.sqrt(math.log((R*R+16)/8)))

# subparabolic: eps=R^-3 -> X=R^-1
for R in [50,100,200,500,1000]:
    eps = R**-3
    r = 1-eps
    delta = R*eps
    q = q_rho_from_r_delta(r,delta)
    C,S = disk_CS(r,q)
    th = tr_threshold(r,R,S)
    check(th < 1.0 and th > 0, "subparabolic threshold bad")
# parabolic: eps=R^-2 -> X=1
for R in [50,100,200,500,1000]:
    eps = R**-2
    r = 1-eps
    delta = R*eps
    q = q_rho_from_r_delta(r,delta)
    C,S = disk_CS(r,q)
    th = tr_threshold(r,R,S)
    check(th < 0.1 and th > 0, "parabolic threshold bad")
# superparabolic: eps=R^-3/2 -> X=R^1/2, delta=R^-1/2
for R in [100,400,1600,6400]:
    eps = R**-1.5
    r = 1-eps
    delta = R*eps
    q = q_rho_from_r_delta(r,delta)
    C,S = disk_CS(r,q)
    th = tr_threshold(r,R,S)
    check(th < 0.1 and th > 0, "superparabolic threshold bad")

# 7. Smooth quadratic transport calibration: T/L -> infinity on parabolic scales.
a = 0.1
ratios=[]
for R in [50,100,200,400,800,1600]:
    eps=R**-2
    r=1-eps
    delta=R*eps
    q=q_rho_from_r_delta(r,delta)
    C,S=disk_CS(r,q)
    gp_r=1+2*a*r
    gp_C=1+2*a*C
    T=math.pi*S*S*abs(gp_C-gp_r)**2
    L=math.pi*(1-r*r)**2*abs(gp_r)**2*R*R/(1152*math.log((R*R+16)/8))
    ratios.append(T/(0.5*L))
    check(T > 0.5*L, "smooth quadratic not transport-rich eventually")
for x,y in zip(ratios,ratios[1:]):
    check(y > x, "quadratic transport/L ratio not increasing")

# 8. Power tangent scaling: endpoint images stay separated and all limits lie on two rays.
for alpha in [0.2,0.5,0.8,1.0,1.3,1.7,1.9]:
    sep = abs((0.5j)**alpha - (-0.5j)**alpha)
    expected = (2**(1-alpha))*math.sin(math.pi*alpha/2)
    check(abs(sep-expected) < 1e-12, "power endpoint separation formula failed")
    check(sep > 0, "power endpoint separation zero")
    for s in [-0.5,-0.2,0,0.17,0.5]:
        w = (-1j*s)**alpha if s != 0 else 0j
        if s > 0:
            target = -math.pi*alpha/2
            # principal argument
            check(abs(cmath.phase(w)-target) < 1e-12, "positive-s ray phase failed")
        elif s < 0:
            target = math.pi*alpha/2
            check(abs(cmath.phase(w)-target) < 1e-12, "negative-s ray phase failed")
        else:
            check(w == 0, "zero power limit failed")

# 9. Direct asymptotic check for f_alpha normalized packet.
for alpha in [0.4,0.8,1.2,1.6]:
    for k in [100,300,1000]:
        delta = 1.0/k
        eps = delta*delta  # R=k -> infinity
        r=1-eps
        for s in [-0.5,-0.17,0.11,0.5]:
            t=delta*s
            z=r*cmath.exp(1j*t)
            scaled=(1-z)**alpha/(delta**alpha)
            limit=(-1j*s)**alpha if s != 0 else 0j
            # convergence is O(eps/delta + delta)
            check(abs(scaled-limit) < 0.08, "power scaling convergence too slow")

print(f"PASS {passed}")
print(f"FAIL {failed}")
if failures:
    for msg in failures[:30]:
        print("FAILURE:", msg)
    raise SystemExit(1)
