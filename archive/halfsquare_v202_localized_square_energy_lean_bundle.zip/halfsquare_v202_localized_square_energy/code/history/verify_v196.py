#!/usr/bin/env python3
import cmath, math, random
import sympy as sp

random.seed(196)
passed=0; failed=0; failures=[]
def check(cond,msg):
    global passed,failed
    if cond: passed+=1
    else:
        failed+=1; failures.append(msg)

def dft4(vals,k):
    return sum(vals[j]*(1j**(-k*j)) for j in range(4))/4.0

def vec23(vals):
    return (dft4(vals,2),dft4(vals,3))

def norm(v): return math.sqrt(sum(abs(z)**2 for z in v))
def inner(u,v): return sum(u[j].conjugate()*v[j] for j in range(len(u)))
def project_perp(v,S):
    den=inner(S,S)
    if abs(den)<1e-30: return v
    c=inner(S,v)/den
    return tuple(v[j]-c*S[j] for j in range(len(v)))
def trans(v,S):
    nv=norm(v); ns=norm(S)
    if nv==0 or ns==0: return 1.0
    c=abs(inner(S,v))/(nv*ns)
    c=min(1,max(0,c))
    return math.sqrt(max(0,1-c*c))

def u_formula(t,r):
    return r*(cmath.exp(1j*t)-1)/(1-r*r*cmath.exp(1j*t))

def s_formula(t,r):
    return (1-r)*(1+r*cmath.exp(1j*t))/(1-r*r*cmath.exp(1j*t))

# 1. Symbolic resultants for the three inequivalent square-order types.
a,b,y=sp.symbols('a b y', real=True)
xs=[sp.Integer(0),a,b,sp.Integer(1)]
I=sp.I
w2=[1,-1,1,-1]
w3=[1,I,-1,-I]
reps=[(0,1,2,3),(0,1,3,2),(0,2,1,3)]
expected_extra=[1+a-b,a+b-1,1+b-a]
for idx,p in enumerate(reps):
    vals=[xs[q] for q in p]
    V2=sum(w2[j]*vals[j] for j in range(4))
    V3=sum(w3[j]*vals[j] for j in range(4))
    qv=[1/(vals[j]-y) for j in range(4)]
    Q2=sum(w2[j]*qv[j] for j in range(4))
    Q3=sum(w3[j]*qv[j] for j in range(4))
    num=sp.factor(sp.together(V2*Q3-V3*Q2).as_numer_denom()[0])
    re,im=sp.expand_complex(num).as_real_imag()
    res=sp.factor(sp.resultant(sp.factor(re),sp.factor(im),y))
    base=sp.factor(a*b*(1-a)*(b-a)*(1-b)*expected_extra[idx])
    ratio=sp.simplify(res/base)
    check(sp.simplify(ratio).is_number and ratio != 0, f"resultant factor mismatch {p}: {res}")

# interleaved symmetric locus: unique alignment y=1/2, but not identically zero.
p=reps[1]
vals=[xs[q] for q in p]
V2=sum(w2[j]*vals[j] for j in range(4)); V3=sum(w3[j]*vals[j] for j in range(4))
qv=[1/(vals[j]-y) for j in range(4)]
Q2=sum(w2[j]*qv[j] for j in range(4)); Q3=sum(w3[j]*qv[j] for j in range(4))
D=sp.factor(sp.together(V2*Q3-V3*Q2))
Ds=sp.factor(D.subs(b,1-a))
num_s=sp.factor(sp.together(Ds).as_numer_denom()[0])
check(sp.simplify(num_s.subs(y,sp.Rational(1,2)))==0,"symmetric interleaved y=1/2 not zero")
check(sp.simplify(sp.diff(num_s,y))!=0,"symmetric interleaved determinant accidentally identically zero")

# 2. Numerical compact-shape transversality catalog.
# Search the middle third of every gap and take the best center.
def best_safe_trans(shape,p,grid=21):
    x0,x1,x2,x3=shape
    xlab=[shape[q] for q in p]
    V=vec23(xlab)
    gaps=[(x0,x1),(x1,x2),(x2,x3)]
    best=0.0; besty=None
    for lo,hi in gaps:
        A=lo+(hi-lo)/3; B=hi-(hi-lo)/3
        for m in range(grid):
            yy=A+(B-A)*(m+0.5)/grid
            Q=vec23([1/(xx-yy) for xx in xlab])
            tr=trans(V,Q)
            if tr>best: best=tr; besty=yy
    return best,besty

for eta in [0.05,0.1,0.2]:
    observed=1.0
    for _ in range(180):
        # sample gap simplex with each gap >= eta
        u=[random.random() for _ in range(3)]
        su=sum(u)
        rem=1-3*eta
        gs=[eta+rem*z/su for z in u]
        shape=(0.0,gs[0],gs[0]+gs[1],1.0)
        for p in reps:
            tr,yy=best_safe_trans(shape,p)
            observed=min(observed,tr)
            check(tr>1e-5,"compact shape had vanishing best transversality")
            check(min(abs(xx-yy) for xx in shape)>=eta/3-1e-12,"chosen safe center too close to a point")
    # loose empirical sanity: larger eta should not have catastrophic constant
    check(observed>1e-3,f"empirical transversality too small eta={eta}: {observed}")

# 3. Exact Möbius asymptotics and projected second-order moment estimate.
for _ in range(320):
    eta=0.08
    u=[random.random() for _ in range(3)]; su=sum(u); rem=1-3*eta
    gs=[eta+rem*z/su for z in u]
    shape=(0.0,gs[0],gs[0]+gs[1],1.0)
    p=random.choice(reps)
    tr0,yy=best_safe_trans(shape,p,grid=31)
    xlab=[shape[q] for q in p]
    R=random.uniform(2e3,2e5)
    delta=random.uniform(2e-5,2e-3)
    eps=delta/R
    r=1-eps
    ts=[delta*(xx-yy) for xx in xlab]
    nus=[u_formula(t,r) for t in ts]
    ss=[1+z for z in nus]
    # exact s identity
    for t,s in zip(ts,ss):
        check(abs(s-s_formula(t,r))<1e-10,"exact s formula mismatch")
    S=vec23(ss)
    # baseline
    G=[r*(cmath.exp(1j*t)-1)/(1-r*r) for t in ts]
    B=vec23(G)
    # leading vectors
    V=vec23(xlab)
    Q=vec23([1/(xx-yy) for xx in xlab])
    check(trans(B,S)>max(1e-7,0.15*tr0),"exact B/S transversality lost unexpectedly")
    sigma=max(abs(s) for s in ss)
    for n in [2,3,5,10,20]:
        if n*sigma>0.45: continue
        M=vec23([z**n for z in nus])
        PM=project_perp(M,S)
        # universal conservative remainder constant under n*sigma <= .45
        check(norm(PM)<=2.0*n*n*sigma*sigma*(1+1e-9),
              f"projected second-order bound failed n={n}, ratio={norm(PM)/(n*n*sigma*sigma)}")

# 4. Scaling exponent sanity: projected low block behaves N^4/R^2.
for R in [1e4,1e6,1e8,1e10]:
    for c in [0.02,0.05,0.1]:
        N=max(2,int(c*R**0.75))
        s=sum((n+1)*n*n for n in range(2,N+1))
        ratio=(s/R**2)/R
        # asymptotic ratio should be about c^4/4
        target=c**4/4
        check(ratio < 2.0*target+1e-12 and ratio > 0.35*target,
              f"N^4/R^3 scaling mismatch R={R} c={c}: {ratio} vs {target}")

# 5. Collision simplex classification.
def classify(lams,tol=1e-3):
    z=[i for i,x in enumerate(lams) if x<tol]
    if len(z)==0: return 'interior'
    if len(z)==1: return '2+1+1'
    if len(z)==2:
        if z==[0,2]: return '2+2'
        return '3+1'
    return 'invalid'
for examples,label in [
    ((.2,.3,.5),'interior'),
    ((1e-6,.4,.599999),'2+1+1'),
    ((1e-6,2e-6,.999997),'3+1'),
    ((1e-6,.999998,1e-6),'2+2'),
    ((.499999,1e-6,.5),'2+1+1')]:
    check(classify(examples)==label,f"collision classify {examples}")

# 6. Off-center power tangent: comparable-offset convergence to one/two rays.
for alpha in [0.35,0.7,1.0,1.4,1.8]:
    for lam in [-2.0,-0.3,0.0,0.8,3.0]:
        delta=2e-4; eps=delta*delta; r=1-eps; c=lam*delta
        svals=[-0.5,-0.12,0.21,0.5]
        actual=[]; target=[]
        for s in svals:
            z=r*cmath.exp(1j*(c+delta*s))
            actual.append((1-z)**alpha/(delta**alpha))
            target.append((-1j*(lam+s))**alpha if lam+s != 0 else 0j)
        err=max(abs(a-t) for a,t in zip(actual,target))
        check(err<0.02,f"comparable-offset power convergence alpha={alpha} lam={lam} err={err}")
        # endpoint target separation positive
        check(abs(target[0]-target[-1])>1e-8,"comparable power endpoints coincided")

# 7. Large-offset power profile linearizes.
for alpha in [0.4,0.8,1.2,1.7]:
    for lam in [30,100,300]:
        delta=1e-6
        c=lam*delta
        eps=delta*delta
        r=1-eps
        q=1-r*cmath.exp(1j*c)
        scale=-alpha*1j*r*cmath.exp(1j*c)*(q**(alpha-1))*delta
        vals=[]
        svals=[-0.5,-0.1,0.2,0.5]
        base=q**alpha
        for s in svals:
            z=r*cmath.exp(1j*(c+delta*s))
            vals.append(((1-z)**alpha-base)/scale)
        err=max(abs(v-s) for v,s in zip(vals,svals))
        check(err<0.08,f"large-offset linearization alpha={alpha} lam={lam} err={err}")

print(f"PASS {passed}")
print(f"FAIL {failed}")
if failures:
    for msg in failures[:50]: print('FAILURE:',msg)
    raise SystemExit(1)
