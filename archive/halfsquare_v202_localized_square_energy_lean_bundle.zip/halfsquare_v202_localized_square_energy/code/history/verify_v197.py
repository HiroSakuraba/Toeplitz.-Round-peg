#!/usr/bin/env python3
import cmath, math, random
random.seed(197)
passed=0; failed=0; failures=[]
def check(cond,msg):
    global passed,failed
    if cond: passed+=1
    else:
        failed+=1; failures.append(msg)

def dft4(vals,k): return sum(vals[j]*(1j**(-k*j)) for j in range(4))/4.0
def vec23(vals): return (dft4(vals,2),dft4(vals,3))
def norm(v): return math.sqrt(sum(abs(z)**2 for z in v))
def inner(u,v): return sum(u[j].conjugate()*v[j] for j in range(len(u)))
def trans(v,S):
    nv=norm(v); ns=norm(S)
    if nv<1e-30 or ns<1e-30: return 0.0
    c=abs(inner(S,v))/(nv*ns); c=min(1.0,max(0.0,c))
    return math.sqrt(max(0.0,1-c*c))
def project_perp(v,S):
    den=inner(S,S)
    if abs(den)<1e-30: return v
    c=inner(S,v)/den
    return tuple(v[j]-c*S[j] for j in range(len(v)))
def u_formula(t,r): return r*(cmath.exp(1j*t)-1)/(1-r*r*cmath.exp(1j*t))
def s_formula(t,r): return (1-r)*(1+r*cmath.exp(1j*t))/(1-r*r*cmath.exp(1j*t))
reps=[(0,1,2,3),(0,1,3,2),(0,2,1,3)]

def shape_det(shape,p,y):
    vals=[shape[q] for q in p]
    V=vec23(vals)
    Q=vec23([1/(z-y) for z in vals])
    return V[0]*Q[1]-V[1]*Q[0]

def best_at_centers(shape,p,centers):
    vals=[shape[q] for q in p]; V=vec23(vals)
    best=0.0; by=None
    for y in centers:
        if min(abs(z-y) for z in shape)<1e-14: continue
        Q=vec23([1/(z-y) for z in vals])
        t=trans(V,Q)
        if t>best: best=t; by=y
    return best,by

def best_safe_trans(shape,p,allowed_gaps=None,grid=13):
    vals=[shape[q] for q in p]; V=vec23(vals)
    best=0.0; by=None
    for i in range(3):
        if allowed_gaps is not None and i not in allowed_gaps: continue
        lo,hi=shape[i],shape[i+1]
        if hi-lo<1e-14: continue
        A=lo+(hi-lo)/3; B=hi-(hi-lo)/3
        for m in range(grid):
            y=A+(B-A)*(m+.5)/grid
            Q=vec23([1/(z-y) for z in vals])
            t=trans(V,Q)
            if t>best: best=t; by=y
    return best,by

# 1. Exact edge samples: all three order types remain transverse when one gap is zero.
for edge in range(3):
    for q in range(1,100):
        t=q/100
        if edge==0: shape=(0.0,0.0,t,1.0); centers=[t/2,(t+1)/2]
        elif edge==1: shape=(0.0,t,t,1.0); centers=[t/2,(t+1)/2]
        else: shape=(0.0,t,1.0,1.0); centers=[t/2,(t+1)/2]
        for p in reps:
            vals=[]
            for y in centers:
                if min(abs(z-y) for z in shape)>1e-12: vals.append(abs(shape_det(shape,p,y)))
            check(max(vals)>1e-5,f'edge determinant vanished edge={edge} t={t} p={p}')

# 2. Pair-centroid identities, numeric exactness.
for _ in range(500):
    A=complex(random.uniform(-2,2),random.uniform(-2,2)); B=complex(random.uniform(-2,2),random.uniform(-2,2))
    d=complex(random.uniform(-2,2),random.uniform(-2,2)); e=complex(random.uniform(-2,2),random.uniform(-2,2))
    Z=[A+d,A-d,B+e,B-e]
    h2=dft4(Z,2); h3=dft4(Z,3)
    check(abs(h2-(d+e)/2)<1e-12,'pair h2')
    check(abs(h3-(1-1j)*(1j*(A-B)+d-e)/4)<1e-12,'pair h3')
    Z=[complex(random.random(),random.random()) for _ in range(4)]
    OA=(Z[0]+Z[2])/2; OB=(Z[1]+Z[3])/2
    check(abs(dft4(Z,2)-(OA-OB)/2)<1e-12,'opposite centroid')

# 3. Edge-stable numerical transversality with one arbitrarily tiny gap.
for eta in [0.04,0.08,0.15]:
    for _ in range(260):
        tiny_index=random.randrange(3)
        tiny=10**random.uniform(-10,math.log10(eta/20))
        rem=1-tiny; u=random.uniform(eta,rem-eta)
        gs=[0.,0.,0.]; others=[i for i in range(3) if i!=tiny_index]
        gs[tiny_index]=tiny; gs[others[0]]=u; gs[others[1]]=rem-u
        shape=(0.,gs[0],gs[0]+gs[1],1.)
        allowed=[i for i,g in enumerate(gs) if g>=eta/2]
        for p in reps:
            tr,y=best_safe_trans(shape,p,allowed)
            check(tr>0.05,f'edge stable tr={tr} eta={eta} gs={gs} p={p}')
            check(y is not None,'edge center missing')

# vertex helpers
def vertex_shape(kind,tau,alpha):
    if kind=='left3': gs=[alpha*tau,(1-alpha)*tau,1-tau]
    elif kind=='right3': gs=[1-tau,alpha*tau,(1-alpha)*tau]
    elif kind=='22': gs=[alpha*tau,1-tau,(1-alpha)*tau]
    else: raise ValueError
    return (0.,gs[0],gs[0]+gs[1],1.),gs

def outer_centers(kind,shape,p):
    if kind=='left3': return [(shape[2]+1)/2]
    if kind=='right3': return [shape[1]/2]
    return [1/3,2/3] if p==reps[1] else [0.5]

def inner_center(kind,shape,gs):
    inds=[0,1] if kind=='left3' else ([1,2] if kind=='right3' else [0,2])
    i=max(inds,key=lambda j:gs[j])
    return (shape[i]+shape[i+1])/2

# 4. Outer vertex law: exact shape transversality is Theta(tau).
for kind in ['left3','right3','22']:
    for _ in range(500):
        tv=10**random.uniform(-7,-2); av=random.random(); shape,gs=vertex_shape(kind,tv,av)
        for p in reps:
            tr,y=best_at_centers(shape,p,outer_centers(kind,shape,p))
            check(tr>0.02*tv,f'outer lower {kind} tr/tau={tr/tv}')
            check(tr<100*tv,f'outer upper {kind} tr/tau={tr/tv}')

# 5. Inner cluster transversality is order one.
for kind in ['left3','right3','22']:
    for _ in range(500):
        tv=10**random.uniform(-8,-3); av=random.random(); shape,gs=vertex_shape(kind,tv,av)
        y=inner_center(kind,shape,gs)
        for p in reps:
            tr,_=best_at_centers(shape,p,[y])
            check(tr>0.30,f'inner trans {kind} tr={tr}')

# 6. Direct leading-determinant slope samples at the three vertices.
# This numerically checks nonzero first derivative in tau uniformly in alpha.
for kind in ['left3','right3','22']:
    for av in [i/40 for i in range(41)]:
        t1=1e-6; t2=5e-7
        for p in reps:
            sh1,_=vertex_shape(kind,t1,av); sh2,_=vertex_shape(kind,t2,av)
            cands1=outer_centers(kind,sh1,p); cands2=outer_centers(kind,sh2,p)
            # use matching candidate index and retain best normalized determinant slope
            slopes=[]
            for idx in range(min(len(cands1),len(cands2))):
                D1=shape_det(sh1,p,cands1[idx]); D2=shape_det(sh2,p,cands2[idx])
                slopes.append(max(abs(D1)/t1,abs(D2)/t2))
            check(max(slopes)>0.01,f'vertex determinant slope zero {kind} a={av} p={p}')

# exact Möbius helpers
def exact_BS(shape,p,y,delta,R):
    eps=delta/R; r=1-eps; vals=[shape[q] for q in p]
    ts=[delta*(x-y) for x in vals]
    nus=[u_formula(t,r) for t in ts]; ss=[1+u for u in nus]
    B=vec23([r*(cmath.exp(1j*t)-1)/(1-r*r) for t in ts]); S=vec23(ss)
    return r,ts,nus,ss,B,S

# 7. Exact Möbius outer and inner scaling for Lambda -> infinity.
for kind in ['left3','right3','22']:
    for _ in range(140):
        R=10**random.uniform(5,7)
        Lam=10**random.uniform(1.6,3.0)
        if Lam>R/20: Lam=R/20
        tv=Lam/R; av=random.random(); shape,gs=vertex_shape(kind,tv,av)
        delta=10**random.uniform(-5,-3)
        for p in reps:
            # outer
            _,yout=best_at_centers(shape,p,outer_centers(kind,shape,p))
            r,ts,nus,ss,B,S=exact_BS(shape,p,yout,delta,R)
            check(trans(B,S)>0.001*tv,f'exact outer trans lost {kind}')
            sig=max(abs(s) for s in ss)
            check(sig*R<50,f'outer s scale {kind} sigR={sig*R}')
            for t,s in zip(ts,ss): check(abs(s-s_formula(t,r))<5e-10,'s identity')
            for n in [2,3,5]:
                if n*sig<=0.4:
                    M=vec23([u**n for u in nus]); PM=project_perp(M,S)
                    check(norm(PM)<=2.5*n*n*sig*sig+2e-13,f'outer remainder {kind} n={n}')
            # inner
            yin=inner_center(kind,shape,gs)
            r,ts,nus,ss,B,S=exact_BS(shape,p,yin,delta,R)
            check(trans(B,S)>0.04,f'exact inner trans lost {kind} tr={trans(B,S)}')
            sig=max(abs(s) for s in ss)
            check(sig*Lam<120,f'inner s scale {kind} sigLam={sig*Lam}')
            for n in [2,3,5]:
                if n*sig<=0.4:
                    M=vec23([u**n for u in nus]); PM=project_perp(M,S)
                    check(norm(PM)<=2.5*n*n*sig*sig+2e-13,f'inner remainder {kind} n={n}')

# 8. Threshold exponent sanity.
for _ in range(500):
    R=10**random.uniform(5,12); Lam=10**random.uniform(1,math.log10(R)-0.3)
    Nout=(Lam*R*R)**0.25; Nin=(R*Lam*Lam)**0.25
    check(Nin<=Nout*(1+1e-12),'Nin>Nout')
    c=.04; No=max(2,int(c*Nout)); Ni=max(2,int(c*Nin))
    so=sum((n+1)*n*n for n in range(2,No+1))/R**2
    si=sum((n+1)*n*n for n in range(2,Ni+1))/Lam**2
    check(so<2e-4*Lam+1e-20,f'outer scale ratio {so/Lam}')
    check(si<2e-4*R+1e-20,f'inner scale ratio {si/R}')

# 9. Bounded-Lambda 3+1 calibration: Mobius image of limiting horocycle is a circle
# carrying a square with one vertex at the tangency image.
def Mc(z,c): return z/(1+c*z)
def Minv(w,c): return w/(1-c*w)
def fit_circle(z1,z2,z3):
    x1,y1=z1.real,z1.imag; x2,y2=z2.real,z2.imag; x3,y3=z3.real,z3.imag
    A1=2*(x2-x1); B1=2*(y2-y1); C1=x2*x2+y2*y2-x1*x1-y1*y1
    A2=2*(x3-x1); B2=2*(y3-y1); C2=x3*x3+y3*y3-x1*x1-y1*y1
    det=A1*B2-A2*B1
    cen=complex((C1*B2-C2*B1)/det,(A1*C2-A2*C1)/det)
    return cen,abs(z1-cen)
for c in [0.15,0.35,0.55,0.75]:
    hp=[-0.5+0.5*cmath.exp(1j*t) for t in [0.4,1.8,3.2]]
    cen,rad=fit_circle(*(Mc(z,c) for z in hp)); wt=Mc(-1,c)
    check(abs(abs(wt-cen)-rad)<1e-9,'tangency not on image circle')
    phi=cmath.phase(wt-cen)
    sq=[cen+rad*cmath.exp(1j*(phi+k*math.pi/2)) for k in range(4)]
    pre=[Minv(w,c) for w in sq]
    check(abs(pre[0]+1)<1e-8,'first preimage not tangency')
    for z in pre[1:]:
        check(abs(abs(z+0.5)-0.5)<1e-8,'finite preimage not on H')
        check(abs(z+1)>1e-5,'finite preimage collapsed')

print(f'PASS {passed}')
print(f'FAIL {failed}')
if failures:
    for msg in failures[:100]: print('FAILURE:',msg)
    raise SystemExit(1)
