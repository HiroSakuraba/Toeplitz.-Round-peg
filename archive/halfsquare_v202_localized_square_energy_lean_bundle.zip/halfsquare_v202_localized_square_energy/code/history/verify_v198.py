#!/usr/bin/env python3
import cmath, math, random
import mpmath as mp

random.seed(198)
passed=0; failed=0; failures=[]

def check(cond,msg):
    global passed, failed
    if cond:
        passed += 1
    else:
        failed += 1
        if len(failures)<200: failures.append(msg)

def phi(a,z):
    return (a+z)/(1+a.conjugate()*z)

def phiinv(a,w):
    return (w-a)/(1-a.conjugate()*w)

def h_ab(a,b,z):
    return phiinv(a,phi(b,z))

def c_ab(a,b):
    return (b-a)/(1-a.conjugate()*b)

def omega_ab(a,b):
    return (1-a*b.conjugate())/(1-a.conjugate()*b)

def h_closed(a,b,z):
    c=c_ab(a,b); om=omega_ab(a,b)
    return (c+om*z)/(1+c.conjugate()*om*z)

def hprime0(a,b):
    c=c_ab(a,b); om=omega_ab(a,b)
    return om*(1-abs(c)**2)

def C_map(f,fp,a,z):
    A=1-abs(a)**2
    return (f(phi(a,z))-f(a))/(A*fp(a))

def R_h(F,Fp,h,hp0,z):
    c=h(0)
    return (F(h(z))-F(c))/(Fp(c)*hp0)

def G(z): return z/(1+z)
def Ginv(x): return x/(1-x)
def U(t): return 1j*t/(1-1j*t)
def P(t,z): return Ginv(G(z)+1j*t)
def Pprime0(t): return 1/(1-1j*t)**2

def Mc(z,c): return z/(1+c*z)
def Mcp(z,c): return 1/(1+c*z)**2

def Rc_on_M(c,t,z):
    h=lambda w:P(t,w)
    hp=Pprime0(t)
    return (Mc(h(z),c)-Mc(h(0),c))/(Mcp(h(0),c)*hp)

def ct_orbit(c,t):
    a=1-c
    return 1-a/(1-1j*a*t)

def cross_ratio_ordered(vals):
    z0,z1,z2,z3=vals
    return (z1-z0)*(z3-z2)/((z2-z0)*(z3-z1))

def circle_points(r,angles): return [r*cmath.exp(1j*t) for t in angles]

# 1. Exact automorphism transition formulas.
for _ in range(5000):
    ra=random.uniform(0,0.95); rb=random.uniform(0,0.95)
    a=ra*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    b=rb*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    z=random.uniform(0,0.8)*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    check(abs(h_ab(a,b,z)-h_closed(a,b,z))<2e-12,'h closed form')
    c=c_ab(a,b); om=omega_ab(a,b)
    check(abs(abs(om)-1)<2e-12,'omega unit')
    # magnitude derivative identity
    lhs=abs(hprime0(a,b)); rhs=1-abs(c)**2
    check(abs(lhs-rhs)<3e-12,'h derivative magnitude')

# 2. Exact renormalization cocycle on a simple univalent polynomial.
# f(z)=z+q z^2 with |q|<0.2.
for _ in range(4000):
    q=random.uniform(-0.18,0.18)+1j*random.uniform(-0.18,0.18)
    f=lambda z,q=q: z+q*z*z
    fp=lambda z,q=q: 1+2*q*z
    a=random.uniform(0,0.75)*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    b=random.uniform(0,0.75)*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    z=random.uniform(0,0.65)*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    Fa=lambda w:C_map(f,fp,a,w)
    # derivative of C_a f exactly
    A=1-abs(a)**2
    phiap=lambda w: A/(1+a.conjugate()*w)**2
    Fap=lambda w: fp(phi(a,w))*phiap(w)/(A*fp(a))
    h=lambda w:h_ab(a,b,w)
    hp0=hprime0(a,b)
    lhs=C_map(f,fp,b,z)
    rhs=R_h(Fa,Fap,h,hp0,z)
    check(abs(lhs-rhs)<2e-10,'exact cocycle')
    scale=Fap(c_ab(a,b))*hp0
    target=(1-abs(b)**2)*fp(b)/((1-abs(a)**2)*fp(a))
    check(abs(scale-target)<2e-10,'scale ratio')

# 3. Parabolic transition limit from equal-radius angular shifts.
for t in [-8,-3,-1,-.25,.25,1,3,8]:
    for k in range(3,9):
        eps=10**(-k)
        r=1-eps; d=1-r*r
        theta=random.uniform(-0.05,0.05)*eps**0.2
        a=r*cmath.exp(1j*theta)
        b=r*cmath.exp(1j*(theta+d*t))
        for z in [0, .2, -.3+0.2j, .5j]:
            hv=h_ab(a,b,z)
            tol=12*(eps+abs(theta))*(1+abs(t))**3
            check(abs(hv-P(t,z))<tol,'parabolic h limit')
        check(abs(c_ab(a,b)-U(t))<12*(eps+abs(theta))*(1+abs(t))**3,'center U limit')

# 4. Parabolic group and G fixed point.
for _ in range(5000):
    s=random.uniform(-8,8); t=random.uniform(-8,8)
    z=random.uniform(0,0.75)*cmath.exp(1j*random.uniform(-math.pi,math.pi))
    check(abs(P(s,P(t,z))-P(s+t,z))<3e-12,'P group')
    lhs=(G(P(t,z))-G(U(t)))/((1/(1+U(t))**2)*Pprime0(t))
    check(abs(lhs-G(z))<3e-12,'G fixed')

# 5. Möbius calibration orbit formula and convergence to G.
for c in [0.0,0.2,0.55,0.85,0.97]:
    for t in [-20,-7,-2,-.5,.5,2,7,20]:
        ct=ct_orbit(c,t)
        check(abs(ct)<=1+1e-12,'ct remains admissible')
        for z in [0.1,-0.2,0.25j,-.3+.15j]:
            check(abs(Rc_on_M(c,t,z)-Mc(z,ct))<3e-11,'Mc orbit formula')
    for t in [1e2,1e3,1e4]:
        ct=ct_orbit(c,t)
        for z in [.2,-.2j,.3+.1j]:
            check(abs(Mc(z,ct)-G(z))<0.1/t+1e-7,'Mc orbit tends G')

# 6. Discrete parabolic-periodic non-Mobius calibration.
# H(x)=[x+eta(exp(2pi x/T)-1)]/D on Re x<1/2.
def Hper(x,T,eta):
    D=1+2*math.pi*eta/T
    return (x+eta*(cmath.exp(2*math.pi*x/T)-1))/D
def Hpper(x,T,eta):
    D=1+2*math.pi*eta/T
    return (1+(2*math.pi*eta/T)*cmath.exp(2*math.pi*x/T))/D
def Fper(z,T,eta): return Hper(G(z),T,eta)
def Fpper(z,T,eta): return Hpper(G(z),T,eta)/(1+z)**2
for T in [3.0,5.0,9.0]:
    eta=0.02
    a=2*math.pi*eta/T
    check(a*math.exp(math.pi/T)<1,'periodic univalence derivative criterion')
    for _ in range(300):
        x=random.uniform(-5,0.45)+1j*random.uniform(-10,10)
        check(Hpper(x,T,eta).real>0,'Re Hprime positive')
    for z in [.15,-.2,.25j,-.4+.1j]:
        num=Fper(P(T,z),T,eta)-Fper(U(T),T,eta)
        den=Fpper(U(T),T,eta)*Pprime0(T)
        check(abs(num/den-Fper(z,T,eta))<5e-11,'discrete periodic R_T')
        # not G
        check(abs(Fper(z,T,eta)-G(z))>1e-8 or abs(z)<1e-12,'periodic calibration non-G')

# 7. Square cross-ratio values for the three parameter-order types.
sq=[1,1j,-1,-1j]
reps=[(0,1,2,3),(0,1,3,2),(0,2,1,3)]
qvals=[]
for p in reps:
    qv=cross_ratio_ordered([sq[j] for j in p])
    qvals.append(qv)
check(abs(qvals[0]-.5)<1e-12,'square CR p0')
check(abs(qvals[1]+1)<1e-12,'square CR p1')
check(abs(qvals[2]-2)<1e-12,'square CR p2')

# 8. Exact sine formula for four concyclic ordered points.
for _ in range(6000):
    g1=random.uniform(1e-5,.5); g2=random.uniform(1e-5,.5); g3=random.uniform(1e-5,.5)
    if g1+g2+g3>1.4: continue
    ang=[0,g1,g1+g2,g1+g2+g3]
    z=circle_points(random.uniform(.2,.99),ang)
    cr=cross_ratio_ordered(z)
    rhs=math.sin(g1/2)*math.sin(g3/2)/(math.sin((g1+g2)/2)*math.sin((g2+g3)/2))
    check(abs(cr.imag)<3e-12,'circle CR real')
    check(abs(cr.real-rhs)<3e-11,'sine CR formula')
    check(0<rhs<1,'ordered CR in 0,1')

# 9. 3+1 is cross-ratio/moduli invisible: CR -> alpha.
for _ in range(5000):
    alpha=random.uniform(.02,.98)
    tau=10**random.uniform(-8,-2)
    gs=[alpha*tau,(1-alpha)*tau,1-tau]
    # use a tiny physical total angle so sine formula approximates affine shape
    delta=10**random.uniform(-5,-2)
    g1,g2,g3=[delta*x for x in gs]
    cr=math.sin(g1/2)*math.sin(g3/2)/(math.sin((g1+g2)/2)*math.sin((g2+g3)/2))
    check(abs(cr-alpha)<0.03+20*delta*delta,'3+1 CR -> alpha')

# 10. 2+2 cross ratio decays like product of pair widths / delta^2.
for _ in range(10000):
    R=10**random.uniform(2.5,8)
    Lam=random.uniform(.02,8.0)
    # split bounded inner thickness between the two pair gaps
    alpha=random.uniform(1e-4,1-1e-4)
    s1=alpha*Lam; s3=(1-alpha)*Lam
    eps=10**random.uniform(-10,-5)
    delta=R*eps
    if delta>.05:
        eps=.02/R; delta=.02
    g1=s1*eps; g3=s3*eps; g2=delta-g1-g3
    if g2<=0: continue
    cr=math.sin(g1/2)*math.sin(g3/2)/(math.sin((g1+g2)/2)*math.sin((g2+g3)/2))
    approx=g1*g3/(delta*delta)
    # uniform relative error as pair total / delta ->0 and delta->0
    rel=abs(cr/approx-1) if approx>0 else 0
    check(rel<0.08,'2+2 CR asymptotic')
    check(cr <= 1.3*(Lam*Lam)/(4*R*R),'2+2 CR upper')
    # square cross-ratio distortion lower bound, worst square |q|=1/2
    Q=.5/cr
    check(Q >= 0.3*R*R/(Lam*Lam),'2+2 CR distortion load')

# 11. Quadrilateral modulus asymptotic K(1-m)/K(m) ~ (1/pi) log(16/m).
mp.mp.dps=40
for mexp in [3,4,5,6,8,10,12]:
    m=mp.mpf(10)**(-mexp)
    M=mp.ellipk(1-m)/mp.ellipk(m)
    asym=(1/mp.pi)*mp.log(16/m)
    check(abs(float(M-asym))<0.01,'elliptic modulus asymptotic')

# 12. In bounded 2+2, modulus >= (2/pi) log R - O_L(1), numerical calibration.
for _ in range(3000):
    R=10**random.uniform(3,8); Lam=random.uniform(.1,5)
    alpha=random.uniform(.03,.97)
    eps=min(1e-6,.01/R); delta=R*eps
    g1=alpha*Lam*eps; g3=(1-alpha)*Lam*eps; g2=delta-g1-g3
    if g2<=0: continue
    cr=math.sin(g1/2)*math.sin(g3/2)/(math.sin((g1+g2)/2)*math.sin((g2+g3)/2))
    M=float(mp.ellipk(1-cr)/mp.ellipk(cr))
    lower=(2/math.pi)*math.log(R)-4.0
    check(M>lower,'2+2 modulus log lower')

# 13. Divided-difference amplification is order R/Lambda for square data.
for _ in range(6000):
    R=10**random.uniform(3,7); Lam=random.uniform(.1,6)
    alpha=random.uniform(.02,.98)
    eps=min(1e-6,.01/R); delta=R*eps
    g1=alpha*Lam*eps; g3=(1-alpha)*Lam*eps; g2=delta-g1-g3
    if g2<=0: continue
    ang=[0,g1,g1+g2,delta]
    zin=circle_points(1-eps,ang)
    p=random.choice(reps)
    zout=[sq[j] for j in p]
    def D(i,j): return abs((zout[j]-zout[i])/(zin[j]-zin[i]))
    # close pair vs one long pair from same endpoint
    ratio1=D(0,1)/D(0,2)
    ratio3=D(2,3)/D(1,3)
    check(ratio1>0.15*R/Lam,'pair1 secant amplification')
    check(ratio3>0.15*R/Lam,'pair2 secant amplification')

# 14. Three square vertices have minimal strip width s/sqrt(2).
# sample orientations and all 4 choices of omitted vertex.
for omit in range(4):
    tri=[sq[j] for j in range(4) if j!=omit]
    for k in range(720):
        theta=2*math.pi*k/720
        n=cmath.exp(1j*theta)
        projs=[(z*n.conjugate()).real for z in tri]
        width=max(projs)-min(projs)
        check(width>=1/math.sqrt(2)-1e-12,'triangle strip width')

print(f'PASS {passed}')
print(f'FAIL {failed}')
if failures:
    for msg in failures[:200]: print('FAILURE:',msg)
    raise SystemExit(1)
