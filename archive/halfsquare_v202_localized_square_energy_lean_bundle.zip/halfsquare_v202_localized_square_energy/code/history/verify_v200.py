#!/usr/bin/env python3
import cmath, math, random
import numpy as np
import sympy as sp

checks=0

def ck(cond,msg):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(msg)

# ---------- symbolic 3+1 calibration ----------
I=sp.I
X,q,e,z=sp.symbols('X q e z', real=True)
J=lambda Y: sp.simplify(Y/(1-Y))
Q=[sp.simplify(-sp.Rational(1,2)+sp.Rational(1,2)*I**j) for j in range(4)]
ck(sp.simplify(J(0)-Q[0])==0,'J(0)')
ck(sp.simplify(J(I)-Q[1])==0,'J(i)')
ck(sp.simplify(J(-I)-Q[3])==0,'J(-i)')
ck(sp.limit(J(I/q),q,0,dir='+')==Q[2],'J(infty)')

# all sides / diagonals of Q are those of a square
for j in range(4):
    d=sp.simplify(sp.Abs(Q[(j+1)%4]-Q[j])**2)
    ck(d==sp.Rational(1,2),'square side')
for j in [0,1]:
    d=sp.simplify(sp.Abs(Q[(j+2)%4]-Q[j])**2)
    ck(d==1,'square diagonal')

P=(z+sp.Rational(1,2))**4-sp.Rational(1,16)
h=I+(2*z+1)**2
psi=z+e*P*h
psip=sp.diff(psi,z)
for qj in Q:
    ck(sp.simplify(psi.subs(z,qj)-qj)==0,'Psi fixes square')

# endpoint series and critical coefficient
zq=sp.simplify(I/(q-I)) # J(i/q)
series_z=sp.series(zq,q,0,3).removeO()
ck(sp.expand(series_z-(-1+I*q+q**2))==0,'compactifier series')
crit=sp.simplify(psip.subs(z,-1))
ck(crit==1-e*(1+I)/2,'critical derivative')

# Compactified source derivatives for variables (s0,s1,q,s3)
def Jp(Y): return sp.simplify(1/(1-Y)**2)
svals=[0,1,None,-1]
ws=[]
for j,qj in enumerate(Q):
    if j==2:
        wj=sp.simplify(I*psip.subs(z,qj)) # dz/dq at q=0 is i
    else:
        s=svals[j]
        wj=sp.simplify(I*Jp(I*s)*psip.subs(z,qj))
    ws.append(wj)

a=[1,-1,1,-1]
b=[1,I,-1,-I]
cols=[]
for j,wj in enumerate(ws):
    p=sp.expand(a[j]*wj/4)
    r=sp.expand(b[j]*wj/4)
    cols.append(sp.Matrix([sp.re(p),sp.im(p),sp.re(r),sp.im(r)]))
Jac=sp.Matrix.hstack(*cols)
detJ=sp.factor(Jac.det())
ck(detJ==-e**2/sp.Integer(512),f'Jac det {detJ}')

# Exact derivative conversion numerical checks: F'(zT)=(1-iT)^2 H'(iT)
# use a random polynomial F where H=F o J
rng=random.Random(200)
for _ in range(10000):
    T=10**rng.uniform(-1,4)
    aa=complex(rng.uniform(-.3,.3),rng.uniform(-.3,.3))
    bb=complex(rng.uniform(-.2,.2),rng.uniform(-.2,.2))
    zT=1j*T/(1-1j*T)
    Fp=1+2*aa*zT+3*bb*zT*zT
    JpT=1/(1-1j*T)**2
    Hp=Fp*JpT
    lhs=(1-1j*T)**2*Hp
    ck(abs(lhs-Fp) < 1e-10*(1+abs(Fp)),'derivative conversion')

# Critical beta=1 numerical difference quotient for sample e's
for ee in [1e-4,5e-4,1e-3,2e-3,4e-3]:
    def Pn(zz): return (zz+.5)**4-1/16
    def hn(zz): return 1j+(2*zz+1)**2
    def psin(zz): return zz+ee*Pn(zz)*hn(zz)
    dcrit=1-ee*(1+1j)/2
    for T in [1e3,2e3,5e3,1e4]:
        qq=1/T
        zz=1j/(qq-1j)
        ratio=(psin(zz)-(-1))/qq
        ck(abs(ratio-1j*dcrit) < 5e-3,'beta1 quotient')

# ---------- 2+2 packet algebra ----------
def pairvec(r,th_a,th_b,N):
    n=np.arange(1,N+1,dtype=float)
    return (r**n)*(np.exp(1j*n*th_a)-np.exp(1j*n*th_b))/np.sqrt(n)

def exact_pair_norm_sq(r,Delta):
    return math.log(1+4*r*r*math.sin(Delta/2)**2/(1-r*r)**2)

# Exact finite truncations approach logarithmic norm formula and modulation correction formula.
for _ in range(2000):
    eps=10**rng.uniform(-4,-2)
    r=1-eps
    R=rng.uniform(20,100)
    delta=R*eps
    # keep angles small enough
    if delta>.7: delta=.7
    g1=rng.uniform(.3,2.0)*eps
    g3=rng.uniform(.3,2.0)*eps
    if g1+g3>delta/2:
        g1=g3=eps*.4
    # choose truncation to capture radial tail
    N=int(min(200000,max(5000,20/eps)))
    u=pairvec(r,0,delta,N)
    v=pairvec(r,g1,delta-g3,N)
    n=np.arange(1,N+1,dtype=float)
    Dgu=np.exp(1j*n*g1)*u
    corr=v-Dgu
    target=exact_pair_norm_sq(r,g1+g3)
    val=float(np.vdot(corr,corr).real)
    ck(abs(val-target) < 2e-5+2e-5*target,'correction norm')
    # conjugate identity exact up to fp
    ck(np.linalg.norm(np.conj(u)+np.exp(-1j*n*delta)*u) < 1e-10*(1+np.linalg.norm(u)),'conj modulation')

# Every interior octave loaded: deterministic asymptotic sanity checks.
# This numerically checks the theorem's scale profile; proof is Abel summation in the note.
for R in [64,128,256,512]:
    eps=1/(R*R)
    delta=R*eps # 1/R
    r=1-eps
    M=64
    while 2*M <= 0.25*R:
        lo=max(1,int(math.ceil(M/delta)))
        hi=int(math.floor(2*M/delta))
        n=np.arange(lo,hi+1,dtype=float)
        vals=4*(r**(2*n))*(np.sin(n*delta/2)**2)/n
        mass=float(vals.sum())
        ck(mass>0.25,'octave lower')
        ck(mass<4.0,'octave upper')
        M*=2

# More detailed dyadic profile at larger R with smaller starting M.
for R in [256,512,1024]:
    eps=1/(R*R)
    delta=1/R
    r=1-eps
    for M in [8,16,32,64,128]:
        if 2*M>0.35*R: continue
        lo=int(math.ceil(M/delta)); hi=int(math.floor(2*M/delta))
        n=np.arange(lo,hi+1,dtype=float)
        mass=float((4*(r**(2*n))*np.sin(n*delta/2)**2/n).sum())
        ck(mass>0.08,'profile positive')
        ck(mass<4.0,'profile bounded')

print(f'PASS {checks}/{checks} checks')
print('symbolic compactified DFT Jacobian determinant =',detJ)
print('critical endpoint derivative Psi_e\'(-1) =',crit)
