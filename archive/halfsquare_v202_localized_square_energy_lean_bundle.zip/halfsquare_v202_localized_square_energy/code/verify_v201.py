#!/usr/bin/env python3
"""Exact algebra checks for v201. Requires SymPy; uses no floating point.

These checks validate signs, constants, and countermodels. The analytic and
topological theorems are proved in the notes, not established by this script.
"""
import itertools
import sympy as s

I = s.I
R = s.Rational
counts = {}


def check(group, assertion):
    if not assertion:
        raise AssertionError(group)
    counts[group] = counts.get(group, 0) + 1


def zero(x):
    return s.simplify(s.expand_complex(x)) == 0


def abs2(z):
    return s.simplify(s.expand_complex(z * s.conjugate(z)))


def norm2(x):
    return s.simplify((x.conjugate().T * x)[0])


def form(B, x):
    return s.simplify(norm2(x) + s.re((x.T * B * x)[0]))


def polar(B, x, y):
    return s.simplify(s.re((x.conjugate().T * y)[0] + (x.T * B * y)[0]))


# Complex-symmetric contraction with a nonreal unit singular direction.
O = s.Matrix([[R(3, 5), -R(4, 5), 0],
              [R(4, 5), R(3, 5), 0], [0, 0, 1]])
diag = [R(3, 5) + R(4, 5)*I, -R(2, 3), I/2]
B = O * s.diag(*diag) * O.T
check("contraction construction", O.T * O == s.eye(3))
check("contraction construction", B.T == B)
for z in diag:
    check("contraction construction", abs2(z) <= 1)

vectors = [s.Matrix([1+I, 2-I, -1]),
           s.Matrix([2, -1+2*I, 3-I]),
           s.Matrix([I, 1, 1+I]),
           s.Matrix([R(1, 3), I/2, -R(2, 5)])]
for u, v in itertools.product(vectors, repeat=2):
    D = s.simplify(norm2(u) + norm2(v) + 2*s.re((u.T*B*v)[0]))
    defect = s.simplify(norm2(v) - norm2(B*v))
    residual = norm2(B*v + u.conjugate())
    m, d = (u+v)/2, (u-v)/2
    check("positive deficit identities", zero(D-defect-residual))
    check("positive deficit identities", D >= 0 and defect >= 0)
    check("positive deficit identities", zero(D-2*form(B, m)-2*form(-B, d)))
    check("positive deficit identities", form(B, u) <= D+norm2(u-v))
    check("positive deficit identities", norm2(B*u+u.conjugate()) <= 2*form(B, u))

G = s.Matrix([[polar(B, u, v) for v in vectors[:3]] for u in vectors[:3]])
for k in range(1, 4):
    for indices in itertools.combinations(range(3), k):
        check("real Gram positivity", G.extract(indices, indices).det() >= 0)

# Exact finite-point product identities for an analytic Jordan map.
# f(z)=z+z^2/4 is injective on the closed disk since Re f'(z)>=1/2.
def f(z):
    return z + z*z/4


def fp(z):
    return 1+z/2


def df(a, b):
    return fp(a) if a == b else s.cancel((f(a)-f(b))/(a-b))


def rho2(a, b):
    return s.cancel(abs2(a-b)/abs2(1-a*s.conjugate(b)))


def cr2(a):
    return s.cancel((1-abs2(a))**2 * abs2(fp(a)))


def kexp(a, b):
    """exp(-2 K_f(a,b)); rational at the chosen points."""
    return s.cancel(abs2((1-a*s.conjugate(b))*df(a, b)))


points = [R(1, 3), I/4, -R(2, 5), (1-I)/5, (2+I)/6]
for a, b in itertools.combinations(points, 2):
    kernel = s.cancel(kexp(a, b)**2/(kexp(a, a)*kexp(b, b)))
    geometric = s.cancel(abs2(f(a)-f(b))**2/(rho2(a, b)**2*cr2(a)*cr2(b)))
    check("diagonal finite-point formula", zero(kernel-geometric))
    check("diagonal finite-point formula", geometric >= 1)
for a, b, c, d in itertools.permutations(points[:4]):
    kernel = s.cancel(kexp(a, d)*kexp(b, c)/(kexp(a, c)*kexp(b, d)))
    geometric = s.cancel(
        abs2((f(a)-f(d))*(f(b)-f(c))/((f(a)-f(c))*(f(b)-f(d))))
        *rho2(a, c)*rho2(b, d)/(rho2(a, d)*rho2(b, c)))
    check("mixed finite-point formula", zero(kernel-geometric))

# Rotation bookkeeping, with exact unit complex numbers.
phase = R(3, 5)+R(4, 5)*I
gap_phase = R(5, 13)+R(12, 13)*I
r = R(7, 8)
for n in range(1, 9):
    u = r**n * phase**n * (1-gap_phase**n) / s.sqrt(n)
    check("global conjugacy phase",
          zero(s.conjugate(u)+(phase**2*gap_phase)**(-n)*u))

# Check the factor 4 in the explicit deficit asymptotic by an exact limit.
# eps=t^2, delta=t, g1=2t^2, g3=3t^2, k=1/2.
t = s.symbols("t", positive=True)
rr = 1-t*t
g1, g3, delta, kval = 2*t*t, 3*t*t, t, R(1, 2)
def pair_norm_exponential(angle):
    return 1+4*rr**2*s.sin(angle/2)**2/(1-rr**2)**2
chi = s.sin(g1/2)*s.sin(g3/2) / (
    s.sin((delta-g3)/2)*s.sin((delta-g1)/2))
exp_D = (pair_norm_exponential(delta)
         *pair_norm_exponential(delta-g1-g3)*(chi/kval)**2)
check("pair-width constant", s.limit(exp_D, t, 0, dir="+") == 9)

# A fixed direct sum of these blocks has bounded packet energy and large
# sum of coordinate energies. The finite formulas are exact.
for n in [2, 3, 5, 8, 16]:
    ones = s.ones(n, 1)
    block = -(1-R(1, n)) * ones*ones.T/n
    check("nonadditive octave countermodel", form(block, ones) == 1)
    coord_sum = sum(form(block, s.eye(n)[:, j]) for j in range(n))
    check("nonadditive octave countermodel", coord_sum == n-1+R(1, n))

# Verify the C4 gluing and the separation in the globalization counterexample.
x = s.symbols("x", real=True)
bump = (-x*(x+1))**5
for endpoint in [-1, 0]:
    for order in range(5):
        check("local versus global phase", s.diff(bump, x, order).subs(x, endpoint) == 0)
check("local versus global phase", bump.subs(x, -R(1, 2)) == R(1, 1024))
check("local versus global phase", R(5, 256) < 1)
check("entropy convexity",
      zero(s.diff(x*s.log(1+x), x, 2)-(x+2)/(x+1)**2))

# Faber generating functions and their Grunsky convention for f=z+z^2/4.
zz, ww, tt = s.symbols("zz ww tt")
generator = s.series(-s.log(1-(zz+zz**2/4)/ww), zz, 0, 5).removeO()
for n in range(1, 5):
    phi = s.expand(generator).coeff(zz, n)*n
    check("Faber dipole convention", s.limit(phi, ww, s.oo) == 0)
    pulled = s.series(phi.subs(ww, tt+tt**2/4)-tt**(-n), tt, 0, 4).removeO()
    for m in range(1, 4):
        c_nm = (-1)**(n+m)*s.binomial(n+m, n)*R(1, 4)**(n+m)/(n+m)
        check("Faber dipole convention", zero(s.expand(pulled).coeff(tt, m)-n*c_nm))
aa, bb, ww = s.symbols("aa bb ww")
check("physical dipole derivative",
      s.cancel(1/(ww-bb)-1/(ww-aa)-(bb-aa)/((ww-aa)*(ww-bb))) == 0)
rr, cc = s.symbols("rr cc", positive=True)
gap_bound_difference = cc**2/(4+cc**2) - rr**2*cc**2/((1+rr)**2+rr**2*cc**2)
expected_difference = cc**2*(1-rr)*(1+3*rr)/(
    (4+cc**2)*((1+rr)**2+rr**2*cc**2))
check("clearance radius constant", s.cancel(gap_bound_difference-expected_difference) == 0)

# Retain the essential v200 correction: the compactified Jacobian has full rank.
e, z = s.symbols("e z", real=True)
vertices = [-R(1, 2)+I**j/2 for j in range(4)]
P = (z+R(1, 2))**4-R(1, 16)
h = I+(2*z+1)**2
psip = s.diff(z+e*P*h, z)
source_derivatives = [I, -R(1, 2), I, R(1, 2)]
col = []
for j in range(4):
    w = s.expand(psip.subs(z, vertices[j])*source_derivatives[j])
    d2, d3 = (-1)**j*w/4, I**j*w/4
    col.append(s.Matrix([s.re(d2), s.im(d2), s.re(d3), s.im(d3)]))
det = s.factor(s.Matrix.hstack(*col).det())
check("v200 rank correction", det == -e**2/512)

for group, count in counts.items():
    print(f"PASS {group}: {count} exact checks")
print(f"TOTAL: {sum(counts.values())} exact checks, zero failures")
print(f"Compactified v200 Jacobian: {det}")
print("No floating-point diagnostics or interval arithmetic were used.")
print("Analytic and topological claims require the written proofs.")
