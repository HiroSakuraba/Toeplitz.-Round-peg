#!/usr/bin/env python3
"""Exact checks for v202 constants, energy signs, and transport calibration.

Requires SymPy. No floating point or interval arithmetic is used.
The functional-analytic and Jordan-domain arguments require the written proofs.
"""
import itertools
import sympy as S

I = S.I
Q = S.Rational
counts = {}


def check(group, condition):
    if not condition:
        raise AssertionError(group)
    counts[group] = counts.get(group, 0) + 1


def zero(expr):
    return S.simplify(S.expand_complex(expr)) == 0


def abs2(expr):
    return S.simplify(S.expand_complex(expr*S.conjugate(expr)))


w, a = S.symbols("w a")
ratio = (w*w+a*a)/(w*w-a*a)
check("quadrupole derivative",
      S.cancel(S.diff(ratio, w)/ratio + 4*a*a*w/(w**4-a**4)) == 0)

# Charge cancellation and the entire surviving congruence class of moments.
for n in range(17):
    moment = S.expand(sum((-1)**j * I**(j*n) for j in range(4)))
    expected = 4 if n % 4 == 2 else 0
    check("square charge moments", moment == expected)

# The potential expansion and the exact energy tail must have consistent
# Laurent-mode factors, not just consistent leading powers.
z = S.symbols("z", real=True)
potential_series = S.series(S.log((1+z**2)/(1-z**2)), z, 0, 24).removeO()
for n in range(1, 24):
    expected = Q(4, n) if n % 4 == 2 else 0
    check("quadrupole Laurent coefficients",
          S.expand(potential_series).coeff(z, n) == expected)

tail = 4*S.log((1+z**4)/(1-z**4))
tail_series = S.series(tail, z, 0, 44).removeO().expand()
for k in range(5):
    n = 4*k+2
    laurent_coefficient = Q(4, n)
    energy_coefficient = n*laurent_coefficient**2
    check("Dirichlet tail normalization",
          tail_series.coeff(z, 2*n) == energy_coefficient)
check("Dirichlet tail normalization",
      S.limit(tail/z**4, z, 0) == 8)

# Integration of one Laurent mode directly in polar radius.
rho, radius = S.symbols("rho radius", positive=True)
for n in [2, 6, 10]:
    integral = S.integrate(2*n*n*rho**(-2*n-1), (rho, radius, S.oo))
    check("Laurent mode integration", S.simplify(integral-n/radius**(2*n)) == 0)

# exp(2 E(P)/(2 pi)) from squared pair distances avoids all approximate logs.
# For a square it is (circumradius/d)^8, equivalently s^8/(16 d^8).
for center, axis, d in [
    (0, 1, Q(1, 4)),
    (Q(2, 3)+I/5, Q(3, 5)+Q(4, 5)*I, Q(1, 7)),
    (-1+2*I, Q(3, 2)+I/2, Q(1, 8)),
]:
    points = [center+axis*I**j for j in range(4)]
    charges = [(-1)**j for j in range(4)]
    check("regularized square energy", sum(charges) == 0)
    check("regularized square energy",
          zero(sum(charges[j]*points[j] for j in range(4))))
    product = d**(-2*sum(v*v for v in charges))
    for j, k in itertools.permutations(range(4), 2):
        product *= abs2(points[j]-points[k])**(-charges[j]*charges[k])
    check("regularized square energy",
          S.simplify(product-abs2(axis)**4/d**8) == 0)
    side2 = abs2(points[0]-points[1])
    check("regularized square energy",
          S.simplify(product-side2**4/(16*d**8)) == 0)

# q for alternating charges in the identity disk, computed independently
# from the finite-point kernel K(z,w)=-log|1-z conjugate(w)|.
b = S.symbols("b", positive=True)
pts = [b*I**j for j in range(4)]
kernel_product = S.Integer(1)
for j, k in itertools.product(range(4), repeat=2):
    kernel_product *= abs2(1-pts[j]*S.conjugate(pts[k]))**(-(-1)**(j+k))
expected_product = ((1+b**4)/(1-b**4))**8
check("disk kernel and tail agreement",
      S.cancel(kernel_product-expected_product) == 0)

# Fixed-charge monotonicity versus moving-charge cancellation.
t, kappa = S.symbols("t kappa", positive=True)
q_fixed = 4*S.log((t**4+b**4)/(t**4-b**4))
fixed_rate = -32*b**4*t**3/(t**8-b**8)
check("fixed-charge flow",
      S.simplify(S.diff(q_fixed, t)-fixed_rate) == 0)
check("fixed-charge flow",
      S.limit((t-b)*S.diff(q_fixed, t), t, b, dir="+") == -4)
check("moving-square transport",
      S.simplify(S.diff(q_fixed.subs(b, kappa*t), t)) == 0)
transport = S.diff(q_fixed, b).subs(b, kappa*t)*kappa
dissipation = -fixed_rate.subs(b, kappa*t)
check("moving-square transport",
      S.simplify(transport-dissipation) == 0)
check("moving-square transport",
      S.simplify(t*dissipation-32*kappa**4/(1-kappa**8)) == 0)

# General finite truncation: varying complex moments and a symmetric
# nonreal Grunsky coefficient matrix. This checks the conjugations and 2s.
moments = S.Matrix([t+I*t*t, 2*t*t-I*t, 1+t**3+I/2])
C = S.Matrix([[Q(1, 5), I/7, Q(1, 11)],
              [I/7, -Q(1, 9), (1+I)/13],
              [Q(1, 11), (1+I)/13, I/17]])
q_expr = sum(abs2(moments[n-1])/(n*t**(2*n)) for n in range(1, 4))
q_expr += S.re((moments.T*C*moments)[0])
dis = 2*sum(abs2(moments[n-1])/t**(2*n+1) for n in range(1, 4))
work = 2*S.re(sum(S.conjugate(moments[n-1])*S.diff(moments[n-1], t)
                  /(n*t**(2*n)) for n in range(1, 4)))
work += 2*S.re((moments.diff(t).T*C*moments)[0])
check("general transport formula", zero(S.diff(q_expr, t)+dis-work))

# Annular Poincare constant and the numerical factors in the cutoff proof.
theta = S.symbols("theta", real=True)
g = S.sin(theta/2)
lhs = S.integrate(g*g, (theta, 0, 2*S.pi))
rhs = 4*S.integrate(S.diff(g, theta)**2, (theta, 0, 2*S.pi))
check("annular constants", S.simplify(lhs-rhs) == 0)
check("annular constants", 2+8*4 == 34)
check("annular constants", 34*2 == 68)
check("annular constants", 68*2 == 136)
check("nearby-boundary threshold",
      2*Q(1, 2)/(1+Q(1, 2)**2) == Q(4, 5))

# Nested projection sign: v_D=(x,0,0), v_Omega=(x,y,0).
x, y, zz = S.symbols("x y zz", real=True)
P = S.Matrix([x, y, zz])
v_D, v_O = S.Matrix([x, 0, 0]), S.Matrix([x, y, 0])
energy = lambda v: (v.T*v)[0]
check("domain monotonicity sign",
      S.expand(energy(P-v_D)-energy(P-v_O)-energy(v_O-v_D)) == 0)

for group, count in counts.items():
    print(f"PASS {group}: {count} exact checks")
print(f"TOTAL: {sum(counts.values())} exact checks, zero failures")
print("No floating-point diagnostics or interval arithmetic were used.")
print("These checks do not replace the written analytic and topological proofs.")
