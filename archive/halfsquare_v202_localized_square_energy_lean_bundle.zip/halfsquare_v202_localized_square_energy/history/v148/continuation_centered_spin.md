# Continuation: radial backtracking and power-like access paths

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026  
**Status:** Local square-forcing theorems with explicit hypotheses. This does not prove the general Toeplitz conjecture. No priority claim is made.

**Later results:** `continuation_profile_classification.md` supplies the general profile criterion proposed in Section 5 and extends it to oscillating logarithmic modulation. `continuation_logarithmic_slope.md` handles a growing logarithmic slope through widening annular crossings. The angular comparison and access-path reduction proved here are retained as inputs to both continuations.

Read this continuation before the earlier `research_note.md`. The earlier note proved a power-phase theorem for radial graphs and left the centered square motion as an exception to its two-time incidence argument. The present continuation removes radial monotonicity from the existence theorem and excludes that centered motion as part of a square-free Jordan envelope with power-like spin.

The additional input is the actual Jordan boundary. A relation-avoiding centered motion remains possible as an abstract local motion. When one of its corner paths is required to lie in the complement of the same Jordan curve, angular separation transfers its phase law to a genuine boundary arc. A degree argument then produces four actual curve points forming a square.

## 1. A square theorem allowing arbitrary radial backtracking

Let \(\eta:[0,t_0]\to\mathbb C\) be continuous, with

\[
\eta(0)=0,\qquad \eta(t)\ne0\quad(t>0).
\]

Write

\[
R(t)=|\eta(t)|,\qquad
\eta(t)=R(t)e^{i\Theta(t)},
\]

using a continuous angular lift on \((0,t_0]\).

**Theorem 5 — power-like arcs with backtracking contain squares.** Suppose

\[
\Theta(t)=aR(t)^{-p}(1+o(1)),
\qquad a>0,\quad p>0,\qquad t\downarrow0.
\tag{1.1}
\]

Then the image of \(\eta\) contains nondegenerate squares arbitrarily close to the origin. Neither \(R\) nor \(\Theta\) needs to be monotone. The path need not be differentiable or injective. The square's four spatial vertices are distinct regardless.

More precisely, for every sufficiently small reference scale \(s>0\), there is a square

\[
z_j=s\tau_s e^{i\psi_s}(w_s+i^j),
\qquad w_s\to w_*,\quad \tau_s\to1,
\tag{1.2}
\]

whose four vertices belong to \(\eta([0,t_s])\), with \(t_s\to0\). Its side length is \(\sqrt2s\tau_s\). No prescribed temporal order is asserted.

### Proof

The earlier note establishes that

\[
H_p(w,\tau)=\big((\tau|w+i^j|)^{-p}
 -(\tau|w+1|)^{-p}\big)_{j=1}^3
\tag{1.3}
\]

has a nonzero Jacobian at some \((w_*,1)\), with \(w_*>1\) real. Its calculation is explicit: if \(D_p(w)=H_p(w,1)\), then at real \(x\downarrow1\),

\[
\det[(D_p)_x,(D_p)_y,D_p]
=2t(de'-d'e)<0,
\]

where \(d=(x^2+1)^{-p/2}-(x+1)^{-p}\), \(e=(x-1)^{-p}-(x+1)^{-p}\), and \(t=p(x^2+1)^{-p/2-1}>0\). Thus \(\det DH_p=-p\det[(D_p)_x,(D_p)_y,D_p]\ne0\) at an appropriate fixed \(x>1\).

Choose a small bounded neighborhood \(U\) of this point on which \(H_p\) is one-to-one and locally invertible, with compact closure avoiding the four punctures. Put

\[
h_0=H_p(w_*,1),\qquad
\delta=\operatorname{dist}(h_0,H_p(\partial U))>0.
\]

Choose constants \(0<A<B\) with

\[
A<\rho_j(w,\tau):=\tau|w+i^j|<B
\quad\text{for all }(w,\tau)\in\overline U,
\quad j=0,1,2,3.
\tag{1.4}
\]

**Select an annular crossing, without selecting a radial inverse.** For small \(s\), let \(b_s\) be the first parameter, starting from \(0\), at which \(R=B s\). Let \(a_s<b_s\) be the last preceding parameter at which \(R=A s\). Continuity gives both parameters, and

\[
As\le R(t)\le Bs\quad(a_s\le t\le b_s),
\qquad b_s\to0.
\]

Parametrize this whole interval affinely by \(u\in[0,1]\). Define

\[
g_s(u)=R(t(u))/s,\qquad
\vartheta_s(u)=\Theta(t(u))/(a s^{-p}).
\]

Then \(g_s(0)=A\), \(g_s(1)=B\), \(g_s\in[A,B]\), and (1.1) gives

\[
\sup_{u\in[0,1]}|\vartheta_s(u)-g_s(u)^{-p}|\to0.
\tag{1.5}
\]

The function \(g_s\) may backtrack any number of times. It is not inverted.

**Keep all four contact parameters.** On the parameter domain

\[
\mathcal U=(0,1)^4\times U\subset\mathbb R^7,
\]

use variables \((u_0,u_1,u_2,u_3,w,\tau)\). Choose continuous arguments \(\phi_j=\arg(w+i^j)\) on \(\overline U\), and choose \(n_s\in\mathbb Z^3\) by rounding \(a s^{-p}h_0/(2\pi)\). Set

\[
y_s=2\pi n_s/(a s^{-p}),\qquad y_s\to h_0.
\]

Consider the seven-component map consisting of four radius equations

\[
g_s(u_j)-\rho_j(w,\tau),\qquad j=0,1,2,3,
\tag{1.6}
\]

and three exact relative phase equations

\[
\vartheta_s(u_j)-\vartheta_s(u_0)
 -\frac{\phi_j-\phi_0}{a s^{-p}}-y_{s,j},
\qquad j=1,2,3.
\tag{1.7}
\]

**First homotopy.** Replace the three expressions (1.7) by

\[
g_s(u_j)^{-p}-g_s(u_0)^{-p}-y_{s,j}.
\tag{1.8}
\]

The replacement tends uniformly to zero in norm. No boundary zero appears: on a face \(u_j=0\) or \(1\), (1.4) makes the corresponding radius equation nonzero. On the remaining boundary, \((w,\tau)\in\partial U\); if all radius equations vanish, (1.8) becomes \(H_p(w,\tau)-y_s\), whose distance from zero stays positive. Equation (1.5) and the bounded argument terms make the first homotopy admissible for small \(s\).

**Second homotopy.** In both (1.6) and (1.8), replace \(g_s\) continuously by

\[
g_{s,v}(u)=(1-v)g_s(u)+v(A+(B-A)u),\qquad0\le v\le1.
\tag{1.9}
\]

All these functions retain the same endpoints and stay in \([A,B]\). The same boundary argument applies exactly. At \(v=1\), the four radius equations have the unique solutions

\[
u_j=\frac{\rho_j(w,\tau)-A}{B-A}\in(0,1).
\]

Eliminating them leaves \(H_p(w,\tau)=y_s\), which has one regular solution in \(U\) for small \(s\). With the four \(u\)-coordinates written first, the Jacobian determinant of the full limiting map at this solution is

\[
(B-A)^4\det DH_p(w,\tau)\ne0.
\tag{1.10}
\]

Thus the seven-dimensional degree is \(\pm1\), and the original map (1.6)–(1.7) has a zero.

At that zero, set \(\psi_s=\Theta(t(u_0))-\phi_0\). The radius equations and the phase equations modulo \(2\pi\) show that every point in (1.2) equals \(\eta(t(u_j))\). The four spatial points are distinct because \(s\tau_s>0\). Finally, the local inverse of \(H_p\), (1.5), and \(y_s\to h_0\) give \((w_s,\tau_s)\to(w_*,1)\). All contact parameters lie before \(b_s\to0\). \(\square\)

The extra variables preserve actual incidence. No points are filled in between different radial branches, and no continuous first-hit inverse is assumed.

## 2. Angular comparison for disjoint arcs

**Lemma 6 — disjoint arcs have ordered angular lifts.** Let \(\alpha,\beta\) be two simple planar arcs meeting only at a common endpoint \(0\). Truncate each at its first exit from a sufficiently small circle \(|z|=R\), starting at \(0\). Choose continuous angular lifts \(\theta_\alpha,\theta_\beta\) on their punctured portions.

For \(0<r<R\), define

\[
m_\alpha(r)=\min_{|\alpha(t)|=r}\theta_\alpha(t),\qquad
M_\alpha(r)=\max_{|\alpha(t)|=r}\theta_\alpha(t).
\]

These quantities are finite. There is a fixed integer \(k\) such that every point of \(\beta\) at radius \(r\) satisfies

\[
m_\alpha(r)+2\pi k
<\theta_\beta
<M_\alpha(r)+2\pi(k+1).
\tag{2.1}
\]

In particular, if

\[
\theta_\alpha(t)=a|\alpha(t)|^{-p}(1+o(1)),
\qquad a,p>0,
\]

then the same leading law holds on \(\beta\).

**Proof.** Use the universal covering coordinates

\[
(x,y)=(\log|z|,\arg z),\qquad x\le\log R.
\]

The lift of \(\alpha\) is a proper simple arc from the boundary line \(x=\log R\) to the end \(x\to-\infty\). Its vertical translates by \(2\pi\mathbb Z\) are disjoint, because the projected arc is simple. Jordan separation for a proper planar arc gives an upper and a lower side, distinguished by the two rays of the boundary line on either side of its endpoint. One can obtain this separation by reflecting the arc across the boundary line and applying the Jordan curve theorem after one-point compactification.

Choose \(k\) so that the boundary endpoint of the lift of \(\beta\) lies between the endpoints of the \(k\)-th and \((k+1)\)-st translates of the lift of \(\alpha\). Since the projected arcs are disjoint, the whole lift of \(\beta\) stays above the first and below the second in this separation sense.

At a fixed \(x=\log r\), a point higher than every intersection with one lifted arc lies on its upper side: move vertically farther up, then move to the outer boundary above that arc. Such a route exists because the lifted arc is bounded in height on every closed strip \(\log r\le x\le\log R\). The analogous statement holds below its lowest intersection. These two observations yield (2.1).

Every sufficiently small-radius point on a simple arc lies sufficiently close to its endpoint in parameter: the image of any compact parameter interval away from that endpoint has positive distance from zero. Therefore the assumed asymptotic is uniform among all intersections of \(\alpha\) with the circle of radius \(r\). Both \(m_\alpha(r)\) and \(M_\alpha(r)\) equal \(a r^{-p}(1+o(1))\). The fixed \(2\pi\) offsets in (2.1) are negligible compared with \(r^{-p}\), proving the final claim. \(\square\)

This comparison does not bound the number of radial returns. It uses all intersections at a radius through their minimum and maximum lifted angles.

## 3. An access path transfers the phase law to the boundary

**Theorem 7 — power-like access forces a boundary square.** Let \(\Gamma\) be a Jordan curve and \(P\in\Gamma\). Suppose there is a continuous path \(A:[0,t_0]\to\mathbb C\) with

\[
A(0)=P,\qquad A(t)\notin\Gamma\quad(t>0),
\]

and a continuous angular lift about \(P\) satisfying

\[
\arg(A(t)-P)=a|A(t)-P|^{-p}(1+o(1)),
\qquad a,p>0.
\tag{3.1}
\]

Then \(\Gamma\) contains nondegenerate squares arbitrarily close to \(P\). The access path may lie in the interior or exterior, may backtrack radially, and may have self-intersections.

**Proof for a simple access arc.** Take a small subarc of \(\Gamma\) starting at \(P\). It is disjoint from the access arc except at \(P\). Lemma 6 transfers (3.1) to that actual boundary arc. Theorem 5 then produces the squares there.

**Reduction of a general access path to this case.** Translate \(P\) to zero. Choose \(R>0\) so that some point \(Q\in\Gamma\) lies outside \(\overline{B(0,R)}\), and truncate \(A\) so its punctured image lies inside this ball. It lies in one connected component \(V\) of \(B(0,R)\setminus\Gamma\).

There is a single-valued continuous argument on \(V\). Indeed, any closed polygonal loop \(L\subset V\) has the same winding number about all points of the connected set \(\Gamma\), since \(L\) is disjoint from \(\Gamma\). Its winding about \(Q\) is zero, so its winding about zero is also zero. This zero-period condition permits an argument branch on the open connected set \(V\); equivalently, integrate \(1/z\) along paths in \(V\).

The argument branch restricted to \(A\) differs from the lift in (3.1) by one fixed multiple of \(2\pi\). Thus (3.1) becomes a statement about points in the trace of \(A\), independent of repeated visits. The error tends uniformly to zero on that trace as its points approach zero: preimages of such points must tend to the endpoint, because the rest of the original parameter interval is compact and avoids zero.

The standard path-to-arc theorem supplies a simple arc from zero to \(A(t_0)\) contained in the trace of \(A\) [DK]. The branch of argument on \(V\) preserves (3.1) on this extracted arc. Apply the simple-arc case. \(\square\)

For an exactly radial access spiral \(A(r)=r e^{i\Phi(r)}\), the transfer has a shorter proof. On any boundary arc disjoint from it, the continuous difference

\[
\theta_\Gamma(t)-\Phi(|\Gamma(t)|)
\]

avoids \(2\pi\mathbb Z\) and therefore stays in one interval of length \(2\pi\). Theorem 7 extends this observation to access paths whose radial projection is not injective.

## 4. The centered envelope exception is excluded in the power-like class

Hugelmeyer's square envelope has two adjacent corner tracks in the open exterior and two in the open interior of the same Jordan curve [H]. We use only those local separation conditions here; no unproved Spiral Conjecture is invoked.

**Corollary 8 — finite shape limits under power-like spin force a square.** Suppose four corner paths have the form

\[
Q_j(t)=P+r(t)e^{i\Theta(t)}(w(t)+i^j),
\qquad j=0,1,2,3,
\tag{4.1}
\]

where all quantities are continuous and

\[
r(t)>0,\quad r(t)\to0,\quad
w(t)\to w_*\in\mathbb C,
\quad \Theta(t)=a r(t)^{-p}(1+o(1)),\quad a,p>0.
\tag{4.2}
\]

Assume \(Q_0,Q_1\) lie in the open exterior of a Jordan curve \(\Gamma\), and \(Q_2,Q_3\) lie in its open interior. Then \(\Gamma\) contains squares arbitrarily close to \(P\). In particular, this cannot be a tail of an envelope for a square-free Jordan curve.

There is no monotonicity assumption on \(r(t)\). The finite limit \(w_*\) may be zero.

**Proof.** All four corners tend to \(P\). The interior and exterior conditions imply \(P\in\Gamma\). At least one of the two exterior limiting coefficients \(c=w_*+1\), \(c=w_*+i\) is nonzero. Choose its corner \(Q_j\), and put \(c(t)=w(t)+i^j\). For small \(t\), a continuous argument of \(c(t)\) stays bounded. Therefore

\[
|Q_j-P|=r(t)|c(t)|,
\]

\[
\arg(Q_j-P)=\Theta(t)+\arg c(t)
=a|c|^p|Q_j-P|^{-p}(1+o(1)).
\tag{4.3}
\]

This corner path is an access path satisfying Theorem 7. The conclusion follows. \(\square\)

The original centered example \(w\equiv0\) still satisfies all-times avoidance between its four abstract tracks. The new conclusion uses more information: placing an exterior track beside a Jordan boundary forces that boundary to acquire the same angular profile, and the boundary then contains squares. Thus the abstract exception was real, while its use in a square-free envelope is excluded under (4.2).

## 5. What this changes and what it leaves open

| Issue in the earlier note | Result of the continuation |
|---|---|
| A radial graph was needed to write the phase equations | Four curve parameters and four radius constraints allow arbitrary radial backtracking |
| Noncentral shape limits were excluded only with a monotone amplitude parameter | The access-path argument removes that monotonicity assumption |
| The centered limit survived the two-time condition | It is excluded for a square-free envelope satisfying the power-like phase hypothesis |
| A corner track might intersect itself | A local argument branch and path-to-arc extraction preserve the phase law |

This continuation does **not** show that every hypothetical envelope satisfies (4.2). In particular it does not control:

- a normalized shape with no finite limit, including \(|w(t)|\to\infty\);
- a tail without one limiting physical point;
- angular growth that has no nonzero power asymptotic of the stated form;
- rapidly varying phase profiles for which no uniform nonzero profile degree is available.

A subsequence with \(w(t_n)\to w_*\) is not enough for Corollary 8: its hypothesis is convergence along the tail. Nor does mere unbounded winding imply the power law. The Fermat and logarithmic rank-loss profiles discussed in the earlier note remain reasons to distinguish the shape of the phase distribution from its total variation.

The most useful next extension is to determine which more general diverging phase profiles have a nonzero three-dimensional degree. The seven-dimensional incidence construction already accommodates radial backtracking once such a profile is available. A universal profile-extraction theorem remains unproved.

## 6. Exact checks and proof dependencies

`verify_backtracking_degree.py` checks the algebra of the enlarged limiting map with rational arithmetic. It uses \(p=2\), \(w=3/4\), \(\tau=1\), where the four vertex radii are \(7/4,5/4,1/4,5/4\). A piecewise linear radial function crosses each target three times, with signs \(+1,-1,+1\).

The resulting limiting map has 81 zeros in the four contact parameters. All 81 exact \(7\times7\) determinants factor as the product of the four radial slopes and the profile determinant. There are 40 positive signs and 41 negative signs, for total degree \(-1\). This verifies, in an explicit model, how extra radial returns cancel while preserving a nonzero degree.

These are zeros of an auxiliary limiting map, not a list of certified squares on a concrete curve. The boundary homotopies and the analytic proofs above establish the existence statements. No numerical premise or interval computation is used in them.

Dependencies are explicit: Theorem 5 uses the nonzero profile Jacobian calculated in the earlier note; Lemma 6 uses Jordan separation for proper planar arcs; Theorem 7 uses the ordinary path-to-arc theorem; and Corollary 8 uses Theorem 7. No global odd-square lineage, logarithmic action identity, or conjectural normal-form theorem is required for these local conclusions.

## References

- **[H]** Cole Hugelmeyer, *Inscribed Squares and Relation Avoiding Paths*, Definition 1 and Theorem 1. [Primary paper](https://arxiv.org/pdf/2301.01340).
- **[DK]** Reinhard Diestel and Daniela Kühn, *On Infinite Cycles I*, Lemma 6.1, recording the standard fact that a path between distinct endpoints contains an arc joining those endpoints. [Authors' paper](https://web.mat.bham.ac.uk/D.Kuehn/infcycle1.pdf).
- **Internal:** `research_note.md` in this bundle, especially Theorem 2 and its explicit profile-Jacobian calculation. The new conclusions above supersede the earlier remaining-case discussion only for the stated power-like class.
