# New directions after v148: phase degree, inversion pairing, and two-time incidence

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026  
**Status:** Exploratory research note with proved local statements and explicit global gaps. This is not a proof of the Toeplitz conjecture. No priority claim is made.

**Continuation available:** `continuation_centered_spin.md` removes the radial-monotonicity restriction and excludes the centered case for square-free envelope tails with power-like spin and a finite normalized-shape limit. Read its updated remaining-case discussion after the original results below.

**Further continuations:** `continuation_profile_classification.md` classifies singular C1 phase profiles and proves square existence under leading logarithmic modulation. `continuation_logarithmic_slope.md` treats an exceptional logarithmic profile using its growing slope across wider annuli, including phases (log(r0/r))^nu for every nu > 1. Their explicit hypotheses and remaining cases supersede the corresponding earlier work-order entries below.

The starting point is the supplied v148 bundle, especially v146's exact phase equations and v147's realization of both square-degree signs at every nonzero logarithmic action. The useful next question is whether an entire family of configurations has a constraint that a scalar attached to one square cannot see.

Three local statements can be established. First, a continuous spiral with a power-like angular law contains actual squares even when its angular derivative is uncontrolled or nonexistent. Second, inversion pairs the regular phase equations on the reciprocal double spiral and gives opposite-degree actual roots for the same local lattice target. Third, the all-times separation required of a square envelope excludes power-like spinning paths whose normalized shape converges to a noncentral limit.

These statements concern actual incidence equations. None asserts that every Jordan collision admits a radial parametrization, a power-like phase profile, a convergent normalized shape, or a global pairing.

## 1. A degree criterion for a whole radial phase profile

Let

\[
\gamma(r)=r e^{i\Phi(r)},\qquad 0<r\le r_0,
\]

where \(\Phi\) is continuous. This is an injective arc because distinct parameters have distinct radii. Adding \(\gamma(0)=0\) gives continuity at the origin without any restriction on the angular oscillation.

Suppose there are scales \(s_n\downarrow0\), positive amplitudes \(A_n\to\infty\), constants \(b_n\), and a continuous function \(f\) such that

\[
\frac{\Phi(s_n\rho)-b_n}{A_n}\longrightarrow f(\rho)
\tag{1.1}
\]

uniformly on every compact radial interval needed below. The constants \(b_n\) remove a common rotation; they need not be bounded.

Write a candidate square as

\[
z_j=s_n\tau e^{i\psi}(w+i^j),\qquad j=0,1,2,3,
\tag{1.2}
\]

where \(w\in\mathbb C\), \(\tau>0\). On a small neighborhood avoiding \(w\in\{-1,-i,1,i\}\), choose continuous arguments

\[
\phi_j(w)=\arg(w+i^j),\qquad \rho_j=\tau|w+i^j|.
\]

The three exact relative phase equations are

\[
F_{n,j}(w,\tau)
=\Phi(s_n\rho_j)-\Phi(s_n\rho_0)
 -(\phi_j-\phi_0)\in2\pi\mathbb Z,
\quad j=1,2,3.
\tag{1.3}
\]

Define the limiting map

\[
H_f(w,\tau)
=\big(f(\rho_j)-f(\rho_0)\big)_{j=1}^3.
\tag{1.4}
\]

Then \(F_n/A_n\to H_f\) uniformly on compact parameter sets. The angular chart term is bounded and disappears after division by \(A_n\).

**Proposition 1 — profile degree forces actual squares.** Suppose a bounded open set \(U\subset\mathbb C\times(0,\infty)\), with compact closure inside a valid argument chart, and a target \(h_0\in\mathbb R^3\) satisfy

\[
h_0\notin H_f(\partial U),\qquad
\deg(H_f,U,h_0)\ne0.
\tag{1.5}
\]

Then \(\gamma\) contains a nondegenerate square of the form (1.2) for every sufficiently large \(n\).

**Proof.** Let

\[
\delta=\operatorname{dist}(h_0,H_f(\partial U))>0,
\qquad
\epsilon_n=\sup_{\overline U}|F_n/A_n-H_f|\to0.
\]

Choose \(k_n\in\mathbb Z^3\) by rounding each coordinate of \(A_nh_0/(2\pi)\). Then

\[
|2\pi k_n/A_n-h_0|\le\pi\sqrt3/A_n.
\]

For large \(n\),

\[
\epsilon_n+\pi\sqrt3/A_n<\delta.
\tag{1.6}
\]

The straight-line homotopy from \(H_f-h_0\) to \(F_n/A_n-2\pi k_n/A_n\) avoids zero on \(\partial U\). Its degree is nonzero, so some \((w_n,\tau_n)\in U\) satisfies \(F_n=2\pi k_n\).

Set

\[
\psi_n=\Phi(s_n\rho_0)-\phi_0.
\]

Equation (1.3) gives \(\psi_n+\phi_j\equiv\Phi(s_n\rho_j)\pmod{2\pi}\) for all four vertices. Their radii are already \(s_n\rho_j\), so all four points lie on the actual arc. Since \(s_n\tau_n>0\), they are distinct vertices of a square. \(\square\)

This proposition gives a finite-window sufficient condition through (1.6). It tracks no individual root and requires no continuous choice of a radius realizing a prescribed angular drop. The nonzero degree belongs to a full three-dimensional region of exact contact equations.

## 2. A rough power-phase theorem

**Theorem 2 — one continuous arm suffices.** Suppose

\[
\Phi(r)=a r^{-p}(1+o(1)),\qquad a>0,\quad p>0,
\quad r\downarrow0.
\tag{2.1}
\]

Then the arc \(r e^{i\Phi(r)}\) contains squares at arbitrarily small radii. More precisely, there is a fixed regular shape \(w_*\) such that, for every sufficiently small reference scale \(s>0\), one can choose an actual square

\[
z_j=s\tau_s e^{i\psi_s}(w_s+i^j),
\qquad w_s\to w_*,\quad \tau_s\to1.
\tag{2.2}
\]

Its side length is \(\sqrt2\,s\tau_s\). No derivative of \(\Phi\), and no monotonicity of \(\Phi\), is assumed. The theorem does not prescribe the order of these four points along the single arm.

**Proof.** Take \(A(s)=a s^{-p}\). Uniformly for \(\rho\) in compact subsets of \((0,\infty)\),

\[
\Phi(s\rho)/A(s)\to\rho^{-p}.
\]

Put

\[
D_p(w)=\big(|w+i^j|^{-p}-|w+1|^{-p}\big)_{j=1}^3.
\]

The limiting map in Proposition 1 is

\[
H_p(w,\tau)=\tau^{-p}D_p(w).
\tag{2.3}
\]

It remains to exhibit one nonsingular point of this map. On the real axis \(w=x>1\), let

\[
u=(x+1)^{-p},\quad v=(x-1)^{-p},\quad
c=(x^2+1)^{-p/2},
\]

\[
d=c-u,\quad e=v-u,\quad
t=p(x^2+1)^{-p/2-1}>0.
\]

Direct differentiation gives

\[
D_p=(d,e,d),\quad (D_p)_x=(d',e',d'),
\quad (D_p)_y=(-t,0,t).
\]

Consequently

\[
J_p(x):=\det[(D_p)_x,(D_p)_y,D_p]
=2t(de'-d'e).
\tag{2.4}
\]

As \(x\downarrow1\),

\[
d\to2^{-p/2}-2^{-p}>0,\qquad d'=O(1),
\]

\[
e=(x-1)^{-p}+O(1),\qquad
e'=-p(x-1)^{-p-1}+O(1).
\]

Thus

\[
de'-d'e
=-p(2^{-p/2}-2^{-p})(x-1)^{-p-1}(1+o(1))<0.
\]

Choose \(x_*>1\) sufficiently close to 1 and fix it. At \((w_*,\tau)=(x_*,1)\),

\[
\det DH_p=-pJ_p(x_*)\ne0.
\tag{2.5}
\]

The inverse function theorem gives a small neighborhood with degree \(\pm1\) at \(H_p(x_*,1)\). Proposition 1 applies for every sufficiently small \(s\). Within this neighborhood the inverse of \(H_p\) is locally Lipschitz. The uniform error and the rounded target both tend to zero, so the solutions obtained there satisfy \((w_s,\tau_s)\to(x_*,1)\). \(\square\)

The same proof works under the more general, explicitly uniform scaling assumption

\[
A(s)\to\infty,\qquad
\Phi(s\rho)/A(s)\to\rho^{-p}
\]

on compact radial intervals. This includes a regularly varying phase of index \(-p\) with positive divergent amplitude. Reflection handles a negative leading angular sign.

An illustrative allowed perturbation is

\[
\Phi(r)=r^{-2}+r^{-1}h(r),
\tag{2.6}
\]

for any bounded continuous \(h\). It may have no derivative. For \(h(r)=\sin(r^{-4})\), the angular derivative reverses sign repeatedly, while the theorem still applies.

### Relation to earlier radial work

The v102 snapshot already proves robustness near power phase profiles using a family of continuously realized angular-drop windows. The new argument uses a three-dimensional lattice target and a fixed multiplicative radial block. It supplies a different proof mechanism and removes the window-selection and angular-monotonicity hypotheses for the class (2.1). It does not establish any priority claim beyond the supplied corpus.

### Two radial arms and graceful squares

Suppose two disjoint arms of one Jordan curve meet the origin and each has exactly one point at every sufficiently small radius. Choose continuous angle lifts \(\Phi_0,\Phi_1\). Their difference avoids \(2\pi\mathbb Z\), so continuity places it in one fixed interval between consecutive multiples of \(2\pi\). In particular,

\[
\Phi_1(r)-\Phi_0(r)=O(1).
\tag{2.7}
\]

If one arm satisfies (2.1), both have the same leading profile. Assign square vertices 0,1,2 to the incoming arm and vertex 3 to the outgoing arm. The extra arm-phase differences in (1.3), divided by \(A(s)\), tend to zero. Near \(w=x_*>1\), the strict inequalities

\[
|w+1|>|w+i|>|w-1|
\]

give the correct order of the three incoming contacts. The degree proof therefore also produces graceful squares in this two-arm setting. The automatic bounded phase difference does not establish that arbitrary Jordan arms are radial graphs.

### Why the Fermat obstruction survives

For \(f(\rho)=a\rho^2+b\), the alternating square identity gives

\[
H_{f,2}-H_{f,1}-H_{f,3}=0
\tag{2.8}
\]

identically. Its image lies in a plane, so this three-dimensional degree mechanism cannot apply. This is consistent with the exact square-free Fermat spirals in v124.

For \(f(\rho)=a\log\rho+b\), relative phase differences are independent of \(\tau\), which is a second rank-loss mechanism. These are examples of degenerate profiles, not a classification of all such profiles. Large winding by itself gives no nonzero degree.

## 3. Inversion pairs entire regular phase regions

Return to v146's reciprocal double spiral and write

\[
z_j=\lambda^{-1/2}e^{i\psi}(w+i^j),\qquad
R_j(w)=|w+i^j|^2,
\]

\[
D(w)=(R_j^{-1}-R_0^{-1})_{j=1}^3,
\qquad F_m(w,\lambda)=\lambda D(w)-C_m(w),
\tag{3.1}
\]

where

\[
C_{m,j}=\phi_j-\phi_0+\pi(\chi_j-\chi_0),
\qquad \chi_j=\mathbf1_{\{j\ge m\}}.
\]

The exact contact condition is \(F_m\in2\pi\mathbb Z^3\), together with the strict arm-order conditions from v146.

Let \(q=|w|^2>0\) and \(I(w)=w/q=1/\overline w\). Direct expansion gives

\[
R_j(Iw)=R_j(w)/q,
\qquad D(Iw)=qD(w).
\tag{3.2}
\]

Hence the transformation

\[
T(w,\lambda)=(Iw,\lambda/q)
\tag{3.3}
\]

preserves the leading phase vector exactly:

\[
(\lambda/q)D(Iw)=\lambda D(w).
\]

It also preserves each of the four physical radii \(\sqrt{R_j/\lambda}\). This radius-preserving identity is geometric and holds independently of the particular radial phase law.

For the logarithmic action,

\[
\mathcal L(w)=-\log\left|\frac{w^2-1}{w^2+1}\right|,
\]

one has

\[
\frac{(Iw)^2-1}{(Iw)^2+1}
=-\overline{\frac{w^2-1}{w^2+1}},
\qquad \mathcal L(Iw)=\mathcal L(w).
\tag{3.4}
\]

This extends the axis symmetry used in v147 to all nonzero, nonpunctured shapes.

The strict split domains

\[
\Omega_1=\{x>y,\ x+y<0\},\quad
\Omega_2=\{x>y\},\quad
\Omega_3=\{x>y,\ x+y>0\}
\]

are preserved by inversion. The v146 Jacobian

\[
\det[D_x,D_y,D]
=-64\frac{(x^2-y^2)(|w|^2-1)}{(R_0R_1R_2R_3)^2}
\tag{3.5}
\]

changes sign under inversion at every regular shape.

**Proposition 3 — paired roots for one local lattice target.** Fix a regular strict shape \(w_*\), away from the punctures, \(x^2=y^2\), and \(|w|=1\). There are paired three-dimensional parameter neighborhoods and an open region of normalized phase targets such that, for all sufficiently large \(\Lambda\), every lattice target \(2\pi n/\Lambda\) in a fixed compact subset of that region has exactly one root in each neighborhood. The two roots have opposite local square degrees. If their parameters are \((w,\lambda)\) and \((\widetilde w,\widetilde\lambda)\), then

\[
\widetilde w=Iw+O(\Lambda^{-1}),\qquad
\widetilde\lambda=\lambda/|w|^2+O(1).
\tag{3.6}
\]

Here \(\lambda\asymp\Lambda\). The integer labels refer to fixed local argument charts; no global canonical labeling is asserted.

**Proof.** Set \(\lambda=\Lambda t\) and \(H(w,t)=tD(w)\). Equation (3.5) makes \(H\) locally invertible near \((w_*,1)\). Let \(V\) be a small convex ball in its image, and \(g_+:V\to U_+\) its local inverse. In the scaled coordinates the involution is

\[
T_0(w,t)=(Iw,t/q),\qquad H\circ T_0=H.
\]

Set \(g_-=T_0\circ g_+\) and \(U_-=T_0(U_+)\), shrinking \(V\) so the paired closures are disjoint and regular. The determinant of \(T_0\) is \(-q^{-3}\), so the two inverse branches have opposite orientations.

In the target coordinate \(u\in V\), each exact normalized map is

\[
G_{\Lambda,\pm}(u)
=u-\Lambda^{-1}C_m(\operatorname{pr}_w g_\pm(u)).
\tag{3.7}
\]

The second term has uniformly bounded derivative before division by \(\Lambda\). If that derivative bound is \(L\), then

\[
|G_{\Lambda,\pm}(u)-G_{\Lambda,\pm}(v)|
\ge(1-L/\Lambda)|u-v|.
\]

Thus each map is injective for large \(\Lambda\). Uniform convergence to the identity and degree on \(V\) show that each image contains every fixed compact subset \(V_0\subset V\) for large \(\Lambda\). Each normalized lattice target in \(V_0\) therefore has exactly one root on each branch.

Their target coordinates differ by \(O(\Lambda^{-1})\), which proves (3.6). Their local phase-map degrees have opposite signs. For a fixed arm split, the conversion from phase-map degree to the ordered square degree has a fixed sign factor, so the square degrees are opposite as well. Strict order and sufficiently large spiral angles hold on the chosen compact neighborhoods. \(\square\)

The logarithmic actions of the two *actual*, perturbed squares agree up to \(O(\Lambda^{-1})\). Exact equality in (3.4) concerns the unperturbed inversion pair.

### What cancellation would and would not establish

For every target in \(V_0\), the two local degrees sum to zero. This is a cancellation of whole regular families, not merely the existence of one positive and one negative example.

It is not yet a global cancellation theorem. An exhaustion must control roots near the unit circle, diagonal resonances, punctures, unbounded normalized shapes, arm-order boundaries, and the boundaries of the chosen phase regions. Opposite-degree roots have not been connected by a physical zero-cobordism on an arbitrary curve. A universal application would also require information about actual collision profiles beyond this model.

## 4. Two-time incidence is stronger than a one-square statistic

Hugelmeyer's Theorem 1 states that a square-free Jordan curve has a square envelope [H]: a moving square with two adjacent corners in the open exterior and two in the open interior, side length tending to zero at both ends, and an additional winding condition. Exterior and interior tracks must therefore remain disjoint for every pair of times. His higher-dimensional Spiral Conjecture remains an assumption in the further reduction of the problem; it is not used below.

Use the geometric order

\[
Q_j(r)=\zeta(r)(w(r)+i^j),\qquad
\zeta(r)=r e^{i\Phi(r)}.
\tag{4.1}
\]

Take \(j=0,1\) as the exterior corners and \(k=2,3\) as the interior corners. A necessary envelope condition is

\[
Q_j(r)\ne Q_k(s)
\quad\text{for all }r,s>0,
\quad j\in\{0,1\},\ k\in\{2,3\}.
\tag{4.2}
\]

These equations compare different configurations. The continuous action spectrum in v147 does not test them.

### A direct computation for a fixed shape

For \(\zeta(t)=t^{-1/2}e^{it}\), any complex ratio \(c=\rho e^{i\delta}\) with \(\rho\ne1\) is realized as \(\zeta(s)/\zeta(t)\) at arbitrarily large positive times. Indeed set

\[
t=\frac{\delta+2\pi k}{\rho^{-2}-1},\qquad
s=t/\rho^2,
\tag{4.3}
\]

choosing integers \(k\) with the sign that makes \(t\to+\infty\). Then \(\zeta(s)/\zeta(t)=c\) exactly.

For fixed \(w\), choose an exterior coefficient \(a=w+i^j\) and an interior coefficient \(b=w+i^k\) with \(a,b\ne0\) and \(|a|\ne|b|\). Taking \(c=b/a\) gives \(a\zeta(s)=b\zeta(t)\), violating (4.2).

Unless \(w=0\), such a pair always exists. When all four coefficients are nonzero, failure to find a pair would force all four moduli to be equal; the equalities \(|w+1|=|w-1|\) and \(|w+i|=|w-i|\) then force \(\operatorname{Re}w=\operatorname{Im}w=0\). If one coefficient is zero, the other three have two distinct nonzero moduli across the exterior/interior split, which can be checked directly at \(w=\pm1,\pm i\).

### The exclusion survives continuous shape drift

**Theorem 4 — noncentral shape limits force a cross-time collision.** Suppose

\[
\Phi(r)=a r^{-p}(1+o(1)),\quad a,p>0,
\qquad w(r)\to w_*\in\mathbb C\setminus\{0\},
\tag{4.4}
\]

with \(\Phi,w\) continuous. Then (4.2) fails at arbitrarily small radii. No derivative or rate of convergence of \(w\) is required.

**Proof.** Choose \(j,k\) with limiting coefficients

\[
a_*=w_*+i^j\ne0,\qquad b_*=w_*+i^k\ne0,
\qquad |a_*|\ne|b_*|.
\]

Let \(c=|b_*|/|a_*|\ne1\). Seek equal corners at radii \(s\rho\) and \(s\tau\), with \((\rho,\tau)\) close to \((c,1)\). Equality of moduli is equivalent to

\[
U_s(\rho,\tau)=\log(\rho/\tau)
 +\log|w(s\rho)+i^j|-\log|w(s\tau)+i^k|=0.
\]

Choose continuous arguments near the two nonzero limiting coefficients and set

\[
V_s(\rho,\tau)=\frac{1}{a s^{-p}}
\left[\Phi(s\rho)-\Phi(s\tau)
 +\arg(w(s\rho)+i^j)-\arg(w(s\tau)+i^k)\right].
\]

Uniformly on a small compact neighborhood,

\[
(U_s,V_s)\to
\left(\log(\rho/\tau)+\log|a_*/b_*|,
\rho^{-p}-\tau^{-p}\right)=:K(\rho,\tau).
\tag{4.5}
\]

The limiting Jacobian is

\[
\det DK(\rho,\tau)
=\frac{p}{\rho\tau}(\tau^{-p}-\rho^{-p}),
\]

which is nonzero at \((c,1)\). Choose an integer \(k_s\) so that

\[
\frac{2\pi k_s}{a s^{-p}}\to c^{-p}-1.
\]

The two-dimensional degree near \((c,1)\) gives a solution of

\[
U_s=0,\qquad V_s=2\pi k_s/(a s^{-p})
\]

for every sufficiently small \(s\). These are exact equality of modulus and equality of argument modulo \(2\pi\), so \(Q_j(s\rho)=Q_k(s\tau)\). Shrinking the neighborhood ensures \(\rho\ne\tau\), since \(c\ne1\). \(\square\)

The conclusion is deliberately limited: an envelope path with a monotone side-amplitude parametrization and this angular scaling cannot have a finite nonzero normalized-shape limit. Arbitrary envelopes need not have any of those properties.

The central case is a real exception. If \(w(r)\equiv0\), then \(Q_j(r)=i^j\zeta(r)\). Equality of two track points first forces equal radii, and then forces equal corner labels. Thus (4.2) holds. This is a local relation-avoiding model, not a square envelope of a Jordan curve satisfying Hugelmeyer's full endpoint and winding conditions.

The next meaningful step is to use those global conditions to control central spin, nonconvergent shape, or nonmonotone side amplitude. The v142 lineage on varying polygonal approximants does not automatically satisfy (4.2) on one fixed curve.

## 5. A global alternative: special trapezoids at one fixed span

Matschke's Theorem 2.8 and Corollary 2.10 [M] give a concrete sufficient target. A special trapezoid has consecutive side lengths \((a,a,a,b)\), with \(a>b\), and equal diagonals. Its size is the parameter span \(x_4-x_1\) on \(S^1=\mathbb R/\mathbb Z\). If one span \(\varepsilon\in(0,1)\) has zero mod-two special-trapezoid intersection number, the curve has a square. For a generic finite configuration set this means an even count; nonsmooth curves require the intersection-number formulation.

There is useful compactness at a fixed span:

\[
b_\varepsilon
=\min_{t\in S^1}|\gamma(t+\varepsilon)-\gamma(t)|>0
\]

by continuity and injectivity. Every such trapezoid has short side \(b\ge b_\varepsilon\) and long sides \(a>b\). It cannot disappear through total spatial collapse.

The proposed task is to find a pairing or relative-degree computation on this fixed-span family. No evenness has been proved here. The payoff would be a sufficient certificate on a compact macroscopic family, instead of a further necessary condition on shrinking squares. Matschke also warns that a connected trapezoid path can run between different collision boundaries; connectedness alone does not close this route.

## 6. Why a raw phase-wall count needs repair

The proposed phase-wall invariant in v148 is not defined merely by labeling exact solutions with integers. In one fixed valid chart,

\[
F_m(w(t),\lambda(t))=2\pi n(t)
\]

along a continuous exact-solution path makes \(n(t)\) a continuous integer-valued function. It is therefore constant. Generic roots on the fixed reciprocal curve are isolated in any case.

Changing argument charts can change an integer label without changing a physical square. A raw sum of label increments, when defined in one global chart, telescopes to an endpoint difference. To obtain new topology, one must specify a genuine nontrivial transition system, a physical deformation through singular configurations, or a relative class with independently defined boundary data. Neither a phase-cell partition nor a relabeling count alone supplies that structure.

This is a reason to study whole paired regions, two-time incidences, or a compact trapezoid family. It does not rule out a properly constructed relative phase invariant.

## 7. Work order and remaining obligations

| Direction | Established here | Next mathematical obligation | Present limitation |
|---|---|---|---|
| Degree of a radial phase profile | Actual squares for a continuous power-like arm; no angular derivative or window-selection assumption | Find actual-curve radial windows with a nonzero profile degree beyond the power class | No universal radial-window extraction theorem |
| Inversion pairing | Opposite-degree actual roots for every interior target of paired regular phase regions | Control the boundary contributions of a global exhaustion | No global pairing or transfer to arbitrary collision germs |
| Two-time incidence | Noncentral convergent shapes under power-like spin violate all-times corner separation | Exploit envelope winding to treat central spin and drifting amplitude/shape | The local centered model survives |
| Fixed-span trapezoids | Published sufficient criterion with a compact physical scale | Prove even intersection number on one suitable span or generator loop | No such parity computation supplied |

The first theorem is the cleanest immediate addition to the radial program. The two-time route is the most direct way to make a local model conflict with an independently required global structure. Inversion pairing is useful for locating where signed degree can remain after cancellation. Matschke's criterion provides a separate global target that does not require a lower bound for an arbitrarily selected approximating square.

The full Toeplitz problem remains unresolved by this note. In particular, none of these statements implies that every Jordan curve has a useful limiting phase profile or that all collision-boundary charge vanishes.

## 8. Verification

The accompanying Python script separates exact arithmetic from floating-point diagnostics:

1. Exact rational arithmetic verifies the inversion identities for 220 rational shapes. The general identities are proved by (3.2) and (3.4), not by sampling.
2. Floating-point root solving checks 12 paired phase targets in four strict shape/split cases at reference parameters 2,000, 10,000, and 50,000. The roots have opposite phase-Jacobian signs. Their maximum equation residual is below \(10^{-9}\), and their shape and scale corrections follow (3.6) in these examples. These computations are diagnostics, not certified exact roots or interval proofs.
3. Twelve floating-point substitutions check the explicit two-time ratio formula (4.3), with relative residual below \(10^{-9}\). The algebraic formula and the degree proof, rather than these substitutions, establish the incidence statements.

The proofs of Theorems 2 and 4 use uniform convergence, an explicit nonzero Jacobian of the limiting map, and ordinary Brouwer degree. No numerical premise enters either theorem.

Two small qualifications to v148 are also worth retaining. Its floored turn-capacity formula has a multiplicative asymptotic only when the unfloored capacity tends to infinity; generally an additive \(O(1)\) floor error remains. Its upper sensitivity estimates give sufficient accuracy scales, and do not by themselves establish a necessary accuracy threshold for every synchronized configuration. These qualifications do not alter the principal phase-density obstruction.

## References and provenance

- **[M]** Benjamin Matschke, *On the Square Peg Problem and Some Relatives*, revised version 2022, Theorem 2.8, Corollary 2.10, and the discussion of spiral trapezoid paths. [Primary paper](https://arxiv.org/pdf/1001.0186).
- **[H]** Cole Hugelmeyer, *Inscribed Squares and Relation Avoiding Paths*, 2023, Definition 1, Theorem 1, and the distinction between the proved envelope theorem and the proposed Spiral Conjecture. [Primary paper](https://arxiv.org/pdf/2301.01340).
- **Internal sources:** the supplied `halfsquare_v148_cubic_turn_spacing_and_phase_density_barrier_bundle.zip`; its v146 and v147 handoffs; the nested v102 reading snapshot, v123/v124 notes, and v142 lineage note. The earlier Hugelmeyer pointers in v123/v124 are acknowledged; the worked two-time collision argument above is the specific extension explored here.

This is an additive brainstorming bundle. It does not replace or reproduce the full v148 archive, and it does not assign a new numbered handoff version.
