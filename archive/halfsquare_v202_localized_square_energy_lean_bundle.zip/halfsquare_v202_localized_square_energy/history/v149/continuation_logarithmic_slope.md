# Continuation: logarithmic profiles with a growing angular slope

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026  
**Status:** A local square theorem beyond the nondegenerate fixed-profile criterion. The general Toeplitz problem is not proved. No priority claim is made.

**Later extension:** `continuation_slope_reversals.md` replaces the inverse of the increasing slope by a complete level-crossing interval. It removes slope monotonicity and eventual divergence, allows leading sign reversals, and weakens the finite-shape hypothesis to control of one complementary corner. The theorems below retain their original, sufficient hypotheses.

The preceding `continuation_profile_classification.md` shows that a logarithmic limiting phase profile has a singular three-dimensional phase map. This note works through that exception. A logarithmic profile at one fixed amplitude loses the scale direction; allowing its angular slope to vary with physical scale can restore that direction.

The result covers phases such as

\[
\Theta(r)=a\big(\log(r_0/r)\big)^\nu,
\qquad a>0,\quad \nu>1,
\tag{0.1}
\]

and, with \(T=\log(r_0/r)\),

\[
\Theta(r)=T\log T.
\tag{0.2}
\]

These grow more slowly than every inverse power of \(r\). Continuous bounded phase perturbations are allowed, and radial backtracking remains allowed. The proof uses logarithmic radius intervals that widen as the endpoint is approached. It does not obtain a nonzero degree from the singular fixed-annulus profile itself.

## 1. The cone over logarithmic relative radii has full rank

For \(w\notin\{-1,-i,1,i\}\), set

\[
\ell_j(w)=\log|w+i^j|,\qquad
D(w)=\big(\ell_j(w)-\ell_0(w)\big)_{j=1}^3.
\tag{1.1}
\]

A pure logarithmic radial phase gives a constant multiple of \(D(w)\), which has only two shape variables. The map

\[
H(w,\mu)=-\mu D(w),\qquad \mu>0,
\tag{1.2}
\]

has a third variable: the normalized angular slope.

**Lemma 16 — an exact regular point.** At \(w=2\),

\[
J:=\det[D_x,D_y,D]
=\frac{2}{75}\log\frac{19683}{3125}>0.
\tag{1.3}
\]

Consequently \(\det DH(2,1)=-J\ne0\).

**Proof.** At this real shape, write

\[
d=\tfrac12\log5-\log3,\qquad e=-\log3.
\]

The columns are

\[
D_x=(1/15,\ 2/3,\ 1/15),\qquad
D_y=(1/5,\ 0,\ -1/5),\qquad
D=(d,e,d).
\]

Expansion gives

\[
J=\frac{2}{5}\left(\frac{e}{15}-\frac{2d}{3}\right)
=\frac{2}{75}(9\log3-5\log5).
\]

The sign follows from the exact integer inequality \(3^9=19683>3125=5^5\). The three columns of \(DH(2,1)\) are the negatives of those in \(J\). \(\square\)

This is a concrete distinction between two statements: the map at one fixed logarithmic slope is singular, while the family with a variable slope has a regular point. The remaining task is to realize that slope variable using actual scales on the same path.

## 2. Hypotheses on the angular slope

Fix \(r_0>0\). Let \(\eta:[0,t_0]\to\mathbb C\) be continuous, with \(\eta(0)=P\) and \(\eta(t)\ne P\) for \(t>0\). Near its endpoint put

\[
R(t)=|\eta(t)-P|,\qquad T(t)=\log\frac{r_0}{R(t)},
\]

and choose a continuous angular lift \(\Theta(t)\) about \(P\).

Let \(F\in C^1([T_0,\infty))\). Assume, after increasing \(T_0\) if necessary, that

\[
F'(T)>0,\qquad F'\text{ is strictly increasing},\qquad F'(T)\to\infty,
\tag{2.1}
\]

and, for every fixed \(C>0\),

\[
\sup_{|u|\le C}
\left|\frac{F'(T+u)}{F'(T)}-1\right|\longrightarrow0
\qquad(T\to\infty).
\tag{2.2}
\]

The path's error must obey

\[
\Theta(t)=F(T(t))+o(F'(T(t)))\qquad(t\downarrow0).
\tag{2.3}
\]

This is a statement about every sufficiently late contact of the actual path, including every return to a radius. It implies uniform control over any collection of contacts whose radii tend uniformly to zero.

Condition (2.2) says that bounded changes of logarithmic radius change the angular slope by a negligible proportion. It imposes no second derivative on \(F\). Condition (2.1) supplies a continuous inverse of \(F'\). The actual phase \(\Theta\) need not be differentiable or monotone.

## 3. Square existence with a growing slope

**Theorem 17 — an increasing unbounded angular slope forces squares.** Under (2.1)–(2.3), the image of \(\eta\) contains nondegenerate squares arbitrarily close to \(P\). In fact there are such squares with \(P\) inside their open circumdisk and such squares with \(P\) outside their closed circumdisk. Radial backtracking and self-intersections of the path are allowed.

### 3.1. The effective slope parametrizes actual physical scales

Translate \(P\) to zero. Choose a small bounded neighborhood \(U\) of \((w,\mu)=(2,1)\), with compact closure, on which \(H\) from (1.2) is one-to-one with a smooth local inverse. Set

\[
h_*=H(2,1),\qquad
\delta=\operatorname{dist}(h_*,H(\partial U))>0.
\]

On \(\overline U\), let \(0<m\le\mu\le M\), and choose \(C>0\) such that \(|\ell_j(w)|\le C\) for every vertex and shape in this closure. Continuous local arguments \(\phi_j=\arg(w+i^j)\) are bounded there as well.

Choose any sequence \(\Lambda_n\to\infty\). For large \(n\), define

\[
S_n(\mu)=(F')^{-1}(\Lambda_n\mu).
\tag{3.1}
\]

This is continuous and tends uniformly to infinity on the allowed \(\mu\)-interval. The square with shape \(w\) and circumradius

\[
a_n(\mu)=r_0e^{-S_n(\mu)}
\tag{3.2}
\]

has vertex logarithmic radii

\[
T_j=S_n(\mu)-\ell_j(w).
\tag{3.3}
\]

The ideal normalized relative phase map is

\[
G_n(w,\mu)=\frac1{\Lambda_n}
\big(F(S_n(\mu)-\ell_j(w))-F(S_n(\mu)-\ell_0(w))\big)_{j=1}^3.
\tag{3.4}
\]

By the fundamental theorem of calculus,

\[
G_{n,j}
=-\frac1{\Lambda_n}\int_{\ell_0(w)}^{\ell_j(w)}
F'(S_n(\mu)-v)\,dv.
\]

Condition (2.2), the bound on the logarithms, and \(F'(S_n(\mu))=\Lambda_n\mu\) give

\[
G_n\longrightarrow H(w,\mu)=-\mu D(w)
\quad\text{uniformly on }\overline U.
\tag{3.5}
\]

Choose \(k_n\in\mathbb Z^3\) by rounding \(\Lambda_n h_* /(2\pi)\), and put

\[
y_n=\frac{2\pi k_n}{\Lambda_n},\qquad
\|y_n-h_*\|\le\frac{\pi\sqrt3}{\Lambda_n}.
\tag{3.6}
\]

It follows that \(\deg(G_n,U,y_n)=\deg(H,U,h_*)=-1\) for all sufficiently large \(n\). We still must realize the four radii by actual path parameters.

### 3.2. One full annular crossing contains all the required contacts

Set

\[
\alpha_n=S_n(m)-C-1,\qquad
\beta_n=S_n(M)+C+1.
\tag{3.7}
\]

Every target in (3.3) lies strictly between \(\alpha_n\) and \(\beta_n\), with margin at least one. Also \(\alpha_n\to\infty\). Take the first actual path contact with the outer radius \(r_0e^{-\alpha_n}\), and the last preceding contact with the inner radius \(r_0e^{-\beta_n}\). Continuity supplies both. The entire crossing stays in this annulus.

Affinely parametrize the crossing by \(\xi\in[0,1]\), and define

\[
q_n(\xi)=T(t_n(\xi)),\qquad
\vartheta_n(\xi)=\Theta(t_n(\xi)).
\]

Then

\[
q_n(0)=\beta_n,\quad q_n(1)=\alpha_n,\quad
q_n([0,1])\subset[\alpha_n,\beta_n].
\tag{3.8}
\]

The radial function may backtrack. We will keep its actual contact parameter instead of choosing an inverse.

The phase error is uniformly small on this whole growing annulus:

\[
\frac1{\Lambda_n}
\|\vartheta_n-F(q_n)\|_\infty\longrightarrow0.
\tag{3.9}
\]

To verify this point explicitly, the error in (2.3) is uniformly \(o(F'(q))\) for these contacts, since their radii tend uniformly to zero. Monotonicity bounds \(F'(q)\le F'(\beta_n)\), while (2.2) at \(S_n(M)\), with the fixed shift \(C+1\), gives

\[
\frac{F'(\beta_n)}{\Lambda_n}
=M\frac{F'(S_n(M)+C+1)}{F'(S_n(M))}\longrightarrow M.
\tag{3.10}
\]

Thus the fact that the logarithmic width may grow does not invalidate (3.9).

### 3.3. Seven equations preserve actual incidence

On \((0,1)^4\times U\), use four independent contact variables \(\xi_j\). The four radius equations are

\[
q_n(\xi_j)-S_n(\mu)+\ell_j(w)=0,
\qquad 0\le j\le3.
\tag{3.11}
\]

The three exact relative phase equations are

\[
\frac{\vartheta_n(\xi_j)-\vartheta_n(\xi_0)
-(\phi_j-\phi_0)}{\Lambda_n}-y_{n,j}=0,
\qquad 1\le j\le3.
\tag{3.12}
\]

First homotope (3.12) to

\[
\frac{F(q_n(\xi_j))-F(q_n(\xi_0))}{\Lambda_n}-y_{n,j}.
\tag{3.13}
\]

The change tends uniformly to zero, by (3.9) and boundedness of the argument terms. There is no boundary zero on a contact face: (3.7) makes the corresponding equation (3.11) nonzero. On \((w,\mu)\in\partial U\), vanishing of all radius equations reduces (3.13) to \(G_n(w,\mu)-y_n\), which stays away from zero by (3.5)–(3.6) and the boundary margin \(\delta\). The first homotopy is therefore admissible for large \(n\).

Next homotope \(q_n\), in both (3.11) and (3.13), to the decreasing affine map

\[
q_{n,1}(\xi)=\beta_n-(\beta_n-\alpha_n)\xi.
\tag{3.14}
\]

The straight homotopy preserves the endpoint values and stays in the same logarithmic annulus. The boundary argument remains valid exactly. At its endpoint the four radius equations have the unique solutions

\[
\xi_j=\frac{\beta_n-S_n(\mu)+\ell_j(w)}{\beta_n-\alpha_n}\in(0,1).
\tag{3.15}
\]

Eliminating them leaves \(G_n(w,\mu)=y_n\). Product degree gives the full seven-dimensional degree as

\[
(-1)^4\deg(G_n,U,y_n)=-1.
\tag{3.16}
\]

This elimination does not require differentiability of \((F')^{-1}\). One may first deform the phase equations to \(G_n(w,\mu)-y_n\); their values where the four radius equations vanish remain unchanged, so no boundary zero appears. Then continuously move each root in (3.15) to \(1/2\). These roots stay inside the contact interval, and the four affine radius equations each have degree \(-1\). Ordinary product degree proves (3.16).

The original equations (3.11)–(3.12) consequently have a zero. At such a zero, put \(\psi_n=\vartheta_n(\xi_0)-\phi_0\). The four actual path points are exactly

\[
r_0e^{-S_n(\mu_n)}e^{i\psi_n}(w_n+i^j),
\qquad j=0,1,2,3.
\tag{3.17}
\]

They form a nondegenerate square. All lie in the annulus whose outer radius tends to zero, and hence approach \(P\). The local inverse and uniform error control also give \((w_n,\mu_n)\to(2,1)\).

### 3.4. The other circumdisk position

For \(I(w)=1/\overline w\),

\[
\ell_j(Iw)=\ell_j(w)-\log|w|,
\qquad D(Iw)=D(w).
\tag{3.18}
\]

Inversion reverses orientation in the shape plane. Thus the same cone map has a regular point with the opposite local degree at \((w,\mu)=(1/2,1)\), and the same limiting target \(h_*\). Repeating the proof in that neighborhood gives another actual square for the same rounded target.

The first squares have \(|w_n|>1\), placing \(P\) outside the closed circumdisk. The second have \(|w_n|<1\), placing \(P\) inside the open circumdisk. They are distinct geometric squares. No uniqueness or exact matching of their physical radii is asserted. This completes the proof of Theorem 17. \(\square\)

## 4. Explicit slow-growth families

For

\[
F(T)=aT^\nu,\qquad a>0,\quad\nu>1,
\]

one has \(F'(T)=a\nu T^{\nu-1}\), which satisfies (2.1)–(2.2). The allowed path law is

\[
\Theta(t)=aT(t)^\nu+o(T(t)^{\nu-1}).
\tag{4.1}
\]

Here

\[
S_n(\mu)=\left(\frac{\Lambda_n\mu}{a\nu}\right)^{1/(\nu-1)}.
\tag{4.2}
\]

In particular, every exponent \(\nu>1\) is covered. A restriction such as \(\nu>2\), which would arise from insisting that the second derivative diverge on fixed logarithmic windows, is unnecessary. The proof permits the window itself to widen.

For \(F(T)=T\log T\),

\[
F'(T)=1+\log T,\qquad S_n(\mu)=e^{\Lambda_n\mu-1},
\]

and the allowed error is \(o(\log T)\). These formulas show how widely separated the physical scales can be. The theorem gives existence arbitrarily near the endpoint, with no assertion that the square's side remains within a fixed multiplicative factor of one prescribed reference radius.

Since \(F'\to\infty\), any bounded continuous angular perturbation satisfies the error hypothesis. Reflection handles the corresponding negative leading angular direction. Neither statement makes an arbitrary error \(o(F(T))\) sufficient: that larger error can swamp the relative phases used in (3.5).

## 5. Access paths and envelope tails

**Corollary 18 — a growing-slope access path forces boundary squares.** Let \(\Gamma\) be a Jordan curve and \(P\in\Gamma\). If a complementary access path satisfies (2.1)–(2.3), then \(\Gamma\) contains squares arbitrarily close to \(P\), with both circumdisk positions from Theorem 17.

**Proof.** For a simple access arc, Lemma 6 of `continuation_centered_spin.md` bounds the boundary angle between the minimum and maximum access angles at the same radius, plus two fixed multiples of \(2\pi\). At radius \(R\), all access angles equal \(F(T)+o(F'(T))\), uniformly among returns. Since \(F'(T)\to\infty\), the fixed multiples of \(2\pi\) are negligible. Thus the actual boundary arc has the same estimate (2.3), and Theorem 17 applies.

For a self-intersecting access path, the local argument branch and path-to-arc extraction proved in Theorem 7 of that continuation preserve this estimate. The simple-arc proof then applies. \(\square\)

**Corollary 19 — finite envelope shapes with this angular law force squares.** Suppose

\[
Q_j(t)=P+r(t)e^{i\Theta(t)}(w(t)+i^j),\qquad
r(t)>0,\quad r(t)\to0,\quad w(t)\to w_*\in\mathbb C,
\tag{5.1}
\]

with two adjacent corners in the open exterior and the other two in the open interior of one Jordan curve \(\Gamma\). Suppose

\[
\Theta(t)=F\!\left(\log\frac{r_0}{r(t)}\right)
+o\!\left(F'\!\left(\log\frac{r_0}{r(t)}\right)\right),
\tag{5.2}
\]

where \(F\) satisfies (2.1)–(2.2). Then \(\Gamma\) has squares arbitrarily close to \(P\). A centered limit \(w_*=0\) is included, and \(r(t)\) need not be monotone.

**Proof.** As before, the complementary positions imply \(P\in\Gamma\). Choose an exterior corner whose coefficient \(c(t)=w(t)+i^j\) tends to \(c\ne0\). Its radius is \(R(t)=r(t)|c(t)|\). Use the fixed reference radius \(r'_0=r_0|c|\) for this corner. Then

\[
T_A(t):=\log\frac{r'_0}{R(t)}
=\log\frac{r_0}{r(t)}+\log\frac{|c|}{|c(t)|}
=T(t)+o(1).
\tag{5.3}
\]

Condition (2.2) implies \(F'(T_A)/F'(T)\to1\), and the fundamental theorem of calculus gives

\[
F(T_A)-F(T)=o(F'(T)).
\tag{5.4}
\]

The bounded argument of \(c(t)\) is also \(o(F'(T))\). Therefore this actual complementary corner path satisfies (2.3), with \(T_A\) in place of \(T\). Apply Corollary 18. \(\square\)

## 6. What this resolves and what remains

The fixed-annulus classification remains correct. For \(F(T)=aT^\nu\), the first large-amplitude relative profile on a bounded logarithmic radius window is a multiple of \(\log r\), and has rank two. Theorem 17 obtains a third parameter from actual physical scales at which \(F'\) differs by a fixed proportion. This yields a full-rank limiting map \(-\mu D(w)\) on a wider annular crossing.

This is a sufficient square-existence theorem for an additional class, including slow angular growth and rough bounded perturbations. It does not prove that a general Jordan curve or envelope has an angular function of the form (2.3). The essential unresolved points include:

- angular models without the locally controlled large-slope intervals treated in `continuation_slope_reversals.md`;
- errors known only to be \(o(F)\), without the finer \(o(F')\) control;
- exceptional affine squared-radius profiles and other residual regimes not handled here;
- normalized envelope shapes without a finite limit or the weaker corner control in that later continuation, and tails with no fixed limiting physical point.

A constant logarithmic slope does not satisfy (2.1); this theorem makes no assertion about that case. The new local opposite-degree squares also do not provide a global cancellation or control every collision boundary in the Toeplitz program.

## 7. Exact verification and proof dependencies

The shared checker `verify_profile_classification.py` now expands the cone determinant at \(w=2\) symbolically in two independent formal variables for \(\log3\) and \(\log5\). It obtains (1.3), and its sign uses the exact integer inequality \(19683>3125\). No decimal logarithms, floating-point root solving, or interval arithmetic enter this check.

The existence proof uses only uniform convergence, the fundamental theorem of calculus, the continuous inverse of a strictly increasing function, and Brouwer degree. The enlargement to four actual contact parameters follows the earlier backtracking proof, with an explicit new error bound (3.9) on the widening annulus. No differentiability of the actual path or of the inverse slope function is assumed.

The access-path corollaries use the already stated angular-separation and path-to-arc results from `continuation_centered_spin.md`, which records their primary-source topological reference. The envelope corollary uses its stated complementary corner conditions. No unproved global normal form is used.
