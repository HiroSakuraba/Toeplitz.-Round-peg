# Continuation: classifying phase profiles and forcing squares with oscillating spin

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026  
**Status:** Exact profile classification and local square-existence theorems under stated hypotheses. This does not prove the general Toeplitz conjecture. No priority claim is made.

**Next continuation:** `continuation_logarithmic_slope.md` treats one of the rank-loss cases identified here. A logarithmic profile with an unbounded, sufficiently slowly changing slope can recover the scale direction on widening annular crossings. The fixed-profile classification below remains unchanged.

**Further extension:** `continuation_slope_reversals.md` replaces monotone slope growth by controlled crossings of arbitrarily large slope levels and admits certain nonconvergent normalized shapes. It does not alter the exact rank-loss classification.

This continues `continuation_centered_spin.md`, whose Theorems 5–7 allow radial backtracking and transfer a power-like angular law from an access path to the Jordan boundary. The present note identifies exactly which nonconstant \(C^1\) limiting profiles make the three-dimensional phase Jacobian singular everywhere. It then proves square existence for oscillating logarithmic modulation, including profiles that do not have a power asymptotic.

The exceptional profiles are affine functions of **squared radius** and logarithms of affine functions of squared radius. The shift inside the logarithm matters: the earlier examples \(r^2\) and \(\log r\) did not exhaust the rank-loss possibilities.

## 1. Coordinates adapted to the four actual radii

Write a normalized square as

\[
z_j=s\tau e^{i\psi}(w+i^j),\qquad
w=x+iy,\quad \tau>0,\quad j=0,1,2,3.
\tag{1.1}
\]

Here \(s\) is a small reference scale. Put

\[
A=\tau^2(1+x^2+y^2),\qquad
B=2\tau^2x,\qquad C=2\tau^2y.
\tag{1.2}
\]

The four squared radii divided by \(s^2\) become

\[
u_0=A+B,\quad u_1=A+C,\quad
u_2=A-B,\quad u_3=A-C.
\tag{1.3}
\]

Let \(I\subset(0,\infty)\) be an open interval. We use the open physical domain

\[
\mathcal D_I=\{(A,B,C): A>\sqrt{B^2+C^2},\quad u_j\in I\ (0\le j\le3)\}.
\tag{1.4}
\]

Indeed,

\[
A^2-B^2-C^2=\tau^4(1-|w|^2)^2.
\]

Conversely, when \(B^2+C^2>0\), every point of (1.4) has two lifts:

\[
\tau^2=\frac{A\pm\sqrt{A^2-B^2-C^2}}2,
\qquad w=\frac{B+iC}{2\tau^2}.
\tag{1.5}
\]

One has \(|w|<1\) and the other \(|w|>1\). When \(B=C=0\), only the positive solution \(\tau^2=A,w=0\) is valid. That point will always be singular for the phase map.

The coordinate Jacobian, with columns \((x,y,\tau)\), is

\[
\boxed{\det\frac{\partial(A,B,C)}{\partial(x,y,\tau)}
=8\tau^5(1-|w|^2).}
\tag{1.6}
\]

Thus (1.4) avoids the inversion fold \(|w|=1\). The two lifts in (1.5) are related by

\[
(w,\tau)\longmapsto(1/\overline w,\tau|w|),
\tag{1.7}
\]

which preserves all four radii.

## 2. The determinant is a symmetric second difference

Let \(g\in C^1(I)\) be a profile expressed in squared radius. A profile \(f\) in the earlier radius convention corresponds to \(g(u)=f(\sqrt u)\). Define

\[
\Psi_g(A,B,C)=
\big(g(u_j)-g(u_0)\big)_{j=1}^3.
\tag{2.1}
\]

Set \(h_j=g'(u_j)\). Differentiation gives

\[
D\Psi_g=
\begin{pmatrix}
h_1-h_0&-h_0&h_1\\
h_2-h_0&-h_2-h_0&0\\
h_3-h_0&-h_0&-h_3
\end{pmatrix}.
\tag{2.2}
\]

**Proposition 9 — universal determinant formula.** At every point of \(\mathcal D_I\),

\[
\boxed{\det D\Psi_g
=2(h_1h_2h_3+h_0h_1h_3-h_0h_2h_3-h_0h_1h_2).}
\tag{2.3}
\]

Where all four derivatives are nonzero, put \(k(u)=1/g'(u)\). Then

\[
\boxed{\det D\Psi_g
=2\prod_{j=0}^3 g'(u_j)
\left[k(A+B)+k(A-B)-k(A+C)-k(A-C)\right].}
\tag{2.4}
\]

**Proof.** Expand the determinant in (2.2). Factoring the product of its four nonzero slopes gives (2.4). Formula (2.3) remains valid when one or more slopes vanish. \(\square\)

For the earlier shape map

\[
H_g(w,\tau)=\big(g(\tau^2|w+i^j|^2)
-g(\tau^2|w+1|^2)\big)_{j=1}^3,
\tag{2.5}
\]

the determinant is therefore

\[
\det DH_g=16\tau^5(1-|w|^2)\prod_jg'(u_j)\,K(A,B,C),
\tag{2.6}
\]

with \(K\) the bracket in (2.4), whenever the reciprocal slopes are defined. The inversion fold and the profile-dependent factor have separate explicit roles.

A convenient sufficient test uses \(C=0\). If \(k\) is twice continuously differentiable near \(A\), then

\[
K(A,B,0)=k''(A)B^2+o(B^2).
\tag{2.7}
\]

Consequently \(g'(A)\ne0\) and \(k''(A)\ne0\) give a regular physical point for sufficiently small nonzero \(B\). This differential test needs extra smoothness; the classification below needs only \(g\in C^1\).

## 3. Complete classification of everywhere-singular profiles

**Theorem 10 — classification on an interval.** For \(g\in C^1(I)\), the following are equivalent:

1. \(\det D\Psi_g=0\) everywhere on \(\mathcal D_I\).
2. Throughout \(I\), either

\[
g(u)=a u+b,
\tag{3.1}
\]

including the constant case, or

\[
g(u)=a\log|u-b|+c,
\qquad a\ne0,\quad b\notin I.
\tag{3.2}
\]

**Proof.** Suppose the determinant vanishes everywhere. If \(g'\equiv0\), the conclusion is immediate. Otherwise let \(J\) be a connected component of the open set where \(g'\ne0\). For any \(A-B,A+B\in J\), with \(C=0\), positivity gives \(A>|B|\), so this is an admissible physical triple. Formula (2.4) yields

\[
k(A+B)+k(A-B)=2k(A),\qquad k=1/g'.
\tag{3.3}
\]

This is the midpoint identity on \(J\). A continuous function satisfying it is affine: dyadic subdivision gives the affine interpolation identity first at dyadic fractions, and continuity gives it at every fraction. Hence

\[
k(u)=\alpha u+\beta\quad(u\in J).
\tag{3.4}
\]

The component \(J\) cannot terminate at a point \(d\) in the interior of \(I\). At such an endpoint, continuity and maximality would require \(g'(u)\to g'(d)=0\). But \(g'(u)=1/(\alpha u+\beta)\) cannot tend to zero at a finite endpoint: it either has a nonzero finite limit or becomes unbounded. Thus \(J=I\).

Integrating (3.4) now gives (3.1) if \(\alpha=0\), or (3.2) if \(\alpha\ne0\). The root of \(\alpha u+\beta\) lies outside \(I\), because \(g'\) is finite and nonzero there.

Conversely, every nonconstant function in (3.1) or (3.2) has affine reciprocal derivative. Its bracket in (2.4) vanishes identically. A constant profile is covered directly by (2.3). \(\square\)

The rank loss can also be seen without differentiating. If \(H_j=g(u_j)-g(u_0)\), an affine profile satisfies

\[
H_2=H_1+H_3.
\tag{3.5}
\]

For (3.2), all \(u_j-b\) have the same sign, and

\[
1+e^{H_2/a}=e^{H_1/a}+e^{H_3/a}.
\tag{3.6}
\]

These follow from \(u_0+u_2=u_1+u_3=2A\). Their images lie in surfaces of dimension at most two.

The theorem classifies **everywhere-singular limiting phase maps**. It does not classify square-free curves. It also does not say that an arc with an exceptional profile contains no squares: the present leading-profile degree argument simply has no regular point to use.

## 4. A general profile theorem on a continuous path

Let \(\eta:[0,t_0]\to\mathbb C\) be continuous, with \(\eta(0)=P\) and \(\eta(t)\ne P\) for \(t>0\). Put \(R(t)=|\eta(t)-P|\), and choose a continuous lift \(\Theta(t)\) of its angle about \(P\).

Assume there are scales \(s_n\downarrow0\), positive amplitudes \(L_n\to\infty\), offsets \(b_n\in\mathbb R\), and a profile \(g\in C^1(I)\) such that for every compact interval \(J\subset I\),

\[
E_n(J):=\sup_{\substack{0<t\le t_0\\R(t)^2/s_n^2\in J}}
\left|\frac{\Theta(t)-b_n}{L_n}
-g\!\left(\frac{R(t)^2}{s_n^2}\right)\right|\longrightarrow0.
\tag{4.1}
\]

The supremum includes **all radial returns**. Since \(\eta\) avoids \(P\) away from its endpoint, all the parameters occurring in this supremum tend to zero as \(n\to\infty\).

**Theorem 11 — a nonexceptional large-amplitude profile forces squares.** If (4.1) holds and \(g\) is outside both families in Theorem 10, then for every sufficiently large \(n\), the image of \(\eta\) contains a nondegenerate square at scale comparable to \(s_n\). The vertices approach \(P\). Neither radius nor angle must be monotone, and \(\eta\) need not be injective or differentiable.

### Proof with four actual contact parameters

Translate \(P\) to zero. Theorem 10 gives a regular point of \(\Psi_g\) in \(\mathcal D_I\). This point cannot have \(B=C=0\), where the determinant is zero. Choose either lift \(\sigma_*=(w_*,\tau_*)\) from (1.5). Equation (1.6) makes it a regular point of \(H_g\).

Choose a small neighborhood \(U\) of \(\sigma_*\) with compact closure on which \(H_g\) is one-to-one and has a continuously differentiable inverse onto its image. Set

\[
h_*=H_g(\sigma_*),\qquad
\delta=\operatorname{dist}(h_*,H_g(\partial U))>0.
\]

Choose \(0<a<b\) such that \([a^2,b^2]\subset I\) and

\[
a<\rho_j(\sigma):=\tau|w+i^j|<b
\quad(\sigma\in\overline U,\ 0\le j\le3).
\tag{4.2}
\]

For each large \(n\), take the first path contact with radius \(bs_n\), and the last preceding contact with radius \(as_n\). The interval between them is an actual annular crossing and lies in \([as_n,bs_n]\). Affinely parametrize this interval by \(\xi\in[0,1]\), writing

\[
q_n(\xi)=R(t_n(\xi))/s_n,\qquad
\vartheta_n(\xi)=\frac{\Theta(t_n(\xi))-b_n}{L_n}.
\]

Then \(q_n(0)=a,q_n(1)=b\), and

\[
\|\vartheta_n-g(q_n^2)\|_\infty\le E_n([a^2,b^2])\to0.
\tag{4.3}
\]

No inverse of \(q_n\) is selected. On \((0,1)^4\times U\), keep four independent actual parameters \(\xi_0,\ldots,\xi_3\). Choose continuous local arguments \(\phi_j=\arg(w+i^j)\). Round each component of \(L_nh_*/(2\pi)\) to an integer \(m_{n,j}\), and put

\[
y_n=\frac{2\pi m_n}{L_n},\qquad
\|y_n-h_*\|\le\frac{\pi\sqrt3}{L_n}.
\tag{4.4}
\]

Use the seven equations

\[
q_n(\xi_j)-\rho_j(\sigma)=0\quad(0\le j\le3),
\tag{4.5}
\]

\[
\vartheta_n(\xi_j)-\vartheta_n(\xi_0)
-\frac{\phi_j-\phi_0}{L_n}-y_{n,j}=0
\quad(1\le j\le3).
\tag{4.6}
\]

First homotope the three phase expressions to

\[
g(q_n(\xi_j)^2)-g(q_n(\xi_0)^2)-y_{n,j}.
\tag{4.7}
\]

There is no zero on a contact face \(\xi_j=0\) or \(1\), by (4.2). On the remaining boundary, \(\sigma\in\partial U\); if the radius equations vanish, (4.7) equals \(H_g(\sigma)-y_n\). If

\[
M=\sup_{\sigma\in\overline U}
\| (\phi_j-\phi_0)_{j=1}^3\|,
\]

an explicit sufficient boundary margin is

\[
2\sqrt3 E_n([a^2,b^2])+\frac{M+\pi\sqrt3}{L_n}<\delta.
\tag{4.8}
\]

It holds for large \(n\). Thus the first homotopy preserves degree.

Next replace \(q_n\), in both the radius equations and the model phase equations (4.7), by

\[
q_{n,v}(\xi)=(1-v)q_n(\xi)+v(a+(b-a)\xi),\qquad0\le v\le1.
\tag{4.9}
\]

The endpoints remain \(a,b\), and the same boundary argument applies exactly. At \(v=1\), the four radius equations have the unique solutions

\[
\xi_j=\frac{\rho_j(\sigma)-a}{b-a}\in(0,1).
\]

Elimination leaves \(H_g(\sigma)=y_n\), which has one regular solution in \(U\) for large \(n\). With contact variables first, the full Jacobian determinant is

\[
(b-a)^4\det DH_g(\sigma)\ne0.
\tag{4.10}
\]

The seven-dimensional degree is therefore \(\pm1\), and the original equations have a zero. At that zero put

\[
\psi_n=\Theta(t_n(\xi_0))-\phi_0.
\]

The radius equations and the exact phase equations modulo \(2\pi\) identify the four actual path points with

\[
s_n\tau_n e^{i\psi_n}(w_n+i^j),\qquad 0\le j\le3.
\tag{4.11}
\]

They are four distinct spatial points because \(s_n\tau_n>0\). The uniform phase approximation and the local inverse give \((w_n,\tau_n)\to(w_*,\tau_*)\). All contact parameters lie before the first radius-\(bs_n\) contact, which tends to zero. This proves the theorem. \(\square\)

The divergent amplitude is essential to this proof: it makes the normalized lattice spacing and the bounded argument corrections tend to zero. A nonzero Jacobian at one fixed finite scale does not alone imply an exact lattice hit.

### Two squares and the inversion pairing

The proof can be run at both lifts in (1.5), using the same target \(h_*\) and lattice vector \(m_n\). Their local degrees are opposite, because (1.6) has opposite signs on the two lifts while \(D\Psi_g\) is unchanged. Each local degree remains nonzero under the homotopies.

In fact Theorem 11 therefore gives **at least two distinct squares** for every sufficiently large \(n\): one whose open circumdisk contains \(P\), and one whose closed circumdisk excludes \(P\). These properties follow from \(|w_n|<1\) and \(|w_n|>1\), respectively, and distinguish the two actual squares independently of vertex labeling.

For a rough actual path, no uniqueness of either root is asserted. The statement concerns nonzero total degree in each of two small parameter regions. It also supplies no global cancellation across the singular boundary of all square configurations.

## 5. Transfer from an access path to the Jordan boundary

**Theorem 12 — general profile transfer.** Let \(\Gamma\) be a Jordan curve, \(P\in\Gamma\), and let \(\eta\) be a continuous access path with \(\eta(0)=P\) and \(\eta(t)\notin\Gamma\) for \(t>0\). Suppose its angular lift satisfies (4.1) with a nonexceptional \(g\in C^1(I)\). Then \(\Gamma\) contains squares arbitrarily close to \(P\). The two circumdisk conclusions above also hold along the scales \(s_n\).

**Proof.** First suppose the access path is a simple arc \(\alpha\). Take a simple boundary subarc \(\beta\) starting at \(P\), disjoint from \(\alpha\) except at \(P\), and truncate both at their first exit from one fixed small circle. Lemma 6 in `continuation_centered_spin.md` gives one integer \(k\), independent of radius, such that

\[
m_\alpha(r)+2\pi k<\theta_\beta
<M_\alpha(r)+2\pi(k+1)
\tag{5.1}
\]

at every boundary contact of radius \(r\). Here the minimum and maximum are over all access-arc contacts at that radius. For \(r^2/s_n^2\in J\), condition (4.1) places both these extrema within

\[
b_n+L_n g(r^2/s_n^2)\ \pm\ L_n E_n(J).
\]

After division by \(L_n\), the fixed integer offsets contribute at most \(2\pi\max(|k|,|k+1|)/L_n\). Thus (4.1) transfers uniformly to every boundary-arc contact. Apply Theorem 11.

For an access path with self-intersections, the reduction in Theorem 7 of the previous continuation still applies. Briefly, choose a small ball about \(P\) with a point of \(\Gamma\) outside it. The component of the ball minus \(\Gamma\) containing the access tail admits a continuous argument branch: every loop in that component has winding zero about \(P\), since its winding is constant on the connected set \(\Gamma\) and zero at the boundary point outside the ball. The chosen angular lift differs from this branch by a fixed multiple of \(2\pi\).

A simple access arc can be extracted from the path trace. The argument branch and the estimate over all returns preserve (4.1) on this extracted arc, up to the negligible fixed lift constant. The simple-arc case finishes the proof. \(\square\)

The estimate over all returns is an actual hypothesis here. A phase law on one selected annular crossing need not control the other contacts that enter (5.1).

## 6. A new family: nontrivial periodic modulation

**Corollary 13 — periodic modulation of arbitrary size.** Let \(p>0\), and let \(P\in C^1(\mathbb R)\) be periodic and not identically zero. Suppose a continuous path approaching its endpoint satisfies

\[
\Theta(t)=R(t)^{-p}P(\log R(t))+o(R(t)^{-p}).
\tag{6.1}
\]

Its image contains squares arbitrarily near the endpoint. If it is an access path to a Jordan curve, the boundary contains such squares. The radius may backtrack, and \(P\) may change sign.

**Proof.** Let \(T>0\) be a period, and set

\[
s_n=e^{-nT},\qquad L_n=s_n^{-p},\qquad b_n=0.
\]

The squared-radius limiting profile on \((0,\infty)\) is exactly

\[
g(u)=u^{-p/2}P\!\left(\tfrac12\log u\right).
\tag{6.2}
\]

The remainder in (6.1) gives (4.1) uniformly on each compact interval, because all contacts there approach the endpoint and \(u^{-p/2}\) is bounded on that interval. The function \(g\) is \(C^1\), is not identically zero, and tends to zero as \(u\to\infty\), since \(P\) is bounded.

No nonzero affine function on \((0,\infty)\) tends to zero at infinity. No nonconstant shifted logarithm defined on this whole interval does so either. Hence \(g\) is outside both exceptional families. Apply Theorem 11 or Theorem 12. \(\square\)

The modulation is allowed at leading order. It need not be a small error around a positive constant. In particular, a nonconstant periodic \(P\) generally prevents a single power asymptotic or regular variation, while the new theorem still applies.

### An explicit regular point for an oscillating example

Consider

\[
\Theta(r)=r^{-2}\big[3+\sin(2\log r)\big].
\tag{6.3}
\]

With \(s_n=e^{-n\pi}\), its profile is

\[
g(u)=\frac{3+\sin(\log u)}u.
\]

At \(u=1\),

\[
g'(1)=-2,\qquad g''(1)=3,\qquad g'''(1)=-8.
\]

For \(k=1/g'\),

\[
k''(1)=\frac{2g''(1)^2-g'(1)g'''(1)}{g'(1)^3}
=-\frac14.
\tag{6.4}
\]

Consequently

\[
\det D\Psi_g(1,B,0)=-8B^2+o(B^2),
\tag{6.5}
\]

which is nonzero for sufficiently small nonzero \(B\). This supplies an explicit local test, in addition to the classification proof. The accompanying script verifies the derivatives and the coefficient \(-8\) by exact rational Taylor jets.

## 7. Periodicity can be replaced by compactness of translates

**Corollary 14 — bounded modulation with controlled derivatives.** In (6.1), replace periodicity by

\[
P\in C^2(\mathbb R),\qquad
\sup_{\mathbb R}(|P|+|P'|+|P''|)<\infty,
\qquad
\limsup_{x\to-\infty}|P(x)|>0.
\tag{7.1}
\]

The same conclusions hold, along a sequence of scales tending to zero. No periodicity or convergence of \(P(x)\) as \(x\to-\infty\) is required.

**Proof.** Choose \(x_n\to-\infty\) with \(|P(x_n)|\ge c>0\). The translates \(P(x_n+v)\), and their first derivatives, are uniformly bounded and equicontinuous on every compact \(v\)-interval. Arzelà–Ascoli and a diagonal subsequence give convergence in \(C^1_{\mathrm{loc}}(\mathbb R)\) to a bounded \(C^1\) function \(P_*\), with \(|P_*(0)|\ge c\). Passing to a further subsequence makes \(s_n=e^{x_n}\) strictly decrease to zero.

With \(L_n=s_n^{-p}\), the limiting profile is

\[
g_*(u)=u^{-p/2}P_*\!\left(\tfrac12\log u\right).
\tag{7.2}
\]

It is \(C^1\), is nonzero at \(u=1\), and tends to zero as \(u\to\infty\). Thus it is nonexceptional. Local uniform convergence of the translates and the remainder in (6.1) give (4.1), including all radial returns. Theorems 11–12 apply. \(\square\)

The derivative bounds in (7.1) are a sufficient compactness hypothesis. They have not been proved for arbitrary curve or envelope data. They are not regularity assumptions on the actual path: its lower-order phase error may still be only continuous.

## 8. Consequence for finite-shape envelope tails

**Corollary 15 — oscillating power-scale spin also excludes finite shape limits.** Suppose continuous corner paths have the form

\[
Q_j(t)=P_0+r(t)e^{i\Theta(t)}(w(t)+i^j),
\qquad j=0,1,2,3,
\tag{8.1}
\]

with \(r(t)>0\), \(r(t)\to0\), and \(w(t)\to w_*\in\mathbb C\). Suppose the first two corners lie in the open exterior of a Jordan curve \(\Gamma\), and the other two in its open interior. Assume

\[
\Theta(t)=r(t)^{-p}P(\log r(t))+o(r(t)^{-p}),\qquad p>0,
\tag{8.2}
\]

where \(P\) satisfies either Corollary 13 or Corollary 14. Then \(\Gamma\) contains squares arbitrarily close to \(P_0\). This includes \(w_*=0\), and no monotonicity of \(r\) is assumed.

**Proof.** All corners tend to \(P_0\); their opposite complementary positions imply \(P_0\in\Gamma\). At least one exterior limiting coefficient \(c=w_*+1\) or \(c=w_*+i\) is nonzero. Choose that corner, write \(c(t)=w(t)+i^j\), and let \(R=r(t)|c(t)|\) be its radius about \(P_0\). A continuous argument of \(c(t)\) remains bounded near the endpoint.

Both sets of hypotheses give a bounded derivative for \(P\). Since \(c(t)\to c\ne0\), substituting \(r=R/|c(t)|\) into (8.2) gives

\[
\arg(Q_j-P_0)=R^{-p}\widetilde P(\log R)+o(R^{-p}),
\tag{8.3}
\]

where

\[
\widetilde P(x)=|c|^p P(x-\log|c|).
\tag{8.4}
\]

The changes of coefficient and argument contribute \(o(R^{-p})\); the bounded lift correction does too. The transformed function retains periodicity and nontriviality, or all the properties in (7.1), respectively. The corner is an actual complementary access path, so Corollary 13 or 14 forces the boundary squares. \(\square\)

Only these local complementary positions are used from the square-envelope framework. No assertion about a universal phase normal form, or about the unproved higher-dimensional Spiral Conjecture, enters the proof.

## 9. What is now established, and the precise remaining problem

| Question | Result of this continuation |
|---|---|
| Which \(C^1\) profiles lose phase rank at every physical shape? | Exactly affine and shifted-logarithmic functions of squared radius |
| Can a nonexceptional profile reach four actual curve points? | Yes, with diverging amplitude and the uniform annular estimate (4.1), using four independent contact parameters |
| Does radial backtracking destroy the degree? | No; the enlarged incidence map keeps the contact parameters and has nonzero degree |
| Can leading oscillations replace a fixed power coefficient? | Yes for nonzero periodic modulation, and for the compactness class (7.1) |
| Does this apply to a complementary corner track? | Yes; uniform angular comparison transfers the profile to an actual boundary arc |
| Are arbitrary square-envelope tails covered? | No extraction theorem supplying these hypotheses has been proved |

A square-free arc satisfying (4.1) with a \(C^1\) profile would have to have one of the two exceptional profiles. This is a conditional conclusion. A general continuous arc might have no controlled \(C^1\) profile at all, or its available normalizations might yield only exceptional profiles. A normalized shape may also fail to converge, and a collapsing envelope need not have one fixed physical limit point.

The companion `continuation_logarithmic_slope.md` now treats a logarithmic leading profile with an increasing unbounded slope that changes by a negligible proportion over bounded shifts of logarithmic radius. It uses a wider annulus to realize that slope as a third parameter. Exceptional affine profiles and other residual regimes remain untreated. A further residual argument would need a correctly scaled multidimensional lattice argument: small rank-restoring terms and large total winding do not by themselves supply the boundary margin (4.8). Obtaining useful compactness directly from the interior/exterior separation of an arbitrary envelope also remains open in this work.

The advances above are square-existence statements for explicit additional classes, together with a complete algebraic classification of the obstruction to this particular profile method. They do not provide a contradiction for every possible continuous Jordan counterexample.

## 10. Verification and dependencies

`verify_profile_classification.py` uses only the Python standard library. Its exact checks are:

1. Expansion of the universal determinant as a polynomial in four independent slopes, agreeing with all four cubic monomials in (2.3).
2. Symbolic differentiation and determinant expansion for the coordinate map (1.2), giving (1.6).
3. Exact rational affine and shifted-log derivative examples, and agreement with the earlier \(p=2\) shape determinant \(-19327352832/133984375\).
4. Rational Taylor jets at \(u=1\) for the example (6.3), yielding \(k''(1)=-1/4\) and the determinant coefficient \(-8\).
5. The logarithmic cone determinant used in the next continuation, with its sign certified by the integer inequality \(3^9>5^5\).

`profile_classification_verification_output.txt` records the completed run. No floating-point or interval arithmetic is used in this new checker. It verifies algebra; the midpoint argument, boundary homotopies, angular separation, and compactness arguments are the proofs of the corresponding theorems. Individual squares on an arbitrary continuous path are not numerically certified by the script.

Theorem 12 uses Lemma 6 and the path-to-arc reduction of Theorem 7 in `continuation_centered_spin.md`. Their stated topological inputs are Jordan separation for proper arcs and the standard path-to-arc theorem. That earlier continuation provides the primary-source reference for the latter. Corollary 15 uses only the local interior/exterior requirements of the envelope, which are also documented there.

The determinant calculation, classification, and modulation arguments here are direct derivations. The supplied v148 material remains the underlying research record. This is an additive post-v148 continuation; it does not replace the archive or claim a completed Toeplitz proof.
