# Continuation: slope reversals, large peaks, and changing normalized shapes

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026  
**Status:** Additional local square-existence theorems with explicit hypotheses, and an exact example showing why a regularity condition is needed. This does not complete Toeplitz. No priority claim is made.

The preceding `continuation_logarithmic_slope.md` required the model angular slope to increase strictly to infinity. The present continuation removes both strict monotonicity and convergence to infinity. It is enough to have arbitrarily large slope peaks with controlled variation over bounded logarithmic-radius shifts. The derivative may reverse sign repeatedly.

There is also a geometric extension. A full limit of the normalized envelope shape is unnecessary if one complementary corner has a convergent nonzero distance ratio and its additional angular motion is small compared with the large model slope. This covers some normalized shapes that keep rotating forever.

## 1. The hypotheses only concern contacts with large model slope

Let \(\eta:[0,t_0]\to\mathbb C\) be continuous, with \(\eta(0)=P\), \(\eta(t)\ne P\) for \(t>0\), and a continuous angular lift \(\Theta(t)\) about \(P\). Fix \(r_0>0\), and put

\[
R(t)=|\eta(t)-P|,\qquad T(t)=\log\frac{r_0}{R(t)}.
\tag{1.1}
\]

Let \(F\in C^1([T_0,\infty))\), and write \(a(T)=F'(T)\). Assume

\[
\limsup_{T\to\infty}|a(T)|=\infty.
\tag{1.2}
\]

For every fixed \(C>0\), require

\[
\sup_{|u|\le C}\frac{|a(T+u)-a(T)|}{|a(T)|}\longrightarrow0
\quad\text{as }T\to\infty\text{ and }|a(T)|\to\infty.
\tag{1.3}
\]

The actual path must satisfy

\[
\frac{|\Theta(t)-F(T(t))|}{|a(T(t))|}\longrightarrow0
\quad\text{as }t\downarrow0\text{ and }|a(T(t))|\to\infty.
\tag{1.4}
\]

These are joint, sequential limits. For example, (1.3) holds along every sequence \(T_n\to\infty\) for which \(|a(T_n)|\to\infty\), uniformly over the indicated bounded shifts. It makes no demand at a zero of \(a\). Likewise (1.4) covers every actual path contact whose model slope becomes large, including all returns to a radius. It does not impose a separate small-error requirement on contacts where \(|a|\) stays bounded.

A bounded continuous angular error satisfies (1.4). Errors such as \(O(\sqrt{1+|a|})\) do as well. The actual path need not be differentiable or injective, and neither its radius nor its angle needs to be monotone.

## 2. Nonmonotone slope peaks still force squares

**Theorem 20 — square existence from large, locally controlled slope peaks.** Under (1.2)–(1.4), the image of \(\eta\) contains nondegenerate squares arbitrarily close to \(P\). There are such squares with \(P\) inside the open circumdisk and such squares with \(P\) outside the closed circumdisk.

### 2.1. A full crossing of two slope levels replaces the inverse function

Translate \(P\) to zero. Reflection changes \((\Theta,F,a)\) to \((-\Theta,-F,-a)\) and preserves the assumptions and square existence. We may therefore assume that \(a\) is unbounded above.

Use the logarithmic shape map from the previous continuation:

\[
\ell_j(w)=\log|w+i^j|,\qquad
D(w)=(\ell_j(w)-\ell_0(w))_{j=1}^3,
\qquad H(w,\mu)=-\mu D(w).
\tag{2.1}
\]

Its exact determinant at \((w,\mu)=(2,1)\) is

\[
\det DH(2,1)=-\frac{2}{75}\log\frac{19683}{3125}<0.
\tag{2.2}
\]

Choose a small shape neighborhood \(V\) of \(2\) and constants \(0<m<1<M\) such that the compact closure of \(V\times(m,M)\) lies in a local inverse chart for \(H\). Put

\[
h_*=H(2,1),\qquad
\delta=\operatorname{dist}\big(h_*,H(\partial(V\times(m,M)))\big)>0.
\tag{2.3}
\]

Choose \(C>0\) with \(|\ell_j(w)|<C\) on \(\overline V\), and take continuous local arguments \(\phi_j=\arg(w+i^j)\) there.

Let \(\Lambda_n\to\infty\). For large \(n\), starting at one fixed \(T_0\), let \(B_n\) be the first time \(a(T)=M\Lambda_n\), and let \(A_n<B_n\) be the last preceding time \(a(T)=m\Lambda_n\). Continuity and unboundedness supply both. Their definitions imply

\[
m\Lambda_n\le a(T)\le M\Lambda_n
\quad(A_n\le T\le B_n).
\tag{2.4}
\]

Moreover \(A_n\to\infty\), since a continuous function is bounded on each fixed compact interval and \(a(A_n)=m\Lambda_n\to\infty\).

Parametrize the **whole** interval by

\[
S_n(v)=A_n+(B_n-A_n)v,\qquad
p_n(v)=\frac{a(S_n(v))}{\Lambda_n},\quad 0\le v\le1.
\tag{2.5}
\]

Then \(p_n\) is continuous, takes values in \([m,M]\), and has endpoints \(p_n(0)=m,p_n(1)=M\). It may reverse direction arbitrarily often. No inverse of \(a\) has been selected.

### 2.2. The phase map stays close to a cone with a backtracking coefficient

For a square of shape \(w\) and circumradius \(r_0e^{-S_n(v)}\), define

\[
G_n(w,v)=\frac1{\Lambda_n}
\big(F(S_n(v)-\ell_j(w))-F(S_n(v)-\ell_0(w))\big)_{j=1}^3.
\tag{2.6}
\]

The fundamental theorem of calculus gives

\[
G_{n,j}=-\frac1{\Lambda_n}
\int_{\ell_0(w)}^{\ell_j(w)}a(S_n(v)-u)\,du.
\]

Since \(S_n(v)\ge A_n\to\infty\) and \(a(S_n(v))\ge m\Lambda_n\to\infty\), (1.3) applies uniformly over the entire interval. Thus

\[
\sup_{\overline V\times[0,1]}
\big\|G_n(w,v)-H(w,p_n(v))\big\|\longrightarrow0.
\tag{2.7}
\]

There need not be a limiting function \(p_n\). It is enough that all of them have the same two endpoint levels.

Round \(\Lambda_n h_* /(2\pi)\) to \(k_n\in\mathbb Z^3\), and set

\[
y_n=2\pi k_n/\Lambda_n,
\qquad \|y_n-h_*\|\le\pi\sqrt3/\Lambda_n.
\tag{2.8}
\]

On \(\mathcal V=V\times(0,1)\), the map \(H(w,p_n(v))\) avoids \(h_*\) on the boundary by (2.3). Homotope \(p_n\) to

\[
p_{n,1}(v)=m+(M-m)v
\tag{2.9}
\]

by straight interpolation. All intermediate functions retain the endpoints and stay in \([m,M]\). On a shape face, their images lie in \(H(\partial V\times[m,M])\); on a scale face, they lie in \(H(\overline V\times\{m,M\})\). Hence the homotopy has no boundary zero. At the affine endpoint, its degree is the local degree of \(H\), since \(M-m>0\). Consequently

\[
\deg(G_n,\mathcal V,y_n)=-1
\tag{2.10}
\]

for all sufficiently large \(n\), by (2.7)–(2.8). Slope reversals have not removed the degree.

### 2.3. Control the padded annulus and retain actual contacts

Put

\[
\alpha_n=A_n-C-1,\qquad \beta_n=B_n+C+1.
\tag{2.11}
\]

The vertex logarithmic radii \(S_n(v)-\ell_j(w)\) lie inside this interval with margin at least one. On \([A_n,B_n]\), the slope bounds are (2.4). On the two padding intervals, (1.3), applied at the endpoints \(A_n,B_n\), supplies the same bounds up to a factor tending to one. In particular, for large \(n\),

\[
\tfrac m2\Lambda_n\le a(T)\le2M\Lambda_n
\quad(\alpha_n\le T\le\beta_n).
\tag{2.12}
\]

This estimate replaces the monotonicity bound used in the earlier theorem.

Select the first actual path contact with the outer radius \(r_0e^{-\alpha_n}\), and the last preceding contact with the inner radius \(r_0e^{-\beta_n}\). Parametrize this complete crossing by \(\xi\in[0,1]\). Write

\[
q_n(\xi)=T(t_n(\xi)),\qquad
\vartheta_n(\xi)=\Theta(t_n(\xi)).
\]

Its endpoints are \(q_n(0)=\beta_n,q_n(1)=\alpha_n\), and it stays in \([\alpha_n,\beta_n]\). All these actual contacts approach \(P\), and their model slopes tend uniformly to infinity by (2.12). Assumption (1.4) therefore gives

\[
\frac1{\Lambda_n}\|\vartheta_n-F(q_n)\|_\infty\to0.
\tag{2.13}
\]

On \((0,1)^4\times\mathcal V\), keep the four actual contact parameters \(\xi_j\). Use the seven equations

\[
q_n(\xi_j)-S_n(v)+\ell_j(w)=0\qquad(0\le j\le3),
\tag{2.14}
\]

\[
\frac{\vartheta_n(\xi_j)-\vartheta_n(\xi_0)
-(\phi_j-\phi_0)}{\Lambda_n}-y_{n,j}=0
\qquad(1\le j\le3).
\tag{2.15}
\]

First homotope the phase expressions to

\[
\frac{F(q_n(\xi_j))-F(q_n(\xi_0))}{\Lambda_n}-y_{n,j}.
\tag{2.16}
\]

The change is uniformly small by (2.13), and the argument corrections are bounded before division by \(\Lambda_n\). A contact face cannot be a zero of all radius equations, by the margin in (2.11). On a shape or scale face, whenever the four radius equations vanish, (2.16) equals \(G_n(w,v)-y_n\), which stays away from zero by the boundary argument above. Thus the first homotopy is admissible.

Next homotope \(q_n\), in both the radius and model phase equations, to

\[
q_{n,1}(\xi)=\beta_n-(\beta_n-\alpha_n)\xi.
\tag{2.17}
\]

The same boundary argument applies exactly. The four contacts can then be eliminated, leaving \(G_n(w,v)=y_n\). Each affine radius equation has degree \(-1\), so the four together contribute \((-1)^4=1\). The full seven-dimensional degree equals (2.10) and is nonzero.

At a zero of the original equations, the four actual path points are

\[
r_0e^{-S_n(v_n)}e^{i\psi_n}(w_n+i^j),\qquad
\psi_n=\vartheta_n(\xi_0)-\phi_0.
\tag{2.18}
\]

They are distinct and form a square. Their radii are bounded above by \(r_0e^{-\alpha_n}\to0\). The local inverse of \(H\) and the errors above give

\[
w_n\to2,\qquad p_n(v_n)\to1.
\tag{2.19}
\]

There is no claim that the scale parameters \(v_n\) themselves converge or that a branch is unique.

Finally, \(D(1/\overline w)=D(w)\). Repeating the construction near \(w=1/2\) gives the opposite local degree, as in the preceding continuation. The two shape regions lie on opposite sides of \(|w|=1\), giving distinct actual squares with the two stated circumdisk positions. \(\square\)

### A finite-window version without a differentiable angular model

The proof also supplies a direct sufficient target. Suppose \(A_n\to\infty\), \(B_n>A_n\), \(\Lambda_n\to\infty\), and continuous functions \(F_n\) on \([A_n-C-1,B_n+C+1]\) approximate every actual phase contact there with error \(o(\Lambda_n)\). Suppose continuous functions \(p_n:[A_n,B_n]\to[m,M]\) have endpoints \(m,M\), and

\[
\sup_{\substack{A_n\le T\le B_n\\|u|\le C}}
\left|\frac{F_n(T+u)-F_n(T)}{\Lambda_n}-p_n(T)u\right|\to0.
\tag{2.20}
\]

Here \(V,m,M,C\) are chosen as above, with \(C\) large enough for the four logarithmic shape radii. The same proof forces squares. In this formulation no derivative of \(F_n\) is needed. The derivative hypotheses in Theorem 20 are one way to produce these actual annular estimates; (2.20) states the finite-difference information that the degree argument uses.

## 3. A leading angular law that repeatedly reverses direction

**Corollary 21 — unbounded uniformly continuous slopes suffice.** If \(F'\) is uniformly continuous and unbounded in absolute value on a tail, then it satisfies (1.3). In particular, a \(C^2\) function with bounded second derivative and unbounded first derivative satisfies the model hypotheses of Theorem 20.

**Proof.** For any fixed \(C\), uniform continuity gives a finite bound on \(|F'(T+u)-F'(T)|\), uniform in \(T\) and \(|u|\le C\): subdivide an interval of length at most \(C\) into a fixed finite number of sufficiently short intervals. Dividing this bound by \(|F'(T)|\to\infty\) gives (1.3). A bounded second derivative makes the first derivative Lipschitz, hence uniformly continuous. \(\square\)

A concrete example is

\[
F(T)=\frac{T^2}{5}\big(2\sin\log T-\cos\log T\big),\qquad T>0.
\tag{3.1}
\]

Its derivatives are exactly

\[
F'(T)=T\sin\log T,
\qquad F''(T)=\sin\log T+\cos\log T.
\tag{3.2}
\]

Thus \(|F''|\le2\). At \(T=e^{\pi/2+2\pi n}\), the slope is \(T\); at \(T=e^{3\pi/2+2\pi n}\), it is \(-T\). It has arbitrarily large values of both signs and infinitely many zeros.

Theorem 20 therefore proves square existence for a continuous path with

\[
\Theta(t)=F\!\left(\log\frac{r_0}{R(t)}\right)+O(1),
\tag{3.3}
\]

including arbitrary bounded continuous phase perturbations. More generally, the joint error condition (1.4) suffices. This is a leading-order reversal example; the positive-slope and monotone-slope hypotheses of the earlier theorem do not apply to its model.

## 4. Transfer to the actual boundary

**Corollary 22 — complementary access with slope reversals forces boundary squares.** Suppose \(P\) lies on a Jordan curve \(\Gamma\), and \(\eta\) is a continuous path approaching \(P\) from the complement of \(\Gamma\). If its angular law satisfies (1.2)–(1.4), then \(\Gamma\) contains squares arbitrarily close to \(P\), with both circumdisk positions from Theorem 20.

**Proof.** For a simple access arc, Lemma 6 in `continuation_centered_spin.md` gives one integer \(k\) such that, at each radius,

\[
m_\eta(R)+2\pi k<\theta_\Gamma
<M_\eta(R)+2\pi(k+1).
\tag{4.1}
\]

The extrema include all access contacts at that radius. Consider any sequence \(R_n\to0\) with \(|a(\log(r_0/R_n))|\to\infty\). All corresponding access parameters approach the endpoint. Condition (1.4) therefore controls both extrema uniformly with error \(o(|a|)\); otherwise one could choose a violating sequence of actual contacts. The fixed integer offsets are also \(o(|a|)\). Hence (1.4) transfers to every boundary-arc contact with large model slope, which is exactly what Theorem 20 requires.

For a self-intersecting access path, use the local argument branch and path-to-arc extraction proved in Theorem 7 of the earlier continuation. The extracted trace inherits the same estimates; fixed lift constants are negligible when \(|a|\to\infty\). Apply the simple-arc case. \(\square\)

No uniform small-error statement at low-slope radii was inserted into this proof. The selected annular crossings lie where the slope is uniformly large.

## 5. A full normalized-shape limit is not necessary

Suppose continuous corner paths are

\[
Q_j(t)=P+r(t)e^{i\Theta(t)}(w(t)+i^j),
\qquad r(t)>0,\quad r(t)\to0,
\tag{5.1}
\]

with two adjacent corners in the open exterior and the other two in the open interior of the same Jordan curve \(\Gamma\). Suppose the orientation \(\Theta(t)\), measured against \(T(t)=\log(r_0/r(t))\), satisfies (1.2)–(1.4) for a model \(F\).

**Corollary 23 — one controlled corner suffices.** Assume one fixed complementary corner, with coefficient

\[
c(t)=w(t)+i^j,
\]

satisfies

\[
|c(t)|\to d\in(0,\infty),
\tag{5.2}
\]

and has a continuous angular lift \(\beta(t)=\arg c(t)\) for small \(t\), with

\[
\frac{|\beta(t)|}{|a(T(t))|}\to0
\quad\text{as }t\downarrow0\text{ and }|a(T(t))|\to\infty.
\tag{5.3}
\]

Then \(\Gamma\) has squares arbitrarily close to \(P\). No limit of \(w(t)\) is assumed. A bounded coefficient-angle lift is a sufficient special case of (5.3).

**Proof.** Condition (5.2) makes \(w\) bounded. All four corners therefore tend to \(P\), and their opposite complementary positions imply \(P\in\Gamma\). The chosen corner is an actual complementary access path. Its radius is \(R_A=r|c(t)|\). With reference radius \(r'_0=r_0d\), its logarithmic radius is

\[
T_A=\log\frac{r'_0}{R_A}
=T+\log\frac d{|c(t)|}=T+o(1).
\tag{5.4}
\]

On any sequence with \(|a(T_A)|\to\infty\), condition (1.3), centered at \(T_A\), gives

\[
\frac{a(T)}{a(T_A)}\to1.
\tag{5.5}
\]

In particular the original slope also becomes large. The same uniform bound on intermediate shifts and the fundamental theorem of calculus imply

\[
F(T_A)-F(T)=o(|a(T_A)|).
\tag{5.6}
\]

The original phase error and the additional coefficient angle are both \(o(|a(T_A)|)\), by (1.4), (5.3), and (5.5). Thus

\[
\arg(Q_j-P)=\Theta+\beta
=F(T_A)+o(|a(T_A)|)
\tag{5.7}
\]

along every sequence of large model slope. Corollary 22 applies. \(\square\)

This permits nonconvergent shapes. For example, with \(T\to\infty\), take

\[
F(T)=T^2,\qquad
w(T)=3e^{i\sqrt T}-1.
\tag{5.8}
\]

The normalized shape keeps circling and has no limit. For corner \(j=0\), however,

\[
|w+1|=3,\qquad \beta(T)=\sqrt T,\qquad
\frac{\beta(T)}{F'(T)}=\frac1{2\sqrt T}\to0.
\]

Thus any envelope tail satisfying the stated complementary positions and this orientation law would force actual boundary squares. Equation (5.8) is an example satisfying the coefficient hypotheses, not a construction of a square-free envelope.

If \(w(t)\) does have a finite limit, at least one of two adjacent complementary coefficients has a nonzero limit and a bounded angular lift. Thus Corollary 19 of `continuation_logarithmic_slope.md` is a special case. The power-phase and modulation corollaries remain separate results. Arbitrary drifting shapes need not satisfy (5.2)–(5.3).

## 6. Why unbounded slope alone cannot replace the variation hypothesis

**Proposition 24 — an exact square-free arc with unbounded model slope.** There is a \(C^1\) angular model \(F\) whose derivative is nonnegative and unbounded, but the radial arc

\[
\gamma(T)=e^{-T}e^{iF(T)},\qquad T\ge0,
\tag{6.1}
\]

contains no nondegenerate square. Its derivative fails (1.3).

**Construction and proof.** For integers \(n\ge1\), put

\[
w_n=2^{-3n-4},\qquad
b_n(T)=2^n\max\left(1-\frac{|T-n|}{w_n},0\right),
\qquad a(T)=\sum_{n\ge1}b_n(T).
\tag{6.2}
\]

The triangular bumps have disjoint supports. The sum is locally finite and continuous, and \(a(n)=2^n\). Each bump has area

\[
A_n=2^nw_n=2^{-2n-4}.
\]

Define

\[
\delta(T)=\int_T^\infty a(s)\,ds>0,
\qquad F(T)=-\delta(T).
\tag{6.3}
\]

Then \(F\in C^1\) and \(F'=a\). The exact geometric sums give

\[
0<\delta(T)\le\sum_{n\ge1}A_n=\frac1{48}.
\tag{6.4}
\]

On the support of bump \(n\),

\[
a(T)\delta(T)
\le2^n\sum_{k\ge n}2^{-2k-4}
=\frac1{12}2^{-n}\le\frac1{24};
\tag{6.5}
\]

off the bumps the product is zero. Write \(\gamma(T)=(x(T),y(T))\). Then

\[
x=e^{-T}\cos\delta,\qquad y=-e^{-T}\sin\delta,
\]

\[
x'=e^{-T}(-\cos\delta+a\sin\delta)<0,
\qquad
y'=e^{-T}(\sin\delta+a\cos\delta)>0.
\tag{6.6}
\]

For the first strict inequality, \(\cos\delta>1/2\) and \(\sin\delta\le\delta\) give \(a\tan\delta\le2a\delta\le1/12<1\). The second is immediate from \(\delta>0\), \(a\ge0\), and \(\cos\delta>0\).

Every pair of distinct points on this arc therefore has coordinate differences with negative product. This is impossible for all four vertices of a square: its two diagonal vectors are perpendicular, and their coordinate products have opposite signs, or are zero. Thus the arc is square-free. Adding its limiting endpoint \(0\) preserves the same strict coordinate ordering and does not create a square.

Finally \(a(n+1/2)=0\), whereas \(a(n)=2^n\). The ratio in (1.3), with shift \(u=1/2\), is exactly one along the peaks. The hypothesis fails. \(\square\)

This is a square-free **arc**, not a Jordan-curve counterexample to Toeplitz. Its angular change is finite. It shows that arbitrarily high derivative peaks can carry arbitrarily small angular change and need not provide the annular estimates used in Theorem 20. It makes no claim about the cost of a charged four-cycle or a genuine chamber-escape event.

## 7. Exact verification of both kinds of backtracking

`verify_slope_reversals.py` checks an auxiliary model after the phase homotopies. Its scale coefficient crosses the target level three times, with signs \(+1,-1,+1\). Each of its four logarithmic-radius equations has three crossings with signs \(-1,+1,-1\).

For specificity, the coefficient has piecewise-linear nodes

\[
(0,1/2),\quad(1/3,7/5),\quad(2/3,3/5),\quad(1,3/2),
\]

and the radial function has nodes

\[
(0,2),\quad(1/3,-7/4),\quad(2/3,7/4),\quad(1,-2).
\]

The reduced phase map is \(-p(v)D(w)\) with target \(-D(2)\). Take a sufficiently small shape neighborhood of \(2\) on which the direction of \(D(w)\) determines \(w\); this is possible because \(\det[D_x,D_y,D]\ne0\). Then the phase equation forces \(w=2\), \(p(v)=1\). For each of its three scale roots, the four logarithmic-radius targets \(v-\ell_j(2)\) lie between \(-3/2\) and \(1\), and each is crossed three times.

There are consequently \(3^5=243\) auxiliary zeros. The script computes the two rational coefficients of \(\log3\) and \(\log5\) in every \(7\times7\) determinant. In each case the determinant equals

\[
-p'(v)\left(\prod_{j=0}^3q'(\xi_j)\right)
\frac{2}{75}\log\frac{19683}{3125}.
\tag{7.1}
\]

There are 121 positive signs and 122 negative signs, with total degree \(-1\). The script also checks the exact differentiation in (3.2) and the rational geometric-series bounds (6.4)–(6.5).

These are checks of an auxiliary model and the stated algebra. They are not 243 numerically certified squares on a concrete curve. The analytic boundary homotopies prove the existence results. No floating-point or interval arithmetic is used in the new checker.

## 8. The remaining mathematical obligation

The new theorem removes monotonicity and eventual divergence of the model slope. It also gives an explicit class of changing normalized shapes that cannot occur in a square-free envelope. Its finite-window form (2.20) states a possible target directly in terms of continuous angular data.

What remains unproved is an extraction theorem supplying such windows, or another sufficient incidence mechanism, from an arbitrary continuous Jordan curve. Very narrow slope spikes need not qualify, as Proposition 24 demonstrates. Arbitrary normalized shapes need not have a corner satisfying (5.2)–(5.3), and no fixed limiting physical point has been obtained for every collapsing tail.

The exact fixed-profile classification, the modulation theorems, inversion pairing, and the global trapezoid proposal in the preceding notes remain part of the record. No universal cancellation, quantized action, or contradiction for all possible collision profiles has been established here.

## Dependencies

The exact logarithmic cone determinant is Lemma 16 in `continuation_logarithmic_slope.md`. The angular comparison and local argument-branch reduction are Lemma 6 and Theorem 7 in `continuation_centered_spin.md`, which also records the primary-source reference for path-to-arc extraction. The new degree argument uses those results and ordinary Brouwer degree. The finite-window version, model examples, and coordinate-monotone obstruction above are derived explicitly in this note.

Primary references checked for the inherited topological framework:

- Cole Hugelmeyer, *Inscribed Squares and Relation Avoiding Paths*, Definition 1 and Theorem 1. These give the complementary corner conditions and the square-envelope reduction. They do not supply the angular estimates assumed here. [Primary paper](https://arxiv.org/pdf/2301.01340).
- Reinhard Diestel and Daniela Kühn, *On Infinite Cycles I*, Lemma 6.1, which records the standard extraction of an arc between the distinct endpoints of a path in a Hausdorff space. [Authors' paper](https://web.mat.bham.ac.uk/D.Kuehn/infcycle1.pdf).
