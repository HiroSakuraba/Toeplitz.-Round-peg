# Project Handoff v149: Shrinking-Window Profile Extraction and Angular-Mass Spikes

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

It attacks the extraction problem left by the post-v148 slope-reversal work.

The narrow-spike counterexample in Proposition 24 showed that an angular
derivative can become arbitrarily large while the total angular change in
each spike tends to zero.  The fixed-width theorem therefore cannot be
recovered from slope height alone.

v149 identifies the correct next scale:

\[
\boxed{
\text{angular mass}
=
(\text{slope height})\times(\text{log-radius width}).
}
\]

The main theorem allows the useful log-radius window itself to shrink to
zero.  The square shape is allowed to degenerate simultaneously so that its
four radial contacts fit inside that shrinking window.

Suppose a radial phase law has windows

\[
T=T_n+\delta_n t,
\qquad
T_n\to\infty,
\qquad
\delta_n\to0,
\]

and amplitudes

\[
A_n\to\infty
\]

such that

\[
\boxed{
\frac{F(T_n+\delta_n t)-b_n}{A_n}
\longrightarrow
f(t)
}
\tag{0.1}
\]

uniformly on the compact interval needed below.

If the \(C^1\) profile \(f\) is not one of the two everywhere-singular
families

\[
\boxed{
f(t)=at+b
}
\tag{0.2}
\]

or

\[
\boxed{
f(t)=a\log|t-b|+c,
\qquad b\notin I,
}
\tag{0.3}
\]

then the radial arc

\[
\boxed{
\gamma(T)=e^{-T}e^{iF(T)}
}
\tag{0.4}
\]

contains nondegenerate squares whose contacts lie in those shrinking windows.

Their side length is

\[
\boxed{
\ell_n
\asymp
e^{-T_n}\delta_n.
}
\tag{0.5}
\]

Thus the square becomes smaller than its distance from the collision point by
the same factor \(\delta_n\) by which the angular window shrinks.

Equivalently, the normalized square-center parameter satisfies

\[
\boxed{
|w_n|\asymp\delta_n^{-1}\to\infty.
}
\tag{0.6}
\]

So the theorem covers a shape-degeneration regime that the fixed-shape
post-v148 arguments did not use.

The most useful derivative corollary is this.

Suppose on shrinking windows

\[
\boxed{
\frac{
F'(T_n+\delta_n t)
}{
M_n
}
\longrightarrow
p(t)
}
\tag{0.7}
\]

uniformly, and

\[
\boxed{
M_n\delta_n\to\infty.
}
\tag{0.8}
\]

Let

\[
f(t)=\int_0^t p(s)\,ds.
\]

If \(f\) is nonexceptional, then actual squares are forced.

This gives a direct "height times width" theorem for narrow slope spikes.

The Proposition 24 square-free spike arc has

\[
M_n=2^n,
\qquad
\delta_n\asymp2^{-3n},
\]

and therefore

\[
\boxed{
M_n\delta_n\asymp2^{-2n}\to0.
}
\tag{0.9}
\]

So it lies on the opposite side of the new criterion.

This does not prove that bounded angular mass is sufficient for square
avoidance.  It proves that **shrinking width alone is not an escape** once the
angular mass across the window diverges and a nonexceptional profile emerges.

The result also extends to a complementary access path with radial
backtracking: if all contacts in the shrinking log-radius window satisfy the
same normalized profile estimate, the four-contact Brouwer-degree argument
survives, and the standard Jordan angular-comparison lemma transfers the
result to the actual boundary.

The new remaining obstruction is therefore sharper:

\[
\boxed{
\begin{array}{l}
\text{A square-free collision tail must avoid every nonexceptional}\\
\text{high-angular-mass blow-up profile, even on shrinking windows.}
\end{array}
}
\tag{0.10}
\]

Its angular complexity must instead be concentrated into bounded-mass packets,
fail to have a stable local profile, or repeatedly approach the affine /
shifted-logarithmic exceptional families.

---

# 1. The shrinking-window square coordinates

Use logarithmic radius

\[
T=-\log r.
\]

Fix a window center \(T_n\) and width \(\delta_n\).

Let

\[
q=a+ib\ne0,
\qquad
v\in\mathbb R.
\]

Define four points

\[
\boxed{
z_{n,j}
=
e^{-T_n-\delta_n v}
e^{i\psi}
\left(
1+\delta_n q\,i^j
\right),
\qquad
j=0,1,2,3.
}
\tag{1.1}
\]

These are exactly the vertices of a square.

Indeed the center is

\[
h_n=e^{-T_n-\delta_n v}e^{i\psi},
\]

and the half-diagonal vector is

\[
d_n
=
e^{-T_n-\delta_n v}e^{i\psi}\delta_n q.
\]

Hence

\[
z_{n,j}=h_n+d_n i^j.
\]

The side length is

\[
\boxed{
\ell_n
=
\sqrt2\,
e^{-T_n-\delta_n v}
\delta_n|q|.
}
\tag{1.2}
\]

The normalized center relative to the half-diagonal is

\[
\boxed{
w_n
=
\frac{h_n}{d_n}
=
\frac1{\delta_n q}.
}
\tag{1.3}
\]

Thus if \(q\to q_*\ne0\) and \(\delta_n\to0\),

\[
|w_n|\to\infty.
\]

This is a controlled large-\(w\) collision shape.

---

# 2. Exact normalized log radii

The radius of vertex \(j\) is

\[
|z_{n,j}|
=
e^{-T_n-\delta_n v}
|1+\delta_n q i^j|.
\]

Therefore its logarithmic radius is

\[
T_{n,j}
=
T_n+\delta_n v
-\log|1+\delta_n q i^j|.
\]

Define

\[
\boxed{
t_{n,j}(q,v)
=
\frac{T_{n,j}-T_n}{\delta_n}
=
v
-
\frac1{\delta_n}
\log|1+\delta_n q i^j|.
}
\tag{2.1}
\]

On compact \(q\)-sets,

\[
\frac1{\delta}
\log|1+\delta \xi|
=
\Re\xi+O(\delta)
\]

uniformly.

Hence

\[
\boxed{
t_{n,j}
\longrightarrow
u_j
=
v-\Re(q i^j)
}
\tag{2.2}
\]

uniformly on compact \((q,v)\)-sets.

Writing \(q=a+ib\), the limiting four coordinates are

\[
\boxed{
u_0=v-a,
\quad
u_1=v+b,
\quad
u_2=v+a,
\quad
u_3=v-b.
}
\tag{2.3}
\]

This is exactly the additive analogue of the squared-radius coordinates from
the post-v148 profile classification.

---

# 3. Exact phase equations

Let

\[
\gamma(T)=e^{-T}e^{iF(T)}.
\]

Choose the common square rotation \(\psi\).

The angular position of vertex \(j\) in (1.1) is

\[
\psi+\phi_{n,j}(q),
\]

where

\[
\phi_{n,j}(q)=\arg(1+\delta_nq i^j).
\]

Thus the four square vertices lie on \(\gamma\) if and only if there are
integers \(k_j\) with

\[
F(T_{n,j})
-
\psi
-
\phi_{n,j}
=
2\pi k_j.
\]

Subtract the \(j=0\) equation.

Define

\[
\boxed{
G_{n,j}(q,v)
=
F(T_{n,j})-F(T_{n,0})
-
\bigl(
\phi_{n,j}-\phi_{n,0}
\bigr),
\quad
j=1,2,3.
}
\tag{3.1}
\]

Then exact square incidence is equivalent to

\[
\boxed{
G_n(q,v)\in2\pi\mathbb Z^3.
}
\tag{3.2}
\]

Once (3.2) holds, \(\psi\) is recovered from the \(j=0\) equation.

So the shrinking-window problem is again a three-dimensional phase-lattice
problem.

---

# 4. Limiting profile map

Assume

\[
\frac{F(T_n+\delta_nt)-b_n}{A_n}
\to
f(t)
\]

uniformly on a compact interval containing all \(u_j\) in the chosen local
parameter region, with

\[
A_n\to\infty.
\]

Because

\[
t_{n,j}\to u_j
\]

uniformly and \(f\) is continuous,

\[
\frac{
F(T_{n,j})-F(T_{n,0})
}{
A_n
}
\to
f(u_j)-f(u_0).
\]

Also

\[
|\phi_{n,j}-\phi_{n,0}|=O(\delta_n),
\]

so after division by \(A_n\) the angular square-chart correction vanishes.

Therefore

\[
\boxed{
\frac{G_n(q,v)}{A_n}
\longrightarrow
H_f(q,v)
}
\tag{4.1}
\]

uniformly on compact parameter sets, where

\[
\boxed{
H_f(a,b,v)
=
\begin{pmatrix}
f(v+b)-f(v-a)\\
f(v+a)-f(v-a)\\
f(v-b)-f(v-a)
\end{pmatrix}.
}
\tag{4.2}
\]

This is the key limiting map.

---

# 5. The same exceptional-profile classification reappears

Set

\[
A=v,\qquad
B=-a,\qquad
C=b.
\]

Then

\[
u_0=A+B,\quad
u_1=A+C,\quad
u_2=A-B,\quad
u_3=A-C.
\]

Thus \(H_f\) is exactly the profile map \(\Psi_f\) from the supplied
`continuation_profile_classification.md`, composed with a determinant-\(-1\)
linear coordinate change.

Consequently:

> **Theorem 5.1 — shrinking-window rank-loss classification.**  
> For \(f\in C^1(I)\), the shrinking-window limiting map \(H_f\) is singular
> everywhere on its physical domain if and only if
>
> \[
> \boxed{
> f(t)=at+b
> }
> \]
>
> or
>
> \[
> \boxed{
> f(t)=a\log|t-b|+c,
> \qquad b\notin I.
> }
> \]

No new exceptional family appears when the useful radial window shrinks.

This is important: the large-\(w\) shape degeneration does not enlarge the
rank-loss class.

---

# 6. Shrinking-window profile theorem

Suppose \(f\) is nonexceptional.

The classification theorem supplies one regular point

\[
(q_*,v_*),
\qquad
q_*\ne0,
\]

with

\[
\det DH_f(q_*,v_*)\ne0.
\]

Choose a small bounded neighborhood \(U\) of this point such that

\[
h_*=H_f(q_*,v_*)
\]

has nonzero Brouwer degree in \(U\), and define the boundary margin

\[
\Delta
=
\operatorname{dist}
\left(
h_*,
H_f(\partial U)
\right)
>0.
\]

For each \(n\), choose

\[
m_n\in\mathbb Z^3
\]

by rounding

\[
\frac{A_nh_*}{2\pi}.
\]

Then

\[
\left|
\frac{2\pi m_n}{A_n}-h_*
\right|
\le
\frac{\pi\sqrt3}{A_n}.
\]

The convergence in Section 4 gives

\[
\sup_U
\left|
\frac{G_n}{A_n}-H_f
\right|
\to0.
\]

Therefore for sufficiently large \(n\),

\[
\sup_U
\left|
\frac{G_n}{A_n}-H_f
\right|
+
\frac{\pi\sqrt3}{A_n}
<
\Delta.
\]

The straight homotopy avoids zero on \(\partial U\), so

\[
\deg
\left(
\frac{G_n}{A_n}
-
\frac{2\pi m_n}{A_n},
U,0
\right)
=
\deg(H_f-h_*,U,0)
\ne0.
\]

Hence there exists

\[
(q_n,v_n)\in U
\]

with

\[
G_n(q_n,v_n)=2\pi m_n.
\]

By Section 3 this gives an actual square on the radial arc.

Thus:

> **Theorem 6.1 — shrinking-window profile extraction.**  
> Let
> \[
> \gamma(T)=e^{-T}e^{iF(T)}
> \]
> and suppose there exist
> \[
> T_n\to\infty,\qquad
> \delta_n\to0,\qquad
> A_n\to\infty,
> \]
> offsets \(b_n\), and a nonexceptional \(C^1\) profile \(f\) satisfying
> \[
> \frac{F(T_n+\delta_nt)-b_n}{A_n}\to f(t)
> \]
> uniformly on the needed compact interval.
>
> Then \(\gamma\) contains nondegenerate squares with
> \[
> \boxed{
> \ell_n
> =
> \sqrt2
> e^{-T_n}
> \delta_n
> |q_*|
> (1+o(1)).
> }
> \]
>
> Their normalized center parameters satisfy
> \[
> \boxed{
> \delta_n w_n\to1/q_*.
> }
> \]

So arbitrarily narrow angular windows still force squares if their normalized
angular excursion tends to a nonexceptional large-amplitude profile.

---

# 7. Quantitative finite-window criterion

The proof gives an explicit finite sufficient condition.

Let \(L_f\) be a Lipschitz constant for \(f\) on the compact profile interval,
and suppose

\[
E_n
=
\sup
\left|
\frac{F(T_n+\delta_nt)-b_n}{A_n}
-f(t)
\right|.
\]

On a fixed compact \(U\),

\[
|t_{n,j}-u_j|
\le
C_U\delta_n
\]

for large \(n\).

Hence

\[
\sup_U
\left|
\frac{G_n}{A_n}-H_f
\right|
\le
2E_n
+
C_U L_f\delta_n
+
C_U\frac{\delta_n}{A_n}.
\]

It is therefore sufficient that

\[
\boxed{
2E_n
+
C_U L_f\delta_n
+
C_U\frac{\delta_n}{A_n}
+
\frac{\pi\sqrt3}{A_n}
<
\Delta.
}
\tag{7.1}
\]

This makes the role of angular mass explicit.

A large profile amplitude reduces the phase-lattice mesh, while a small
window is harmless because the square shape expands like \(\delta_n^{-1}\).

---

# 8. Derivative form: height times width

Assume now that \(F\in C^1\) and that

\[
\boxed{
\frac{
F'(T_n+\delta_nt)
}{
M_n
}
\to
p(t)
}
\tag{8.1}
\]

uniformly on a compact interval, where

\[
M_n>0.
\]

Put

\[
\boxed{
A_n=M_n\delta_n.
}
\tag{8.2}
\]

Then

\[
\frac{
F(T_n+\delta_nt)-F(T_n)
}{
A_n
}
=
\int_0^t
\frac{
F'(T_n+\delta_ns)
}{
M_n
}
\,ds
\to
\int_0^t p(s)\,ds.
\]

Define

\[
\boxed{
f(t)=\int_0^tp(s)\,ds.
}
\tag{8.3}
\]

Therefore:

> **Corollary 8.1 — angular-mass spike theorem.**  
> If
> \[
> M_n\delta_n\to\infty
> \]
> and the integrated limiting spike profile \(f\) is nonexceptional, then the
> radial arc contains squares at side scale
> \[
> \boxed{
> \ell_n\asymp e^{-T_n}\delta_n.
> }
> \]

The quantity

\[
\boxed{
M_n\delta_n
}
\]

is the angular excursion naturally available across the spike.

Slope height alone is not the right resource.

---

# 9. The narrow-spike counterexample is now located sharply

The square-free arc in Proposition 24 of
`continuation_slope_reversals.md` uses triangular derivative spikes with

\[
M_n=2^n
\]

and half-width

\[
\delta_n=2^{-3n-4}.
\]

Therefore

\[
\boxed{
M_n\delta_n
=
2^{-2n-4}
\to0.
}
\tag{9.1}
\]

Its total angular mass is summable.

So Proposition 24 does not merely violate a technical fixed-width
hypothesis.  It occupies the small-angular-mass regime complementary to
Corollary 8.1.

This yields the sharper dichotomy:

\[
\boxed{
\begin{array}{l}
\text{large narrow slopes with diverging angular mass and a regular}\\
\text{profile force squares;}\\[1mm]
\text{the known square-free spike model survives by making its mass vanish.}
\end{array}
}
\tag{9.2}
\]

---

# 10. Exact quadratic-window audit

Take the model profile

\[
\boxed{
f(t)=t^2.
}
\]

For

\[
q=a+ib,
\]

the limiting map is

\[
H_f(a,b,v)
=
\begin{pmatrix}
(v+b)^2-(v-a)^2\\
(v+a)^2-(v-a)^2\\
(v-b)^2-(v-a)^2
\end{pmatrix}.
\]

Its determinant is exactly

\[
\boxed{
\det DH_f
=
-32v(a-b)(a+b).
}
\tag{10.1}
\]

At

\[
\boxed{
(a,b,v)=
\left(
1,\frac12,3
\right),
}
\]

\[
\boxed{
\det DH_f=-72.
}
\tag{10.2}
\]

So this is a robust regular shrinking-window target.

For a numerical illustration choose

\[
A=500,\qquad
\delta=10^{-2},
\]

and the exact phase law on the local window

\[
F(T)=
500
\left(
\frac{T-T_0}{10^{-2}}
\right)^2.
\]

Solving the exact three phase-lattice equations near the regular target gives

\[
\boxed{
q
\approx
1.00206255+0.50129663\,i,
}
\]

\[
\boxed{
v\approx2.99338670.
}
\]

The four normalized log radii are approximately

\[
\boxed{
1.99508,\quad
3.49087,\quad
3.99922,\quad
2.48837.
}
\]

The residual of the three exact lattice equations is below \(2\times10^{-8}\)
in the verifier.

This numerical root is only an audit of the exact equations.  The existence
theorem is the Brouwer-degree argument above.

---

# 11. Radial backtracking version

The radial-graph formulation is not essential.

Let

\[
\eta:[0,t_0]\to\mathbb C
\]

approach a point \(P\), and define

\[
T(t)=\log\frac{r_0}{|\eta(t)-P|}.
\]

Suppose for shrinking windows

\[
T_n+\delta_n I
\]

all actual path contacts satisfy

\[
\boxed{
\sup_{\substack{t\\
(T(t)-T_n)/\delta_n\in J}}
\left|
\frac{\Theta(t)-b_n}{A_n}
-
f\left(
\frac{T(t)-T_n}{\delta_n}
\right)
\right|
\to0
}
\tag{11.1}
\]

for every compact \(J\Subset I\).

The supremum is over **all radial returns**.

Choose one actual crossing of the desired normalized log-radius block using
the same first/last crossing device as in the supplied backtracking theorems.
Keep all four contact parameters independently.

The seven-equation map consists of

1. four exact normalized log-radius equations matching the functions
   \(t_{n,j}(q,v)\);
2. three exact phase equations.

The phase homotopy is controlled by (11.1).

The actual normalized log-radius crossing can then be homotoped to an affine
crossing while preserving its endpoint values, exactly as in the supplied
Theorems 5, 11, and 20.

The four radius equations contribute degree \(+1\) in total, leaving the
degree of \(H_f\).

Hence:

> **Theorem 11.1 — shrinking-window theorem with radial backtracking.**  
> Under (11.1), if \(A_n\to\infty\) and \(f\) is nonexceptional, the image of
> \(\eta\) contains nondegenerate squares approaching \(P\).
>
> No radial inverse, radial monotonicity, angular monotonicity, or
> differentiability of the path is required.

This is the form relevant to a Jordan collision tail.

---

# 12. Transfer to the actual Jordan boundary

Suppose \(P\in\Gamma\) for a Jordan curve \(\Gamma\), and \(\eta\) is a
complementary access path approaching \(P\).

The supplied angular-comparison lemma traps every boundary contact at a fixed
radius between the minimum and maximum access arguments plus one fixed
\(2\pi\) lift interval.

If the access path satisfies the shrinking-window estimate (11.1) with

\[
A_n\to\infty,
\]

then the fixed \(2\pi\) lift ambiguity is

\[
o(A_n).
\]

Therefore the same normalized profile estimate transfers to every boundary
contact in those windows.

Applying Theorem 11.1 to the boundary arc gives:

> **Corollary 12.1 — shrinking high-angular-mass access forces boundary
> squares.**  
> A Jordan curve with a complementary access path satisfying a
> nonexceptional shrinking-window profile of amplitude \(A_n\to\infty\)
> contains squares arbitrarily close to the access point.

This extends the post-v148 access-path square theorems into the shrinking
window regime.

---

# 13. What this changes in the extraction problem

Before v149, Proposition 24 left a broad-looking loophole:

\[
\text{perhaps all large slopes can hide in windows too narrow for the degree
argument.}
\]

That loophole is now substantially smaller.

The window may shrink arbitrarily fast.

The square simply becomes tangentially tiny relative to its distance from the
collision point, with

\[
\ell_n/e^{-T_n}\asymp\delta_n.
\]

What matters is whether the **angular excursion across the shrinking window**
still tends to infinity and has a nonexceptional normalized profile.

Therefore a hypothetical square-free collision tail must arrange that every
candidate high-complexity shrinking window falls into at least one of:

\[
\boxed{
\begin{array}{ll}
\text{I.}&
\text{bounded angular mass;}\\
\text{II.}&
\text{no stable continuous blow-up profile;}\\
\text{III.}&
\text{an affine limiting profile;}\\
\text{IV.}&
\text{a shifted-logarithmic limiting profile.}
\end{array}
}
\tag{13.1}
\]

This is a much more precise extraction frontier.

---

# 14. What is still missing

Theorem 6.1 is still conditional on the existence of a normalized local
profile.

An arbitrary continuous angular function can distribute infinite variation
among infinitely many bounded-mass packets whose normalized shapes fail to
converge.

Even if a profile limit exists, it could repeatedly be affine or
shifted-logarithmic.

The theorem also does not show that every collision germ has a fixed physical
access point with the required angular comparison.

So the general Toeplitz obstruction has not been closed.

The remaining task is no longer merely to find a "wide" high-slope interval.
It is:

\[
\boxed{
\text{extract a nonexceptional high-angular-mass blow-up window, or derive a
new contradiction from persistent bounded-mass / exceptional packets.}
}
\]

---

# 15. Recommended v150 target

There are now two concrete next problems.

### Route A — bounded-mass packet accumulation

Suppose every shrinking window carries only \(O(1)\) angular mass, but the
total angular variation still diverges.

Then the tail contains infinitely many angular packets.

Study whether a persistent square-zero lineage can cross infinitely many such
packets while staying in one center/orientation germ.

A parity or renewal argument may accumulate many \(O(1)\) packets into a
macroscopic phase current even though no individual packet reaches the
v149 threshold.

### Route B — exceptional-profile renormalization

The only stable \(C^1\) blow-up profiles not killed by v149 are

\[
at+b
\]

and

\[
a\log|t-b|+c.
\]

The fixed-width post-v148 notes already recover some logarithmic cases by
varying the effective slope across scale.

Try to iterate that idea in the shrinking-window setting.

If every blow-up window is asymptotically affine, compare adjacent windows.
A change in affine slope is a second-order profile.

If every blow-up is shifted-logarithmic, track motion of the pole \(b\) and
coefficient \(a\) across nested windows.

A renormalization theorem saying that persistent exceptional behavior forces a
rigid model would be much closer to an actual extraction theorem.

Route B is probably the higher-value mathematical target.

---

# 16. Claim boundary

## Established in v149

- exact shrinking-window square coordinate system;
- exact normalized log-radius formula;
- exact three-dimensional phase-lattice incidence equations;
- uniform convergence to the additive profile map \(H_f\);
- the post-v148 affine / shifted-log rank-loss classification remains exactly
  the exceptional class in the shrinking-window regime;
- nonexceptional shrinking-window profiles with amplitude \(A_n\to\infty\)
  force actual squares;
- square side scale
  \[
  \ell_n\asymp e^{-T_n}\delta_n;
  \]
- derivative version with the criterion
  \[
  M_n\delta_n\to\infty;
  \]
- exact explanation of why the Proposition 24 spike example escapes:
  \[
  M_n\delta_n\to0;
  \]
- radial-backtracking extension under uniform all-return profile control;
- complementary-access transfer to a Jordan boundary;
- exact quadratic-profile determinant audit.

## Inherited and used

- post-v148 Theorem 10: classification of everywhere-singular \(C^1\)
  profiles;
- post-v148 four-contact radial-backtracking degree method;
- post-v148 angular comparison from a complementary access path to the Jordan
  boundary;
- Proposition 24 narrow-spike square-free arc as the obstruction model.

## Not established

- existence of a high-angular-mass profile window for an arbitrary Jordan
  collision;
- a theorem for infinite bounded-mass packet accumulation;
- rigidity of nested affine / shifted-logarithmic blow-ups;
- a universal collision contradiction;
- the Toeplitz square-peg conjecture.

The frontier is now **bounded-mass packet accumulation versus exceptional
profile renormalization**.
