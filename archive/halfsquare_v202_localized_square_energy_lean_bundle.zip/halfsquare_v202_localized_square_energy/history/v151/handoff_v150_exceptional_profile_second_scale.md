# Project Handoff v150: Second-Scale Renormalization of the Exceptional Profiles

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v149 reduced the stable \(C^1\) high-angular-mass blow-up profiles which are
not immediately killed by the three-dimensional phase degree to two families:

\[
\boxed{f(t)=at+b}
\]

and

\[
\boxed{f(t)=a\log|t-b|+c.}
\]

v150 asks the next renormalization question:

> If the leading blow-up profile is exceptional, what smaller but still
> diverging correction can remain invisible?

The answer is surprisingly rigid.

There are two exact second-scale classification theorems.

---

## Main result A — affine leading profile

Suppose on shrinking windows the phase has a two-scale expansion

\[
\boxed{
F(T_n+\delta_n t)-c_n
=
A_n t
+
B_n g(t)
+
r_n(t),
}
\tag{0.1}
\]

uniformly on a compact interval \(I\), with

\[
\boxed{
A_n\to\infty,
\qquad
B_n\to\infty,
\qquad
\frac{B_n}{A_n}\to0,
\qquad
\frac{\|r_n\|_\infty}{B_n}\to0.
}
\tag{0.2}
\]

Then the large affine part occupies only a two-dimensional plane in relative
phase space.

After quotienting that plane and rescaling the two phase scales separately,
the limiting map is

\[
\boxed{
K_g(a,b,v)
=
\left(
a+b,\,
a-b,\,
Q_g(a,b,v)
\right),
}
\tag{0.3}
\]

where

\[
\boxed{
Q_g
=
g(v-a)-g(v+b)+g(v+a)-g(v-b).
}
\tag{0.4}
\]

Its Jacobian is

\[
\boxed{
\det DK_g
=
-2\,\partial_vQ_g.
}
\tag{0.5}
\]

The map is singular everywhere if and only if

\[
\boxed{
g(t)=\alpha t^2+\beta t+\gamma.
}
\tag{0.6}
\]

Therefore:

> **Affine second-scale theorem.**  
> If the leading profile is affine, the secondary amplitude \(B_n\) still
> diverges, and the normalized secondary profile is **not quadratic**, then
> the shrinking-window square argument regains full degree and forces actual
> squares.

So the affine exception from v149 is not stable under a generic diverging
second scale.

Its only stable \(C^1\) second-order escape is a quadratic correction.

---

## Main result B — shifted-logarithmic leading profile

Now suppose, on an interval avoiding \(b\),

\[
\boxed{
F(T_n+\delta_n t)-c_n
=
A_n\log|t-b|
+
B_n g(t)
+
r_n(t),
}
\tag{0.7}
\]

with the same scale separation (0.2).

The leading log profile has a two-dimensional image because its three relative
phases satisfy the exact surface relation

\[
\boxed{
1+e^{H_2}=e^{H_1}+e^{H_3}.
}
\tag{0.8}
\]

Flatten this surface before looking at the smaller scale.

Writing

\[
x=|t-b|
\]

on one side of the pole, the secondary correction fails to restore the
missing scale direction **if and only if**

\[
\boxed{
g(t)
=
\alpha\log|t-b|
+
\frac{\beta}{t-b}
+
\gamma.
}
\tag{0.9}
\]

Thus:

> **Shifted-log second-scale theorem.**  
> A diverging secondary correction to a shifted-logarithmic leading profile
> forces squares unless it is itself asymptotically a linear combination of
>
> \[
> \boxed{
> 1,\qquad
> \log|t-b|,\qquad
> \frac1{t-b}.
> }
> \]
>
> These are exactly the infinitesimal changes of
>
> - additive phase offset;
> - logarithmic coefficient;
> - logarithmic pole position.

This gives a geometric interpretation of the remaining exception:
the second scale can remain invisible only by **moving inside the same
three-parameter logarithmic family**.

---

The conclusion is a genuine renormalization rigidity statement.

A hypothetical square-free tail whose large-angular-mass blow-ups keep
looking exceptional cannot make arbitrary smaller corrections.

It must organize them into a very small hierarchy:

\[
\boxed{
\begin{array}{rcl}
\text{affine leading}
&\Longrightarrow&
\text{quadratic secondary or smaller/no-profile};\\[1mm]
\text{shifted log leading}
&\Longrightarrow&
\text{coefficient/pole/offset drift or smaller/no-profile}.
\end{array}
}
\tag{0.10}
\]

This is substantially narrower than the v149 four-way obstruction.

---

# 1. The common shrinking-window phase map

Use the v149 square coordinates

\[
z_{n,j}
=
e^{-T_n-\delta_nv}e^{i\psi}
(1+\delta_n q i^j),
\qquad
q=a+ib.
\]

The normalized logarithmic radii satisfy

\[
t_{n,j}
=
\frac{T_{n,j}-T_n}{\delta_n}
\longrightarrow
u_j,
\]

where

\[
\boxed{
u_0=v-a,\quad
u_1=v+b,\quad
u_2=v+a,\quad
u_3=v-b.
}
\tag{1.1}
\]

For any profile \(h\), define

\[
\boxed{
H_h(a,b,v)
=
\begin{pmatrix}
h(u_1)-h(u_0)\\
h(u_2)-h(u_0)\\
h(u_3)-h(u_0)
\end{pmatrix}.
}
\tag{1.2}
\]

The exact three phase-lattice equations have the asymptotic form dictated by
the corresponding combination of the \(H_h\)'s.

The four little square-angle corrections are \(O(\delta_n)\) and are
negligible compared with every diverging amplitude used below.

---

# 2. Affine leading profile: the exact plane

For

\[
h(t)=t,
\]

one obtains

\[
\boxed{
H_t(a,b,v)
=
\begin{pmatrix}
a+b\\
2a\\
a-b
\end{pmatrix}.
}
\tag{2.1}
\]

The image is exactly the plane

\[
\boxed{
-y_1+y_2-y_3=0.
}
\tag{2.2}
\]

Use the integer unimodular change of output coordinates

\[
\boxed{
L(y_1,y_2,y_3)
=
(y_1,\ y_3,\ -y_1+y_2-y_3).
}
\tag{2.3}
\]

Because \(L\in GL(3,\mathbb Z)\), it preserves the phase lattice:

\[
L(2\pi\mathbb Z^3)=2\pi\mathbb Z^3.
\]

Under the two-scale expansion (0.1), apply

\[
\boxed{
\operatorname{diag}
(A_n^{-1},A_n^{-1},B_n^{-1})L.
}
\tag{2.4}
\]

The transformed phase map converges uniformly to

\[
\boxed{
K_g(a,b,v)
=
(a+b,\ a-b,\ Q_g),
}
\tag{2.5}
\]

with \(Q_g\) from (0.4).

The transformed lattice has spacings

\[
\frac{2\pi}{A_n},
\qquad
\frac{2\pi}{A_n},
\qquad
\frac{2\pi}{B_n},
\]

so its covering radius tends to zero.

Thus any regular point of \(K_g\) gives the same Brouwer lattice-capture
argument as v146 and v149.

---

# 3. Exact secondary classification after an affine leading term

The first two rows of \(K_g\) have constant derivatives:

\[
d(a+b)=(1,1,0),
\]

\[
d(a-b)=(1,-1,0).
\]

Therefore

\[
\boxed{
\det DK_g
=
-2\,\partial_vQ_g.
}
\tag{3.1}
\]

Now

\[
\partial_vQ_g
=
g'(v-a)-g'(v+b)+g'(v+a)-g'(v-b).
\tag{3.2}
\]

If this vanishes identically, set \(b=0\).  Then

\[
g'(v-a)+g'(v+a)=2g'(v)
\]

for every allowed \(v,a\).

Since \(g'\) is continuous, midpoint Jensen gives

\[
g'(t)=\alpha t+\beta.
\]

Hence

\[
\boxed{
g(t)
=
\frac{\alpha}{2}t^2+\beta t+\gamma.
}
\tag{3.3}
\]

Conversely every quadratic polynomial has zero expression (3.2).

Therefore:

> **Theorem 3.1 — affine secondary rank-loss classification.**  
> For \(g\in C^1(I)\), \(K_g\) is singular everywhere if and only if \(g\)
> is a polynomial of degree at most two.

This is exact.

---

# 4. Affine second-scale square theorem

Assume (0.1)--(0.2) and let \(g\) be nonquadratic.

Theorem 3.1 gives a regular point

\[
\sigma_*=(a_*,b_*,v_*),
\qquad
q_*=a_*+ib_*\ne0.
\]

Choose a small product neighborhood \(U\) on which \(K_g\) has nonzero local
degree.

The transformed exact phase map converges uniformly to \(K_g\).

Choose a point of the transformed rectangular phase lattice nearest to
\(K_g(\sigma_*)\).

Its distance is bounded by

\[
\boxed{
\pi
\sqrt{
\frac2{A_n^2}
+
\frac1{B_n^2}
}
\longrightarrow0.
}
\tag{4.1}
\]

Hence the boundary degree stabilizes and an exact phase-lattice solution
exists in \(U\) for every sufficiently large \(n\).

Reconstructing the common square rotation gives an actual square.

Therefore:

> **Theorem 4.1 — affine second-scale square forcing.**  
> Under (0.1)--(0.2), if \(g\) is not quadratic, the radial arc contains
> nondegenerate squares in the shrinking windows.  Their side scale is the
> same as v149:
> \[
> \boxed{
> \ell_n\asymp e^{-T_n}\delta_n.
> }
> \]

The radial-backtracking and complementary-access versions follow by the same
seven-equation replacement used in v149.

---

# 5. Derivative interpretation of the affine theorem

Suppose the slope itself has the expansion

\[
\boxed{
F'(T_n+\delta_nt)
=
M_n
+
N_n p(t)
+
o(N_n)
}
\tag{5.1}
\]

uniformly, with

\[
M_n\delta_n\to\infty,
\]

\[
N_n\delta_n\to\infty,
\]

and

\[
\frac{N_n}{M_n}\to0.
\]

Integrating gives

\[
A_n=M_n\delta_n,
\qquad
B_n=N_n\delta_n,
\]

and

\[
g(t)=\int_0^tp(s)\,ds
\]

up to an irrelevant affine term.

The secondary profile \(g\) is quadratic exactly when \(p\) is affine.

Thus:

> **Corollary 5.1.**  
> A nearly constant very large angular slope with a smaller but still
> diverging modulation forces squares unless the normalized slope modulation
> is asymptotically affine in the shrinking coordinate.

So even an affine leading blow-up can remain exceptional only if the next
visible slope structure is essentially linear.

---

# 6. The quadratic secondary barrier

The quadratic family is not an artifact of the proof.

For the exact two-scale profile

\[
\boxed{
f_{A,B}(t)
=
At+Bt^2,
}
\tag{6.1}
\]

the full relative phase map has exact Jacobian determinant

\[
\boxed{
\det DH_{f_{A,B}}
=
-16B^2
(A+2Bv)
(a-b)(a+b).
}
\tag{6.2}
\]

When

\[
B/A\to0
\]

on a compact region with

\[
a^2\ne b^2,
\]

two singular values are of order \(A\), while the third is

\[
\boxed{
\Theta(B^2/A).
}
\tag{6.3}
\]

So quadratic curvature does restore full rank at finite scale, but only
through a **third effective phase scale**

\[
\boxed{
C_n=\frac{B_n^2}{A_n}.
}
\tag{6.4}
\]

This explains why the two-scale limit of Sections 2--4 cannot see it.

In the plane coordinates

\[
p=a+b,
\qquad
q=a-b,
\]

the transformed exact map is

\[
\boxed{
\begin{aligned}
Y_1&=
p[A+B(2v-q)],\\
Y_2&=
q[A+B(2v-p)],\\
Y_3&=
2Bpq.
\end{aligned}
}
\tag{6.5}
\]

If the first two coordinates are held fixed and \(p(v),q(v)\) are followed
implicitly, then

\[
\boxed{
\frac{dY_3}{dv}
=
\frac{
8B^2pq
}{
-A+B(p+q-2v)
}.
}
\tag{6.6}
\]

Hence the motion transverse to the two-scale singular surface is indeed of
size

\[
B^2/A.
\]

This is a new quantitative barrier:

> To extract squares robustly from an approximately quadratic secondary
> profile, one must resolve phase information below the \(B\)-scale and down
> to the smaller scale \(B^2/A\), or introduce a third profile scale.

v150 does **not** claim that quadratic corrections are square-free.

It identifies the scale at which the next argument has to operate.

---

# 7. Shifted logarithm: the exact leading surface

Now fix an interval on one side of a pole \(b\).

After translating the normalized coordinate, write

\[
x_j=|u_j-b|>0.
\]

For the leading profile

\[
h_0(t)=\log|t-b|,
\]

the relative phase vector is

\[
H_0
=
\begin{pmatrix}
\log(x_1/x_0)\\
\log(x_2/x_0)\\
\log(x_3/x_0)
\end{pmatrix}.
\]

Because

\[
x_0+x_2=x_1+x_3,
\]

its image lies on the exact surface

\[
\boxed{
R(H_0)
=
1+e^{H_{0,2}}
-e^{H_{0,1}}
-e^{H_{0,3}}
=
0.
}
\tag{7.1}
\]

This is the shifted-log analogue of the affine plane.

---

# 8. Flattening the logarithmic surface at the second scale

Suppose

\[
G_n
=
A_nH_0
+
B_nH_g
+
o(B_n).
\]

Define the output transformation

\[
\boxed{
\Phi_n(y)
=
\left(
\frac{y_1}{A_n},
\frac{y_3}{A_n},
\frac{A_n}{B_n}
R\left(\frac y{A_n}\right)
\right).
}
\tag{8.1}
\]

On the relevant output neighborhood \(\Phi_n\) is injective: the first two
coordinates determine \(y_1,y_3\), and the third determines
\(e^{y_2/A_n}\).

Taylor expansion gives

\[
\boxed{
\Phi_n(G_n)
\longrightarrow
K_g^{\log}
=
\left(
H_{0,1},
H_{0,3},
N_g
\right),
}
\tag{8.2}
\]

where

\[
\boxed{
N_g
=
dR_{H_0}(H_g)
=
\frac{
x_0g(x_0)
-x_1g(x_1)
+x_2g(x_2)
-x_3g(x_3)
}{
x_0
}.
}
\tag{8.3}
\]

For a nearest raw phase-lattice point \(2\pi k_n\),

\[
|2\pi k_n-G_n(\sigma_*)|
\le\pi\sqrt3.
\]

The first two transformed errors are \(O(A_n^{-1})\), while the third is
\(O(B_n^{-1})\).

Thus the transformed lattice again becomes dense at the two appropriate
scales.

No special arithmetic of the exponential surface is needed.

---

# 9. The shifted-log kernel direction

Let

\[
s=v-b
\]

in the normalized profile coordinate and write

\[
x_0=s-a,\quad
x_1=s+b_1,\quad
x_2=s+a,\quad
x_3=s-b_1,
\]

with all \(x_j>0\).

The leading relative log phases are invariant when all \(x_j\) are multiplied
by the same positive constant.

Therefore the kernel direction of the leading map is

\[
\boxed{
V
=
a\partial_a
+
b_1\partial_{b_1}
+
s\partial_s.
}
\tag{9.1}
\]

The first two components of \(K_g^{\log}\) have rank two transverse to \(V\).

Hence the full second-scale map is regular precisely where

\[
VN_g\ne0.
\]

A direct differentiation of (8.3) under

\[
x_j\mapsto cx_j
\]

gives

\[
\boxed{
VN_g
=
\frac{
x_0^2g'(x_0)
-x_1^2g'(x_1)
+x_2^2g'(x_2)
-x_3^2g'(x_3)
}{
x_0
}.
}
\tag{9.2}
\]

---

# 10. Exact shifted-log secondary classification

Suppose

\[
VN_g=0
\]

for every physical parallelogram of positive \(x_j\).

Set

\[
k(x)=x^2g'(x).
\]

Equation (9.2) becomes

\[
k(x_0)-k(x_1)+k(x_2)-k(x_3)=0
\]

whenever

\[
x_0+x_2=x_1+x_3.
\]

Continuity gives the Jensen/Cauchy conclusion

\[
\boxed{
k(x)=\alpha x+\beta.
}
\tag{10.1}
\]

Thus

\[
g'(x)
=
\frac{\alpha}{x}
+
\frac{\beta}{x^2},
\]

and hence

\[
\boxed{
g(x)
=
\alpha\log x
-\frac{\beta}{x}
+\gamma.
}
\tag{10.2}
\]

Returning to \(t\),

\[
\boxed{
g(t)
=
\alpha\log|t-b|
+
\frac{\beta_1}{t-b}
+
\gamma.
}
\tag{10.3}
\]

Conversely every function in (10.3) makes (9.2) vanish identically.

Therefore:

> **Theorem 10.1 — shifted-log secondary rank-loss classification.**  
> The second-scale logarithmic map is singular everywhere if and only if the
> secondary correction lies in
> \[
> \operatorname{span}
> \left\{
> 1,\,
> \log|t-b|,\,
> (t-b)^{-1}
> \right\}.
> \]

The three functions have an exact geometric meaning:

\[
1
\quad\leftrightarrow\quad
\text{phase offset},
\]

\[
\log|t-b|
\quad\leftrightarrow\quad
\text{log coefficient},
\]

\[
(t-b)^{-1}
\quad\leftrightarrow\quad
\text{first-order pole motion}.
\]

So the full invisible second-scale space is precisely the tangent space to
the original shifted-logarithmic exceptional family.

---

# 11. Shifted-log second-scale square theorem

Assume the two-scale expansion (0.7), with all normalized contacts remaining
on one side of the pole.

If \(g\) is outside the family (10.3), Theorem 10.1 gives a regular point of

\[
K_g^{\log}.
\]

Choose a small neighborhood of that point.

Section 8 gives uniform convergence of the transformed exact phase map, and
nearest raw lattice points converge to the required transformed target with
error

\[
O(A_n^{-1})+O(B_n^{-1}).
\]

Brouwer degree therefore gives an exact phase-lattice solution.

Hence:

> **Theorem 11.1 — shifted-log second-scale square forcing.**  
> A shifted-logarithmic leading blow-up with a smaller diverging correction
> forces squares unless that correction is asymptotically a combination of
> offset, coefficient drift, and pole drift.

As in v149, the same result extends through the four-contact radial
backtracking construction whenever the profile estimate holds uniformly over
all returns in the shrinking window.

---

# 12. Exact regular examples

## Affine leading, cubic secondary

Take

\[
g(t)=t^3.
\]

Then

\[
\partial_vQ_g
=
6(a^2-b^2).
\]

At

\[
(a,b,v)=
\left(
1,\frac12,0
\right),
\]

\[
\boxed{
\det DK_g=-9.
}
\tag{12.1}
\]

So a cubic secondary correction is robustly nonexceptional.

For

\[
g(t)=t^2,
\]

\[
\partial_vQ_g\equiv0,
\]

exactly as Theorem 3.1 predicts.

## Shifted-log leading, linear secondary

Take pole \(b=0\),

\[
g(t)=t,
\]

and the positive normalized radii

\[
x_0=2,\quad
x_1=\frac72,\quad
x_2=4,\quad
x_3=\frac52,
\]

corresponding to

\[
(a,b_1,s)=
\left(
1,\frac12,3
\right).
\]

Then

\[
N_g
=
\frac{2(a^2-b_1^2)}{s-a}.
\]

The Jacobian of

\[
(H_{0,1},H_{0,3},N_g)
\]

is exactly

\[
\boxed{
-\frac{
4(a^2-b_1^2)
}{
(s-a)^2(s-b_1)(s+b_1)
}.
}
\tag{12.2}
\]

At the displayed point,

\[
\boxed{
\det DK_g^{\log}
=
-\frac3{35}.
}
\tag{12.3}
\]

So a linear secondary correction restores the scale direction to a leading
logarithmic profile.

---

# 13. What v150 changes in the extraction problem

v149 left four broad possibilities for a hypothetical square-free
high-angular-mass tail:

1. bounded angular mass;
2. no stable profile;
3. affine profile;
4. shifted-log profile.

v150 resolves most of the internal freedom in cases 3 and 4.

An affine blow-up is not enough.

If there is any smaller **diverging** profile correction, it too must be
exceptional:

\[
\boxed{
\text{secondary profile must be quadratic.}
}
\]

A shifted logarithm is even more rigid.

Its smaller diverging correction must remain tangent to the same exceptional
family:

\[
\boxed{
\text{offset + coefficient drift + pole drift only.}
}
\]

Thus an escaping counterexample has to support an **exceptional
renormalization tower**, not merely one exceptional leading profile.

That is a substantially stronger structural requirement.

---

# 14. What remains open

Three serious escape mechanisms remain.

### A. Bounded-mass packets

The angular complexity may be split into infinitely many packets none of
which has diverging normalized amplitude.

v149--v150 do not combine those packets.

### B. Affine-to-quadratic tower

If an affine leading profile has a quadratic secondary profile, the first
missing direction appears only at scale

\[
B^2/A.
\]

A third-scale argument is needed when that quantity does not become large
enough for robust extraction.

### C. Persistent logarithmic parameter drift

A shifted-log tower may keep changing only its coefficient and pole.

That is a finite-dimensional dynamical problem in the logarithmic parameters,
but it is not yet rigid enough to contradict Jordan geometry.

---

# 15. Recommended v151 target

The higher-value target is now the **affine-to-quadratic third scale**.

There is an exact small parameter:

\[
\boxed{
C_n=B_n^2/A_n.
}
\]

Three regimes should be separated.

1. \(C_n\to\infty\): exploit the weak transverse phase motion quantitatively.
2. \(C_n\to C\in(0,\infty)\): derive a finite third-scale normal form.
3. \(C_n\to0\): the quadratic correction is too weak; renormalize the next
   residual.

The exact formulas (6.5)--(6.6) make this unusually tractable.

In parallel, the shifted-log parameter tower can be written as evolution of

\[
(a_n,b_n,c_n)
\]

for coefficient, pole, and offset.

If its pole moves by more than the shrinking-window width, it should leave
the log tangent family in the next normalization.

So there is a realistic route to a full exceptional-tower dichotomy.

---

# 16. Claim boundary

## Established in v150

- exact two-scale output quotient for an affine leading profile;
- exact affine secondary map \(K_g\);
- exact classification:
  \[
  \text{secondary singular everywhere}
  \iff
  g\text{ quadratic};
  \]
- affine leading plus any diverging nonquadratic secondary profile forces
  squares;
- derivative interpretation: the smaller slope modulation may remain
  invisible only if it is asymptotically affine;
- exact quadratic Jacobian and the weak transverse scale
  \[
  B^2/A;
  \]
- exact logarithmic leading surface;
- exact nonlinear flattening of that surface at the secondary scale;
- exact shifted-log secondary normal functional;
- exact classification:
  \[
  g\in
  \operatorname{span}
  \{1,\log|t-b|,(t-b)^{-1}\}
  \]
  is the complete second-scale invisible family;
- shifted-log leading plus every other diverging secondary profile forces
  squares;
- exact regular examples for both branches.

## Inherited and used

- v149 shrinking-window square coordinates and phase-lattice degree;
- post-v148 classification of the two leading exceptional \(C^1\) profiles;
- post-v148 four-contact radial-backtracking transfer machinery.

## Not established

- robust extraction through the quadratic secondary scale in all regimes;
- iteration of the affine/quadratic tower to arbitrary depth;
- rigidity of persistent shifted-log coefficient/pole drift;
- accumulation of infinitely many bounded-mass angular packets;
- universal square existence;
- the Toeplitz square-peg conjecture.

The frontier is now an **exceptional renormalization tower**, with the
affine-to-quadratic third scale \(B^2/A\) as the cleanest next target.
