# Project Handoff v151: Third-Scale Cubic Resonance and Logarithmic Compactification

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v150 identified the weak transverse phase scale left by an affine leading
profile with quadratic secondary profile:

\[
\boxed{
C_n^{(3)}=\frac{B_n^2}{A_n}.
}
\]

v151 resolves the regime in which that weak scale, possibly together with a
smaller tertiary profile, still tends to infinity.

The result is a third-scale classification theorem.

Suppose on the shrinking windows from v149

\[
\boxed{
F_n(t)
=
A_n t
+
B_n t^2
+
C_n g(t)
+
r_n(t),
}
\tag{0.1}
\]

uniformly on the required compact profile interval, with

\[
A_n>0,\qquad
B_n\ge0,\qquad
C_n\ge0,
\]

\[
\boxed{
A_n\to\infty,
\qquad
\frac{B_n}{A_n}\to0,
\qquad
\frac{C_n}{A_n}\to0.
}
\tag{0.2}
\]

Define the total third-scale amplitude

\[
\boxed{
E_n
=
\frac{B_n^2}{A_n}+C_n.
}
\tag{0.3}
\]

Assume

\[
\boxed{
E_n\to\infty,
\qquad
\frac{\|r_n\|_\infty}{E_n}\to0,
}
\tag{0.4}
\]

and after passing to a subsequence

\[
\boxed{
\theta_n
=
\frac{B_n^2/A_n}{E_n}
\longrightarrow
\theta\in[0,1].
}
\tag{0.5}
\]

After an exact integer change of the three relative phase equations and a
nonlinear flattening of the quadratic phase surface, the limiting map is

\[
\boxed{
K_{\theta,g}(p,q,v)
=
\left(
p,\,
q,\,
R_{\theta,g}(p,q,v)
\right),
}
\tag{0.6}
\]

where

\[
\boxed{
R_{\theta,g}
=
-2\theta pq(4v-p-q)
+
(1-\theta)Q_g,
}
\tag{0.7}
\]

and

\[
\boxed{
Q_g
=
g(v-a)-g(v+b)+g(v+a)-g(v-b),
}
\tag{0.8}
\]

with

\[
p=a+b,\qquad q=a-b.
\]

The determinant is simply

\[
\boxed{
\det DK_{\theta,g}
=
-8\theta pq
+
(1-\theta)\,\partial_vQ_g.
}
\tag{0.9}
\]

This yields a complete classification.

### If \(\theta=1\)

The quadratic weak motion dominates the third scale.

Then

\[
\boxed{
\det DK_{1,g}=-8pq,
}
\tag{0.10}
\]

so the limiting map is automatically regular away from

\[
pq=0.
\]

Therefore:

> **Quadratic weak-scale theorem.**
> If
> \[
> \boxed{
> B_n^2/A_n\to\infty
> }
> \]
> and every still smaller profile term is
> \[
> o(B_n^2/A_n),
> \]
> the shrinking-window phase degree forces actual squares.

This completely resolves regime 1 proposed in v150.

### If \(0\le\theta<1\)

The map is singular everywhere if and only if

\[
\boxed{
g(t)
=
\frac{4\theta}{3(1-\theta)}\,t^3
+
\alpha t^2+\beta t+\gamma.
}
\tag{0.11}
\]

Thus the only new third-scale escape is a **tuned cubic**.

Everything else restores full degree and forces actual squares.

For a pure cubic tertiary correction,

\[
g(t)=t^3,
\]

write

\[
\rho_n
=
\frac{C_n}{B_n^2/A_n}.
\]

The unique singular ratio is

\[
\boxed{
\rho_n\to\frac43.
}
\tag{0.12}
\]

So

\[
\boxed{
A t+B t^2+C t^3
}
\]

can remain exceptional through the third scale only when

\[
\boxed{
C
\sim
\frac{4B^2}{3A}.
}
\tag{0.13}
\]

That coefficient is not accidental.

Define

\[
\boxed{
\mathfrak L_{A,B}(t)
=
-\frac{A^2}{2B}
\log
\left(
1-\frac{2B}{A}t
\right).
}
\tag{0.14}
\]

Its Taylor expansion is

\[
\boxed{
\mathfrak L_{A,B}(t)
=
A t
+
B t^2
+
\frac{4B^2}{3A}t^3
+
\frac{2B^3}{A^2}t^4
+
\frac{16B^4}{5A^3}t^5
+\cdots.
}
\tag{0.15}
\]

Thus the unique tuned cubic is exactly the third Taylor coefficient of a
shifted logarithm whose pole is

\[
\boxed{
b=\frac{A}{2B}.
}
\tag{0.16}
\]

As

\[
B/A\to0,
\]

the pole escapes to infinity and the shifted logarithm approaches an affine
profile.

This unifies the two exceptional families from v149:

\[
\boxed{
\text{affine}
=
\text{shifted logarithm with pole at infinity}.
}
\tag{0.17}
\]

So the exceptional renormalization tower is not generating unrelated
polynomial coincidences.  It is reconstructing the Taylor jet of the
shifted-logarithmic family.

An exact fourth-order audit supports this interpretation.

If the cubic is tuned as in (0.13) and

\[
D_n
=
d\,\frac{B_n^3}{A_n^2}
\]

multiplies \(t^4\), then the square-map Jacobian has leading term

\[
\boxed{
\det DH
=
48(d-2)
B_n^3
v(a^2-b^2)
+
O\left(
\frac{B_n^4}{A_n}
\right).
}
\tag{0.18}
\]

The fourth-order leading degeneracy occurs precisely at

\[
\boxed{
d=2,
}
\tag{0.19}
\]

again exactly the shifted-log Taylor coefficient.

v151 proves the third-scale theorem.  Equation (0.18) is an exact asymptotic
audit and identifies the next scale, but the full fourth-scale lattice degree
is left for the next version.

---

# 1. Relative phase coordinates

Use the v149 additive contact coordinates

\[
u_0=v-a,\qquad
u_1=v+b,\qquad
u_2=v+a,\qquad
u_3=v-b.
\]

For any profile \(h\), define

\[
H_h
=
\begin{pmatrix}
h(u_1)-h(u_0)\\
h(u_2)-h(u_0)\\
h(u_3)-h(u_0)
\end{pmatrix}.
\]

Apply the integer unimodular output map

\[
\boxed{
L(y_1,y_2,y_3)
=
(y_1,\ y_3,\ -y_1+y_2-y_3).
}
\tag{1.1}
\]

Because

\[
\det L=-1,
\]

\[
L(2\pi\mathbb Z^3)=2\pi\mathbb Z^3.
\]

Set

\[
p=a+b,\qquad
q=a-b.
\]

For the affine profile,

\[
\boxed{
LH_t=(p,q,0).
}
\tag{1.2}
\]

For the quadratic profile,

\[
\boxed{
LH_{t^2}
=
\left(
p(2v-q),\,
q(2v-p),\,
2pq
\right).
}
\tag{1.3}
\]

For a general tertiary profile \(g\),

\[
\boxed{
LH_g=(G_1,G_3,Q_g),
}
\tag{1.4}
\]

where

\[
G_1=g(v+b)-g(v-a),
\]

\[
G_3=g(v-b)-g(v-a),
\]

and \(Q_g\) is (0.8).

---

# 2. The quadratic phase surface

Ignoring the \(o(E_n)\) remainder and the v149 square-angle correction, the
three transformed phase coordinates are

\[
\boxed{
\begin{aligned}
Y_1&=
A p+Bp(2v-q)+CG_1,\\
Y_2&=
A q+Bq(2v-p)+CG_3,\\
Y_3&=
2Bpq+CQ_g.
\end{aligned}
}
\tag{2.1}
\]

Since

\[
B/A\to0,
\qquad
C/A\to0,
\]

the first two normalized coordinates

\[
X_1=Y_1/A,\qquad X_2=Y_2/A
\]

satisfy

\[
\boxed{
X_1\to p,\qquad X_2\to q.
}
\tag{2.2}
\]

The large third coordinate \(2Bpq\) is determined by those first two
coordinates at leading order.

Flatten it by defining

\[
\boxed{
Z
=
Y_3
-
2B X_1X_2.
}
\tag{2.3}
\]

Direct expansion gives

\[
\boxed{
Z
=
-2\frac{B^2}{A}
pq(4v-p-q)
+
C Q_g
+
o(E_n).
}
\tag{2.4}
\]

The error terms generated by the nonlinear flattening are

\[
O\left(
\frac{B^3}{A^2}
\right)
+
O\left(
\frac{BC}{A}
\right)
+
O\left(
\frac{BC^2}{A^2}
\right),
\]

all of which are \(o(E_n)\).

The exact square-chart angular corrections from v149 are \(O(\delta_n)\) and
therefore also \(o(E_n)\) because \(E_n\to\infty\).

---

# 3. Third-scale limit

Normalize with

\[
\boxed{
\Phi_n(Y)
=
\left(
\frac{Y_1}{A_n},
\frac{Y_2}{A_n},
\frac{
Y_3-2B_n(Y_1/A_n)(Y_2/A_n)
}{
E_n
}
\right).
}
\tag{3.1}
\]

Then uniformly on compact parameter boxes,

\[
\boxed{
\Phi_n(Y_n)
\longrightarrow
K_{\theta,g}.
}
\tag{3.2}
\]

This nonlinear target change does not preserve the phase lattice exactly, but
that is not required.

Given any target output \(Y_n(\sigma_*)\), choose a nearest raw phase-lattice
point

\[
\ell_n\in2\pi\mathbb Z^3.
\]

Then

\[
|\ell_n-Y_n(\sigma_*)|\le\pi\sqrt3.
\]

Because

\[
A_n\to\infty,
\qquad
E_n\to\infty,
\]

the transformed difference satisfies

\[
\boxed{
\left|
\Phi_n(\ell_n)
-
\Phi_n(Y_n(\sigma_*))
\right|
\to0.
}
\tag{3.3}
\]

The two errors in the first coordinates are \(O(A_n^{-1})\); the third is

\[
O(E_n^{-1})
+
O\left(
\frac{B_n}{A_nE_n}
\right).
\]

Thus the phase lattice becomes dense in the anisotropically flattened
third-scale coordinates.

At a regular point of \(K_{\theta,g}\), the same local Brouwer-degree
argument used in v146, v149, and v150 therefore produces an exact lattice
solution, hence an actual square.

---

# 4. Third-scale determinant

Since the first two limiting coordinates are exactly \(p,q\),

\[
\det DK_{\theta,g}
=
\partial_vR_{\theta,g}.
\]

Now

\[
\partial_v
\left[
-2\theta pq(4v-p-q)
\right]
=
-8\theta pq,
\]

so

\[
\boxed{
\det DK_{\theta,g}
=
-8\theta pq
+
(1-\theta)
\left[
g'(v-a)-g'(v+b)+g'(v+a)-g'(v-b)
\right].
}
\tag{4.1}
\]

This is the exact limiting determinant.

---

# 5. Classification of everywhere-singular tertiary profiles

Assume first

\[
0\le\theta<1.
\]

If (4.1) vanishes identically, put

\[
h=g'
\]

and

\[
c=\frac{8\theta}{1-\theta}.
\]

Then

\[
\boxed{
h(v-a)-h(v+b)+h(v+a)-h(v-b)
=
c(a^2-b^2).
}
\tag{5.1}
\]

Set \(b=0\).  We obtain

\[
\boxed{
h(v-a)+h(v+a)-2h(v)=ca^2.
}
\tag{5.2}
\]

Subtract

\[
\frac c2v^2.
\]

The resulting continuous function satisfies midpoint Jensen, so it is affine.

Therefore

\[
h(v)
=
\frac c2v^2+\alpha v+\beta.
\]

Integrating,

\[
\boxed{
g(v)
=
\frac c6v^3
+
\frac\alpha2v^2
+
\beta v+\gamma.
}
\]

Since

\[
c=\frac{8\theta}{1-\theta},
\]

the cubic coefficient is

\[
\boxed{
\frac{4\theta}{3(1-\theta)}.
}
\tag{5.3}
\]

Conversely every such cubic-plus-quadratic profile makes (4.1) vanish
identically.

Thus:

> **Theorem 5.1 — third-scale rank-loss classification.**  
> If \(0\le\theta<1\), the third-scale map is singular everywhere if and only
> if
> \[
> \boxed{
> g(t)=
> \frac{4\theta}{3(1-\theta)}t^3
> +\alpha t^2+\beta t+\gamma.
> }
> \]

For

\[
\theta=0,
\]

this reduces to v150's quadratic secondary exception.

For

\[
\theta\uparrow1,
\]

the required cubic coefficient diverges.

At

\[
\theta=1
\]

there is no finite tertiary profile capable of cancelling the intrinsic
quadratic weak motion.

---

# 6. Square-forcing theorem at the third scale

Combine Sections 3--5.

> **Theorem 6.1 — third-scale square forcing.**  
> Assume (0.1)--(0.5) in the shrinking-window setting of v149.
>
> If
> \[
> \theta=1,
> \]
> then actual squares are forced.
>
> If
> \[
> 0\le\theta<1,
> \]
> actual squares are forced unless the limiting tertiary profile has exactly
> the tuned form
> \[
> \boxed{
> g(t)=
> \frac{4\theta}{3(1-\theta)}t^3
> +\text{quadratic polynomial}.
> }
> \]
>
> The resulting squares have the same physical scale as v149:
> \[
> \boxed{
> \ell_n\asymp e^{-T_n}\delta_n.
> }
> \]

As before, the four-contact radial-backtracking and complementary-access
versions follow whenever the corresponding normalized profile estimate holds
uniformly over all returns in the shrinking window.

---

# 7. Pure quadratic secondary: v150 regime 1 is closed

Take

\[
C_n=o(B_n^2/A_n).
\]

If

\[
\boxed{
B_n^2/A_n\to\infty,
}
\]

then

\[
\theta=1.
\]

Theorem 6.1 immediately gives:

> **Corollary 7.1.**
> An affine leading profile with a quadratic secondary correction forces
> squares whenever its weak transverse phase scale
> \[
> \boxed{
> B_n^2/A_n
> }
> \]
> diverges.

Thus the quadratic secondary barrier from v150 is only a barrier when

\[
B_n^2/A_n
\]

stays bounded or tends to zero.

---

# 8. Pure cubic tertiary: unique resonance ratio

Take

\[
g(t)=t^3
\]

and suppose

\[
B_n^2/A_n>0.
\]

Write

\[
\rho_n
=
\frac{C_n}{B_n^2/A_n}
\longrightarrow
\rho\in[0,\infty].
\]

For finite \(\rho\),

\[
\theta=\frac1{1+\rho}.
\]

The tuned cubic coefficient condition is

\[
1=
\frac{4}{3\rho}.
\]

Hence

\[
\boxed{
\rho=\frac43.
}
\tag{8.1}
\]

Therefore:

> **Corollary 8.1 — cubic resonance.**  
> If
> \[
> E_n\to\infty
> \]
> and
> \[
> \frac{C_n}{B_n^2/A_n}
> \not\to\frac43,
> \]
> then an affine + quadratic + cubic blow-up forces squares.
>
> The only third-scale resonance is
> \[
> \boxed{
> C_n\sim\frac{4B_n^2}{3A_n}.
> }
> \]

---

# 9. The resonance is exactly a shifted logarithm

Set

\[
\varepsilon=\frac{2B}{A}.
\]

Then

\[
-\frac{A}{\varepsilon}\log(1-\varepsilon t)
=
A
\sum_{k\ge1}
\frac{\varepsilon^{k-1}}{k}t^k.
\]

Since

\[
\frac{A}{\varepsilon}
=
\frac{A^2}{2B},
\]

the coefficients are

\[
\boxed{
c_k
=
\frac{2^{k-1}}{k}
\frac{B^{k-1}}{A^{k-2}}.
}
\tag{9.1}
\]

In particular,

\[
c_1=A,
\qquad
c_2=B,
\]

\[
\boxed{
c_3=\frac{4B^2}{3A},
}
\tag{9.2}
\]

\[
\boxed{
c_4=\frac{2B^3}{A^2},
}
\tag{9.3}
\]

\[
\boxed{
c_5=\frac{16B^4}{5A^3}.
}
\tag{9.4}
\]

Thus the unique cubic resonance from Corollary 8.1 is precisely the shifted
logarithmic jet.

The pole is

\[
\boxed{
t=\frac1\varepsilon=\frac{A}{2B}.
}
\]

When

\[
B/A\to0,
\]

this pole tends to infinity.

Therefore the affine family is the pole-at-infinity boundary of the
shifted-log exceptional family.

This is the conceptual synthesis of v149--v151.

---

# 10. Exact fourth-order audit

The cubic resonance suggests checking the next coefficient.

Take

\[
\boxed{
f(t)
=
At
+
Bt^2
+
\frac{4B^2}{3A}t^3
+
d\frac{B^3}{A^2}t^4.
}
\tag{10.1}
\]

Direct symbolic evaluation of the exact three-dimensional relative phase
Jacobian gives, on every fixed compact \((a,b,v)\)-set,

\[
\boxed{
\det DH_f
=
48(d-2)B^3v(a^2-b^2)
+
O(B^4/A).
}
\tag{10.2}
\]

Therefore the third-scale resonance is broken at the next order unless

\[
\boxed{
d=2.
}
\]

But

\[
d=2
\]

is exactly the fourth shifted-log coefficient (9.3).

For \(d=2\), the leading determinant moves down by one further factor
\(B/A\).

This is an audit, not yet a complete fourth-scale lattice-capture theorem.

---

# 11. Emerging exceptional tower

The first coefficients now read

\[
A,
\quad
B,
\quad
\frac{4B^2}{3A},
\quad
\frac{2B^3}{A^2},
\quad
\frac{16B^4}{5A^3},
\ldots
\]

which are precisely

\[
\boxed{
c_k=
\frac{2^{k-1}}{k}
\frac{B^{k-1}}{A^{k-2}}.
}
\]

The corresponding phase scales decrease geometrically by

\[
\frac BA.
\]

This suggests the following renormalization picture:

\[
\boxed{
A
\;\to\;
B
\;\to\;
\frac{B^2}{A}
\;\to\;
\frac{B^3}{A^2}
\;\to\cdots
}
\tag{11.1}
\]

A square-free tail can remain in the affine exceptional channel only by
matching the shifted-log Taylor jet for as many of these scales as remain
phase-visible.

This statement is proved through the cubic resonance and audited at quartic
order.  The all-orders version remains open.

---

# 12. Why this matters for extraction

The post-v148 classification originally produced two apparently independent
exceptions:

1. affine;
2. shifted logarithmic.

v151 shows that they are actually one compactified family.

If repeated zooms of a hypothetical counterexample keep producing an affine
profile, but a nontrivial quadratic correction is visible, then either

\[
B^2/A\to\infty
\]

and Corollary 7.1 forces squares, or the next phase scale becomes small.

If a cubic correction is visible at the third scale, it must satisfy the
precise resonance

\[
\frac{C}{B^2/A}\to\frac43.
\]

That resonance moves the profile toward the shifted-log family.

So persistent affine exceptional behavior cannot wander arbitrarily through
profile space.

It is funneled toward a logarithmic pole escaping to infinity.

---

# 13. What is still open

The theorem leaves three serious possibilities.

### I. The phase-visible tower terminates

At some depth,

\[
\frac{B^k}{A^{k-1}}
\]

may become \(O(1)\) before a profile mismatch becomes visible.

Then phase-lattice density is no longer enough for the Brouwer capture.

### II. The profile matches the logarithmic jet to every visible order

The local tail may genuinely approach a shifted logarithm with a moving pole.

That returns us to the finite-dimensional logarithmic parameter dynamics from
v150.

### III. No stable multiscale jet exists

Angular complexity can still be distributed among bounded-mass,
nonconvergent packets.

The extraction theorem has not yet ruled that out.

---

# 14. Recommended v152 target

There are now two unusually concrete targets.

### Route A — fourth and all-order logarithmic jet rigidity

Construct the next nonlinear flattening after the tuned cubic surface.

Prove rigorously that at scale

\[
\boxed{
B^3/A^2
}
\]

the only quartic cancellation coefficient is

\[
\boxed{2}.
\]

Then seek an induction showing that the unique \(k\)-th cancellation
coefficient is

\[
\boxed{
c_k=
\frac{2^{k-1}}{k}
\frac{B^{k-1}}{A^{k-2}}.
}
\]

That would identify the complete affine exceptional tower with the shifted
logarithm.

### Route B — visible-depth versus pole motion

If the shifted-log pole is

\[
b_n=A_n/(2B_n),
\]

compare its motion to the shrinking window.

A pole that moves substantially between nested windows should create a
non-logarithmic secondary profile and be killed by v150.

A pole that does not move substantially may yield a genuine asymptotic log
model, which can then be attacked directly.

Route B may be the shorter route to an extraction theorem.

---

# 15. Claim boundary

## Established in v151

- exact nonlinear flattening of the quadratic phase surface;
- exact third-scale limiting map \(K_{\theta,g}\);
- exact third-scale determinant;
- complete \(C^1\) classification of everywhere-singular tertiary profiles;
- if \(B^2/A\to\infty\), a pure quadratic secondary profile forces squares;
- unique pure-cubic resonance
  \[
  C/(B^2/A)\to4/3;
  \]
- the cubic resonance is exactly the third Taylor coefficient of a shifted
  logarithm;
- affine profiles are the pole-at-infinity boundary of the shifted-log
  exceptional family;
- exact quartic determinant audit identifying the next resonant coefficient
  \(2B^3/A^2\).

## Inherited and used

- v149 shrinking-window phase-lattice square forcing;
- v150 affine secondary quadratic exception and weak scale \(B^2/A\);
- v150 shifted-log tangent-family classification.

## Not established

- complete fourth-scale Brouwer lattice capture;
- all-orders uniqueness of the logarithmic jet;
- rigidity of a moving shifted-log pole;
- bounded-mass/nonprofile packet accumulation;
- universal square existence;
- the Toeplitz square-peg conjecture.

The frontier is now the **logarithmic exceptional tower and its pole
dynamics**, rather than a generic space of exceptional profiles.
