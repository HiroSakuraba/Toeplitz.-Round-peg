# Project Handoff v152: Moving-Log Resummation and All-Order Visible-Jet Rigidity

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v151 found the cubic resonance

\[
C\sim \frac{4B^2}{3A}
\]

and audited the quartic resonance

\[
D\sim 2\frac{B^3}{A^2}.
\]

The apparent next task was to construct a new nonlinear flattening at every
successive scale

\[
\frac{B^{m-1}}{A^{m-2}}.
\]

v152 shows that this is unnecessary for fixed-order polynomial jets.

The key observation is that the entire resonant tower can be **resummed into
one exact shifted logarithm**

\[
\boxed{
\mathfrak L_{A,B}(t)
=
-\frac{A^2}{2B}
\log\!\left(1-\frac{2B}{A}t\right).
}
\tag{0.1}
\]

Instead of flattening the affine plane, then the quadratic surface, then the
tuned cubic surface, one flattens the exact phase surface of (0.1) while its
pole

\[
\boxed{b=\frac{A}{2B}}
\]

moves to infinity.

This gives a one-shot theorem.

Suppose, on the shrinking windows inherited from v149,

\[
\boxed{
F_n(t)
=
\mathfrak L_{A_n,B_n}(t)
+
S_n g(t)
+
r_n(t),
}
\tag{0.2}
\]

uniformly on a fixed compact profile interval, where

\[
A_n\to\infty,
\qquad
B_n>0,
\qquad
\frac{B_n}{A_n}\to0,
\tag{0.3}
\]

\[
\boxed{
S_n\to\infty,
\qquad
\frac{S_n}{A_n}\to0,
\qquad
\frac{\|r_n\|_\infty}{S_n}\to0.
}
\tag{0.4}
\]

Then the exact moving-log phase surface can be flattened so that the limiting
map is

\[
\boxed{
K_g(p,q,v)
=
\left(
 p,
 q,
 -Q_g(p,q,v)
\right),
}
\tag{0.5}
\]

where

\[
Q_g
=
g(v-a)-g(v+b)+g(v+a)-g(v-b),
\qquad
p=a+b,
\quad
q=a-b.
\tag{0.6}
\]

Hence, in \((p,q,v)\)-coordinates,

\[
\boxed{
\det DK_g=-\partial_vQ_g.
}
\tag{0.7}
\]

Exactly as in v150, this determinant vanishes everywhere if and only if
\(g\) is quadratic.

Therefore:

> **Moving-log residual theorem.**  
> A diverging residual around the exact shifted-log reference forces actual
> squares unless its limiting profile is quadratic.

For a polynomial jet whose linear and quadratic coefficients have already
been used to define \(A_n,B_n\), every nonzero residual beginning in degree
\(3\) is nonquadratic.  Thus every **phase-visible** deviation from the exact
shifted-log jet is square-forcing.

This immediately upgrades the v151 quartic audit to a theorem and gives a
fixed-order all-orders result.

Define

\[
\boxed{
S_{m,n}
=
\frac{B_n^{m-1}}{A_n^{m-2}}
}
\tag{0.8}
\]

and the shifted-log coefficient

\[
\boxed{
c_{m,n}^*
=
\frac{2^{m-1}}{m}
\frac{B_n^{m-1}}{A_n^{m-2}}.
}
\tag{0.9}
\]

For any fixed \(m\ge3\), if \(S_{m,n}\to\infty\) and an expansion through
degree \(m\) is controlled to \(o(S_{m,n})\), then a square-free tail must
match **all** coefficients \(3,\ldots,m\) to the shifted-log jet with absolute
error \(o(S_{m,n})\).

In particular, at the fourth scale

\[
S_{4,n}=\frac{B_n^3}{A_n^2}\to\infty,
\]

square-freeness requires simultaneously

\[
\boxed{
C_n
=
\frac{4B_n^2}{3A_n}
+o\!\left(\frac{B_n^3}{A_n^2}\right),
}
\tag{0.10}
\]

and

\[
\boxed{
D_n
=
2\frac{B_n^3}{A_n^2}
+o\!\left(\frac{B_n^3}{A_n^2}\right).
}
\tag{0.11}
\]

So the quartic coefficient \(2\) is no longer merely an exact determinant
audit.  It is the unique fourth-scale coefficient compatible with the
shrinking-window lattice degree, under the stated profile control.

A second exact identity explains why the logarithm is the unique object that
can survive this tower.  For any \(C^1\) profile \(f\), with

\[
u_0=v-a,
\quad
u_1=v+b,
\quad
u_2=v+a,
\quad
u_3=v-b,
\]

let

\[
H_f
=
\begin{pmatrix}
f(u_1)-f(u_0)\\
f(u_2)-f(u_0)\\
f(u_3)-f(u_0)
\end{pmatrix}.
\]

Then, writing \(d_j=f'(u_j)\),

\[
\boxed{
\det DH_f
=
2d_0d_1d_2d_3
\left(
\frac1{d_1}+\frac1{d_3}-\frac1{d_0}-\frac1{d_2}
\right).
}
\tag{0.12}
\]

Thus the square-map rank defect is exactly the parallelogram additivity
defect of the **reciprocal slope**

\[
r=\frac1{f'}.
\]

When \(f'\neq0\), everywhere rank loss is equivalent to midpoint Jensen for
\(r\), hence to

\[
\boxed{r(t)=\alpha t+\beta.}
\tag{0.13}
\]

Integrating gives precisely the two v149 exceptional families:

\[
\boxed{
\text{affine}
\quad\text{or}\quad
\text{shifted logarithm}.
}
\tag{0.14}
\]

So v152 identifies a single structural invariant behind both the global
exceptional classification and the multiscale Taylor resonances:

\[
\boxed{
\text{persistent exceptionality}
\iff
\frac1{f'}\text{ remains asymptotically affine.}
}
\tag{0.15}
\]

The main unresolved issues are now not the quartic or any fixed higher
polynomial coefficient.  They are:

1. termination of the visible scale tower before a mismatch diverges;
2. genuinely moving shifted-log parameters across nested windows;
3. bounded-mass/nonprofile packet accumulation.

---

# 1. Exact reciprocal-slope Jacobian identity

For the raw relative phase map

\[
H_f(a,b,v)
=
\begin{pmatrix}
f(u_1)-f(u_0)\\
f(u_2)-f(u_0)\\
f(u_3)-f(u_0)
\end{pmatrix},
\]

we have

\[
\partial_a u_0=-1,
\quad
\partial_a u_2=1,
\]

\[
\partial_b u_1=1,
\quad
\partial_b u_3=-1,
\]

and every \(u_j\) has \(\partial_vu_j=1\).

Writing

\[
d_j=f'(u_j),
\]

the Jacobian is exactly

\[
DH_f
=
\begin{pmatrix}
d_0&d_1&d_1-d_0\\
d_2+d_0&0&d_2-d_0\\
d_0&-d_3&d_3-d_0
\end{pmatrix}.
\tag{1.1}
\]

Its determinant factors as

\[
\boxed{
\det DH_f
=
2(
 d_0d_1d_2
-d_0d_1d_3
+d_0d_2d_3
-d_1d_2d_3
).
}
\tag{1.2}
\]

If all \(d_j\neq0\), this is

\[
\boxed{
\det DH_f
=
2\prod_{j=0}^3d_j
\left[
 r(u_1)+r(u_3)-r(u_0)-r(u_2)
\right],
}
\tag{1.3}
\]

where

\[
r=\frac1{f'}.
\]

But

\[
u_0+u_2=u_1+u_3=2v.
\tag{1.4}
\]

Therefore exact rank loss is controlled by an additive parallelogram defect
of \(r\).

Setting \(b=0\) in the everywhere-singular identity gives

\[
r(v-a)+r(v+a)=2r(v).
\tag{1.5}
\]

Under continuity, midpoint Jensen implies

\[
r(v)=\alpha v+\beta.
\tag{1.6}
\]

Hence

\[
f'(v)=\frac1{\alpha v+\beta}.
\]

If \(\alpha=0\), \(f\) is affine.  If \(\alpha\ne0\),

\[
f(v)=\frac1\alpha\log|\alpha v+\beta|+\gamma.
\]

This recovers the affine / shifted-log dichotomy from one exact formula.

---

# 2. The exact moving shifted-log surface

Set

\[
\lambda=\frac{2B}{A},
\qquad
M=\frac{A}{\lambda}=\frac{A^2}{2B},
\tag{2.1}
\]

and

\[
h_\lambda(t)=-\log(1-\lambda t).
\]

Then

\[
\mathfrak L_{A,B}=Mh_\lambda.
\]

For fixed compact \(t\)-intervals and \(B/A\to0\), eventually
\(1-\lambda t>0\).

Define

\[
z_j=1-\lambda u_j.
\]

Because of (1.4),

\[
\boxed{z_0+z_2=z_1+z_3.}
\tag{2.2}
\]

For the relative phases of \(h_\lambda\),

\[
H_j=h_\lambda(u_j)-h_\lambda(u_0),
\]

we have

\[
e^{-H_j}=\frac{z_j}{z_0}.
\]

Hence the image lies on the exact surface

\[
\boxed{
\mathcal R_-(H)
=
1+e^{-H_2}-e^{-H_1}-e^{-H_3}
=0.
}
\tag{2.3}
\]

This surface is valid for every \(\lambda\); no Taylor truncation has been
made.

As \(\lambda\to0\), the moving logarithmic pole

\[
b=\lambda^{-1}=\frac{A}{2B}
\]

escapes to infinity and the surface degenerates toward the affine phase
plane.

---

# 3. One-shot moving-log flattening

Assume (0.2)--(0.4).  Let

\[
Y_n=H_{F_n}.
\]

Define

\[
\boxed{
\Psi_n(y)
=
\left(
\frac{y_1}{A_n},
\frac{y_3}{A_n},
\frac{M_n}{S_n}
\mathcal R_-\!\left(\frac{y}{M_n}\right)
\right),
}
\tag{3.1}
\]

where

\[
M_n=\frac{A_n^2}{2B_n}.
\]

The transform is locally injective on the relevant output neighborhood.
Indeed, the first two displayed coordinates determine \(y_1,y_3\), while
the third determines

\[
e^{-y_2/M_n}
\]

from (2.3).

Now

\[
\frac{S_n}{M_n}
=
\frac{S_n}{A_n}\frac{2B_n}{A_n}
\to0.
\tag{3.2}
\]

The first coordinate satisfies

\[
\frac{M_n}{A_n}
\left[
h_{\lambda_n}(u_1)-h_{\lambda_n}(u_0)\right]
\to u_1-u_0=p,
\]

because \(M_n/A_n=1/\lambda_n\) and

\[
\lambda_n^{-1}h_{\lambda_n}(t)\to t.
\]

Similarly the second displayed coordinate tends to \(q\).

For the third coordinate, use the exact identity

\[
\mathcal R_-(H_{h_{\lambda_n}})=0.
\]

Taylor expansion only in the **small residual direction** gives

\[
\frac{M_n}{S_n}
\mathcal R_-\!\left(
H_{h_{\lambda_n}}
+
\frac{S_n}{M_n}H_g
+o(S_n/M_n)
\right)
\]

\[
=
d\mathcal R_-\big|_{H_{h_{\lambda_n}}}(H_g)+o(1).
\tag{3.3}
\]

Since \(H_{h_{\lambda_n}}\to0\),

\[
d\mathcal R_-\big|_0(H_g)
=H_{g,1}-H_{g,2}+H_{g,3}.
\]

But

\[
H_{g,1}-H_{g,2}+H_{g,3}
=-Q_g.
\]

Therefore

\[
\boxed{
\Psi_n(Y_n)
\longrightarrow
K_g(p,q,v)
=
(p,q,-Q_g).
}
\tag{3.4}
\]

uniformly on compact parameter boxes.

This is the central v152 resummation.

---

# 4. Phase-lattice density survives the exact flattening

Let \(Y_n(\sigma_*)\) be the raw phase target at a regular point of \(K_g\),
and choose a nearest raw lattice point

\[
\ell_n\in2\pi\mathbb Z^3.
\]

Then

\[
|\ell_n-Y_n(\sigma_*)|\le\pi\sqrt3.
\]

The first two transformed differences are

\[
O(A_n^{-1}).
\]

For the third coordinate, the derivative of

\[
y\mapsto\mathcal R_-(y/M_n)
\]

is \(O(M_n^{-1})\) on the relevant compact output neighborhood.  Therefore

\[
\boxed{
\left|
\frac{M_n}{S_n}
\left[
\mathcal R_-(\ell_n/M_n)
-
\mathcal R_-(Y_n(\sigma_*)/M_n)
\right]
\right|
=O(S_n^{-1}).
}
\tag{4.1}
\]

Thus

\[
\boxed{
\Psi_n(\ell_n)
-
\Psi_n(Y_n(\sigma_*))
\to0.
}
\tag{4.2}
\]

The exact square-chart angular corrections inherited from v149 are also
\(o(S_n)\) because \(S_n\to\infty\).

Hence the same local Brouwer-degree argument used in v149--v151 applies.
Injectivity of \(\Psi_n\) turns a solution of the transformed target equation
back into an exact raw phase-lattice solution.

---

# 5. Classification of moving-log residuals

In \((p,q,v)\)-coordinates the first two components of \(K_g\) are exactly
\(p,q\).  Therefore

\[
\boxed{
\det DK_g
=-\partial_vQ_g.
}
\tag{5.1}
\]

Now

\[
\partial_vQ_g
=
g'(v-a)-g'(v+b)+g'(v+a)-g'(v-b).
\tag{5.2}
\]

If this vanishes identically, put \(h=g'\) and set \(b=0\).  Then

\[
h(v-a)+h(v+a)-2h(v)=0.
\]

Continuity gives that \(h\) is affine.  Hence \(g\) is quadratic.
Conversely every quadratic \(g\) gives \(\partial_vQ_g\equiv0\).

Therefore:

> **Theorem 5.1 — moving-log residual square forcing.**  
> In the shrinking-window setting of v149, assume (0.2)--(0.4) with
> \(g\in C^1\).  If \(g\) is not a quadratic polynomial, then the phase
> degree forces actual squares.

The physical square scale remains the v149 scale

\[
\ell_n\asymp e^{-T_n}\delta_n.
\]

---

# 6. Fixed-order all-order logarithmic jet rigidity

The shifted-log Taylor expansion is

\[
\mathfrak L_{A,B}(t)
=
\sum_{k\ge1}c_k^*t^k,
\]

with

\[
\boxed{
c_k^*
=
\frac{2^{k-1}}{k}
\frac{B^{k-1}}{A^{k-2}}.
}
\tag{6.1}
\]

Let

\[
S_m=\frac{B^{m-1}}{A^{m-2}}.
\]

For fixed \(m\), the next log coefficient satisfies

\[
\frac{c_{m+1}^*}{S_m}
=
\frac{2^m}{m+1}\frac BA
\to0.
\tag{6.2}
\]

On a fixed compact \(|t|\le R\), the whole Taylor tail after degree \(m\) is
therefore

\[
\boxed{o(S_m)}
\tag{6.3}
\]

uniformly.

Assume

\[
F_n(t)
=
A_nt+B_nt^2
+
\sum_{k=3}^m c_{k,n}t^k
+
r_n(t),
\tag{6.4}
\]

with

\[
S_{m,n}\to\infty,
\qquad
\frac{\|r_n\|_\infty}{S_{m,n}}\to0,
\]

and suppose the normalized coefficient deviations converge:

\[
\boxed{
\frac{c_{k,n}-c_{k,n}^*}{S_{m,n}}
\to\delta_k,
\qquad
3\le k\le m.
}
\tag{6.5}
\]

Then

\[
F_n-\mathfrak L_{A_n,B_n}
=
S_{m,n}
\left(
\sum_{k=3}^m\delta_kt^k

ight)
+o(S_{m,n}).
\tag{6.6}
\]

If any \(\delta_k\neq0\), the limiting residual is a nonzero polynomial with
no terms below degree \(3\), hence is not quadratic.  Theorem 5.1 forces
squares.

Thus:

> **Theorem 6.1 — fixed-order visible-jet rigidity.**  
> For every fixed \(m\ge3\), whenever
> \[
> S_{m,n}=B_n^{m-1}/A_n^{m-2}\to\infty,
> \]
> a square-free tail with an \(o(S_{m,n})\)-controlled degree-\(m\) expansion
> must satisfy
> \[
> \boxed{
> c_{k,n}-c_{k,n}^*=o(S_{m,n}),
> \qquad 3\le k\le m,
> }
> \]
> along every subsequence on which the normalized deviations have finite
> limits.

This is an all-orders theorem in the usual fixed-order sense.  It does not
claim uniform control when \(m=m_n\to\infty\).

---

# 7. Genuine fourth-scale theorem

Take \(m=4\) and

\[
\boxed{
S_4=\frac{B^3}{A^2}\to\infty.
}
\tag{7.1}
\]

Write

\[
F_n(t)
=
A_nt+B_nt^2+C_nt^3+D_nt^4+r_n(t),
\]

with

\[
\|r_n\|_\infty=o(S_{4,n}).
\]

Suppose

\[
\frac{
C_n-\frac{4B_n^2}{3A_n}
}{S_{4,n}}
\to\gamma,
\tag{7.2}
\]

and

\[
\frac{D_n}{S_{4,n}}
\to d.
\tag{7.3}
\]

After subtracting the exact shifted log,

\[
\frac{F_n-\mathfrak L_{A_n,B_n}}{S_{4,n}}
\to
\gamma t^3+(d-2)t^4.
\tag{7.4}
\]

This is quadratic only when

\[
\gamma=0,
\qquad
d=2.
\]

Therefore:

> **Corollary 7.1 — fourth-scale capture.**  
> If \(S_{4,n}\to\infty\), then every finite nonzero fourth-scale deviation
> from the shifted-log cubic/quartic block forces squares.  A square-free tail
> must satisfy
> \[
> \boxed{
> C_n
> =
> \frac{4B_n^2}{3A_n}
> +o\!\left(\frac{B_n^3}{A_n^2}\right)
> }
> \]
> and
> \[
> \boxed{
> D_n
> =
> 2\frac{B_n^3}{A_n^2}
> +o\!\left(\frac{B_n^3}{A_n^2}\right).
> }
> \]

This is the theorem-level upgrade of v151 equation (0.18).

---

# 8. Fifth and higher visible scales

At degree five the shifted-log coefficient is

\[
\boxed{
c_5^*
=\frac{16}{5}\frac{B^4}{A^3}.
}
\]

Thus if

\[
\frac{B^4}{A^3}\to\infty
\]

and the expansion is controlled to this scale, square-freeness requires not
only the cubic and quartic matches at absolute \(o(B^4/A^3)\) precision, but
also

\[
\boxed{
c_5
=\frac{16}{5}\frac{B^4}{A^3}
+o\!\left(\frac{B^4}{A^3}\right).
}
\]

The same statement holds at every fixed degree \(m\).

This removes the need to construct a separate quartic, quintic, sextic, ...
phase surface whenever the residual can be compared directly with the exact
moving logarithm.

---

# 9. Formal all-order coefficient explanation from reciprocal slope

The reciprocal-slope identity gives an independent algebraic explanation of
(6.1).

Suppose the coefficients through degree \(m-1\) equal the shifted-log values,
and write

\[
c_m=d\frac{B^{m-1}}{A^{m-2}}.
\]

Then the reciprocal slope has expansion

\[
\boxed{
\frac1{f'(t)}
=
\frac1A
-
\frac{2B}{A^2}t
-
\frac{m(c_m-c_m^*)}{A^2}t^{m-1}
+O(t^m),
}
\tag{9.1}
\]

with all powers \(t^2,\ldots,t^{m-2}\) absent.

Thus the first failure of the shifted-log coefficient is exactly the first
failure of \(1/f'\) to remain affine.

Let

\[
P_j(a,b,v)
=
u_1^j+u_3^j-u_0^j-u_2^j.
\tag{9.2}
\]

Then, on fixed compact parameter boxes as \(B/A\to0\),

\[
\boxed{
\det DH_f
=
-2mA^2(c_m-c_m^*)P_{m-1}(a,b,v)
+o\!\left(A^2S_m\right).
}
\tag{9.3}
\]

The polynomial \(P_{m-1}\) is not identically zero for \(m\ge3\).

For \(m=4\),

\[
P_3=-6v(a^2-b^2),
\]

so (9.3) becomes

\[
\det DH_f
=
48(d-2)B^3v(a^2-b^2)
+o(B^3),
\]

exactly reproducing the v151 quartic audit.

The determinant calculation and the moving-log degree theorem therefore point
to the same coefficient sequence for different reasons.

---

# 10. Conceptual compression of v149--v152

The exceptional story can now be stated in one line:

\[
\boxed{
\text{the square-map loses rank exactly when reciprocal slope is affine.}
}
\]

The two exact families are:

- constant reciprocal slope \(\Rightarrow\) affine profile;
- nonconstant affine reciprocal slope \(\Rightarrow\) shifted logarithm.

The affine exceptional tower is simply the expansion at a pole moving to
infinity:

\[
\frac1{f'}
=
\frac1A
\left(1-\frac{2B}{A}t\right).
\]

Consequently the coefficients

\[
A,
\quad
B,
\quad
\frac{4B^2}{3A},
\quad
\frac{2B^3}{A^2},
\quad
\frac{16B^4}{5A^3},
\ldots
\]

are not a sequence of accidental cancellations.  They are the unique Taylor
coefficients compatible with the exact requirement that \(1/f'\) be affine.

The moving-log flattening then shows that any phase-visible failure of this
resummed structure restores the missing degree direction.

---

# 11. Exact nested-window renormalization law inside the log family

The reciprocal-slope coordinate also simplifies the pole-dynamics problem.

Let

\[
\mathfrak L_{A,B}(t)
=-\frac{A^2}{2B}\log\!\left(1-\frac{2B}{A}t\right),
\]

and write

\[
M=\frac{A^2}{2B},
\qquad
b=\frac{A}{2B}.
\tag{11.1}
\]

Then

\[
\mathfrak L_{A,B}'(t)=\frac{M}{b-t},
\qquad
\frac1{\mathfrak L_{A,B}'(t)}=\frac{b-t}{M}.
\tag{11.2}
\]

Now pass to a nested affine window

\[
t=t_0+\delta s,
\qquad
\delta>0,
\]

and subtract the irrelevant value at the new origin:

\[
\widetilde{\mathfrak L}(s)
=\mathfrak L_{A,B}(t_0+\delta s)-\mathfrak L_{A,B}(t_0).
\]

This is **exactly** another member of the same normalized family,

\[
\boxed{
\widetilde{\mathfrak L}(s)
=\mathfrak L_{A',B'}(s),
}
\tag{11.3}
\]

with

\[
\boxed{
A'
=\frac{\delta A}{1-(2B/A)t_0},
}
\tag{11.4}
\]

and

\[
\boxed{
B'
=\frac{\delta^2B}{[1-(2B/A)t_0]^2}.
}
\tag{11.5}
\]

Two consequences are exact:

\[
\boxed{
M'=\frac{A'^2}{2B'}=\frac{A^2}{2B}=M,
}
\tag{11.6}
\]

while

\[
\boxed{
b'=\frac{A'}{2B'}=\frac{b-t_0}{\delta}.}
\tag{11.7}
\]

Thus the logarithmic coefficient \(M\) is a true renormalization invariant
under horizontal nested-window zooms.  The pole does not undergo arbitrary
dynamics inside the exact family; it moves only by the coordinate change.

Equivalently, if

\[
r(t)=\frac1{\mathfrak L'(t)}=\alpha+\beta t,
\]

then under the same zoom

\[
\widetilde r(s)
=\frac{1}{\widetilde{\mathfrak L}'(s)}
=\frac{\alpha+\beta t_0}{\delta}+\beta s.
\tag{11.8}
\]

Therefore

\[
\boxed{\beta=-1/M}
\]

is exactly invariant.  Only the affine intercept changes.

This sharpens the next target: after transporting fitted reciprocal-slope
lines into a common coordinate system, any significant change in their slope
\(\beta\) is **genuine non-logarithmic drift**, not a harmless consequence of
window re-centering or rescaling.

---

# 12. What v152 closes

Relative to the v151 target list, v152 closes the following fixed-order
problem.

### Closed: quartic logarithmic coefficient under visible-scale control

The coefficient

\[
2\frac{B^3}{A^2}
\]

is now enforced by the same lattice-degree mechanism, not only by a Jacobian
audit.

### Closed: separate higher-order flattenings for fixed polynomial jets

For every fixed \(m\), one may subtract the exact shifted logarithm and use a
single exact surface flattening.  No new order-specific phase surface is
needed.

### Closed: algebraic uniqueness of the full formal logarithmic jet

The reciprocal-slope identity implies that formal rank loss with prescribed
linear/quadratic data uniquely reconstructs the shifted logarithm.

---

# 13. What remains open

The remaining difficulties are more structural.

### I. Visible-scale termination

The scales

\[
S_m=\frac{B^{m-1}}{A^{m-2}}
\]

shrink by the factor \(B/A\).  For a given sequence, they may become \(O(1)\)
before a profile mismatch is visible.  The nearest-lattice argument then
loses density in the residual coordinate.

### II. Genuine moving-pole dynamics

A tail may remain close to an exact shifted logarithm on every visible scale,
while the fitted coefficient and pole change between nested windows.

v152 treats a moving pole **inside one window normalization** exactly, but it
does not yet prove coherence or rigidity of the fitted pole across different
nested windows.

### III. No stable residual profile

The normalized difference

\[
\frac{F_n-\mathfrak L_{A_n,B_n}}{S_n}
\]

may fail to converge in a useful topology even when \(S_n\to\infty\).

### IV. Bounded-mass packets

Angular complexity may still be distributed among infinitely many packets
whose individual phase amplitudes never diverge.

None of these issues is resolved by the fixed-order jet theorem.

---

# 14. Recommended v153 target

The best next target is now **nested-window parameter coherence**, not a fifth
order calculation.

Write the fitted moving logarithm on a window as

\[
\mathfrak L_n(t)
=
-\frac{A_n^2}{2B_n}
\log\!\left(1-\frac{2B_n}{A_n}t\right)
+c_n.
\]

Its pole is

\[
b_n=\frac{A_n}{2B_n}.
\]

On two overlapping nested windows, derive a quantitative identifiability
lemma of the form:

> if two shifted logarithms agree to error \(o(S)\) on an interval and the
> relevant phase scale \(S\to\infty\), then their reciprocal-slope affine
> functions agree to a correspondingly small error.

Because

\[
\frac1{\mathfrak L_n'(t)}
=
\frac1{A_n}-\frac{2B_n}{A_n^2}t,
\]

this becomes a finite-dimensional stability problem for two affine functions,
which is substantially simpler than comparing logarithms directly.

This suggests using **reciprocal slope as the renormalization coordinate**.
If successful, it could turn moving-pole dynamics into an affine parameter
cocycle and may provide the missing nested-window rigidity.

A secondary target is a compactness theorem for normalized reciprocal-slope
defects, which could address the no-stable-profile branch in the same
coordinate system.

---

# 15. Claim boundary

## Established in v152

- exact reciprocal-slope factorization of the raw three-phase Jacobian;
- exact derivation of affine / shifted-log rank loss from reciprocal-slope
  additivity, under nonvanishing slope;
- exact moving shifted-log phase surface
  \[
  1+e^{-H_2}-e^{-H_1}-e^{-H_3}=0;
  \]
- one-shot nonlinear flattening of that surface while the pole tends to
  infinity;
- transformed phase-lattice density with errors
  \[
  O(A_n^{-1})+O(S_n^{-1});
  \]
- moving-log residual square forcing for every nonquadratic \(C^1\) residual
  profile;
- fixed-order visible logarithmic jet rigidity for every \(m\ge3\);
- theorem-level fourth-scale forcing of both the refined cubic match and the
  quartic coefficient \(2B^3/A^2\);
- formal all-order uniqueness of the logarithmic coefficient sequence;
- recovery of the v151 quartic determinant coefficient from the general
  reciprocal-slope defect formula.
- exact nested-window renormalization law for the shifted-log family:
  \(M=A^2/(2B)\) is invariant and \(b\mapsto(b-t_0)/\delta\).

## Inherited and used

- v149 shrinking-window square coordinates and local phase-lattice Brouwer
  capture;
- v150 classification that the affine residual normal functional is singular
  everywhere exactly for quadratic profiles;
- v151 cubic resonance and quadratic-surface flattening, used as consistency
  checks and as the previous frontier.

## Not established

- a theorem when the first non-logarithmic mismatch occurs only at a bounded
  phase scale;
- uniform all-orders control with depth \(m=m_n\to\infty\);
- rigidity/coherence of fitted shifted-log parameters across nested windows;
- compactness of arbitrary normalized residual packets;
- bounded-mass packet accumulation;
- universal square existence;
- the Toeplitz square-peg conjecture.

The frontier has moved from **higher polynomial resonance coefficients** to
**reciprocal-slope parameter coherence and phase-visible depth**.
