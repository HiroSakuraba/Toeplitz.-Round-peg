# Project Handoff v153: Stable Nested-Window Coherence of Shifted-Log Fits

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v152 replaced the order-by-order affine/quadratic/cubic resonance tower by one
exact shifted logarithm and identified reciprocal slope

\[
r(t)=\frac1{f'(t)}
\]

as the structural coordinate.  Exact square-map rank loss occurs precisely
when `r` is affine.  Inside the shifted-log family, the slope of that affine
line is invariant under horizontal re-centering and zooming.

The open question left by v152 was whether independently fitted shifted logs
on nested windows could drift incoherently even though every visible fixed
order remains logarithmic.

v153 proves a quantitative **overlap-coherence theorem**.  The main point is
that this is a finite-dimensional problem that can be solved using function
values alone; no derivative control of the original curve is required.

Write a shifted log in reciprocal-slope coordinates as

\[
\boxed{
L_{\alpha,\beta}(t)
=
\begin{cases}
\displaystyle
\frac1\beta\log\frac{\alpha+\beta t}{\alpha},&\beta\ne0,\\[1.2ex]
\displaystyle
\frac{t}{\alpha},&\beta=0,
\end{cases}
}
\tag{0.1}
\]

so that

\[
\boxed{
L'_{\alpha,\beta}(t)=\frac1{\alpha+\beta t},
\qquad
r(t)=\alpha+\beta t.
}
\tag{0.2}
\]

For the v152 normalization

\[
\mathfrak L_{A,B}(t)
=-\frac{A^2}{2B}\log\left(1-\frac{2B}{A}t\right),
\]

we have

\[
\boxed{
\alpha=\frac1A,
\qquad
\beta=-\frac{2B}{A^2}=-\frac1M.
}
\tag{0.3}
\]

The new results are:

1. **Exact three-contact identifiability.**  Two shifted logs that agree up to
   one additive constant at three distinct points are the same shifted log.
   Equivalently, their reciprocal-slope affine lines coincide exactly.

2. **Stable overlap rigidity.**  If two shifted logs differ by at most
   \(\varepsilon\), up to an additive constant, on \([-R,R]\), then their
   reciprocal-slope lines differ by an explicitly controlled amount.  If
   \(\bar r_i=\max_{[-R,R]}|r_i|\), then

   \[
   \boxed{
   |\beta_2-\beta_1|
   \le
   \frac{8\varepsilon\,\bar r_1\bar r_2}{R^2},
   }
   \tag{0.4}
   \]

   \[
   \boxed{
   |\alpha_2-\alpha_1|
   \le
   \frac{12\varepsilon\,\bar r_1\bar r_2}{R},
   }
   \tag{0.5}
   \]

   and

   \[
   \boxed{
   \sup_{|t|\le R}|r_2(t)-r_1(t)|
   \le
   \frac{20\varepsilon\,\bar r_1\bar r_2}{R}.
   }
   \tag{0.6}
   \]

3. **Near-affine phase-scaled form.**  If

   \[
   |\beta_i|R\le\theta\alpha_i,
   \qquad 0\le\theta<1,
   \]

   and \(A_i=1/\alpha_i\), then

   \[
   \boxed{
   |A_2-A_1|
   \le
   \frac{12(1+\theta)^2}{R}\,\varepsilon,
   }
   \tag{0.7}
   \]

   and

   \[
   \boxed{
   A_1A_2|\beta_2-\beta_1|
   \le
   \frac{8(1+\theta)^2}{R^2}\,\varepsilon.
   }
   \tag{0.8}
   \]

   Thus phase-visible reciprocal-slope drift costs phase error of the same
   order.

4. **Nested-window coherence.**  Re-express a parent fit on the child
   coordinate \(t=t_0+\delta s\).  Its reciprocal line becomes

   \[
   \boxed{
   r_{p\to c}(s)
   =
   \frac{\alpha_p+\beta_p t_0}{\delta}
   +\beta_p s.
   }
   \tag{0.9}
   \]

   Therefore \(\beta_p\) is exactly invariant.  If the parent and child fits
   approximate the same phase function on the child overlap with total error
   \(\varepsilon\), then (0.4)--(0.8) apply directly to
   \(r_{p\to c}\) and the child reciprocal line.

5. **No independent visible pole-drift obstruction.**  Suppose on a fixed
   child profile interval both fits have errors \(o(S_n)\), with
   \(S_n\to\infty\) and \(S_n/A_n\to0\).  Then

   \[
   A_{c,n}-A_{p\to c,n}=o(S_n)
   \]

   and, when the two amplitudes are asymptotic,

   \[
   \boxed{
   A_n^2(\beta_{c,n}-\beta_{p,n})=o(S_n).
   }
   \tag{0.10}
   \]

   Hence a genuinely phase-visible change in the renormalization invariant
   \(\beta=-1/M\) cannot occur while both overlapping shifted-log models are
   simultaneously accurate at that phase scale.

This removes most of v152's “moving pole dynamics” as a separate smooth
obstruction.  Significant fitted-log drift can only appear when an older fit
has already lost accuracy at the new visible scale, when the relevant phase
amplitude has become bounded, or when there is no compact residual profile.
The frontier therefore compresses toward **visible-depth termination / loss
of profile compactness / bounded-mass packets**.

---

# 1. Reciprocal-slope coordinates are the stable parameters

The v152 shifted logarithm is

\[
\mathfrak L_{A,B}(t)
=-M\log(1-t/b),
\]

with

\[
M=\frac{A^2}{2B},
\qquad
b=\frac{A}{2B}.
\]

Its derivative is

\[
\mathfrak L'_{A,B}(t)=\frac{M}{b-t},
\]

so

\[
\frac1{\mathfrak L'_{A,B}(t)}
=\frac{b-t}{M}
=\frac1A-\frac{2B}{A^2}t.
\]

Thus

\[
\alpha=\frac1A,
\qquad
\beta=-\frac{2B}{A^2}=-\frac1M.
\]

The pole itself is

\[
b=-\frac{\alpha}{\beta}.
\]

This is an ill-conditioned coordinate near the affine limit \(\beta=0\).
A tiny change in \(\beta\) can produce a macroscopic change in \(b\) while
changing the phase function only slightly on a fixed compact interval.

For example,

\[
\alpha=10^{-6},
\qquad
\beta_1=-10^{-12},
\qquad
\beta_2=-1.001\times10^{-12}
\]

moves the pole by more than \(900\), while the two normalized logs differ by
less than \(10^{-3}\) on \([-1,1]\) after optimizing the additive constant.

Therefore the correct coherence variable is not the raw pole \(b\).  It is

\[
\boxed{\beta=-1/M,}
\]

the slope of the reciprocal-slope affine line.  This is also the exact
nested-window invariant found in v152.

---

# 2. Exact three-contact identifiability

Let

\[
r_i(t)=\alpha_i+\beta_i t,
\qquad
L_i'(t)=\frac1{r_i(t)},
\]

with no zero of \(r_i\) on the interval of interest.

Set

\[
h=L_1-L_2.
\]

Then exactly

\[
\boxed{
h'(t)
=
\frac1{r_1(t)}-\frac1{r_2(t)}
=
\frac{r_2(t)-r_1(t)}{r_1(t)r_2(t)}.
}
\tag{2.1}
\]

The numerator

\[
r_2-r_1
=(\alpha_2-\alpha_1)+(\beta_2-\beta_1)t
\]

is affine.

Suppose there is a constant \(c\) and three distinct points

\[
t_1<t_2<t_3
\]

such that

\[
L_1(t_j)-L_2(t_j)=c,
\qquad j=1,2,3.
\]

Then \(h-c\) has three zeros.  Rolle's theorem gives at least two distinct
zeros of \(h'\).  By (2.1), the affine numerator \(r_2-r_1\) has at least two
zeros.  Therefore

\[
r_1\equiv r_2.
\]

Hence

\[
L_1-L_2\equiv c.
\]

So:

> **Theorem 2.1 — exact three-contact rigidity.**  A shifted logarithm is
> determined up to an additive phase constant by its values at any three
> distinct points, provided the pole is outside the interval.

This is the exact finite-dimensional identifiability statement needed for
nested-window comparisons.

---

# 3. Stable overlap-coherence lemma

Exact equality is not what the square-peg blow-up gives; the fits agree only
to a small phase error.  The exact derivative factorization above makes the
stable theorem elementary.

Let

\[
I=[-R,R],
\qquad R>0,
\]

and assume \(r_1,r_2\) have no zeros on \(I\).  Suppose there is a constant
\(c\) such that

\[
\boxed{
\|L_1-L_2-c\|_{L^\infty(I)}\le\varepsilon.
}
\tag{3.1}
\]

Define

\[
d(t)=r_2(t)-r_1(t)=d_0+d_1t
\]

and

\[
w(t)=\frac1{|r_1(t)r_2(t)|}.
\]

The sign of \(r_1r_2\) is constant on \(I\), so after multiplying by that
fixed sign we may write

\[
h'(t)=d(t)w(t)
\]

with \(w>0\).

Take the separated half-intervals

\[
J_-=[-R,-R/2],
\qquad
J_+=[R/2,R].
\]

Set

\[
W_\pm=\int_{J_\pm}w(t)\,dt,
\qquad
\mu_\pm=\frac1{W_\pm}\int_{J_\pm}t w(t)\,dt.
\]

Because \(w>0\),

\[
\mu_-\in[-R,-R/2],
\qquad
\mu_+\in[R/2,R],
\]

and therefore

\[
\boxed{\mu_+-\mu_-\ge R.}
\tag{3.2}
\]

Also, from (3.1), the phase increment of \(h\) across either half-interval is
bounded by \(2\varepsilon\).  Thus

\[
\left|d_0+d_1\mu_\pm\right|
\le
\frac{2\varepsilon}{W_\pm}.
\tag{3.3}
\]

Let

\[
\bar r_i=\max_{|t|\le R}|r_i(t)|.
\]

Then

\[
w(t)\ge\frac1{\bar r_1\bar r_2},
\]

so

\[
\boxed{
W_\pm
\ge
\frac{R}{2\bar r_1\bar r_2}.
}
\tag{3.4}
\]

Subtracting the two equations in (3.3), using (3.2)--(3.4), gives

\[
\boxed{
|d_1|
=|\beta_2-\beta_1|
\le
\frac{8\varepsilon\bar r_1\bar r_2}{R^2}.
}
\tag{3.5}
\]

Using one of (3.3) and \(|\mu_\pm|\le R\) then gives

\[
\boxed{
|d_0|
=|\alpha_2-\alpha_1|
\le
\frac{12\varepsilon\bar r_1\bar r_2}{R}.
}
\tag{3.6}
\]

Finally,

\[
\sup_I|d|
\le |d_0|+R|d_1|,
\]

hence

\[
\boxed{
\sup_{|t|\le R}|r_2(t)-r_1(t)|
\le
\frac{20\varepsilon\bar r_1\bar r_2}{R}.
}
\tag{3.7}
\]

Therefore:

> **Theorem 3.1 — stable reciprocal-line coherence.**  Uniform phase
> agreement of two shifted logs on an interval quantitatively controls the
> entire difference of their reciprocal-slope affine lines.  The estimate
> uses only value agreement of the two models.

The constants are not optimized.  Their role is to make the phase-scale
relationship explicit.

---

# 4. Near-affine form relevant to v152

In the moving-pole regime the reciprocal lines are nearly constant on a fixed
profile interval.  Assume

\[
|\beta_i|R\le\theta\alpha_i,
\qquad 0\le\theta<1,
\tag{4.1}
\]

with \(\alpha_i>0\), and define

\[
A_i=\frac1{\alpha_i}.
\]

Then

\[
\bar r_i\le(1+\theta)\alpha_i
=\frac{1+\theta}{A_i}.
\tag{4.2}
\]

Substitution in (3.5) gives

\[
\boxed{
A_1A_2|\beta_2-\beta_1|
\le
\frac{8(1+\theta)^2}{R^2}\varepsilon.
}
\tag{4.3}
\]

Equation (3.6) gives

\[
|\alpha_2-\alpha_1|
\le
\frac{12(1+\theta)^2}{A_1A_2R}\varepsilon.
\]

Since

\[
|A_2-A_1|
=A_1A_2|\alpha_2-\alpha_1|,
\]

we obtain

\[
\boxed{
|A_2-A_1|
\le
\frac{12(1+\theta)^2}{R}\varepsilon.
}
\tag{4.4}
\]

The contrapositive is especially useful:

\[
\boxed{
\inf_c\|L_1-L_2-c\|_\infty
\ge
\frac{R^2}{8(1+\theta)^2}
A_1A_2|\beta_2-\beta_1|.
}
\tag{4.5}
\]

Thus an invariant-slope drift of phase-scaled size \(S\), meaning

\[
A_1A_2|\Delta\beta|\asymp S,
\]

forces an \(\Omega(S)\) disagreement of the two log models on a fixed
profile interval.

This is exactly the scale needed in the v152 nearest-lattice argument.

---

# 5. Exact parent-to-child transport

Let a parent shifted-log fit be written in reciprocal coordinates as

\[
r_p(t)=\alpha_p+\beta_pt.
\]

Take a nested window

\[
t=t_0+\delta s,
\qquad \delta>0,
\]

and subtract the irrelevant phase value at \(t_0\):

\[
\widetilde L_p(s)
=L_p(t_0+\delta s)-L_p(t_0).
\]

Then

\[
\widetilde L_p'(s)
=\delta L_p'(t_0+\delta s),
\]

so its reciprocal slope is

\[
\boxed{
\widetilde r_p(s)
=\frac{1}{\widetilde L_p'(s)}
=\frac{\alpha_p+\beta_pt_0}{\delta}
+\beta_ps.
}
\tag{5.1}
\]

Therefore

\[
\boxed{
\widetilde\alpha_p
=\frac{\alpha_p+\beta_pt_0}{\delta},
\qquad
\widetilde\beta_p=\beta_p.
}
\tag{5.2}
\]

This is the v152 renormalization law in its simplest form.

If

\[
A_{p\to c}
=\frac1{\widetilde\alpha_p},
\]

then

\[
\boxed{
A_{p\to c}
=\frac{\delta}{\alpha_p+\beta_pt_0}.
}
\tag{5.3}
\]

In the \((A,B)\) notation this is exactly

\[
A'
=\frac{\delta A}{1-(2B/A)t_0}.
\]

The key point is that \(\beta=-1/M\) does not change under the zoom.

---

# 6. Nested-window overlap theorem

Let \(F\) be the actual phase function on the parent interval.  Suppose the
parent model satisfies

\[
\|F-L_p-c_p\|\le e_p
\]

on a region containing the child window.

Define the child-coordinate phase

\[
\widetilde F(s)
=F(t_0+\delta s)-F(t_0).
\]

Suppose a child shifted-log fit satisfies

\[
\|\widetilde F-L_c\|_{[-R,R]}\le e_c.
\]

The re-expressed parent model is

\[
\widetilde L_p(s)
=L_p(t_0+\delta s)-L_p(t_0).
\]

Then

\[
\widetilde L_p(s)-L_c(s)
=
-[F-L_p-c_p](t_0+\delta s)
+[F-L_p-c_p](t_0)
+[\widetilde F(s)-L_c(s)].
\]

Therefore

\[
\boxed{
\|\widetilde L_p-L_c\|_{[-R,R]}
\le
2e_p+e_c.
}
\tag{6.1}
\]

No derivative estimate on \(F\) has been used.

Set

\[
\varepsilon=2e_p+e_c.
\]

Applying Theorem 3.1 to the parent and child models in the **same child
coordinate** gives:

> **Theorem 6.1 — nested shifted-log coherence.**  On every fixed child
> overlap interval, the transported parent reciprocal line and the child
> reciprocal line obey (3.5)--(3.7) with total phase error
> \(\varepsilon=2e_p+e_c\).  In particular, in the near-affine regime,
> \[
> |A_c-A_{p\to c}|
> \le
> \frac{12(1+\theta)^2}{R}(2e_p+e_c),
> \]
> and
> \[
> A_cA_{p\to c}|\beta_c-\beta_p|
> \le
> \frac{8(1+\theta)^2}{R^2}(2e_p+e_c).
> \]

This is the quantitative identifiability lemma requested at the end of v152.

---

# 7. Phase-visible coherence corollary

Suppose along a nested sequence there is a diverging phase scale

\[
S_n\to\infty
\]

such that

\[
e_{p,n}=o(S_n),
\qquad
e_{c,n}=o(S_n).
\tag{7.1}
\]

Assume also that the transported parent and child amplitudes satisfy

\[
\frac{S_n}{A_{p\to c,n}}\to0,
\qquad
\frac{S_n}{A_{c,n}}\to0,
\tag{7.2}
\]

and that both logs are uniformly near-affine on the fixed child profile
interval.

Then Theorem 6.1 gives

\[
\boxed{
A_{c,n}-A_{p\to c,n}=o(S_n).
}
\tag{7.3}
\]

Since \(S_n=o(A_{p\to c,n})\) and \(S_n=o(A_{c,n})\), this implies

\[
\boxed{
\frac{A_{c,n}}{A_{p\to c,n}}\to1.
}
\tag{7.4}
\]

The invariant-slope estimate becomes

\[
A_{c,n}A_{p\to c,n}
|\beta_{c,n}-\beta_{p,n}|
=o(S_n).
\tag{7.5}
\]

Using (7.4), either amplitude may be used in the prefactor:

\[
\boxed{
A_n^2(\beta_{c,n}-\beta_{p,n})=o(S_n).
}
\tag{7.6}
\]

Thus there is no phase-visible \(\beta\)-drift while both models remain
accurate at the same diverging scale.

This is stronger than saying the parameters have finite limits.  It says the
entire possible drift is smaller than the phase scale that the lattice-degree
argument can resolve.

---

# 8. Moving-pole dynamics is not an independent visible obstruction

v152 listed “genuinely moving shifted-log parameters across nested windows” as
one of the remaining branches.

Theorem 7.1 substantially reduces that branch.

Suppose a child fit has a phase-visible invariant-slope discrepancy

\[
A_cA_{p\to c}|\beta_c-\beta_p|
\ge cS
\]

for some fixed \(c>0\).  Then by (4.5), the two shifted logs themselves must
differ by \(\Omega(S)\) on the child profile interval.

But if they are both approximations to the same phase function, (6.1) says
that this is impossible unless

\[
2e_p+e_c\gtrsim S.
\]

Therefore:

\[
\boxed{
\text{phase-visible parameter drift}
\Longrightarrow
\text{loss of common }o(S)\text{ approximation}.
}
\tag{8.1}
\]

So the drift cannot remain hidden inside a coherent visible log tower.

The obstruction has moved.  If an older log fit and a deeper log fit appear
to have incompatible invariant slopes, then the older approximation has
already failed at the deeper scale.  The next object to study is the residual
created at that **first failure scale**.

This means that v152's issues I and II are not independent in the profile
regime:

- visible-depth termination, and
- moving-log parameter drift

meet at the same stopping scale.

---

# 9. Direct ancestor-descendant comparison prevents accumulated drift

A possible concern is that each parent-child drift could be tiny but a long
chain of tiny drifts could accumulate into a large change in \(\beta\).

The overlap theorem does not require step-by-step comparison.

If an ancestor log model remains accurate on a descendant window at the
phase scale relevant to that descendant, transport the ancestor model
**directly** into the descendant coordinate and apply Theorem 6.1 there.
The exact zoom law preserves the ancestor \(\beta\) through any number of
intermediate re-centerings.

Therefore a long chain cannot accumulate phase-visible invariant-slope drift
while the ancestor approximation remains phase-accurate at the descendant
scale.

Accumulation becomes possible only after ancestor accuracy has degraded to
the descendant's visible scale.  Again, that is a stopping-scale failure,
not an independent cocycle pathology.

---

# 10. Relationship to the v150 tangent-space obstruction

v150 found that around a fixed shifted logarithm the entire invisible
second-scale space is

\[
\operatorname{span}
\{1,\log|t-b|,(t-b)^{-1}\}.
\]

These directions are exactly infinitesimal changes of:

- phase offset,
- logarithmic coefficient,
- pole position.

v152 resummed those tangent directions into the full moving-log family.

v153 adds the missing compatibility statement: when two such resummed models
are fitted to the **same data on an overlap**, their tangent parameters cannot
wander freely.  Their reciprocal-slope affine lines are quantitatively tied
together by the phase error.

The sequence v150--v153 can therefore be compressed as:

\[
\boxed{
\begin{array}{c}
\text{local invisible directions}\\
\downarrow\\
\text{exact shifted-log manifold}\\
\downarrow\\
\text{stable overlap coherence of that manifold.}
\end{array}
}
\]

---

# 11. What v153 closes

### Closed: exact identifiability of overlapping shifted logs

Three exact phase contacts determine the reciprocal-slope affine line.

### Closed: quantitative stability of the fit parameters

Uniform phase agreement gives explicit control of \(\alpha\), \(\beta\), and
of the whole reciprocal line.

### Closed: visible invariant-slope drift under common overlap control

If parent and child fits are both \(o(S)\)-accurate on a fixed child profile
interval with \(S\to\infty\), their \(\beta=-1/M\) drift is itself
sub-visible.

### Closed: accumulation while an ancestor remains accurate

Ancestor and descendant can be compared directly.  Tiny intermediate drifts
cannot accumulate into a visible discrepancy without loss of ancestor
accuracy at the descendant scale.

### Reframed: raw pole motion

The pole \(b\) is ill-conditioned near the affine limit.  Absolute pole
coherence is neither stable nor necessary.  The correct invariant is the
reciprocal-line slope \(\beta=-1/M\).

---

# 12. What remains open

The remaining obstruction is now concentrated in the **first scale at which
common shifted-log accuracy fails**.

### I. First-failure residual compactness

Let an ancestor log fit be accurate above scale \(S\), but cease to be
\(o(S)\)-accurate on a deeper window.  The normalized residual has nontrivial
size there, but may fail to converge to a useful \(C^1\) or even continuous
profile after rescaling.

If a nonquadratic profile does emerge, v152 forces squares immediately.
The unresolved case is loss of compactness.

### II. Concentration into narrower packets

The first-failure residual may concentrate on a still narrower subwindow.
If that subwindow has diverging angular mass, the extraction process should
recurse.  A rigorous stopping-time/concentration theorem has not yet been
proved.

### III. Bounded-mass terminal packets

The recursion may terminate only when every remaining packet carries
\(O(1)\) phase mass.  The lattice in the residual coordinate is then no
longer asymptotically dense.  This remains a genuine obstruction.

### IV. General Jordan transfer

As throughout v149--v152, the radial/profile statements still need the
inherited four-contact backtracking hypotheses when transferred to an
arbitrary Jordan boundary.

---

# 13. Recommended v154 target

The next target should be a **first-failure stopping-time / concentration-
compactness theorem**, not another parameter calculation.

A useful formulation is:

1. choose the deepest nested window on which one transported shifted-log fit
   remains \(o(S)\)-accurate at the current diverging visible scale;
2. stop at the first child scale where the normalized residual has order one;
3. prove a trichotomy for that normalized residual:

   - **compact profile:** extract a nonquadratic limit and apply v152;
   - **concentration:** locate a narrower packet whose angular mass still
     diverges and restart the shrinking-window extraction there;
   - **vanishing/bounded packets:** isolate the true bounded-mass terminal
     obstruction.

The analogy is concentration compactness, but the quantity to track is phase
mass across logarithmic-radius windows rather than an \(L^p\) norm.

A particularly useful invariant would be a subadditive “visible phase mass”
that survives recentering and controls the transformed lattice mesh.  If such
an invariant can be made to satisfy a compactness-or-concentration dichotomy,
then the present proof program would have reduced the general square-peg
problem to the bounded-mass terminal branch.

---

# 14. Verification

`code/verify_v153.py` checks:

1. the reciprocal-slope parameterization of the shifted log;
2. exact invariance of \(\beta\) under nested affine zooms;
3. the affine-numerator factorization of the derivative of two-log
   differences;
4. the quantitative coherence bounds on 3000 randomized log pairs;
5. the near-affine \(A\)/\(\beta\) corollary on 1000 randomized pairs;
6. the parent-to-child coordinate transport identity;
7. a numerical example showing why the raw pole is ill-conditioned.

All checks pass.

---

# 15. Claim boundary

## Established in v153

- exact three-contact identifiability of shifted logarithms up to additive
  phase constant;
- explicit stable bounds (3.5)--(3.7) for reciprocal-line drift from uniform
  phase overlap error;
- near-affine phase-scaled bounds (4.3)--(4.4);
- exact parent-to-child reciprocal-line transport;
- quantitative nested-window coherence using only function-value error;
- phase-visible rigidity of the invariant \(\beta=-1/M\) under common
  \(o(S)\) overlap control;
- direct ancestor-descendant comparison, ruling out accumulated visible drift
  while ancestor accuracy persists;
- identification of raw pole location as an ill-conditioned, noncanonical
  coherence variable near the affine limit.

## Inherited and used

- v149 shrinking-window square coordinates and phase-lattice Brouwer capture;
- v150 shifted-log tangent-space classification;
- v151 cubic/quartic resonance calculations;
- v152 exact reciprocal-slope Jacobian identity, moving-log resummation,
  all-order fixed-depth rigidity, and exact nested-window log law.

## Not established

- compactness of the normalized residual at the first fit-failure scale;
- a concentration-compactness theorem for arbitrary phase packets;
- forcing from bounded-mass terminal packets;
- uniform control through an unbounded number of visible scales;
- universal square existence;
- the Toeplitz square-peg conjecture.

The main frontier is now **first-failure residual compactness and bounded-mass
packet termination**, rather than shifted-log parameter drift.
