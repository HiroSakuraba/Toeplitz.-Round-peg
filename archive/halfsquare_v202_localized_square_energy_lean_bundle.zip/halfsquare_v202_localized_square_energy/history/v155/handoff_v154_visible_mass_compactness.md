# Project Handoff v154: Visible Nonquadratic Mass and First-Failure Compactness

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v153 reduced coherent moving-log drift to the first scale where a shifted-log
fit genuinely loses phase accuracy. The remaining question was what the
normalized first-failure residual can do.

v154 gives a substantially sharper answer.

There are two main advances.

First, the moving-log residual theorem from v152 does not require a `C^1`
limit. A merely **continuous** nonquadratic residual profile already forces a
square. The reason is that after exact moving-log flattening the limiting map
has the triangular form

\[
K_g(p,q,v)=(p,q,-Q_g(p,q,v)),
\]

where

\[
Q_g(a,b,v)
=
 g(v-a)-g(v+b)+g(v+a)-g(v-b),
\qquad
p=a+b,
\quad q=a-b.
\]

If `g` is not quadratic, then for some fixed `(p,q)` the scalar function
`v -> Q_g(p,q,v)` is nonconstant. A one-dimensional sign crossing already
produces nonzero Brouwer degree. No derivative of `g` is needed.

Second, the correct first-failure mass is the quotient norm

\[
\boxed{
\mu_I(R)
=
\operatorname{dist}_{C(I)}(R,\mathcal P_2)
=
\inf_{P\in\mathcal P_2}\|R-P\|_{L^\infty(I)},
}
\tag{0.1}
\]

where `P_2` is the three-dimensional space of quadratic polynomials.

This is the right quantity because a subleading quadratic phase residual can
be absorbed into a small refit of the shifted logarithm. More precisely, if

\[
\mathfrak L_{A,B}(t)
=-\frac{A^2}{2B}
 \log\left(1-\frac{2B}{A}t\right),
\]

and

\[
|a|+|b|=O(S),
\qquad
S/A\to0,
\qquad
B/A\to0,
\]

then on every fixed compact interval

\[
\boxed{
\mathfrak L_{A+a,B+b}(t)-\mathfrak L_{A,B}(t)
=
 a t+b t^2+o(S).
}
\tag{0.2}
\]

An additive constant absorbs the constant term. Thus, to first visible order,
small shifted-log refitting is exactly quotienting by `P_2`.

This lets one define a canonical first-fit-failure residual by taking a
near-best shifted-log approximation. If

\[
D_n
=
\inf_{c,A,B}
\|F_n-c-\mathfrak L_{A,B}\|_\infty
\]

on the profile window and a near-minimizer lies in the moving-pole regime

\[
A_n\to\infty,
\qquad
B_n/A_n\to0,
\qquad
D_n\to\infty,
\qquad
D_n/A_n\to0,
\]

then for its residual

\[
R_n=F_n-c_n-\mathfrak L_{A_n,B_n}
\]

the quadratic quotient mass satisfies

\[
\boxed{
\mu_I(R_n)=D_n(1+o(1)).
}
\tag{0.3}
\]

Choose a best quadratic approximant `P_n` to `R_n` and normalize

\[
\boxed{
h_n=\frac{R_n-P_n}{\mu_I(R_n)}.
}
\tag{0.4}
\]

Then exactly

\[
\boxed{
\|h_n\|_\infty=1,
\qquad
\operatorname{dist}(h_n,\mathcal P_2)=1.
}
\tag{0.5}
\]

Hence any uniformly convergent subsequence has a continuous limit `h` with

\[
\operatorname{dist}(h,\mathcal P_2)=1,
\]

so `h` is automatically nonquadratic. By the new continuous-profile theorem,
that compact branch forces a square.

Therefore a square-free first-failure sequence with diverging subleading
visible mass **cannot be equicontinuous** after quadratic gauge fixing.
Consequently there must exist a fixed `eta > 0` and pairs

\[
x_n,y_n\in I,
\qquad
|x_n-y_n|\to0,
\]

such that

\[
\boxed{
|h_n(x_n)-h_n(y_n)|\ge\eta.
}
\tag{0.6}
\]

In the original phase scale this is a packet of width tending to zero but
phase excursion at least

\[
\boxed{
\eta\,\mu_I(R_n)(1+o(1))\to\infty.
}
\tag{0.7}
\]

Thus the first-failure obstruction has now been reduced to a genuine
**concentration cascade**. At every finite level, either a continuous
nonquadratic profile emerges and the square is forced, or a narrower packet
retains a fixed positive fraction of the current diverging visible mass.
A bounded-mass escape can occur only at a depth tending to infinity.

The remaining obstruction is therefore substantially narrower than in v153:

\[
\boxed{
\text{square-free escape} \Longrightarrow
\text{infinite-depth concentration of visible nonquadratic phase mass}
}
\]

subject, as always, to the inherited shrinking-window and four-contact
backtracking hypotheses needed to transfer the radial/profile argument to an
arbitrary Jordan boundary.

---

# 1. The continuous residual theorem

The moving-log flattening of v152 assumed

\[
F_n(t)
=
\mathfrak L_{A_n,B_n}(t)
+S_n g(t)
+r_n(t),
\tag{1.1}
\]

uniformly on a fixed compact profile interval, with

\[
A_n\to\infty,
\qquad
B_n/A_n\to0,
\tag{1.2}
\]

\[
S_n\to\infty,
\qquad
S_n/A_n\to0,
\qquad
\|r_n\|_\infty/S_n\to0.
\tag{1.3}
\]

The exact flattening gives

\[
\Psi_n(H_{F_n})
\longrightarrow
K_g(p,q,v)
=
(p,q,-Q_g(p,q,v)),
\tag{1.4}
\]

uniformly on compact parameter boxes.

The derivation of (1.4) uses only uniform boundedness and continuity of the
residual values. It does not differentiate `g`.

The v152 proof then differentiated `Q_g` to identify regular points. That
step can be replaced by a purely topological one.

## 1.1 The finite-difference operator

Write

\[
u_0=v-a,
\quad
u_1=v+b,
\quad
u_2=v+a,
\quad
u_3=v-b.
\]

Define

\[
\boxed{
Q_g(a,b,v)
=
 g(v-a)-g(v+b)+g(v+a)-g(v-b).
}
\tag{1.5}
\]

Equivalently,

\[
Q_g(a,b,v)
=
[g(v-a)+g(v+a)]-[g(v-b)+g(v+b)].
\tag{1.6}
\]

For a quadratic

\[
g(t)=c_0+c_1t+c_2t^2,
\]

one has exactly

\[
\boxed{
Q_g(a,b,v)=2c_2(a^2-b^2),
}
\tag{1.7}
\]

which is independent of `v`.

The converse remains true under continuity alone.

> **Lemma 1.1 — continuous finite-difference classification.**  
> Let `g` be continuous on an interval, and suppose that for every admissible
> pair `(a,b)` the function `v -> Q_g(a,b,v)` is constant wherever all four
> arguments remain in the interval. Then `g` is a quadratic polynomial on
> that interval.

### Proof

Set `b=0`. Then

\[
g(v-a)+g(v+a)-2g(v)=C(a)
\tag{1.8}
\]

with no dependence on `v`.

Split

\[
g=g_e+g_o,
\]

into even and odd parts after translating to an interior origin.

For the odd part, (1.8) has zero right-hand side because at `v=0`

\[
g_o(-a)+g_o(a)-2g_o(0)=0.
\]

Hence

\[
g_o(v-a)+g_o(v+a)=2g_o(v).
\tag{1.9}
\]

This is midpoint Jensen. Continuity implies

\[
g_o(v)=\lambda v.
\tag{1.10}
\]

For the even part, put

\[
E(v)=g_e(v)-g_e(0).
\]

Equation (1.8) becomes

\[
\boxed{
E(v-a)+E(v+a)=2E(v)+2E(a).
}
\tag{1.11}
\]

This is the quadratic functional equation. Continuity implies

\[
E(v)=\kappa v^2.
\tag{1.12}
\]

Thus

\[
g(v)=\kappa v^2+\lambda v+c.
\]

The argument localizes and patches across a connected interval. QED.

Therefore, if `g` is continuous and nonquadratic, there are admissible
`a,b` and `v_-<v_+` with

\[
Q_g(a,b,v_-)\ne Q_g(a,b,v_+).
\tag{1.13}
\]

## 1.2 Strip degree without derivatives

Assume after exchanging the endpoints if necessary that

\[
Q_g(a,b,v_-)<y<Q_g(a,b,v_+).
\tag{1.14}
\]

Let

\[
p_0=a+b,
\qquad
q_0=a-b.
\]

At the target

\[
y_*=(p_0,q_0,-y),
\]

the limiting map is

\[
K_g-y_*
=
(p-p_0,q-q_0,y-Q_g).
\tag{1.15}
\]

By continuity, choose a small rectangle in `(p,q)` around `(p_0,q_0)` such
that on the lower `v` face

\[
y-Q_g>0
\]

and on the upper `v` face

\[
y-Q_g<0.
\]

On the two `p` faces the first component has opposite fixed signs; on the two
`q` faces the second component does the same. Therefore the map is homotopic,
without creating a boundary zero, to the product of the identity in `(p,q)`
and a one-dimensional sign crossing in `v`. Its Brouwer degree is `+1` or
`-1`.

No differentiability is involved.

The nearest-lattice argument from v152 still applies because

\[
S_n\to\infty.
\]

The transformed lattice mesh is `o(1)`, and the exact moving-log flattening
is locally injective. Hence the nonzero degree forces an exact raw phase
lattice hit and therefore an actual square.

This proves:

> **Theorem 1.2 — continuous moving-log residual square forcing.**  
> Under the inherited shrinking-window hypotheses, assume (1.1)--(1.3) with
> `g` merely continuous. If `g` is not a quadratic polynomial, then actual
> squares are forced.

This strictly strengthens v152 Theorem 5.1, which assumed `g in C^1`.

---

# 2. Quadratics are exactly the first-order refit directions

The shifted logarithm satisfies

\[
\boxed{
\mathfrak L'_{A,B}(t)
=
\frac{A}{1-(2B/A)t}.
}
\tag{2.1}
\]

An exact decomposition is

\[
\mathfrak L'_{A,B}(t)
=
A+2Bt+E_{A,B}(t),
\tag{2.2}
\]

where

\[
\boxed{
E_{A,B}(t)
=
\frac{4B^2t^2}{A-2Bt}.
}
\tag{2.3}
\]

Take parameter perturbations

\[
A\mapsto A+a,
\qquad
B\mapsto B+b.
\]

Then the exact derivative remainder after removing the expected linear and
quadratic phase terms is

\[
\boxed{
\begin{aligned}
&\mathfrak L'_{A+a,B+b}(t)
-\mathfrak L'_{A,B}(t)
-a-2bt
\\[1mm]
&=
\frac{
4t^2
\left(
2ABb+Ab^2-B^2a-2B^2bt-2Bb^2t
\right)
}
{(A-2Bt)(A+a-2(B+b)t)}.
\end{aligned}
}
\tag{2.4}
\]

Suppose on a fixed interval `|t| <= R`

\[
|a|+|b|\le CS,
\qquad
S/A\to0,
\qquad
B/A\to0.
\tag{2.5}
\]

Then both denominators are asymptotic to `A`, while every term in the
numerator divided by `A^2 S` tends to zero:

\[
\frac{|B||b|}{AS}=O(B/A)\to0,
\]

\[
\frac{b^2}{AS}=O(S/A)\to0,
\]

\[
\frac{B^2|a|}{A^2S}=O((B/A)^2)\to0,
\]

with the remaining terms smaller on a fixed compact interval.

Therefore

\[
\sup_{|t|\le R}
\left|
\mathfrak L'_{A+a,B+b}
-\mathfrak L'_{A,B}
-a-2bt
\right|
=o(S).
\tag{2.6}
\]

Since every normalized shifted log vanishes at `t=0`, integration gives:

> **Lemma 2.1 — quadratic absorption.**  
> If (2.5) holds, then
> 
> \[
> \boxed{
> \mathfrak L_{A+a,B+b}(t)-\mathfrak L_{A,B}(t)
> =a t+b t^2+o(S)
> }
> \tag{2.7}
> \]
> 
> uniformly on every fixed compact interval.

Adding an arbitrary constant parameter shows that the tangent space of
subleading shifted-log refits is exactly

\[
\boxed{\mathcal P_2=\operatorname{span}\{1,t,t^2\}.}
\tag{2.8}
\]

This is the near-affine version of the v150 tangent-space computation, but it
is now stated directly in the visible phase scale used by the stopping
argument.

---

# 3. Visible nonquadratic phase mass

For a compact interval `I`, define

\[
\boxed{
\mu_I(R)
=
\inf_{P\in\mathcal P_2}
\|R-P\|_{L^\infty(I)}.
}
\tag{3.1}
\]

This is a seminorm on `C(I)` whose kernel is precisely `P_2`.

It has four useful exact properties.

### 3.1 Quadratic gauge invariance

For every `Q in P_2`,

\[
\boxed{
\mu_I(R+Q)=\mu_I(R).
}
\tag{3.2}
\]

### 3.2 Homogeneity

\[
\boxed{
\mu_I(cR)=|c|\mu_I(R).
}
\tag{3.3}
\]

### 3.3 Subadditivity

\[
\boxed{
\mu_I(R_1+R_2)
\le
\mu_I(R_1)+\mu_I(R_2).
}
\tag{3.4}
\]

### 3.4 Affine-window covariance

Let

\[
T(s)=t_0+\delta s,
\qquad \delta\ne0,
\]

map an interval `J` bijectively onto `I`. Because the composition of a
quadratic with an affine map is again quadratic,

\[
\boxed{
\mu_J(R\circ T)=\mu_I(R).
}
\tag{3.5}
\]

If one merely restricts to a smaller interval,

\[
\boxed{
J\subset I
\quad\Longrightarrow\quad
\mu_J(R)\le\mu_I(R).
}
\tag{3.6}
\]

A best approximating quadratic exists because `P_2` is finite-dimensional and
closed in `C(I)`.

## 3.5 A directly measurable three-anchor defect

The abstract best-approximation norm can be replaced, up to an explicit
universal constant, by a fixed interpolation defect.

Let

\[
I=[x_-,x_+],
\qquad
x_0=\frac{x_-+x_+}{2},
\]

and let `Pi_I R` be the unique quadratic interpolating `R` at

\[
x_-,\quad x_0,\quad x_+.
\]

Define

\[
\boxed{
\nu_I(R)=\|R-\Pi_I R\|_\infty.
}
\tag{3.7}
\]

Because `Pi_I` reproduces every quadratic,

\[
\mu_I(R)\le\nu_I(R).
\tag{3.8}
\]

On the normalized interval `[-1,1]`, the three Lagrange basis functions are

\[
\ell_-(x)=\frac{x(x-1)}2,
\qquad
\ell_0(x)=1-x^2,
\qquad
\ell_+(x)=\frac{x(x+1)}2.
\]

Their Lebesgue function has maximum

\[
\boxed{
\max_{|x|\le1}
(|\ell_-|+|\ell_0|+|\ell_+|)
=\frac54.
}
\tag{3.9}
\]

Hence the interpolation projector has operator norm `5/4`. If `P_*` is a
best quadratic approximant and `r=R-P_*`, then

\[
R-\Pi_I R
=r-\Pi_I r,
\]

so

\[
\nu_I(R)
\le
\left(1+\frac54\right)\|r\|_\infty.
\]

Therefore

\[
\boxed{
\mu_I(R)
\le
\nu_I(R)
\le
\frac94\mu_I(R).
}
\tag{3.10}
\]

The quantity `nu_I` has the same quadratic-gauge invariance, homogeneity,
subadditivity, and affine-window covariance as `mu_I`, because `I-Pi_I` is a
linear operator that annihilates `P_2` and the three interpolation nodes are
preserved by affine normalization.

For any fourth point `x` distinct from the anchors,

\[
R(x)-\Pi_I R(x)
=
R[x_-,x_0,x_+,x]
(x-x_-)(x-x_0)(x-x_+),
\tag{3.11}
\]

where the bracket is the third divided difference. Thus visible
nonquadratic phase mass can be read as a weighted **four-point third
difference**. This is the concrete finite-difference observable suggested at
the end of v153.

This gives the requested subadditive, zoom-compatible visible phase mass.
Unlike raw oscillation, it discards exactly the phase directions that the
moving logarithm can absorb at first order.

---

# 4. Best shifted-log failure equals quotient mass to first order

Let the local shifted-log family on `I` be

\[
\mathcal M
=
\{c+\mathfrak L_{A,B}:\text{pole outside }I\}.
\]

Define the best-fit error

\[
\boxed{
D(F;I)
=
\inf_{L\in\mathcal M}
\|F-L\|_{L^\infty(I)}.
}
\tag{4.1}
\]

Consider a sequence `F_n` for which one can choose near-minimizers

\[
L_n=c_n+\mathfrak L_{A_n,B_n}
\]

satisfying

\[
\|F_n-L_n\|_\infty
\le
D_n+o(D_n),
\qquad
D_n=D(F_n;I),
\tag{4.2}
\]

and

\[
A_n\to\infty,
\qquad
B_n/A_n\to0,
\tag{4.3}
\]

\[
D_n\to\infty,
\qquad
D_n/A_n\to0.
\tag{4.4}
\]

Set

\[
R_n=F_n-L_n.
\]

Let

\[
\mu_n=\mu_I(R_n).
\]

Trivially

\[
\mu_n\le\|R_n\|_\infty
\le D_n+o(D_n).
\tag{4.5}
\]

Choose a best quadratic

\[
P_n=c'_n+a_nt+b_nt^2
\]

with

\[
\|R_n-P_n\|_\infty=\mu_n.
\tag{4.6}
\]

Because `R_n=O(D_n)` and all norms are equivalent on the fixed
three-dimensional space `P_2`, the coefficients of `P_n` satisfy

\[
|c'_n|+|a_n|+|b_n|=O(D_n).
\tag{4.7}
\]

By (4.4), these are subleading compared with `A_n`. Lemma 2.1 therefore
absorbs `P_n` into a new shifted-log fit:

\[
L_n+P_n
=
\widetilde L_n+o(D_n)
\tag{4.8}
\]

uniformly, where `\widetilde L_n in M` and remains in the near-affine branch.
Hence

\[
D_n
\le
\|F_n-\widetilde L_n\|_\infty
\le
\mu_n+o(D_n).
\tag{4.9}
\]

Combining with (4.5) gives

\[
\boxed{
\mu_n=D_n(1+o(1)).
}
\tag{4.10}
\]

Thus the nonlinear shifted-log distance and the linear quotient distance by
quadratics agree to first visible order at every subleading moving-pole
failure scale.

This is one of the main structural results of v154.

---

# 5. Canonically normalized first-failure residual

Let `P_n` be a best quadratic approximant to `R_n` and define

\[
\boxed{
h_n
=
\frac{R_n-P_n}{\mu_n}.
}
\tag{5.1}
\]

Because `P_n` is best,

\[
\boxed{
\|h_n\|_\infty=1.
}
\tag{5.2}
\]

Quadratic gauge invariance gives

\[
\operatorname{dist}(R_n-P_n,\mathcal P_2)
=
\mu_n,
\]

so

\[
\boxed{
\operatorname{dist}(h_n,\mathcal P_2)=1.
}
\tag{5.3}
\]

After the quadratic absorption in Section 4,

\[
\boxed{
F_n
=
\widetilde L_n
+
\mu_n h_n
+
o(\mu_n),
}
\tag{5.4}
\]

with

\[
\mu_n\to\infty,
\qquad
\mu_n/\widetilde A_n\to0,
\qquad
\widetilde B_n/\widetilde A_n\to0.
\tag{5.5}
\]

Equation (5.4) is exactly in the form required by the continuous residual
theorem, except that a limiting profile has not yet been extracted.

---

# 6. Compactness-or-concentration at first failure

The sequence `h_n` is uniformly bounded in `C(I)` because

\[
\|h_n\|_\infty=1.
\]

There are now two branches.

## 6.1 Compact branch

Suppose `h_n` is equicontinuous. By Arzela-Ascoli, after passing to a
subsequence,

\[
h_n\to h
\]

uniformly for some continuous `h`.

Distance to a fixed closed subset is 1-Lipschitz in the ambient norm, so

\[
\operatorname{dist}(h,\mathcal P_2)
=
\lim_n
\operatorname{dist}(h_n,\mathcal P_2)
=1.
\tag{6.1}
\]

Therefore `h` is not quadratic.

Equation (5.4) and Theorem 1.2 then force actual squares.

Thus:

> **Theorem 6.1 — compact first-failure branch closes.**  
> In the subleading moving-pole regime (4.3)--(4.4), a square-free tail cannot
> have an equicontinuous canonically normalized first-failure residual.

This is stronger than the v153 statement that compactness would be useful.
The compact branch is now closed under mere `C^0` compactness.

## 6.2 Concentration branch

If `h_n` is not equicontinuous, the negation of equicontinuity gives a fixed
number

\[
\eta>0
\]

and, after passing to a subsequence, points

\[
x_n,y_n\in I
\]

such that

\[
\boxed{
|x_n-y_n|\to0,
\qquad
|h_n(x_n)-h_n(y_n)|\ge\eta.
}
\tag{6.2}
\]

Using (5.4), the non-log residual in the actual phase changes across this
shrinking interval by

\[
\boxed{
\ge
\eta\mu_n+o(\mu_n).
}
\tag{6.3}
\]

Since

\[
\mu_n\to\infty,
\]

the packet still has diverging phase mass.

Let

\[
\delta_n=|x_n-y_n|.
\]

Recenter and rescale by

\[
t=x_n+\delta_n s.
\]

The exact shifted-log family transports to another shifted log under this
affine zoom, by v152/v153. The quotient mass is also exactly covariant under
the same affine change of variable. Therefore the child window is again in
the same structural setting.

This proves:

> **Theorem 6.2 — first-failure concentration.**  
> Under the assumptions of Theorem 6.1, if the tail remains square-free then
> there exist shrinking child windows carrying a fixed positive fraction of
> the current diverging normalized phase excursion.

The theorem does not claim that the child residual already has a compact
profile. It says the failure cannot disappear into a diffuse bounded error.
It must concentrate.

---

# 7. Finite-depth concentration cannot terminate at bounded mass

Suppose the concentration alternative is iterated.

At generation `j`, after passing to a subsequence, let the retained fraction
of visible phase excursion be

\[
\eta_j>0.
\]

If the root visible mass is `\mu_n -> infinity`, then at every **fixed** depth
`k` the retained phase excursion is at least

\[
\boxed{
\left(\prod_{j=1}^{k}\eta_j\right)\mu_n(1+o(1)).
}
\tag{7.1}
\]

The product is a positive constant for fixed `k`, so

\[
\boxed{
\left(\prod_{j=1}^{k}\eta_j\right)\mu_n\to\infty.
}
\tag{7.2}
\]

Therefore a bounded-mass terminal packet cannot appear after any uniformly
bounded number of concentration steps.

It can occur only at a depth

\[
\boxed{k=k_n\to\infty.}
\tag{7.3}
\]

This is a meaningful reduction. The surviving obstruction is not merely
“some bad packet.” It is an **infinite-depth cascade** in which spatial width
shrinks over more and more renormalization levels before the visible phase
mass finally becomes `O(1)`.

If at any fixed depth an equicontinuous normalized residual appears, Section 6
closes the branch by a square.

---

# 8. Why the quotient norm is better than raw oscillation

Raw phase oscillation has two defects.

First, an affine or quadratic residual can have arbitrarily large oscillation
while remaining invisible to the moving-log degree at first order because it
can be absorbed by parameter refitting.

Second, raw oscillation is not tied to the nonlinear exceptional manifold.

The quotient mass

\[
\mu_I(R)=\operatorname{dist}(R,\mathcal P_2)
\]

removes exactly those problems.

It is:

- zero precisely on first-order moving-log refit directions;
- subadditive;
- invariant under addition of those invisible directions;
- covariant under affine window zooms;
- asymptotically equal to the actual best shifted-log fit error in the
  subleading moving-pole regime;
- normalized so that every compact limit is automatically nonquadratic.

This is the natural “visible phase mass” requested in v153 Section 13.

---

# 9. Relationship to v150--v153

The sequence of reductions is now:

\[
\boxed{
\begin{array}{c}
\text{v150: invisible tangent directions}\
\downarrow\\
\text{v152: exact shifted-log manifold}\
\downarrow\\
\text{v153: nested overlap coherence}\
\downarrow\\
\text{v154: quotient mass and first-failure concentration.}
\end{array}
}
\]

More concretely:

1. v150 found the infinitesimal exceptional tangent space.
2. v152 resummed it into the exact shifted logarithm and showed every
   nonquadratic visible residual restores the missing degree direction.
3. v153 showed overlapping shifted-log fits cannot drift visibly while both
   remain accurate.
4. v154 identifies the canonical residual mass after the first fit actually
   fails, closes every compact `C^0` residual profile, and forces the
   remaining mass into successively narrower windows.

The proof program is therefore no longer blocked by:

- cubic, quartic, or any fixed polynomial resonance;
- smooth moving-log parameter drift;
- lack of `C^1` compactness of the first-failure residual;
- compact continuous nonquadratic residuals.

The obstruction is now genuinely an infinite-depth, non-equicontinuous
concentration phenomenon.

---

# 10. What v154 closes

### Closed: `C^1` regularity of the residual profile

The moving-log residual theorem extends to continuous profiles.

### Closed: identifying a subadditive visible phase mass

The quotient norm by `P_2` has the required gauge, subadditivity, and affine
zoom properties.

### Closed: quadratic compact residuals as a loophole

Best-fit normalization gives distance one from `P_2`, so no compact limit can
be quadratic.

### Closed: diffuse compact first-fit failure

Equicontinuity gives a continuous nonquadratic limit and therefore a square.

### Closed: finite-depth bounded-mass termination

Every fixed finite number of concentration steps retains diverging phase
mass.

---

# 11. What remains open

## I. Infinite-depth concentration cascade

The main unresolved branch is a sequence of narrower and narrower windows,
with the number of required zooms tending to infinity with `n`, before the
visible mass becomes bounded.

A proof now needs to show that such a cascade either:

- produces a square directly;
- violates Jordan injectivity/topology;
- accumulates enough total angular variation to force an already-controlled
  branch; or
- admits a terminal model that can itself be classified.

## II. Quantitative geometry of the concentration centers

The locations of the child packets inside their parents may drift. The exact
log parameter `beta` remains coherent wherever an ancestor fit is still
accurate, but after each first-failure refit there is a new local model. A
useful next invariant would track the packet centers and widths as a tree.

## III. Bounded terminal mass

When the final visible nonquadratic mass is `O(1)`, the transformed phase
lattice is no longer asymptotically dense. The Brouwer capture argument does
not automatically close.

## IV. General Jordan transfer

As in v149--v153, the radial/profile results require the inherited
four-contact backtracking and angular-comparison hypotheses when applied to a
general Jordan curve.

---

# 12. Recommended v155 target

The next target should be the **infinite-depth concentration cascade**, not
another smooth-profile calculation.

Three concrete approaches now look worthwhile.

### A. Packet-tree Carleson bound

Build a tree of nested first-failure intervals. Associate to each node its
visible mass `mu(J)` and width `|J|`. Try to prove a packing inequality of the
form

\[
\sum_{J\text{ child of }I}
\Phi(\mu(J),|J|)
\le C\,\Phi(\mu(I),|I|)
\]

for a quantity tied to angular variation or reciprocal-slope defect. An
infinite-depth branch carrying a fixed fraction of mass would then violate a
finite total budget.

### B. Three-scale finite-difference obstruction

Because `mu` quotients out quadratics, third finite differences are the first
quantities that detect it. Seek a scale-local inequality comparing

\[
\mu_I(R)
\]

to a supremum or average of third divided differences. A concentration
cascade would then produce a nested sequence of large third differences,
which may be incompatible with the monotone radial/angular geometry of an
injective Jordan arc.

### C. Bounded-mass lattice arithmetic

At the terminal scale the asymptotic lattice-density argument fails. Instead,
classify which `O(1)` residual packets can avoid the discrete lattice for all
nearby square shapes. This is a finite-scale arithmetic/topological problem,
not a smooth asymptotic one.

Approach B is probably the cleanest immediate target because it converts the
new quotient norm into a concrete finite-difference observable.

---

# 13. Verification

`code/verify_v154.py` checks:

1. the exact formula for `Q_g` on quadratic and cubic polynomials;
2. the exact derivative remainder identity (2.4);
3. numerical quadratic absorption along several moving-pole asymptotic
   sequences;
4. affine covariance of quadratic polynomials under window zooms;
5. the exact `5/4` Lebesgue constant for the three-anchor quadratic
   interpolation projector;
6. a strip-degree sign-crossing example for a continuous nonquadratic
   profile;
7. the concentration alternative on a shrinking tent-packet toy sequence;
8. preservation of a diverging phase amplitude through any fixed number of
   concentration levels.

All checks pass.

---

# 14. Claim boundary

## Established in v154

- extension of the v152 moving-log residual theorem from `C^1` to continuous
  nonquadratic profiles using a strip-degree argument;
- continuous classification: `Q_g(a,b,v)` is independent of `v` for every
  admissible `(a,b)` iff `g` is quadratic;
- exact quadratic-absorption expansion for subleading shifted-log parameter
  perturbations;
- definition and structural properties of the visible nonquadratic mass
  `mu_I = dist(.,P_2)`;
- asymptotic equivalence of best shifted-log fit error and quadratic quotient
  mass at subleading moving-pole first-failure scales;
- canonical normalization with both sup norm and distance from `P_2` equal to
  one;
- closure of the equicontinuous/compact first-failure branch;
- forced concentration of every square-free diverging first-failure residual;
- impossibility of bounded-mass termination after a uniformly bounded number
  of concentration steps.

## Inherited and used

- v149 shrinking-window square coordinates and phase-lattice Brouwer capture;
- v150 exceptional tangent-space analysis;
- v151 cubic/quartic resonance calculations;
- v152 exact moving-log flattening, reciprocal-slope Jacobian identity,
  all-order visible-jet rigidity, and exact affine-window transport;
- v153 stable overlap coherence of nested shifted-log fits.

## Not established

- exclusion of an infinite-depth concentration cascade;
- a Carleson/packing or total-variation bound for the packet tree;
- a terminal bounded-mass lattice theorem;
- a complete transfer from every arbitrary Jordan boundary without the
  inherited four-contact profile/backtracking hypotheses;
- the full Toeplitz square-peg conjecture.
