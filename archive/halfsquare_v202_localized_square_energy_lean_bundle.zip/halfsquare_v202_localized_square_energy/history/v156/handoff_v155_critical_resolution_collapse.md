# Project Handoff v155: Critical Resolution and Collapse of the Perturbative Concentration Cascade

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v154 reduced the subleading moving-log branch to normalized residuals

\[
F_n(t)=L_n(t)+S_n h_n(t)+r_n(t),
\tag{0.1}
\]

on a fixed buffered profile interval, where

\[
L_n(t)=\mathfrak L_{A_n,B_n}(t),
\qquad
\mathfrak L_{A,B}(t)
=-\frac{A^2}{2B}\log\left(1-\frac{2B}{A}t\right),
\tag{0.2}
\]

\[
A_n\to\infty,
\qquad
\frac{B_n}{A_n}\to0,
\qquad
S_n\to\infty,
\qquad
\frac{S_n}{A_n}\to0,
\tag{0.3}
\]

\[
\|r_n\|_\infty=o(S_n),
\qquad
\|h_n\|_\infty=1,
\qquad
\operatorname{dist}(h_n,\mathcal P_2)=1.
\tag{0.4}
\]

Here `P_2` denotes the quadratic polynomials.  In v154, failure of
Arzela--Ascoli compactness was described as an apparently unlimited
concentration cascade.

v155 identifies a canonical horizontal resolution for that cascade:

\[
\boxed{
\varepsilon_n=\frac{S_n}{A_n}.
}
\tag{0.5}
\]

This is the profile distance over which the dominant shifted logarithm
accumulates phase of order `S_n`, the same order as the entire first-failure
residual.

The main new result is:

> **Critical-resolution theorem.**  In the inherited v149--v154
> shrinking-window/lattice setting, there are constants `K < infinity` and
> `eta > 0`, depending only on the fixed buffered profile box and not on `n`,
> such that if
> \[
> \omega_1(h_n;K\varepsilon_n)\le \eta
> \tag{0.6}
> \]
> for infinitely many `n`, then the phase-lattice degree forces actual
> squares along that subsequence.
>
> Consequently every square-free tail in the v154 first-failure regime must
> satisfy
> \[
> \boxed{
> \omega_1(h_n;K S_n/A_n)>\eta
> }
> \tag{0.7}
> \]
> for all sufficiently large `n`.

Here

\[
\omega_1(h;r)
=
\sup\{|h(x)-h(y)|:|x-y|\le r\}.
\tag{0.8}
\]

Thus square-free escape requires points `x_n,y_n` with

\[
|x_n-y_n|\le K\frac{S_n}{A_n},
\qquad
|h_n(x_n)-h_n(y_n)|\ge\eta.
\tag{0.9}
\]

The first-fit residual therefore changes by a fixed fraction of its entire
visible amplitude `S_n` across a window no wider than `O(S_n/A_n)`.

That is the critical scale because after the zoom

\[
t=t_n+\frac{S_n}{A_n}s,
\tag{0.10}
\]

and division by `S_n`, the parent shifted logarithm is no longer dominant:

\[
\boxed{
\frac{F_n(t_n+(S_n/A_n)s)-F_n(t_n)}{S_n}
=
 s+
 \bigl[h_n(t_n+(S_n/A_n)s)-h_n(t_n)\bigr]
 +o(1)
}
\tag{0.11}
\]

uniformly for bounded `s` (after the harmless normalization of the log slope
at `t_n`; on the fixed profile box that slope factor tends to `1`).

The bracketed term is bounded by `2` and, on a bounded `s`-interval, has
oscillation at least `eta` in the square-free branch.

So the hierarchy cannot remain a **subleading moving-log perturbation** for
arbitrarily many concentration levels.  It reaches a balanced rough profile
in one canonical zoom.

The v154 obstruction should therefore be restated as

\[
\boxed{
\begin{array}{c}
\text{moving-log first failure}\\
\Downarrow\\
\text{square, unless residual is rough at }S/A\\
\Downarrow\\
\text{balanced high-phase profile at the critical zoom.}
\end{array}
}
\tag{0.12}
\]

An infinite-depth obstruction may still exist **after** the critical zoom,
but it is no longer an infinite tower of ever-smaller subleading corrections
to one shifted logarithm.  It is a new balanced-profile problem.

This is a material narrowing of the frontier.

---

# 1. The exact first-failure representation inherited from v154

v154 starts with a near-best shifted-log fit and quotients its residual by the
quadratic tangent directions of the moving-log manifold.  After absorbing the
best quadratic into a nearby shifted logarithm, one has exactly the form

\[
F_n=L_n+S_n h_n+r_n,
\tag{1.1}
\]

with (0.3)--(0.4).

The normalization is important:

\[
\|h_n\|_\infty=1,
\qquad
E_2(h_n):=\inf_{P\in\mathcal P_2}\|h_n-P\|_\infty=1.
\tag{1.2}
\]

Thus zero is itself a best quadratic approximant to `h_n`.

By the Chebyshev alternation theorem, each `h_n` has four ordered alternation
points

\[
x_{0,n}<x_{1,n}<x_{2,n}<x_{3,n}
\tag{1.3}
\]

with

\[
h_n(x_{j,n})=\sigma_n(-1)^j,
\qquad
\sigma_n\in\{+1,-1\}.
\tag{1.4}
\]

This already shows that the normalized residual contains three full-amplitude
transitions.  The difficulty left by v154 was that all of those transitions
could become arbitrarily sharp.

v155 determines how sharp they are allowed to become before the problem
changes scale.

---

# 2. Third differences are exactly vertical motion of the flattened map

For a continuous function `g`, recall

\[
Q_g(a,b,v)
=
 g(v-a)-g(v+b)+g(v+a)-g(v-b).
\tag{2.1}
\]

Set `b=0`.  Then

\[
Q_g(a,0,v)
=
 g(v-a)-2g(v)+g(v+a).
\tag{2.2}
\]

For a forward step `s>0`, define

\[
\Delta_s^3g(x)
=
-g(x)+3g(x+s)-3g(x+2s)+g(x+3s).
\tag{2.3}
\]

A direct subtraction gives the exact identity

\[
\boxed{
\Delta_s^3g(x)
=
Q_g(s,0,x+2s)-Q_g(s,0,x+s).
}
\tag{2.4}
\]

In the `(p,q,v)` coordinates of v151--v154,

\[
p=a+b,
\qquad
q=a-b,
\tag{2.5}
\]

so `b=0,a=s` means

\[
p=q=s.
\tag{2.6}
\]

Therefore a third difference is not merely analogous to the missing normal
direction.  It is **exactly a finite vertical displacement of the flattened
normal functional** at fixed square-shape coordinates.

This gives the right bridge from v154's quotient norm to a finite-size degree
box.

---

# 3. A quantitative third-difference witness

Let the core profile interval be `I_0`, contained with positive buffer in a
slightly larger interval `I_+` on which (1.1) holds uniformly.

For a continuous function on `I_0`, define the third modulus

\[
\omega_3(g)
=
\sup_{x,x+3s\in I_0}|\Delta_s^3g(x)|.
\tag{3.1}
\]

The standard Whitney/Jackson finite-difference inequality for approximation
by degree-two polynomials gives a constant `C_W`, depending only on the fixed
interval normalization, such that

\[
E_2(g)\le C_W\omega_3(g).
\tag{3.2}
\]

For the v154 normalization `E_2(h_n)=1`, this yields

\[
\boxed{
\omega_3(h_n)\ge c_W:=C_W^{-1}>0.
}
\tag{3.3}
\]

Hence for each `n` there are `x_n,s_n` with

\[
|\Delta_{s_n}^3h_n(x_n)|\ge c_W.
\tag{3.4}
\]

Combining (2.4) and (3.4), the scalar flattened coordinate has a vertical gap
at least `c_W` between

\[
(p,q,v)=(s_n,s_n,x_n+s_n)
\tag{3.5}
\]

and

\[
(p,q,v)=(s_n,s_n,x_n+2s_n).
\tag{3.6}
\]

No differentiability of `h_n` is used.

## 3.1 Why a small first-order modulus makes the witness macroscopic

Suppose

\[
\omega_1(h_n;K\varepsilon_n)\le\eta.
\tag{3.7}
\]

If `s_n <= K epsilon_n`, then

\[
\Delta_{s_n}^3h_n(x_n)
=
[h_n(x_n+3s_n)-h_n(x_n+2s_n)]
-2[h_n(x_n+2s_n)-h_n(x_n+s_n)]
+[h_n(x_n+s_n)-h_n(x_n)],
\]

so

\[
|\Delta_{s_n}^3h_n(x_n)|
\le4\omega_1(h_n;K\varepsilon_n)
\le4\eta.
\tag{3.8}
\]

Choose

\[
\eta<c_W/8.
\tag{3.9}
\]

Then the Whitney witness must satisfy

\[
\boxed{
s_n>K\varepsilon_n.
}
\tag{3.10}
\]

Thus, under small roughness at the critical resolution, the nonquadratic
third-difference witness automatically lives on a scale much larger than the
size of the perturbation in the first two flattened coordinates.

That is the key separation of scales used below.

---

# 4. Exact leading-surface coordinates

There is a small technical point that matters for the quantitative argument.

The first two coordinates of the v152 transform tend to `p,q`, but the pure
shifted-log surface itself still has `O(B_n/A_n)` curvature.  Since
`B_n/A_n` need not be smaller than `S_n/A_n`, one should **not** compare an
`O(S_n/A_n)` box directly with the limiting coordinates `p,q`.

Instead use the exact pure-log surface as the domain chart.

Write

\[
H_{L_n}=(H_{L_n,1},H_{L_n,2},H_{L_n,3})
\tag{4.1}
\]

for the relative phase map of `L_n`, and define

\[
\boxed{
\xi_n(p,q,v)=\frac{H_{L_n,1}(p,q,v)}{A_n},
\qquad
\zeta_n(p,q,v)=\frac{H_{L_n,3}(p,q,v)}{A_n}.
}
\tag{4.2}
\]

Because `B_n/A_n -> 0`, on every fixed physical parameter box

\[
D_{(p,q)}(\xi_n,\zeta_n)\to I_2
\tag{4.3}
\]

uniformly.  Therefore

\[
\boxed{
\Xi_n:(p,q,v)\mapsto(\xi_n,\zeta_n,v)
}
\tag{4.4}
\]

is a uniformly bi-Lipschitz local coordinate chart for all sufficiently large
`n`.

This chart removes the irrelevant `O(B_n/A_n)` drift of the leading surface
exactly.  Changes of size `O(S_n/A_n)` in `(xi,zeta)` correspond to changes of
that same order in `(p,q)`.

---

# 5. Size of the residual perturbation in the flattened map

Set

\[
\varepsilon_n=S_n/A_n.
\tag{5.1}
\]

The first and third raw relative phase differences satisfy

\[
\frac{H_{F_n,1}}{A_n}
=
\xi_n
+
\varepsilon_n
\bigl[h_n(u_1)-h_n(u_0)\bigr]
+o(\varepsilon_n),
\tag{5.2}
\]

\[
\frac{H_{F_n,3}}{A_n}
=
\zeta_n
+
\varepsilon_n
\bigl[h_n(u_3)-h_n(u_0)\bigr]
+o(\varepsilon_n).
\tag{5.3}
\]

Since `||h_n||_infty=1`, the perturbation of either leading-surface coordinate
is at most

\[
2\varepsilon_n+o(\varepsilon_n).
\tag{5.4}
\]

For the normal coordinate, the exact v152 shifted-log flattening gives,
uniformly for **varying** bounded continuous `h_n`,

\[
\boxed{
Z_n(p,q,v)
=
-Q_{h_n}(p,q,v)+o(1).
}
\tag{5.5}
\]

The uniformity follows because the only Taylor expansion is in the small
output perturbation

\[
\frac{S_n}{M_n}H_{h_n},
\qquad
M_n=\frac{A_n^2}{2B_n},
\tag{5.6}
\]

and

\[
\frac{S_n}{M_n}
=
2\frac{S_n}{A_n}\frac{B_n}{A_n}
\to0.
\tag{5.7}
\]

No modulus of continuity enters (5.5); boundedness of `h_n` is enough.

The modulus is needed only to make the third-difference witness stable under
the `O(epsilon_n)` motion required to absorb the first two residual phase
coordinates.

---

# 6. Critical-resolution degree theorem

We now prove the main v155 statement.

Choose the witness `x_n,s_n` from Section 3 and set

\[
v_n^- = x_n+s_n,
\qquad
v_n^+ = x_n+2s_n,
\qquad
p_n=q_n=s_n.
\tag{6.1}
\]

Then

\[
|Q_{h_n}(p_n,q_n,v_n^+)
-Q_{h_n}(p_n,q_n,v_n^-)|
\ge c_W.
\tag{6.2}
\]

Assume

\[
\omega_1(h_n;K\varepsilon_n)\le\eta
\tag{6.3}
\]

with `K` large and `eta` small, to be fixed universally.

By (3.10), the vertical witness length `s_n` is much larger than the
horizontal correction scale `epsilon_n`.

Use the exact leading-surface chart `(xi,zeta,v)`.  Center a rectangular box
at the witness shape and let the two horizontal half-widths be

\[
R\varepsilon_n
\tag{6.4}
\]

for a fixed `R>4`, while the two vertical faces are `v=v_n^-` and
`v=v_n^+`.

Because `Xi_n` is uniformly bi-Lipschitz, all sample arguments entering
`Q_{h_n}` move by at most

\[
C R\varepsilon_n
\tag{6.5}
\]

when `(xi,zeta)` moves across the box.  Choose

\[
K>CR.
\tag{6.6}
\]

Then each value of `Q` on either vertical face changes by at most

\[
4\omega_1(h_n;K\varepsilon_n)
\le4\eta.
\tag{6.7}
\]

Hence the separation between the two vertical-face values is at least

\[
c_W-8\eta.
\tag{6.8}
\]

Choose, for example,

\[
\eta<c_W/32.
\tag{6.9}
\]

The normal gap is then bounded below by a fixed positive constant.

Meanwhile (5.2)--(5.4) show that on each horizontal side face the corresponding
first or second transformed coordinate still points outward provided `R` is
chosen larger than the universal residual bound.  The `o(epsilon_n)` errors
are harmless.

Choose the normal target halfway between the two center-face values in
(6.2).  The third coordinate has opposite signs relative to this target on
the two vertical faces, uniformly across the horizontal section.  Therefore
the transformed map on this box is homotopic, without a boundary zero, to a
triangular box map of degree `+/-1`.

Finally, v152's lattice estimate says that a nearest raw phase-lattice point
has transformed errors

\[
O(A_n^{-1})
=o(\varepsilon_n)
\tag{6.10}
\]

in the first two coordinates and

\[
O(S_n^{-1})=o(1)
\tag{6.11}
\]

in the normal coordinate.  It therefore lies inside the degree-protected
target neighborhood for all large `n`.

Injectivity of the output flattening converts the transformed solution back
to an exact raw phase-lattice incidence, hence to an actual square by the
inherited v149 shrinking-window argument.

We have proved:

> **Theorem 6.1 — critical-resolution square forcing.**  Under the v154
> first-failure representation (1.1)--(1.2), with the inherited buffered
> shrinking-window and four-contact hypotheses, there exist universal
> constants `K,eta>0` such that
> \[
> \omega_1(h_n;K S_n/A_n)\le\eta
> \]
> along any infinite subsequence forces actual squares along that subsequence.

Equivalently:

> **Corollary 6.2 — forced critical roughness.**  A square-free tail must
> satisfy
> \[
> \boxed{
> \omega_1(h_n;K S_n/A_n)>\eta
> }
> \]
> for all sufficiently large `n`.

This is the first quantitative horizontal localization of the v154
concentration branch.

---

# 7. The critical zoom

Corollary 6.2 supplies points `t_n,t_n'` with

\[
|t_n-t_n'|\le K\varepsilon_n,
\qquad
|h_n(t_n)-h_n(t_n')|\ge\eta.
\tag{7.1}
\]

Set

\[
\rho_n=\varepsilon_n=\frac{S_n}{A_n}
\tag{7.2}
\]

and introduce the child coordinate

\[
t=t_n+\rho_n s.
\tag{7.3}
\]

Define the child phase normalized by the first-failure mass:

\[
\widehat F_n(s)
=
\frac{F_n(t_n+\rho_n s)-F_n(t_n)}{S_n}.
\tag{7.4}
\]

## 7.1 Exact parent-log asymptotic on the child window

Write

\[
\lambda_n=\frac{2B_n}{A_n}.
\tag{7.5}
\]

Then

\[
L_n'(t)=\frac{A_n}{1-\lambda_n t}.
\tag{7.6}
\]

Since `rho_n=S_n/A_n`, Taylor expansion of the **exact** logarithm gives,
uniformly for bounded `s`,

\[
\frac{L_n(t_n+\rho_n s)-L_n(t_n)}{S_n}
=
\frac{s}{1-\lambda_n t_n}
+O(\lambda_n\rho_n s^2).
\tag{7.7}
\]

On the fixed profile interval,

\[
\lambda_n t_n\to0,
\qquad
\lambda_n\rho_n
=
2\frac{B_n}{A_n}\frac{S_n}{A_n}
\to0.
\tag{7.8}
\]

Therefore

\[
\boxed{
\frac{L_n(t_n+\rho_n s)-L_n(t_n)}{S_n}
\to s
}
\tag{7.9}
\]

uniformly on compact `s`-intervals.

Using (1.1),

\[
\boxed{
\widehat F_n(s)
=
 s+
 \widehat h_n(s)
 +o(1),
}
\tag{7.10}
\]

where

\[
\widehat h_n(s)
=
h_n(t_n+\rho_n s)-h_n(t_n),
\qquad
|\widehat h_n(s)|\le2.
\tag{7.11}
\]

The second point in (7.1) has child coordinate

\[
|s_n'|\le K
\tag{7.12}
\]

and satisfies

\[
|\widehat h_n(s_n')|\ge\eta.
\tag{7.13}
\]

Thus the child residual has a fixed nonzero visible excursion on a fixed
bounded child window.

## 7.2 What changes at this zoom

Before the zoom,

\[
S_n/A_n\to0,
\]

so the residual is subleading relative to the parent log slope.

After the zoom, the parent log variation across one child unit is

\[
A_n\rho_n=S_n.
\tag{7.14}
\]

The residual variation is also `O(S_n)`.

Hence the ratio is now order one:

\[
\boxed{
\frac{\text{residual phase scale}}
{\text{parent-log phase scale on child window}}
\asymp1.
}
\tag{7.15}
\]

The moving-log perturbative expansion has reached its natural endpoint.

---

# 8. Collapse of the perturbative concentration cascade

v154 described the surviving branch as an infinite-depth concentration
cascade.  That description remains possible for a completely arbitrary
continuous child profile, but v155 shows that it is **not** an infinite-depth
cascade inside the subleading moving-log normal form.

There are only two possibilities at the v154 first failure:

1. the residual is controlled at its critical resolution `S_n/A_n`; then
   Theorem 6.1 forces a square;
2. the residual is not controlled there; then Corollary 6.2 supplies a child
   window of relative width `O(S_n/A_n)` on which the residual and parent log
   already have the same phase size.

Therefore:

\[
\boxed{
\text{no square-free sequence can remain in the regime }
S_{\rm child}/A_{\rm child}\to0
\text{ through an unlimited chain of first-failure zooms.}
}
\tag{8.1}
\]

A square-free branch reaches a balanced profile before another perturbative
moving-log level can be justified.

This corrects the most pessimistic reading of v154 Section 7.

The unresolved branch is now better described as

\[
\boxed{
\text{balanced rough high-phase profile}
}
\tag{8.2}
\]

rather than

\[
\text{infinite subleading moving-log concentration tower}.
\]

---

# 9. Relation to Chebyshev alternation

The v154 choice of a best quadratic was more useful than previously noted.
Because zero is a best quadratic approximant to `h_n`, the residual has four
alternating extremal contacts (1.3)--(1.4).

This gives a canonical packet skeleton:

\[
[x_{0,n},x_{1,n}],
\quad
[x_{1,n},x_{2,n}],
\quad
[x_{2,n},x_{3,n}].
\tag{9.1}
\]

Across each interval the residual changes by exactly `2` in normalized units.

At least one of the following must occur:

- these transitions are broad enough that their third-difference content is
  stable under `O(S_n/A_n)` parameter motion, and Theorem 6.1 captures the
  lattice;
- one or more transitions contain a subinterval of width `O(S_n/A_n)` with a
  fixed residual change, producing the critical zoom directly.

Thus the alternation points provide a concrete deterministic way to seed the
next extraction algorithm.  There is no need to search an arbitrary packet
tree first.

---

# 10. A useful new numerical diagnostic

For computations, define the dimensionless critical roughness statistic

\[
\boxed{
\mathcal R_n(K)
=
\omega_1\!\left(h_n;K\frac{S_n}{A_n}\right).
}
\tag{10.1}
\]

The v155 theorem says that a candidate square-free first-failure sequence
must keep

\[
\mathcal R_n(K)\ge\eta.
\tag{10.2}
\]

This is much more informative than simply observing failure of
Arzela--Ascoli equicontinuity.

A numerical profile with

\[
\mathcal R_n(K)\to0
\tag{10.3}
\]

is already on the square-forcing side of the v155 criterion, regardless of
whether the profiles converge globally.

Conversely, if (10.2) persists, the centers of the maximizing pairs give the
critical child windows automatically.

---

# 11. What v155 closes

### Closed: arbitrary horizontal depth inside the subleading log normal form

The first-failure residual has a canonical critical horizontal scale
`S_n/A_n`.  It cannot continue to concentrate through arbitrarily many
subleading moving-log levels without first reaching that scale.

### Closed: need for full equicontinuity in the v154 compact branch

Global Arzela--Ascoli control is stronger than necessary.  It is enough to
control the residual at the single shrinking resolution `O(S_n/A_n)`.

### Closed: abstract packet location

The critical roughness statistic and the Chebyshev alternation skeleton give
explicit candidate windows.

### Closed: concern that `B_n/A_n` might mask the critical scale

Using exact pure-log surface coordinates removes the larger deterministic
`O(B_n/A_n)` leading-surface drift before comparing with `S_n/A_n`.

---

# 12. What remains open

## I. Balanced rough profile classification

After the critical zoom the normalized phase has the form

\[
\widehat F_n(s)=s+\widehat h_n(s)+o(1),
\qquad
\|\widehat h_n\|_\infty\le2,
\tag{12.1}
\]

with a fixed nontrivial residual excursion on a bounded interval.

The perturbation is no longer small.  A compact limit can therefore be a
finite-pole shifted logarithm, an affine profile with a changed slope, or a
nonexceptional profile.  Only the last branch is already closed by v149.

A quantitative theorem for sequences that remain a definite distance from
the affine/log exceptional manifold would be valuable here.

## II. Balanced noncompactness

The child profiles `\widehat h_n` can still fail equicontinuity.  That is now
a rough-profile concentration problem at a **single amplitude scale**, not a
moving-log jet problem.

## III. Finite-pole exceptional transition

A child profile may approach

\[
a\log|s-b|+c
\tag{12.2}
\]

with `b` at finite child distance.  The exact nested-log law from v152 should
be compared with the parent model at the critical overlap, where their phase
errors are now order one rather than `o(1)` relative to the child amplitude.
This is outside the v153 stable-coherence theorem as currently stated.

## IV. Bounded phase packets and general Jordan transfer

The earlier bounded-mass and all-return/backtracking issues remain inherited.

---

# 13. Recommended v156 target

The next target should be the **balanced exceptional manifold**, not another
moving-pole Taylor scale.

A promising formulation is a quantitative distance

\[
\boxed{
\beta_{\mathcal E}(f;J)
=
\inf_{e\in\mathcal E}
\|f-e\|_{L^\infty(J)},
}
\tag{13.1}
\]

where

\[
\mathcal E
=
\{at+b\}
\cup
\{a\log|t-b|+c:\ b\notin J\}.
\tag{13.2}
\]

Then seek a Reifenberg-style alternative on the critical child window:

1. if `beta_E` is bounded below at a phase-visible scale, prove a quantitative
   degree theorem without requiring convergence;
2. if `beta_E -> 0`, compare the best exceptional models on overlapping child
   intervals and derive a finite-scale coherence law;
3. if that coherence fails only in windows of width comparable to the child
   lattice mesh, isolate a terminal finite-lattice problem.

This would unify the affine and finite-pole logarithmic branches instead of
restarting a separate Taylor hierarchy.

---

# 14. Verification

`code/verify_v155.py` checks:

1. the exact identity (2.4) between third differences and vertical `Q` motion;
2. annihilation of all quadratics by the third-difference witness;
3. exact shifted-log critical-zoom asymptotics over several moving-pole
   sequences;
4. the scaling `rho_n=S_n/A_n` and the fact that parent-log phase variation is
   asymptotic to `S_n` there;
5. stability of `Q` under small sample-coordinate perturbations for random
   continuous piecewise-linear profiles, compared with the `4 omega_1` bound;
6. toy concentrated residuals showing that the v155 roughness statistic stays
   order one precisely when the packet width is `O(S_n/A_n)` or smaller;
7. a smooth residual family for which the critical roughness tends to zero,
   illustrating the square-forcing side of Theorem 6.1.

All checks pass.

---

# 15. Claim boundary

## Established in v155

Subject to the inherited v149--v154 shrinking-window, lattice, and
four-contact profile hypotheses:

- exact identification of third finite differences with vertical displacement
  of the flattened normal functional;
- a quantitative third-difference witness from degree-two approximation;
- use of exact pure-log surface coordinates to remove `O(B/A)` drift;
- the critical-resolution square-forcing theorem at horizontal scale `S/A`;
- forced `O(1)` residual roughness at that scale in every square-free tail;
- the critical zoom formula (7.10);
- collapse of the putative infinite **perturbative moving-log** cascade to a
  balanced profile after one canonical zoom;
- Chebyshev alternation as a deterministic packet skeleton.

## Inherited and used

- v149 shrinking-window phase-lattice coordinates and Brouwer capture;
- v150--v151 exceptional tangent and cubic resonance calculations;
- v152 exact shifted-log flattening and lattice-error estimates;
- v153 exact nested-log transport and overlap coherence;
- v154 quadratic quotient normalization and first-fit-failure representation.

## Not established

- exclusion of arbitrary balanced noncompact profile sequences;
- a quantitative degree theorem separated from the full affine/log
  exceptional manifold;
- finite-scale coherence of finite-pole exceptional fits at order-one overlap
  error;
- exclusion of bounded terminal phase packets;
- unconditional transfer to every Jordan boundary without the inherited
  all-return/backtracking hypotheses;
- the full Toeplitz square-peg conjecture.
