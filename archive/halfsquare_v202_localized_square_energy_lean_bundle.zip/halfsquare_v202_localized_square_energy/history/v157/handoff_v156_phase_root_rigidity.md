# Project Handoff v156: Phase-Root Triangularization and C0 Exceptional Rigidity

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v155 reduced the surviving moving-log branch to a balanced critical profile.  On a
child window of width

\[
\rho_n=\frac{S_n}{A_n},
\]

a square-free first-failure sequence has normalized phase

\[
\widehat F_n(s)
=
\frac{F_n(t_n+\rho_n s)-F_n(t_n)}{S_n}
=
s+\widehat h_n(s)+o(1),
\tag{0.1}
\]

with

\[
S_n\to\infty,
\qquad
\|\widehat h_n\|_\infty\le 2,
\tag{0.2}
\]

and with a fixed nontrivial residual excursion on a bounded child interval.
The perturbation is now order one, so the v152--v155 small-residual
linearization is no longer the correct tool.

v156 introduces a different exact coordinate system for the balanced regime.
For a **continuous strictly monotone** profile `f`, invert phase:

\[
g=f^{-1}.
\tag{0.3}
\]

Use the first two relative phases themselves as coordinates.  If

\[
x=f(u_0),
\qquad
f(u_1)=x+y_1,
\qquad
f(u_2)=x+y_2,
\qquad
0<y_1<y_2,
\tag{0.4}
\]

then the parallelogram relation on the four contact parameters forces

\[
u_3=u_0+u_2-u_1,
\tag{0.5}
\]

and therefore determines the fourth relative phase

\[
\boxed{
R_f(x;y_1,y_2)
=
f\!\left(g(x)+g(x+y_2)-g(x+y_1)\right)-x.
}
\tag{0.6}
\]

Equivalently, `R_f` is the unique number in `(0,y_2)` satisfying

\[
\boxed{
g(x)+g(x+y_2)=g(x+y_1)+g(x+R_f).}
\tag{0.7}
\]

In these coordinates the entire three-phase map becomes exactly triangular:

\[
\boxed{
H_f\circ\Theta_f(x,y_1,y_2)
=
\bigl(y_1,y_2,R_f(x;y_1,y_2)\bigr).
}
\tag{0.8}
\]

This has three consequences.

1. **Any base-phase drift of `R_f` gives a full-dimensional phase cell by a
   one-dimensional sign crossing.**  No derivative of `f` is required.
2. **If `R_f` never drifts with `x`, then `f` is exactly affine or shifted
   logarithmic.**  This gives a `C^0` exceptional classification in the
   strictly monotone category.
3. **For an exceptional shifted logarithm, the phase-root law depends on only
   one invariant:** the slope `beta` of the affine reciprocal slope `1/f'`.
   The pole position and additive phase offset cancel exactly.

The exceptional phase surfaces are

\[
\boxed{
\Sigma_\beta:
\quad
 e^{\beta y_1}+e^{\beta y_3}=1+e^{\beta y_2},
}
\tag{0.9}
\]

with the continuous affine limit

\[
\boxed{
\Sigma_0:\quad y_1+y_3=y_2.
}
\tag{0.10}
\]

For fixed `0<y_1<y_2`, the exceptional root

\[
\boxed{
R_\beta(y_1,y_2)
=
\begin{cases}
\displaystyle
\frac1\beta
\log\!\left(1+e^{\beta y_2}-e^{\beta y_1}\right),&\beta\ne0,\\[3mm]
y_2-y_1,&\beta=0,
\end{cases}
}
\tag{0.11}
\]

is **strictly increasing in `beta`**.  In particular

\[
\boxed{
\left.\frac{\partial R_\beta}{\partial\beta}\right|_{\beta=0}
=
y_1(y_2-y_1)>0.
}
\tag{0.12}
\]

Thus the affine/log transition is well-conditioned in the invariant `beta`,
even though the raw pole coordinate becomes ill-conditioned as the pole goes
to infinity.

The practical v156 conclusion is:

> **Balanced monotone C0 theorem.**  Let a subsequence of critical child
> profiles converge uniformly to a continuous strictly monotone profile `f`
> on a buffered interval.  If `f` is not affine or shifted logarithmic, then
> the inherited high-phase lattice argument forces actual squares.  No `C^1`
> convergence and no Jacobian are needed.

Moreover, on any normalized bi-Lipschitz class, a fixed positive uniform
distance from the exceptional family yields a **uniform positive root-drift
margin** by compactness.  Hence a square-free, balanced, bi-Lipschitz tail
must approach the affine/log family in `C^0`.

This is the first nonperturbative coherence theorem at the v155 critical
scale.

The main remaining obstruction is no longer an arbitrary finite-pole drift.
It is:

\[
\boxed{
\text{balanced profiles with no usable monotone inverse chart,}
}
\tag{0.13}
\]

including strongly backtracking or noncompact phase profiles.  The natural
v157 target is to replace the ordinary inverse `g=f^{-1}` by first/last phase
crossing selections and determine whether discontinuities of those selections
already force a lattice cell.

---

# 1. The balanced phase map inherited from v149

For a profile `f` on an interval `I`, write

\[
u_0=v-a,
\qquad
u_1=v+b,
\qquad
u_2=v+a,
\qquad
u_3=v-b,
\tag{1.1}
\]

with

\[
a>0,
\qquad
|b|<a,
\tag{1.2}
\]

and all four `u_j` in `I`.

The relative phase map is

\[
\boxed{
H_f(a,b,v)
=
\begin{pmatrix}
f(u_1)-f(u_0)\\
f(u_2)-f(u_0)\\
f(u_3)-f(u_0)
\end{pmatrix}.
}
\tag{1.3}
\]

At a high-phase scale `S_n`, the actual square equations have the form

\[
G_n=2\pi m,
\qquad
m\in\mathbb Z^3,
\tag{1.4}
\]

with

\[
\frac{G_n}{S_n}=H_{f_n}+o(1)
\tag{1.5}
\]

uniformly on a fixed physical parameter box.

The normalized phase lattice therefore has mesh

\[
\frac{2\pi}{S_n}\to0.
\tag{1.6}
\]

v149 used a regular `C^1` point of `H_f` to create a degree-protected image
ball.  v156 replaces that regular-point argument, for monotone continuous
profiles, by an exact triangular chart.

---

# 2. Exact phase-root coordinates

Assume first that `f:I->J` is continuous and strictly increasing.  The
strictly decreasing case is reduced to this one by reversing phase
orientation.

Let

\[
g=f^{-1}:J\to I.
\tag{2.1}
\]

Choose phase variables satisfying

\[
x,
\quad x+y_1,
\quad x+y_2\in J,
\qquad
0<y_1<y_2.
\tag{2.2}
\]

Set

\[
u_0=g(x),
\qquad
u_1=g(x+y_1),
\qquad
u_2=g(x+y_2).
\tag{2.3}
\]

Because `g` is strictly increasing,

\[
u_0<u_1<u_2.
\tag{2.4}
\]

Define

\[
\boxed{
u_3=u_0+u_2-u_1.}
\tag{2.5}
\]

Then

\[
u_0<u_3<u_2.
\tag{2.6}
\]

Hence `u_3` lies in the same parameter interval and its relative phase is
well-defined:

\[
\boxed{
R_f(x;y_1,y_2)=f(u_3)-x.
}
\tag{2.7}
\]

Since `u_0<u_3<u_2`,

\[
0<R_f(x;y_1,y_2)<y_2.
\tag{2.8}
\]

Applying `g` to (2.7) gives the equivalent root equation

\[
\boxed{
g(x)+g(x+y_2)-g(x+y_1)-g(x+R_f)=0.}
\tag{2.9}
\]

The fourth root is unique because `g` is strictly increasing.

## 2.1 Recovering the physical square-shape variables

Set

\[
v=\frac{u_0+u_2}{2},
\qquad
a=\frac{u_2-u_0}{2},
\tag{2.10}
\]

and

\[
b=\frac{u_1-u_3}{2}.
\tag{2.11}
\]

Then

\[
u_0=v-a,
\quad
u_2=v+a,
\tag{2.12}
\]

and because

\[
u_1+u_3=u_0+u_2=2v,
\tag{2.13}
\]

we also have

\[
u_1=v+b,
\qquad
u_3=v-b.
\tag{2.14}
\]

Thus `(x,y_1,y_2)` produces a valid physical triple `(a,b,v)`.

Define this coordinate map by

\[
\Theta_f(x,y_1,y_2)=(a,b,v).
\tag{2.15}
\]

On any compact admissible phase box, `Theta_f` is a homeomorphism onto its
image.  Its inverse is explicit:

\[
x=f(v-a),
\tag{2.16}
\]

\[
y_1=f(v+b)-f(v-a),
\tag{2.17}
\]

\[
y_2=f(v+a)-f(v-a).
\tag{2.18}
\]

Therefore the three-phase map in these coordinates is exactly

\[
\boxed{
H_f\circ\Theta_f(x,y_1,y_2)
=
\left(y_1,y_2,R_f(x;y_1,y_2)\right).
}
\tag{2.19}
\]

No limiting argument, Taylor expansion, or differentiability is used.

This is the central v156 identity.

---

# 3. Root drift gives a robust three-dimensional phase cell

Fix an admissible pair `(y_1^*,y_2^*)`.  Suppose there are two base phases

\[
x^-<x^+
\tag{3.1}
\]

such that

\[
R_f(x^-;y_1^*,y_2^*)
e R_f(x^+;y_1^*,y_2^*).
\tag{3.2}
\]

Reverse the two faces if necessary and assume

\[
R_f(x^-;y_1^*,y_2^*)
<
R_f(x^+;y_1^*,y_2^*).
\tag{3.3}
\]

Set

\[
\Delta
=
R_f(x^+;y_1^*,y_2^*)
-
R_f(x^-;y_1^*,y_2^*)
>0.
\tag{3.4}
\]

By continuity of `R_f`, there is a rectangle `B` around
`(y_1^*,y_2^*)` such that for every `(y_1,y_2) in B`,

\[
R_f(x^+;y_1,y_2)
-
R_f(x^-;y_1,y_2)
>\frac{\Delta}{2}.
\tag{3.5}
\]

Choose numbers `r_-<r_+` lying uniformly between the two face values, for
example after shrinking `B`:

\[
R_f(x^-;y_1,y_2)<r_-
<r_+<R_f(x^+;y_1,y_2)
\tag{3.6}
\]

for every `(y_1,y_2) in B`.

Then every target

\[
(y_1^{\rm tar},y_2^{\rm tar},y_3^{\rm tar})
\in
B\times(r_-,r_+)
\tag{3.7}
\]

is attained by `H_f`.

Indeed, use the rectangular domain

\[
D=[x^-,x^+]\times B
\tag{3.8}
\]

in the phase-root coordinates.  The map

\[
\mathcal M_f
=
H_f\circ\Theta_f
-
(y_1^{\rm tar},y_2^{\rm tar},y_3^{\rm tar})
\tag{3.9}
\]

has the exact form

\[
\mathcal M_f
=
\left(
 y_1-y_1^{\rm tar},
 y_2-y_2^{\rm tar},
 R_f(x;y_1,y_2)-y_3^{\rm tar}
\right).
\tag{3.10}
\]

The first coordinate has opposite signs on the two `y_1` faces, the second
has opposite signs on the two `y_2` faces, and the third has opposite signs
on the two `x` faces.  The Poincare--Miranda theorem therefore gives a zero.

Thus:

> **Theorem 3.1 — root-drift cell theorem.**  For a continuous strictly
> monotone profile, any nonzero base-phase drift of one root function
> `R_f(.;y_1,y_2)` creates a full three-dimensional open phase cell in the
> image of `H_f`.

## 3.1 Robustness under arbitrary uniform profile perturbations

This cell is stronger than mere interior of the image because its boundary
signs have a positive margin.

Let `f_n` be any continuous profiles, not necessarily monotone, satisfying

\[
\|f_n-f\|_{L^\infty(I_+)}\to0
\tag{3.11}
\]

on a buffered interval containing the four contact coordinates generated by
`Theta_f(D)`.

For any fixed physical `(a,b,v)`, each relative phase difference changes by
at most

\[
2\|f_n-f\|_\infty.
\tag{3.12}
\]

Therefore

\[
\boxed{
\|H_{f_n}\circ\Theta_f-H_f\circ\Theta_f\|_\infty
\le 2\|f_n-f\|_\infty.
}
\tag{3.13}
\]

Once the right-hand side is smaller than the Poincare--Miranda face margin,
the same signs persist for `H_{f_n}`.  Thus every target in a slightly
smaller phase cell is still attained.

This is important for the Toeplitz application: the **limit** profile must be
strictly monotone to construct the chart, but the approximating child phases
do not have to be monotone.  The inherited v149 backtracking machinery can
therefore still be used.

---

# 4. If there is no root drift, the profile is exceptional

We now classify continuous strictly monotone profiles for which

\[
R_f(x;y_1,y_2)
\tag{4.1}
\]

is independent of `x` for every sufficiently small admissible pair
`0<y_1<y_2`.

Write again

\[
g=f^{-1}.
\tag{4.2}
\]

For a phase shift `y`, define the translation conjugate

\[
\boxed{
T_y(t)=g(g^{-1}(t)+y).
}
\tag{4.3}
\]

This is the action, in parameter coordinates, of adding `y` units of phase.
The maps satisfy the local one-parameter group law

\[
T_y\circ T_z=T_{y+z}=T_z\circ T_y.
\tag{4.4}
\]

Set

\[
U_y(t)=T_y(t)-t.
\tag{4.5}
\]

## 4.1 Root independence becomes closure under differences

If `R_f` is independent of base phase, then (2.9) gives, for each
`0<y_1<y_2`, a number `R=R(y_1,y_2)` such that

\[
T_{y_2}(t)-T_{y_1}(t)=T_R(t)-t
\tag{4.6}
\]

for every `t` in the common local domain.  Equivalently,

\[
\boxed{
U_{y_2}-U_{y_1}=U_R.
}
\tag{4.7}
\]

Fix a reference parameter `t_0` and define

\[
c(y)=U_y(t_0)=T_y(t_0)-t_0.
\tag{4.8}
\]

Because `g` is strictly monotone, `c(y)` is continuous and strictly
monotone for small positive `y`.  Evaluating (4.7) at `t_0` gives

\[
c(y_2)-c(y_1)=c(R).
\tag{4.9}
\]

Reparameterize the family by `c` instead of `y`:

\[
V_c(t)=U_{y(c)}(t).
\tag{4.10}
\]

Then (4.7)--(4.9) become

\[
\boxed{
V_{c_2}-V_{c_1}=V_{c_2-c_1}.
}
\tag{4.11}
\]

Hence, for small positive `c,d`,

\[
V_{c+d}=V_c+V_d.
\tag{4.12}
\]

Continuity of the family in `c` gives the local Cauchy conclusion

\[
\boxed{
V_c(t)=cW(t)
}
\tag{4.13}
\]

for a continuous function `W`, normalized by

\[
W(t_0)=1.
\tag{4.14}
\]

Thus every phase translation has the form

\[
\boxed{
T_{y(c)}(t)=t+cW(t).
}
\tag{4.15}
\]

## 4.2 Commuting translations force `W` to be affine

The original phase translations commute.  Their composition must again be a
member of the same one-parameter family.  Therefore, for small `c,d`,

\[
T_c\circ T_d=T_e
\tag{4.16}
\]

for some `e=e(c,d)`.

Using (4.15),

\[
t+dW(t)+cW(t+dW(t))
=
t+eW(t).
\tag{4.17}
\]

Hence

\[
W(t+dW(t))=\lambda(d)W(t),
\tag{4.18}
\]

where the factor is independent of `t`.  Evaluating at `t=t_0` gives

\[
\lambda(d)=W(t_0+d).
\tag{4.19}
\]

After translating `t_0` to zero, write `W(0)=1`.  Then

\[
\boxed{
W(t+dW(t))=W(t)W(d).
}
\tag{4.20}
\]

Now use commutativity at the reference point:

\[
T_c(T_d(0))=T_d(T_c(0)).
\tag{4.21}
\]

Since `T_d(0)=d` and `T_c(0)=c`,

\[
d+cW(d)=c+dW(c).
\tag{4.22}
\]

Thus

\[
\frac{W(c)-1}{c}
=
\frac{W(d)-1}{d}
\tag{4.23}
\]

for all small positive `c,d`.  There is a constant `kappa` such that

\[
W(c)=1+\kappa c
\tag{4.24}
\]

near zero.

Equation (4.20) propagates this identity through the connected local domain.
Indeed, for small positive `d`,

\[
W(t+dW(t))
=W(t)(1+\kappa d)
=
W(t)+\kappa(dW(t)).
\tag{4.25}
\]

Since

\[
t+dW(t)-t=dW(t),
\tag{4.26}
\]

we obtain

\[
W(t')-W(t)=\kappa(t'-t)
\tag{4.27}
\]

for all sufficiently nearby `t'` on one side of `t`.  Connectedness gives

\[
\boxed{
W(t)=1+\kappa(t-t_0).
}
\tag{4.28}
\]

Thus every phase translation `T_y` is affine in the parameter variable.

## 4.3 Solving the remaining one-parameter group law

Return to

\[
c(y)=T_y(t_0)-t_0.
\tag{4.29}
\]

Using (4.28) in `T_{y+z}=T_y\circ T_z` and evaluating at `t_0` gives

\[
\boxed{
c(y+z)=c(y)+c(z)+\kappa c(y)c(z).}
\tag{4.30}
\]

If `kappa=0`, continuity gives

\[
c(y)=Cy.
\tag{4.31}
\]

Therefore

\[
g(x)=\alpha+\gamma x,
\tag{4.32}
\]

and `f` is affine.

If `kappa != 0`, define

\[
d(y)=1+\kappa c(y).
\tag{4.33}
\]

Then (4.30) becomes

\[
d(y+z)=d(y)d(z).
\tag{4.34}
\]

The positive continuous solutions are

\[
d(y)=e^{\beta y}
\tag{4.35}
\]

for a constant `beta`.  Hence

\[
c(y)=\frac{e^{\beta y}-1}{\kappa},
\tag{4.36}
\]

and therefore

\[
\boxed{
g(x)=\alpha+\gamma e^{\beta x}.}
\tag{4.37}
\]

Inverting gives

\[
\boxed{
f(t)=a\log|t-b|+c}
\tag{4.38}
\]

on the relevant component, with the pole `b` outside the profile interval.

We have proved:

> **Theorem 4.1 — C0 monotone exceptional classification.**  Let `f` be a
> continuous strictly monotone profile on an interval.  The following are
> equivalent locally, and therefore on connected buffered subintervals:
>
> 1. every phase-root function `R_f(x;y_1,y_2)` is independent of the base
>    phase `x`;
> 2. the triangularized phase map has no root-drift cell;
> 3. `f` is affine or shifted logarithmic.

Combining with Theorem 3.1:

> **Corollary 4.2 — interior-or-exceptional dichotomy.**  A continuous
> strictly monotone profile is either affine/shifted-logarithmic or its
> three-phase map contains a robust full-dimensional phase cell.

This is the `C^0` replacement, in the monotone category, for the `C^1`
Jacobian classification used in v149.

---

# 5. The exceptional output family is only one-dimensional

The preceding classification identifies the same two function families as
v149/v152.  The phase-root coordinates show that most of the apparent log
parameters are irrelevant to the relative phase image.

Consider

\[
f(t)=a\log|t-b|+c,
\qquad a\ne0,
\tag{5.1}
\]

on a component avoiding the pole.

Its inverse has the form

\[
g(x)=b+\sigma e^{(x-c)/a},
\qquad \sigma\ne0.
\tag{5.2}
\]

Set

\[
\boxed{\beta=\frac1a.}
\tag{5.3}
\]

Then the root equation (2.9) factors as

\[
\sigma e^{\beta(x-c)}
\left(
1+e^{\beta y_2}-e^{\beta y_1}-e^{\beta y_3}
\right)=0.
\tag{5.4}
\]

The factors containing the base phase `x`, pole `b`, branch scale `sigma`,
and offset `c` cancel.

Hence the phase image is contained in the surface

\[
\boxed{
\Sigma_\beta:
\quad
1+e^{\beta y_2}
-e^{\beta y_1}
-e^{\beta y_3}=0.
}
\tag{5.5}
\]

The root is

\[
\boxed{
R_\beta(y_1,y_2)
=
\frac1\beta
\log\left(1+e^{\beta y_2}-e^{\beta y_1}\right)
}
\tag{5.6}
\]

for `beta != 0`.

The affine limit is obtained continuously as `beta -> 0`:

\[
\boxed{
R_0(y_1,y_2)=y_2-y_1.
}
\tag{5.7}
\]

Thus the entire balanced exceptional **output** manifold is a one-parameter
family

\[
\boxed{\{\Sigma_\beta:\beta\in\mathbb R\}.}
\tag{5.8}
\]

This is substantially smaller than the three-parameter function family
`a log|t-b|+c`.

## 5.1 Identification with the v153 reciprocal-slope invariant

For an exceptional profile,

\[
\frac1{f'(t)}=\alpha+\beta t.
\tag{5.9}
\]

The coefficient `beta` in (5.9) is exactly the `beta=1/a` appearing in the
phase surface (5.5).

For the v152 shifted logarithm

\[
\mathfrak L_{A,B}(t)
=-\frac{A^2}{2B}
\log\left(1-\frac{2B}{A}t\right),
\tag{5.10}
\]

one has

\[
\frac1{\mathfrak L_{A,B}'(t)}
=
\frac1A-\frac{2B}{A^2}t.
\tag{5.11}
\]

Therefore

\[
\boxed{
\beta=-\frac{2B}{A^2}=-\frac1M,
\qquad
M=\frac{A^2}{2B}.
}
\tag{5.12}
\]

This is precisely the invariant tracked by the v153 nested-window coherence
theorem.

The v156 phase-root law therefore gives a nonperturbative interpretation of
that invariant:

\[
\boxed{
\beta
=
\text{the unique parameter of the exceptional relative-phase surface.}
}
\tag{5.13}
\]

The moving pole changes the domain chart but not the exceptional phase
surface.

---

# 6. One root measurement identifies beta

Fix

\[
0<y_1<y_2.
\tag{6.1}
\]

The exceptional root can be characterized without logarithms by

\[
\boxed{
\int_0^{R_\beta}e^{\beta t}\,dt
=
\int_{y_1}^{y_2}e^{\beta t}\,dt.
}
\tag{6.2}
\]

For `beta=0`, this reduces to equality of lengths and gives

\[
R_0=y_2-y_1.
\tag{6.3}
\]

## 6.1 Strict monotonicity in beta

Differentiate (6.2) implicitly.  Since

\[
\partial_R\int_0^R e^{\beta t}dt=e^{\beta R}>0,
\tag{6.4}
\]

we obtain

\[
\boxed{
\frac{dR_\beta}{d\beta}
=
\frac{
\displaystyle
\int_{y_1}^{y_2}t e^{\beta t}dt
-
\int_0^{R_\beta}t e^{\beta t}dt
}{e^{\beta R_\beta}}.
}
\tag{6.5}
\]

The numerator is strictly positive.

If `R_\beta <= y_1`, the interval `[y_1,y_2]` lies strictly to the right of
`[0,R_\beta]`, and the two intervals have equal positive `e^{beta t}` mass by
(6.2).  Their first moments are therefore strictly ordered.

If `R_\beta>y_1`, the common overlap `[y_1,R_\beta]` cancels from both the
mass equality and the first-moment difference.  Equation (6.2) then gives

\[
\int_0^{y_1}e^{\beta t}dt
=
\int_{R_\beta}^{y_2}e^{\beta t}dt.
\tag{6.6}
\]

Every point in the right tail is larger than every point in the left tail,
so

\[
\int_{R_\beta}^{y_2}t e^{\beta t}dt
>
\int_0^{y_1}t e^{\beta t}dt.
\tag{6.7}
\]

Thus in all cases

\[
\boxed{
\frac{dR_\beta}{d\beta}>0.
}
\tag{6.8}
\]

Therefore one root value determines `beta` uniquely.

## 6.2 The affine limit is not singular in beta

Expanding (5.6) at `beta=0` gives

\[
\boxed{
R_\beta(y_1,y_2)
=
(y_2-y_1)
+
\beta y_1(y_2-y_1)
+O(\beta^2).
}
\tag{6.9}
\]

Hence

\[
\boxed{
\left.\frac{dR_\beta}{d\beta}\right|_{\beta=0}
=y_1(y_2-y_1)>0.
}
\tag{6.10}
\]

The raw pole `b` is ill-conditioned in the affine limit, but the invariant
`beta` is not.

This is the correct balanced-scale coherence coordinate.

## 6.3 Effective beta for a general monotone profile

Because `beta -> R_beta(y_1,y_2)` is strictly increasing from `0` to `y_2`
as `beta` runs from `-\infty` to `+\infty`, every root

\[
0<R_f(x;y_1,y_2)<y_2
\tag{6.11}
\]

has a unique effective parameter

\[
\boxed{
\beta_f(x;y_1,y_2)
:=
R_{\bullet}(y_1,y_2)^{-1}
\bigl(R_f(x;y_1,y_2)\bigr).
}
\tag{6.12}
\]

For an exceptional profile this is independent of `x,y_1,y_2` and equals the
true reciprocal-slope coefficient `beta`.

For a general profile, any visible drift of this effective `beta` in `x`
produces root drift and therefore a full phase cell by Theorem 3.1.

This gives a finite-scale diagnostic that remains meaningful at order-one
balanced amplitude; no small perturbation parameter is involved.

---

# 7. Quantitative separation from the exceptional family on conditioned classes

v155 proposed the distance

\[
\beta_{\mathcal E}(f;I)
=
\inf_{e\in\mathcal E}
\|f-e\|_{L^\infty(I)},
\tag{7.1}
\]

where

\[
\mathcal E
=
\{at+b\}
\cup
\{a\log|t-b|+c:\ b\notin I\}.
\tag{7.2}
\]

In full `C(I)` this distance alone does not give a uniform degree radius;
profiles can lose all horizontal conditioning.  On a normalized
bi-Lipschitz class, however, compactness supplies the missing quantitative
statement.

Fix a compact interval `I` and constants

\[
0<m<M<\infty.
\tag{7.3}
\]

Let `C_{m,M}` be the normalized class of continuous increasing profiles with
`f(t_*)=0` at one fixed base point and

\[
\boxed{
m(y-x)\le f(y)-f(x)\le M(y-x)}
\tag{7.4}
\]

for every `x<y` in `I`.

This family is compact in `C(I)` by Arzela--Ascoli, and the inverses are
uniformly Lipschitz on common interior phase intervals.

For a compact admissible configuration set `K` in
`(x,y_1,y_2)` coordinates, define the root-drift seminorm

\[
\boxed{
\Gamma_K(f)
=
\sup_{
(x_-,x_+,y_1,y_2)\in K
}
|R_f(x_+;y_1,y_2)-R_f(x_-;y_1,y_2)|.
}
\tag{7.5}
\]

Uniform convergence in `C_{m,M}` implies uniform convergence of inverses on
buffered phase intervals, and therefore continuity of `Gamma_K`.

Theorem 4.1 says that if all such root drifts vanish on the interior, the
profile lies in `E`.

A compactness contradiction therefore gives:

> **Theorem 7.1 — quantitative exceptional separation.**  Fix
> `delta>0`.  There exist a buffered admissible configuration scale
> `sigma>0` and a constant `c>0`, depending only on
> `(I,m,M,delta)`, such that every `f in C_{m,M}` satisfying
> 
> \[
> \operatorname{dist}_{\infty}(f,\mathcal E)\ge\delta
> \]
> 
> has a phase-root witness, staying at least `sigma` away from all domain
> degeneracies, with
> 
> \[
> \boxed{
> |R_f(x_+;y_1,y_2)-R_f(x_-;y_1,y_2)|\ge c.
> }
> \]

### Proof by contradiction

If no such `(sigma,c)` existed, choose a sequence `f_n in C_{m,M}` with

\[
\operatorname{dist}(f_n,\mathcal E)\ge\delta
\tag{7.6}
\]

but whose root drift tends to zero on every fixed compact admissible
configuration set.  By compactness, pass to

\[
f_n\to f\in C_{m,M}
\tag{7.7}
\]

uniformly.  The inverse functions converge uniformly on buffered phase
intervals, so every limiting root function is independent of base phase.
Theorem 4.1 gives

\[
f\in\mathcal E.
\tag{7.8}
\]

Then

\[
\operatorname{dist}(f_n,\mathcal E)
\le\|f_n-f\|_\infty\to0,
\tag{7.9}
\]

contradicting (7.6).

The theorem is nonconstructive in its constants, but it is enough for the
high-phase lattice argument.

---

# 8. Robust lattice capture without derivatives

Suppose a high-phase sequence has normalized profiles `f_n` with amplitude
`S_n -> \infty`, and suppose

\[
f_n\to f
\tag{8.1}
\]

uniformly on the buffered profile interval.

Assume the limit `f` is continuous, strictly monotone, and nonexceptional.
Theorem 3.1 produces a root-drift box `D` and a compact phase cell

\[
P\Subset H_f(\Theta_f(D))
\tag{8.2}
\]

with a positive Poincare--Miranda face margin.

The actual normalized phase map satisfies

\[
\frac{G_n}{S_n}
=
H_{f_n}+o(1)
\tag{8.3}
\]

uniformly on the corresponding physical parameter box.  By (3.13), after
composition with the fixed chart `Theta_f`, this is a uniform perturbation of

\[
(y_1,y_2,R_f).
\tag{8.4}
\]

The normalized lattice

\[
\frac{2\pi}{S_n}\mathbb Z^3
\tag{8.5}
\]

has mesh tending to zero.  Choose a lattice target in a smaller cell
`P' compactly contained in P`.  The geometric square-angle corrections are
also `o(1)` after division by `S_n`, exactly as in v149.

For all sufficiently large `n`, the perturbed Poincare--Miranda face signs
remain intact, so the exact normalized phase map attains that lattice target.
The inherited shrinking-window incidence theorem then gives an actual square.

Thus:

> **Theorem 8.1 — balanced monotone C0 square forcing.**  Under the inherited
> v149 shrinking-window/four-contact hypotheses, suppose the v155 critical
> child profiles have amplitude `S_n -> \infty` and converge uniformly on a
> buffered interval to a continuous strictly monotone profile `f`.  If `f` is
> neither affine nor shifted logarithmic, actual squares are forced along the
> subsequence.

This theorem does not assume `C^1` convergence and does not use the raw
Jacobian factorization.

## 8.1 Quantitative version for conditioned sequences

If the normalized child profiles remain in one class `C_{m,M}` and satisfy

\[
\operatorname{dist}(f_n,\mathcal E)\ge\delta>0,
\tag{8.6}
\]

then Theorem 7.1 gives a root-drift margin `c>0` independent of `n`.
The Poincare--Miranda cell can therefore be chosen with a uniform positive
phase thickness.  Since the lattice mesh is `2\pi/S_n -> 0`, square capture
follows directly for all sufficiently large `n`.

Hence:

\[
\boxed{
\text{square-free balanced bi-Lipschitz tail}
\Longrightarrow
\operatorname{dist}(f_n,\mathcal E)\to0.
}
\tag{8.7}
\]

This is the quantitative alternative proposed in v155, proved here on the
natural conditioned monotone class.

---

# 9. What happens to the finite-pole transition

v155 left a specific issue:

> a critical child profile may approach a finite-pole shifted logarithm, and
> the v153 small-overlap coherence estimate no longer applies because the
> parent error is order one at the child scale.

v156 does not eliminate a genuinely exceptional child profile, but it removes
most of the apparent parameter freedom.

For relative phase incidence, every affine/log child is represented by only
one number `beta`, through the surface `Sigma_beta`.

The pole position, additive phase offset, and multiplicative branch constant
of the inverse profile do **not** affect the surface.

Moreover, `beta` is recoverable from one root measurement and is
well-conditioned at the affine limit.

Thus the balanced exceptional transition should no longer be tracked as

\[
(a,b,c)\text{ moving independently}.
\tag{9.1}
\]

The correct output invariant is

\[
\boxed{\beta=\text{slope of }1/f'.}
\tag{9.2}
\]

Any visible base-phase variation in the effective `beta` produces a root
drift cell and therefore a square.

A square-free monotone exceptional limit must have one coherent constant
`beta` across the whole usable child window.

This is a nonperturbative analogue of the v153 coherence conclusion.

---

# 10. Relation to the v152 Jacobian factorization

v152 proved for `C^1` profiles with nonzero derivative that

\[
\det DH_f
=
2\prod_{j=0}^3 f'(u_j)
\left(
\frac1{f'(u_1)}
+
\frac1{f'(u_3)}
-
\frac1{f'(u_0)}
-
\frac1{f'(u_2)}
\right).
\tag{10.1}
\]

Thus everywhere rank loss is equivalent to affine reciprocal slope

\[
\frac1{f'(t)}=\alpha+\beta t.
\tag{10.2}
\]

v156 reaches the same invariant without derivatives.

For exceptional profiles, the root surface is `Sigma_beta`.  If `beta`
changes with base phase, the fourth-phase root changes and the image thickens
from a surface into a volume.

In smooth language, the infinitesimal version of that thickening is exactly
the nonzero reciprocal-slope parallelogram defect in (10.1).

So the two viewpoints fit together:

\[
\boxed{
\begin{array}{c}
\text{v152: infinitesimal defect of }1/f'\\
\Updownarrow\\
\text{v156: finite phase-root drift of }\beta.
\end{array}
}
\tag{10.3}
\]

The v156 formulation survives at `C^0` regularity as long as a monotone phase
inverse exists.

---

# 11. A practical diagnostic for computations

For a monotone numerical profile, choose a fixed phase pair

\[
0<y_1<y_2
\tag{11.1}
\]

well inside the available phase range.

For each admissible base phase `x`, compute

\[
R_f(x;y_1,y_2)
=
f\left(g(x)+g(x+y_2)-g(x+y_1)\right)-x.
\tag{11.2}
\]

Then define

\[
\boxed{
\mathcal D_f(y_1,y_2)
=
\operatorname{osc}_x R_f(x;y_1,y_2).
}
\tag{11.3}
\]

Any phase-visible lower bound

\[
\mathcal D_f(y_1,y_2)\ge c>0
\tag{11.4}
\]

is already a finite-size degree witness.

Alternatively invert the exceptional root law and compute

\[
\beta_f(x;y_1,y_2).
\tag{11.5}
\]

Then

\[
\operatorname{osc}_x\beta_f
\tag{11.6}
\]

measures failure of balanced exceptional coherence directly.

This statistic is preferable to fitting raw pole positions, because `beta`
remains well-conditioned as the exceptional model approaches the affine
limit.

---

# 12. What v156 closes

## Closed: derivative dependence for monotone compact limits

A continuous strictly monotone nonexceptional profile now gives a robust
three-dimensional phase cell without any derivative or Jacobian.

## Closed: apparent three-parameter freedom of balanced logs in output space

The exceptional relative-phase surface depends only on

\[
\beta=\text{slope of }1/f'.
\]

Pole location and phase offset cancel.

## Closed: affine-limit ill-conditioning of the relevant invariant

Although pole location diverges in the affine limit,

\[
\partial_\beta R_\beta|_{\beta=0}
=y_1(y_2-y_1)>0.
\]

Thus `beta` remains identifiable.

## Closed: quantitative separation on normalized bi-Lipschitz classes

A fixed `C^0` distance from the affine/log family gives a uniform root-drift
margin by compactness, hence a uniform phase cell and eventual lattice
capture.

## Closed: order-one beta drift on a monotone balanced window

Any visible drift of the effective exceptional parameter with base phase
produces a full-dimensional image cell.  A square-free monotone exceptional
limit must use one constant `beta`.

---

# 13. What remains open

## I. Balanced profiles without a usable monotone inverse chart

The critical child profile may backtrack in phase on every useful interval,
or may have no stable continuous monotone limit.  The exact inverse `g=f^{-1}`
then does not exist globally.

This is now the main v156 obstruction.

## II. First/last crossing triangularization

For a continuous phase excursion one can define first-hit and last-hit
selections of phase levels.  These selections are monotone as set-valued
objects but can jump when the profile backtracks.  It is not yet proved that
one can replace `g` by such selections while preserving a three-dimensional
Poincare--Miranda box.

## III. Jumping crossing selections

A discontinuity in a first-hit inverse corresponds to a parameter interval in
which the curve revisits lower phase before attaining the next level.  It may
itself provide the additional degree direction, but that has not been
established.

## IV. Noncompact balanced profiles

Even after the v155 critical zoom, a sequence may fail every compactness
criterion.  v156 handles conditioned monotone compact branches, not arbitrary
rough phase packets.

## V. Bounded terminal phase packets and Jordan transfer

The earlier bounded-mass/all-return issues remain inherited.  No claim here
removes those global topological obstructions.

---

# 14. Recommended v157 target

The strongest next target is a **crossing-selection extension of the
phase-root chart**.

For a continuous phase law `f` on a child interval with a large excursion,
choose a base phase range `[p,q]` and define first-hitting selections

\[
g_-(y)=\inf\{t:\ f(t)=y\},
\tag{14.1}
\]

and/or last-hitting selections

\[
g_+(y)=\sup\{t:\ f(t)=y\}.
\tag{14.2}
\]

Then study the generalized root relation

\[
g_\star(x)+g_\star(x+y_2)
-g_\star(x+y_1)
-g_\star(x+y_3)=0.
\tag{14.3}
\]

There are two possible outcomes.

1. **Continuous crossing selection.**  On a phase subinterval the selected
   inverse is continuous and strict.  Then the entire v156 triangularization
   applies verbatim, even if the original phase law backtracks between the
   selected contacts.
2. **Jumping crossing selection.**  Quantify the jump.  Try to show that a
   phase-visible jump produces a second independent contact choice and hence a
   full-dimensional lattice cell.  If the jump is subvisible, pass to a
   smaller phase interval and recover continuity.

A theorem of the form

\[
\boxed{
\text{continuous selected inverse}
\quad\text{or}\quad
\text{phase-visible crossing jump forces degree}
}
\tag{14.4}
\]

would remove the strict-monotonicity qualification from v156 and directly
attack the balanced rough branch left by v155.

---

# 15. Verification

`code/verify_v156.py` checks:

1. exact phase-root triangularization for a nonlinear monotone profile;
2. base-phase independence of the affine root law;
3. base-phase independence and exact formula for shifted logarithms;
4. visible root drift for a monotone nonexceptional cubic profile;
5. the robust Poincare--Miranda face margins under a small, deliberately
   oscillatory profile perturbation;
6. strict monotonicity of `R_beta(y_1,y_2)` over a large numerical beta range;
7. the affine-limit derivative
   `dR/dbeta = y_1(y_2-y_1)`;
8. recovery of `beta` from one root measurement by scalar inversion;
9. the v153 identity between `beta` and the reciprocal-slope coefficient for
   the exact shifted logarithm;
10. normalized lattice mesh entering a fixed root-drift phase cell as the
    high-phase amplitude tends to infinity.

All checks pass.

---

# 16. Claim boundary

## Established in v156

Subject to the inherited v149 physical/shrinking-window setup:

- exact phase-root coordinates for continuous strictly monotone profiles;
- exact triangularization `(y_1,y_2,R_f)` of the three-phase map;
- a robust Poincare--Miranda phase cell from any base-phase root drift;
- robustness of that cell under arbitrary small `C^0` perturbations of the
  profile, so approximating profiles need not themselves be monotone;
- `C^0` monotone exceptional classification: root independence if and only if
  affine/shifted-logarithmic;
- one-parameter exceptional phase surfaces `Sigma_beta`;
- exact cancellation of log pole and offset from the relative-phase surface;
- identification of `beta` with the slope of the reciprocal slope `1/f'`;
- strict monotonicity and affine-limit stability of the exceptional root
  `R_beta`;
- effective-beta diagnostics for general monotone profiles;
- compactness-based quantitative separation from the exceptional family on
  normalized bi-Lipschitz classes;
- balanced monotone `C^0` square forcing for nonexceptional compact limits.

## Inherited and used

- v149 exact three-phase lattice equations and shrinking-window capture;
- v149 all-return/backtracking transfer after a protected local degree cell is
  available;
- v152 reciprocal-slope exceptional classification in the `C^1` category;
- v152 exact shifted-log model;
- v153 reciprocal-slope invariant `beta` and nested-window coherence;
- v154 first-failure normalization;
- v155 critical scale `S/A` and balanced child reduction.

## Not established

- a phase-root triangularization for arbitrary nonmonotone continuous limits;
- exclusion of phase profiles whose every useful crossing selection jumps;
- arbitrary balanced noncompact sequences;
- bounded terminal phase packets;
- unconditional all-return/backtracking control for every Jordan boundary;
- the full Toeplitz square-peg conjecture.
