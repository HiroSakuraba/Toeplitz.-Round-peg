# Project Handoff v157: Plateau Degree and Return-Arch Rigidity

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v156 gave an exact `C^0` phase-root chart for continuous **strictly monotone**
balanced critical profiles.  It proved:

1. any base-phase drift of the fourth phase root creates a protected
   three-dimensional phase cell;
2. if no such drift occurs, the profile is affine or shifted logarithmic;
3. the exceptional phase surface is indexed by the single reciprocal-slope
   invariant `beta`.

The qualification “strictly monotone” left two conceptually different branches:

- a compact limit that is monotone but has flat pieces;
- a genuinely nonmonotone/backtracking limit, where ordinary inverse-phase
  coordinates do not exist.

v157 closes the first branch completely and puts the second into a much more
rigid form.

The central new theorem is:

> **Plateau-cell theorem.** A continuous nondecreasing profile with a genuine
> interior plateau has a protected open phase cell in the square phase map.

No differentiability and no inverse selection are used.  The proof is a direct
Poincare--Miranda argument in the three physical contact coordinates.

Combining this with v156 has a stronger consequence in the actual v155 critical
normalization.  A locally compact critical child limit satisfies globally

\[
f(s)=s+h(s),\qquad |h(s)|\le 2,
\tag{0.1}
\]

with

\[
f(0)=0
\tag{0.2}
\]

and a fixed nonzero residual excursion on a bounded child interval.  If such a
limit were nondecreasing and square-free, the plateau theorem would first make
it strictly increasing, and v156 would then make it globally affine or shifted
logarithmic.  Equation (0.1) excludes every shifted logarithm on all of
`R` and every affine slope except `1`; (0.2) then leaves only

\[
f(s)=s.
\tag{0.3}
\]

That contradicts the inherited critical excursion.  Hence:

\[
\boxed{
\text{a square-free locally compact critical limit cannot be monotone.}
}
\tag{0.4}
\]

The surviving compact branch is therefore genuinely backtracking.

For such a global balanced profile, v157 defines the first-hit inverse

\[
g(y)=\min\{t:f(t)=y\}.
\tag{0.5}
\]

Because `f(t)-t` is bounded, every level set is nonempty and compact.  The map
`g` is strictly increasing as an order map but may have jump discontinuities.
Every jump is exactly a **return arch**.  If

\[
a=g(z),\qquad b=g(z+),\qquad d=b-a>0,
\tag{0.6}
\]

then

\[
f(a)=f(b)=z,
\qquad
f(t)\le z\quad(a\le t\le b),
\tag{0.7}
\]

and, in the critical bound `|f(t)-t|<=2`,

\[
\boxed{d\le 4.}
\tag{0.8}
\]

At the two endpoints of the return arch, the corresponding square-contact
configurations have **exactly the same first two relative phases**.  Their
third-phase difference is

\[
\boxed{
\Delta_d(x)=f(x+d)-f(x).
}
\tag{0.9}
\]

This branch-separation observable cannot disappear.  Writing

\[
f(t)=t+h(t),\qquad |h(t)|\le C,
\tag{0.10}
\]

one has the exact averaging identity

\[
\frac1L\int_X^{X+L}\Delta_d(t)\,dt
=
 d+
 \frac1L
 \left(
 \int_{X+L}^{X+L+d}h(t)\,dt
 -
 \int_X^{X+d}h(t)\,dt
 \right),
\tag{0.11}
\]

and therefore

\[
\boxed{
\left|
\frac1L\int_X^{X+L}\Delta_d(t)\,dt-d
\right|
\le \frac{2Cd}{L}.
}
\tag{0.12}
\]

For the critical value `C=2`, every interval of translation parameters of
length `L>4` contains a point with positive branch separation.

Thus the remaining compact obstruction is no longer “arbitrary backtracking.”
It is the more specific problem of converting a recurrent return-arch branch
separation into a protected three-dimensional phase cell without a continuous
inverse branch.

---

# 1. Contact coordinates

It is useful to replace `(a,b,v)` temporarily by three of the four contact
parameters.  Set

\[
u_3=u_0+u_2-u_1.
\tag{1.1}
\]

Then the relative phase map is

\[
\boxed{
\mathcal H_f(u_0,u_1,u_2)
=
\begin{pmatrix}
 f(u_1)-f(u_0)\\
 f(u_2)-f(u_0)\\
 f(u_3)-f(u_0)
\end{pmatrix}.
}
\tag{1.2}
\]

The change of variables back to the v149 coordinates is

\[
v=\frac{u_0+u_2}{2},
\qquad
A=\frac{u_2-u_0}{2},
\qquad
B=u_1-v.
\tag{1.3}
\]

If

\[
u_0<u_1<u_2,
\tag{1.4}
\]

then `A>0` and `|B|<A`.  Moreover `u_3` automatically lies strictly between
`u_0` and `u_2`.  Thus a physical box in `(u_0,u_1,u_2)` with the ordering
(1.4) is an admissible square-map box after the affine coordinate change.

This formulation is especially convenient when `u_1` traverses a plateau or
return arch.

---

# 2. A direct plateau cell

Let `f` be continuous and nondecreasing on a buffered interval.  Suppose

\[
f(t)=z\qquad(a\le t\le b),
\qquad d=b-a>0.
\tag{2.1}
\]

Choose two further intervals

\[
I_0=[r_-,r_+],
\qquad
I_2=[s_-,s_+],
\tag{2.2}
\]

with

\[
r_+<a<b<s_-.
\tag{2.3}
\]

Write

\[
\delta_0=f(r_+)-f(r_-),
\qquad
\delta_2=f(s_+)-f(s_-).
\tag{2.4}
\]

Assume

\[
\delta_0>0,
\qquad
\delta_2>\delta_0.
\tag{2.5}
\]

For `r in I_0`, `s in I_2`, put

\[
\sigma(r,s)=r+s-a-b.
\tag{2.6}
\]

Assume the whole sum box satisfies

\[
0<\sigma_-:=r_-+s_--a-b
\le
\sigma(r,s)
\le
r_++s_+-a-b=:\sigma_+
<d.
\tag{2.7}
\]

Then

\[
r+s-b=a+\sigma(r,s)\in(a,b),
\tag{2.8}
\]

so

\[
f(r+s-b)=z.
\tag{2.9}
\]

On the other hand

\[
r+s-a=b+\sigma(r,s)>b.
\tag{2.10}
\]

Set

\[
\gamma=f(b+\sigma_-)-z.
\tag{2.11}
\]

If the plateau is maximal to the right, then `gamma>0`.  Assume in addition
that

\[
\gamma>\delta_0.
\tag{2.12}
\]

These inequalities are enough for a three-dimensional Poincare--Miranda box.

## 2.1 First coordinate

For `u_1 in [a,b]`,

\[
f(u_1)=z,
\tag{2.13}
\]

so

\[
Y_1=z-f(u_0).
\tag{2.14}
\]

Choose

\[
\tau_1
=
 z-\frac{f(r_-)+f(r_+)}2.
\tag{2.15}
\]

Then `Y_1-tau_1` has opposite signs on the two `u_0` faces, with margin

\[
m_1=\frac{\delta_0}{2}.
\tag{2.16}
\]

## 2.2 Second coordinate

On the lower `u_2=s_-` face,

\[
Y_2\le f(s_-)-f(r_-),
\tag{2.17}
\]

while on the upper `u_2=s_+` face,

\[
Y_2\ge f(s_+)-f(r_+).
\tag{2.18}
\]

The interval

\[
\left(
 f(s_-)-f(r_-),
 f(s_+)-f(r_+)
\right)
\tag{2.19}
\]

is nonempty exactly because

\[
\delta_2>\delta_0.
\tag{2.20}
\]

Choose its midpoint as `tau_2`.  The second face margin is

\[
m_2=\frac{\delta_2-\delta_0}{2}.
\tag{2.21}
\]

## 2.3 Third coordinate

On the `u_1=b` face, equations (2.8)--(2.9) give

\[
Y_3=z-f(u_0),
\tag{2.22}
\]

and hence

\[
Y_3\le z-f(r_-).
\tag{2.23}
\]

On the `u_1=a` face,

\[
Y_3
=f(u_0+u_2-a)-f(u_0)
\ge
z+\gamma-f(r_+).
\tag{2.24}
\]

Because `gamma>delta_0`,

\[
z-f(r_-)
<
z+\gamma-f(r_+).
\tag{2.25}
\]

Choose `tau_3` halfway between these two quantities.  The third face margin is

\[
m_3=\frac{\gamma-\delta_0}{2}.
\tag{2.26}
\]

The three components of

\[
\mathcal H_f-(\tau_1,\tau_2,\tau_3)
\tag{2.27}
\]

therefore have the Poincare--Miranda sign pattern on the three pairs of
opposite faces of

\[
I_0\times[a,b]\times I_2,
\tag{2.28}
\]

with coordinate order `(u_0,u_1,u_2)` and the second and third output roles
assigned as above.

Hence the target is attained.  More importantly, because

\[
m_*:=\min(m_1,m_2,m_3)>0,
\tag{2.29}
\]

all targets in a sufficiently small open cube around
`(tau_1,tau_2,tau_3)` have the same face signs.  Thus the image contains a
protected open phase cell.

We record this as:

> **Theorem 2.1 — plateau-cell theorem.**  Under (2.1)--(2.12), the phase map
> `H_f` contains a protected three-dimensional open cell.  The theorem uses
> only continuity and monotonicity of `f`.

---

# 3. Every interior maximal plateau supplies such a box

The hypotheses of Theorem 2.1 are not an extra dynamical assumption in the
critical global setting.

Let `f:R->R` be continuous and nondecreasing, and let `[a,b]` be a maximal
finite plateau with `a<b`.  Assume `f` is not constant on either half-line.
Then

\[
f(t)<z\quad(t<a),
\qquad
f(t)>z\quad(t>b),
\tag{3.1}
\]

where `z=f([a,b])`.

Choose `s_-<s_+` in

\[
(b,b+d/4)
\tag{3.2}
\]

so that

\[
\delta_2=f(s_+)-f(s_-)>0.
\tag{3.3}
\]

Such a pair exists because maximality and continuity imply that `f` cannot be
constant on the whole interval `(b,b+d/4)`.

Put

\[
e=s_--b>0.
\tag{3.4}
\]

Now choose

\[
r_-<r_+<a
\tag{3.5}
\]

so close to `a` that

\[
a-r_-<e/2,
\tag{3.6}
\]

and so that

\[
0<\delta_0=f(r_+)-f(r_-)
<
\min\left\{
\delta_2,
\frac12\bigl(f(b+e/2)-z\bigr)
\right\}.
\tag{3.7}
\]

This is possible because `f(t) -> z` as `t ↑ a`, while every left
neighborhood of `a` contains a phase increase; otherwise the plateau would
extend to the left.

Then

\[
\sigma_-
=r_-+s_--a-b
=e-(a-r_-)
>e/2>0,
\tag{3.8}
\]

while, by taking all four endpoints close enough to `a` and `b`,

\[
\sigma_+<d.
\tag{3.9}
\]

Moreover

\[
\gamma
=f(b+\sigma_-)-z
\ge f(b+e/2)-z
>2\delta_0.
\tag{3.10}
\]

Thus all hypotheses of Theorem 2.1 hold.

Therefore:

> **Corollary 3.1.**  Every continuous nondecreasing nonconstant global
> profile with a genuine finite plateau has a protected open phase cell.

The same construction can be reflected if one works on a finite interval and
only one side has sufficient buffer.  In the v155 critical child limit the
domain expands to all of `R`, so no endpoint qualification is needed.

---

# 4. Monotone C0 classification without strictness

A continuous nondecreasing function is either strictly increasing or it has a
nontrivial plateau: if `x<y` and `f(x)=f(y)`, monotonicity forces `f` to be
constant on `[x,y]`.

Hence Corollary 3.1 and v156 combine directly.

> **Theorem 4.1 — monotone C0 interior-or-exceptional dichotomy.**  Let `f` be
> a continuous nondecreasing profile on a buffered interval.
>
> - If `f` has a genuine interior plateau with the required physical buffer,
>   `H_f` has a protected open phase cell.
> - If `f` has no plateau, it is strictly increasing.  Then v156 applies:
>   either a phase root drifts and `H_f` has a protected open phase cell, or
>   `f` is affine or shifted logarithmic on that interval.

Thus the strict-monotonicity assumption in the **monotone** compact branch is
not a genuine obstruction.

---

# 5. Elimination of the monotone compact critical branch

This is stronger than the local classification because the v155 critical zoom
has an expanding child domain.

Recall

\[
\rho_n=\frac{S_n}{A_n}\to0
\tag{5.1}
\]

and

\[
\widehat F_n(s)
=
\frac{F_n(t_n+\rho_n s)-F_n(t_n)}{S_n}
=
s+\widehat h_n(s)+o(1),
\tag{5.2}
\]

with

\[
|\widehat h_n(s)|\le2
\tag{5.3}
\]

on every fixed child compact once `n` is large enough.  The original witness
also gives

\[
|s_n'|\le K,
\qquad
|\widehat h_n(s_n')|\ge\eta>0.
\tag{5.4}
\]

Assume there is a locally uniformly convergent subsequence

\[
\widehat F_n\to f
\tag{5.5}
\]

on every compact subset of `R`.  Then

\[
\boxed{|f(s)-s|\le2\quad\text{for every }s\in\mathbb R.}
\tag{5.6}
\]

Also, from the exact definition of the child phase,

\[
f(0)=0.
\tag{5.7}
\]

After passing to a further subsequence,

\[
s_n'\to s_*\in[-K,K],
\tag{5.8}
\]

and (5.2)--(5.4) imply

\[
|f(s_*)-s_*|\ge\eta.
\tag{5.9}
\]

So the limit is not the identity.

Suppose now that `f` is nondecreasing and that the original sequence remains
square-free.

If `f` has a plateau, Corollary 3.1 gives a protected phase cell.  Uniform
convergence on the finite contact box preserves the Poincare--Miranda face
margins, and the inherited high-phase lattice argument captures an actual
square.  Contradiction.

Therefore `f` must be strictly increasing.

If any v156 phase root drifts, the same protected-cell/lattice argument gives a
square.  Thus every local phase-root law is exceptional, and v156 makes `f`
locally affine or shifted logarithmic.

Overlapping exceptional representations must agree.  An affine representation
cannot agree with a genuine finite-pole logarithm on a nontrivial open
interval; two genuine logarithmic representations agreeing on an open interval
have the same pole and coefficient.  Consequently the local exceptional forms
glue to one global exceptional profile unless the branch is affine.

A genuine shifted logarithm cannot be continuous on all of `R`: its real pole
lies at a finite parameter value and separates its domain.  Therefore the
global limit must be affine,

\[
f(s)=cs+d.
\tag{5.10}
\]

The bounded-displacement condition (5.6) forces

\[
c=1.
\tag{5.11}
\]

Equation (5.7) then forces

\[
d=0.
\tag{5.12}
\]

Hence

\[
f(s)=s,
\tag{5.13}
\]

contradicting (5.9).

We obtain:

> **Theorem 5.1 — no monotone compact critical escape.**  Under the inherited
> v155 critical normalization and shrinking-window/lattice hypotheses, a
> square-free sequence cannot have a locally uniform critical child limit that
> is nondecreasing.

This is the main v157 closure.

---

# 6. The global first-hit inverse in the surviving branch

The remaining locally compact limit is therefore nonmonotone.  Its global
bounded-displacement structure provides much more information than an arbitrary
continuous function.

Let

\[
f(t)=t+h(t),
\qquad
|h(t)|\le C
\tag{6.1}
\]

on all of `R`.  In the v155 limit, `C=2`.

Then

\[
f(t)\to-\infty\quad(t\to-\infty),
\qquad
f(t)\to+\infty\quad(t\to+\infty).
\tag{6.2}
\]

For each phase level `y`, the level set

\[
K_y=\{t:f(t)=y\}
\tag{6.3}
\]

is therefore nonempty and compact.  Moreover every `t in K_y` satisfies

\[
|t-y|\le C.
\tag{6.4}
\]

Define the first-hit inverse

\[
\boxed{
g(y)=\min K_y.
}
\tag{6.5}
\]

Then immediately

\[
\boxed{|g(y)-y|\le C.}
\tag{6.6}
\]

## 6.1 Order monotonicity

If `y_1<y_2` but `g(y_2)<g(y_1)`, then continuity and (6.2) force `f` to cross
`y_1` before reaching `g(y_2)`, contradicting the definition of `g(y_1)`.
Thus

\[
y_1<y_2\quad\Longrightarrow\quad g(y_1)<g(y_2).
\tag{6.7}
\]

So `g` is strictly increasing as an order map, although it can have jumps.

Its monotonicity gives one-sided limits at every level.  The first-hit
minimality also gives left continuity:

\[
\lim_{y\uparrow z}g(y)=g(z).
\tag{6.8}
\]

The only possible discontinuity is therefore a right jump.

---

# 7. A first-hit jump is exactly a return arch

Let

\[
a=g(z),
\qquad
b=g(z+):=\lim_{y\downarrow z,\ y>z}g(y),
\tag{7.1}
\]

and suppose

\[
b>a.
\tag{7.2}
\]

Choose `y_n downarrow z` with `y_n>z`.  Then

\[
f(g(y_n))=y_n.
\tag{7.3}
\]

By (6.6), the points `g(y_n)` stay in a compact interval, and by monotonicity
they converge to `b`.  Continuity gives

\[
f(b)=z.
\tag{7.4}
\]

Of course

\[
f(a)=z.
\tag{7.5}
\]

If some `t in (a,b)` satisfied `f(t)>z`, choose

\[
z<y<f(t).
\tag{7.6}
\]

Continuity from the far left would force a first hit of level `y` no later
than `t`, contradicting the definition of `b=g(z+)`.  Hence

\[
\boxed{
f(t)\le z\qquad(a\le t\le b).
}
\tag{7.7}
\]

Thus `[a,b]` is a return arch from the record level `z` back to the same level.

The bounded displacement gives an absolute width bound.  Since both `a` and
`b` belong to `K_z`,

\[
|a-z|\le C,
\qquad
|b-z|\le C,
\tag{7.8}
\]

so

\[
\boxed{0<b-a\le2C.}
\tag{7.9}
\]

At the critical value `C=2`, every first-hit jump has width at most `4`.

## 7.1 Nonmonotonicity forces a jump

If `g` had no jumps, then it would be continuous.  By (6.6),

\[
g(y)\to\pm\infty\quad(y\to\pm\infty),
\tag{7.10}
\]

so a continuous strictly increasing `g:R->R` would be a homeomorphism onto
`R`.  Since

\[
f(g(y))=y,
\tag{7.11}
\]

this would make `f=g^{-1}` strictly increasing.

Therefore:

\[
\boxed{
 f\text{ nonmonotone}
 \Longrightarrow
 g\text{ has a positive jump}
 \Longrightarrow
 f\text{ has a return arch.}
}
\tag{7.12}
\]

For a global balanced critical limit, the compact nonmonotone obstruction is
therefore equivalent to the existence of at least one first-hit return arch.

---

# 8. Exact branch separation at a return arch

Let `[a,b]` be the return arch at level `z`, and write

\[
d=b-a>0.
\tag{8.1}
\]

Fix any `u_0,u_2` for which all four contacts stay in the working interval.
Compare the two contact triples

\[
P_a=(u_0,a,u_2),
\qquad
P_b=(u_0,b,u_2).
\tag{8.2}
\]

The first coordinates agree exactly because

\[
f(a)=f(b)=z:
\qquad
Y_1(P_a)=Y_1(P_b)=z-f(u_0).
\tag{8.3}
\]

The second coordinates also agree because `u_0,u_2` did not move:

\[
Y_2(P_a)=Y_2(P_b)=f(u_2)-f(u_0).
\tag{8.4}
\]

The fourth contacts are

\[
u_3(P_a)=u_0+u_2-a,
\qquad
u_3(P_b)=u_0+u_2-b.
\tag{8.5}
\]

Their separation is exactly `d`.  Hence

\[
\begin{aligned}
Y_3(P_a)-Y_3(P_b)
&=
 f(u_0+u_2-a)-f(u_0+u_2-b)\\
&=
 f(x+d)-f(x),
\end{aligned}
\tag{8.6}
\]

where

\[
x=u_0+u_2-b.
\tag{8.7}
\]

Define

\[
\boxed{
\Delta_d(x)=f(x+d)-f(x).
}
\tag{8.8}
\]

Then

\[
\boxed{
\mathcal H_f(P_a)_{1,2}
=\mathcal H_f(P_b)_{1,2},
\qquad
\mathcal H_f(P_a)_3-\mathcal H_f(P_b)_3
=\Delta_d(x).
}
\tag{8.9}
\]

This is the exact transverse observable exposed by a first-hit jump.

A jump therefore does not merely destroy the v156 inverse chart.  It creates
two competing contact branches over the same first two phase coordinates.
The only way those branches can fail to separate at a given translation is

\[
\Delta_d(x)=0.
\tag{8.10}
\]

---

# 9. Translation defects cannot stay hidden

For a balanced global profile

\[
f(t)=t+h(t),
\qquad
|h(t)|\le C,
\tag{9.1}
\]

one has

\[
\Delta_d(t)
=d+h(t+d)-h(t).
\tag{9.2}
\]

Integrating over `[X,X+L]`,

\[
\int_X^{X+L}\Delta_d(t)\,dt
=
dL+
\int_X^{X+L}(h(t+d)-h(t))\,dt.
\tag{9.3}
\]

The second integral telescopes at the two ends:

\[
\int_X^{X+L}(h(t+d)-h(t))\,dt
=
\int_{X+L}^{X+L+d}h(t)\,dt
-
\int_X^{X+d}h(t)\,dt.
\tag{9.4}
\]

Therefore

\[
\boxed{
\left|
\frac1L\int_X^{X+L}\Delta_d(t)\,dt-d
\right|
\le\frac{2Cd}{L}.
}
\tag{9.5}
\]

For `C=2`,

\[
\frac1L\int_X^{X+L}\Delta_d(t)\,dt
\ge
d\left(1-\frac4L\right).
\tag{9.6}
\]

Hence for every

\[
L>4,
\tag{9.7}
\]

every translation interval `[X,X+L]` contains at least one point at which

\[
\boxed{\Delta_d(t)>0.}
\tag{9.8}
\]

A second exact form is the discrete telescoping identity

\[
\boxed{
\sum_{k=0}^{N-1}\Delta_d(t+kd)
=Nd+h(t+Nd)-h(t).
}
\tag{9.9}
\]

Thus

\[
\frac1N\sum_{k=0}^{N-1}\Delta_d(t+kd)\to d.
\tag{9.10}
\]

In particular, `Delta_d` cannot vanish identically for any `d>0`; a global
period of `f` is incompatible with bounded displacement from the identity.

This is a useful improvement over the qualitative v156 suggestion that a
crossing jump “might” provide another degree direction.  A jump always creates
a pair of equal-`(Y_1,Y_2)` branches, and those branches are forced to separate
again and again in translation.

---

# 10. Running-record envelope

For later work it is convenient to make the monotone skeleton explicit.
Define

\[
M(t)=\max_{s\le t}f(s).
\tag{10.1}
\]

The maximum exists because `f(s)->-infinity` as `s->-infinity`.
The function `M` is continuous and nondecreasing.  Moreover

\[
t-C\le f(t)\le M(t)\le t+C,
\tag{10.2}
\]

so

\[
\boxed{|M(t)-t|\le C.}
\tag{10.3}
\]

At a first-hit jump `(a,b)` of level `z`,

\[
M(t)=z\qquad(a\le t\le b).
\tag{10.4}
\]

Thus every nonmonotone compact critical limit carries a monotone envelope with
a genuine plateau.  Section 2 proves that the envelope itself has a protected
phase cell.

This does **not** yet transfer that cell to `f`, because the return arch may dip
an order-one amount below its envelope.  That transfer problem is now the
remaining compact issue.

There is, however, a useful stability statement.  If on a buffered contact box

\[
\|f-M\|_\infty\le\varepsilon,
\tag{10.5}
\]

then

\[
\|\mathcal H_f-\mathcal H_M\|_\infty\le2\varepsilon.
\tag{10.6}
\]

Therefore any plateau cell of `M` whose face margin exceeds `2 epsilon`
persists for `f`.  A square-free return arch must consequently have
backtracking depth large enough to destroy **every** available plateau cell of
its record envelope.

This gives a quantitative diagnostic for v158.

---

# 11. Updated obstruction ledger

## Closed in v157: monotone plateau limits

A monotone plateau is not a new exceptional family.  It produces a protected
phase cell directly.

## Closed in v157: monotone compact critical escape

Combining the plateau theorem with v156 and the global balanced bound leaves
only the identity, which contradicts the inherited critical excursion.

## Closed in v157: possibility that a first-hit jump carries no transverse data

The two endpoint branches have third-phase separation exactly `Delta_d`, and
`Delta_d` has positive mean `d`.  It cannot vanish globally or remain
nonpositive over translation intervals longer than the universal critical
bound.

## Still open I: return-arch branch separation to degree

For the original nonmonotone profile, moving continuously through a return arch
changes the first relative phase as well as the fourth contact.  The two
endpoint branch sheets are separated, but v157 has not yet proved that the
three-dimensional image between them contains a protected lattice cell.

## Still open II: rough/noncompact critical sequences

A sequence may fail local equicontinuity after the critical zoom and admit no
locally uniform limit.  The present compact arguments do not cover that case.

## Still open III: bounded terminal packets and global Jordan transfer

The inherited v149 all-return/terminal-mass issues remain.  No statement here
removes the final global topological transfer problem for arbitrary Jordan
curves.

---

# 12. Recommended v158 target

The next target should no longer be phrased as “find a continuous inverse
selection.”  v157 shows that discontinuity of the first-hit inverse is itself
structured enough to work with.

The strongest next object is the **return-arch contact cylinder**

\[
\mathcal C
=
\{(u_0,u_1,u_2):
 u_0\in I_0,
 u_1\in[a,b],
 u_2\in I_2\},
\tag{12.1}
\]

with `[a,b]` a first-hit return arch.

At the two `u_1` faces the first two phase coordinates agree, while the third
face displacement is `Delta_d`.  The problem is to use the interior dip of the
arch, rather than fight it, to obtain a nonzero relative degree.

Three routes now look concrete.

### Route A: relative-degree cylinder theorem

Develop a degree statement in which the first two output coordinates need not
keep fixed signs on the whole `u_0` and `u_2` faces.  It should be enough that
the two-dimensional map `(Y_1,Y_2)` has nonzero degree on each transverse slice
and that the endpoint branch values of `Y_3` are separated on the resulting
zero continuum.

This is the cleanest topological formulation.

### Route B: shallow subarches

Every nonconstant return arch contains arbitrarily shallow equal-level
subarches around an interior minimum (or a literal flat minimum).  On a shallow
subarch the first-coordinate variation is small, while the endpoint branch
separation remains a translation defect at the corresponding horizontal width.
Try to make the direct plateau box of Section 2 stable under this small but
nonzero phase dip.

### Route C: record-envelope comparison

Quantify the best plateau-cell margin `m(M;[a,b])` of the running-record
envelope and compare it with the backtracking depth

\[
D(a,b)=\max_{[a,b]}(M-f).
\tag{12.2}
\]

If

\[
2D(a,b)<m(M;[a,b]),
\tag{12.3}
\]

robustness already forces a square.  A square-free arch must satisfy the
reverse inequality at every useful record plateau.  Iterating that inequality
may produce a quantitative depth/width cascade incompatible with

\[
|f(t)-t|\le2.
\tag{12.4}
\]

The preferred v158 theorem would be of the form

\[
\boxed{
\text{return arch}
\Longrightarrow
\text{protected phase cell}
\quad\text{or}\quad
\text{strict quantitative depth cascade}.
}
\tag{12.5}
\]

If the cascade can be ruled out by the bounded-displacement budget, the entire
locally compact critical branch would close.

---

# 13. Verification

`code/verify_v157.py` runs seven grouped audits covering:

1. the contact-coordinate transformation and parallelogram relation;
2. the plateau hypotheses, all three Poincare--Miranda face inequalities,
   and the predicted positive margins;
3. exact attainment of 100 random targets inside an explicit protected
   plateau subcell;
4. the return-arch endpoint identity together with the synthetic jump-width
   bound;
5. the continuous averaging identity and its `C=2`, `L>4` lower bound;
6. the discrete telescoping identity for `Delta_d`;
7. the running-record envelope bound `|M(t)-t|<=C` on a dense numerical grid.

The verifier is an audit of the algebra and representative numerical geometry;
it is not a substitute for the proofs above.

---

# 14. Claim boundary

v157 proves, within the inherited half-square/high-phase reduction:

- a derivative-free plateau-cell theorem for continuous nondecreasing profiles;
- extension of the v156 monotone classification from strictly increasing to
  arbitrary continuous nondecreasing profiles;
- elimination of a monotone locally compact critical child limit using the
  global bound `|f(s)-s|<=2` and the fixed critical excursion;
- exact first-hit/return-arch structure for every nonmonotone global balanced
  limit;
- the universal critical jump-width bound `d<=4`;
- exact two-branch phase separation by the translation defect `Delta_d`;
- positive-mean and telescoping laws that force recurrent branch separation.

v157 does **not** prove:

- that every nonmonotone compact critical limit forces a square;
- that every return-arch branch separation yields nonzero three-dimensional
  degree;
- compactness of arbitrary critical child sequences;
- exclusion of bounded terminal packets;
- the final Jordan-curve transfer needed for the full Toeplitz conjecture.
