# Project Handoff v158: Two-Channel Return-Arch Degree and the Channel-Sumset Obstruction

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v157 reduced every locally compact square-free critical limit to a genuinely
nonmonotone global balanced profile

\[
f(t)=t+h(t),\qquad |h(t)|\le 2,
\tag{0.1}
\]

with a first-hit return arch

\[
f(a)=f(b)=z,\qquad f(t)\le z\quad(a\le t\le b),
\qquad d=b-a>0,
\tag{0.2}
\]

and with the exact endpoint branch separation

\[
\Delta_d(x)=f(x+d)-f(x).
\tag{0.3}
\]

v157 showed that `Delta_d` cannot vanish globally and has positive long-scale
mean `d`, but it did not convert that separation into a protected phase cell
for the original nonmonotone profile.

v158 supplies a clean conversion theorem whenever the arch can be flanked by
two continuous inverse-phase channels.  The key point is that one does not
need a global inverse and does not need to control the interior backtracking.
One only needs a left phase section and a right phase section wide enough to
absorb the **depth** of the arch.

The new theorem is:

> **Two-channel return-arch theorem.**  Let `[a,b]` be a return arch of depth
> `D`.  Suppose there is a continuous inverse-phase channel to the left of the
> arch and another to the right, each covering a phase band of width `D`.
> If the return-arch translation defect is nonzero at the sum of the two
> endpoint contacts, then the square phase map contains a protected open
> three-dimensional cell.

The proof is completely `C^0`.  In suitable output coordinates the map is
triangular:

\[
(r_1,r_2,s)\longmapsto (r_1,r_2,W(r_1,r_2,s)).
\tag{0.4}
\]

At `s=a,b`, the first two coordinates agree exactly, while

\[
W(r_1,r_2,a)-W(r_1,r_2,b)
=
\Delta_d(x(r_1,r_2)).
\tag{0.5}
\]

A nonzero endpoint gap therefore gives a common vertical interval by the
intermediate value theorem; continuity in `(r_1,r_2)` thickens it to an open
three-dimensional slab.  Because the construction has an explicit triangular
degree, the slab is stable under the locally uniform approximations inherited
from the critical sequence.

This theorem has a strong global consequence.  Define the left and right
`D`-channel endpoint sets `C_D^-` and `C_D^+`.  A square-free return arch must
satisfy

\[
\boxed{
C_D^-+C_D^+-b\subset Z(\Delta_d).
}
\tag{0.6}
\]

Thus all nonzero translation defect has to avoid the additive sumset of the
available phase channels.  Since `Delta_d` is continuous and not identically
zero, a dense channel sumset is impossible in a square-free profile.

In particular, every balanced nonmonotone profile with strictly increasing
remote tails is closed by v158: the left and right channel sets contain rays,
so their sumset is all of `R`, contradicting (0.6) and the positive-mean
identity for `Delta_d`.

The surviving compact obstruction is therefore no longer arbitrary
backtracking.  It must contain a genuine **phase-channel desert** at infinity:
for the depth `D` of every usable return arch, at least one side must eventually
fail to admit robust continuous phase sections of that width.

---

# 1. Output coordinates adapted to a return arch

Recall the contact map

\[
\mathcal H_f(u_0,u_1,u_2)
=
\begin{pmatrix}
 f(u_1)-f(u_0)\\
 f(u_2)-f(u_0)\\
 f(u_0+u_2-u_1)-f(u_0)
\end{pmatrix}.
\tag{1.1}
\]

Use the invertible linear output change

\[
T(y_1,y_2,y_3)=(y_1,y_2-y_1,y_3).
\tag{1.2}
\]

Then

\[
\Phi_f:=T\circ\mathcal H_f
=
\begin{pmatrix}
 X_1\\X_2\\X_3
\end{pmatrix}
=
\begin{pmatrix}
 f(u_1)-f(u_0)\\
 f(u_2)-f(u_1)\\
 f(u_0+u_2-u_1)-f(u_0)
\end{pmatrix}.
\tag{1.3}
\]

The first two coordinates are now the two adjacent phase increments.  This is
the right chart for a return arch because they can be held fixed by choosing
one inverse-phase branch on each side of the arch.

The linear map `T` is invertible.  Hence an open cell for `Phi_f` is equivalent
to an open parallelepiped for `H_f`.  The fine phase lattice used in the
inherited capture argument remains a full-rank lattice under `T`, so protected
interior is all that is needed.

---

# 2. Return-arch depth

Let `[a,b]` be a return arch at level `z`:

\[
f(a)=f(b)=z,
\qquad
f(s)\le z\quad(a\le s\le b).
\tag{2.1}
\]

Set

\[
d=b-a>0
\tag{2.2}
\]

and

\[
m=\min_{[a,b]}f,
\qquad
D=z-m\ge0.
\tag{2.3}
\]

For a genuine nonconstant return arch,

\[
D>0.
\tag{2.4}
\]

Every phase encountered while the middle contact traverses the arch lies in

\[
f(s)\in[z-D,z].
\tag{2.5}
\]

That is exactly the phase width that the two auxiliary channels must cover.

---

# 3. Robust phase channels

A **left robust `D`-channel based at `p<a`** consists of an open phase interval
`J_-`, a continuous map

\[
L:J_-\to(-\infty,a),
\tag{3.1}
\]

and a phase value

\[
\lambda_-=f(p)\in J_-
\tag{3.2}
\]

such that

\[
f(L(y))=y,
\qquad
L(\lambda_-)=p,
\tag{3.3}
\]

and

\[
[\lambda_--D,\lambda_-]\Subset J_-.
\tag{3.4}
\]

The compact containment is the robustness margin needed to perturb the target
phase increments.

Similarly, a **right robust `D`-channel based at `q>b`** is a continuous section

\[
R:J_+\to(b,\infty),
\qquad
f(R(y))=y,
\qquad
R(\lambda_+)=q,
\tag{3.5}
\]

with

\[
\lambda_+=f(q),
\qquad
[\lambda_+-D,\lambda_+]\Subset J_+.
\tag{3.6}
\]

Because `f\circ L=id` and `f\circ R=id`, both sections are injective.  On a
compact phase subinterval they are therefore homeomorphisms onto their images.
No differentiability is involved.

Define the endpoint sets

\[
C_D^-(a,b)
=
\{p<a:p\text{ supports a left robust }D\text{-channel}\},
\tag{3.7}
\]

\[
C_D^+(a,b)
=
\{q>b:q\text{ supports a right robust }D\text{-channel}\}.
\tag{3.8}
\]

---

# 4. Exact two-channel triangularization

Fix

\[
p\in C_D^-(a,b),
\qquad
q\in C_D^+(a,b).
\tag{4.1}
\]

Write

\[
\lambda_-=f(p),
\qquad
\lambda_+=f(q).
\tag{4.2}
\]

Set the central adjacent phase increments

\[
r_1^*=z-\lambda_-,
\qquad
r_2^*=\lambda_+-z.
\tag{4.3}
\]

For `(r_1,r_2)` sufficiently close to `(r_1^*,r_2^*)` and `s\in[a,b]`, define

\[
u_0=L(f(s)-r_1),
\tag{4.4}
\]

\[
u_1=s,
\tag{4.5}
\]

\[
u_2=R(f(s)+r_2).
\tag{4.6}
\]

The channel-band hypotheses ensure that all arguments of `L` and `R` stay in
their domains.  The image conditions in (3.1) and (3.5) give

\[
u_0<a\le s\le b<u_2,
\tag{4.7}
\]

so the contacts remain physically ordered.

By construction,

\[
f(u_1)-f(u_0)
=
 f(s)-\bigl(f(s)-r_1\bigr)
=r_1,
\tag{4.8}
\]

and

\[
f(u_2)-f(u_1)
=
\bigl(f(s)+r_2\bigr)-f(s)
=r_2.
\tag{4.9}
\]

Define

\[
W(r_1,r_2,s)
=
 f(u_0+u_2-s)-f(u_0).
\tag{4.10}
\]

Then the composed phase map is exactly

\[
\boxed{
\Phi_f(u_0,u_1,u_2)
=
(r_1,r_2,W(r_1,r_2,s)).
}
\tag{4.11}
\]

This is the return-arch analogue of the v156 phase-root triangularization, but
it does not require `f` to be monotone on the arch.

---

# 5. Endpoint separation is exactly the translation defect

At either arch endpoint,

\[
f(a)=f(b)=z.
\tag{5.1}
\]

Therefore the auxiliary contacts coincide at the two ends:

\[
u_0(a)=u_0(b)=L(z-r_1),
\tag{5.2}
\]

\[
u_2(a)=u_2(b)=R(z+r_2).
\tag{5.3}
\]

Write

\[
x(r_1,r_2)
=
L(z-r_1)+R(z+r_2)-b.
\tag{5.4}
\]

Since `a=b-d`,

\[
L(z-r_1)+R(z+r_2)-a
=x(r_1,r_2)+d.
\tag{5.5}
\]

Hence

\[
\begin{aligned}
W(r_1,r_2,a)-W(r_1,r_2,b)
&=
 f(x(r_1,r_2)+d)-f(x(r_1,r_2))\\
&=
\boxed{\Delta_d(x(r_1,r_2))}.
\end{aligned}
\tag{5.6}
\]

At the central parameters,

\[
x(r_1^*,r_2^*)=p+q-b.
\tag{5.7}
\]

Thus the v157 transverse observable appears with no error term at all.

---

# 6. Two-channel return-arch theorem

Assume

\[
\Delta_d(p+q-b)\ne0.
\tag{6.1}
\]

After interchanging the two endpoint labels if necessary, suppose

\[
\Delta_d(p+q-b)>0.
\tag{6.2}
\]

Let

\[
\delta
=
\Delta_d(p+q-b)>0.
\tag{6.3}
\]

The functions `L`, `R`, `f`, and therefore `W`, are continuous.  Shrink to a
small open rectangle `U` around `(r_1^*,r_2^*)` so that

\[
W(r_1,r_2,a)-W(r_1,r_2,b)>\frac{3\delta}{4}
\qquad((r_1,r_2)\in U),
\tag{6.4}
\]

and

\[
|W(r_1,r_2,a)-W(r_1^*,r_2^*,a)|<\frac{\delta}{8},
\tag{6.5}
\]

\[
|W(r_1,r_2,b)-W(r_1^*,r_2^*,b)|<\frac{\delta}{8}.
\tag{6.6}
\]

Set

\[
A_*=W(r_1^*,r_2^*,a),
\qquad
B_*=W(r_1^*,r_2^*,b),
\tag{6.7}
\]

so

\[
A_*-B_*=\delta.
\tag{6.8}
\]

The interval

\[
J=
\left(
B_*+\frac{\delta}{4},
A_*-\frac{\delta}{4}
\right)
\tag{6.9}
\]

has length `delta/2`.  For every `(r_1,r_2)\in U`, equations (6.5)--(6.6) give

\[
W(r_1,r_2,b)<B_*+\frac{\delta}{4},
\tag{6.10}
\]

and

\[
W(r_1,r_2,a)>A_*-\frac{\delta}{4}.
\tag{6.11}
\]

For fixed `(r_1,r_2)`, the function

\[
s\longmapsto W(r_1,r_2,s)
\tag{6.12}
\]

is continuous on `[a,b]`.  The intermediate value theorem therefore gives

\[
J\subset W(r_1,r_2,[a,b]).
\tag{6.13}
\]

Using the exact first two coordinates in (4.11),

\[
\boxed{
U\times J\subset \Phi_f(\mathcal A),
}
\tag{6.14}
\]

where `A` is the corresponding compact family of physical contacts.

This proves:

> **Theorem 6.1 — two-channel return-arch theorem.**  Let `f` be continuous,
> let `[a,b]` be a return arch of depth `D`, and suppose there are robust left
> and right `D`-channels based at `p<a` and `q>b`.  If
> `Delta_d(p+q-b) != 0`, then `Phi_f`, and hence `H_f`, contains a protected
> open three-dimensional phase cell.

## 6.1 Why the cell is degree-protected

The parameter map

\[
\Psi(r_1,r_2,s)
=
\bigl(L(f(s)-r_1),s,R(f(s)+r_2)\bigr)
\tag{6.15}
\]

is an embedding on a sufficiently small compact parameter box: `s` is recovered
from the middle coordinate, and then `r_1,r_2` are recovered from the first two
phase increments.  In these coordinates the composed map is triangular as in
(4.11).

Choose a closed rectangle `U_0\Subset U` and a closed vertical interval
`J_0\Subset J`.  On the two `s`-faces, the third component lies strictly on
opposite sides of every target in `J_0`, while the first two components are the
identity in `(r_1,r_2)`.  The Brouwer degree is therefore `+/-1` on
`U_0 x J_0` (orientation depending only on the endpoint ordering).

Consequently the cell survives sufficiently small uniform perturbations of the
phase map on this finite contact family.  This is the protection needed to pass
from a compact critical limit back to the approximating high-phase sequence.

---

# 7. The channel-sumset obstruction

Theorem 6.1 has an immediate contrapositive.

If a return arch survives in a square-free compact critical limit, then for
**every** pair of robust depth-`D` channel endpoints

\[
p\in C_D^-(a,b),
\qquad
q\in C_D^+(a,b),
\tag{7.1}
\]

one must have

\[
\Delta_d(p+q-b)=0.
\tag{7.2}
\]

Equivalently,

\[
\boxed{
C_D^-(a,b)+C_D^+(a,b)-b
\subset
Z(\Delta_d).
}
\tag{7.3}
\]

This is the main structural reduction of v158.

The v157 averaging identity says

\[
\left|
\frac1L\int_X^{X+L}\Delta_d(t)\,dt-d
\right|
\le\frac{4d}{L}
\tag{7.4}
\]

in the critical bound `|f-t|<=2`.  Therefore `Delta_d` is not identically zero;
in fact every interval of length greater than `4` contains a point where it is
positive.

Since `Delta_d` is continuous, (7.3) yields:

> **Corollary 7.1 — dense channel sumsets are impossible.**  A square-free
> compact return-arch profile cannot have
>
> \[
> \overline{C_D^-+C_D^+-b}=\mathbb R.
> \tag{7.5}
> \]
>
> Otherwise continuity would force `Delta_d identically 0`, contradicting
> (7.4).

Thus a surviving compact profile must possess an actual open **translation
hole** in the additive sumset of its left and right depth-`D` phase channels.

---

# 8. Eventual monotone tails are closed

Assume there are numbers

\[
A<a<b<B
\tag{8.1}
\]

such that `f` is strictly increasing on

\[
(-\infty,A]
\tag{8.2}
\]

and on

\[
[B,\infty).
\tag{8.3}
\]

Because `f(t)-t` is bounded, both restrictions have unbounded phase ranges in
the appropriate directions.  Their inverses are continuous.

For every sufficiently negative `p`, the phase band

\[
[f(p)-D,f(p)]
\tag{8.4}
\]

lies completely in the left-tail phase range, with inverse image below `a`.
Hence

\[
(-\infty,P]\subset C_D^-
\tag{8.5}
\]

for some `P`.

Similarly,

\[
[Q,\infty)\subset C_D^+
\tag{8.6}
\]

for some `Q`.

But

\[
(-\infty,P]+[Q,\infty)=\mathbb R.
\tag{8.7}
\]

Indeed, for any `x` choose `p` sufficiently negative and put

\[
q=x+b-p;
\tag{8.8}
\]

then `q` is sufficiently positive.

Therefore

\[
C_D^-+C_D^+-b=\mathbb R.
\tag{8.9}
\]

Corollary 7.1 gives a contradiction.

We obtain:

> **Theorem 8.1 — no compact escape with monotone remote tails.**  Under the
> inherited critical normalization and lattice-transfer hypotheses, a
> nonmonotone locally compact square-free limit cannot be eventually strictly
> increasing on both tails.

This closes all compact backtracking profiles whose folding is confined to a
bounded region, and more generally every profile possessing robust monotone
phase tails on both sides of the return arch.

---

# 9. One clean tail forces a channel desert on the other

The sumset statement is stronger than Theorem 8.1.

Suppose, for example,

\[
(-\infty,P]\subset C_D^-.
\tag{9.1}
\]

If `C_D^+` were unbounded above, then

\[
(-\infty,P]+C_D^+=\mathbb R,
\tag{9.2}
\]

because for every target sum `x+b` one can choose a sufficiently large
`q\in C_D^+` and set `p=x+b-q\le P`.

Hence a square-free profile satisfying (9.1) must have

\[
\boxed{
sup C_D^+<\infty.
}
\tag{9.3}
\]

Symmetrically, if the right side contains a channel ray, then the left
`D`-channel set must be bounded below.

So one clean tail forces a genuine **channel desert** on the opposite tail:
beyond some finite point there can be no robust continuous inverse-phase branch
covering the depth `D` of the return arch.

This is substantially stronger than merely saying “the profile must keep
backtracking.”  The recurrent folds have to destroy every depth-`D` phase
section on that side.

---

# 10. Relation to the relative-degree cylinder idea

v157 recommended a relative-degree theorem for the return-arch contact
cylinder.  That remains useful in the fully wild case, but v158 shows that it
is unnecessary whenever two phase sections exist.

The two-channel parameterization explicitly builds the zero cylinder of the
first two phase equations.  In those coordinates, the putative abstract
relative-degree formula becomes the elementary triangular statement

\[
(r_1,r_2,s)\mapsto(r_1,r_2,W).
\tag{10.1}
\]

Thus the remaining need for a genuinely multivalued relative-degree formalism
is now confined to profiles where a full depth-`D` phase band has **no
continuous section** on at least one side.

That is exactly the channel-desert obstruction isolated above.

---

# 11. What v158 closes

## Closed: return arches flanked by two depth channels

Any nonzero endpoint translation defect gives a protected phase cell.

## Closed: compact backtracking of bounded spatial extent

If the profile becomes strictly increasing on both remote tails, the channel
sumset is all of `R`, contradicting the nonzero translation defect.

## Closed: one clean tail plus arbitrarily remote opposite channels

One channel ray and an unbounded opposite channel set already make the sumset
all of `R`.

---

# 12. What remains open

## Open I: phase-channel deserts

A surviving compact profile must arrange that, for every usable return arch of
depth `D`, at least one side eventually contains no robust continuous inverse
section spanning a `D`-wide phase band.

Equivalently, the folding at infinity must be strong enough to destroy every
such section.

## Open II: multivalued cancellation

In a channel desert, the first two phase equations still have nonzero global
topological degree, but their zero sets can branch and jump.  One now needs the
relative-degree/contact-current formulation suggested in v157, or an
alternative selection theorem that extracts a usable branch despite the
folding.

## Open III: noncompact critical sequences

As before, the critical zoom may fail local equicontinuity and have no locally
uniform limit.

## Open IV: inherited terminal/Jordan transfer

The bounded terminal packet and global Jordan-curve transfer issues from the
v149 stack remain untouched.

---

# 13. Recommended v159 target

The next target is now quite precise.

Let `B=[y-D,y]` be a phase band.  Consider the full preimage strip

\[
\Gamma_B=\{(t,\eta):f(t)=\eta,\ \eta\in B\}.
\tag{13.1}
\]

A robust channel is exactly a connected component of `Gamma_B` that projects
homeomorphically onto `B` and stays on the required side of the return arch.
A channel desert means no such component survives.

The best v159 theorem would be a **band-crossing alternative**:

\[
\boxed{
\text{no continuous section across a }D\text{-band}
\Longrightarrow
\text{a nested return subarch carrying a definite topological index}.
}
\tag{13.2}
\]

If the index can be made additive under nesting, then an infinite channel
failure cascade may contradict the global degree-one condition of
`f(t)=t+O(1)`.

A second route is to formalize the relative degree of the multivalued zero
cylinder.  For

\[
G=(X_1-r_1,X_2-r_2),
\tag{13.3}
\]

the global two-dimensional degree is `1`.  The desired three-dimensional
degree should be expressible as the difference of the degree carried below a
third-phase threshold on the two return-arch faces.  v158 shows exactly what
that formula must reduce to when a single channel is present.

The main conceptual gain is that the compact obstruction is now an explicit
failure of **phase-band sectionability**, not generic nonmonotonicity.
