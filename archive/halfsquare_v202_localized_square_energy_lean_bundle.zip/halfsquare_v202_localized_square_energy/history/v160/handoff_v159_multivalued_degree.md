# Project Handoff v159: Multivalued Band Degree and the Signed Cancellation Cycle

**Author:** Benjamin John Schulz  
**Date:** 7 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v158 reduced the locally compact nonmonotone critical branch to a return arch

\[
f(a)=f(b)=z,\qquad f(t)\le z\quad(a\le t\le b),\qquad d=b-a>0,
\tag{0.1}
\]

inside a global balanced profile

\[
f(t)=t+h(t),\qquad |h(t)|\le2.
\tag{0.2}
\]

v158 closed the arch whenever it is flanked by two continuous inverse-phase
channels.  The apparent remaining obstruction was a **phase-channel desert**:
a width-\(D\) phase band folds so often that no continuous inverse section can
be followed across it.

v159 shows that the absence of a section is not, by itself, the real
obstruction.  Every such folded band still carries one-dimensional Brouwer
degree \(+1\).  A left and right band crossing therefore generate an essential
**multivalued degree cylinder** for the first two phase equations.  The third
phase can be analyzed by a relative-degree boundary formula without choosing a
single branch.

The new exact obstruction is a signed one-dimensional current.  In a regular
finite-branch chamber, each endpoint root pair contributes an oriented interval
in third-phase space.  The three-dimensional degree at threshold \(c\) is the
signed coverage of those intervals at \(c\).  Therefore a square-free profile
must make the entire interval current cancel.

A crucial audit result is that **same-direction geometric motion is not enough
to prevent cancellation**, because local Brouwer weights can be negative.  The
minimal cancellation is

\[
\boxed{
[0,1]-[0,2]+[1,2]=0.
}
\tag{0.3}
\]

This is not a nuisance example.  It identifies the genuine compact bottleneck:

\[
\boxed{
\text{persistent signed branch-cycle cancellation of the return-arch defect.}
}
\tag{0.4}
\]

v159 therefore completes the relative-degree/contact-current formalism left
open in v157-v158, but it also shows precisely why a naive extension of the
two-channel theorem would be false.

---

# 1. Adjacent-phase coordinates

Use the invertible output change from v158:

\[
\Phi_f(u_0,u_1,u_2)
=
\begin{pmatrix}
X_1\\X_2\\X_3
\end{pmatrix}
=
\begin{pmatrix}
f(u_1)-f(u_0)\\
f(u_2)-f(u_1)\\
f(u_0+u_2-u_1)-f(u_0)
\end{pmatrix}.
\tag{1.1}
\]

Let

\[
m=\min_{[a,b]}f,
\qquad
D=z-m.
\tag{1.2}
\]

Then

\[
f(s)\in[z-D,z]
\qquad(s\in[a,b]).
\tag{1.3}
\]

The first two coordinates are exactly the two adjacent phase increments.  The
return arch will be the cylinder parameter.

---

# 2. Folded band crossings still have degree one

Choose a low phase level \(\alpha\) and a compact interval

\[
I_-=[P_-,Q_-]\subset(-\infty,a)
\tag{2.1}
\]

such that, for some robustness margin \(\rho>0\),

\[
f(P_-)<\alpha-D-\rho,
\qquad
f(Q_-)>\alpha+\rho.
\tag{2.2}
\]

No monotonicity is assumed on \(I_-\).  It can contain any finite or infinite
amount of backtracking.

Similarly choose \(\beta\) and

\[
I_+=[P_+,Q_+]\subset(b,\infty)
\tag{2.3}
\]

with

\[
f(P_+)<\beta-D-\rho,
\qquad
f(Q_+)>\beta+\rho.
\tag{2.4}
\]

Because \(f(t)-t\) is bounded and \(f(t)\to\pm\infty\), such intervals exist
for all sufficiently negative \(\alpha\) and sufficiently positive \(\beta\).

For every

\[
y\in[\alpha-D,\alpha]
\tag{2.5}
\]

the endpoint signs in (2.2) give

\[
\deg(f-y,\operatorname{int}I_-,0)=+1.
\tag{2.6}
\]

Likewise the right crossing has degree \(+1\) throughout its phase band.

Thus a channel desert can destroy continuous selection, but it cannot destroy
the net topological crossing number.

---

# 3. The multivalued first-two-phase cylinder

Set

\[
r_1^*=z-\alpha,
\qquad
r_2^*=\beta-z.
\tag{3.1}
\]

For \((r_1,r_2)\) in a sufficiently small rectangle \(U\) around this pair,
define

\[
G_s(u,v;r_1,r_2)
=
\begin{pmatrix}
f(s)-f(u)-r_1\\
f(v)-f(s)-r_2\end{pmatrix}
\tag{3.2}
\]

on

\[
\Omega=\operatorname{int}(I_-\times I_+).
\tag{3.3}
\]

The robust band margins ensure

\[
0\notin G_s(\partial\Omega;r_1,r_2)
\tag{3.4}
\]

for all \(s\in[a,b]\) and all \((r_1,r_2)\in U\).

The coordinates separate, so the product formula gives a fixed nonzero degree of magnitude one.  With the standard `(u,v)` orientation the first coordinate contributes the opposite of the left crossing orientation, so the sign is `-1`; reversing the global orientation normalizes it to `+1`.  Only nonvanishing is used below:

\[
\boxed{
|\deg(G_s,\Omega,0)|=1.
}
\tag{3.5}
\]

This sign is constant for every \(s\in[a,b]\).

The zero set need not be a graph over \(s\).  It may branch, merge, and jump.
Nevertheless it carries an oriented multiplicity-one current from the
\(s=a\) face to the \(s=b\) face.

This is the exact topological replacement for the v158 two-channel cylinder.

---

# 4. Endpoint translation on every branch

Define the third phase on the cylinder by

\[
C_s(u,v)=f(u+v-s)-f(u).
\tag{4.1}
\]

Whenever \(G_s=0\),

\[
\Phi_f(u,s,v)=(r_1,r_2,C_s(u,v)).
\tag{4.2}
\]

At the return-arch faces,

\[
f(a)=f(b)=z,
\tag{4.3}
\]

so

\[
G_a=G_b=:G_\partial.
\tag{4.4}
\]

For the same endpoint pair \((u,v)\), write

\[
x=u+v-b.
\tag{4.5}
\]

Then

\[
\begin{aligned}
C_a(u,v)-C_b(u,v)
&=f(u+v-a)-f(u+v-b)\\
&=f(x+d)-f(x).
\end{aligned}
\tag{4.6}
\]

Therefore

\[
\boxed{
C_a-C_b=\Delta_d(u+v-b),
\qquad
\Delta_d(x)=f(x+d)-f(x).
}
\tag{4.7}
\]

The v157 translation defect is thus the exact branchwise displacement of the
third phase on the multivalued endpoint degree set.

---

# 5. Relative-degree boundary formula

Fix \((r_1,r_2)\in U\).  For a third-phase threshold \(c\) that does not equal
\(C_a\) or \(C_b\) at an endpoint zero of \(G_\partial\), define

\[
\mathcal D_s(c)
=
\deg\Bigl(
G_s,
\{(u,v)\in\Omega:C_s(u,v)<c\},
0
\Bigr),
\qquad s=a,b.
\tag{5.1}
\]

The new boundary \(C_s=c\) contains no zero of \(G_s\), so the degree is
well-defined componentwise.

Consider

\[
F(u,v,s)
=
\bigl(G_s(u,v),C_s(u,v)-c\bigr)
\tag{5.2}
\]

on \(\Omega\times(a,b)\).  Its lateral boundary is protected by (3.4).
The degree-suspension formula gives, up to the global orientation convention,

\[
\boxed{
\deg(F,\Omega\times(a,b),0)
=
\mathcal D_b(c)-\mathcal D_a(c).
}
\tag{5.3}
\]

Only nonvanishing is used below.

## 5.1 Why (5.3) is valid in the fully folded case

For a generic PL approximation, the zero set of \(G_s\) in
\(\Omega\times[a,b]\) is a finite oriented one-complex.  The net oriented
multiplicity through each \(s\)-slice is a fixed `\pm1`, by (3.5).  The zeros of the full
map \(F\) are exactly its intersections with the hypersurface \(C=c\).
Oriented flux conservation identifies the signed intersection number with the
change in the degree carried by the sublevel \(C<c\) between the two endpoint
faces.  That is (5.3).

For continuous \(f\), approximate uniformly by a generic PL map while
preserving the lateral boundary margins and the endpoint avoidance of the
chosen threshold.  Brouwer degree is homotopy-stable, so the identity passes to
the limit.

This completes the relative-degree/contact-current construction that v157 and
v158 had left as an open route.

---

# 6. The regular finite-branch formula

The obstruction is most transparent for a regular PL or piecewise-\(C^1\)
endpoint target.

At \(s=a,b\), the first two equations reduce to

\[
f(u)=\alpha,
\qquad
f(v)=\beta.
\tag{6.1}
\]

Let the regular roots be

\[
u_1,\dots,u_m,
\qquad
v_1,\dots,v_n,
\tag{6.2}
\]

with local one-dimensional degree signs

\[
\varepsilon_i\in\{\pm1\},
\qquad
\eta_j\in\{\pm1\}.
\tag{6.3}
\]

For the scalar equations `f(u)=alpha` and `f(v)=beta`, each side crossing has total degree \(+1\),

\[
\sum_i\varepsilon_i=1,
\qquad
\sum_j\eta_j=1.
\tag{6.4}
\]

Up to the single global orientation sign coming from the first coordinate of `G`, the product root \((u_i,v_j)\) has weight

\[
w_{ij}=\varepsilon_i\eta_j.
\tag{6.5}
\]

Multiplying every weight by the same global sign does not affect whether the interval current vanishes, so this normalized convention is used throughout Sections 6--16.

Define

\[
B_{ij}=C_b(u_i,v_j),
\qquad
A_{ij}=C_a(u_i,v_j).
\tag{6.6}
\]

Then

\[
A_{ij}-B_{ij}
=
\Delta_d(u_i+v_j-b).
\tag{6.7}
\]

The relative three-dimensional degree at threshold \(c\) is exactly the signed
oriented-interval coverage

\[
\boxed{
\deg_3(c)
=
\sum_{i,j}
w_{ij}
\Bigl(
\mathbf 1_{B_{ij}<c<A_{ij}}
-
\mathbf 1_{A_{ij}<c<B_{ij}}
\Bigr),
}
\tag{6.8}
\]

away from endpoint values.

Equivalently, define the oriented interval current

\[
\boxed{
\mathcal I_{\alpha,\beta}
=
\sum_{i,j}w_{ij}[B_{ij},A_{ij}]_{\rm or}.
}
\tag{6.9}
\]

Then \(\deg_3(c)\) is the multiplicity of this current at \(c\).

Hence a square-free regular chamber must satisfy

\[
\boxed{
\mathcal I_{\alpha,\beta}=0.
}
\tag{6.10}
\]

This is the central v159 reduction.

---

# 7. Endpoint-current formulation

On the real line, a compactly supported oriented interval current is determined
by its boundary.  Therefore

\[
\mathcal I_{\alpha,\beta}=0
\tag{7.1}
\]

is equivalent to

\[
\boxed{
\sum_{i,j}w_{ij}\delta_{A_{ij}}
=
\sum_{i,j}w_{ij}\delta_{B_{ij}}.
}
\tag{7.2}
\]

Thus square-free escape requires exact equality of the **signed endpoint
third-phase distributions**.

Integrating the coverage function gives the first moment constraint

\[
\boxed{
\sum_{i,j}w_{ij}\Delta_d(u_i+v_j-b)=0.
}
\tag{7.3}
\]

More generally, equality (7.2) gives, for every polynomial or continuous test
function \(\varphi\),

\[
\sum_{i,j}w_{ij}\varphi(A_{ij})
=
\sum_{i,j}w_{ij}\varphi(B_{ij}).
\tag{7.4}
\]

The cancellation requirement is therefore substantially stronger than a
single scalar moment identity.

---

# 8. Important audit: same-sign motion can still cancel

A tempting but false argument is:

> if every \(A_{ij}-B_{ij}\) has the same sign, then the signed endpoint
> distribution must change.

This fails because the Brouwer weights \(w_{ij}\) themselves can be negative.
The smallest counterexample is

\[
[0,1]-[0,2]+[1,2]=0.
\tag{8.1}
\]

Every geometric interval points to the right, and the total coefficient is

\[
1-1+1=1,
\tag{8.2}
\]

but the oriented interval current vanishes identically.

At the endpoint level,

\[
(\delta_1-\delta_0)
-(\delta_2-\delta_0)
+(\delta_2-\delta_1)=0.
\tag{8.3}
\]

This motif has exactly the sign pattern \(+,-,+\) produced by three regular
crossings of a degree-one one-dimensional map.

So v159 explicitly rejects the naive claim that a zero-free window of
\(\Delta_d\) alone forces a square in the fully multivalued case.

That correction is mathematically important: **signed branch cancellation is
the real remaining compact obstruction.**

---

# 9. Cancellation graph and cycle decomposition

Equation (7.2) has a useful graph interpretation.

For every carrier \((i,j)\):

- if \(w_{ij}>0\), draw an oriented edge from \(B_{ij}\) to \(A_{ij}\);
- if \(w_{ij}<0\), reverse the edge and give it multiplicity \(|w_{ij}|\).

Then (7.2) says exactly that the resulting finite directed multigraph has equal
indegree and outdegree at every third-phase vertex.

Therefore every connected component decomposes into directed cycles.

> **Theorem 9.1 — branch-cycle necessity.**  In a regular finite-branch chamber,
> if the return-arch relative degree vanishes for every third-phase threshold,
> then all branch transport decomposes into closed directed cycles in third-phase
> space.

A nontrivial cycle necessarily contains both positive- and negative-degree
branches when all geometric displacements \(A_{ij}-B_{ij}\) have one sign.

The minimal cycle is precisely (8.1).  In geometric variables it has the form

\[
B_1=B_2,
\qquad
A_1=B_3,
\qquad
A_3=A_2,
\tag{9.1}
\]

after reversing the negative-weight edge.

Thus persistent square-free escape forces exact **third-phase branch matching**,
not merely a large number of folds.

---

# 10. Generic endpoint separation forces a phase cell

The cycle formulation gives an immediate sufficient condition that is useful
in computations.

If the endpoint values

\[
\{A_{ij},B_{ij}\}
\tag{10.1}
\]

are all distinct, then the boundary current in (7.2) cannot vanish.  Hence

\[
\mathcal I_{\alpha,\beta}\ne0,
\tag{10.2}
\]

so there exists a threshold \(c\) with nonzero three-dimensional degree.

More generally, cancellation is impossible unless the endpoint values admit
the exact collisions needed to build the cycle decomposition.

Therefore:

> **Corollary 10.1 — generic regular targets are captured.**  In any finite
> regular branch chamber, if the endpoint third-phase values do not satisfy a
> cycle of exact collision identities, the return arch produces a protected
> three-dimensional phase target.

This does not yet close the continuous problem because persistent identities
can survive on whole parameter chambers.  But it replaces vague
“multivalued cancellation” by explicit equations that can now be attacked.

---

# 11. Pair-sum localization remains useful

At an endpoint root,

\[
f(u_i)=\alpha,
\qquad
f(v_j)=\beta.
\tag{11.1}
\]

The balanced bound gives

\[
|u_i-\alpha|\le2,
\qquad
|v_j-\beta|\le2.
\tag{11.2}
\]

Hence every translation argument satisfies

\[
\boxed{
\left|(u_i+v_j-b)-(\alpha+\beta-b)\right|\le4.
}
\tag{11.3}
\]

So all defects participating in one cancellation cycle are sampled from a
fixed radius-four window of \(\Delta_d\).

This does **not** by itself force a zero of \(\Delta_d\), because the signed
cycle (8.1) can cancel intervals whose lengths are all strictly positive.
Instead it says that any persistent cancellation identity is a highly local
functional relation among values of the same translation defect.

That localization should be useful in v160.

---

# 12. Minimal branch complexity

For a regular degree-one crossing of a real line, simple roots have alternating
orientation signs and their total signed count is \(+1\).  Consequently the
number of simple roots is odd.

If both side levels have one simple root, there is one endpoint carrier and no
signed cycle is possible; this is the v158 single-channel situation.

The smallest genuinely multivalued cancellation therefore requires at least
three endpoint carriers.  The minimal possibility is:

- three simple roots on one side and one on the other; or
- one on one side and three on the other.

The weights are then \(+,-,+\), exactly the motif in Section 8.

Thus a square-free regular chamber must have genuine fold multiplicity; a mere
failure of a globally chosen inverse is not enough.

---


# 13. Sign-coherent regular chambers cannot cancel

The signed motif in Section 8 shows that same-direction motion can cancel in an
abstract integer current.  The actual square phase current has extra structure:
its endpoint locations are generated by inverse branches of the **same scalar
function**.  In a regular locally monotone branch chamber, that structure rules
out the cancellation cycle.

Assume the endpoint equations have finitely many continuous inverse branches

\[
u_i=u_i(\alpha),
\qquad
v_j=v_j(\beta)
\tag{13.1}
\]

on an open rectangle of phase targets.  Each branch is strictly monotone, with
orientation signs

\[
\sigma_i\in\{\pm1\},
\qquad
\tau_j\in\{\pm1\}.
\tag{13.2}
\]

The normalized product Brouwer sign is

\[
w_{ij}=\sigma_i\tau_j.
\tag{13.3}
\]

Set

\[
x_{ij}(\alpha,\beta)
=u_i(\alpha)+v_j(\beta)-b.
\tag{13.4}
\]

Suppose also that, on the parameter chamber under discussion, the ranges swept
by each relevant \(x_{ij}\) and \(x_{ij}+d\) lie in intervals on which \(f\) is
strictly monotone.  No derivative is assumed.  Let those local orientation
signs be denoted by

\[
\rho_{ij}^{B},\rho_{ij}^{A}\in\{\pm1\}.
\tag{13.5}
\]

## 13.1 Same-type collision lemma

Suppose two lower endpoints agree identically on an open target rectangle:

\[
B_{ij}(\alpha,\beta)=B_{k\ell}(\alpha,\beta).
\tag{13.6}
\]

Since

\[
B_{ij}=f(x_{ij})-\alpha,
\tag{13.7}
\]

this is equivalent to

\[
f(x_{ij})=f(x_{k\ell}).
\tag{13.8}
\]

Fix \(\beta\) and vary \(\alpha\).  The two sides of (13.8) are strictly
monotone functions whose orientation signs are

\[
\rho_{ij}^{B}\sigma_i,
\qquad
\rho_{k\ell}^{B}\sigma_k.
\tag{13.9}
\]

Equality on an interval forces those signs to agree:

\[
\rho_{ij}^{B}\rho_{k\ell}^{B}\sigma_i\sigma_k=+1.
\tag{13.10}
\]

Now fix \(\alpha\) and vary \(\beta\).  The same argument gives

\[
\rho_{ij}^{B}\rho_{k\ell}^{B}\tau_j\tau_\ell=+1.
\tag{13.11}
\]

Therefore

\[
\sigma_i\sigma_k=\tau_j\tau_\ell,
\tag{13.12}
\]

and hence

\[
\boxed{
w_{ij}w_{k\ell}
=(\sigma_i\sigma_k)(\tau_j\tau_\ell)=+1.}
\tag{13.13}
\]

So a persistent \(B=B\) collision can occur only between carriers of the same
product degree sign.

Exactly the same argument applied to

\[
A_{ij}=f(x_{ij}+d)-\alpha
\tag{13.14}
\]

proves:

\[
\boxed{
A_{ij}\equiv A_{k\ell}
\quad\Longrightarrow\quad
w_{ij}=w_{k\ell}
}
\tag{13.15}
\]

throughout every such locally monotone chamber.

This is a purely \(C^0\) orientation argument.  In a PL chamber it is the sign
version of differentiating the two branch identities, but no differentiability
is needed.

## 13.2 Cycle obstruction

Assume now that every endpoint translation defect in the chamber has the same
strict sign:

\[
\operatorname{sgn}(A_{ij}-B_{ij})=\varepsilon
\qquad\text{for all }(i,j),
\tag{13.16}
\]

where \(\varepsilon\in\{\pm1\}\).

If the interval current vanished, Section 9 would decompose it into directed
cycles after reversing every negative-weight carrier.

For \(\varepsilon=+1\):

- a positive-weight carrier points right, from \(B\) to \(A\);
- a negative-weight carrier is reversed and points left, from \(A\) to \(B\).

A directed cycle on the ordered real line cannot consist solely of rightward
edges or solely of leftward edges.  It must switch between positive- and
negative-weight carriers.

At a positive-to-negative switch the common vertex has the form

\[
A_{ij}=A_{k\ell}
\tag{13.17}
\]

for opposite product signs.  This contradicts (13.15).

At a negative-to-positive switch the common vertex has the form

\[
B_{ij}=B_{k\ell}
\tag{13.18}
\]

for opposite product signs, contradicting (13.13).

The case \(\varepsilon=-1\) is the same with left and right interchanged.

Therefore:

> **Theorem 13.1 — sign-coherent regular chamber theorem.**  In a finite branch
> chamber where the side inverse branches are continuous and strictly monotone,
> and where all third-phase endpoint evaluation branches are locally strictly
> monotone, a common nonzero sign of the return-arch defects
> \(A_{ij}-B_{ij}\) prevents signed interval-current cancellation.  Hence some
> third-phase threshold has nonzero relative degree and the phase map contains
> a protected three-dimensional target.

This eliminates not just the minimal three-carrier motif, but **every finite
sign-coherent cancellation cycle in a regular locally monotone chamber**.

## 13.3 Consequences

The abstract subdivision

\[
[0,1]-[0,2]+[1,2]=0
\tag{13.19}
\]

remains a valid warning, but an actual square-phase branch chamber cannot
sustain it unless at least one of the regularity hypotheses above fails.

Thus a square-free compact profile can survive a sign-coherent defect window
only by forcing one of the following:

1. a third-phase evaluation branch hits a local extremum, plateau, or other
   failure of local strict monotonicity;
2. the number of inverse branches ceases to be finite/regular;
3. the defect changes sign or vanishes among the participating pair sums;
4. the target chamber itself collapses onto branch-critical values.

Combined with the radius-four pair-sum localization (11.3), a zero-free
length-eight interval of \(\Delta_d\) **does** force a phase cell for every
regular locally monotone finite-branch target chamber centered there.  What
prevents this from being a full \(C^0\) theorem is now precisely singular
branch/evaluation behavior, not ordinary multivalued folding.

---

# 14. What v159 closes

## Closed: phase-channel deserts as a purely selection-theoretic obstruction

Continuous inverse sections are unnecessary.  Arbitrarily folded phase bands
still supply the first-two-coordinate degree cylinder.

## Closed: the relative-degree/contact-current formalism

The three-dimensional degree is now explicitly the difference of endpoint
threshold degrees, and in a regular finite chamber it is the signed coverage of
the oriented interval current (6.9).

## Closed: generic finite-branch cancellation

If endpoint third-phase values do not satisfy exact collision cycles, some
third-phase threshold has nonzero degree and the inherited capture mechanism
applies.

---

# 15. What remains open

## Open I: defect sign-change recurrence

Theorem 13.1 closes every finite locally monotone chamber in which all sampled
translation defects have one nonzero sign.  A regular square-free chamber must
therefore arrange

\[
\Delta_d(x_{ij})\Delta_d(x_{k\ell})\le0
\tag{15.1}
\]

for some participating pair sums, or place one of them at a zero of
\(\Delta_d\).

Because all pair sums lie in the radius-four window (11.3), this points back to
a quantitative recurrence problem for the zero/sign-change set of the fixed
translation defect.

## Open II: branch-critical endpoint locking

The other escape from Theorem 13.1 is persistent failure of local strict
monotonicity at one of the third-contact evaluation branches

\[
x_{ij}(\alpha,\beta)
\quad\text{or}\quad
x_{ij}(\alpha,\beta)+d.
\tag{15.2}
\]

If this happens on every target perturbation, the branch sums are being locked
to local extrema, plateaus, or recursively folded regions.  That should create
new return arches at the **third-contact level**, but the required nesting
lemma has not yet been proved.

## Open III: infinitely many branches / singular degree currents

A phase level may have infinitely many crossings, and the finite branch current
may converge only as a locally finite integer current.  Uniform control of that
limit, especially under target perturbation, is still missing.

## Open IV: noncompact critical sequences

The critical zoom may fail local equicontinuity and have no locally uniform
limit.

## Open V: terminal/Jordan transfer

The bounded terminal packet and global Jordan-curve transfer issues inherited
from the earlier stack remain open.

---

# 16. Recommended v160 target

The best next theorem is now a **sign-change-or-criticality alternative** for
the radius-four pair-sum window.

For a chosen center

\[
c_0=\alpha+\beta-b,
\tag{16.1}
\]

all endpoint translation arguments lie in

\[
[c_0-4,c_0+4].
\tag{16.2}
\]

If \(\Delta_d\) has one strict sign on that whole interval, Theorem 13.1 says
that a square-free target can survive only if finite local monotonicity fails.
Therefore the desired v160 statement is schematically

\[
\boxed{
\begin{array}{c}
\Delta_d\text{ sign-coherent on }[c_0-4,c_0+4]
\\[2mm]
\Downarrow
\\[2mm]
\text{phase cell}
\quad\text{or}\quad
\text{third-contact critical locking}.
\end{array}}
\tag{16.3}
\]

The next task is to analyze the critical-locking branch.  If an evaluation sum
\(x_{ij}(\alpha,\beta)\) is forced into local nonmonotonicity throughout an
open two-parameter target chamber, its image should sweep a family of return
arches.  A useful target lemma would be:

\[
\boxed{
\text{persistent critical locking}
\Longrightarrow
\text{a nested return arch with strictly smaller branch complexity}.}
\tag{16.4}
\]

A complexity descent of that kind would combine with the v159 current theorem:
regular chambers give degree, while singular chambers descend to a simpler
return configuration.

A parallel computational route is to enumerate PL branch chambers.  For each
finite slope/sign pattern:

1. build all inverse branches of the two side phase levels;
2. form every endpoint pair sum \(x_{ij}\);
3. enumerate the possible endpoint-current cycles;
4. reject cycles violating the same-type collision lemma;
5. classify the remaining cases in which an \(x_{ij}\) or \(x_{ij}+d\) is
   locked to a breakpoint or defect sign change.

That finite enumeration should reveal whether the critical-locking descent is
actually true before attempting the full \(C^0\) proof.

---

# 17. Bottom line

The compact obstruction has now moved through

\[
\text{return arch}
\to
\text{channel desert}
\to
\text{multivalued degree cylinder}
\to
\text{signed interval current}
\to
\boxed{\text{defect sign change or branch-critical locking}}.
\tag{17.1}
\]

The main technical gain is that ordinary finite multivalued folding is no
longer enough to escape.  Brouwer degree absorbs the folding, and the special
inverse-branch geometry prevents the signed cancellation cycles from persisting
whenever the sampled defect has one sign and the endpoint branches remain
locally monotone.

The compact survivor must therefore live on the singular boundary of those
regular chambers: recurrent zeros/sign changes of \(\Delta_d\), persistent
third-contact extrema, infinitely many crossings, or some combination of all
three.

That is the v160 frontier.
