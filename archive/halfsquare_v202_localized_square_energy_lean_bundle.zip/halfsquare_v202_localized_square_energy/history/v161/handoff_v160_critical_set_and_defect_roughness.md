# Project Handoff v160: Critical-Set Baire Reduction and Syndetic Defect Roughness

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v159 reduced the locally compact nonmonotone critical branch to a return arch

\[
f(a)=f(b)=z,\qquad f(t)\le z\quad(a\le t\le b),\qquad d=b-a>0,
\tag{0.1}
\]

inside a balanced global profile

\[
f(t)=t+h(t),\qquad |h(t)|\le2.
\tag{0.2}
\]

For a finite regular endpoint chamber, v159 proved that a sign-coherent
translation defect

\[
\Delta_d(x)=f(x+d)-f(x)
\tag{0.3}
\]

forces a three-dimensional phase cell unless the third-contact evaluation
branches lose local strict monotonicity.  The remaining finite-branch escape
was called **critical locking**.

v160 proves that persistent critical locking is much more singular than that
phrase suggested.  Define the closed critical set

\[
\boxed{
K(f)=\{x:\ f\text{ is not locally one-to-one at }x\}.
}
\tag{0.4}
\]

In a finite endpoint-branch chamber, if critical locking blocks every target
perturbation, then a finite family of closed preimages of `K(f)` covers an open
two-parameter rectangle.  Baire category then forces one of those preimages
to contain an open subrectangle.  Because the corresponding pair-sum map is
strictly monotone in either target variable, its image contains an interval.
Hence

\[
\boxed{
\text{persistent finite-branch critical locking}
\Longrightarrow
\operatorname{int}K(f)\ne\varnothing.
}
\tag{0.5}
\]

Thus isolated turning points, finitely many folds, and even nowhere-dense
critical sets cannot sustain the v159 escape mechanism on an open target
chamber.

The second result concerns the other v159 escape, recurrent sign changes or
zeros of `Delta_d`.  If there is no zero-free interval of length `8`, then
`Z(Delta_d)` is 8-syndetic.  Every defect zero satisfies

\[
h(x+d)-h(x)=-d,
\tag{0.6}
\]

so the bounded residual executes an exact slope-`-1` drop across a distance
`d`.  Choosing disjoint zero intervals gives the exact variation lower bound

\[
\boxed{
\operatorname{Var}_{[0,L]}h
\ge
 d\left\lfloor\frac{L}{8+d}\right\rfloor .
}
\tag{0.7}
\]

Moreover the v157 averaging identity implies that every length-eight interval
contains a point with `Delta_d >= d/2`.  Therefore the syndetic-zero branch
satisfies

\[
\boxed{
\operatorname{osc}_{[X,X+8]}\Delta_d\ge d/2
\quad\text{for every }X.
}
\tag{0.8}
\]

The compact obstruction has consequently split into two explicitly wild
objects:

1. an interval on which `f` is nowhere locally injective; or
2. recurrent slope-`-1` saturation / positive variation density in the defect
   branch;

plus the already inherited possibility of genuinely infinite endpoint branch
complexity.

---

# 1. The local-injectivity critical set

For a continuous real function define

\[
K(f)=\{x:\text{no neighborhood of }x\text{ exists on which }f\text{ is injective}\}.
\tag{1.1}
\]

A continuous injective function on an interval is strictly monotone.  Thus
`x notin K(f)` is equivalent to the existence of a neighborhood on which `f`
is strictly monotone.

The complement of `K(f)` is open: if `f` is injective on a neighborhood `J`
of `x`, then every point of a smaller interval `J' compactly contained in J`
has the same property.  Hence

\[
\boxed{K(f)\text{ is closed}.}
\tag{1.2}
\]

This elementary closedness is what makes the Baire argument below possible.

---

# 2. Finite regular endpoint chambers

Use the v159 notation.  On an open target rectangle

\[
U=I_\alpha\times I_\beta,
\tag{2.1}
\]

suppose the endpoint equations admit finitely many continuous strictly
monotone inverse branches

\[
u_i=u_i(\alpha),\qquad i=1,\dots,m,
\tag{2.2}
\]

and

\[
v_j=v_j(\beta),\qquad j=1,\dots,n.
\tag{2.3}
\]

For the return arch `[a,b]`, set

\[
x_{ij}(\alpha,\beta)=u_i(\alpha)+v_j(\beta)-b.
\tag{2.4}
\]

The lower and upper third-contact evaluations occur at

\[
x_{ij},\qquad x_{ij}+d.
\tag{2.5}
\]

The v159 sign-coherent chamber theorem applies on any subrectangle on which
all these evaluation points lie in neighborhoods where `f` is strictly
monotone and all sampled `Delta_d` have one strict sign.

The question left by v159 was whether every perturbation could be forced into
a critical third-contact location.

---

# 3. Baire reduction of persistent critical locking

For each carrier define the closed subsets of target space

\[
E_{ij}^{B}=x_{ij}^{-1}(K(f)),
\qquad
E_{ij}^{A}=(x_{ij}+d)^{-1}(K(f)).
\tag{3.1}
\]

They are closed because `K(f)` is closed and the branch maps are continuous.

Assume that **every** target point in `U` is critically locked, meaning that at
least one of the `2mn` third-contact positions belongs to `K(f)`.  Then

\[
U=
\bigcup_{i,j}
\left(E_{ij}^{A}\cup E_{ij}^{B}\right).
\tag{3.2}
\]

This is a finite union of closed subsets of the Baire space `U`.  Therefore at
least one member, say `E_{ij}^{B}`, has nonempty interior.  Shrinking if
necessary, there is an open rectangle

\[
V=J_\alpha\times J_\beta\subset E_{ij}^{B}.
\tag{3.3}
\]

Fix any `beta_0 in J_beta`.  Because `u_i` is continuous and strictly monotone,

\[
\alpha\longmapsto
u_i(\alpha)+v_j(\beta_0)-b
\tag{3.4}
\]

maps `J_alpha` homeomorphically onto a nondegenerate interval.  Equation
(3.3) places that whole interval inside `K(f)`.

The same proof applies if the Baire member is an `A`-set.

> **Theorem 3.1 — critical-set interval theorem.**  In a finite regular
> endpoint chamber, if every target perturbation has at least one critically
> locked third-contact evaluation, then `K(f)` contains a nondegenerate open
> interval.

Equivalently,

\[
\boxed{
\operatorname{int}K(f)=\varnothing
\Longrightarrow
\text{some open target subchamber has no critical locking.}
}
\tag{3.5}
\]

This is a qualitative but exact improvement over v159.

---

# 4. Combination with the v159 sign-coherent theorem

Assume, in addition, that the localized pair-sum window of v159 lies in an
interval on which

\[
\operatorname{sgn}\Delta_d=\varepsilon\in\{+1,-1\}
\tag{4.1}
\]

strictly.

If `int K(f)=empty`, Theorem 3.1 supplies a target point at which **all**
third-contact evaluation positions avoid `K(f)`.  Local strict monotonicity is
an open condition, so after shrinking the target rectangle all evaluation
positions stay inside fixed monotonicity neighborhoods.

Theorem 13.1 of v159 then applies and the signed endpoint current cannot
cancel.  Hence some third-phase threshold has nonzero relative degree.

> **Theorem 4.1 — sign-coherent finite-chamber alternative.**  In a finite
> regular endpoint chamber with sign-coherent nonzero return-arch defects,
> either the square phase map contains a protected three-dimensional target,
> or `K(f)` contains a nondegenerate interval.

So the finite-branch critical escape is not “a turning point happens to lie in
the way.”  It requires an entire interval of nowhere-local-injectivity.

---

# 5. What an interval of critical points means

Suppose

\[
J\subset K(f)
\tag{5.1}
\]

is a nondegenerate interval.

Every open subinterval `W subset J` contains two distinct points `p<q` with

\[
f(p)=f(q),
\tag{5.2}
\]

because otherwise `f` would be injective on `W`.

There is a sharper excursion statement.

> **Lemma 5.1 — microscopic return-arch lemma.**  Let `f` be continuous on an
> interval `W` and suppose `W` contains a nontrivial equal-value pair.  If `f`
> is not constant on any subinterval of `W`, then `W` contains primitive return
> arches of arbitrarily small positive width.

**Proof sketch.**  Choose `p<q` with equal endpoint value and with `f`
nonconstant on `[p,q]`.  One of the maximum or minimum differs from the common
endpoint value.  Suppose the maximum is larger.  Choose a point `r` in the
maximum set.  For levels `y` increasing to that maximum, take the connected
component `(a_y,b_y)` of `{f>y}` containing `r`.  Its endpoints satisfy
`f(a_y)=f(b_y)=y` and its interior lies above `y`.  If these component widths
did not tend to zero along some sequence, nested compact closures would leave
a nondegenerate interval on which `f` equals the maximum, contradicting the
no-plateau assumption.  The minimum case is identical.  QED.

Consequently:

\[
\boxed{
J\subset K(f)
\Longrightarrow
\begin{cases}
\text{a genuine plateau occurs in }J,\\
\text{or every subinterval of }J\text{ contains arbitrarily small return arches.}
\end{cases}}
\tag{5.3}
\]

Thus the Baire escape is automatically a microscopic folding cascade, not an
ordinary finite turning-point phenomenon.

For the balanced representation `f=t+h`, every equal-value pair `p<q`
satisfies

\[
\boxed{
\frac{h(q)-h(p)}{q-p}=-1.
}
\tag{5.4}
\]

Hence an interval contained in `K(f)` forces slope-`-1` secants at arbitrarily
small scales in every subinterval.

---

# 6. Defect zeros are exact return pairs

The fixed return-arch translation defect is

\[
\Delta_d(x)=f(x+d)-f(x).
\tag{6.1}
\]

A zero is exactly an equal-value pair separated by `d`:

\[
\Delta_d(x)=0
\iff
f(x+d)=f(x).
\tag{6.2}
\]

Using `f=t+h`, this is equivalent to

\[
\boxed{
h(x+d)-h(x)=-d.}
\tag{6.3}
\]

So every defect zero saturates the background unit drift with an exact
slope-`-1` residual secant.

If `f` is nonconstant on `[x,x+d]`, the same excursion argument as Lemma 5.1
produces arbitrarily small return arches inside that interval unless a plateau
is present.  Thus a defect zero is already a local source of recursive folding.

---

# 7. The 8-syndetic zero alternative

The pair-sum localization in v159 is

\[
|x_{ij}-(\alpha+\beta-b)|\le4.
\tag{7.1}
\]

Therefore a zero-free interval of length `8` is exactly the natural window on
which all possible endpoint defects have one strict sign.

Suppose no such interval exists.  Since `Delta_d` is continuous, every
zero-free interval is sign-coherent.  Hence

\[
\boxed{
\forall X\in\mathbb R,\qquad
[X,X+8]\cap Z(\Delta_d)\ne\varnothing.
}
\tag{7.2}
\]

That is, the defect zero set is `8`-syndetic.

This alternative is independent of branch regularity.  It is a direct
geometric property of the balanced profile.

---

# 8. Linear variation density forced by syndetic zeros

Assume (7.2).  For each integer `k>=0`, choose

\[
x_k\in[k(8+d),\ k(8+d)+8]
\tag{8.1}
\]

with `Delta_d(x_k)=0`.  Then

\[
x_k+d\le(k+1)(8+d)\le x_{k+1},
\tag{8.2}
\]

so the intervals `[x_k,x_k+d]` are pairwise disjoint up to endpoints.

On each such interval,

\[
|h(x_k+d)-h(x_k)|=d.
\tag{8.3}
\]

Variation is additive over disjoint ordered intervals, so for every integer
`N>=1`,

\[
\boxed{
\operatorname{Var}_{[0,N(8+d)]}h\ge Nd.
}
\tag{8.4}
\]

For arbitrary `L>=0`,

\[
\boxed{
\operatorname{Var}_{[0,L]}h
\ge
 d\left\lfloor\frac{L}{8+d}\right\rfloor.
}
\tag{8.5}
\]

The same estimate holds on negative tails after translation.

Thus a defect-zero set dense enough to block every sign-coherent radius-four
window forces a positive asymptotic variation density

\[
\liminf_{L\to\infty}
\frac{\operatorname{Var}_{[0,L]}h}{L}
\ge
\frac{d}{8+d}>0.
\tag{8.6}
\]

This gives a new sufficient closure condition:

> **Corollary 8.1.**  If the balanced residual `h` has sublinear total variation
> on one tail, then `Z(Delta_d)` cannot be 8-syndetic.  Hence that tail contains
> a zero-free length-eight defect window.

To turn this directly into a square one still needs a finite regular endpoint
chamber or the elimination of the infinite-current branch.

---

# 9. Defect oscillation on every length-eight block

v157 proved, for `|h|<=2`,

\[
\left|
\frac1L\int_X^{X+L}\Delta_d(t)\,dt-d
\right|
\le\frac{4d}{L}.
\tag{9.1}
\]

At `L=8`,

\[
\frac18\int_X^{X+8}\Delta_d(t)\,dt\ge\frac d2.
\tag{9.2}
\]

Therefore every length-eight interval contains a point `p` with

\[
\Delta_d(p)\ge d/2.
\tag{9.3}
\]

Under the syndetic-zero alternative, the same interval also contains a point
`q` with `Delta_d(q)=0`.  Hence

\[
\boxed{
\operatorname{osc}_{[X,X+8]}\Delta_d\ge d/2
\qquad\text{for every }X.
}
\tag{9.4}
\]

Thus the zero-rich branch cannot approach a flat or slowly varying translation
defect.  It must repeatedly rise by order `d` and return to zero on a universal
horizontal scale.

---

# 10. Updated compact obstruction

Combining v159 with Sections 3--9 gives the following hierarchy.

For a finite regular endpoint chamber centered in a zero-free length-eight
window of `Delta_d`:

\[
\boxed{
\text{phase cell}
\quad\text{or}\quad
\operatorname{int}K(f)\ne\varnothing.
}
\tag{10.1}
\]

If no zero-free length-eight window exists, then

\[
\boxed{
Z(\Delta_d)\text{ is 8-syndetic},
}
\tag{10.2}
\]

which forces both

\[
\boxed{
\operatorname{Var}_{[0,L]}h\gtrsim \frac{d}{8+d}L
}
\tag{10.3}
\]

and

\[
\boxed{
\operatorname{osc}_{[X,X+8]}\Delta_d\ge d/2.
}
\tag{10.4}
\]

Therefore the compact square-free survivor is no longer described adequately
as “backtracking.”  It must exhibit at least one of:

1. **critical-set interior:** an interval of nowhere-local-injectivity, hence
   microscopic return arches or plateaus everywhere in that interval;
2. **syndetic defect zeros:** recurrent exact slope-`-1` residual drops with
   positive variation density;
3. **infinite endpoint branch complexity:** the finite regular chamber itself
   fails before v159 can be applied.

The first two alternatives are both quantitative forms of persistent rough
folding.

---

# 11. What v160 closes

## Closed: isolated/finitely many third-contact critical points as an escape

A finite collection of ordinary turning points cannot lock every point of an
open target chamber.  Persistent locking forces an interval inside `K(f)`.

## Closed: nowhere-dense critical sets in sign-coherent finite chambers

If `K(f)` has empty interior, some subchamber avoids all third-contact critical
positions, and v159 gives nonzero relative degree.

## Quantified: defect-sign recurrence

Failure of every length-eight sign-coherent window is equivalent to an
8-syndetic defect-zero condition, which forces the variation and oscillation
bounds above.

---

# 12. What remains open

## Open I: interval critical sets / nowhere-local-injective bands

A continuous function can in principle fold at arbitrarily small scales on an
entire interval.  v160 shows that this is what finite-branch critical locking
must converge to, but it does not yet rule it out.

## Open II: infinite endpoint branch currents

A phase level may have infinitely many crossings.  The v159 finite interval
current should have a locally finite current limit, but a robust no-cancellation
theorem for that limit is still missing.

## Open III: syndetic defect-zero roughness

The linear variation-density estimate is strong but not contradictory to an
arbitrary `C^0` balanced profile.  A new compactness or signed-current argument
is needed to convert this recurrent slope saturation into degree.

## Open IV: noncompact critical sequences

The critical zoom may still fail local equicontinuity.

## Open V: terminal/Jordan transfer

The inherited bounded-terminal-packet and general Jordan transfer problems
remain untouched.

---

# 13. Recommended v161 target

The three remaining compact singularities should now be unified using the
**first-hit inverse**

\[
g(y)=\min\{t:f(t)=y\}.
\tag{13.1}
\]

It is monotone, satisfies `|g(y)-y|<=2`, and its jumps are exactly the record
return arches.  This converts arbitrary folding of `f` into a monotone
Stieltjes object.

The promising next question is whether the v159 endpoint current can be
rewritten in terms of the Lebesgue--Stieltjes measure `dg` plus an excursion
correction.  If so:

- finite regular crossings become atoms/sign changes of the absolutely
  continuous branch representation;
- record arches become atoms of `dg`;
- an interval of `K(f)` should appear as a singular-continuous or infinite
  excursion component;
- syndetic defect zeros should force a positive lower density of excursion
  mass.

A successful Stieltjes formulation could replace branch counting altogether
and attack Open I--III at once.

A second, more computational route is to approximate a nowhere-locally-
injective interval by PL functions with increasing lap number and measure how
the v159 signed endpoint current concentrates.  The numerical question is
whether cancellation mass is forced onto a vanishing set of third-contact
critical values or whether a nonzero degree survives uniformly.

---

# 14. Bottom line

The v159 singular escape has been narrowed from

\[
\text{critical point or infinite folding}
\]

to

\[
\boxed{
\text{critical-set interior}
\quad\text{or}\quad
\text{8-syndetic defect zeros with positive variation density}
\quad\text{or}\quad
\text{genuinely infinite endpoint current}.
}
\tag{14.1}
\]

The first alternative is forced by Baire category, not by a smoothness
assumption.  The second carries exact quantitative roughness.  Ordinary finite
folding and sparse criticality are no longer viable compact escape mechanisms.
