# Project Handoff v161: Record-Envelope / Stieltjes Reduction and Approximate Phase Channels

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v160 left three compact singular mechanisms in the balanced critical profile

\[
f(t)=t+h(t),\qquad |h(t)|\le 2:
\tag{0.1}
\]

1. an interval of nowhere-local-injectivity;
2. an 8-syndetic zero set of a return-arch translation defect;
3. genuinely infinite endpoint branch complexity.

The suggested v161 route was to replace branch enumeration by the monotone
first-hit inverse.  That route works substantially better than a branch list,
but not yet far enough to close the compact branch.

The main new objects are the first- and last-hit inverses

\[
g(y)=\min\{t:f(t)=y\},\qquad
\ell(y)=\max\{t:f(t)=y\},
\tag{0.2}
\]

the running record envelopes

\[
M(t)=\max_{s\le t}f(s),\qquad
N(t)=\min_{s\ge t}f(s),
\tag{0.3}
\]

and the post-first-hit excursion slice

\[
A_y=\{t>g(y):f(t)\le y\}.
\tag{0.4}
\]

The exact branch-free oriented level-current identity is

\[
\boxed{
R_y:=D_t\mathbf 1_{\{f>y\}}
=\delta_{g(y)}-D_t\mathbf 1_{A_y}.
}
\tag{0.5}
\]

There is a symmetric last-hit formula

\[
\boxed{
R_y=\delta_{\ell(y)}+D_t\mathbf 1_{B_y},
\qquad
B_y=\{t<\ell(y):f(t)>y\}.
}
\tag{0.6}
\]

The correction sets are universally localized:

\[
A_y\subset[g(y),y+2],\qquad
B_y\subset[y-2,\ell(y)],
\tag{0.7}
\]

so every correction lies in a horizontal window of width at most four.

This gives an exact meaning to “infinite branch current”: it is the failure of
the excursion indicator to have finite one-dimensional perimeter.  Finite
regular branches are simply the atomic expansion of (0.5).

The second main result regularizes the discontinuous first-hit inverse.
Complete the monotone graph of `g` by inserting the vertical segment across
each jump.  If every jump in a compact phase band has horizontal size at most
`epsilon`, then, for every `lambda in (0,1)`, the completed graph can be tilted
into a continuous ordered approximate inverse channel with phase error

\[
\boxed{
\eta\le \omega_f(\varepsilon)+2\lambda,
}
\tag{0.8}
\]

where `omega_f` is the local modulus of continuity on the corresponding
horizontal root window.  The same theorem holds for the last-hit inverse.

v158's two-channel degree argument is stable under such phase errors.  Thus an
exact phase-channel desert cannot be maintained merely by arbitrarily tiny
first-/last-hit jumps.  A square-free tail must instead supply at least one of:

\[
\boxed{
\text{macroscopic record jumps}
\quad\text{or}\quad
\text{deteriorating local modulus}
\quad\text{or}\quad
\text{vanishing return-defect margin}.
}
\tag{0.9}
\]

The Stieltjes route therefore unifies the finite/infinite branch language and
shrinks the channel obstruction, but a nonlinear push-forward problem remains:
when `D 1_{A_y}` is only a distribution of infinite variation, the third-phase
map cannot yet be applied to it as a signed Radon current.  That is now the
clean analytic obstruction.

---

# 1. First-hit and last-hit inverses exist globally

Because `|f(t)-t|<=2`,

\[
f(t)\to-\infty\quad(t\to-\infty),\qquad
f(t)\to+\infty\quad(t\to+\infty).
\tag{1.1}
\]

Hence every phase `y` is attained, and its level set is contained in

\[
[y-2,y+2].
\tag{1.2}
\]

Therefore both extrema in (0.2) exist and

\[
\boxed{|g(y)-y|\le2,\qquad |\ell(y)-y|\le2.}
\tag{1.3}
\]

If `y_1<y_2`, continuity implies that the first encounter with `y_1` occurs
strictly before the first encounter with `y_2`; otherwise reaching `y_2`
would force an earlier crossing of `y_1`.  Hence

\[
\boxed{g\text{ is strictly increasing}.}
\tag{1.4}
\]

The same argument from the right gives

\[
\boxed{\ell\text{ is strictly increasing}.}
\tag{1.5}
\]

The first-hit inverse is left-continuous.  Indeed, if `y_n up y`, then
`g(y_n)` increases to some `L<=g(y)`; continuity gives `f(L)=y`, so minimality
forces `L=g(y)`.  Dually, `ell` is right-continuous.

Write

\[
g(y+)=\lim_{v\downarrow y,\ v>y}g(v),
\qquad
\ell(y-)=\lim_{v\uparrow y,\ v<y}\ell(v).
\tag{1.6}
\]

Their jumps satisfy

\[
0\le g(y+)-g(y)\le4,
\qquad
0\le \ell(y)-\ell(y-)\le4.
\tag{1.7}
\]

---

# 2. Record envelopes

Define

\[
M(t)=\max_{s\le t}f(s).
\tag{2.1}
\]

The maximum exists because `f(s)->-infty` on the left.  The running maximum is
continuous and nondecreasing.  Moreover

\[
f(t)\le M(t)\le t+2,
\tag{2.2}
\]

while `f(t)>=t-2`, so

\[
\boxed{|M(t)-t|\le2.}
\tag{2.3}
\]

Similarly

\[
N(t)=\min_{s\ge t}f(s)
\tag{2.4}
\]

is continuous, nondecreasing, and

\[
\boxed{|N(t)-t|\le2.}
\tag{2.5}
\]

The first-hit inverse is the generalized inverse of `M`:

\[
\boxed{
g(y)=\inf\{t:M(t)\ge y\}.
}
\tag{2.6}
\]

Indeed, the first time the running maximum reaches `y` is exactly the first
time `f` reaches `y`.

The last-hit inverse is the corresponding generalized inverse of the future
minimum `N`.

---

# 3. Jumps are exactly record return arches

Suppose

\[
a=g(y),\qquad b=g(y+),\qquad d=b-a>0.
\tag{3.1}
\]

For every `t in (a,b)`, one must have `f(t)<=y`.  Otherwise, if `f(t)>y`, then
some level `y'<f(t)` with `y'>y` would be reached before `b`, contradicting
the definition of `g(y+)`.

Taking levels `y_n down y` and first-hit points `g(y_n)->b` gives

\[
f(b)=y.
\tag{3.2}
\]

Hence

\[
\boxed{
f(a)=f(b)=y,\qquad f(t)\le y\quad(a\le t\le b).
}
\tag{3.3}
\]

Equivalently, `M` is constant at height `y` on `[a,b]`.  Thus every atom of
the Stieltjes derivative of `g` is a record return arch, and its atom mass is
exactly the arch width.

Dually, a jump of `ell` is an upper record arch

\[
f(a)=f(b)=y,\qquad f(t)\ge y\quad(a\le t\le b).
\tag{3.4}
\]

This gives a canonical arch decomposition independent of a chosen branch
enumeration.

---

# 4. Bounded-discrepancy Stieltjes measures

Use the right-continuous representative

\[
G(y)=g(y+).
\tag{4.1}
\]

It is increasing and satisfies `|G(y)-y|<=2`.  Let

\[
\mu_g=dG
\tag{4.2}
\]

be its Lebesgue--Stieltjes measure.  For every `u<v`,

\[
\mu_g((u,v])=G(v)-G(u),
\tag{4.3}
\]

hence

\[
\boxed{
|\mu_g((u,v])-(v-u)|\le4.
}
\tag{4.4}
\]

In particular every atom has mass at most four, recovering the return-width
bound without a separate calculation.

The atomic part is

\[
\mu_g^{\rm at}
=
\sum_y\bigl(g(y+)-g(y)\bigr)\delta_y.
\tag{4.5}
\]

The same construction applies to the right-continuous last-hit inverse
`ell`, producing `mu_ell` with the same interval-discrepancy bound.

A phase interval `J` supports an exact continuous first-hit channel iff `g`
has no jump on `J`, equivalently iff

\[
\mu_g^{\rm at}(\{y\})=0
\quad\text{for every }y\in J.
\tag{4.6}
\]

Thus v158's exact channel desert becomes an atomic Stieltjes statement.

---

# 5. Excursion slices

For each phase `y` define

\[
A_y=\{t>g(y):f(t)\le y\}.
\tag{5.1}
\]

If `t in A_y`, then `t<=y+2`; otherwise `f(t)>=t-2>y`.  Combined with
`g(y)>=y-2`,

\[
\boxed{
A_y\subset[g(y),y+2]\subset[y-2,y+2].
}
\tag{5.2}
\]

Similarly

\[
B_y=\{t<\ell(y):f(t)>y\}
\tag{5.3}
\]

satisfies

\[
\boxed{
B_y\subset[y-2,\ell(y)]\subset[y-2,y+2].
}
\tag{5.4}
\]

The entire noncanonical branch correction is therefore localized to a
universal horizontal radius-two window around the phase level.

---

# 6. Exact branch-free oriented level current

Set

\[
\chi_y(t)=\mathbf 1_{\{f(t)>y\}}.
\tag{6.1}
\]

For `t<g(y)`, necessarily `f(t)<y`.  For `t>g(y)`,

\[
\chi_y(t)
=
1-\mathbf 1_{A_y}(t).
\tag{6.2}
\]

Point values at `t=g(y)` are irrelevant distributionally, so

\[
\chi_y
=
\mathbf 1_{(g(y),\infty)}-\mathbf 1_{A_y}.
\tag{6.3}
\]

Taking distributional derivatives gives

\[
\boxed{
R_y:=D_t\chi_y
=
\delta_{g(y)}-D_t\mathbf 1_{A_y}.
}
\tag{6.4}
\]

Using the last hit instead,

\[
\chi_y
=
\mathbf 1_{(\ell(y),\infty)}+\mathbf 1_{B_y},
\tag{6.5}
\]

hence

\[
\boxed{
R_y
=
\delta_{\ell(y)}+D_t\mathbf 1_{B_y}.
}
\tag{6.6}
\]

Equations (6.4) and (6.6) are exact for every continuous balanced profile.
No branch regularity is assumed.

## 6.1 Recovery of the finite branch sum

At a regular finite-crossing level with roots

\[
t_1<t_2<\cdots<t_{2k+1},
\tag{6.7}
\]

the crossing signs alternate `+,-,+,...,+`, `g(y)=t_1`, and

\[
A_y=[t_2,t_3]\cup[t_4,t_5]\cup\cdots\cup[t_{2k},t_{2k+1}]
\tag{6.8}
\]

up to endpoint conventions.  Therefore

\[
D\mathbf1_{A_y}
=\delta_{t_2}-\delta_{t_3}+\cdots+
\delta_{t_{2k}}-\delta_{t_{2k+1}},
\tag{6.9}
\]

and (6.4) becomes exactly

\[
R_y
=
\delta_{t_1}-\delta_{t_2}+\delta_{t_3}-\cdots+\delta_{t_{2k+1}}.
\tag{6.10}
\]

Thus the v159 signed branch list is the finite-perimeter expansion of one
canonical excursion distribution.

---

# 7. Excursion region and the layer-cake identity

Define the two-dimensional record-excursion region

\[
\mathcal A
=
\{(t,y):f(t)\le y<M(t)\}.
\tag{7.1}
\]

For fixed `t`, the vertical slice has length

\[
M(t)-f(t).
\tag{7.2}
\]

For fixed `y`, its horizontal slice agrees with `A_y` up to phase-boundary
sets that do not affect Lebesgue measure.  Indeed, `y<M(t)` means the level
`y` was hit before time `t`, and `f(t)<=y` means the trajectory has returned
below that level.

Therefore Fubini gives the exact layer-cake identity

\[
\boxed{
\int_{\mathbb R}|A_y\cap I|\,dy
=
\int_I\bigl(M(t)-f(t)\bigr)\,dt
}
\tag{7.3}
\]

for every bounded time interval `I`.

Since

\[
0\le M(t)-f(t)\le4,
\tag{7.4}
\]

we also have

\[
\boxed{
\int_{\mathbb R}|A_y\cap I|\,dy\le4|I|.
}
\tag{7.5}
\]

This is the first exact area budget for all post-first-hit excursions at once.

---

# 8. Finite perimeter and the meaning of infinite branch complexity

In one dimension, if `1_{A_y}` has bounded variation on its compact support,
then `A_y` is, modulo null sets, a finite union of intervals.  In that case

\[
D\mathbf1_{A_y}
\tag{8.1}
\]

is a finite signed Radon measure and (6.4) is a finite level current.

For a generic PL level with `2k+1` roots,

\[
\operatorname{Per}(A_y)=2k,
\tag{8.2}
\]

so

\[
\boxed{
\#\{\text{oriented level crossings}\}
=1+\operatorname{Per}(A_y).
}
\tag{8.3}
\]

Thus v160's “infinite endpoint branch current” is exactly the infinite-
perimeter branch of the canonical excursion slice.

## 8.1 Exact PL coarea audit

Let `J=[Y_0,Y_1]` be a compact regular phase band for a proper PL balanced
profile.  Every `y in J` has odd crossing count `N(y)` and

\[
\operatorname{Per}(A_y)=N(y)-1
\tag{8.4}
\]

for almost every `y`.

On each PL segment, the integral of its level-crossing indicator over `J` is
exactly the length of the overlap between `J` and the segment's phase range.
Summing segments gives

\[
\int_JN(y)\,dy
=
\sum_{e}\bigl|J\cap f(e)\bigr|,
\tag{8.5}
\]

where `f(e)` denotes the interval between the endpoint phase values of segment
`e`.  Hence

\[
\boxed{
\int_J\operatorname{Per}(A_y)\,dy
=
\sum_e|J\cap f(e)|-|J|.
}
\tag{8.6}
\]

The right side is precisely the phase-band variation in excess of the one
net upward crossing forced by degree one.

This formula is useful because it shows where a Stieltjes strategy can and
cannot be expected to control the branch current.  At an individual phase,
infinite endpoint complexity is the infinite-perimeter case.  Averaged over a
phase band, the integral of that perimeter is exactly the excess crossing
variation in (8.6).  An isolated infinite-perimeter level need not by itself
make the band integral infinite.

---

# 9. Pair current decomposition

For two endpoint phases `alpha,beta`, the first-two-phase oriented product
current is formally

\[
R_\alpha\otimes R_\beta.
\tag{9.1}
\]

Substituting (6.4),

\[
\boxed{
\begin{aligned}
R_\alpha\otimes R_\beta
={}&
\delta_{g(\alpha)}\otimes\delta_{g(\beta)}
-
\delta_{g(\alpha)}\otimes D\mathbf1_{A_\beta}\\
&-
D\mathbf1_{A_\alpha}\otimes\delta_{g(\beta)}
+
D\mathbf1_{A_\alpha}\otimes D\mathbf1_{A_\beta}.
\end{aligned}}
\tag{9.2}
\]

Every correction is supported inside the same universal radius-two phase
windows from Section 5.  This recovers the radius-four pair-sum localization
of v159 without naming any individual branch.

When the excursion derivatives are finite Radon measures, (9.2) can be pushed
forward by the continuous endpoint third-phase maps and reproduces the v159
signed endpoint current.

When one excursion derivative has infinite variation, (9.2) remains a valid
tensor distribution, but a nonlinear push-forward by the third-phase map is
not automatically defined.  This is the precise analytic point at which the
branch-free Stieltjes program still stops.

---

# 10. Completed first-hit graph

For a compact phase interval `J`, define the completed graph

\[
\Gamma_g(J)
=
\{(y,t):y\in J,\ g(y)\le t\le g(y+)\}.
\tag{10.1}
\]

At continuity points this is the ordinary graph.  At a jump it inserts the
vertical segment across the corresponding record arch.

The graph is compact and totally ordered: as one moves along it, both `y` and
`t` are nondecreasing, and at least one increases strictly between distinct
points.

For `0<lambda<1`, define

\[
q=(1-\lambda)y+\lambda t.
\tag{10.2}
\]

Along `Gamma_g(J)`, `q` is strictly increasing.  Therefore `q` is a
homeomorphism from the completed graph onto an interval.  Write its inverse as

\[
q\longmapsto (Y(q),T(q)).
\tag{10.3}
\]

Since every point of the completed graph satisfies `|t-y|<=2`,

\[
\boxed{|Y(q)-q|\le2\lambda.}
\tag{10.4}
\]

---

# 11. Small-jump approximate-channel theorem

Let

\[
I_J=[\inf J-2,\sup J+2]
\tag{11.1}
\]

and define the local modulus

\[
\omega_{f,J}(r)
=
\sup\{|f(s)-f(t)|:s,t\in I_J,\ |s-t|\le r\}.
\tag{11.2}
\]

Assume every first-hit jump in `J` has width at most `epsilon`:

\[
\sup_{y\in J}\bigl(g(y+)-g(y)\bigr)\le\varepsilon.
\tag{11.3}
\]

At a nonjump point of the completed graph, `f(t)=y`.  At a jump, `[a,b]` is a
record arch of width at most `epsilon`, `f(a)=f(b)=y`, and every point
`t in [a,b]` lies within `epsilon` of an endpoint.  Hence

\[
|f(t)-y|\le\omega_{f,J}(\varepsilon)
\tag{11.4}
\]

on the entire completed graph.

Combining with (10.4),

\[
\boxed{
|f(T(q))-q|
\le
\omega_{f,J}(\varepsilon)+2\lambda.
}
\tag{11.5}
\]

Moreover `T(q)` is continuous and nondecreasing.  After discarding at most a
`2lambda` phase margin at each endpoint of `J`, its `q`-domain contains the
corresponding shrunken phase band.

> **Theorem 11.1 — small-jump approximate first-hit channel.**  Dense first-hit
> jumps do not by themselves destroy a phase channel.  If their horizontal
> sizes are uniformly at most `epsilon`, the completed graph supplies a
> continuous ordered approximate inverse whose phase error is bounded by
> `omega_{f,J}(epsilon)+2lambda`.

The identical statement holds for the completed last-hit graph, using jumps
of `ell`.

The theorem is purely `C^0` and remains valid with infinitely many dense
jumps.

---

# 12. Approximate channels still give return-arch degree

The exact-channel hypothesis in v158 can be weakened.

Let `[a,b]` be a return arch of depth `D`, and suppose continuous maps `L,R`
are defined on the required left/right phase bands, have images respectively
in `(-infinity,a)` and `(b,infinity)`, and satisfy

\[
|f(L(y))-y|\le\eta,
\qquad
|f(R(y))-y|\le\eta.
\tag{12.1}
\]

Use the same parameterization as v158:

\[
u_0=L(f(s)-r_1),\qquad
u_1=s,\qquad
u_2=R(f(s)+r_2).
\tag{12.2}
\]

Write

\[
f(L(y))=y+e_-(y),\qquad
f(R(y))=y+e_+(y),
\quad |e_\pm|\le\eta.
\tag{12.3}
\]

Then the first two adjacent phase coordinates are

\[
X_1=r_1-e_-(f(s)-r_1),
\tag{12.4}
\]

\[
X_2=r_2+e_+(f(s)+r_2),
\tag{12.5}
\]

so

\[
\boxed{|X_1-r_1|\le\eta,\qquad |X_2-r_2|\le\eta.}
\tag{12.6}
\]

At `s=a,b`, the inputs to `L` and `R` are identical because `f(a)=f(b)`.
Therefore the auxiliary contacts agree on the two faces exactly, even though
the channels are only approximate.  Consequently the third-coordinate face
gap is still

\[
\boxed{
W(r_1,r_2,a)-W(r_1,r_2,b)
=
\Delta_d\bigl(L(z-r_1)+R(z+r_2)-b\bigr).
}
\tag{12.7}
\]

No approximation appears in (12.7).

Choose a parameter rectangle of half-width `rho` in `(r_1,r_2)`.  If

\[
\eta<\rho
\tag{12.8}
\]

then (12.6) gives the required opposite signs for `X_1-r_1^*` and
`X_2-r_2^*` on the four side faces.  If the central defect in (12.7) is nonzero, continuity permits the parameter
rectangle to be shrunk so that the defect keeps one strict sign and both
endpoint face functions vary by less than (say) one eighth of the central gap.
Then their ranges have a common open interval between them.  Choose the third
target in that interval.  Poincare--Miranda / Brouwer degree gives a protected
three-dimensional phase target exactly as in v158.

> **Theorem 12.1 — approximate two-channel return-arch theorem.**  v158 remains
> valid when exact inverse channels are replaced by continuous approximate
> channels whose phase error is smaller than the first-two-coordinate boundary
> margin.  The transverse return-arch defect remains exact.

This is the key payoff of Section 11.

---

# 13. Quantitative replacement for the channel desert

Combine Theorems 11.1 and 12.1.

Fix a return arch `[a,b]` of depth `D`.  Consider a candidate left phase band
`J_-` and right phase band `J_+` large enough to contain the width-`D` ranges
used by v158 plus a small robustness margin.

Suppose

\[
\sup_{y\in J_-}\bigl(g(y+)-g(y)\bigr)\le\varepsilon_-,
\tag{13.1}
\]

and, on the right, the last-hit jumps satisfy

\[
\sup_{y\in J_+}\bigl(\ell(y)-\ell(y-)\bigr)\le\varepsilon_+.
\tag{13.2}
\]

Then completed-graph regularization gives left/right approximate channels with
errors

\[
\eta_-
\le\omega_{f,J_-}(\varepsilon_-)+2\lambda,
\qquad
\eta_+
\le\omega_{f,J_+}(\varepsilon_+)+2\lambda.
\tag{13.3}
\]

If these errors fit inside the target margins and the sampled translation
defect stays away from zero, Theorem 12.1 forces a square.

Therefore a square-free profile cannot use arbitrarily tiny record jumps as a
stand-alone obstruction.  On every candidate pair of side bands with a
nonvanishing defect margin, at least one of the following must occur:

1. a first-/last-hit jump has **macroscopic horizontal width**;
2. the local modulus `omega_f(epsilon)` is too large at the required scale;
3. the translation defect collapses toward zero on the corresponding sumset.

In symbols, schematically,

\[
\boxed{
\text{square-free}
\Longrightarrow
\text{large atom}
\ \vee\
\text{rough modulus}
\ \vee\
|\Delta_d|\text{ small}.
}
\tag{13.4}
\]

This is a strict improvement over the v158/v160 phrase “channel desert.”
A dense set of tiny jumps is no longer enough.

---

# 14. Relation to the v160 singular branches

## 14.1 Critical-set interior

An interval inside `K(f)` may contain folds at arbitrarily small scales.  v161
shows that if those folds have vanishing horizontal jump sizes and the local
modulus remains controlled, their completed first-/last-hit graphs still act
as approximate channels.  Thus the `K(f)`-interior obstruction must carry
quantitative roughness, not merely topological noninjectivity.

## 14.2 Syndetic defect zeros

v160 showed that a syndetic zero branch forces recurrent exact return pairs and
positive variation density in `h`.  v161 adds that if the side record jumps
around those pairs are all microscopically small, they can be regularized into
approximate channels.  A survivor must therefore coordinate defect zeros with
macroscopic record arches or with a deteriorating modulus.

## 14.3 Infinite endpoint current

This branch is now represented exactly by `D 1_{A_y}`.  Finite perimeter gives
the v159 finite signed current.  Infinite perimeter is the genuinely new case.
There is no need to speak about an unspecified infinite list of branches.

---

# 15. The analytic obstruction exposed by v161

The Stieltjes idea does **not** automatically solve the infinite-current case.
Equation (9.2) is a tensor distribution when an excursion slice has infinite
perimeter.  The third-phase endpoint map contains

\[
(u,v)\longmapsto f(u+v-s)-f(u),
\tag{15.1}
\]

which is merely continuous in the critical `C^0` setting.  There is no general
operation that pushes an arbitrary distribution of order one through a
nonlinear continuous map.

Thus the exact remaining problem is:

\[
\boxed{
\text{replace nonlinear push-forward of }D\mathbf1_{A_y}
\text{ by a topological/flat-norm object stable at infinite perimeter.}
}
\tag{15.2}
\]

Two plausible routes remain.

### Route A — finite-scale perimeter truncation

Truncate the excursion set to components whose phase/horizontal persistence
exceeds `epsilon`.  The persistent part is finite.  Prove that the discarded
small components have vanishing effect on the endpoint degree in a topology
strong enough for the third-phase map.  Theorem 11.1 is the first input to such
a proof.

### Route B — excursion-region topology

Work with the two-dimensional set

\[
\mathcal A=\{(t,y):f(t)\le y<M(t)\}
\tag{15.3}
\]

directly.  Its boundary is a geometric object even when individual horizontal
slices have infinite perimeter.  A relative homology or mod-2 intersection
construction on `\partial\mathcal A` may survive the nonlinear third-contact
map better than a distributional slice current.

---

# 16. Recommended v162 target

The best next step is a **persistence truncation theorem**.

For a phase band `J` and threshold `epsilon>0`, collapse every first-hit record
arch of width `<epsilon` and every last-hit record arch of width `<epsilon`.
The completed-graph theorem says this collapse changes phase by at most the
local modulus `omega_f(epsilon)`.

One then wants to prove:

\[
\boxed{
\text{after epsilon-truncation, the endpoint degree current is finite,}
}
\tag{16.1}
\]

and, more importantly,

\[
\boxed{
\text{its degree differs from the original by }o(1)
\text{ as }\varepsilon\downarrow0
}
\tag{16.2}
\]

under the critical local-modulus hypotheses.

If (16.2) can be obtained without a BV assumption, v159's finite orientation
argument can be applied at every truncation scale and then passed to the
limit.  That would remove the infinite-current branch and likely absorb the
`K(f)`-interior branch as well.

A computational companion should approximate highly oscillatory PL balanced
profiles with increasing lap number, compute the excursion slice perimeter,
truncate by arch width, and measure the flat norm / threshold-degree error of
the resulting endpoint current.  The important empirical question is whether
small-arch cancellation really vanishes with the horizontal persistence scale
or can remain order one.

---

# 17. Bottom line

v161 replaces the branch language by the exact identities

\[
\boxed{
R_y=\delta_{g(y)}-D\mathbf1_{A_y}
=\delta_{\ell(y)}+D\mathbf1_{B_y}
}
\tag{17.1}
\]

and

\[
\boxed{
\int|A_y\cap I|\,dy
=
\int_I(M-f).
}
\tag{17.2}
\]

The Stieltjes atoms of `g` are precisely record return arches, with bounded
interval discrepancy inherited from `|g(y)-y|<=2`.

Most importantly, dense **small** atoms can be regularized into approximate
continuous phase channels:

\[
\boxed{
\eta\le\omega_f(\varepsilon)+2\lambda.
}
\tag{17.3}
\]

Since v158's return-arch degree survives such approximate channels, the compact
escape is now quantitatively narrower:

\[
\boxed{
\text{macroscopic arch persistence}
\quad\text{or}\quad
\text{tail-scale roughness}
\quad\text{or}\quad
\text{defect collapse}
\quad\text{or}\quad
\text{infinite-perimeter nonlinear-current obstruction}.
}
\tag{17.4}
\]

The last item is the principal v162 target.
