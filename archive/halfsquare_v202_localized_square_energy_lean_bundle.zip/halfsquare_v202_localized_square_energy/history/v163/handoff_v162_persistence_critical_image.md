# Project Handoff v162: Persistence Truncation, Critical Images, and a Sharp C0 Counterexample

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v161 isolated the analytic obstruction in the compact critical-profile branch:
for a continuous balanced profile

\[
f(t)=t+h(t),\qquad |h(t)|\le 2,
\tag{0.1}
\]

the oriented level current can be written branch-free as

\[
R_y=\delta_{g(y)}-D\mathbf 1_{A_y},
\tag{0.2}
\]

but if the excursion slice `A_y` has infinite perimeter, the distribution
`D 1_{A_y}` cannot in general be pushed through the merely continuous
third-phase map.

v161 proposed persistence truncation: discard excursion components whose
horizontal widths are below `epsilon`, obtain a finite current, and attempt to
pass `epsilon -> 0`.

v162 resolves that proposal in the following precise sense.

1. The strongest naive statement is **false in C0**.  Even if the discarded
   source current goes to zero in flat norm geometrically fast, its nonlinear
   third-phase push-forward can carry unbounded threshold degree and can even
   fail to converge distributionally against a smooth test function.
2. The failure is nevertheless localized.  Define the **vanishing-persistence
   core** `K_y` of a level excursion slice.  For every continuous endpoint map,
   persistence-truncated threshold degree stabilizes **exactly** at every
   target outside the image of that core.
3. For the two-variable endpoint current relevant to the square map, the only
   bad targets lie in an explicit compact **critical image**

   \[
   \Sigma_s(\alpha,\beta)
   =C_s(K_\alpha\times L_\beta)
   \cup C_s(L_\alpha\times K_\beta),
   \tag{0.3}
   \]

   where `L_y` is the full oriented level-support set and

   \[
   C_s(u,v)=f(u+v-s)-f(u).
   \tag{0.4}
   \]
4. Because `K_y subset f^{-1}(y)`, the critical image has the additive form

   \[
   \boxed{
   \Sigma_s(\alpha,\beta)
   =\bigl[f(K_\alpha+L_\beta-s)-\alpha\bigr]
    \cup
    \bigl[f(L_\alpha+K_\beta-s)-\alpha\bigr].
   }
   \tag{0.5}
   \]

Thus the infinite-current branch is no longer “persistence truncation may
fail.”  It is reduced to a specific singular mechanism:

\[
\boxed{
\text{all nonzero finite-truncation degree must concentrate onto }
\Sigma_s.
}
\tag{0.6}
\]

In the nonplateau branch, each `K_y` is compact with empty interior.  The new
remaining obstruction is therefore an additive/fractal one: a nowhere-dense
vanishing-persistence core must have a sufficiently large sumset image to
swallow the degree targets.

---

# 1. Use the open excursion slice

For persistence it is cleaner to replace v161's closed slice by its open
interior

\[
U_y=\{t>g(y):f(t)<y\}.
\tag{1.1}
\]

It is contained in `[y-2,y+2]` and is a countable disjoint union of open
intervals

\[
U_y=\bigsqcup_{I\in\mathcal C_y} I,
\qquad I=(a_I,b_I).
\tag{1.2}
\]

Every nondegenerate component has

\[
f(a_I)=f(b_I)=y,
\tag{1.3}
\]

and corresponds to one downward return below level `y`.

At finite perimeter, the excursion correction is

\[
-D\mathbf 1_{U_y}
=\sum_{I\in\mathcal C_y}(-\delta_{a_I}+\delta_{b_I}),
\tag{1.4}
\]

with the sum finite.  At infinite perimeter, (1.4) is only formal, but each
finite persistence truncation below is a genuine finite current.

For `epsilon>0`, define

\[
\mathcal C_y^{\ge\varepsilon}
=\{I\in\mathcal C_y:|I|\ge\varepsilon\}.
\tag{1.5}
\]

Since the components are disjoint and lie in a window of length at most four,

\[
\#\mathcal C_y^{\ge\varepsilon}\le \frac4\varepsilon.
\tag{1.6}
\]

Hence the persistence-truncated current

\[
R_y^{\varepsilon}
=\delta_{g(y)}
+\sum_{I\in\mathcal C_y^{\ge\varepsilon}}
(-\delta_{a_I}+\delta_{b_I})
\tag{1.7}
\]

is always finite.

---

# 2. Vanishing-persistence core

Define

\[
V_y(\varepsilon)
=\bigcup_{I\in\mathcal C_y,\ |I|<\varepsilon}\overline I
\tag{2.1}
\]

and the compact nested core

\[
\boxed{
K_y
=\bigcap_{\varepsilon>0}\overline{V_y(\varepsilon)}.
}
\tag{2.2}
\]

This is the set on which arbitrarily small excursion components accumulate.

## Proposition 2.1 — the core lies in the level set

\[
\boxed{K_y\subseteq f^{-1}(y).}
\tag{2.3}
\]

### Proof

Take `x in K_y`.  There are components `I_n=(a_n,b_n)` with
`|I_n| -> 0` and points `x_n in closure(I_n)` such that `x_n -> x`.
Because `f(a_n)=f(b_n)=y` and every `x_n` lies at distance at most `|I_n|`
from one endpoint, uniform continuity on the compact root window gives

\[
f(x_n)\to y.
\tag{2.4}
\]

Continuity then gives `f(x)=y`.  QED.

Consequently, if `f` has no plateau at level `y`, then `K_y` has empty
interior.  It can still be a Cantor or fat-Cantor type set.

Define also the compact full level-support set

\[
L_y
=\overline{\{g(y)\}\cup
\bigcup_{I\in\mathcal C_y}\{a_I,b_I\}}.
\tag{2.5}
\]

Then

\[
K_y\subseteq L_y\subseteq f^{-1}(y)\cap[y-2,y+2].
\tag{2.6}
\]

---

# 3. Exact C0 threshold-stabilization theorem

The key fact is topological and uses only continuity.

Let `U` be a bounded open subset of the line, with disjoint interval
components `I=(a_I,b_I)`, and let `K(U)` be its vanishing-persistence core as
in (2.2).  Let

\[
\Phi:\overline U\to\mathbb R
\tag{3.1}
\]

be continuous.

For a finite truncation define the oriented threshold count

\[
J_\varepsilon(c)
=\sum_{|I|\ge\varepsilon}
\left[
\mathbf1_{\{\Phi(b_I)<c\}}
-\mathbf1_{\{\Phi(a_I)<c\}}
\right].
\tag{3.2}
\]

The orientation matches the correction current `-D 1_U`.

## Theorem 3.1 — persistence stabilization away from the critical image

If

\[
c\notin\Phi(K(U)),
\tag{3.3}
\]

then there exists `epsilon_0>0` such that

\[
\boxed{
J_\varepsilon(c)=J_{\varepsilon_0}(c)
\qquad (0<\varepsilon<\varepsilon_0).
}
\tag{3.4}
\]

In fact the stabilization is locally uniform: if `Q` is compact and

\[
Q\cap\Phi(K(U))=\varnothing,
\tag{3.5}
\]

then one `epsilon_0` works for all `c in Q`.

### Proof

A component contributes nonzero threshold count only if its two endpoint
images lie on opposite sides of `c`.  By the intermediate value theorem this
implies

\[
c\in\Phi(\overline I).
\tag{3.6}
\]

Suppose arbitrarily small components contributed.  Choose `I_n` with
`|I_n|->0` and `x_n in closure(I_n)` with `Phi(x_n)=c`.  Compactness gives a
subsequence `x_n -> x`.  By construction `x in K(U)`, so continuity gives
`Phi(x)=c`, contradicting (3.3).

For compact `Q`, the same contradiction uses points with
`Phi(x_n) in Q` and then compactness of `Q`.  QED.

### Interpretation

This theorem is stronger than flat-norm convergence where it applies.  The
small components do not merely have small total effect: **each sufficiently
small component has exactly zero threshold contribution**.

No BV, Lipschitz, Holder, or differentiability assumption is used.

---

# 4. Why flat norm alone is not enough

For any interval `I=(a,b)`,

\[
\mathcal F(\delta_b-\delta_a)\le b-a.
\tag{4.1}
\]

Hence if the discarded components have total length tending to zero, their
source boundary tends to zero in flat norm.

It is tempting to infer that their nonlinear image also vanishes.  This is
false for a merely continuous map.

The failure is not a technicality.  Section 7 gives an explicit balanced
profile in which

\[
\sum_{n>N}|I_n|\to0
\tag{4.2}
\]

geometrically, while every `I_n` contributes one unit to the same third-phase
threshold.  The pushed finite currents therefore have threshold mass tending
to infinity.

Even against the smooth test `phi(z)=z`, their action is a harmonic sum and
diverges.

Thus there can be no theorem of the form

\[
\mathcal F(T_\varepsilon-T)\to0
\quad\Longrightarrow\quad
\Phi_\#T_\varepsilon\to\Phi_\#T
\tag{4.3}
\]

for arbitrary continuous `Phi` and these infinite-perimeter currents.

Theorem 3.1 identifies exactly where this can happen: only at
`Phi(K(U))`.

---

# 5. Pair-current stabilization

The square map uses a product of two oriented level currents, so the one-line
theorem must be upgraded to two variables.

Let `U,V` be bounded excursion slices with persistence cores `K_U,K_V` and
full level-support sets `L_U,L_V`.  Let

\[
\Phi:L_U\times L_V\to\mathbb R
\tag{5.1}
\]

be continuous.

At persistence threshold `epsilon`, let `T_U^epsilon,T_V^epsilon` be the
finite oriented endpoint currents obtained by retaining components of width
at least `epsilon` (plus any distinguished first-hit root).  Define

\[
J_\varepsilon(c)
=
\sum_{p\in T_U^\varepsilon}
\sum_{q\in T_V^\varepsilon}
 w_p w_q\,
\mathbf1_{\{\Phi(p,q)<c\}}.
\tag{5.2}
\]

Here `w_p,w_q in {+1,-1}` are the endpoint orientations.

Define the pair critical image

\[
\boxed{
\Sigma_\Phi
=\Phi(K_U\times L_V)
\cup
\Phi(L_U\times K_V).
}
\tag{5.3}
\]

## Theorem 5.1 — exact pair stabilization

If

\[
c\notin\Sigma_\Phi,
\tag{5.4}
\]

then `J_epsilon(c)` is eventually constant as `epsilon downarrow 0`.
The stabilization is uniform for `c` in compact subsets of
`R \ Sigma_Phi`.

### Proof

Lower the persistence cutoff.  A change in `J_epsilon` must involve at least
one newly admitted small component.

Suppose first a small `U`-component `I=(a,b)` is newly admitted while a
`V` endpoint `q` is fixed.  Its contribution at that `q` is

\[
w_q\left[
\mathbf1_{\{\Phi(b,q)<c\}}
-
\mathbf1_{\{\Phi(a,q)<c\}}
\right].
\tag{5.5}
\]

If nonzero, continuity supplies `x in closure(I)` with

\[
\Phi(x,q)=c.
\tag{5.6}
\]

If such changes occurred for components with widths tending to zero, a
compactness subsequence would give

\[
x\to x_*\in K_U,
\qquad q\to q_*\in L_V,
\tag{5.7}
\]

and hence

\[
c=\Phi(x_*,q_*)\in\Phi(K_U\times L_V),
\tag{5.8}
\]

contrary to (5.4).

The argument is symmetric for newly admitted `V` components.  Simultaneous
admission is handled sequentially.  QED.

## Binary second-difference check

For one new component in each variable, the four-corner contribution is an
alternating second difference of the binary threshold values.  If it is
nonzero, at least one row and one column contain different binary values.
Thus a threshold-straddling edge always exists, reducing the pair argument to
the one-dimensional IVT mechanism above.

---

# 6. Application to the return-arch endpoint degree

At a return-arch face `s`, the third phase is

\[
C_s(u,v)=f(u+v-s)-f(u).
\tag{6.1}
\]

For the two side phase levels

\[
f(u)=\alpha,
\qquad
f(v)=\beta,
\tag{6.2}
\]

define

\[
\boxed{
\Sigma_s(\alpha,\beta)
=C_s(K_\alpha\times L_\beta)
\cup C_s(L_\alpha\times K_\beta).
}
\tag{6.3}
\]

By Theorem 5.1, the cumulative endpoint degree at third-phase target `c`
stabilizes exactly whenever

\[
c\notin\Sigma_s(\alpha,\beta).
\tag{6.4}
\]

At the two faces `s=a,b` of a return arch, set

\[
\Sigma_{a,b}
=\Sigma_a\cup\Sigma_b.
\tag{6.5}
\]

Then v159's relative-degree identity

\[
\deg_3(c)=\mathcal D_b(c)-\mathcal D_a(c)
\tag{6.6}
\]

can be evaluated by finite persistence truncations at every

\[
c\notin\Sigma_{a,b},
\tag{6.7}
\]

provided the usual side-boundary target exclusions are respected.

Thus infinite perimeter itself is no obstruction at such a target.

> **Corollary 6.1 — finite reduction off the critical image.**  At every
> third-phase target outside `Sigma_{a,b}`, the infinite endpoint current has
> the same relative-degree integer as all sufficiently fine finite
> persistence truncations.

This is the main positive result of v162.

---

# 7. Additive form of the critical image

Because

\[
K_\alpha,L_\alpha\subset f^{-1}(\alpha),
\tag{7.1}
\]

we have, for `u in L_alpha`,

\[
C_s(u,v)=f(u+v-s)-\alpha.
\tag{7.2}
\]

Therefore

\[
\boxed{
\Sigma_s(\alpha,\beta)
=\bigl[f(K_\alpha+L_\beta-s)-\alpha\bigr]
\cup
\bigl[f(L_\alpha+K_\beta-s)-\alpha\bigr].
}
\tag{7.3}
\]

This is the exact singular set on which vanishing-persistence folds can keep
changing the endpoint degree.

The infinite-current obstruction has therefore become an additive-set
problem.

If `f` has no plateau at the side levels, `K_alpha` and `K_beta` have empty
interior.  Yet their sums with the opposite level supports can still contain
intervals (Cantor-sumset behavior), so no contradiction follows from Baire
category alone.

This is now the genuine C0 compact obstruction.

---

# 8. Sharp balanced counterexample

The failure at the critical image can already be realized by the exact
third-phase translation structure.

For `n>=2`, set

\[
a_n=2^{-n},
\qquad
\ell_n=2^{-4n-4},
\qquad
b_n=a_n+\ell_n,
\qquad
\alpha_n=\frac1n.
\tag{8.1}
\]

Construct a continuous piecewise-linear-in-the-complement profile with the
following countable knot data.

Near the origin:

\[
f(0)=0,
\qquad
f(a_n)=f(b_n)=0,
\tag{8.2}
\]

and let `f<0` in the interior of every `(a_n,b_n)`, while `f>0` in all gaps.
The excursions therefore have widths `ell_n` and accumulate only at zero.

Near `t=1`, prescribe

\[
f(1)=1,
\tag{8.3}
\]

and

\[
f(1+a_n)=1+\frac1n,
\qquad
f(1+b_n)=1-\frac1n.
\tag{8.4}
\]

Connect all listed knots linearly in order and take `f(t)=t` outside a bounded
interval.  All prescribed deviations from `t` have magnitude `<1`, so after
linear interpolation

\[
\boxed{|f(t)-t|\le1<2.}
\tag{8.5}
\]

Thus the profile belongs to the balanced class.

At level `y=0`,

\[
U_0=\bigsqcup_{n\ge2}(a_n,b_n),
\qquad
K_0=\{0\}.
\tag{8.6}
\]

Consider the translation map

\[
\Phi(u)=f(u+1)-f(u).
\tag{8.7}
\]

At each excursion endpoint,

\[
\Phi(a_n)=1+\frac1n,
\qquad
\Phi(b_n)=1-\frac1n.
\tag{8.8}
\]

Therefore every excursion straddles the same threshold `c=1`.
The oriented correction `-delta_{a_n}+delta_{b_n}` contributes exactly `+1`
to the sublevel threshold count below `1`.

The persistence-truncated threshold index is consequently

\[
J_N(1)=N-1\to\infty.
\tag{8.9}
\]

But the source flat tail satisfies

\[
\mathcal F\left(
\sum_{n>N}(-\delta_{a_n}+\delta_{b_n})
\right)
\le
\sum_{n>N}\ell_n
\to0
\tag{8.10}
\]

geometrically.

Moreover, against the smooth test `phi(z)=z`,

\[
\sum_{n=2}^N
\left[
\phi\!\left(1-\frac1n\right)
-\phi\!\left(1+\frac1n\right)
\right]
=-2\sum_{n=2}^N\frac1n,
\tag{8.11}
\]

which diverges.

So even weak distributional push-forward can fail.

Exactly as Theorem 3.1 predicts, the bad target is

\[
\Phi(K_0)=\{\Phi(0)\}=\{1\}.
\tag{8.12}
\]

For every fixed `c != 1`, the tail threshold contribution is eventually
identically zero.

## Quantitative roughness of the example

Across a source interval of width

\[
\ell_n=2^{-4n-4},
\tag{8.13}
\]

the third-phase map changes by

\[
|\Phi(a_n)-\Phi(b_n)|=\frac2n.
\tag{8.14}
\]

Thus its modulus decays only logarithmically in the horizontal scale.  The
counterexample sits exactly in the deteriorating-modulus branch isolated by
v161; it does not contradict the approximate-channel result there.

---

# 9. What v162 does and does not close

The proposed v161 statement

\[
\text{finite persistence current}
\longrightarrow
\text{uniform degree convergence as }\varepsilon\to0
\tag{9.1}
\]

is false in C0.

The correct replacement is

\[
\boxed{
\text{finite persistence degree stabilizes locally uniformly on}
\quad
\mathbb R\setminus\Sigma_s.
}
\tag{9.2}
\]

Hence any square-free infinite-current escape must force the nonzero degree of
finer and finer finite truncations to concentrate onto the critical image.

Schematically,

\[
\boxed{
\text{infinite current}
\Longrightarrow
\text{finite truncations}
\Longrightarrow
\begin{cases}
\text{degree survives off }\Sigma &\Rightarrow\text{square},\\
\text{degree concentrates on }\Sigma &\Rightarrow\text{singular sumset branch}.
\end{cases}
}
\tag{9.3}
\]

The remaining object is therefore not arbitrary infinite perimeter, but
**critical-image saturation**.

---

# 10. Relation to v160-v161 singular mechanisms

## 10.1 Nowhere-local-injective intervals

If the small-persistence core `K_y` contains an interval, Proposition 2.1
forces `f` to be constant on that interval.  The plateau mechanism is already
handled by v157.  Therefore a surviving core is interval-free.

## 10.2 Deteriorating modulus

The explicit counterexample shows why rough modulus cannot simply be removed
from v161's obstruction ledger.  Vanishing horizontal persistence can be
converted into persistent third-phase threshold changes if `f` oscillates too
strongly on the translated contact set.

## 10.3 Infinite endpoint current

This branch is now split cleanly:

* off `Sigma_s`, infinite perimeter is harmless for endpoint degree;
* on `Sigma_s`, infinitely many vanishing excursions can remain visible.

The latter is the only genuinely new persistence obstruction.

---

# 11. Useful conditional closures

The exact theorem gives several immediate closure criteria.

### 11.1 Empty persistence core

If

\[
K_\alpha=K_\beta=\varnothing,
\tag{11.1}
\]

then `Sigma_s` is empty and the endpoint degree is globally finite after some
persistence scale.

### 11.2 Target interval separated from the critical image

If a protected third-phase target interval `Q` satisfies

\[
\operatorname{dist}(Q,\Sigma_{a,b})>0,
\tag{11.2}
\]

then one persistence threshold works uniformly for all `c in Q`, and the
relative-degree computation is exactly finite on the entire interval.

### 11.3 Fixed off-critical target

If a fixed target

\[
c\notin\Sigma_{a,b}
\tag{11.3}
\]

has nonzero relative degree for arbitrarily fine truncations, eventual
stabilization forces that same nonzero integer for the full map.

These statements require no quantitative modulus assumption.

---

# 12. Recommended v163 target

The next question is no longer whether persistence truncation converges.
It does, exactly, away from the critical image.

The correct target is:

\[
\boxed{
\text{Can }\Sigma_s(\alpha,\beta)
\text{ contain every protected third-phase target interval?}
}
\tag{12.1}
\]

Using (7.3), this is an additive problem for level-set cores:

\[
K_\alpha+L_\beta,
\qquad
L_\alpha+K_\beta.
\tag{12.2}
\]

Three routes look plausible.

### Route A — additive thinness

Show that the vanishing-persistence cores arising from a balanced first-failure
profile have sufficiently small thickness/dimension that the sumsets in
(12.2) cannot contain intervals.

A useful conditional benchmark: if `f` is locally Lipschitz and

\[
\dim_H K_\alpha+\dim_H L_\beta<1,
\qquad
\dim_H L_\alpha+\dim_H K_\beta<1,
\tag{12.3}
\]

then the critical image has Hausdorff dimension `<1` and hence empty interior.
This is not presently available in the C0 branch, but it identifies the
correct quantitative invariant.

### Route B — parameterized Baire argument

The sets `K_alpha` move with the side phase parameters.  Persistent saturation
of a two-parameter family of target intervals by the critical images may force
an actual interval in a level core, which would return to the plateau theorem.
This is the closest analogue of v160's finite critical-locking Baire argument.

### Route C — critical-image recurrence

If a target remains inside `Sigma_s` at all persistence scales, choose witness
pairs

\[
u_n\in K_\alpha,
\qquad
v_n\in L_\beta
\tag{12.4}
\]

(or the symmetric alternative).  Their tiny excursion components may define a
new nested return arch.  A successful recurrence/descent theorem would turn
critical-image saturation into a smaller-scale copy of the v155 critical
packet and potentially contradict bounded visible depth.

Route B presently looks strongest because it uses the target-parameter freedom
already present in the degree box rather than imposing fractal regularity not
known for a Jordan curve.

---

# 13. Computational audit

`code/verify_v162.py` checks twelve items:

1. disjointness and summability of the explicit vanishing-persistence arches;
2. the balanced bound `|f-t|<=2` for finite PL approximants;
3. the prescribed level-zero excursion components;
4. exact translation-map endpoint values `1 +/- 1/n`;
5. geometric decay of the source flat tail;
6. divergence of threshold degree at the critical target;
7. harmonic divergence against the smooth test `phi(z)=z`;
8. exact threshold stabilization at every tested `c != 1`;
9. identification `K={0}`, `Phi(K)={1}`;
10. the one-current persistence-stabilization mechanism;
11. the pair-current binary edge-straddling principle;
12. explicit deterioration of the third-phase modulus on the tiny arches.

All twelve checks pass.

---

# 14. Bottom line

v162 gives both a negative and a positive answer to the v161 persistence
proposal.

The negative answer is sharp:

\[
\boxed{
\text{flat-small source folds can remain order-one visible after a C0
nonlinear third-phase map.}
}
\tag{14.1}
\]

So a global flat-norm truncation theorem is impossible without extra
regularity.

The positive answer is more useful for the proof program:

\[
\boxed{
\text{away from the vanishing-persistence critical image, the threshold
endpoint degree stabilizes exactly at finite persistence.}
}
\tag{14.2}
\]

For the square map, that critical image is the additive set

\[
\boxed{
\Sigma_s
=f(K_\alpha+L_\beta-s)-\alpha
\ \cup\ 
 f(L_\alpha+K_\beta-s)-\alpha.
}
\tag{14.3}
\]

Thus the compact infinite-folding obstruction has been reduced from an
analytic nonlinear-pushforward problem to a concrete additive/fractal
saturation problem.

That is the v163 frontier.
