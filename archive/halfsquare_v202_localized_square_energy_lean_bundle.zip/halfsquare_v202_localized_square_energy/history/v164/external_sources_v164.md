# External sources checked for v164

1. Xiangfei Li and Yichen Pan, **Rectangular Pegs on Jordan Curves of Finite
   p-Variation**, arXiv:2609.04918v1, 4 September 2026.
   https://arxiv.org/abs/2609.04918

   Used only as an external regularity boundary: finite p-variation for some
   1 <= p < 2 implies an inscribed rectangle of every prescribed similarity
   class, hence a square.

2. **Banach indicatrix**, Encyclopedia of Mathematics.
   https://encyclopediaofmath.org/wiki/Banach_indicatrix

   Used for the classical identity Var(F)=integral N(y,F) dy for continuous
   real functions on an interval.
