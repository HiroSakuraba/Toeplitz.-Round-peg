# Project Handoff v163: Parameterized Critical-Image Entropy and the 2/3 Roughness Barrier

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v162 reduced the genuinely infinite endpoint-current branch to **critical-image
saturation**.  For a continuous balanced critical profile

\[
f(t)=t+h(t),\qquad |h(t)|\le 2,
\tag{0.1}
\]

the persistence-truncated endpoint degree stabilizes exactly away from the
vanishing-persistence critical image

\[
\Sigma_s(\alpha,\beta)
=
\bigl[f(K_\alpha+L_\beta-s)-\alpha\bigr]
\cup
\bigl[f(L_\alpha+K_\beta-s)-\alpha\bigr].
\tag{0.2}
\]

Here `K_y` is the vanishing-persistence core of the level-`y` excursion slice
and `L_y` is the full oriented level-support set.

v163 exploits the fact that the side phase targets `(alpha,beta)` are not
fixed: they vary through an open two-parameter chamber.  If the singular sets
(0.2) swallow an open family of third-phase targets as well, then a special
map from **two source variables into three target variables** must have
positive three-dimensional image measure.  A direct covering argument gives a
quantitative obstruction.

The main theorem is:

> **Parameterized critical-image entropy theorem.**  If critical-image
> saturation contains a nonempty open three-dimensional target box, then on
> the relevant compact contact region the modulus of continuity of `f` obeys
> \[
> \boxed{\omega_f(r)\ge c\,r^{2/3}}
> \tag{0.3}
> \]
> for all sufficiently small `r`, unless the global persistence-core carrier
> has correspondingly large covering entropy.  More precisely, if
> `N_K(r)` is the covering number of the two possible persistence-core
> carriers, then
> \[
> \boxed{
> N_K(r)\,\frac{\omega_f(2r)^3}{r}\ge c_0>0.
> }
> \tag{0.4}
> \]

Consequently:

\[
\boxed{
 f\text{ locally Holder of exponent }\gamma>2/3
 \quad\Longrightarrow\quad
 \text{critical-image saturation is impossible.}
}
\tag{0.5}
\]

More generally, if the relevant persistence core has upper box dimension `d`,
then a locally `gamma`-Holder profile cannot saturate an open target chamber
whenever

\[
\boxed{3\gamma>d+1.}
\tag{0.6}
\]

Conversely, saturation under a `gamma`-Holder bound forces the core carrier to
have lower box dimension at least

\[
\boxed{\underline{\dim}_{B}K\ge 3\gamma-1.}
\tag{0.7}
\]

Thus v162's additive/fractal obstruction has acquired a quantitative price:
**thin cores and regular phase profiles cannot jointly hide the degree.**

A new external result also changes the global regularity boundary.  Li and Pan
(arXiv:2609.04918, 4 September 2026) prove that every planar Jordan curve of
finite `p`-variation for some `1 <= p < 2` inscribes every prescribed rectangle,
and hence a square.  In particular, every Jordan curve admitting an
`alpha`-Holder parametrization with `alpha>1/2` is already covered.  This is an
external theorem, not part of the v163 proof, but it shows that any genuine
counterexample must lie beyond all finite-`p` variation classes with `p<2`.

---

# 1. Globalizing the v162 critical image

Fix one return arch `[a,b]`, one face parameter `s in {a,b}` (or any fixed
`s` in the return cylinder), and compact side contact intervals

\[
J_-\subset(-\infty,a),\qquad J_+\subset(b,\infty).
\tag{1.1}
\]

Let `A,B` be compact phase intervals contained in the robust side-target
chamber.  Define the accumulated persistence-core carriers

\[
\mathcal K_-
=
\overline{\bigcup_{\alpha\in A}(K_\alpha\cap J_-)},
\qquad
\mathcal K_+
=
\overline{\bigcup_{\beta\in B}(K_\beta\cap J_+)}.
\tag{1.2}
\]

By v162,

\[
K_y\subset f^{-1}(y).
\tag{1.3}
\]

By v160, the set

\[
K(f)=\{x:f\text{ is not locally one-to-one at }x\}
\tag{1.4}
\]

is closed.  Every `K_y` is contained in `K(f)`, hence

\[
\mathcal K_-,\mathcal K_+\subset K(f).
\tag{1.5}
\]

Therefore, in the branch where v160 has already excluded critical-set
interior, these global carriers are compact nowhere-dense subsets of the line.
They can nevertheless have full box dimension one.

Define the three-coordinate endpoint map

\[
\boxed{
\Psi_s(u,v)
=
\left(
 f(u),
 f(v),
 f(u+v-s)-f(u)
\right).
}
\tag{1.6}
\]

The union over all side phases of the actual v162 critical images is contained
in

\[
\boxed{
\mathfrak S_s
=
\Psi_s(\mathcal K_-\times J_+)
\cup
\Psi_s(J_-\times\mathcal K_+).
}
\tag{1.7}
\]

This is an **enlargement** of the true singular set: the opposite contact is
allowed to range through the whole side interval rather than only through its
level-support set.  That only makes the obstruction harder to rule out.
Consequently, if the true critical images saturate an open target chamber,
then so does `mathfrak S_s`.

The advantage of (1.7) is that it is now a fixed compact image of two planar
carrier sets.

In the v159 adjacent-phase coordinates the actual target variables are
`(r_1,r_2,c)`.  On a fixed return-arch face, `f(s)=z`, and

\[
\alpha=z-r_1,\qquad \beta=z+r_2.
\tag{1.8}
\]

Thus `(r_1,r_2,c) -> (alpha,beta,c)` is an affine isomorphism with Jacobian
magnitude one.  An open protected phase cell in the original target
coordinates is therefore an open three-dimensional set of exactly the kind
measured below.

---

# 2. Cellwise image-diameter estimate

Let `J_*` be a compact interval containing

\[
J_-\cup J_+\cup(J_-+J_+-s)
\tag{2.1}
\]

with a small fixed buffer.  Define the local modulus

\[
\omega(r)
=
\sup\{|f(x)-f(y)|:x,y\in J_*,\ |x-y|\le r\}.
\tag{2.2}
\]

Cover a subset of `J_- x J_+` by axis-parallel cells of side at most `r`.
For two points `(u,v),(u',v')` in one cell,

\[
|f(u)-f(u')|\le\omega(r),
\tag{2.3}
\]

\[
|f(v)-f(v')|\le\omega(r),
\tag{2.4}
\]

and

\[
\begin{aligned}
&|[f(u+v-s)-f(u)]-[f(u'+v'-s)-f(u')]|\\
&\qquad\le
\omega(|u-u'|+|v-v'|)+\omega(|u-u'|)\\
&\qquad\le
\omega(2r)+\omega(r)
\le 2\omega(2r).
\end{aligned}
\tag{2.5}
\]

Hence the image of every source cell under `Psi_s` is contained in a
three-dimensional rectangle of volume at most

\[
\boxed{2\,\omega(2r)^3.}
\tag{2.6}
\]

This elementary estimate is the engine of v163.

---

# 3. Covering theorem for the parameterized critical image

Let `N(E,r)` denote the least number of intervals of length `r` needed to
cover a compact set `E subset R`.  Let

\[
N_-(r)=N(\mathcal K_-,r),
\qquad
N_+(r)=N(\mathcal K_+,r).
\tag{3.1}
\]

An interval of length `L` can be covered by at most

\[
1+\lceil L/r\rceil
\tag{3.2}
\]

intervals of length `r`.  Applying (2.6) to the two pieces of (1.7) gives:

## Theorem 3.1 — critical-image covering bound

For every sufficiently small `r>0`,

\[
\boxed{
\begin{aligned}
\mathcal L^{3,*}(\mathfrak S_s)
\le {}&
2\omega(2r)^3
\Bigl[
 N_-(r)\bigl(1+\lceil |J_+|/r\rceil\bigr)\\
&\qquad\qquad+
 N_+(r)\bigl(1+\lceil |J_-|/r\rceil\bigr)
\Bigr].
\end{aligned}
}
\tag{3.3}
\]

Here `L^{3,*}` denotes three-dimensional Lebesgue outer measure.

### Proof

Cover `mathcal K_-` by `N_-(r)` intervals of length `r` and `J_+` by
`1+ceil(|J_+|/r)` such intervals.  Their products give a source-cell cover of
the first set in (1.7).  Every image cell has volume at most (2.6), so the sum
of the containing target-box volumes gives the first term in (3.3).  The
second orientation is identical.  QED.

The theorem uses no differentiability, bounded variation, monotonicity, or
finite-perimeter hypothesis.

---

# 4. The covering-pressure obstruction

For `0<r<=1`, put

\[
C_J=2+\max(|J_-|,|J_+|).
\tag{4.1}
\]

Then

\[
1+\lceil |J_\pm|/r\rceil\le C_J/r.
\tag{4.2}
\]

Therefore (3.3) implies

\[
\boxed{
\mathcal L^{3,*}(\mathfrak S_s)
\le
2C_J\,
\frac{[N_-(r)+N_+(r)]\omega(2r)^3}{r}.
}
\tag{4.3}
\]

Define the scale-dependent quantity

\[
\boxed{
\mathcal P(r)
=
\frac{[N_-(r)+N_+(r)]\omega(2r)^3}{r}.
}
\tag{4.4}
\]

This is the natural **covering pressure** of the critical-image branch.

## Corollary 4.1 — vanishing pressure closes the singular image

If

\[
\liminf_{r\downarrow0}\mathcal P(r)=0,
\tag{4.5}
\]

then

\[
\boxed{\mathcal L^3(\mathfrak S_s)=0.}
\tag{4.6}
\]

In particular `mathfrak S_s` cannot contain a nonempty open target set.

## Corollary 4.2 — saturation forces positive pressure

If `mathfrak S_s` contains a target box `Q` of volume `V>0`, then for every
sufficiently small `r`,

\[
\boxed{
N_-(r)+N_+(r)
\ge
\frac{V}{2C_J}
\frac{r}{\omega(2r)^3}.
}
\tag{4.7}
\]

Thus persistent critical-image saturation cannot be carried by both a thin
persistence core and a tame modulus of continuity.

---

# 5. Universal 2/3 roughness barrier

Because `mathcal K_- subset J_-` and `mathcal K_+ subset J_+`, there is a
constant `C_K` depending only on the fixed side-window lengths such that

\[
N_-(r)+N_+(r)\le \frac{C_K}{r}
\tag{5.1}
\]

for all small `r`.

Insert (5.1) into (4.3):

\[
\mathcal L^{3,*}(\mathfrak S_s)
\le
2C_JC_K\,
\frac{\omega(2r)^3}{r^2}.
\tag{5.2}
\]

Hence:

## Theorem 5.1 — the 2/3 modulus barrier

If `mathfrak S_s` contains an open target box of volume `V>0`, then

\[
\boxed{
\omega(2r)
\ge
\left(\frac{V}{2C_JC_K}\right)^{1/3}r^{2/3}
}
\tag{5.3}
\]

for every sufficiently small `r`.

Equivalently, after changing constants,

\[
\boxed{\omega(\rho)\ge c\rho^{2/3}}
\tag{5.4}
\]

at all sufficiently small scales.

This is a necessary condition for a parameterized critical-image escape.

### Holder consequence

Suppose on `J_*`

\[
\omega(r)\le H r^\gamma.
\tag{5.5}
\]

Then (5.2) becomes

\[
\mathcal L^{3,*}(\mathfrak S_s)
\le C H^3 r^{3\gamma-2}.
\tag{5.6}
\]

If

\[
\gamma>\frac23,
\tag{5.7}
\]

the right side tends to zero.  Therefore:

\[
\boxed{
\gamma>2/3
\quad\Longrightarrow\quad
\mathfrak S_s\text{ has zero 3D measure and no interior.}
}
\tag{5.8}
\]

So the v162 singular concentration mechanism is impossible for every locally
Holder critical profile of exponent strictly larger than `2/3`.

This is an internal statement about the **critical phase profile**, not the
original Jordan parametrization.

---

# 6. Dimension/entropy tradeoff for the persistence core

The universal estimate (5.1) ignores the fact that the persistence core may
be much thinner than an interval.

Assume, for some `d in [0,1]`,

\[
N_-(r)+N_+(r)\le C_\varepsilon r^{-d-\varepsilon}
\tag{6.1}
\]

for every `epsilon>0` and all sufficiently small `r`; equivalently the union
of the two core carriers has upper box dimension at most `d`.

Under the Holder estimate (5.5), (4.3) gives

\[
\mathcal L^{3,*}(\mathfrak S_s)
\le
C r^{3\gamma-d-1-\varepsilon}.
\tag{6.2}
\]

Thus:

## Corollary 6.1 — core-dimension closure criterion

If

\[
\boxed{3\gamma>d+1,}
\tag{6.3}
\]

then the parameterized critical image has zero three-dimensional measure and
cannot swallow an open protected target chamber.

Conversely, if saturation occurs and `f` is `gamma`-Holder, (4.7) implies

\[
N_-(r)+N_+(r)\ge c r^{-(3\gamma-1)}.
\tag{6.4}
\]

Hence

\[
\boxed{
\underline{\dim}_{B}(\mathcal K_-\cup\mathcal K_+)
\ge 3\gamma-1.
}
\tag{6.5}
\]

At the borderline `gamma=2/3`, a survivor needs a persistence-core carrier of
full lower box dimension one.  Since v160 already excludes an interval of
criticality in the regular finite-chamber branch, the remaining possibility is
therefore a **nowhere-dense but metrically full one-dimensional core**.

That is substantially more rigid than the v162 statement “a Cantor sumset may
contain an interval.”

---

# 7. Why ordinary Cantor-sum saturation is not enough

The middle-thirds Cantor set `C` has empty interior and

\[
C+C=[0,2].
\tag{7.1}
\]

So v162 correctly warned that a fixed scalar additive image can contain an
interval even when the persistence core is nowhere dense.

But its box dimension is

\[
d_C=\frac{\log2}{\log3}\approx0.63093.
\tag{7.2}
\]

If the phase profile is Lipschitz (`gamma=1`), then the exponent in (6.2) is

\[
3-d_C-1=2-d_C>0.
\tag{7.3}
\]

Thus a Cantor core can saturate one fixed **one-dimensional** sumset while
still being far too small to saturate an open **three-dimensional** family of
`(alpha,beta,c)` targets.

This explains precisely what the parameter freedom buys us.  Pure Baire
category was not enough; parameterized target volume plus quantitative
continuity is stronger.

---

# 8. Relation to the explicit v162 counterexample

The v162 counterexample has

\[
K_0=\{0\}
\tag{8.1}
\]

and one bad threshold

\[
\Phi(K_0)=\{1\}.
\tag{8.2}
\]

It does **not** saturate a three-dimensional target chamber.  Its translated
third-phase modulus is deliberately very rough:

\[
\ell_n=2^{-4n-4},
\qquad
|\Phi(a_n)-\Phi(b_n)|=\frac2n.
\tag{8.3}
\]

Thus the ratio between image oscillation and horizontal persistence decays far
more slowly than any fixed Holder law.  There is no conflict with Theorem 5.1.

Indeed this example is a useful model for what a surviving singular branch
must increasingly resemble: either the core entropy rises, or the phase map
becomes violently non-Holder, or both.

---

# 9. New external regularity boundary: finite p-variation, p<2

A new preprint appeared during this continuation:

**Xiangfei Li and Yichen Pan, “Rectangular Pegs on Jordan Curves of Finite
`p`-Variation,” arXiv:2609.04918v1, 4 September 2026.**

Their Theorem 1.1 states that a planar Jordan curve admitting a parametrization
of finite `p`-variation for some

\[
1\le p<2
\tag{9.1}
\]

inscribes a rectangle of every prescribed similarity class, hence a square.
They prove a variation-controlled smooth-Jordan approximation theorem and use
Young integration to verify the Asano-Ike primitive-convergence criterion.

Their Corollary 4.3 gives the convenient sufficient condition:

\[
\boxed{
\text{an }\alpha\text{-Holder Jordan parametrization with }\alpha>1/2
\Longrightarrow
\text{a square}.}
\tag{9.2}
\]

This is an **external theorem**, not a theorem of the present bundle.

For the global Toeplitz problem it means that any genuine counterexample must
have infinite `p`-variation for every `p<2`; equivalently, none of the newly
covered finite-variation regularity classes can host the terminal obstruction.

The external result and v163's internal `2/3` barrier concern different
objects:

* Li-Pan control the original planar Jordan parametrization;
* v163 controls the one-dimensional balanced **critical phase profile** created
  by the v155 blow-up.

They should not be conflated.  Strategically, however, both point in the same
direction: the only branch worth investing in is genuinely rough.

The Asano-Ike criterion is also conceptually relevant.  It shows that the
classical collapse problem can be defeated if smooth Jordan approximants
converge together with a primitive of the Liouville form.  If the present
program eventually stalls at a `C^0` phase-current singularity, importing a
primitive/area control into the blow-up may be more productive than adding
another branch enumeration.

---

# 10. What v163 closes conditionally

The v162 critical-image escape is closed under any of the following local
conditions on the critical phase profile/contact core:

1. **Holder exponent greater than `2/3`:**
   \[
   \omega(r)=O(r^\gamma),\quad\gamma>2/3.
   \tag{10.1}
   \]
2. **General vanishing pressure:**
   \[
   [N_-(r)+N_+(r)]\omega(2r)^3/r\to0
   \tag{10.2}
   \]
   along any sequence of scales.
3. **Thin core plus weaker Holder control:** if the core has upper box
   dimension `d` and
   \[
   3\gamma>d+1.
   \tag{10.3}
   \]

These are genuinely `C^0` covering statements.  No derivatives or variation
measure of `f` are used.

---

# 11. What remains open after v163

v163 does **not** rule out a profile satisfying both:

* a nowhere-dense persistence core with near-full metric entropy; and
* a modulus as rough as, or rougher than, `r^(2/3)` on every relevant scale.

Nor does it prove that an arbitrary critical profile inherits any Holder
exponent from the original Jordan curve.

The surviving compact obstruction can now be stated quantitatively:

\[
\boxed{
\text{critical-image saturation}
\Longrightarrow
\text{positive covering pressure at every small scale}.}
\tag{11.1}
\]

Together with v160-v162, a square-free compact profile must exhibit at least
one of the following severe behaviors:

* an interval on which local injectivity fails;
* recurrent/syndetic return defects with positive variation density;
* vanishing-persistence cores of high covering entropy;
* a phase modulus no better than the `2/3` Peano threshold;
* or some mixture of the last two keeping (4.4) bounded away from zero.

The phrase “Peano threshold” is descriptive only: the proof is the elementary
covering estimate (3.3), not an appeal to a space-filling-curve theorem.

---

# 12. Recommended v164 target

The next step should use the new pressure quantity rather than return to raw
additive sumsets.

## Route A — pressure descent under a core witness

Suppose

\[
\mathcal P(r)\ge c_0>0
\tag{12.1}
\]

at all small scales.  Pick an `r`-cell of the core carrier whose image accounts
for a definite fraction of target volume.  Rescale that cell horizontally by
`r` and vertically by `omega(r)`.  The covering proof implies that the child
profile cannot become trivial: it inherits a definite amount of target-volume
complexity.

The desired theorem is a renormalization alternative:

\[
\boxed{
\text{positive pressure at all scales}
\Longrightarrow
\text{a nontrivial child critical profile with controlled pressure}.}
\tag{12.2}
\]

If the normalization exponent settles above `2/3`, v163 closes it.  If it
settles at or below `2/3`, one obtains an honest rough self-similar obstruction
rather than an unstructured `C^0` pathology.

## Route B — connect pressure to planar p-variation

The fresh Li-Pan theorem suggests trying to relate the critical-profile
pressure to a `p<2` variation quantity of the original Jordan arc.  A theorem
of the schematic form

\[
\text{finite planar }p\text{-variation}
\Longrightarrow
\mathcal P(r_j)\to0
\tag{12.3}
\]

on some blow-up scales would immediately dovetail with an existing square-peg
theorem.  This is not presently established; the phase profile and planar
curve variation live in different coordinates.

## Route C — area/primitive import

Asano-Ike/Li-Pan show that uniform approximation becomes strong enough when an
area primitive also converges.  Search for an analogue of the Liouville
primitive in the half-square phase map.  A conserved primitive could suppress
exactly the high-entropy/high-roughness concentration that remains here.

Route A is the cleanest continuation inside the existing program.  Route C is
the most promising conceptual import from the new literature.

---

# 13. Computational audit

`code/verify_v163.py` checks the following structural statements:

1. the cellwise third-coordinate oscillation bound (2.5) on randomized
   piecewise-linear balanced profiles;
2. the complete image-box volume bound (2.6);
3. the algebra of the global covering inequality (3.3);
4. the `2/3` exponent obtained from the worst-case one-dimensional core cover;
5. decay of the critical-image volume bound for every tested Holder exponent
   `gamma>2/3`;
6. nondecay/possible growth at exponents `gamma<=2/3`;
7. the dimension tradeoff `3 gamma > d+1`;
8. the lower entropy exponent `3 gamma - 1` forced by saturation;
9. finite-stage middle-thirds Cantor sums cover `[0,2]`, demonstrating why
   fixed-pair additive thinness is false;
10. despite item 9, the parameterized volume exponent for a Lipschitz map and
    Cantor core is positive (`2-d_C`), so v163 rules out 3D saturation there;
11. the v162 rough counterexample violates every tested positive Holder
    exponent asymptotically at its excursion scales;
12. the Li-Pan threshold arithmetic: `alpha>1/2` implies
    `p=1/alpha<2`.

The numerical checks are theorem audits, not substitutes for the proofs above.

---

# 14. Bottom line

v162 left a qualitative additive/fractal obstruction.  v163 turns it into a
quantitative metric one.

The core estimate is

\[
\boxed{
\mathcal L^{3,*}(\mathfrak S_s)
\lesssim
\frac{N_K(r)\,\omega_f(r)^3}{r}.
}
\tag{14.1}
\]

Therefore a singular critical image can swallow an open three-dimensional
phase chamber only by paying for it with core entropy, phase roughness, or
both.

In particular,

\[
\boxed{
\text{Holder exponent }>2/3
\Longrightarrow
\text{no critical-image saturation}.}
\tag{14.2}
\]

And if the exponent is exactly `2/3`, the persistence-core carrier must already
have full one-dimensional lower box dimension.

The remaining branch is no longer merely “Cantor-like.”  It must be a
near-space-filling interaction between a metrically thick critical core and a
rough phase map at every small scale.

That is the correct object for the next renormalization step.
