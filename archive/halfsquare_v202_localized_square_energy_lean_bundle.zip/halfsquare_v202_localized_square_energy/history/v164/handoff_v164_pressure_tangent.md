# Project Handoff v164: Pressure Renormalization and Positive-Volume Three-Patch Tangents

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v163 showed that if the vanishing-persistence critical image swallows an open
three-dimensional phase chamber, then the covering pressure

\[
\mathcal P(r)
=
\frac{N_K(r)\,\omega_f(2r)^3}{r}
\tag{0.1}
\]

cannot tend to zero.  Here `K` denotes one of the accumulated persistence-core
carriers after choosing one critical-image orientation, `N_K(r)` is its interval
covering number, and `omega_f` is the local modulus of continuity on the compact
contact region.

v164 turns that scalar inequality into an actual renormalization theorem.
There are now two sharply different ways critical-image saturation can persist:

1. **bounded-pressure regime:** a subsequence of witness cells converges, after
   canonical rescaling, to a continuous special map
   \[
   \boxed{
   T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr)
   }
   \tag{0.2}
   \]
   whose image has positive three-dimensional Lebesgue measure;
2. **pressure-spike regime:** along arbitrarily small scales,
   \[
   \boxed{
   \frac{\omega_f(2r)}{r^{2/3}}\to\infty,
   }
   \tag{0.3}
   \]
   quantitatively realizing a genuinely super-Peano roughness spike.

The first alternative is considerably more rigid than an arbitrary Peano
surface.  It is built from **three one-dimensional blow-up patches of the same
phase profile**, sampled near the three locations `u`, `v`, and `u+v-s` that
appear in the endpoint map.

Moreover, positive volume of (0.2) forces severe level-set multiplicity.  By
Fubini and Banach's indicatrix theorem, `F` and `G` cannot both have bounded
variation.  Thus even the bounded-pressure branch contains an infinite-variation
tangent.

The surviving object is no longer an unstructured `C^0` pathology.  It is
now either a positive-volume **sum-coupled three-patch tangent** or an explicit
sequence of super-`2/3` pressure spikes.

---

# 1. One-orientation localization

Retain the v163 notation.  For a fixed return-arch face parameter `s`, the
parameterized critical image is contained in the union

\[
\mathfrak S_s
=
\Psi_s(\mathcal K_-\times J_+)
\cup
\Psi_s(J_-\times\mathcal K_+),
\tag{1.1}
\]

where

\[
\Psi_s(u,v)
=
\bigl(f(u),f(v),f(u+v-s)-f(u)\bigr).
\tag{1.2}
\]

Assume an open target box is swallowed by the singular image.  Since the two
sets in (1.1) are compact, the Baire theorem gives a smaller closed target box

\[
Q\subset\mathbb R^3,
\qquad
\mathcal L^3(Q)=V>0,
\tag{1.3}
\]

contained entirely in one orientation.  Relabel that orientation as

\[
\boxed{Q\subset \Psi_s(K\times J),}
\tag{1.4}
\]

where `K` is one accumulated persistence-core carrier and `J` is the opposite
compact side interval.

This reduction is important: from now on there is only one covering number.
Define

\[
N(r)=N(K,r)
\tag{1.5}
\]

and

\[
\boxed{
P(r)=\frac{N(r)\omega(2r)^3}{r}.
}
\tag{1.6}
\]

Here `omega` is the local modulus of `f` on a fixed compact interval containing
`K`, `J`, and `K+J-s` with a small buffer.

---

# 2. Saturation gives a two-sided pressure lower bound

Let `L=|J|`.  Cover `K` by `N(r)` intervals of length `r`, and `J` by at most

\[
m(r)\le 1+\left\lceil\frac{L}{r}\right\rceil
\le \frac{C_J}{r}
\tag{2.1}
\]

intervals of length `r`, for a fixed constant `C_J` and all sufficiently small
`r`.

For one source cell `I x J_0` of side at most `r`, v163's oscillation estimate
gives

\[
|\Delta f(u)|\le\omega(r),
\qquad
|\Delta f(v)|\le\omega(r),
\tag{2.2}
\]

and

\[
|\Delta[f(u+v-s)-f(u)]|
\le 2\omega(2r).
\tag{2.3}
\]

Thus every cell image lies in a rectangular target box of volume at most

\[
2\omega(2r)^3.
\tag{2.4}
\]

Since the cell images cover `Q`,

\[
V
\le
2N(r)m(r)\omega(2r)^3
\le
2C_J\frac{N(r)\omega(2r)^3}{r}.
\tag{2.5}
\]

Therefore:

## Theorem 2.1 — pressure floor

For every sufficiently small `r`,

\[
\boxed{
P(r)\ge p_0:=\frac{V}{2C_J}>0.
}
\tag{2.6}
\]

This is the one-orientation form of v163's positive-pressure obstruction.

---

# 3. A single source cell carries definite normalized target volume

The previous argument can be localized instead of only summed.

For the `N(r)m(r)` source cells let `S_{ij}` be their images.  Since

\[
Q\subset\bigcup_{i,j}S_{ij},
\tag{3.1}
\]

subadditivity gives

\[
V
\le
\sum_{i,j}\mathcal L^3(Q\cap S_{ij}).
\tag{3.2}
\]

Hence at least one cell satisfies

\[
\mathcal L^3(Q\cap S_{ij})
\ge
\frac{V}{N(r)m(r)}.
\tag{3.3}
\]

Put

\[
\lambda_r=\omega(2r).
\tag{3.4}
\]

After translating the target by one corner value and scaling all three target
coordinates by `lambda_r`, the witness cell contains a target subset of volume
at least

\[
\frac{V}{N(r)m(r)\lambda_r^3}.
\tag{3.5}
\]

Using `m(r)<=C_J/r` and (1.6):

## Theorem 3.1 — witness-cell lower bound

If

\[
P(r)\le P_*,
\tag{3.6}
\]

then some `r x r` source cell has normalized image volume at least

\[
\boxed{
\kappa
=
\frac{V}{C_JP_*}>0.
}
\tag{3.7}
\]

Thus bounded pressure does not allow the target volume to diffuse completely
among more and more microscopic cells.  One microscopic source cell always
retains a fixed amount of normalized three-dimensional image volume.

---

# 4. Exact three-patch rescaling

Take a witness cell

\[
I=[u_0,u_0+r],
\qquad
J_0=[v_0,v_0+r].
\tag{4.1}
\]

Set

\[
w_0=u_0+v_0-s,
\qquad
\lambda=\omega(2r).
\tag{4.2}
\]

Define the three normalized one-dimensional patches

\[
F_r(x)
=
\frac{f(u_0+rx)-f(u_0)}{\lambda},
\qquad 0\le x\le1,
\tag{4.3}
\]

\[
G_r(y)
=
\frac{f(v_0+ry)-f(v_0)}{\lambda},
\qquad 0\le y\le1,
\tag{4.4}
\]

and

\[
H_r(t)
=
\frac{f(w_0+rt)-f(w_0)}{\lambda},
\qquad 0\le t\le2.
\tag{4.5}
\]

Then, after subtracting the target value at `(u_0,v_0)` and dividing by
`lambda`, the endpoint map is **exactly**

\[
\boxed{
T_r(x,y)
=
\bigl(
F_r(x),
G_r(y),
H_r(x+y)-F_r(x)
\bigr).
}
\tag{4.6}
\]

There is no Taylor expansion here.

By the definition of `lambda`,

\[
\|F_r\|_\infty\le1,
\qquad
\|G_r\|_\infty\le1,
\qquad
\|H_r\|_\infty\le1.
\tag{4.7}
\]

The third coordinate of `T_r` therefore lies in `[-2,2]`.

This is the correct renormalized object.  A single child profile is not enough,
because the endpoint map samples the parent profile at three linked spatial
locations.

---

# 5. Bounded pressure automatically gives compactness

The main new estimate is that no extra Holder assumption is needed in the
bounded-pressure branch.

Assume that for all sufficiently small scales

\[
p_0\le P(r)\le P_*<\infty.
\tag{5.1}
\]

Let `0<rho<=r`.  Since covering numbers are monotone,

\[
N(\rho)\ge N(r).
\tag{5.2}
\]

From the pressure upper bound,

\[
\omega(2\rho)^3
=
\frac{P(\rho)\rho}{N(\rho)}
\le
\frac{P_*\rho}{N(r)}.
\tag{5.3}
\]

From the pressure floor at scale `r`,

\[
\omega(2r)^3
\ge
\frac{p_0r}{N(r)}.
\tag{5.4}
\]

Divide (5.3) by (5.4):

## Theorem 5.1 — pressure-to-modulus compactness

Whenever `0<rho<=r` are sufficiently small,

\[
\boxed{
\frac{\omega(2\rho)}{\omega(2r)}
\le
\left(\frac{P_*}{p_0}\right)^{1/3}
\left(\frac{\rho}{r}\right)^{1/3}.
}
\tag{5.5}
\]

Consequently the normalized patch families in (4.3)-(4.5) are uniformly
`1/3`-Holder.  For example, with `delta=|x-x'|` and
`rho=r delta/2`,

\[
|F_r(x)-F_r(x')|
\le
C\delta^{1/3},
\tag{5.6}
\]

with the same constant for every sufficiently small witness scale.  The same
holds for `G_r` and `H_r`.

Therefore Arzela-Ascoli applies automatically.

This is a substantial sharpening of the proposed v164 route.  The only way to
lose child compactness is for the pressure itself to develop arbitrarily large
subscale spikes.

---

# 6. Positive-volume three-patch tangent theorem

Assume the bounded-pressure regime (5.1), and choose witness cells at scales

\[
r_n\downarrow0.
\tag{6.1}
\]

By Theorem 3.1,

\[
\mathcal L^3(T_{r_n}([0,1]^2))\ge\kappa>0.
\tag{6.2}
\]

By Theorem 5.1 and Arzela-Ascoli, after passing to a subsequence,

\[
F_{r_n}\to F,
\qquad
G_{r_n}\to G,
\qquad
H_{r_n}\to H
\tag{6.3}
\]

uniformly on their compact domains.  Hence

\[
T_{r_n}\to
T(x,y)
=
\bigl(F(x),G(y),H(x+y)-F(x)\bigr)
\tag{6.4}
\]

uniformly on `[0,1]^2`.

Uniform convergence implies Hausdorff convergence of the compact images.  If
`E=T([0,1]^2)`, then for every `epsilon>0`, for all large `n`,

\[
T_{r_n}([0,1]^2)
\subset
N_\varepsilon(E).
\tag{6.5}
\]

Thus

\[
\kappa
\le
\mathcal L^3(N_\varepsilon(E)).
\tag{6.6}
\]

Letting `epsilon` decrease to zero and using continuity from above of Lebesgue
measure gives:

## Theorem 6.1 — positive-volume tangent

In the bounded-pressure saturation regime there exists a continuous tangent
triad `(F,G,H)` such that

\[
\boxed{
\mathcal L^3
\left(
\left\{
(F(x),G(y),H(x+y)-F(x)):
0\le x,y\le1
\right\}
\right)
\ge\kappa>0.
}
\tag{6.7}
\]

The functions `F,G,H` are uniformly `1/3`-Holder with constants determined
only by the pressure ceiling and the protected target box.

One can also retain a tangent of the core carrier.  If

\[
K_n=(K-u_{0,n})/r_n\cap[0,1],
\tag{6.8}
\]

then a further subsequence converges in Hausdorff distance to a compact set
`K_infty subset [0,1]`, and the positive-volume image can be localized to the
corresponding limiting source relation.  The full-square formulation (6.7) is
simpler and sufficient for the structural conclusions below.

---

# 7. The balanced identity disappears at the rough tangent scale

Recall the critical profile is globally balanced:

\[
f(t)=t+h(t),
\qquad |h(t)|\le2.
\tag{7.1}
\]

v163 saturation already gives

\[
\omega(2r)\ge c r^{2/3}.
\tag{7.2}
\]

Hence

\[
\frac{r}{\omega(2r)}
\le
C r^{1/3}
\longrightarrow0.
\tag{7.3}
\]

Therefore in each normalized patch the contribution of the background identity
`t` vanishes:

\[
\frac{r x}{\omega(2r)}\to0.
\tag{7.4}
\]

The tangent triad in Theorem 6.1 is therefore generated entirely by rough
oscillation of the bounded residual `h`, not by the global degree-one drift.

This explains why the v155 balanced normalization does not by itself rule out
the terminal tangent: after a second critical-image blow-up, the linear drift
is subcritical.

---

# 8. Exact fiber formula for the tangent image

Let

\[
E=T([0,1]^2).
\tag{8.1}
\]

For target values `(a,b)`, the vertical fiber of `E` is exactly

\[
\boxed{
E_{a,b}
=
H\bigl(F^{-1}(a)+G^{-1}(b)\bigr)-a.
}
\tag{8.2}
\]

Indeed, the first two target coordinates force

\[
F(x)=a,
\qquad
G(y)=b,
\tag{8.3}
\]

and the third coordinate is then `H(x+y)-a`.

Because `E` is compact, Fubini gives the exact identity

\[
\boxed{
\mathcal L^3(E)
=
\int_{\mathbb R^2}
\mathcal L^1
\left(
H(F^{-1}(a)+G^{-1}(b))-a
\right)
\,da\,db.
}
\tag{8.4}
\]

Thus positive-volume tangent saturation means that for a positive-measure set
of phase pairs `(a,b)`, the sum of the corresponding one-dimensional level
fibers is sent by `H` to a set of positive one-dimensional measure.

This is a much sharper terminal object than a generic space-filling surface.

---

# 9. Bounded variation cannot support the tangent

Banach's indicatrix theorem states that for a continuous real function `F`
on an interval,

\[
\operatorname{Var}(F)
=
\int_{\mathbb R}N_F(a)\,da,
\tag{9.1}
\]

where `N_F(a)` is the number of solutions of `F(x)=a`, with infinity allowed.
Consequently, if `F` has bounded variation, then `F^{-1}(a)` is finite for
almost every `a`.  The same holds for `G`.

If **both** `F` and `G` had bounded variation, then for almost every `(a,b)` the
sets `F^{-1}(a)` and `G^{-1}(b)` would both be finite.  Their sumset would be
finite, so the vertical fiber in (8.2) would have zero one-dimensional measure.
Equation (8.4) would then give

\[
\mathcal L^3(E)=0,
\tag{9.2}
\]

contradicting Theorem 6.1.

Therefore:

## Theorem 9.1 — infinite-variation tangent obstruction

Every bounded-pressure positive-volume tangent satisfies

\[
\boxed{
\operatorname{Var}(F)=\infty
\quad\text{or}\quad
\operatorname{Var}(G)=\infty.
}
\tag{9.3}
\]

So even the apparently better-behaved bounded-pressure branch necessarily
contains infinite one-dimensional variation in at least one side patch.

This is consistent with the recent Li-Pan finite-`p`-variation theorem for the
original Jordan curve, but it is a different statement: (9.3) concerns the
secondary critical phase tangent, not the original planar parametrization.

---

# 10. Pressure spikes force super-2/3 roughness

The other branch is equally explicit.

Since `K` lies in a fixed compact interval, for a constant `C_K`,

\[
N(r)\le\frac{C_K}{r}
\tag{10.1}
\]

for all small `r`.  Therefore

\[
P(r)
=
\frac{N(r)\omega(2r)^3}{r}
\le
C_K\frac{\omega(2r)^3}{r^2}.
\tag{10.2}
\]

Hence:

## Theorem 10.1 — pressure-spike roughness

If along some sequence `r_n downarrow 0`,

\[
P(r_n)\to\infty,
\tag{10.3}
\]

then

\[
\boxed{
\frac{\omega(2r_n)}{r_n^{2/3}}
\ge
\left(\frac{P(r_n)}{C_K}\right)^{1/3}
\longrightarrow\infty.
}
\tag{10.4}
\]

Thus failure of bounded-pressure compactness is not mysterious.  It is an
actual sequence of increasingly severe super-`2/3` modulus spikes.

Combining Theorems 6.1 and 10.1 gives the v164 renormalization dichotomy:

\[
\boxed{
\begin{array}{c}
\text{critical-image saturation}
\\[1mm]
\Downarrow
\\[1mm]
\text{positive-volume three-patch tangent}
\\
\text{or}
\\
\text{super-}2/3\text{ pressure spikes}.
\end{array}}
\tag{10.5}
\]

---

# 11. Local entropy improves the tangent exponent

The universal `1/3` exponent in Theorem 5.1 used only monotonicity of the
covering number.

Suppose instead that along the witness scales the core has a lower local
covering exponent `d`, in the sense that for `0<rho<=r`,

\[
N(\rho)
\ge
c_d\left(\frac r\rho\right)^d N(r).
\tag{11.1}
\]

Then the same pressure calculation gives

\[
\boxed{
\frac{\omega(2\rho)}{\omega(2r)}
\le
C
\left(\frac\rho r\right)^{(d+1)/3}.
}
\tag{11.2}
\]

Thus the child patches are uniformly Holder with exponent

\[
\boxed{\gamma_{\rm child}=\frac{d+1}{3}.}
\tag{11.3}
\]

For a metrically full one-dimensional core (`d=1`) this is exactly

\[
\gamma_{\rm child}=\frac23.
\tag{11.4}
\]

In a power-law self-similar bounded-pressure regime

\[
N(r)\asymp r^{-d},
\qquad
\omega(r)\asymp r^\gamma,
\tag{11.5}
\]

pressure balance is therefore precisely

\[
\boxed{3\gamma=d+1.}
\tag{11.6}
\]

This is the natural critical line for any self-similar terminal obstruction.
It interpolates from `(d,gamma)=(0,1/3)` to `(1,2/3)`.

---

# 12. Relation to the new finite-p-variation theorem

Li and Pan, *Rectangular Pegs on Jordan Curves of Finite p-Variation*,
arXiv:2609.04918v1 (4 September 2026), prove that every planar Jordan curve of
finite `p`-variation for some `1<=p<2` inscribes every prescribed rectangle
similarity class, hence a square.

Their theorem verifies that any genuine global counterexample must lie beyond
all finite-`p` variation classes with `p<2`.

v164 reaches a parallel conclusion internally at the tangent level:

* pressure spikes require super-`2/3` modulus behavior;
* bounded pressure produces a positive-volume tangent for which at least one
  side patch has infinite ordinary variation.

These are not equivalent statements and should not be conflated, but both say
that the remaining branch is intrinsically rough rather than a technical
failure of smooth approximation.

For the Banach indicatrix identity used in Section 9, see the Encyclopedia of
Mathematics entry **Banach indicatrix** or the classical Banach theorem
`Var(F)=int N_F(y)dy`.

---

# 13. What v164 rules out

The following escape scenario is no longer possible:

> positive critical-image pressure at every scale, with the normalized witness
> cells becoming trivial or losing all target-volume content merely because the
> scale tends to zero.

If pressure is bounded, target volume survives in one microscopic cell and
compactness is automatic.  If compactness fails, pressure must spike, and those
spikes quantitatively exceed the `2/3` Peano scale.

Thus the vague v163 proposal

\[
\text{positive pressure}
\Longrightarrow
\text{some nontrivial child}
\tag{13.1}
\]

has become the rigorous alternative (10.5).

---

# 14. What remains open after v164

v164 does **not** rule out either terminal branch.

## Branch A — positive-volume sum-coupled tangent

A continuous map

\[
T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr)
\tag{14.1}
\]

with positive three-dimensional image measure is not obviously impossible at
low regularity.  The exact fiber formula (8.4) shows what it requires:
for positive-measure many `(a,b)`, the set

\[
H(F^{-1}(a)+G^{-1}(b))
\tag{14.2}
\]

must itself have positive length.

The next classification problem is therefore a **level-fiber sumset problem**,
not a general Peano-surface problem.

## Branch B — pressure spikes

If `P(r)` is unbounded, one obtains scales with

\[
\omega(r)\gg r^{2/3}.
\tag{14.3}
\]

One still needs to show that repeated spikes either generate a compact tangent
at a deeper normalization or contradict some invariant inherited from the
original Jordan curve.

---

# 15. Recommended v165 target

The best next target is Branch A, because it is now an exact functional object.

## Route A — fiber multiplicity / sumset classification

Start from

\[
\mathcal L^3(T([0,1]^2))>0.
\tag{15.1}
\]

By (8.4), positive-measure many phase pairs satisfy

\[
\mathcal L^1\bigl(H(F^{-1}(a)+G^{-1}(b))\bigr)>0.
\tag{15.2}
\]

Try to prove that a tangent generated by three blow-ups of one continuous
one-dimensional profile cannot sustain (15.2) unless one of the level-fiber
families contains an interval or a hereditary full-dimensional core.  Either
outcome would connect back to the plateau/critical-set branches already
isolated in v157-v160.

## Route B — variation descent

Section 9 shows at least one of `F,G` has infinite variation.  Quantify this:
show that positive target volume forces a positive density of level crossings
at every scale.  If that crossing density pulls back to the parent profile, it
may force the pressure to grow, converting bounded-pressure Branch A into
Branch B and collapsing the dichotomy.

## Route C — primitive/area constraint

The Li-Pan/Asano-Ike method suggests looking for a primitive whose convergence
is incompatible with a positive-volume tangent (14.1).  This remains less
internal to the present program but may ultimately be stronger.

Route A is the cleanest v165 continuation.

---

# 16. Computational audit

`code/verify_v164.py` audits the following points:

1. the exact three-patch identity (4.6) on randomized piecewise-linear balanced
   profiles;
2. the source-cell oscillation box bound from v163;
3. the witness-cell volume lower-bound algebra;
4. the pressure floor algebra;
5. the modulus-ratio estimate (5.5) under randomized synthetic pressure data;
6. the local-entropy improvement (11.2);
7. the critical-line identity `3 gamma=d+1` for power-law models;
8. the pressure-spike implication (10.4);
9. disappearance of the background identity term `r/omega(r)` under the
   saturation lower bound;
10. finite-level-fiber examples give zero vertical-fiber length, illustrating
    Section 9;
11. piecewise-linear finite-variation triad images exhibit surface-like rather
    than volume-like voxel scaling;
12. the v163/Li-Pan threshold arithmetic remains consistent.

These are consistency checks, not substitutes for the proofs.

---

# 17. Bottom line

v163 produced a pressure inequality.  v164 makes that pressure dynamical.

The central theorem is now

\[
\boxed{
\text{critical-image saturation}
\Longrightarrow
\begin{cases}
\text{positive-volume three-patch tangent}, & P\text{ bounded},\\
\text{super-}2/3\text{ roughness spikes}, & P\text{ unbounded}.
\end{cases}}
\tag{17.1}
\]

In the bounded branch the tangent has the rigid form

\[
\boxed{
T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr),
}
\tag{17.2}
\]

has positive three-dimensional image measure, and cannot have both `F` and `G`
of bounded variation.

So the remaining compact obstruction has finally become an explicit
space-filling functional equation built from three one-dimensional tangent
patches.  That is a substantially narrower target than the arbitrary rough
critical images left by v162-v163.
