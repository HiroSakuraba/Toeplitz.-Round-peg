# External sources / comparison notes for v165

The v165 proofs are self-contained.  These sources are comparison/background
only.

1. Roope Anttila, Balazs Barany, Antti Kaenmaki, **Level sets of prevalent
   Holder functions**, Proceedings of the American Mathematical Society 153(5)
   (2025), 2023-2035. DOI: 10.1090/proc/17045.
   Repository metadata: https://oulurepo.oulu.fi/handle/10024/55699

   Comparison: for prevalent alpha-Holder functions, Lebesgue-positively many
   level sets have Hausdorff dimension 1-alpha.  At alpha=2/3 this is 1/3,
   matching the deterministic integrated level-cell entropy exponent forced by
   v165 in the critical full-core tangent.  v165 does not use prevalence.

2. **Banach indicatrix**, Encyclopedia of Mathematics.
   https://encyclopediaofmath.org/wiki/Banach_indicatrix

   Background for the exact variation/multiplicity identity used in v164.
   v165 uses instead a finite-scale mesh indicatrix for which the integral
   identity is elementary by Tonelli.

3. Xiangfei Li and Yichen Pan, **Rectangular Pegs on Jordan Curves of Finite
   p-Variation**, arXiv:2609.04918v1 (4 September 2026).
   https://arxiv.org/abs/2609.04918

   Global context only: finite p-variation with p<2 is already on the solved
   side for prescribed rectangles/squares.  The v165 tangent theorem is a
   different internal regularity statement.
