# Project Handoff v165: Fiber-Entropy Budget and the Critical 2/3 Fixed Point

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation still does **not** prove the Toeplitz square-peg conjecture.

v164 reduced the bounded-pressure critical-image branch to a continuous
three-patch tangent

\[
T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr),\qquad (x,y)\in[0,1]^2,
\tag{0.1}
\]

with

\[
\mathcal L^3(T([0,1]^2))=V>0.
\tag{0.2}
\]

v164 used Banach's indicatrix theorem to show that `F` and `G` cannot both have
bounded variation.  v165 replaces that qualitative conclusion by a sharp
finite-scale inequality.

The central new theorem is

\[
\boxed{
\omega_F(r)\,\omega_G(r)\,\omega_H(2r)
\ge \frac{V}{4}r^2
}
\tag{0.3}
\]

for every `0<r<=1` (with an inessential change of the universal constant if a
different endpoint partition convention is used).

Consequently, if the three patches are Holder with exponents
`alpha_F, alpha_G, alpha_H`, then necessarily

\[
\boxed{\alpha_F+\alpha_G+\alpha_H\le2.}
\tag{0.4}
\]

In particular, a common Holder exponent strictly larger than `2/3` is
impossible.  More importantly, if the exponent budget is exactly saturated,
then every inequality used in (0.3) is scale-sharp.  The side patches `F,G`
then saturate the maximal graph/fiber complexity allowed by their Holder
regularity.

For the full-dimensional-core branch of v164, the pressure argument supplies a
common `2/3`-Holder upper bound.  v165 therefore proves the exact critical laws

\[
\boxed{
\omega_F(r)\asymp\omega_G(r)\asymp\omega_H(r)\asymp r^{2/3},
}
\tag{0.5}
\]

and

\[
\boxed{
I_F(r)\asymp I_G(r)\asymp r^{-1/3},
}
\tag{0.6}
\]

where `I_F(r)` is the integrated number of horizontal `r`-mesh cells hit by a
level of `F`.  Equivalently, the graphs of `F` and `G` have critical grid-box
complexity

\[
\boxed{N_{\rm graph(F)}(r)\asymp N_{\rm graph(G)}(r)\asymp r^{-4/3}.}
\tag{0.7}
\]

Thus the full-core bounded-pressure survivor is not merely rough.  It is forced
onto a precise `2/3` Peano threshold, with `1/3` level-crossing entropy on both
side patches at every small scale.

A second new result pulls this back before taking the tangent.  Every v164
witness cell of normalized image volume at least `kappa` satisfies

\[
\boxed{
\frac{\omega_f(2\delta r)}{\omega_f(2r)}
\ge
\left(\frac{\kappa}{4}\right)^{1/3}\delta^{2/3}
}
\tag{0.8}
\]

for `0<delta<=1/2`.  So a positive-volume witness cannot become smoother than
`2/3` when one zooms further inside the same witness scale.

This gives a genuine hereditary lower-modulus law and identifies the
full-dimensional bounded-pressure branch as a critical fixed point of the
renormalization.

---

# 1. Fiber formula recalled

Let

\[
E=T([0,1]^2).
\tag{1.1}
\]

For target phases `(a,b)`, put

\[
A_a=F^{-1}(a),\qquad B_b=G^{-1}(b).
\tag{1.2}
\]

The vertical section of `E` is exactly

\[
E_{a,b}=H(A_a+B_b)-a.
\tag{1.3}
\]

Therefore

\[
V
=
\mathcal L^3(E)
=
\iint \mathcal L^1\bigl(H(A_a+B_b)\bigr)\,da\,db.
\tag{1.4}
\]

The subtraction of `a` does not change one-dimensional measure.

The proof below converts (1.4) into an inequality involving only three
one-dimensional moduli of continuity.

---

# 2. Mesh level-count functions

Fix `0<r<=1`.  Partition `[0,1]` into intervals `I_k` of length at most `r`.
There are at most

\[
m(r)\le 1+\frac1r\le\frac2r
\tag{2.1}
\]

such intervals.

For a continuous function `F`, define

\[
n_F(a,r)
=
\#\{k:a\in F(I_k)\}.
\tag{2.2}
\]

Because the image of each interval is an interval, every point of `A_a` lies
in one of these counted source cells.  Hence `A_a` is covered by
`n_F(a,r)` intervals of length at most `r`.

The integral of this mesh indicatrix is exact:

\[
\boxed{
I_F(r)
:=\int n_F(a,r)\,da
=\sum_k \operatorname{osc}_{I_k}F.
}
\tag{2.3}
\]

Indeed, integrate the sum of indicators
`1_{F(I_k)}(a)` and use Tonelli.

Consequently

\[
\boxed{
I_F(r)\le \frac{2\omega_F(r)}r.
}
\tag{2.4}
\]

The same definitions and estimates apply to `G`.

This quantity is a finite-scale version of Banach's indicatrix: instead of
counting exact roots, it counts the horizontal mesh cells in which a root may
occur.

---

# 3. The fiber-cover inequality

Fix `(a,b)`.  Cover `A_a` by its `n_F(a,r)` counted intervals and `B_b` by its
`n_G(b,r)` counted intervals.

For every pair of source intervals `I,J`, the sum `I+J` has length at most
`2r`.  Hence

\[
A_a+B_b
\tag{3.1}
\]

is covered by at most

\[
n_F(a,r)n_G(b,r)
\tag{3.2}
\]

intervals of length at most `2r`.

The image under `H` of each such interval has diameter at most
`omega_H(2r)`.  Therefore

\[
\boxed{
\mathcal L^1\bigl(H(A_a+B_b)\bigr)
\le
\omega_H(2r)n_F(a,r)n_G(b,r).
}
\tag{3.3}
\]

Integrating (3.3) over `(a,b)` and using (1.4) yields the exact product bound

\[
\boxed{
V\le \omega_H(2r)I_F(r)I_G(r).
}
\tag{3.4}
\]

Together with (2.4),

\[
V
\le
4\frac{\omega_F(r)\omega_G(r)\omega_H(2r)}{r^2}.
\tag{3.5}
\]

Thus:

## Theorem 3.1 — three-modulus volume inequality

For every `0<r<=1`,

\[
\boxed{
\omega_F(r)\omega_G(r)\omega_H(2r)
\ge
\frac V4 r^2.
}
\tag{3.6}
\]

No differentiability, bounded variation, rectifiability, or finite branch
assumption is used.

This is the central theorem of v165.

---

# 4. The Holder regularity budget

Suppose for sufficiently small `r`

\[
\omega_F(r)\le L_Fr^{\alpha_F},
\qquad
\omega_G(r)\le L_Gr^{\alpha_G},
\qquad
\omega_H(r)\le L_Hr^{\alpha_H}.
\tag{4.1}
\]

Then (3.5) gives

\[
V
\le
4\,2^{\alpha_H}L_FL_GL_H
r^{\alpha_F+\alpha_G+\alpha_H-2}.
\tag{4.2}
\]

If the exponent sum were greater than `2`, the right side would tend to zero.
Therefore:

## Corollary 4.1 — regularity budget

Every positive-volume tangent satisfies

\[
\boxed{
\alpha_F+\alpha_G+\alpha_H\le2
}
\tag{4.3}
\]

for any simultaneous Holder exponents valid at small scales.

In particular, if a common exponent `alpha` works for all three patches,

\[
\boxed{\alpha\le\frac23.}
\tag{4.4}
\]

Several useful asymmetric consequences are immediate.

* If `F` and `G` are Lipschitz, continuity of `H` already contradicts positive
  volume, because (3.6) would require `omega_H(2r)` to stay bounded away from
  zero.
* If `F` is Lipschitz and `G` is `beta`-Holder, then an `alpha_H`-Holder `H`
  requires `beta+alpha_H<=1`.
* Any gain of smoothness in one patch must be paid for by roughness in one or
  both of the other two patches.

This is a useful replacement for the weaker statement from v164 that one of
`F,G` has infinite ordinary variation.

---

# 5. Critical exponent equality forces scale saturation

The equality case of (4.3) is rigid.

Assume

\[
\alpha_F+\alpha_G+\alpha_H=2
\tag{5.1}
\]

and the upper bounds (4.1).  From (3.6),

\[
\omega_F(r)
\ge
\frac{V r^2}{4\omega_G(r)\omega_H(2r)}
\ge
c_Fr^{\alpha_F}.
\tag{5.2}
\]

The same argument gives the lower bound for `G`; for `H`, apply (3.6) at scale `r/2` and use the upper bounds for `F,G`.  Hence

\[
\boxed{
\omega_F(r)\asymp r^{\alpha_F},\qquad
\omega_G(r)\asymp r^{\alpha_G},\qquad
\omega_H(r)\asymp r^{\alpha_H}.
}
\tag{5.3}
\]

Thus none of the three functions can secretly be smoother than the exponent
assigned to it.

The indicatrix entropy is also forced to saturate.  From (3.4),

\[
I_F(r)I_G(r)
\ge
\frac{V}{\omega_H(2r)}
\ge
c r^{-\alpha_H}.
\tag{5.4}
\]

But (2.4) and the Holder upper bounds give

\[
I_F(r)\le C_Fr^{\alpha_F-1},
\qquad
I_G(r)\le C_Gr^{\alpha_G-1}.
\tag{5.5}
\]

Using (5.1), dividing (5.4) by the upper bound for the opposite side yields

\[
\boxed{
I_F(r)\asymp r^{\alpha_F-1},
\qquad
I_G(r)\asymp r^{\alpha_G-1}.
}
\tag{5.6}
\]

So both side functions attain the maximum integrated level-crossing complexity
compatible with their Holder exponents.

---

# 6. Graph-box saturation on the critical line

For the same horizontal partition, let `Q_F(r)` be the number of axis-aligned
`r`-mesh squares intersecting the graph of `F`.

Continuity implies, up to universal endpoint constants,

\[
Q_F(r)
\asymp
\frac1r+\frac1r\sum_k\operatorname{osc}_{I_k}F
=
\frac1r+\frac{I_F(r)}r.
\tag{6.1}
\]

If `0<alpha_F<1`, (5.6) therefore gives

\[
\boxed{
Q_F(r)\asymp r^{\alpha_F-2}.
}
\tag{6.2}
\]

Similarly,

\[
\boxed{
Q_G(r)\asymp r^{\alpha_G-2}.
}
\tag{6.3}
\]

Hence the critical side graphs attain the standard Holder upper box exponent:

\[
\boxed{
\dim_B\operatorname{graph}(F)=2-\alpha_F,
\qquad
\dim_B\operatorname{graph}(G)=2-\alpha_G,
}
\tag{6.4}
\]

provided the displayed power-law Holder bounds hold uniformly at all
sufficiently small scales.

This is deterministic.  No genericity or prevalence hypothesis is being used.

---

# 7. The full-dimensional-core fixed point

Now return to the v164 pressure tangent.  Suppose the witness core has the full
local covering exponent

\[
N(\rho)\ge c\frac r\rho N(r),
\qquad 0<\rho\le r,
\tag{7.1}
\]

which is `d=1` in v164 Section 11.

The pressure ceiling and floor then gave the normalized patch upper bound

\[
\omega_F(\delta),\omega_G(\delta),\omega_H(\delta)
\le C\delta^{2/3}.
\tag{7.2}
\]

Because the tangent image has volume `V>0`, Theorem 3.1 places the three patches
exactly on the critical regularity line.  Therefore:

## Theorem 7.1 — critical `2/3` fixed point

In the bounded-pressure, full-dimensional-core regime,

\[
\boxed{
\omega_F(r)\asymp
\omega_G(r)\asymp
\omega_H(r)\asymp
r^{2/3}
}
\tag{7.3}
\]

and

\[
\boxed{
I_F(r)\asymp I_G(r)\asymp r^{-1/3}.
}
\tag{7.4}
\]

Consequently

\[
\boxed{
Q_F(r)\asymp Q_G(r)\asymp r^{-4/3}.
}
\tag{7.5}
\]

Thus the terminal object has an exact critical signature:

* horizontal modulus exponent `2/3` on all three patches;
* integrated level-fiber entropy exponent `1/3` on both side patches;
* graph box exponent `4/3` on both side patches.

This is much more rigid than the statement “at least one side has infinite
variation.”

For comparison only: recent work on prevalent Holder functions finds level-set
dimension `1-alpha` on a positive-measure set of levels in a generic/prevalent
sense.  At `alpha=2/3` that is `1/3`, matching the exponent forced here by a
completely different deterministic positive-volume mechanism.  v165 does not
use that prevalence theorem.

---

# 8. Hereditary lower modulus before taking the tangent

The three-modulus inequality can be applied to each finite v164 witness cell,
not only to its limit.

Let a witness cell have side `r`, normalization

\[
\lambda_r=\omega_f(2r),
\tag{8.1}
\]

and normalized endpoint map

\[
T_r(x,y)=
(F_r(x),G_r(y),H_r(x+y)-F_r(x)).
\tag{8.2}
\]

Suppose

\[
\mathcal L^3(T_r([0,1]^2))\ge\kappa>0.
\tag{8.3}
\]

Applying Theorem 3.1 at child scale `delta` gives

\[
\omega_{F_r}(\delta)
\omega_{G_r}(\delta)
\omega_{H_r}(2\delta)
\ge
\frac\kappa4\delta^2.
\tag{8.4}
\]

Every factor on the left is at most

\[
\frac{\omega_f(2\delta r)}{\omega_f(2r)}.
\tag{8.5}
\]

Therefore:

## Theorem 8.1 — hereditary `2/3` lower-modulus law

For every sufficiently small witness scale `r` and `0<delta<=1/2`,

\[
\boxed{
\frac{\omega_f(2\delta r)}{\omega_f(2r)}
\ge
c_\kappa\delta^{2/3},
\qquad
c_\kappa=\left(\frac\kappa4\right)^{1/3}.
}
\tag{8.6}
\]

Thus a positive-volume witness cannot smooth out faster than the critical
`2/3` rate at any deeper relative scale.

This is the first genuinely hereditary roughness statement in the
pressure-tangent branch.

---

# 9. Interaction with pressure inheritance

Recall

\[
P(r)=\frac{N(r)\omega_f(2r)^3}{r}.
\tag{9.1}
\]

Suppose the core covering number obeys the local entropy lower bound

\[
\frac{N(\delta r)}{N(r)}\ge c_d\delta^{-d}.
\tag{9.2}
\]

Then Theorem 8.1 gives

\[
\frac{P(\delta r)}{P(r)}
=
\frac{N(\delta r)}{N(r)}
\left(\frac{\omega_f(2\delta r)}{\omega_f(2r)}\right)^3
\frac1\delta
\ge
c_dc_\kappa^3\delta^{1-d}.
\tag{9.3}
\]

Hence

\[
\boxed{
P(\delta r)\gtrsim \delta^{1-d}P(r).
}
\tag{9.4}
\]

For `d=1`, pressure is hereditary up to a constant factor:

\[
\boxed{P(\delta r)\gtrsim P(r).}
\tag{9.5}
\]

This justifies calling Theorem 7.1 a critical fixed point.  In the
full-dimensional-core branch, neither the pressure nor the normalized target
volume can dissipate under a further zoom without violating the positive-volume
fiber inequality.

For `d<1`, the lower bound allows pressure to decay like `delta^{1-d}`.  That
lower-dimensional entropy-loss branch remains open.

---

# 10. A scale-local level-fiber multiplicity consequence

Equation (3.4) can be read independently of Holder exponents:

\[
\boxed{
I_F(r)I_G(r)\ge \frac V{\omega_H(2r)}.
}
\tag{10.1}
\]

Therefore

\[
\boxed{
\max\{I_F(r),I_G(r)\}
\ge
\sqrt{\frac V{\omega_H(2r)}}.
}
\tag{10.2}
\]

Since `omega_H(r)->0`, at least one side's integrated level-cell multiplicity
must diverge at every sufficiently fine scale.  This is a finite-scale
strengthening of v164 Theorem 9.1.

At the critical `2/3` fixed point, both sides diverge at the exact rate
`r^{-1/3}` by Theorem 7.1.

One can also localize (10.1) to any positive-measure phase-pair subset on which
the vertical fibers have a uniform positive length.  This will likely be the
right starting point for a hereditary level-core extraction in v166.

---


# 11. Positive-measure simultaneous critical level fibers

The equality case contains more information than the integrated laws alone.

Because the vertical-fiber length

\[
L(a,b)=\mathcal L^1\bigl(H(A_a+B_b)\bigr)
\tag{11.1}
\]

has positive integral `V`, there exist `ell_0>0` and a measurable phase-pair
set `E_0` of positive two-dimensional measure such that

\[
L(a,b)\ge\ell_0
\qquad ((a,b)\in E_0).
\tag{11.2}
\]

The pointwise fiber-cover estimate (3.3) therefore gives, for every small `r`,

\[
\boxed{
n_F(a,r)n_G(b,r)
\ge
\frac{\ell_0}{\omega_H(2r)}
\qquad ((a,b)\in E_0).
}
\tag{11.3}
\]

Assume now the critical Holder equality

\[
\alpha_F+\alpha_G+\alpha_H=2.
\tag{11.4}
\]

The integrated upper bounds

\[
\int n_F(a,r)\,da\le C_Fr^{\alpha_F-1},
\qquad
\int n_G(b,r)\,db\le C_Gr^{\alpha_G-1}
\tag{11.5}
\]

and Markov's inequality allow the deletion, at each scale, of phase strips of
arbitrarily small total two-dimensional measure on which either mesh count is
larger than a fixed multiple of its critical average size.  On the remaining
subset `E_r subset E_0`, whose measure is bounded below independently of `r`,
(11.3) forces the opposite inequalities as well:

\[
\boxed{
n_F(a,r)\asymp r^{\alpha_F-1},
\qquad
n_G(b,r)\asymp r^{\alpha_G-1}
\qquad ((a,b)\in E_r).
}
\tag{11.6}
\]

The constants are uniform in `r`.

Choose dyadic scales `r_n=2^{-n}`.  Since the sets `E_{r_n}` have a uniform
positive measure, their limsup has positive measure.  Consequently there is a
positive-measure set of phase pairs for which **both** level sets attain the
critical mesh multiplicity along infinitely many scales.

Because each counted mesh interval actually contains a root (by the
intermediate value theorem), and one interval of length `r` can cover only a
bounded number of adjacent `r`-mesh cells, this implies

\[
\boxed{
\overline{\dim}_B F^{-1}(a)\ge 1-\alpha_F,
\qquad
\overline{\dim}_B G^{-1}(b)\ge 1-\alpha_G
}
\tag{11.7}
\]

for the corresponding phase pairs (and therefore on positive-measure
projections of levels on both sides).

At the symmetric fixed point `alpha_F=alpha_G=alpha_H=2/3`, positive-measure
many relevant levels on **both** side patches have upper box dimension at least

\[
\boxed{\frac13.}
\tag{11.8}
\]

This is the first extraction of actual thick level fibers, rather than only an
integrated multiplicity statistic.  The set may depend on a limsup of scales;
v165 does not yet promote these level fibers into a hereditary persistence core.

---

# 12. What v165 rules out

v165 eliminates several subclasses of the v164 tangent obstruction.

### 12.1 Common regularity above `2/3`

No positive-volume tangent of the special form (0.1) can have all three patches
Holder with a common exponent `>2/3`.

### 12.2 Two smooth side patches

Two Lipschitz side patches already make positive volume impossible, regardless
of how badly `H` behaves subject to continuity.

### 12.3 A noncritical full-dimensional bounded-pressure tangent

If the persistence core has full local metric entropy (`d=1`), then the tangent
cannot be substantially smoother or substantially less level-multiple than the
`2/3`, `1/3`, `4/3` critical laws in Theorem 7.1.

### 12.4 Dissipation inside a full-core witness

The normalized modulus cannot collapse below `delta^{2/3}` on a deeper child
scale, and pressure remains hereditary up to constants when `d=1`.

---

# 13. What remains open after v165

There are now two bounded-pressure subbranches.

## Branch A — full-dimensional critical fixed point

The strongest terminal object is

\[
T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr),
\qquad |T([0,1]^2)|>0,
\tag{12.1}
\]

with exact critical scaling

\[
\omega_F,\omega_G,\omega_H\asymp r^{2/3},
\tag{12.2}
\]

and

\[
I_F,I_G\asymp r^{-1/3}.
\tag{12.3}
\]

This is a much narrower functional object than v164's generic
positive-volume tangent.

The obvious next question is whether such an object can actually arise from
three blow-ups of one scalar phase profile while retaining the inherited
return-arch/contact structure.

## Branch B — lower-dimensional core

If the local core entropy exponent `d<1`, v164 only provides the common upper
Holder exponent `(d+1)/3<2/3`.  The regularity budget then has slack.

Theorem 9.4 says pressure can lose at most a factor `delta^{1-d}` under one
relative zoom, but this is not enough to force a fixed point.

A useful v166 goal is to extract a new level core from the large indicatrix
entropy in (10.1) and show that its entropy exponent is larger than the old
persistence-core exponent.  Repeated extraction might drive `d` upward toward
`1`, where Theorem 7.1 becomes critical and hereditary.

The unbounded-pressure super-`2/3` spike branch from v164 also remains open.

---

# 14. Recommended v166 target

The best next route is an **entropy ascent theorem**.

From a positive-volume tangent choose a positive-measure phase-pair set `E_0`
and `ell_0>0` such that

\[
\mathcal L^1(H(F^{-1}(a)+G^{-1}(b)))\ge\ell_0
\tag{13.1}
\]

for `(a,b) in E_0`.

At every scale `r`, (3.3) gives

\[
n_F(a,r)n_G(b,r)
\ge
\frac{\ell_0}{\omega_H(2r)}.
\tag{13.2}
\]

The task is to convert this product lower bound, on a positive-measure family
of phase pairs, into a compact level-core carrier with a hereditary covering
exponent.  In the critical `2/3` branch the natural target exponent is `1/3`
for each side level fiber.

If such level cores can be promoted back into persistence cores at the next
return-arch scale, the renormalization would acquire an entropy map

\[
d\mapsto d_{\rm child}.
\tag{13.3}
\]

Any strict ascent `d_child>d` away from `d=1` would collapse the bounded-pressure
branch after finitely or asymptotically many iterations.

A secondary route is to classify the exact `2/3` fixed point directly using the
same-profile origin of `F,G,H`.

---

# 15. External comparison

The proof of v165 is elementary and self-contained; it does not depend on a
level-set dimension theorem.

For comparison, Anttila, Barany and Kaenmaki, *Level sets of prevalent Holder
functions*, Proceedings of the AMS 153 (2025), 2023-2035,
DOI `10.1090/proc/17045`, show that for prevalent `alpha`-Holder functions,
Lebesgue-positively many level sets have Hausdorff dimension `1-alpha`.
At the v165 critical value `alpha=2/3`, this generic exponent is `1/3`, the same
number that appears deterministically in the integrated indicatrix law (7.4).
The mechanisms are different and no prevalence claim is made here.

The recent Li-Pan finite-`p`-variation theorem from v163-v164 remains relevant
only as a global regularity boundary for the original Jordan curve, not as an
ingredient in the v165 tangent proof.

---

# 16. Computational audit

`code/verify_v165.py` checks:

1. the exact mesh-indicatrix identity `I_F=sum osc(F|I_k)` on randomized
   piecewise-linear functions;
2. the bound `I_F<=2 omega_F(r)/r`;
3. level-set source cells really cover all sampled exact piecewise-linear roots;
4. pairwise source-cell sums cover all sampled sums of exact roots;
5. the exponent-budget implication `alpha_F+alpha_G+alpha_H<=2`;
6. equality-case modulus saturation algebra;
7. equality-case indicatrix saturation algebra;
8. the `2/3,1/3,4/3` critical exponent arithmetic;
9. the hereditary lower-modulus formula (8.6);
10. the pressure inheritance formula (9.3);
11. the asymmetric regularity-budget examples;
12. critical graph-grid scaling from `I(r)~r^{-1/3}`.

These are consistency checks and finite models, not substitutes for the proofs.

---

# 17. Bottom line

v164 showed that bounded pressure produces a positive-volume three-patch
tangent.  v165 quantifies exactly how rough such a tangent must be.

The central new law is

\[
\boxed{
\omega_F(r)\omega_G(r)\omega_H(2r)\gtrsim r^2.
}
\tag{16.1}
\]

It yields the sharp regularity budget

\[
\boxed{\alpha_F+\alpha_G+\alpha_H\le2.}
\tag{16.2}
\]

At equality, the side fibers and graphs must saturate their Holder complexity.
For the full-dimensional-core v164 branch this forces the exact critical
signature

\[
\boxed{
2/3\text{ modulus}
\;\leftrightarrow\;
1/3\text{ level entropy}
\;\leftrightarrow\;
4/3\text{ graph complexity}.
}
\tag{16.3}
\]

Moreover the `2/3` lower modulus is hereditary inside every positive-volume
witness cell.

The bounded-pressure obstruction is therefore no longer merely a rough Peano
surface.  Its full-core branch is a precise critical fixed point.  The next
question is whether the large level entropy forced by positive target volume
can be promoted into a thicker child persistence core, giving an entropy-ascent
mechanism toward that fixed point.
