# External sources used in v166

## Falconer–Liu sequence property
Kenneth Falconer and Yuyang Liu, *The sequence property for fractal dimensions*,
arXiv:2608.06051 (6 August 2026).

The paper proves, among other results, that every compact set of positive upper
box dimension contains a convergent sequence with the same upper box dimension.
For subsets of R the witnessing sequence may be chosen monotone.

https://arxiv.org/abs/2608.06051

This is used only to diagnose why an upper-box-dimension entropy-ascent argument
is insufficient.  The carrier-measure theorem in v166 is proved directly by a
covering argument.

## Fraser–Yu weak tangents (comparison only)
Jonathan M. Fraser and Han Yu, *Arithmetic patches, weak tangents, and
dimension*, Bull. London Math. Soc. 50 (2018), 85–95.

They relate full Assouad dimension to weak tangents with non-empty interior.
v166 does not need that theorem: the interval weak tangent at a Lebesgue density
point is proved directly.

https://doi.org/10.1112/blms.12112
