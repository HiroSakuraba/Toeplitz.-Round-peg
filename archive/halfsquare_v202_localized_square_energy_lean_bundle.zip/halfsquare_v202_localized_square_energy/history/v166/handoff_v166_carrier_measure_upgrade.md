# Project Handoff v166: Carrier Measure Upgrade and Density-Tangent Reduction

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.

v163–v165 reduced one compact square-free escape branch to saturation of a
critical image

\[
Q\subset \Psi_s(K\times J),
\qquad
\Psi_s(u,v)=\bigl(f(u),f(v),f(u+v-s)-f(u)\bigr),
\tag{0.1}
\]

where `Q` is an open three-dimensional target box, `K` is an accumulated
persistence-core carrier on one side, and `J` is a nondegenerate interval on
the other side.

v164 introduced the covering pressure

\[
P(r)=\frac{N_K(r)\,\omega_f(2r)^3}{r}.
\tag{0.2}
\]

In a power-law bounded-pressure regime

\[
N_K(r)\asymp r^{-d},
\qquad
\omega_f(r)\asymp r^\alpha,
\tag{0.3}
\]

pressure balance is

\[
\boxed{3\alpha=d+1.}
\tag{0.4}
\]

v165 proposed extracting thick level sets and proving an entropy ascent
`d_child>d`.  v166 shows why that proposal is too strong at the upper-box level
and replaces it by a Hausdorff-measure theorem.

The main new conclusion is:

\[
\boxed{
Q\subset\Psi_s(K\times J),\quad
f\in C^{0,\alpha},\quad d=3\alpha-1
\Longrightarrow
\mathcal H^d(K)>0.
}
\tag{0.5}
\]

At the full critical fixed point `alpha=2/3`, `d=1`, hence

\[
\boxed{|K|>0.}
\tag{0.6}
\]

Thus the terminal full-dimensional carrier cannot be merely a nowhere-dense
set of full box dimension zero Lebesgue measure, nor can its entropy be carried
only by a scattered/convergent sequence.  It must be a **fat singular
carrier**.

Moreover, at Lebesgue density points of `K`, blow-ups of `K` converge in
Hausdorff distance to an interval.  This converts the full fixed-point branch
into an interval-like spatial tangent with the remaining difficulty entirely
in whether the return/folding amplitude survives the phase normalization.

---

# 1. Why the proposed upper-box entropy ascent is not robust

The v165 level-fiber estimate gives, on a positive-measure phase-pair set,

\[
n_F(a,r)n_G(b,r)
\gtrsim \frac1{\omega_H(2r)}.
\tag{1.1}
\]

It is tempting to interpret large mesh multiplicity as a large persistent
accumulation core.  That implication is false for upper box dimension.

For example, the convergent sequence

\[
S_p=\{0\}\cup\{n^{-p}:n\ge1\}
\tag{1.2}
\]

has

\[
\overline{\dim}_B S_p=\frac1{p+1},
\tag{1.3}
\]

but Hausdorff dimension zero and only one accumulation point.

This is a general phenomenon rather than a special example.  Falconer and Liu
(2026) prove that every compact set of positive upper box dimension contains a
convergent sequence with the same upper box dimension.  For subsets of the
line the witnessing sequence can be chosen monotone.

Therefore upper box dimension is the wrong invariant for the desired
"level entropy -> persistent core" promotion.  A high-dimensional box carrier
may still concentrate its entire box entropy into a sequence approaching one
point.

This does **not** invalidate the v163 pressure inequalities: they remain valid
necessary covering estimates.  It means only that pressure saturation must be
combined with target **measure**, not just source covering number.

---

# 2. A critical carrier-content inequality

Let `K subset R` be compact and let `J` be a compact interval of length `L_J>0`.
Assume `f` is alpha-Holder on a compact interval containing

\[
K\cup J\cup(K+J-s),
\tag{2.1}
\]

with constant `L`:

\[
|f(x)-f(y)|\le L|x-y|^\alpha,
\qquad 0<\alpha\le1.
\tag{2.2}
\]

Put

\[
d=3\alpha-1.
\tag{2.3}
\]

The interesting pressure range has `alpha>=1/3`, so `d>=0`.

Take any fine interval cover

\[
K\subset\bigcup_i I_i,
\qquad |I_i|=r_i\le\delta.
\tag{2.4}
\]

For each `I_i`, cover `J` by at most

\[
m_i\le1+\frac{L_J}{r_i}
\tag{2.5}
\]

intervals `J_{ij}` of length at most `r_i`.

On one rectangle `I_i x J_{ij}` the first two coordinates of `Psi_s` oscillate
by at most

\[
Lr_i^\alpha.
\tag{2.6}
\]

The third coordinate oscillates by at most

\[
L(2r_i)^\alpha+Lr_i^\alpha
=(1+2^\alpha)Lr_i^\alpha.
\tag{2.7}
\]

Hence its image is contained in a rectangular target box of volume at most

\[
C_\alpha L^3 r_i^{3\alpha},
\qquad C_\alpha=1+2^\alpha.
\tag{2.8}
\]

Subadditivity of outer Lebesgue measure gives

\[
\begin{aligned}
\mathcal L^3(\Psi_s(K\times J))
&\le
C_\alpha L^3
\sum_i
\left(1+\frac{L_J}{r_i}\right)r_i^{3\alpha}\\
&=
C_\alpha L^3
\sum_i\left(r_i^{d+1}+L_Jr_i^d\right).
\end{aligned}
\tag{2.9}
\]

Since `r_i<=delta`,

\[
\boxed{
\mathcal L^3(\Psi_s(K\times J))
\le
C_\alpha L^3(L_J+\delta)
\sum_i r_i^d.
}
\tag{2.10}
\]

Taking the infimum over all delta-covers and then `delta -> 0` yields:

## Theorem 2.1 — carrier Hausdorff-measure necessity

If

\[
V:=\mathcal L^3(\Psi_s(K\times J))>0,
\tag{2.11}
\]

then

\[
\boxed{
\mathcal H^d(K)>0,
\qquad d=3\alpha-1,
}
\tag{2.12}
\]

with a quantitative lower bound at the level of Hausdorff content determined
by `V`, `L`, `L_J`, and `alpha`.

In particular,

\[
\boxed{\dim_HK\ge3\alpha-1.}
\tag{2.13}
\]

This is the Hausdorff analogue of the v163 box-pressure barrier, but it is
strictly stronger for scattered or highly inhomogeneous carriers.

---

# 3. Critical-line rigidity of the carrier dimension

Suppose now that the bounded-pressure regime has an actual source covering
exponent `d` and a Holder exponent `alpha` satisfying the critical balance

\[
3\alpha=d+1.
\tag{3.1}
\]

If, in addition,

\[
\overline{\dim}_B K\le d,
\tag{3.2}
\]

then Theorem 2.1 gives

\[
d
\le\dim_HK
\le\overline{\dim}_B K
\le d.
\tag{3.3}
\]

Therefore

\[
\boxed{
\dim_HK=\overline{\dim}_B K=d,
\qquad
\mathcal H^d(K)>0.
}
\tag{3.4}
\]

So at an exact bounded-pressure fixed point the carrier cannot obtain its box
entropy from isolated point clusters.  The critical source exponent has to be
real Hausdorff geometry.

By Frostman's lemma, (3.4) also yields a nonzero finite Borel measure `mu`
supported on `K` with

\[
\boxed{\mu(I)\le C|I|^d}
\tag{3.5}
\]

for all intervals `I`.

This is a better hereditary object than the bare covering count: target-volume
saturation manufactures a genuine Frostman carrier.

---

# 4. The full `2/3` fixed point is a positive-measure carrier

Set

\[
\alpha=\frac23.
\tag{4.1}
\]

Then

\[
d=3\alpha-1=1.
\tag{4.2}
\]

Theorem 2.1 becomes

\[
\boxed{
\mathcal L^3(\Psi_s(K\times J))>0
\Longrightarrow
\mathcal H^1(K)>0.
}
\tag{4.3}
\]

For subsets of the real line, `H^1` is Lebesgue measure up to the standard
normalization.  Thus

\[
\boxed{|K|>0.}
\tag{4.4}
\]

More quantitatively, (2.10) at `d=1` gives a critical Lusin-type estimate

\[
\boxed{
\mathcal L^3(\Psi_s(A\times J))
\le C L^3L_J |A|
}
\tag{4.5}
\]

for measurable `A subset K`, after outer regularization and with a universal
constant `C`.

Consequences:

* a Lebesgue-null subset of the carrier contributes zero three-dimensional
  critical-image volume;
* a countable or purely scattered carrier cannot support the saturated target;
* target volume may be localized, up to a null target set, to the Lebesgue
  density points of `K`.

This materially sharpens the v165 description "full box dimensional
nowhere-dense core".  A survivor may still be nowhere dense, but it must be a
**fat** nowhere-dense carrier.

---

# 5. Density points give interval weak tangents

Let `x` be a Lebesgue density point of `K`.  Choose `R_n downarrow 0` so that

\[
\varepsilon_n
:=
1-\frac{|K\cap[x-R_n,x+R_n]|}{2R_n}
\to0.
\tag{5.1}
\]

Define

\[
K_n
=
\frac{K-x}{R_n}\cap[-1,1].
\tag{5.2}
\]

The complement of `K_n` in `[-1,1]` has length `2 epsilon_n`.  Every component
of that complement therefore has length at most `2 epsilon_n`.  Hence every
point of `[-1,1]` is within `2 epsilon_n` of `K_n`, while `K_n subset[-1,1]`.
Thus

\[
\boxed{
d_H(K_n,[-1,1])\le2\varepsilon_n\to0.
}
\tag{5.3}
\]

So:

## Theorem 5.1 — interval carrier tangent

Every positive-measure compact carrier `K subset R` has a density-point blow-up
whose Hausdorff limit is an interval.

This is elementary here; no general Assouad weak-tangent theorem is needed.

The same density estimate gives the full local covering law.  If
`0<rho<R_n` and intervals of length at most `rho` cover
`K cap [x-R_n,x+R_n]`, then

\[
N\rho
\ge
|K\cap[x-R_n,x+R_n]|,
\tag{5.4}
\]

so

\[
\boxed{
N_\rho(K\cap[x-R_n,x+R_n])
\ge
2(1-\varepsilon_n)\frac{R_n}{\rho}.
}
\tag{5.5}
\]

Thus the `d=1` local entropy law used conditionally in v164 becomes automatic
at density-point carrier scales once the critical `2/3` saturation is known.

---

# 6. Density points carry essentially all critical target volume

Let `D subset K` be the set of Lebesgue density points of `K`.  By the Lebesgue
density theorem,

\[
|K\setminus D|=0.
\tag{6.1}
\]

The critical estimate (4.5) therefore gives

\[
\mathcal L^3(\Psi_s((K\setminus D)\times J))=0.
\tag{6.2}
\]

Hence, if an open target box `Q` is contained in `Psi_s(K x J)`, then almost
every point of `Q` that is represented through this orientation has a
representation with first coordinate in the density-point carrier, modulo the
possible overlap with the null image (6.2).

This is the useful hereditary form of Theorem 5.1: the saturated image cannot
hide exclusively on the exceptional zero-density part of the fat carrier.

What is **not** yet proved is that the non-local-injectivity/return amplitude at
those density points survives after the `r^(2/3)` vertical normalization.
Critical points can be dense while their local folding amplitude tends to zero
faster than the ambient modulus.  That is now the precise blocker.

---

# 7. Why the Falconer–Liu sequence theorem matters here

Falconer and Liu prove that upper box dimension has the sequence property: a
compact set contains a convergent sequence with the same upper box dimension.
For subsets of `R`, a monotone convergent sequence can be chosen.

This shows that the v165 proposed entropy map

\[
d\mapsto d_{child}
\tag{7.1}
\]

cannot be justified from box multiplicity alone.  Even a level set with large
upper box dimension may have all that box entropy concentrated into a sequence
with a single limit point.

There is an even simpler target-volume diagnostic.  If `S` is countable, then

\[
\Psi_s(S\times J)
=\bigcup_{u\in S}\Psi_s(\{u\}\times J).
\tag{7.2}
\]

Each set in the union lies in the plane whose first target coordinate is the
constant `f(u)`.  Therefore each has zero three-dimensional Lebesgue measure,
and so

\[
\boxed{
\mathcal L^3(\Psi_s(S\times J))=0.
}
\tag{7.3}
\]

Thus the box-dimension sequence witness can reproduce the source covering
exponent while being completely incapable of supporting the saturated target
volume.  This is exactly why Hausdorff measure, rather than box dimension, is
the correct next invariant.

---

# 8. Updated obstruction ledger

The bounded-pressure branch now separates into two qualitatively different
situations.

## 8.1 Critical power-law carrier

If

\[
3\alpha=d+1,
\tag{8.1}
\]

then saturation forces

\[
\mathcal H^d(K)>0.
\tag{8.2}
\]

At `d=1`, the carrier has positive Lebesgue measure and interval weak tangents.
The old "full box dimension but arbitrarily sparse" escape is gone.

## 8.2 Noncritical / pressure-spike carrier

If the available Holder exponent and source box exponent are not on the
critical line, Theorem 2.1 still supplies

\[
\dim_HK\ge3\alpha-1,
\tag{8.3}
\]

but there may be dimension slack.  The unbounded-pressure super-`2/3` spike
branch remains untouched.

---

# 9. Recommended v167 target: active criticality at density points

The strongest remaining full-fixed-point object is now:

1. `K subset K(f)` is compact and has positive Lebesgue measure;
2. at almost every carrier point, blow-ups of `K` spatially fill an interval;
3. the phase modulus is critical, `omega(r) asymp r^(2/3)` along witness scales;
4. the target map still has a positive-volume witness;
5. but local return amplitudes at individual carrier points may vanish below
   the `r^(2/3)` normalization.

The next invariant should therefore distinguish **active** from **passive**
critical points.  One possible definition at scale `r` is

\[
A_{\tau}(r)
=
\left\{x\in K:
\text{some return arch in }[x-r,x+r]
\text{ has phase depth at least }\tau\omega(r)
\right\}.
\tag{9.1}
\]

The desired v167 dichotomy is:

\[
\boxed{
\begin{array}{ll}
|A_\tau(r)|\gtrsim r
&\Rightarrow\text{ active interval-like return tangent and degree},\\[1mm]
|A_\tau(r)|=o(r)
&\Rightarrow\text{ almost all carrier mass is passive; remove it from the}
\\
&\qquad\text{critical image without losing target volume.}
\end{array}}
\tag{9.2}
\]

The second implication is the difficult one.  If it can be established using
the v162 critical-image localization, the full `2/3` fixed point may finally
collapse.

---

# 10. Bottom line

v166 does not obtain the hoped-for monotone entropy ascent.  It obtains a
stronger and more appropriate replacement:

\[
\boxed{
\text{critical target volume}
\Longrightarrow
\text{positive Hausdorff measure of the singular carrier}.
}
\tag{10.1}
\]

At the terminal `2/3` fixed point this becomes

\[
\boxed{
\text{positive-volume critical image}
\Longrightarrow
|K|>0
\Longrightarrow
\text{interval carrier weak tangents}.
}
\tag{10.2}
\]

So the compact survivor is no longer a generic fractal dust.  Spatially, it
fills intervals in the tangent limit.  The remaining issue is purely whether
the folding responsible for membership in `K(f)` remains **phase-visible** at
that tangent scale.
