# External sources used in v167

1. J. D. Howroyd, *On Hausdorff and packing dimension of product spaces*,
   Mathematical Proceedings of the Cambridge Philosophical Society 119 (1996),
   715–727. Used for the standard upper product inequality
   `dim_H(X x Y) <= dim_H X + dim_P Y` for Borel subsets of Euclidean spaces.

2. Pertti Mattila, *Geometry of Sets and Measures in Euclidean Spaces*, Cambridge
   Studies in Advanced Mathematics 44, 1995. Standard reference for Hausdorff,
   packing, product, and slicing dimension inequalities.

3. Matthew Badger and Kevin Palmer, *Space-filling surfaces: sharp Hölder
   continuous parameterizations from squares to cubes*, arXiv:2608.21246,
   21 August 2026. They construct sharp `2/3`-Hölder surjections
   `[0,1]^2 -> [0,1]^3`. This is used only as an external diagnostic showing
   that the `2/3` volume threshold is genuinely attainable for general maps;
   therefore v167 must exploit the special sum-coupled/persistence structure.

4. Zoltán Buczolich and Balázs Maga, *Exact formula on upper box dimension of
   generic Hölder level sets*, arXiv:2602.09749v2, revised 4 August 2026.
   Their generic result gives upper box dimension `dim_H F - alpha` for
   Lebesgue-a.e. level in a broad self-similar setting. This is comparison only;
   v167 Theorem 2.1 is an elementary non-generic upper bound specialized to
   one-dimensional `2/3`-Hölder functions and is proved directly in the bundle.

## Current-source metadata checked 8 September 2026

- Badger–Palmer arXiv page lists submission date 21 August 2026 and Theorem 1.1:
  for every m>=2, an m/(m+1)-Hölder surjection from [0,1]^m onto
  [0,1]^(m+1); in particular 2/3-Hölder maps from squares onto cubes.
- Buczolich–Maga arXiv page lists v2 revised 4 August 2026 and states that for
  the covered self-similar domains, Lebesgue-a.e. level set of a generic
  1-Hölder-alpha function has upper box dimension dim_H(F)-alpha.
