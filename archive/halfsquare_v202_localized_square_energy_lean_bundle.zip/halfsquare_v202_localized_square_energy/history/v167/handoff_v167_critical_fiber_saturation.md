# Project Handoff v167: Critical Fiber Saturation and Incidence Closure

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.

v166 reduced the full-dimensional bounded-pressure branch to a positive-measure
persistence carrier whose density-point blow-ups are spatially interval-like.
The suggested next step was to distinguish carrier points by whether the return
arches responsible for their criticality remain vertically visible at the
critical normalization.

v167 makes two changes.

First, it records a correction: **return-arch depth is not retained by the
v162 critical image or by the v164-v166 tangent.**  A vanishing-persistence arch
may become vertically invisible after normalization while its endpoint location
still converges to a critical fiber point.  Therefore the proposed implication

\[
\text{``passive return depth''}\Longrightarrow
\text{``removable from the critical image''}
\]

is not available from the current hypotheses.  Treating it as a theorem would
reintroduce exactly the information lost in the persistence limit.

Second, the positive-volume tangent has substantially more rigidity than was
used in v165-v166.  In the terminal symmetric branch let

\[
T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr),
\qquad (x,y)\in[0,1]^2,
\tag{0.1}
\]

where `F,G,H` are `2/3`-Hölder and

\[
V:=\mathcal L^3(T([0,1]^2))>0.
\tag{0.2}
\]

For levels `a,b`, put

\[
X_a=F^{-1}(a),\qquad Y_b=G^{-1}(b),\qquad
S_{a,b}=X_a+Y_b.
\tag{0.3}
\]

The exact vertical fiber is

\[
E_{a,b}=H(S_{a,b})-a.
\tag{0.4}
\]

v167 proves that for a positive-measure set of pairs `(a,b)` with
`|E_{a,b}|>0`, the following critical equalities hold simultaneously:

\[
\boxed{
\dim_H X_a=\dim_P X_a=\underline{\dim}_B X_a=
\overline{\dim}_B X_a=\frac13,
}
\tag{0.5}
\]

\[
\boxed{
\dim_H Y_b=\dim_P Y_b=\underline{\dim}_B Y_b=
\overline{\dim}_B Y_b=\frac13,
}
\tag{0.6}
\]

and

\[
\boxed{
\dim_H S_{a,b}=\dim_P S_{a,b}=\underline{\dim}_B S_{a,b}=
\overline{\dim}_B S_{a,b}=\frac23.
}
\tag{0.7}
\]

Moreover

\[
\boxed{
\mathcal H^{2/3}_\infty(S_{a,b})
\ge \frac{|H(S_{a,b})|}{L_H}>0,
}
\tag{0.8}
\]

where `L_H` is a `2/3`-Hölder constant for `H`.

Thus the terminal branch is not merely rough.  It is a **double equality case**:

\[
\boxed{
\frac13+\frac13
\xrightarrow{\;X+Y\;}
\frac23
\xrightarrow{\;H\;}
1,
}
\tag{0.9}
\]

with no dimension loss in the sumset step and exact saturation of the Hölder
dimension bound in the final step.

Finally, v167 returns to the information discarded when v163 replaced the true
phase-by-phase cores by one accumulated carrier.  The closure of the true
persistence incidence relation is **exactly the graph of the phase profile over
the accumulated carrier**.  Consequently, at a density-point tangent where the
carrier fills an interval, the entire tangent graph is a limit of genuine
phase-indexed persistence-core incidences.  Combining this with (0.5) gives a
new finite-scale signature:

\[
\boxed{
\text{about }\rho^{-1/3}\text{ spatial persistence incidences occur inside a
phase band of width }O(\rho^{2/3})
}
\tag{0.10}
\]

along the critical diagonal sequence.

That scale-resolved incidence law is the recommended starting point for v168.

---

# 1. Why the active-depth route is not yet justified

The v162 persistence core at phase `y` is

\[
K_y
=\bigcap_{\varepsilon>0}
\overline{\bigcup_{I\in\mathcal C_y,\ |I|<\varepsilon}\overline I},
\tag{1.1}
\]

where `\mathcal C_y` consists of the excursion components at level `y`.
Membership of `x` in `K_y` records that **arbitrarily small horizontal
excursions** accumulate at `x`.  It does not record their vertical depths.

The v162 stabilization theorem is correspondingly target-locational: if the
third-phase threshold lies away from the image of the accumulation core, small
components eventually cancel.  At the critical image itself, arbitrarily tiny
components may continue to affect the threshold current even though their
horizontal widths tend to zero.

After the v164 normalization

\[
x=u_0+r\xi,\qquad
F_r(\xi)=\frac{f(u_0+r\xi)-f(u_0)}{\lambda_r},
\qquad \lambda_r\asymp r^{2/3},
\tag{1.2}
\]

an excursion of vertical depth `o(lambda_r)` disappears in the uniform limit.
Its endpoint, however, can still converge to a point of a tangent level set.
Thus the limiting critical-value surface retains the **incidence location** but
not the return amplitude.

This is not a technical nuisance.  It means that the v166 proposal

\[
|A_\tau(r)|=o(r)
\Longrightarrow
\text{the passive carrier can be deleted}
\tag{1.3}
\]

requires a new theorem relating vertical return depth to critical-image measure.
No such theorem has been established in v151-v166.

The correct object available without adding assumptions is the phase-fiber
geometry of the terminal tangent.

---

# 2. A.e. level-set upper box bound at the critical exponent

Let `F:[0,1]->R` be `2/3`-Hölder with constant `L_F`:

\[
|F(x)-F(x')|\le L_F|x-x'|^{2/3}.
\tag{2.1}
\]

For a dyadic mesh of interval length

\[
r_n=2^{-n},
\tag{2.2}
\]

let `n_F(a,r_n)` denote the number of dyadic source intervals `I` whose image
`F(I)` contains the level `a`.  Since `F(I)` is an interval,

\[
\int_{\mathbb R} n_F(a,r_n)\,da
=
\sum_I \operatorname{osc}_I F.
\tag{2.3}
\]

There are `r_n^{-1}` source intervals and each oscillation is at most
`L_F r_n^{2/3}`.  Therefore

\[
\boxed{
\int n_F(a,r_n)\,da\le L_F r_n^{-1/3}.
}
\tag{2.4}
\]

Fix `epsilon>0` and put

\[
B_n(\varepsilon)
=
\{a:n_F(a,r_n)>r_n^{-1/3-\varepsilon}\}.
\tag{2.5}
\]

Markov's inequality gives

\[
|B_n(\varepsilon)|
\le L_F r_n^{\varepsilon}.
\tag{2.6}
\]

The dyadic series is summable.  By Borel-Cantelli, for almost every `a`,

\[
n_F(a,r_n)\le r_n^{-1/3-\varepsilon}
\tag{2.7}
\]

for all sufficiently large `n`.  Since the level set `X_a=F^{-1}(a)` is
covered by those mesh intervals,

\[
\overline{\dim}_B X_a\le \frac13+\varepsilon.
\tag{2.8}
\]

Intersecting over a countable sequence `epsilon downarrow 0` proves:

## Theorem 2.1 — typical critical level upper bound

For Lebesgue almost every level `a`,

\[
\boxed{
\overline{\dim}_B F^{-1}(a)\le\frac13.
}
\tag{2.9}
\]

The same statement holds for `G`.

This is elementary and does not require genericity, self-similarity, bounded
variation, or a coarea theorem.

---

# 3. Exact fiber formula for the tangent surface

Let

\[
E=T([0,1]^2)
\tag{3.1}
\]

for the terminal map (0.1).  For target first coordinates `(a,b)`, the vertical
section is

\[
E_{a,b}
=
\{c:(a,b,c)\in E\}.
\tag{3.2}
\]

If `X_a=F^{-1}(a)` and `Y_b=G^{-1}(b)`, then directly from the definition of
`T`,

\[
\boxed{
E_{a,b}=H(X_a+Y_b)-a.
}
\tag{3.3}
\]

Since `E` is compact, Fubini gives

\[
V=\mathcal L^3(E)
=
\iint |E_{a,b}|\,da\,db.
\tag{3.4}
\]

Therefore the set

\[
P=\{(a,b):|H(X_a+Y_b)|>0\}
\tag{3.5}
\]

has positive two-dimensional Lebesgue measure.

Let `A_F` and `A_G` be the full-measure sets of levels supplied by Theorem 2.1.
Then

\[
P_*=P\cap(A_F\times A_G)
\tag{3.6}
\]

still has positive measure.

All statements below are for `(a,b) in P_*`.

---

# 4. Positive critical Hausdorff content of the fiber sumset

Fix `(a,b) in P_*` and write

\[
X=X_a,\qquad Y=Y_b,\qquad S=X+Y,
\qquad \ell=|H(S)|>0.
\tag{4.1}
\]

Assume

\[
|H(t)-H(t')|\le L_H|t-t'|^{2/3}.
\tag{4.2}
\]

Take any interval cover `S subset union U_i`.  Then `H(S)` is covered by the
sets `H(S cap U_i)`, each of diameter at most

\[
L_H|U_i|^{2/3}.
\tag{4.3}
\]

Since any cover of a positive-Lebesgue-measure subset of the line has total
one-dimensional diameter at least its outer measure,

\[
\ell
\le
L_H\sum_i |U_i|^{2/3}.
\tag{4.4}
\]

Taking the infimum over covers gives:

## Theorem 4.1 — sumset critical content

\[
\boxed{
\mathcal H^{2/3}_\infty(X_a+Y_b)
\ge \frac{|H(X_a+Y_b)|}{L_H}>0.
}
\tag{4.5}
\]

In particular,

\[
\boxed{
\dim_H(X_a+Y_b)\ge\frac23.
}
\tag{4.6}
\]

Thus the last map `H` does not merely increase a box-counting exponent.  It
maps a set with genuine positive critical Hausdorff content to positive
Lebesgue measure.

---

# 5. Critical dimension equality for the two side fibers

The addition map

\[
A:X\times Y\to\mathbb R,
\qquad A(x,y)=x+y,
\tag{5.1}
\]

is Lipschitz, so

\[
\dim_H(X+Y)\le\dim_H(X\times Y).
\tag{5.2}
\]

We use the standard product inequality for Borel subsets of Euclidean space,

\[
\dim_H(X\times Y)
\le
\dim_HX+\dim_PY,
\tag{5.3}
\]

and the symmetric version with `X,Y` interchanged.  Also

\[
\dim_PY\le\overline{\dim}_B Y,
\qquad
\dim_HX\le\overline{\dim}_B X.
\tag{5.4}
\]

By Theorem 2.1,

\[
\overline{\dim}_B X,\overline{\dim}_B Y\le\frac13.
\tag{5.5}
\]

Combining (4.6)-(5.5),

\[
\frac23
\le
\dim_H(X+Y)
\le
\dim_H(X\times Y)
\le
\dim_HX+\dim_PY
\le
\frac23.
\tag{5.6}
\]

Every inequality is therefore an equality.  Applying the symmetric product
bound gives:

## Theorem 5.1 — Hausdorff/packing fiber saturation

For every `(a,b) in P_*`,

\[
\boxed{
\dim_HX_a=\dim_PX_a=\frac13,
\qquad
\dim_HY_b=\dim_PY_b=\frac13,
}
\tag{5.7}
\]

and

\[
\boxed{
\dim_H(X_a\times Y_b)
=\dim_H(X_a+Y_b)
=\frac23.
}
\tag{5.8}
\]

Thus the addition map loses no Hausdorff dimension on the relevant fiber
products.

This is stronger than the v165 mesh lower bound: the `1/3` fiber exponent is
now a genuine Hausdorff and packing dimension statement on a positive-measure
set of contributing phase pairs.

---

# 6. Exact lower and upper box dimensions

The positive vertical fiber also gives a scale-by-scale product inequality.
Let `N_X(r),N_Y(r)` be the minimum numbers of intervals of length `r` covering
`X,Y`.  Their pairwise sums cover `S=X+Y` with at most

\[
N_X(r)N_Y(r)
\tag{6.1}
\]

intervals of length `2r`.  Each such interval has `H`-image diameter at most

\[
L_H(2r)^{2/3}.
\tag{6.2}
\]

Since `|H(S)|=ell`,

\[
\boxed{
N_X(r)N_Y(r)
\ge
\frac{\ell}{L_H(2r)^{2/3}}.
}
\tag{6.3}
\]

For `(a,b) in P_*`, Theorem 2.1 gives, for every `epsilon>0`,

\[
N_Y(r)\le r^{-1/3-\varepsilon}
\tag{6.4}
\]

at all sufficiently small dyadic scales, up to an inessential multiplicative
constant.  Therefore

\[
N_X(r)\ge c_{a,b}\,r^{-1/3+\varepsilon}.
\tag{6.5}
\]

Letting `epsilon downarrow0` gives

\[
\underline{\dim}_B X\ge\frac13.
\tag{6.6}
\]

Together with the typical upper bound,

\[
\boxed{
\underline{\dim}_B X
=\overline{\dim}_B X
=\frac13.
}
\tag{6.7}
\]

The same argument applies to `Y`.

For the sumset itself, any length-`r` cover of `S` gives

\[
N_S(r)\ge \frac{\ell}{L_H r^{2/3}},
\tag{6.8}
\]

while

\[
\overline{\dim}_B S
\le
\overline{\dim}_B X+\overline{\dim}_B Y
\le\frac23.
\tag{6.9}
\]

Hence:

## Theorem 6.1 — exact box dimensions

For every `(a,b) in P_*`,

\[
\boxed{
\dim_B X_a=\dim_B Y_b=\frac13,
\qquad
\dim_B(X_a+Y_b)=\frac23,
}
\tag{6.10}
\]

where the lower and upper box dimensions agree.

Combining with Theorem 5.1 gives the full equalities (0.5)-(0.7).

---

# 7. The no-loss dimension cascade

The terminal positive-volume tangent therefore forces the following chain for
positive-measure many phase pairs:

\[
\boxed{
\begin{array}{ccccc}
X_a &\times& Y_b &\xrightarrow{\ x+y\ }& X_a+Y_b
\\[1mm]
\frac13 && \frac13 && \frac23
\\[1mm]
&&&& \downarrow H
\\[-1mm]
&&&& \text{positive Lebesgue measure }(\dim=1).
\end{array}}
\tag{7.1}
\]

There is no dimension loss in either of the two critical steps:

1. the product achieves dimension `1/3+1/3=2/3`;
2. addition preserves that `2/3` dimension;
3. the `2/3`-Hölder map `H` achieves the maximal possible image dimension
   `1` and in fact positive one-dimensional measure.

This is a much narrower object than an arbitrary rough profile.

At the same time it is not, by itself, contradictory.  The exponent `2/3` is
the sharp general threshold at which maps from a square to a cube can be
space-filling.  Therefore any closure from this point must use the **special
sum-coupled structure and persistence incidence**, not a generic Hölder-volume
argument.

---

# 8. Consequence for the side graphs

Let

\[
\Gamma_F=\{(x,F(x)):0\le x\le1\}.
\tag{8.1}
\]

A `2/3`-Hölder graph satisfies the standard upper dimension bound

\[
\dim_H\Gamma_F\le\frac43.
\tag{8.2}
\]

By Fubini applied to `P_*`, there is a positive-measure set of `a` for which
`X_a` occurs in at least one contributing pair.  Theorem 5.1 gives

\[
\dim_HX_a=\frac13
\tag{8.3}
\]

on that positive-measure set.  The standard slicing lower bound then gives

\[
\dim_H\Gamma_F\ge1+\frac13=\frac43.
\tag{8.4}
\]

Hence

\[
\boxed{\dim_H\Gamma_F=\frac43.}
\tag{8.5}
\]

The same holds for `G`.  Since packing dimension is bounded below by Hausdorff
dimension and above by upper box dimension, the v165 upper graph estimate yields

\[
\boxed{
\dim_H\Gamma_F=\dim_P\Gamma_F=\overline{\dim}_B\Gamma_F=\frac43,
}
\tag{8.6}
\]

and similarly for `G` in the full fixed-point branch.

Thus the terminal tangent saturates the critical dimensions at the graph,
level-set, sumset, and target-volume layers simultaneously.

---

# 9. Restoring the phase-indexed persistence incidence

The global carrier used in v163 was

\[
\mathcal K
=
\overline{\bigcup_{y\in A}(K_y\cap J)}.
\tag{9.1}
\]

Define the true persistence incidence relation

\[
\mathscr I
=
\{(u,y):y\in A,\ u\in K_y\cap J\}.
\tag{9.2}
\]

Because `K_y subset f^{-1}(y)`, every incidence point satisfies

\[
y=f(u).
\tag{9.3}
\]

Conversely, if `u in mathcal K`, there are

\[
u_n\in K_{y_n}\cap J,
\qquad u_n\to u.
\tag{9.4}
\]

Continuity gives

\[
y_n=f(u_n)\to f(u).
\tag{9.5}
\]

Therefore:

## Theorem 9.1 — exact incidence closure

\[
\boxed{
\overline{\mathscr I}
=
\{(u,f(u)):u\in\mathcal K\}.
}
\tag{9.6}
\]

The accumulated carrier loses the exact phase label only before closure; after
the phase coordinate is restored, its closure is precisely the graph of `f`
over `mathcal K`.

This is the right way to carry persistence information into the tangent without
inventing a vertical return-depth bound.

---

# 10. Density-point tangent of the incidence graph

Take a v166 density-point witness scale

\[
u=u_n+r_nx,
\qquad
\lambda_n\asymp r_n^{2/3},
\tag{10.1}
\]

and define

\[
F_n(x)=\frac{f(u_n+r_nx)-f(u_n)}{\lambda_n}.
\tag{10.2}
\]

Let

\[
K_n=\frac{\mathcal K-u_n}{r_n}\cap[0,1].
\tag{10.3}
\]

At a density-point tangent,

\[
K_n\to[0,1]
\tag{10.4}
\]

in Hausdorff distance, while along the compact branch

\[
F_n\to F
\tag{10.5}
\]

uniformly.

The normalized closure of the incidence relation is exactly

\[
\Gamma_n
=
\{(x,F_n(x)):x\in K_n\}.
\tag{10.6}
\]

Uniform convergence plus Hausdorff convergence of `K_n` gives

\[
\boxed{
\Gamma_n\to\Gamma_F
}
\tag{10.7}
\]

in Hausdorff distance.

Hence **every point of the tangent graph is a limit of genuine
phase-indexed persistence-core incidences.**

This is stronger than the statement that the spatial carrier alone tends to an
interval.

---

# 11. Critical near-level persistence multiplicity

Fix one contributing tangent level `a` for which

\[
\dim_B X_a=\frac13.
\tag{11.1}
\]

Let `rho>0` be a fine tangent mesh.  Suppose `X_a` meets

\[
M_a(\rho)
\tag{11.2}
\]

rho-mesh intervals.  From Theorem 6.1,

\[
M_a(\rho)=\rho^{-1/3+o(1)}
\tag{11.3}
\]

along the exact critical scales.

By (10.7), for every fixed `rho` and every `eta>0`, all sufficiently large `n`
have the following property: every rho-mesh interval meeting `X_a` contains,
up to an arbitrarily small enlargement, a normalized persistence-core incidence
`(x_n,a_n)` satisfying

\[
|a_n-a|<\eta.
\tag{11.4}
\]

Choosing a diagonal sequence with

\[
\eta\asymp\rho^{2/3}
\tag{11.5}
\]

gives the critical finite-scale law:

## Theorem 11.1 — near-level persistence multiplicity

Along a suitable diagonal subsequence of prelimit witness scales, a contributing
critical level produces

\[
\boxed{
\rho^{-1/3+o(1)}
}
\tag{11.6}
\]

spatially separated persistence-core incidences inside a normalized phase band
of width

\[
\boxed{O(\rho^{2/3}).}
\tag{11.7}
\]

In original variables the phase-band width is

\[
O(\lambda_n\rho^{2/3}).
\tag{11.8}
\]

The exponents again match the fixed-point balance:

\[
\boxed{
\text{spatial fiber entropy }\frac13
\quad\leftrightarrow\quad
\text{phase scaling }\frac23.
}
\tag{11.9}
\]

This statement uses actual persistence-core incidences, not merely arbitrary
level-set points.

---

# 12. What v167 does and does not close

## Closed / strengthened

1. The proposed active-return-depth removal is identified as an unsupported
   step; no theorem in the stack currently retains that amplitude information.
2. Almost every level of any `2/3`-Hölder side patch has upper box dimension at
   most `1/3`.
3. Positive-volume tangent fibers force exact `1/3` Hausdorff, packing, lower
   box, and upper box dimensions on both contributing side levels.
4. Their sumsets have exact dimension `2/3` in all those senses and positive
   `2/3` Hausdorff content.
5. The addition map and the final `H` map both saturate their critical dimension
   bounds.
6. The side graphs have exact Hausdorff dimension `4/3` in the full fixed-point
   branch.
7. The true persistence incidence closure survives the density tangent as the
   full graph of `F`.
8. Relevant tangent levels therefore correspond to roughly `rho^{-1/3}` actual
   near-phase persistence incidences in a phase band of width `rho^{2/3}`.

## Still open

1. Near-phase persistence multiplicity has not yet been promoted to an
   **exact-level** persistence core of positive `1/3` Hausdorff measure.
2. The vertical depths of the corresponding return arches may still be
   subcritical and disappear under the tangent normalization.
3. The special additive equality
   `X_a + Y_b -> H(X_a+Y_b)` has not been classified.
4. The unbounded-pressure super-`2/3` spike branch remains open.
5. Lower-dimensional pressure branches remain open.
6. The final Jordan/shrinking-window transfer is inherited rather than re-proved.

---

# 13. Recommended v168 targets

The best next object is the **parabolically scaled persistence incidence
measure**, not raw return depth.

For a critical tangent level `a`, record core incidences in boxes

\[
[x,x+\rho]\times[a-c\rho^{2/3},a+c\rho^{2/3}].
\tag{13.1}
\]

The v167 law says that a relevant level needs about `rho^{-1/3}` occupied
spatial boxes.  There are two realistic next routes.

### Route A — phase compression

Prove that if `rho^{-1/3}` persistence incidences lie in a phase band of width
`rho^{2/3}` at all small scales, then some exact phase `a_*` carries a
persistence core with positive `1/3` Hausdorff content.

That would finally reconnect the terminal tangent fiber to the exact v162
object `K_{a_*}`.

### Route B — additive equality rigidity

Take the no-loss cascade

\[
X_a\times Y_b
\to X_a+Y_b
\to H(X_a+Y_b)
\tag{13.2}
\]

and classify equality at every step.  The survivor must simultaneously have

* exact `1/3` side fibers;
* exact `2/3` sumsets with positive critical Hausdorff content;
* no dimension loss under addition;
* positive-length image under a `2/3`-Hölder `H`.

This is now an extremal additive-fractal problem rather than an undifferentiated
roughness problem.

The current recommendation is **Route A first**, because it returns to the
specific persistence structure inherited from the square map and avoids trying
to classify all critical Hölder space-filling surfaces.

---

# 14. Bottom line

The active-depth proposal from v166 cannot be justified from the limiting
critical image alone.  The correct invariant that actually survives the
renormalization is the **phase-indexed persistence incidence**.

At the full `2/3` fixed point, positive target volume forces the terminal tangent
into a complete dimension-saturation cascade:

\[
\boxed{
\begin{array}{c}
\text{side level fibers: }1/3,\ 1/3,\\
\text{fiber sumset: }2/3,\\
\text{side graphs: }4/3,\\
\text{target: positive }3\text{-volume},
\end{array}}
\tag{14.1}
\]

with the first three statements valid in genuine Hausdorff/packing terms, not
only upper-box entropy.

And because the accumulated persistence incidence graph converges to the whole
tangent graph, those critical `1/3` fibers are populated, at the prelimit, by
actual persistence-core incidences at the natural anisotropic scaling

\[
\boxed{\rho\text{ horizontally}\quad\leftrightarrow\quad\rho^{2/3}
\text{ in phase}.}
\tag{14.2}
\]

That is the new frontier.
