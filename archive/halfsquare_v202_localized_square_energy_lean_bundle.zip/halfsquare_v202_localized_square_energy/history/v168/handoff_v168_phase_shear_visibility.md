# Project Handoff v168: Phase-Shear Counterexample and Lattice-Visibility Scale

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.

v167 proposed a phase-compression theorem: from roughly `rho^(-1/3)` genuine
persistence incidences lying in a phase band of width `O(rho^(2/3))`, try to
force one exact phase `y` whose persistence core `K_y` has positive
`1/3`-dimensional content.

v168 shows that this implication is false, even at exactly the critical
`1/3`--`2/3` exponents and even when the points are genuine
vanishing-persistence core points.

The counterexample is elementary. Let `C` be the base-eight two-corner Cantor
set

\[
C=\left\{\sum_{k\ge1}7\xi_k8^{-k}:\xi_k\in\{0,1\}\right\},
\qquad \dim_H C=\frac13,
\tag{0.1}
\]

and define on `[0,1]`

\[
F(x)=-\operatorname{dist}(x,C)^{2/3},
\qquad
f_\varepsilon(x)=F(x)+\varepsilon x.
\tag{0.2}
\]

Then `f_epsilon -> F` uniformly, all functions have a uniform `2/3`-Holder
bound, and

\[
F^{-1}(0)=C.
\tag{0.3}
\]

Nevertheless, for a full-`1/3`-dimensional subset `C^+ subset C`, every point
`c in C^+` is a genuine vanishing-persistence point at the **distinct exact
phase**

\[
y=\varepsilon c,
\tag{0.4}
\]

and in fact

\[
\boxed{K_{\varepsilon c}(f_\varepsilon)=\{c\}.}
\tag{0.5}
\]

Thus an entire critical Cantor level can be split into singleton exact-phase
cores by an arbitrarily small phase shear. Taking

\[
\rho_n=8^{-n},\qquad \varepsilon_n=\rho_n,
\tag{0.6}
\]

gives

\[
N_{\rho_n}(C^+)\asymp \rho_n^{-1/3},
\tag{0.7}
\]

while all the exact persistence phases lie in a band of width

\[
\varepsilon_n=o(\rho_n^{2/3}).
\tag{0.8}
\]

No exact phase carries more than one point.

So v167's near-level incidence law does **not** compress to one exact phase.
The information can hide on a strictly smaller vertical scale.

The positive replacement is a new scale variable. If the current critical
profile is normalized by an absolute phase scale `S_n -> infinity`, and a
critical incidence cloud splits across normalized phase width `sigma_n`, then

\[
\boxed{\Xi_n=S_n\sigma_n}
\tag{0.9}
\]

is the number of raw phase-lattice units across the hidden shear, up to the
fixed lattice normalization constant. This gives the correct next trichotomy:

\[
\boxed{
\Xi_n\to0,
\qquad
\Xi_n\asymp1,
\qquad
\Xi_n\to\infty.
}
\tag{0.10}
\]

* `Xi_n -> 0`: exact phase splitting is sub-lattice and should be removable by
  a finite-resolution degree theorem, not by exact phase compression.
* `Xi_n = O(1)`: the obstruction occupies only finitely many phase slabs and
  becomes a bounded combinatorial/current problem.
* `Xi_n -> infinity`: the shear is itself phase-visible and should be
  renormalized as a new secondary profile.

The recommended v169 target is therefore a **finite-slab / visible-shear
alternative** tied to the actual lattice mesh. This is stronger and more
faithful to the square-forcing mechanism than an exact-level theorem, which
v168 disproves.

---

# 1. The critical Cantor set

Let

\[
\phi_0(x)=\frac{x}{8},
\qquad
\phi_1(x)=\frac78+\frac{x}{8}.
\tag{1.1}
\]

The invariant set `C=phi_0(C) union phi_1(C)` is the set in (0.1). The open-set
condition is immediate, so

\[
2\cdot 8^{-s}=1
\tag{1.2}
\]

at its Hausdorff dimension. Hence

\[
\boxed{s=\frac{\log2}{\log8}=\frac13.}
\tag{1.3}
\]

Moreover

\[
0<\mathcal H^{1/3}(C)<\infty.
\tag{1.4}
\]

At generation `n`, `C` has `2^n` cylinder intervals of length `8^{-n}`, with
large gaps between distinct cylinders. Thus

\[
N_{8^{-n}}(C)\asymp 2^n=(8^{-n})^{-1/3}.
\tag{1.5}
\]

Define `C^+` to consist of points whose symbolic address contains infinitely
many zero symbols. The complement consists of addresses that are eventually
all ones, hence is countable. Therefore

\[
\boxed{
\mathcal H^{1/3}(C^+)=\mathcal H^{1/3}(C)>0,
\qquad
\dim_H C^+=\frac13.
}
\tag{1.6}
\]

The purpose of the `C^+` restriction is only to guarantee infinitely many
small construction gaps lying immediately to the **right** of the point. That
matches the one-sided excursion convention `t>g(y)` used in v162.

---

# 2. Uniform critical Holder regularity

Put

\[
d_C(x)=\operatorname{dist}(x,C),
\qquad
F(x)=-d_C(x)^{2/3}.
\tag{2.1}
\]

The distance function is 1-Lipschitz. For `0<alpha<=1`,

\[
|u^\alpha-v^\alpha|\le |u-v|^\alpha
\qquad (u,v\ge0).
\tag{2.2}
\]

Therefore

\[
|F(x)-F(x')|
\le |x-x'|^{2/3}.
\tag{2.3}
\]

For `0<epsilon<=1`, define

\[
f_\varepsilon(x)=\varepsilon x-d_C(x)^{2/3}.
\tag{2.4}
\]

Since `|x-x'| <= |x-x'|^(2/3)` on `[0,1]`,

\[
\boxed{
|f_\varepsilon(x)-f_\varepsilon(x')|
\le (1+\varepsilon)|x-x'|^{2/3}
\le2|x-x'|^{2/3}.
}
\tag{2.5}
\]

Also

\[
\|f_\varepsilon-F\|_\infty\le\varepsilon.
\tag{2.6}
\]

Thus the family lives exactly in the critical Holder class and converges
uniformly to a profile whose zero level is the whole `1/3`-Cantor set.

---

# 3. Every `c in C^+` is a genuine persistence-core point

Fix `c in C^+` and set

\[
y=\varepsilon c.
\tag{3.1}
\]

Because `c in C`,

\[
f_\varepsilon(c)=\varepsilon c=y.
\tag{3.2}
\]

At every symbolic generation at which the address of `c` chooses the left
child, let `P=[p,p+L]` be the parent construction interval. Then

* `c` belongs to `[p,p+L/8]`;
* the central construction gap to its right is

\[
G=(a,b)=\left(p+\frac L8,\ p+\frac{7L}8\right);
\tag{3.3}
\]

* its midpoint is `m=p+L/2`;
* `d_C(m)=3L/8`;
* `0<a-c<=L/8` except for the eventually-right endpoint addresses already
  removed from `C^+`.

At the gap endpoints,

\[
f_\varepsilon(a)=\varepsilon a>\varepsilon c=y,
\qquad
f_\varepsilon(b)=\varepsilon b>y.
\tag{3.4}
\]

At the midpoint,

\[
\begin{aligned}
f_\varepsilon(m)-y
&=\varepsilon(m-c)-\left(\frac{3L}{8}\right)^{2/3}\\
&\le \frac{\varepsilon L}{2}
-\left(\frac38\right)^{2/3}L^{2/3}.
\end{aligned}
\tag{3.5}
\]

Because `L^(2/3) >> L` as `L -> 0`, the right side is negative for every
sufficiently small selected construction gap. Hence the open sublevel set

\[
\{x\in G:f_\varepsilon(x)<y\}
\tag{3.6}
\]

contains a nonempty interval component `I_L` around `m`. Its endpoints are
level-`y` roots, and

\[
|I_L|\le |G|=\frac{3L}{4}\to0,
\qquad
\operatorname{dist}(I_L,c)\le L\to0.
\tag{3.7}
\]

Since `g(y)<=c` and `G` lies to the right of `c`, these are legitimate
components of the one-sided excursion slice `U_y={t>g(y):f(t)<y}` from v162.
Therefore arbitrarily small excursion components accumulate at `c`, proving

\[
\boxed{c\in K_y(f_\varepsilon).}
\tag{3.8}
\]

---

# 4. The exact core is a singleton

It remains to show that the same exact phase cannot collect other persistence
points.

First, on the Cantor set,

\[
f_\varepsilon(x)=\varepsilon x
\qquad (x\in C),
\tag{4.1}
\]

so `f_epsilon|_C` is strictly increasing. Thus

\[
C\cap f_\varepsilon^{-1}(\varepsilon c)=\{c\}.
\tag{4.2}
\]

Second, no point in a complementary gap can belong to any vanishing-persistence
core. Let `(a,b)` be one fixed complementary interval. On its left half,

\[
f_\varepsilon(x)=\varepsilon x-(x-a)^{2/3},
\tag{4.3}
\]

whose derivative, wherever defined, is

\[
\varepsilon-\frac23(x-a)^{-1/3},
\tag{4.4}
\]

and can change sign at most once. On the right half,

\[
f_\varepsilon(x)=\varepsilon x-(b-x)^{2/3}
\tag{4.5}
\]

has strictly positive derivative

\[
\varepsilon+\frac23(b-x)^{-1/3}>0.
\tag{4.6}
\]

Hence each fixed gap contains only one valley. For any fixed level, its sublevel
set inside that gap has at most one interval component. There is therefore no
sequence of distinct excursion components with widths tending to zero and
accumulating at an interior point of the gap.

Consequently

\[
K_y(f_\varepsilon)\subset C
\tag{4.7}
\]

for every `y`. Combining (3.8), (4.2), and (4.7) gives:

## Theorem 4.1 — exact phase-shear persistence model

For every `c in C^+`,

\[
\boxed{
K_{\varepsilon c}(f_\varepsilon)=\{c\}.
}
\tag{4.8}
\]

Yet as `epsilon -> 0`, these singleton incidences converge to the entire
critical level

\[
C\times\{0\}\subset\operatorname{graph}(F).
\tag{4.9}
\]

This exactly exhibits the information loss identified abstractly in v167.

---

# 5. Failure of phase compression at the critical scales

Take

\[
\rho_n=8^{-n},
\qquad
\varepsilon_n=\rho_n.
\tag{5.1}
\]

At horizontal resolution `rho_n`, the set `C^+` requires

\[
N_{\rho_n}(C^+)\asymp 2^n=\rho_n^{-1/3}
\tag{5.2}
\]

source intervals.

For each such persistence point `c`, the exact phase is

\[
y_c=\varepsilon_n c\in[0,\varepsilon_n].
\tag{5.3}
\]

Hence all the exact phases lie inside a band of width

\[
\sigma_n=\varepsilon_n=\rho_n.
\tag{5.4}
\]

But the v167 parabolic phase scale is `rho_n^(2/3)`, and

\[
\boxed{
\frac{\sigma_n}{\rho_n^{2/3}}
=\rho_n^{1/3}\to0.
}
\tag{5.5}
\]

Therefore the family has the stronger property

\[
\boxed{
\rho_n^{-1/3}\text{ genuine persistence incidences in an }
 o(\rho_n^{2/3})\text{ phase band},
}
\tag{5.6}
\]

while

\[
\boxed{
\sup_y N_{\rho_n}(K_y)=1
}
\tag{5.7}
\]

on the sheared Cantor family.

This disproves the proposed v167 -> v168 exact phase-compression implication.

The example is **not** a counterexample to the square-peg conjecture and is not
claimed to satisfy the entire inherited square-map setup. Its role is narrower
and rigorous: it shows that the local persistence information retained by
v162-v167 is insufficient to prove exact phase compression.

---

# 6. The hidden secondary phase tangent

The information has not vanished; it has moved to a lower vertical scale.

On `C`,

\[
F(c)=0,
\qquad
f_\varepsilon(c)=\varepsilon c.
\tag{6.1}
\]

At the parent `2/3` scale, the normalized shear disappears whenever
`epsilon=o(rho^(2/3))`. But at the secondary vertical scale `epsilon`,

\[
\boxed{
\frac{f_\varepsilon(c)-F(c)}{\varepsilon}=c.
}
\tag{6.2}
\]

So the thick tangent level is resolved into an injective phase law when one
zooms farther vertically.

The scale `epsilon` can be prescribed arbitrarily. More generally, replacing
`epsilon` by any positive sequence `epsilon_n -> 0` yields the same parent
limit `F` but puts the exact phase splitting at whatever subcritical scale was
chosen.

Hence there is no scale-free theorem of the form

\[
\text{thick tangent level}
\Longrightarrow
\text{thick exact prelimit phase fiber}.
\tag{6.3}
\]

A successful argument must know whether the hidden secondary scale is visible
to the phase lattice.

---

# 7. Lattice-visibility number

Return to the square-forcing sequence. Suppose the current normalized critical
profile is multiplied by an absolute phase scale

\[
S_n\to\infty.
\tag{7.1}
\]

Thus one unit in the normalized profile corresponds to `S_n` raw phase units.
The inherited phase lattice then has normalized mesh comparable to

\[
h_n\asymp S_n^{-1}.
\tag{7.2}
\]

Let `sigma_n` be the normalized width of a hidden phase-shear cloud that is
being collapsed into one tangent level. Define

\[
\boxed{
\Xi_n=S_n\sigma_n=\frac{\sigma_n}{h_n}
}
\tag{7.3}
\]

up to the fixed lattice normalization constant.

This quantity measures how many phase-lattice spacings the hidden shear spans.
Indeed an interval of normalized width `sigma_n` meets at most

\[
\boxed{
\lceil \Xi_n\rceil+2
}
\tag{7.4}
\]

lattice slabs.

This gives a natural three-regime split.

### Regime A: sub-lattice shear

\[
\Xi_n\to0.
\tag{7.5}
\]

The exact phases are distinct topologically, but the separation is smaller
than one lattice mesh. Exact compression is the wrong demand. What is needed is
stability of the finite-dimensional degree calculation under replacing an
exact persistence phase by a phase tube narrower than one lattice cell.

### Regime B: bounded visible shear

\[
0<\limsup\Xi_n<\infty.
\tag{7.6}
\]

Only finitely many lattice slabs are involved. The infinite exact-phase
problem has reduced to a bounded combinatorial/current problem. This is the
closest analogue of the bounded-mass packet left by earlier versions.

### Regime C: phase-visible shear

\[
\Xi_n\to\infty.
\tag{7.7}
\]

The hidden phase splitting itself carries an unbounded number of lattice
levels. It should be promoted to a new normalized profile by dividing by
`sigma_n`, exactly as (6.2) exposes the identity shear in the Cantor model.

The point of (7.3) is that it distinguishes phase splitting that is
mathematically real but lattice-invisible from phase splitting that can support
a new phase-cell argument.

---

# 8. What v168 changes in the obstruction ledger

The v167 proposed route was

\[
\rho^{-1/3}\text{ near-level incidences}
\Longrightarrow
\text{one thick exact }K_y.
\tag{8.1}
\]

v168 disproves (8.1).

The corrected route is

\[
\boxed{
\text{near-level incidence cloud}
\Longrightarrow
\text{measure its hidden phase width }\sigma_n
\Longrightarrow
\text{compare }S_n\sigma_n\text{ with the lattice scale}.
}
\tag{8.2}
\]

This is not merely a change of notation. The Cantor model shows that
`sigma_n/rho_n^(2/3)` may tend to zero at an arbitrary rate while every exact
phase fiber remains a singleton.

Therefore any continuation that ignores `S_n sigma_n` can again lose exactly
the phase information needed for the final lattice capture.

---

# 9. Recommended v169 target

The strongest next target is a **finite-slab / visible-shear alternative**.

## Target A — sub-lattice tube stability

Prove that if the vanishing-persistence obstruction over a protected target
cell is contained in a normalized phase tube of width

\[
o(S_n^{-1}),
\tag{9.1}
\]

then replacing exact cores by that tube does not change the Brouwer/lattice
capture conclusion. In other words, phase splitting below one lattice mesh
should be irrelevant to existence of a lattice target inside a protected phase
cell.

This is the correct replacement for exact phase compression.

## Target B — bounded-slab classification

If

\[
S_n\sigma_n=O(1),
\tag{9.2}
\]

reduce the obstruction to finitely many adjacent phase slabs and classify the
possible signed persistence currents across those slabs. The v159 finite-cycle
orientation theorem should become relevant again here.

## Target C — visible-shear renormalization

If

\[
S_n\sigma_n\to\infty,
\tag{9.3}
\]

normalize by `sigma_n` and extract a secondary shear tangent. Determine whether
its nonconstancy supplies the missing degree direction directly, or whether it
creates a new exceptional family.

The three targets together are exhaustive once `sigma_n` is defined by a
specific critical incidence cloud.

---

# 10. Current obstruction ledger after v168

Closed or substantially reduced:

* fixed-order polynomial exceptional towers — resummed by v152;
* moving-log drift — controlled by v153;
* compact nonquadratic residuals — v154;
* monotone compact critical limits — v156-v157;
* finite regular multivalued folding — v158-v160;
* tiny-jump channel deserts — v161;
* infinite persistence currents away from the critical image — v162;
* regular/thin critical-image carriers — v163-v166;
* critical tangent dimension budget — v165-v167;
* **exact phase compression from near-level persistence multiplicity — now
  disproved by v168.**

Remaining:

1. the lattice-visibility trichotomy for hidden phase shear;
2. the bounded-slab signed-current branch;
3. secondary visible-shear tangents;
4. the unbounded-pressure super-`2/3` branch;
5. lower-dimensional pressure branches;
6. the inherited final Jordan/shrinking-window transfer.

The immediate recommendation is item 1, because it repairs an actual logical
information loss rather than adding another dimension estimate to the terminal
tangent.
