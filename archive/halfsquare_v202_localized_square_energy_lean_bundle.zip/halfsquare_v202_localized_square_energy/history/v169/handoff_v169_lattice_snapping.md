# Project Handoff v169: Lattice Snapping and Bounded-Shear Collapse

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.

v168 showed that exact phase compression is false: a critical `1/3`-dimensional
persistence cloud can split into distinct exact phases on a vertical scale much
smaller than the parent `2/3` phase scale.  The correct quantity is the width of
that hidden phase shear relative to the inherited phase-lattice mesh.

v169 turns that observation into a finite-resolution theorem.

Let

\[
h_n=\frac{\Lambda}{S_n},\qquad \Lambda=2\pi,
\tag{0.1}
\]

be the normalized phase-lattice spacing when one normalized phase unit
corresponds to `S_n` raw phase units.  Let `Y_n` be a compact set of exact phase
labels carried by a hidden persistence cloud, with

\[
\sigma_n=\operatorname{diam}Y_n.
\tag{0.2}
\]

The lattice-visibility number is more precisely

\[
\widehat\Xi_n=\frac{\sigma_n}{h_n}
=\frac{S_n\sigma_n}{\Lambda}.
\tag{0.3}
\]

The fixed factor `Lambda` is irrelevant to the trichotomy in v168, but it is
useful to keep the actual lattice spacing explicit here.

The main result is a **continuous staircase snapping theorem**.  If the phase
labels do not occupy every residue class modulo `h_n`, there is a continuous
nondecreasing map `Pi_n` satisfying

\[
\Pi_n(y+h_n)=\Pi_n(y)+h_n,
\qquad
\|\Pi_n-\mathrm{id}\|_\infty\le \frac{h_n}{2},
\tag{0.4}
\]

such that every phase in `Y_n` is sent **exactly** to one translate of the
phase lattice:

\[
\Pi_n(Y_n)\subset \tau_n+h_n\mathbb Z.
\tag{0.5}
\]

If

\[
\widetilde f_n=\Pi_n\circ f_n,
\tag{0.6}
\]

then the entire relative square-phase map moves by at most one normalized
lattice spacing:

\[
\boxed{
\|H_{\widetilde f_n}-H_{f_n}\|_\infty\le h_n.
}
\tag{0.7}
\]

Since `h_n -> 0`, every protected Brouwer-degree conclusion with a fixed
boundary margin survives this snapping.

This gives a sharp replacement for v168's qualitative finite-slab proposal.

* **Sub-lattice shear:** if `sigma_n<h_n`, the entire compact phase cloud can
  always be snapped to **one exact phase level** modulo an `o(1)` perturbation of
  the square-phase map.  Hence sub-lattice phase splitting is not a new
  topological obstruction.
* **Bounded shear:** if `sigma_n <= M h_n`, then either the whole cloud can be
  snapped into at most `M+O(1)` exact phase levels, or its residue projection is
  the full phase circle.  In the latter case

  \[
  \boxed{|Y_n|\ge h_n,}
  \tag{0.8}
  \]

  so after secondary normalization by `h_n` the phase set has positive
  Lebesgue measure and has interval tangents at its density points.
* **Visible shear:** if `sigma_n/h_n -> infinity`, then after normalization by
  `sigma_n` the secondary lattice mesh is

  \[
  \boxed{\widetilde h_n=\frac{h_n}{\sigma_n}
  =\widehat\Xi_n^{-1}\to0.}
  \tag{0.9}
  \]

  Any connected secondary phase variation is therefore automatically
  lattice-visible.  The genuinely new residual obstruction is confined to
  disconnected/fractal secondary carriers and their coupling to the other two
  phase coordinates.

The important point is that v168's phase-shear counterexample is real in exact
phase topology but does **not** survive unchanged at lattice resolution.  If
its shear width is sub-lattice, a uniformly vanishing perturbation collapses
its whole phase cloud to one exact phase while preserving the relative phase
lattice and every protected degree computation.

---

# 1. Relative phase lattice and why absolute phase translates are free

The raw relative phase map used throughout the late-stage program is

\[
H_f(a,b,v)
=
\begin{pmatrix}
 f(u_1)-f(u_0)\\
 f(u_2)-f(u_0)\\
 f(u_3)-f(u_0)
\end{pmatrix}.
\tag{1.1}
\]

At the normalized scale considered in v168, the target lattice is

\[
h\mathbb Z^3,
\qquad h=\Lambda/S.
\tag{1.2}
\]

Only **differences** of phase values occur.  Therefore the four individual
phase values may lie in any common translate

\[
\tau+h\mathbb Z
\tag{1.3}
\]

without changing the relative lattice:

\[
(\tau+kh)-(\tau+\ell h)=(k-\ell)h\in h\mathbb Z.
\tag{1.4}
\]

This harmless translation freedom is what makes continuous snapping possible.
We do not need to force individual phase values to lie in the particular
absolute lattice `h Z`; any common translate gives the same relative target
lattice.

---

# 2. The staircase map

Fix `h>0`, a transition-center residue `c modulo h`, and

\[
0<\delta<h/2.
\tag{2.1}
\]

For each integer `k`, put

\[
m_k=c+kh.
\tag{2.2}
\]

Define the continuous staircase `Pi=Pi_{h,c,delta}` as follows.

On the transition interval

\[
[m_k-\delta,m_k+\delta],
\tag{2.3}
\]

let `Pi` be the affine map from

\[
c+(k-\tfrac12)h
\quad\text{to}\quad
c+(k+\tfrac12)h.
\tag{2.4}
\]

Thus explicitly

\[
\Pi(y)
=
c+(k-\tfrac12)h
+\frac{h}{2\delta}(y-m_k+\delta)
\tag{2.5}
\]

for `y in [m_k-delta,m_k+delta]`.

On the plateau interval

\[
[m_k+\delta,m_{k+1}-\delta],
\tag{2.6}
\]

put

\[
\Pi(y)=c+(k+\tfrac12)h.
\tag{2.7}
\]

The plateau values form the translated lattice

\[
\tau+h\mathbb Z,
\qquad
\tau=c+h/2.
\tag{2.8}
\]

The construction is continuous at every endpoint, nondecreasing, and satisfies

\[
\boxed{\Pi(y+h)=\Pi(y)+h.}
\tag{2.9}
\]

## Lemma 2.1 — uniform snapping error

For every `y`,

\[
\boxed{|\Pi(y)-y|\le h/2.}
\tag{2.10}
\]

### Proof

On a plateau, the plateau value is the midpoint of the full cell between two
successive transition centers.  The retained plateau starts `delta` away from
each center, so the largest displacement is `h/2-delta`.

On a transition ramp the difference `Pi(y)-y` is affine.  At the midpoint
`m_k` it is zero, and at the two ramp endpoints its magnitude is
`h/2-delta`.  Hence its absolute value never exceeds `h/2`.  QED.

No derivative bound on `Pi` is used anywhere below.  The ramp may be
arbitrarily narrow and correspondingly steep.  Only continuity, monotonicity,
and the uniform `C^0` bound matter.

---

# 3. Compact residue snapping

Let

\[
p_h:\mathbb R\to\mathbb T_h:=\mathbb R/h\mathbb Z
\tag{3.1}
\]

be the quotient map to the phase circle of circumference `h`.

Let `Y subset R` be compact.

## Theorem 3.1 — residue-gap snapping theorem

If

\[
p_h(Y)\ne\mathbb T_h,
\tag{3.2}
\]

then there exist `c` and `delta>0` for which the staircase in Section 2 obeys

\[
\boxed{\Pi(Y)\subset\tau+h\mathbb Z.}
\tag{3.3}
\]

At the same time

\[
\boxed{\|\Pi-\mathrm{id}\|_\infty\le h/2.}
\tag{3.4}
\]

### Proof

Because `Y` is compact, `p_h(Y)` is compact.  If it is not the whole circle,
its complement contains a nonempty open arc.  Choose `c` in that open arc and
then choose `delta>0` so small that

\[
p_h(Y)\cap(c-\delta,c+\delta)=\varnothing
\tag{3.5}
\]

on the circle.

All transition ramps of `Pi` project precisely to this omitted residue arc.
Therefore no point of `Y` lies on a transition ramp.  Every point of `Y` lies
on one of the plateaus, and every plateau value belongs to
`tau+h Z`.  Lemma 2.1 gives the uniform bound.  QED.

## Corollary 3.2 — sub-lattice one-level collapse

If

\[
\operatorname{diam}Y<h,
\tag{3.6}
\]

then `p_h(Y)` cannot be the whole phase circle.  Moreover the omitted arc may
be chosen so that all of `Y` lies in a single plateau component.  Hence

\[
\boxed{\Pi(Y)=\{\tau+kh\}}
\tag{3.7}
\]

for one integer `k`.

### Proof

A compact subset of the line with diameter `<h` projects into a proper arc of
the phase circle.  Choose the transition ramp inside the complementary arc.
The complement of one transition arc on the phase circle is connected and is
one plateau modulo `h`; lifting back to the interval of length `<h` containing
`Y` shows that every point lands on the same lifted plateau.  QED.

## Corollary 3.3 — bounded number of snapped levels

If

\[
\operatorname{diam}Y\le Mh
\tag{3.8}
\]

and `p_h(Y)` is not the whole circle, then

\[
\boxed{
\#\Pi(Y)\le \lceil M\rceil+2.
}
\tag{3.9}
\]

This bound is intentionally crude.  A set of diameter `Mh` can meet only
`M+O(1)` consecutive lifted plateaus.

---

# 4. The only obstruction to snapping is residue saturation

The preceding theorem has an exact converse at the level relevant to this
construction.  If `p_h(Y)` is the whole phase circle, every possible
transition residue meets `Y`, so no continuous staircase with a nontrivial
transition interval can map all of `Y` into plateau values.

That failure is quantitatively expensive.

## Theorem 4.1 — residue saturation forces positive phase measure

If `Y subset R` is compact and

\[
p_h(Y)=\mathbb T_h,
\tag{4.1}
\]

then

\[
\boxed{
\mathcal H^1(Y)\ge h.
}
\tag{4.2}
\]

Since `Y subset R`, this is simply

\[
\boxed{|Y|\ge h.}
\tag{4.3}
\]

### Proof

The quotient map `p_h`, with the geodesic metric on `T_h`, is 1-Lipschitz.
Hausdorff one-measure cannot increase under a 1-Lipschitz map.  Hence

\[
h=\mathcal H^1(\mathbb T_h)
=\mathcal H^1(p_h(Y))
\le\mathcal H^1(Y).
\tag{4.4}
\]

QED.

There is also a direct lattice-visibility statement.  Surjectivity of `p_h`
means that **every residue class** occurs in `Y`.  Thus for every
`theta in [0,h)` there is a `y in Y` with

\[
y\equiv\theta\pmod h.
\tag{4.5}
\]

So residue saturation is the opposite of a hidden sub-lattice shear: the
phase set is already visible in every lattice residue.

## Corollary 4.2 — bounded-slab positive-measure secondary limit

Suppose

\[
\operatorname{diam}Y_n\le Mh_n,
\qquad
p_{h_n}(Y_n)=\mathbb T_{h_n}.
\tag{4.6}
\]

Put `a_n=min Y_n`, translate, and rescale so that

\[
Z_n=\frac{Y_n-a_n}{h_n}\subset[0,M+1].
\tag{4.7}
\]

Then

\[
|Z_n|\ge1.
\tag{4.8}
\]

By compactness of nonempty compact subsets of a fixed compact interval, a
subsequence converges in Hausdorff distance to some compact `Z_*`.  Moreover

\[
\boxed{|Z_*|\ge1.}
\tag{4.9}
\]

### Proof of the measure persistence

For every `epsilon>0`, Hausdorff convergence gives

\[
Z_n\subset (Z_*)_\epsilon
\tag{4.10}
\]

for all large `n`.  Hence

\[
1\le |Z_n|\le |(Z_*)_\epsilon|.
\tag{4.11}
\]

Let `epsilon downarrow0`.  Continuity from above of Lebesgue measure for the
nested compact neighborhoods gives

\[
1\le |Z_*|.
\tag{4.12}
\]

QED.

Consequently almost every point of `Z_*` is a Lebesgue density point.  Blowing
up `Z_*` at such a point produces interval tangents exactly as in the v166
carrier-measure argument.

Thus the unsnappable bounded-slab branch has been upgraded to a
**positive-measure secondary phase carrier with interval tangents**.

---

# 5. Stability of the full relative phase map

Let

\[
\widetilde f=\Pi\circ f.
\tag{5.1}
\]

By Lemma 2.1,

\[
\|\widetilde f-f\|_\infty\le h/2.
\tag{5.2}
\]

For one coordinate of the relative phase map,

\[
H_{f,j}=f(u_j)-f(u_0).
\tag{5.3}
\]

Therefore

\[
\begin{aligned}
|H_{\widetilde f,j}-H_{f,j}|
&\le
|\widetilde f(u_j)-f(u_j)|
+|\widetilde f(u_0)-f(u_0)|\\
&\le h.
\end{aligned}
\tag{5.4}
\]

Thus, in max norm,

\[
\boxed{
\|H_{\widetilde f}-H_f\|_\infty\le h.
}
\tag{5.5}
\]

In Euclidean norm the corresponding bound is `sqrt(3) h`.

This estimate is global on the entire parameter domain.  It is not restricted
to the selected persistence points.

## Theorem 5.1 — protected degree survives snapping

Let `D subset R^3` be a bounded degree box and let `q in h Z^3` be a target.
Assume

\[
\operatorname{dist}_\infty(q,H_f(\partial D))>h.
\tag{5.6}
\]

Then

\[
\boxed{
\deg(H_f,D,q)=\deg(H_{\widetilde f},D,q).
}
\tag{5.7}
\]

The same conclusion holds with `f` and `tilde f` interchanged in the boundary
margin assumption.

### Proof

Use the straight-line homotopy

\[
H_t=(1-t)H_f+tH_{\widetilde f}.
\tag{5.8}
\]

By (5.5), every boundary point moves by at most `h` in max norm.  The target
`q` therefore stays off the boundary image throughout the homotopy.  Brouwer
degree is homotopy invariant.  QED.

Because `h_n -> 0`, any protected phase cell with a fixed positive boundary
margin is eventually immune to staircase snapping.

This is the finite-resolution fact v168 was missing.

---

# 6. The relative lattice is preserved by snapping

The plateau values of `Pi` are

\[
\tau+h\mathbb Z.
\tag{6.1}
\]

Hence if two selected phase values lie on plateaus,

\[
\Pi(y_1)-\Pi(y_0)\in h\mathbb Z.
\tag{6.2}
\]

The arbitrary translate `tau` cancels.

Therefore staircase snapping does not create a new relative lattice.  It uses
exactly the same normalized target lattice `h Z^3` as the original square
phase map.

This matters because the perturbation argument in Section 5 transfers degree
at the **same lattice target**, not at a shifted target.

---

# 7. Application to the v168 visibility regimes

Let `Y_n` now denote the compact exact-phase label set of the particular hidden
persistence cloud being tested, and put

\[
h_n=\Lambda/S_n,
\qquad
\sigma_n=\operatorname{diam}Y_n,
\qquad
\widehat\Xi_n=\sigma_n/h_n.
\tag{7.1}
\]

## 7.1 Regime A: sub-lattice shear

Assume

\[
\widehat\Xi_n\to0.
\tag{7.2}
\]

Then eventually

\[
\sigma_n<h_n.
\tag{7.3}
\]

Corollary 3.2 produces a staircase `Pi_n` for which

\[
\boxed{\Pi_n(Y_n)=\{\tau_n+k_nh_n\}.}
\tag{7.4}
\]

The whole hidden exact-phase cloud has become one exact phase level.
Meanwhile

\[
\|H_{\Pi_n\circ f_n}-H_{f_n}\|_\infty\le h_n\to0.
\tag{7.5}
\]

Hence:

> **Theorem 7.1 — sub-lattice phase shear is not a new degree obstruction.**  
> Any protected Brouwer/lattice conclusion that holds after exact collapse of
> a sub-lattice hidden phase cloud also holds for the original profile for all
> sufficiently large `n`.  Conversely, a square-free obstruction that survives
> sub-lattice shear must survive after the whole cloud is collapsed to one exact
> phase by an `o(1)` perturbation of the complete relative phase map.

This does **not** say that the resulting exact-level singular branch is already
closed.  It says that the additional exact-phase splitting discovered in v168
is irrelevant at lattice resolution in Regime A.  The obstruction is pushed
back into the pre-existing exact-level singular-current problem.

That is the correct finite-resolution replacement for the false exact phase
compression theorem.

## 7.2 Regime B: bounded-slab shear

Assume

\[
\widehat\Xi_n\le M.
\tag{7.6}
\]

There are now two exhaustive possibilities.

### B1. Residue gap

If

\[
p_{h_n}(Y_n)\ne\mathbb T_{h_n},
\tag{7.7}
\]

Theorem 3.1 snaps the whole cloud into

\[
\le\lceil M\rceil+2
\tag{7.8}
\]

exact translated lattice phases while changing the full phase map by only
`h_n=o(1)`.

So the bounded-slab obstruction reduces rigorously to a **uniformly finite
exact-level model** modulo degree-negligible perturbation.

### B2. Residue saturation

If

\[
p_{h_n}(Y_n)=\mathbb T_{h_n},
\tag{7.9}
\]

then

\[
|Y_n|\ge h_n.
\tag{7.10}
\]

After dividing by `h_n`, a subsequence produces a compact positive-measure
secondary phase set `Z_*` with

\[
|Z_*|\ge1.
\tag{7.11}
\]

This branch is already lattice-visible in the strongest residue sense: every
residue class occurs in `Y_n`.

Thus v168's informal bounded-slab branch sharpens to

\[
\boxed{
\text{bounded shear}
\Longrightarrow
\begin{cases}
\text{finite exact-level branch after }o(1)\text{ snapping},\\
\text{or positive-measure residue-saturated secondary phase carrier}.
\end{cases}}
\tag{7.12}
\]

There is no third finite-resolution phase-shear mechanism.

## 7.3 Regime C: visible shear

Assume

\[
\widehat\Xi_n\to\infty.
\tag{7.13}
\]

Normalize the hidden phase coordinate by `sigma_n`.  The secondary lattice
spacing is

\[
\widetilde h_n=\frac{h_n}{\sigma_n}
=\widehat\Xi_n^{-1}\to0.
\tag{7.14}
\]

Suppose a secondary shear limit contains a continuous path `gamma:[0,1]->R`
with

\[
\operatorname{osc}\gamma=\Delta>0.
\tag{7.15}
\]

Then `gamma([0,1])` is an interval of length `Delta`.  For large `n` that
interval crosses at least

\[
\boxed{
\left\lfloor\frac{\Delta}{\widetilde h_n}\right\rfloor-1
}
\tag{7.16}
\]

secondary lattice slabs, which tends to infinity.

Therefore connected nonconstant secondary phase motion is automatically
lattice-visible.  The genuinely unresolved visible-shear branch must keep its
phase variation on a disconnected carrier, or else lose the two remaining
protected degree coordinates while the shear is exposed.

The v168 Cantor example does exactly the first: its secondary law is the
identity restricted to a Cantor carrier rather than to an interval.

---

# 8. Reinterpreting the v168 Cantor counterexample

For the v168 family

\[
f_\varepsilon(x)
=\varepsilon x-\operatorname{dist}(x,C)^{2/3},
\tag{8.1}
\]

the exact persistence phases on the Cantor carrier are

\[
Y_\varepsilon=\varepsilon C.
\tag{8.2}
\]

Their diameter is `epsilon`.

Suppose the inherited lattice mesh is `h` and

\[
\varepsilon/h\to0.
\tag{8.3}
\]

Then Theorem 7.1 gives a continuous staircase `Pi` such that

\[
\Pi(\varepsilon C)
\tag{8.4}
\]

is a single exact translated-lattice phase, while

\[
\|H_{\Pi\circ f_\varepsilon}-H_{f_\varepsilon}\|_\infty\le h\to0.
\tag{8.5}
\]

So the counterexample remains a valid refutation of **exact phase compression
as a topological statement**, but it does not furnish a distinct sub-lattice
obstruction to a protected lattice-degree argument.

At lattice resolution, the whole shear can be collapsed continuously for a
vanishing global cost.

That is the main conceptual correction of v169.

---

# 9. What the snapping theorem does not prove

Several distinctions are important.

### 9.1 Snapping does not prove a square by itself

The snapped profile may still possess an exact-level infinite persistence
current of the kind isolated in v159-v162.  v169 removes the **phase-shear
splitting** from the sub-lattice branch; it does not classify every singular
exact-level current.

### 9.2 Persistence status need not be preserved pointwise

If a tiny excursion lies completely inside one staircase plateau, snapping may
turn that excursion into a flat piece.  This is not an error in the argument.
The theorem is about the **entire square-phase map**, which changes uniformly
by at most `h`.  Protected degree is transferred by homotopy rather than by a
pointwise bijection of persistence components.

This is precisely why the construction avoids the unsupported active/passive
step identified in v166-v167.

### 9.3 A residue-saturated bounded phase set need not contain an interval

The conclusion `|Y|>=h` allows fat nowhere-dense sets.  What is proved is
positive phase measure and interval tangents at density points, not literal
finite-scale interior.

### 9.4 Visible fractal shear remains open

When `sigma_n/h_n -> infinity`, a secondary phase set of positive Hausdorff
dimension can still avoid a prescribed discrete lattice at individual scales.
Connected secondary motion is easy; disconnected additive/fractal motion is
not.

---

# 10. Revised obstruction ledger after v169

Closed or reduced in the chain:

1. fixed-order polynomial exceptional tower — v152;
2. moving shifted-log coherence — v153;
3. compact nonquadratic residuals — v154;
4. perturbative infinite-scale cascade — v155;
5. monotone compact critical branch — v156-v157;
6. finite regular multivalued folding — v158-v160;
7. tiny-jump channel obstruction — v161;
8. infinite persistence current away from its critical image — v162;
9. critical-image entropy and pressure alternatives — v163-v165;
10. zero-measure full-box carrier loophole — v166;
11. critical tangent fiber dimensions and persistence-incidence closure — v167;
12. false exact phase-compression route — corrected by v168;
13. **sub-lattice phase shear as a distinct lattice obstruction — removed by
    v169 staircase snapping**;
14. **bounded-slab phase shear — reduced by v169 to finite exact levels or a
    positive-measure residue-saturated secondary phase carrier**.

The main surviving branches are now:

* the exact-level singular current after snapping;
* the positive-measure residue-saturated bounded secondary phase carrier;
* visible shear on disconnected secondary carriers;
* the unbounded-pressure/super-`2/3` branch;
* the inherited final Jordan/shrinking-window transfer.

---

# 11. Recommended v170 target

The best next target is the **residue-saturated bounded branch**, because v169
has converted it into a measure-theoretic object rather than a vague finite
slab problem.

Let `Z_*` be the positive-measure secondary phase set from Corollary 4.2.  At
almost every `z in Z_*`, its phase blow-ups converge to an interval.  Combine
those phase-density points with the spatial persistence-incidence graph from
v167.

The desired theorem is a two-coordinate density statement of the form

\[
\boxed{
\text{spatial persistence density}
+\text{phase residue density}
\Longrightarrow
\text{a genuine 2D persistence rectangle in }(x,y).
}
\tag{11.1}
\]

A 2D persistence rectangle would be much stronger than a thick exact phase
fiber and should feed directly into the v159/v162 third-phase degree current.

The second target is the snapped finite-level branch.  Because the number of
exact levels is uniformly bounded, try to combine the v159 orientation theorem
with the v162 persistence truncation separately on each snapped level.  The
remaining cancellation would then have to pass through a uniformly finite
number of singular critical images.

The visible-shear branch should come third: normalize by `sigma_n`, retain the
secondary mesh `h_n/sigma_n`, and study additive sumsets of disconnected
secondary carriers.

---

# 12. Bottom line

v168 discovered a real defect in exact phase compression.  v169 shows that the
defect has a precise finite-resolution cure.

A hidden phase cloud narrower than one lattice spacing can always be collapsed
to one exact phase by a **continuous global perturbation of size at most half a
lattice spacing**.  The complete relative square-phase map then moves by at
most one lattice spacing, so every protected degree computation survives as
the mesh tends to zero.

More generally, bounded shear has only two possibilities:

\[
\boxed{
\text{finite exact-level model after }o(1)\text{ snapping}
\quad\text{or}\quad
\text{positive-measure residue saturation}.}
\tag{12.1}
\]

Thus the phase-lattice issue has become substantially sharper.  The remaining
bounded obstruction is no longer “many nearby exact phases.”  It must either
be an old exact-level singular current, or a secondary phase set so rich that
it occupies every residue class and has positive measure after lattice-scale
normalization.
