# Project Handoff v171: Lattice Resonance Audit for the Return-Arch Cylinder

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It corrects and sharpens the lattice step at the end of v170.

v170 recovered the v159 multivalued degree cylinder from the bounded,
residue-saturated compact secondary branch.  It then proposed the visibility
number

\[
\Upsilon_n
=\sup_{x\in\mathcal S_n}|q_n(x+d_n)-q_n(x)|
\tag{0.1}
\]

and suggested a three-way analysis according as `Upsilon_n` tends to zero,
stays bounded and nonzero, or diverges.

Two facts change that picture.

First, in the **compact** secondary branch, the family `q_n` is uniformly
equicontinuous and `d_n->0`.  Therefore

\[
\boxed{\Upsilon_n\to0.}
\tag{0.2}
\]

So the bounded-nonzero and divergent alternatives are not compact subbranches;
they are manifestations of loss of secondary compactness / tertiary roughness.

Second, and more importantly, a nonzero relative degree at an arbitrary
third-phase threshold is not the same thing as degree at a target of the
phase lattice.  A sub-lattice endpoint current may live forever in the middle
of one lattice slab.  A completely explicit balanced PL profile realizes this
possibility even when the **first two square phases are already exact lattice
values**.

Thus

\[
\boxed{
\text{sub-lattice third-face motion alone does not force a square.}
}
\tag{0.3}
\]

The missing quantity is arithmetic: the residue of the third-phase current
relative to the lattice.

The corrected terminal object is therefore not `Upsilon_n` by itself but the
pair

\[
\boxed{
(\text{current width},\ \text{lattice residue/clearance}).
}
\tag{0.4}
\]

The best v172 target is a **residue-drift theorem** showing that a genuine
square-free return-arch current cannot remain deep in the interiors of lattice
slabs at every recovered scale unless the profile enters an already-classified
exceptional or noncompact branch.

---

# 1. Relative square phases and the lattice

Use contacts in their late-stage order

\[
u<s<v<w,\qquad w=u+v-s.
\tag{1.1}
\]

The relative phase map is

\[
H_q(u,s,v)
=
\bigl(
q(s)-q(u),\ q(v)-q(u),\ q(w)-q(u)
\bigr).
\tag{1.2}
\]

After normalizing the secondary lattice spacing to one, the square targets are

\[
\boxed{\mathbb Z^3.}
\tag{1.3}
\]

The v159--v170 first-two-cylinder coordinates are more conveniently written

\[
r_1=q(s)-q(u),\qquad r_2=q(v)-q(s).
\tag{1.4}
\]

Then

\[
H_q=(r_1,r_1+r_2,C_s),
\qquad
C_s=q(u+v-s)-q(u).
\tag{1.5}
\]

Therefore the first two lattice conditions are equivalent to

\[
\boxed{r_1\in\mathbb Z,\qquad r_2\in\mathbb Z.}
\tag{1.6}
\]

This elementary observation matters at the secondary scale because the lattice
mesh is now fixed at one.  A topological phase cell centered at a noninteger
`(r_1,r_2)` does not automatically contain a lattice target.

---

# 2. In the compact branch, `Upsilon_n -> 0` is automatic

Let `K_ext` be the fixed enlarged compact interval containing every translated
third-contact argument.  Suppose

\[
q_n:K_{\rm ext}\to\mathbb R
\tag{2.1}
\]

is uniformly equicontinuous.  Write the common modulus

\[
\omega_*(\delta)
=
\sup_n\sup_{\substack{x,y\in K_{\rm ext}\\|x-y|\le\delta}}
|q_n(x)-q_n(y)|,
\qquad
\omega_*(\delta)\to0.
\tag{2.2}
\]

Let `d_n->0`, and let `S_n` be any sample sets for which both `x` and
`x+d_n` remain in `K_ext`.

## Proposition 2.1 -- compact return-defect collapse

\[
\boxed{
\Upsilon_n
:=\sup_{x\in S_n}|q_n(x+d_n)-q_n(x)|
\le\omega_*(d_n)
\to0.
}
\tag{2.3}
\]

### Proof

Immediate from the definition of uniform equicontinuity. QED.

### Consequence

The trichotomy proposed at the end of v170 should be reorganized as

\[
\boxed{
\begin{array}{ll}
\text{secondary compactness} &\Longrightarrow \Upsilon_n\to0,\\[1mm]
\text{bounded/nonzero or large }\Upsilon_n
&\Longrightarrow \text{loss of secondary equicontinuity.}
\end{array}}
\tag{2.4}
\]

So the real compact question is entirely the sub-lattice one.

---

# 3. Audit of the first two lattice coordinates

v170 constructed a return arch

\[
q(a)=q(b)=z,
\qquad
z-D\le q(s)\le z
\quad(a\le s\le b),
\tag{3.1}
\]

and side intervals

\[
I^-=[L,a],\qquad I^+=[b,R]
\tag{3.2}
\]

with phase room below on the left and above on the right.

Define

\[
L^-:=z-q(L),
\qquad
L^+:=q(R)-z.
\tag{3.3}
\]

Assume the endpoint orientation used in v170:

\[
q(L)<z-D,
\qquad
q(R)>z.
\tag{3.4}
\]

For fixed positive increments `m_1,m_2`, the first two equations are

\[
q(u)=q(s)-m_1,
\qquad
q(v)=q(s)+m_2.
\tag{3.5}
\]

## Theorem 3.1 -- lattice-aligned side-room criterion

If

\[
\boxed{
0<m_1<L^- -D,
\qquad
D<m_2<L^+,
}
\tag{3.6}
\]

then for every `s in [a,b]` the two scalar equations in (3.5) have nonzero
one-dimensional Brouwer degree on `int(I^-)` and `int(I^+)`, respectively.
Their product therefore gives the v159 first-two degree cylinder at

\[
(r_1,r_2)=(m_1,m_2).
\tag{3.7}
\]

If `m_1,m_2` are integers, the first two components of the relative square
phase are exact lattice values:

\[
\boxed{(H_1,H_2)=(m_1,m_1+m_2)\in\mathbb Z^2.}
\tag{3.8}
\]

### Proof

Because `q(s) in [z-D,z]`, the left target level ranges through

\[
q(s)-m_1\in[z-D-m_1,z-m_1].
\tag{3.9}
\]

The first inequality in (3.6) says

\[
q(L)=z-L^-<z-D-m_1,
\tag{3.10}
\]

while `q(a)=z>z-m_1`.  Hence the endpoint signs of
`q(u)-(q(s)-m_1)` are opposite throughout the arch.

Likewise

\[
q(s)+m_2\in[z-D+m_2,z+m_2].
\tag{3.11}
\]

The condition `m_2>D` gives

\[
q(b)=z<z-D+m_2,
\tag{3.12}
\]

and `m_2<L^+` gives

\[
q(R)=z+L^+>z+m_2.
\tag{3.13}
\]

Thus the right scalar degree is also nonzero.  Product degree gives the
cylinder. QED.

## Corollary 3.2 -- sufficient room for the first positive lattice increment

If `D<1` and

\[
\boxed{L^->1+D,\qquad L^+>1,}
\tag{3.14}
\]

then `m_1=m_2=1` is admissible and the first two relative square phases are

\[
\boxed{(H_1,H_2)=(1,2).}
\tag{3.15}
\]

## 3.1 What v170 actually supplies

The specific v170 construction chose a small target increment

\[
\eta=\frac1{16}
\tag{3.16}
\]

because its compactness argument guaranteed only fixed **sub-unit** phase room.
This is enough to recover a nonzero topological degree cylinder, but it is not
by itself enough to assert a cylinder at an integer pair `(r_1,r_2)`.

This is not a flaw in the v170 topological theorem.  It is a missing lattice
step.  At the secondary normalization the mesh is one, so that missing step
cannot be hidden by saying that the lattice becomes dense.

---

# 4. Explicit balanced PL counterexample to sub-lattice third-face closure

The next construction shows that even after the first two coordinates are
perfectly lattice-aligned, a sub-lattice third-face interval can avoid the
third lattice indefinitely.

Fix

\[
0<d<\frac14.
\tag{4.1}
\]

Define `q_d:R->R` by

\[
q_d(t)=
\begin{cases}
 t, & t\le0,\\
 -2t, & 0\le t\le d/2,\\
 2t-2d, & d/2\le t\le d,\\
 2(t-d), & d\le t\le d+1/2,\\
 t-d+1/2, & t\ge d+1/2.
\end{cases}
\tag{4.2}
\]

The pieces agree at every breakpoint, so `q_d` is continuous.

## Proposition 4.1 -- balancedness

\[
\boxed{
\sup_{t\in\mathbb R}|q_d(t)-t|\le\frac12.
}
\tag{4.3}
\]

Thus this is a legitimate `t+O(1)` balanced profile.

### Proof

For `t<=0` the difference is zero.  On the return arch it is bounded by
`3d/2<3/8`.  On `[d,d+1/2]`,

\[
q_d(t)-t=t-2d\in[-d,1/2-d],
\tag{4.4}
\]

and thereafter it equals `1/2-d`. QED.

## Proposition 4.2 -- a shrinking return arch

The interval

\[
[a,b]=[0,d]
\tag{4.5}
\]

is a return arch at phase zero:

\[
q_d(0)=q_d(d)=0,
\qquad
q_d(t)\le0\quad(0\le t\le d),
\tag{4.6}
\]

with width and depth both equal to `d`:

\[
\boxed{b-a=d,\qquad D=d.}
\tag{4.7}
\]

## Proposition 4.3 -- exact first-two lattice phases

For every `s in [0,d]`, put

\[
y=q_d(s).
\tag{4.8}
\]

The equations

\[
q_d(u)=y-1,
\qquad
q_d(v)=y+1
\tag{4.9}
\]

have the unique side solutions

\[
\boxed{
u=y-1,
\qquad
v=d+\frac{y+1}{2}.
}
\tag{4.10}
\]

Hence

\[
q_d(s)-q_d(u)=1,
\qquad
q_d(v)-q_d(s)=1,
\tag{4.11}
\]

and therefore

\[
\boxed{(H_1,H_2)=(1,2)\in\mathbb Z^2.}
\tag{4.12}
\]

The first two roots are simple monotone side crossings, so their product degree
has magnitude one.

## Proposition 4.4 -- the complete third phase sits at a half-integer

Let

\[
w=u+v-s.
\tag{4.13}
\]

For all `s in [0,d]`, one has `w<0`, so `q_d(w)=w`.  The third relative phase is

\[
C_d(s)
:=q_d(w)-q_d(u).
\tag{4.14}
\]

A direct substitution gives

\[
C_d(s)
=
\frac12+\frac12y+d-s.
\tag{4.15}
\]

Using the two pieces of the return arch,

\[
\boxed{
C_d(s)=
\begin{cases}
\frac12+d-2s,
&0\le s\le d/2,\\[1mm]
\frac12,
&d/2\le s\le d.
\end{cases}}
\tag{4.16}
\]

Consequently

\[
\boxed{
C_d([0,d])=[1/2,1/2+d].
}
\tag{4.17}
\]

Since `d<1/4`, this interval contains no integer.  Thus

\[
\boxed{
H_{q_d}(u(s),s,v(s))\notin\mathbb Z^3
\quad\text{for every }s\in[0,d].
}
\tag{4.18}
\]

Yet every nonendpoint threshold

\[
c\in(1/2,1/2+d)
\tag{4.19}
\]

is crossed by the third coordinate and carries the ordinary one-dimensional
suspension degree of this single-carrier cylinder.

So the distinction is exact:

\[
\boxed{
\text{nonzero degree at real thresholds}
\not\Rightarrow
\text{nonzero degree at lattice thresholds}.}
\tag{4.20}
\]

## Proposition 4.5 -- `Upsilon` tends to zero while lattice clearance stays macroscopic

At the endpoint pair `(u,v)=(-1,d+1/2)`, the v157 translation argument is

\[
x=u+v-b=-\frac12.
\tag{4.21}
\]

Since `q_d(t)=t` near `[-1/2,-1/2+d]`,

\[
\boxed{
q_d(x+d)-q_d(x)=d.
}
\tag{4.22}
\]

Thus

\[
\Upsilon_d=d\to0.
\tag{4.23}
\]

But the third-current support is `[1/2,1/2+d]`, whose distance from the nearest
lattice point is

\[
\boxed{
\operatorname{dist}([1/2,1/2+d],\mathbb Z)=\frac12-d.
}
\tag{4.24}
\]

Therefore

\[
\boxed{
\frac{\operatorname{dist}(\operatorname{supp}\mathcal I_d,\mathbb Z)}
{\Upsilon_d}
=
\frac{1/2-d}{d}
\longrightarrow\infty.
}
\tag{4.25}
\]

The lattice planes run off to infinity in the tertiary normalization by
`Upsilon_d`.

This is the precise obstruction that `Upsilon` alone cannot see.

---

# 5. The correct discrete invariant: the lattice shadow of the third current

For a regular finite return-arch chamber, v159 associates the signed oriented
interval current

\[
\mathcal I
=
\sum_{i,j}w_{ij}[B_{ij},A_{ij}]_{\rm or}.
\tag{5.1}
\]

Its multiplicity function away from endpoints is exactly the third-coordinate
relative degree:

\[
\operatorname{mult}_{\mathcal I}(c)=\deg_3(c).
\tag{5.2}
\]

At a lattice-aligned pair of first coordinates, define the **lattice shadow**

\[
\boxed{
\mathscr L(\mathcal I)
=
\bigl(\operatorname{mult}_{\mathcal I}(k)\bigr)_{k\in\mathbb Z}.
}
\tag{5.3}
\]

Only finitely many entries are nonzero for a compactly supported current.

## Proposition 5.1 -- exact lattice criterion in a regular chamber

If the first two coordinates are lattice-aligned, then the return-arch chamber
has nonzero Brouwer degree at a square-phase lattice target exactly when

\[
\boxed{
\mathscr L(\mathcal I)\ne0.
}
\tag{5.4}
\]

This is just the v159 threshold formula evaluated at integer thresholds, but it
is the right finite-resolution invariant.

The ordinary statement `mathcal I != 0` is weaker.

The PL example has

\[
\mathcal I_d=[1/2,1/2+d]_{\rm or}\ne0
\tag{5.5}
\]

but

\[
\boxed{\mathscr L(\mathcal I_d)=0.}
\tag{5.6}
\]

---

# 6. Lattice clearance and tertiary normalization

For a nonzero compact current define its lattice clearance

\[
\boxed{
\chi(\mathcal I)
=
\operatorname{dist}(\operatorname{supp}\mathcal I,\mathbb Z).
}
\tag{6.1}
\]

This is only a sufficient diagnostic: `chi=0` does not guarantee nonzero
lattice multiplicity because signed carriers may cancel at a lattice plane.
But `chi>0` certainly implies zero lattice shadow.

Let

\[
\varepsilon_n
=
\max_{i,j}|A_{ij}-B_{ij}|
\tag{6.2}
\]

be the maximal geometric endpoint displacement.  In the single-carrier case it
is the same quantity measured by `Upsilon_n`.

The dimensionless ratio

\[
\boxed{
\mathfrak R_n
=
\frac{\chi(\mathcal I_n)}{\varepsilon_n}
}
\tag{6.3}
\]

measures how far the nearest lattice plane lies after magnifying the current by
its own thickness.

### Regime I -- resonant tertiary scale

If

\[
\mathfrak R_n=O(1),
\tag{6.4}
\]

then at least one lattice plane remains at finite distance in the tertiary
normalization.  A local orientation/cancellation theorem could potentially
force a lattice shadow.

### Regime II -- lattice escapes the tertiary tangent

If

\[
\boxed{\mathfrak R_n\to\infty,}
\tag{6.5}
\]

then every fixed compact tertiary window around the current is eventually free
of lattice planes.  No purely local limiting profile at scale `epsilon_n` can
force a square lattice target.  One must instead prove **residue drift** across
macroscopic parameter changes.

The PL example lies in Regime II.

This is a general warning against an unqualified tertiary blow-up: after
normalizing by a sub-lattice current thickness, the discrete lattice may
simply disappear to infinity.

---

# 7. Why v169-style snapping does not rescue the third coordinate

v169 proved a useful theorem at a scale where the lattice mesh `h_n->0`: a
staircase perturbation of the entire phase profile changes the relative phase
map by at most `h_n`, so any degree computation with a **fixed positive
boundary margin** survives.

The return-arch third cell considered here has raw vertical thickness

\[
\varepsilon_n h_n
\tag{7.1}
\]

with `epsilon_n->0` in the compact branch.  Its boundary margin is therefore
`o(h_n)`, not a fixed positive multiple independent of `h_n`.

A perturbation of size `O(h_n)` is larger than the very cell whose lattice
intersection is in question.  The v169 homotopy estimate consequently gives no
transfer theorem at an integer third target.

The PL model makes this failure concrete.  In unit secondary coordinates its
current is centered at `1/2`, with thickness `d`.  Collapsing or moving it to an
integer requires a displacement comparable to one half of a lattice spacing,
whereas the degree cell itself has thickness only `d`.

Thus:

\[
\boxed{
\text{v169 snapping is valid for protected macroscopic cells, but it does not
resolve a cell whose third margin is }o(\text{mesh}).
}
\tag{7.2}
\]

This is the exact distinction missing from Target A of v170.

---

# 8. A positive conditional residue-drift lemma

The counterexample shows that local thickness is insufficient.  What *would*
be sufficient is parameter-dependent residue motion.

Consider a continuous one-carrier family of oriented intervals

\[
I_t=[B(t),A(t)]_{\rm or},
\qquad t\in[t_0,t_1],
\tag{8.1}
\]

with

\[
A(t)-B(t)>0
\tag{8.2}
\]

throughout.

## Lemma 8.1 -- residue crossing forces a lattice threshold

If for some `t_*`

\[
B(t_*)\in\mathbb Z
\tag{8.3}
\]

and

\[
A(t_*)-B(t_*)>0,
\tag{8.4}
\]

then arbitrarily close parameter values contain an integer strictly inside the
oriented interval.  Hence the third lattice degree is nonzero there.

More generally, if `B([t_0,t_1])` contains an interval of length greater than
one and the displacement remains strictly positive, then some parameter has a
nonzero lattice shadow.

### Proof

At a parameter where `B=k` and `A>B`, continuity gives nearby parameters with
`B<k<A`.  The second statement follows from the intermediate value theorem. QED.

The multicarrier version needs the v159 orientation/cancellation control, but
the lesson is already clear:

\[
\boxed{
\text{the missing mechanism is motion of endpoint residues modulo }1,
\text{ not growth of }\Upsilon.
}
\tag{8.5}
\]

---

# 9. Collapsed third-phase map at a vanishing return arch

Suppose the compact branch has

\[
a_n,b_n\to s_*,
\qquad
q_n\to q
\tag{9.1}
\]

uniformly, and suppose a chosen finite endpoint branch converges to
`(u_*,v_*)`.  Then both endpoint third phases converge to the same collapsed
value

\[
\boxed{
B_*=A_*
=q(u_*+v_*-s_*)-q(u_*).
}
\tag{9.2}
\]

So the sub-lattice return current is a thin oriented perturbation of the
**collapsed three-contact phase map**

\[
\boxed{
C_*(u,v;s_*)
=q(u+v-s_*)-q(u).
}
\tag{9.3}
\]

At lattice-aligned side increments, the arithmetic question is whether the
values of (9.3), on the relevant multivalued level fibers, approach integers.

This identifies the correct zeroth-order residue problem before any tertiary
blow-up.

The PL example has collapsed value

\[
B_*=\frac12,
\tag{9.4}
\]

which remains maximally far from `Z` as the arch shrinks.

---

# 10. Revised obstruction ledger

The compact residue-saturated route now has **two** independent finite-resolution
requirements before the return-arch topology can force an actual square.

## Requirement A -- first-two lattice room

There must exist integer side increments `m_1,m_2` satisfying the side-room
criterion (3.6).

The v170 `eta=1/16` cylinder establishes topological degree but does not by
itself establish this lattice room.

## Requirement B -- third-coordinate resonance

For a lattice-aligned first-two cylinder, the signed interval current must have
nonzero lattice shadow:

\[
\mathscr L(\mathcal I_n)\ne0.
\tag{10.1}
\]

In the compact branch its width tends to zero, so this becomes a residue problem
for the collapsed third-phase map.

Thus the previous single visibility number

\[
\Upsilon_n
\tag{10.2}
\]

should be replaced by a lattice-aware tuple such as

\[
\boxed{
\bigl(L^-_n,L^+_n,\ \varepsilon_n,\ \chi_n,\ \mathscr L(\mathcal I_n)\bigr).
}
\tag{10.3}
\]

---

# 11. What v171 proves

1. Uniform secondary compactness plus `d_n->0` forces `Upsilon_n->0`.
2. The bounded-nonzero and divergent `Upsilon` alternatives therefore belong
   to noncompact/tertiary branches rather than the compact v170 branch.
3. A precise side-phase-room criterion determines when the v159 product degree
   can be centered at integer first-two increments.
4. v170's small `eta` construction is a topological cylinder and does not by
   itself establish first-two lattice alignment at the unit secondary mesh.
5. The explicit continuous PL family (4.2) is balanced (`q_d=t+O(1)`), has a
   return arch of width/depth `d`, and has unique side roots with exact relative
   lattice phases `(H_1,H_2)=(1,2)`.
6. Along that entire cylinder the third relative phase is exactly contained in
   `[1/2,1/2+d]`, so no lattice target occurs for `d<1/4`.
7. The same example has `Upsilon_d=d->0` while its lattice clearance tends to
   `1/2`; hence clearance/current-width tends to infinity.
8. The exact discrete object is the lattice shadow of the v159 signed interval
   current.
9. v169-style `O(h_n)` snapping cannot transfer degree for a third cell whose
   raw boundary margin is `o(h_n)`.
10. A parameter-dependent residue crossing is sufficient to restore a lattice
    threshold.
11. The compact small-arch limit is controlled arithmetically by the collapsed
    three-contact phase map `q(u+v-s)-q(u)`.

---

# 12. What remains open

v171 does **not** prove:

1. that the compact residue-saturated branch always has enough two-sided phase
   room to select integer first-two increments;
2. that the collapsed third-phase map must meet the integer lattice;
3. that signed multicarrier cancellation cannot make the lattice shadow zero at
   every integer even when geometric intervals cross lattice planes;
4. a residue-drift theorem for the multivalued endpoint current;
5. closure of the tertiary non-equicontinuous branch;
6. closure of the visible disconnected/fractal shear branch;
7. closure of the unbounded-pressure super-`2/3` branch;
8. the final shrinking-window/Jordan transfer beyond inherited hypotheses.

---

# 13. Recommended v172 target: residue drift, not another thickness blow-up

The strongest next target is now a **lattice residue-drift theorem**.

Fix a return-arch chamber and integer first-two increments `(m_1,m_2)` whenever
the side-room criterion permits them.  Let

\[
\mathcal I_{n,\theta}
\tag{13.1}
\]

be the v159 endpoint current as an available macroscopic parameter `theta`
varies (arch location, base phase, or a side target parameter inside a
lattice-aligned family).

The desired alternative is:

\[
\boxed{
\begin{array}{l}
\text{either some }\theta\text{ gives }\mathscr L(\mathcal I_{n,\theta})\ne0,\\
\text{or all collapsed endpoint residues remain trapped in open unit slabs.}
\end{array}}
\tag{13.2}
\]

The second case should then be attacked as a rigidity statement for

\[
q(u+v-s)-q(u)\pmod1.
\tag{13.3}
\]

There are two promising routes.

### Route A -- residue winding

Show that some continuous endpoint branch has nonzero winding modulo one as a
macroscopic target parameter varies.  Lemma 8.1 then forces a lattice hit.

### Route B -- slab-trapping rigidity

Assume every endpoint branch remains in one open unit slab and derive a
functional restriction on the collapsed phase-root law.  This reconnects
naturally to the v156 affine/shifted-log classification: persistent absence of
root drift was already rigid there.  The new question is whether persistent
**integer-slab trapping** is sufficiently rigid once several integer side
increments are available.

The PL model in Section 4 is the local obstruction that any v172 theorem must
explicitly defeat.  Its collapsed third residue is exactly `1/2`, so a correct
proof needs genuine parameter drift or additional global structure; local
return-arch degree alone cannot do it.

---

# 14. Bottom line

v170 successfully returned the residue-saturated compact branch to the
multivalued return-arch topology.  v171 shows that topology is still one step
short of the discrete square condition.

At the compact scale the return displacement necessarily becomes sub-lattice.
A thin degree current can sit permanently between adjacent lattice planes, even
when the first two relative phases are exactly integer.  The explicit balanced
PL family demonstrates this with third phase trapped near `1/2`.

Therefore the next obstruction is genuinely arithmetic/topological:

\[
\boxed{
\text{return-arch current}
+\text{ lattice-aligned side phases}
+\text{ residue drift}
\longrightarrow
\text{ lattice degree}.
}
\tag{14.1}
\]

The quantity to control is no longer merely how *large* the third-face motion
is, but where that motion sits **modulo the phase lattice**.
