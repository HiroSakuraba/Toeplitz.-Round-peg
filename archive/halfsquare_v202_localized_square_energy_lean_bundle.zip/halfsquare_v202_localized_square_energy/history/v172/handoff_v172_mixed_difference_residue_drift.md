# Project Handoff v172: Consecutive-Level Mixed Difference and Residue Drift

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It repairs one inherited contact-order typo and replaces the local third-current
visibility heuristic of v171 with a branch-free lattice-aware defect built from
four consecutive phase levels.

The principal new object is the first-hit inverse

\[
g(y)=\min\{t:q(t)=y\}
\]

of a balanced phase profile

\[
q(t)=t+h(t),\qquad |h(t)|\le B.
\]

Every level is hit because `q(t)-t` is bounded.  The first hit satisfies

\[
|g(y)-y|\le B
\]

and is strictly increasing, with upward jumps exactly at record return arches.

For four consecutive phase levels define

\[
\boxed{
R(y)=g(y)+g(y+3)-g(y+1)-g(y+2).
}
\tag{0.1}
\]

If `R(y)=0`, the four exact level hits satisfy the additive contact relation and
produce the phase-lattice target

\[
\boxed{(H_1,H_2,H_3)=(1,3,2).}
\tag{0.2}
\]

The key structural fact is that `R` is a second mixed difference of the bounded
first-hit displacement.  Writing

\[
e(y)=g(y)-y,
\qquad
d(y)=e(y+1)-e(y),
\]

one has

\[
\boxed{R(y)=d(y+2)-d(y).}
\tag{0.3}
\]

This yields two new conclusions.

1. If the inverse phase branch is continuous globally, `R` either vanishes
   identically or changes sign.  Hence a strictly monotone balanced profile
   has an exact consecutive-level lattice resonance; the monotone branch cannot
   hide forever in an open lattice slab.
2. In the nonmonotone first-hit problem, `R` has the exact long-interval mean
   cancellation

   \[
   \boxed{
   \left|\int_X^{X+L}R(y)\,dy\right|\le 8B.
   }
   \tag{0.4}
   \]

   Therefore a uniformly lattice-cleared third phase cannot keep `R` of one
   sign over a long phase interval.  In a square-free profile those forced
   sign changes must occur through discontinuities of `R`, and those
   discontinuities come only from jumps of `g`, i.e. record return arches.

With a uniform modulus of continuity, a fixed lattice-clearance margin forces
not merely return arches but **macroscopic** record arches at syndetic phase
levels.  Thus the v171 trapped-slab alternative is converted into

\[
\boxed{
\text{lattice resonance}
\quad\text{or}\quad
\text{syndetic macroscopic record arches}
\quad\text{or}\quad
\text{modulus collapse / roughness}.
}
\tag{0.5}
\]

That is the main v172 advance.

---

# 1. Contact-order correction

The inherited contact map is

\[
\mathcal H_q(u_0,u_1,u_2)
=
\begin{pmatrix}
q(u_1)-q(u_0)\\
q(u_2)-q(u_0)\\
q(u_3)-q(u_0)
\end{pmatrix},
\qquad
u_3:=u_0+u_2-u_1.
\tag{1.1}
\]

v171 temporarily wrote the late-stage contacts as

\[
u<s<v<w,\qquad w=u+v-s.
\]

That ordering is algebraically impossible, because

\[
w-v=u-s<0.
\]

The correct general statement is:

if

\[
u_0<u_1<u_2,
\]

then

\[
\boxed{u_0<u_3<u_2,}
\tag{1.2}
\]

while the order of `u_1` and `u_3` depends on which side of the midpoint
`u_1` lies.

For the consecutive-level resonance below, the order is

\[
\boxed{u_0<u_1<u_3<u_2,}
\tag{1.3}
\]

which is the `0132` parameter-order sector.

No phase formula used in v157--v171 depends on the erroneous `u<s<v<w`
string; the error is in the prose ordering only.  The explicit v171 PL
calculation already had the fourth contact on the correct side.

---

# 2. First-hit inverse and record arches

Assume throughout

\[
q:\mathbb R\to\mathbb R
\]

is continuous and

\[
\boxed{|q(t)-t|\le B.}
\tag{2.1}
\]

Every level set is nonempty and compact, with

\[
q^{-1}(y)\subset[y-B,y+B].
\tag{2.2}
\]

Define

\[
\boxed{g(y)=\min q^{-1}(y).}
\tag{2.3}
\]

Then

\[
\boxed{|g(y)-y|\le B.}
\tag{2.4}
\]

## Proposition 2.1 -- strict monotonicity of the first hit

If `y_1<y_2`, then

\[
\boxed{g(y_1)<g(y_2).}
\tag{2.5}
\]

### Proof

Before the first hit of `y_2`, the continuous profile must cross `y_1`, since
it tends to `-infinity` at the left end.  Thus the first `y_1` hit occurs
strictly earlier. QED.

Because `g` is monotone, its discontinuities are jumps.  Let

\[
J(y)=g(y+)-g(y)\ge0.
\tag{2.6}
\]

The balanced bound gives

\[
\boxed{0\le J(y)\le2B.}
\tag{2.7}
\]

As in v157/v161, `J(y)>0` is exactly a record return arch:

\[
a=g(y),\qquad b=g(y+),
\]

with

\[
q(a)=q(b)=y,
\qquad
q(t)\le y\quad(a\le t\le b).
\tag{2.8}
\]

So atoms of the first-hit Stieltjes measure and record arches remain the same
object.

---

# 3. The consecutive-level 0132 resonance defect

Consider the four exact phase levels

\[
y,\\quad y+1,\\quad y+2,\\quad y+3.
\]

Put

\[
x_j=g(y+j),\qquad j=0,1,2,3.
\tag{3.1}
\]

Since `g` is strictly increasing,

\[
x_0<x_1<x_2<x_3.
\tag{3.2}
\]

Use the square-map contacts

\[
u_0=x_0,
\qquad
u_1=x_1,
\qquad
u_2=x_3.
\tag{3.3}
\]

The square-map fourth contact is

\[
u_3=u_0+u_2-u_1=x_0+x_3-x_1.
\tag{3.4}
\]

The desired fourth phase is `y+2`, whose first hit is `x_2`.  Define

\[
\boxed{
R(y):=u_3-x_2
=g(y)+g(y+3)-g(y+1)-g(y+2).
}
\tag{3.5}
\]

## Proposition 3.1 -- exact lattice resonance

If

\[
\boxed{R(y_*)=0,}
\tag{3.6}
\]

then

\[
u_3=x_2
\]

and the relative phase map is exactly

\[
\boxed{
\mathcal H_q(u_0,u_1,u_2)=(1,3,2)\in\mathbb Z^3.
}
\tag{3.7}
\]

Moreover

\[
u_0<u_1<u_3<u_2,
\]

so all four contacts are distinct and physically admissible in the `0132`
sector.

### Proof

The first two components are immediate:

\[
q(x_1)-q(x_0)=1,
\qquad
q(x_3)-q(x_0)=3.
\]

If `R=0`, then `u_3=x_2`, hence

\[
q(u_3)-q(u_0)=2.
\]

Strict increase of `g` gives the contact order. QED.

This is a fully lattice-aligned condition; it does not invoke a dense-lattice
limit or a small third current.

---

# 4. Mixed-difference factorization

Write

\[
e(y)=g(y)-y.
\tag{4.1}
\]

Then

\[
|e(y)|\le B.
\tag{4.2}
\]

Define the one-step displacement defect

\[
d(y)=e(y+1)-e(y).
\tag{4.3}
\]

The linear terms cancel in (3.5), and one gets

\[
\boxed{
R(y)
=e(y)+e(y+3)-e(y+1)-e(y+2)
=d(y+2)-d(y).
}
\tag{4.4}
\]

This is the discrete mixed second difference associated with the phase shifts
`1` and `2`.

It is the lattice analogue of the reciprocal-slope/Jensen defects that
appeared in v152 and the phase-root defect of v156, but it requires only the
bounded first-hit displacement.

---

# 5. Global continuous inverse branches must resonate

The cleanest theorem occurs when `g` is continuous.  This includes every
strictly increasing balanced profile and, more generally, any global continuous
phase section.

## Theorem 5.1 -- bounded mixed-difference sign theorem

Let `e:R->R` be bounded and continuous, and set

\[
R(y)=e(y)+e(y+3)-e(y+1)-e(y+2).
\]

Then exactly one of the following occurs:

1. `R identically 0`; or
2. `R` takes both positive and negative values.

In particular,

\[
\boxed{\exists y_*:\ R(y_*)=0.}
\tag{5.1}
\]

### Proof

Let

\[
d(y)=e(y+1)-e(y).
\]

Then `R(y)=d(y+2)-d(y)`.

Suppose `R>=0` everywhere.  Fix `y` and define

\[
p_n=e(y+2n+2)-e(y+2n).
\]

A direct calculation gives

\[
p_{n+1}-p_n
=R(y+2n)+R(y+2n+1)
\ge0.
\tag{5.2}
\]

Hence `(p_n)` is nondecreasing.  But

\[
\sum_{n=0}^{N-1}p_n=e(y+2N)-e(y)
\]

is uniformly bounded in `N`, because `e` is bounded.  A bi-infinite
nondecreasing sequence whose forward and backward partial sums are bounded
must be identically zero.  Thus `p_n=0` for every `n` and every starting `y`.
Hence

\[
e(y+2)=e(y)
\]

for all `y`.  Equation (5.2), together with `R>=0`, now gives

\[
R(y)+R(y+1)=0,
\]

so `R=0` everywhere.

The same argument applies if `R<=0` everywhere.  Therefore a nonzero `R`
cannot have one sign.  Continuity then forces a zero. QED.

## Corollary 5.2 -- exact 0132 lattice resonance for monotone balanced profiles

If `q` is continuous, strictly increasing, and satisfies `|q(t)-t|<=B`, then
its inverse `g=q^{-1}` is continuous and satisfies the hypotheses above.
Consequently

\[
\boxed{
\exists y_*:\
\mathcal H_q(g(y_*),g(y_*+1),g(y_*+3))=(1,3,2).
}
\tag{5.3}
\]

Thus the monotone balanced profile branch has an **exact phase-lattice
resonance**, without invoking the affine/log exceptional classification.

## Corollary 5.3 -- robust crossing unless the defect is identically zero

If `R` is not identically zero, Theorem 5.1 shows that it takes both signs.
Hence some zero is a sign-crossing zero in the weak one-dimensional sense:
there are points on the two sides with opposite sign.

Using the phase chart

\[
\Theta(y,r_1,r_2)
=
\bigl(g(y),g(y+r_1),g(y+r_2)\bigr),
\tag{5.4}
\]

the first two phase outputs are exactly `(r_1,r_2)`.  The sign-changing
third equation at `(r_1,r_2)=(1,3)` therefore gives the same triangular
Poincare--Miranda mechanism used in v156, now centered at the **lattice point**
`(1,3,2)`.

If `R identically 0`, then the consecutive-level lattice resonance holds for
every `y`.

---

# 6. The identically resonant case

If

\[
R(y)=0
\]

for every `y`, then

\[
d(y+2)=d(y).
\]

Since

\[
e(y+2)-e(y)=d(y)+d(y+1),
\]

and `e` is bounded, iteration by `2` forces

\[
\boxed{e(y+2)=e(y).}
\tag{6.1}
\]

Thus the inverse defect is `2`-periodic:

\[
\boxed{g(y+2)=g(y)+2.}
\tag{6.2}
\]

So the non-crossing equality case is itself rigid: the phase inverse is
translation-equivariant by two lattice units.

If this periodic branch is nonaffine, the v156 phase-root rigidity theorem can
be re-used on nearby phase increments.  If it is affine, it is already one of
the exceptional profiles.  Either way, the equality case is not an arbitrary
residue-trapped profile.

---

# 7. Exact long-interval cancellation for the nonmonotone first-hit defect

For a general nonmonotone `q`, `g` is monotone but may jump.  The same algebra
still gives the measurable bounded functions

\[
e(y)=g(y)-y,
\qquad
|e(y)|\le B,
\]

\[
d(y)=e(y+1)-e(y),
\qquad
|d(y)|\le2B,
\]

and

\[
R(y)=d(y+2)-d(y).
\]

No continuity is needed for the next identity.

## Theorem 7.1 -- long-interval mean cancellation

For every `X` and `L>0`,

\[
\boxed{
\int_X^{X+L}R(y)\,dy
=
\int_{X+L}^{X+L+2}d(t)\,dt
-
\int_X^{X+2}d(t)\,dt.
}
\tag{7.1}
\]

Consequently

\[
\boxed{
\left|\int_X^{X+L}R(y)\,dy\right|
\le8B.
}
\tag{7.2}
\]

### Proof

Change variables in the `d(y+2)` integral:

\[
\int_X^{X+L}[d(y+2)-d(y)]\,dy
=
\int_{X+2}^{X+L+2}d(t)\,dt
-
\int_X^{X+L}d(t)\,dt,
\]

and cancel the common interior interval.  Since `|d|<=2B`, the two boundary
integrals of length two have total absolute value at most `8B`. QED.

This is the global residue-drift budget missing from v171.

---

# 8. The third phase associated with the first-hit quadruple

Define the square-map fourth contact generated by the first three selected
levels:

\[
w(y)=g(y)+g(y+3)-g(y+1).
\tag{8.1}
\]

The corresponding third relative phase is

\[
\boxed{
C(y)=q(w(y))-q(g(y))=q(w(y))-y.
}
\tag{8.2}
\]

The first two relative phases are exactly

\[
(H_1,H_2)=(1,3).
\tag{8.3}
\]

The spatial defect `R` measures the displacement from the desired phase-`y+2`
first hit:

\[
\boxed{
w(y)=g(y+2)+R(y).}
\tag{8.4}
\]

Hence

\[
\boxed{
C(y)-2
=q(g(y+2)+R(y))-q(g(y+2)).
}
\tag{8.5}
\]

In particular,

\[
R(y)=0\quad\Longrightarrow\quad C(y)=2,
\]

which recovers Proposition 3.1.

---

# 9. Uniform lattice clearance forces a spatial gap

Assume now that `q` has a global modulus of continuity

\[
|q(x)-q(x')|\le\omega(|x-x'|),
\qquad
\omega(r)\to0.
\tag{9.1}
\]

Fix a lattice-clearance margin `chi>0` and choose any `delta>0` such that

\[
\boxed{\omega(\delta)<\chi.}
\tag{9.2}
\]

Suppose on a phase set `I` one has

\[
\boxed{
\operatorname{dist}(C(y),\mathbb Z)\ge\chi.
}
\tag{9.3}
\]

Then in particular

\[
|C(y)-2|\ge\chi.
\]

Equation (8.5) and the modulus bound imply

\[
\boxed{|R(y)|\ge\delta\qquad(y\in I).}
\tag{9.4}
\]

So a macroscopic clearance from the **phase lattice** becomes a macroscopic
spatial additive-resonance defect.

This is the quantitative bridge between v171's lattice clearance and the new
mixed-difference budget.

---

# 10. A trapped slab cannot keep one residue orientation for long

Combine Theorem 7.1 with (9.4).

## Theorem 10.1 -- finite sign-trap length

Suppose on an interval `[X,X+L]`:

1. `dist(C(y),Z)>=chi`;
2. `q` obeys a modulus with `omega(delta)<chi`; and
3. `R` has one sign almost everywhere on the interval.

Then

\[
\boxed{
L\le\frac{8B}{\delta}.
}
\tag{10.1}
\]

### Proof

If `R` has one sign and `|R|>=delta`, then

\[
\left|\int_X^{X+L}R\right|\ge\delta L.
\]

Theorem 7.1 bounds the same integral by `8B`. QED.

Thus persistent residue trapping cannot be supported by one oriented branch for
arbitrarily many consecutive lattice phases.

---

# 11. In a square-free profile, forced sign changes are record arches

At every point `y` where all four functions

\[
g(y),\quad g(y+1),\quad g(y+2),\quad g(y+3)
\]

are continuous, `R` is continuous.

If `R` changes sign through such a point, the intermediate value theorem gives
`R=0`, hence the exact lattice target `(1,3,2)`.

Therefore, in a square-free profile,

\[
\boxed{
\text{every sign change of }R
\text{ must occur at a discontinuity of at least one }g(y+j).
}
\tag{11.1}
\]

But discontinuities of `g` are record return arches.

The right jump of `R` has the exact form

\[
\boxed{
\Delta R(y)
=J(y)+J(y+3)-J(y+1)-J(y+2),
}
\tag{11.2}
\]

where

\[
J(z)=g(z+)-g(z)\ge0.
\]

Hence if a sign switch occurs while the one-sided values satisfy

\[
|R_-|,|R_+|\ge\delta,
\]

then

\[
|\Delta R|\ge2\delta.
\]

Equation (11.2) gives

\[
J(y)+J(y+1)+J(y+2)+J(y+3)\ge2\delta,
\]

so at least one of the four involved record arches has width

\[
\boxed{J\ge\frac\delta2.}
\tag{11.3}
\]

This is substantially stronger than merely saying that folding occurs.

---

# 12. Syndetic macroscopic record arches under uniform clearance

Assume the square-free alternative and a fixed clearance/modulus pair
`(chi,delta)` as above.

If an interval of phase length greater than `8B/delta` contained no sign switch
of `R`, then `R` would have one sign there and Theorem 10.1 would be violated.
Therefore every sufficiently long phase interval contains a sign switch.

By Section 11, each such sign switch is caused by a first-hit jump among four
phase translates.  Consequently the phase levels carrying record arches of
width at least `delta/2` form a syndetic set up to the fixed shift range
`{0,1,2,3}`.

A convenient conservative statement is:

## Theorem 12.1 -- record-arch forcing

Under the assumptions above, every phase interval of length

\[
\boxed{
L_*=\frac{8B}{\delta}+4
}
\tag{12.1}
\]

contains a record-return level `z` with

\[
\boxed{J(z)\ge\frac\delta2,}
\tag{12.2}
\]

unless an exact `(1,3,2)` lattice resonance occurs first.

Thus a uniformly lattice-cleared square-free profile cannot remain a mild
perturbation with only tiny isolated folds.  It must generate macroscopic
record arches at bounded phase spacing.

---

# 13. Compact translates of the forced arches

Suppose in addition the profile has a global common modulus of continuity and
we are in the syndetic-arch branch.  Choose record levels `z_n->+infinity`
with arches

\[
[a_n,b_n],
\qquad
b_n-a_n\ge\delta/2.
\]

Balancedness also gives

\[
b_n-a_n\le2B.
\]

Translate each arch to the origin:

\[
q_n(t)=q(a_n+t)-z_n.
\tag{13.1}
\]

Since `|a_n-z_n|<=B`,

\[
\boxed{|q_n(t)-t|\le2B.}
\tag{13.2}
\]

The common modulus and Arzela--Ascoli give a locally uniformly convergent
subsequence.  After also taking a subsequence of widths,

\[
d_n=b_n-a_n\to d_\infty\in[\delta/2,2B].
\]

The limiting profile `Q` satisfies

\[
Q(0)=Q(d_\infty)=0,
\qquad
Q(t)\le0\quad(0\le t\le d_\infty).
\tag{13.3}
\]

Hence only two compact limits are possible:

1. **plateau limit**:
   \[
   Q\equiv0\text{ on }[0,d_\infty],
   \]
   which re-enters the v157 plateau cell;
2. **persistent return arch**:
   \[
   \min_{[0,d_\infty]}Q<0,
   \]
   giving a nonvanishing-depth macroscopic record arch.

Thus fixed lattice clearance does not permit an amorphous small-fold escape.
It produces one of the already recognizable topological objects.

---

# 14. Relation to the v171 PL half-integer example

The v171 profile `q_d` showed that a **single shrinking return cylinder** can
have

\[
(H_1,H_2)=(1,2)
\]

while its third current remains in

\[
[1/2,1/2+d].
\]

That example does not contradict v172.

Its local return current is centered far from the third lattice, but the global
profile has affine tails.  On an affine tail the first-hit inverse is itself
affine, so

\[
R(y)=0
\]

for all sufficiently remote consecutive phase quadruples.  The profile
therefore has exact global lattice resonances away from the local half-integer
cylinder.

This is precisely why v171 correctly concluded that **local tertiary zooming
cannot solve the residue problem**: one must look at macroscopic residue drift.
The mixed-difference identity (7.1) is such a macroscopic constraint.

---

# 15. What v172 proves

1. The prose ordering `u<s<v<w` in v171 is inconsistent with
   `w=u+v-s`; the correct fourth contact lies between the two outer contacts.
2. The first-hit inverse `g` is strictly increasing, lies within `B` of the
   identity, and jumps exactly at record return arches.
3. Four consecutive phase levels define the exact spatial resonance defect
   \[
   R(y)=g(y)+g(y+3)-g(y+1)-g(y+2).
   \]
4. `R(y)=0` gives the exact, nondegenerate, lattice-aligned `0132` target
   `(1,3,2)`.
5. The defect factors as
   \[
   R=d(y+2)-d(y),\quad d=e(y+1)-e(y),\quad e=g-y.
   \]
6. For any bounded continuous inverse defect, `R` is either identically zero
   or takes both signs; therefore every strictly monotone balanced profile has
   an exact consecutive-level lattice resonance.
7. In the identically resonant case the inverse defect is `2`-periodic.
8. For the nonmonotone first-hit inverse,
   \[
   |\int_X^{X+L}R|\le8B
   \]
   on every phase interval.
9. A fixed third-phase lattice clearance `chi`, together with a modulus
   `omega(delta)<chi`, forces `|R|>=delta`.
10. Such a cleared defect cannot keep one sign over phase length more than
    `8B/delta`.
11. In a square-free profile, sign changes of `R` must occur through first-hit
    jumps, hence through record return arches.
12. A cleared sign switch forces at least one involved record arch to have
    width at least `delta/2`.
13. Therefore fixed lattice clearance forces macroscopic record arches at
    bounded phase spacing, unless an exact lattice resonance occurs.
14. Under compact translated limits these arches produce either a plateau
    limit or a persistent positive-depth return arch.

---

# 16. What remains open

v172 does **not** prove the full conjecture.  The remaining late-stage branches
are now more sharply separated.

## A. Clearance collapse

The third consecutive-level phase may approach an integer arbitrarily closely
without attaining it:

\[
\operatorname{dist}(C(y),\mathbb Z)\to0.
\]

This is the natural **near-resonant** branch.  It should be attacked with a
lattice-aware degree/limit theorem rather than another local current-width
zoom.

## B. Modulus collapse

The profile may lose any uniform inverse modulus on the remote intervals where
residue trapping is tested.  This is precisely the roughness/noncompactness
branch isolated repeatedly since v155 and v170.

## C. Persistent macroscopic record arches

If clearance stays fixed and the modulus remains controlled, v172 forces
syndetic record arches of width bounded below.  A compact translate gives
one of:

- a plateau, already closed by v157; or
- a persistent positive-depth return arch.

The latter should now be revisited with the **integer** consecutive-level
coordinates `(1,3,2)` rather than the small noninteger `eta` used in v170.

## D. Signed cancellation

Even if several lattice-aligned branch currents cross an integer third plane,
signed multicarrier cancellation remains possible in singular chambers.  The
v159 orientation theorem handles finite regular sign-coherent chambers, but the
singular/infinite-current version remains open.

## E. Final transfer

As throughout v149--v171, the final transfer from the normalized phase-profile
statement to an arbitrary Jordan curve still relies on the inherited shrinking
window/profile-extraction hypotheses.

---

# 17. Recommended v173 target

The cleanest next target is the **clearance-collapse branch**.

Define

\[
\rho(y)=C(y)-2
=q(g(y)+g(y+3)-g(y+1))-(y+2).
\]

v172 shows that if `|rho|` stays uniformly away from zero (indeed away from the
whole integer lattice) and the modulus remains controlled, then macroscopic
record arches are forced syndetically.

So the complementary branch has sequences

\[
y_n\to\infty,
\qquad
\rho(y_n)\to0.
\]

The next theorem should ask whether a **near-additive first-hit quadruple**

\[
g(y_n)+g(y_n+3)
-g(y_n+1)-g(y_n+2)\to0
\]

can be upgraded to a protected lattice hit, or whether the failure of such an
upgrade forces a new nontrivial blow-up of the first-hit graph itself.

That is now a much cleaner near-resonance problem than the half-integer local
current studied in v171.
