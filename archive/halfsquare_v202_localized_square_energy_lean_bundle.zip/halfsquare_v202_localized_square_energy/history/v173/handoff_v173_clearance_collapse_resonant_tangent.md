# Project Handoff v173: Clearance Collapse and the 2-Periodic Resonant Tangent

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the v172 clearance-collapse branch and strengthens the first-hit
mixed-difference analysis in three ways.

For a continuous balanced phase profile

\[
q(t)=t+h(t),\qquad |h(t)|\le B,
\]

let

\[
g(y)=\min\{t:q(t)=y\}
\]

be the first-hit inverse.  As before,

\[
|g(y)-y|\le B,
\]

and `g` is strictly increasing but may have upward jumps.  Define

\[
L(y)=g(y+1)-g(y),
\]

and the consecutive-level lattice resonance defect

\[
\boxed{
R(y)=g(y)+g(y+3)-g(y+1)-g(y+2)
=L(y+2)-L(y).
}
\tag{0.1}
\]

The main v173 results are:

1. **Branch-free one-sign rigidity.**  The continuity hypothesis in v172
   Theorem 5.1 is unnecessary.  For *any* strictly increasing `g` with
   `|g(y)-y|<=B`,

   \[
   R\ge0\text{ on }\mathbb R
   \quad\text{or}\quad
   R\le0\text{ on }\mathbb R
   \quad\Longrightarrow\quad
   R\equiv0.
   \]

   Thus every nonzero square-free first-hit defect must take both signs even
   when all sign changes are carried by record-return jumps.

2. **Eventual one-sign tails converge to the exact resonant manifold.**  If,
   for some `Y`, `R>=0` for all `y>=Y` (or `R<=0`), then the phase-translated
   first-hit graphs converge pointwise along shifts by two:

   \[
   G_n(t):=g(t+2n)-2n\longrightarrow G_\infty(t),
   \]

   with

   \[
   \boxed{G_\infty(t+2)=G_\infty(t)+2.}
   \tag{0.2}
   \]

   Equivalently, the limiting first-hit displacement

   \[
   E_\infty(t)=G_\infty(t)-t
   \]

   is 2-periodic.  The generalized inverse tangent satisfies the same
   translation law

   \[
   Q_\infty(x+2)=Q_\infty(x)+2,
   \]

   and has the exact lattice resonance `(1,3,2)` at every base phase.

3. **Compact clearance-collapse dichotomy.**  Suppose `q_n` have a common
   modulus of continuity, `|q_n(t)-t|<=B`, and there are base phases `y_n`
   with third-phase error

   \[
   \rho_n=C_n(y_n)-2\to0.
   \]

   Put

   \[
   x_n=g_n(y_n+2),
   \qquad
   Q_n(t)=q_n(x_n+t)-(y_n+2),
   \qquad
   R_n=R_n(y_n).
   \]

   After a subsequence, `R_n->r` and `Q_n->Q` locally uniformly.  Then

   \[
   Q(0)=Q(r)=0,
   \qquad
   Q(t)\le0\quad(t\le0).
   \]

   Hence either:

   - `r=0`, and the limit contains an **exact 0132 consecutive-level lattice
     quadruple**; or
   - `r!=0`, and the limit contains a **positive-width plateau or positive-depth
     return/co-return excursion**.

So clearance collapse is no longer an unstructured near miss.  Under
compactness it can only approach an exact resonant tangent or create a
macroscopic excursion object.

There is also an important sharpness example.  A family of balanced monotone
profiles with vanishing plateaus can have first-hit defects `R_epsilon` that
never vanish, while

\[
\|g_\varepsilon-\mathrm{id}\|_\infty\to0
\]

and the limit first-hit graph is exactly resonant.  Thus **an exact resonant
limit is not by itself a stable prelimit lattice hit**.  The missing scale is
precisely the vanishing jump/plateau scale.  This identifies the next genuine
obstruction.

---

# 1. Setup and notation

Let

\[
q:\mathbb R\to\mathbb R
\]

be continuous with

\[
\boxed{|q(t)-t|\le B.}
\tag{1.1}
\]

Then every level is hit and the first-hit inverse

\[
\boxed{g(y)=\min q^{-1}(y)}
\tag{1.2}
\]

is strictly increasing with

\[
\boxed{|g(y)-y|\le B.}
\tag{1.3}
\]

Write

\[
e(y)=g(y)-y,
\tag{1.4}
\]

so `|e|<=B`, and define the unit first-hit spacing

\[
\boxed{L(y)=g(y+1)-g(y)=1+e(y+1)-e(y).}
\tag{1.5}
\]

Since `g` is strictly increasing,

\[
L(y)>0.
\tag{1.6}
\]

The v172 consecutive-level defect is

\[
\boxed{
R(y)=g(y)+g(y+3)-g(y+1)-g(y+2).
}
\tag{1.7}
\]

Grouping the terms as consecutive spacings gives the simpler identity

\[
\boxed{R(y)=L(y+2)-L(y).}
\tag{1.8}
\]

Also define the two-step spacing

\[
\boxed{
P(y)=g(y+2)-g(y)=L(y)+L(y+1)
=2+e(y+2)-e(y).
}
\tag{1.9}
\]

Then

\[
\boxed{P(y+2)-P(y)=R(y)+R(y+1).}
\tag{1.10}
\]

These elementary identities drive the entire v173 analysis.

---

# 2. Branch-free one-sign rigidity

v172 proved the global sign theorem for bounded **continuous** first-hit
displacement.  The continuity assumption can be removed completely.

## Theorem 2.1 -- one-sign rigidity for arbitrary first-hit graphs

Let `g:R->R` be strictly increasing and satisfy

\[
|g(y)-y|\le B.
\]

Define `R` by (1.7).  If

\[
R(y)\ge0\qquad\text{for every }y,
\]

then

\[
\boxed{R\equiv0.}
\tag{2.1}
\]

The same conclusion holds if `R<=0` everywhere.

### Proof

Assume `R>=0`.  By (1.10),

\[
P(y+2)\ge P(y)
\tag{2.2}
\]

for every `y`.

Fix `y` and set

\[
a_k=P(y+2k)-2.
\]

Then `(a_k)_{k\in\mathbb Z}` is nondecreasing.  On the other hand,

\[
\sum_{k=0}^{N-1}a_k
=
\sum_{k=0}^{N-1}[e(y+2k+2)-e(y+2k)]
=
e(y+2N)-e(y),
\]

so all forward partial sums are bounded in absolute value by `2B`.  Likewise
all backward partial sums are bounded:

\[
\sum_{k=-N}^{-1}a_k=e(y)-e(y-2N).
\]

If `a_0>0`, monotonicity gives `a_k>=a_0` for all `k>=0`, and the forward
partial sums diverge.  If `a_0<0`, then `a_k<=a_0` for all `k<=0`, and the
backward partial sums diverge.  Hence `a_0=0`.

Since `y` was arbitrary,

\[
\boxed{P(y)=2\quad\text{for every }y.}
\tag{2.3}
\]

Then (1.10) gives

\[
R(y)+R(y+1)=0.
\]

Both terms are nonnegative, so both vanish.  Therefore `R=0` identically.
The `R<=0` case is identical with all inequalities reversed. QED.

## Corollary 2.2 -- every nonzero defect takes both signs

For an arbitrary balanced first-hit inverse, either

\[
\boxed{R\equiv0}
\]

or there exist `y_+,y_-` such that

\[
\boxed{R(y_+)>0>R(y_-).}
\tag{2.4}
\]

No continuity of `g` is required.

Thus v172's sign-balance mechanism is genuinely branch-free.

## Corollary 2.3 -- the exact resonant manifold

If `R=0` identically, then

\[
L(y+2)=L(y).
\]

The same bounded-partial-sum argument gives

\[
P(y)=L(y)+L(y+1)=2.
\]

Hence

\[
\boxed{g(y+2)=g(y)+2}
\tag{2.5}
\]

and therefore

\[
\boxed{e(y+2)=e(y).}
\tag{2.6}
\]

This is the exact first-hit resonant manifold.  It is larger than the affine
profile: any increasing first-hit graph with bounded 2-periodic displacement
belongs to it.

For example, if

\[
g(y)=y+a\sin(\pi y),
\qquad |a|<1/\pi,
\]

then `g` is strictly increasing, nonaffine, and `R=0` identically.

---

# 3. Eventual one-sign tails converge to a 2-periodic resonant tangent

The more important clearance-collapse statement is asymptotic.

## Theorem 3.1 -- eventual sign implies resonant tail tangent

Assume the setup of Theorem 2.1.  Suppose that for some `Y`,

\[
\boxed{R(y)\ge0\qquad(y\ge Y).}
\tag{3.1}
\]

Then for every fixed `t`, the limit

\[
\boxed{
E_\infty(t)=\lim_{n\to\infty}e(t+2n)
}
\tag{3.2}
\]

exists.  The limit is bounded and 2-periodic:

\[
\boxed{E_\infty(t+2)=E_\infty(t).}
\tag{3.3}
\]

Consequently

\[
\boxed{
G_n(t):=g(t+2n)-2n
\longrightarrow
G_\infty(t):=t+E_\infty(t)
}
\tag{3.4}
\]

pointwise at every fixed `t`, and

\[
\boxed{G_\infty(t+2)=G_\infty(t)+2.}
\tag{3.5}
\]

The same conclusion holds with monotonic directions reversed if `R<=0`
eventually.

### Proof

From `R>=0` on the tail and (1.10),

\[
P(y+2)\ge P(y)
\]

for all sufficiently large `y`.  Fix `t`.  Then

\[
P(t+2n)
\]

is eventually nondecreasing and bounded, so it converges to some limit `p`.
But

\[
\sum_{k=0}^{N-1}[P(t+2k)-2]
=e(t+2N)-e(t)
\]

is bounded.  The summands converge to `p-2`, hence necessarily

\[
p=2.
\]

Therefore `P(t+2n)<=2` eventually.  Since

\[
e(t+2n+2)-e(t+2n)=P(t+2n)-2\le0,
\]

the tail sequence `e(t+2n)` is nonincreasing and bounded.  It converges.
The 2-periodicity follows immediately by shifting the index:

\[
E_\infty(t+2)
=
\lim_n e(t+2+2n)
=
E_\infty(t).
\]

Equation (3.5) follows. QED.

## Corollary 3.2 -- convergence of the unit-spacing law

Under Theorem 3.1,

\[
L(t+2n)
\]

is eventually nondecreasing and converges to a 2-periodic limit

\[
\Lambda(t)=G_\infty(t+1)-G_\infty(t)
\]

satisfying

\[
\boxed{\Lambda(t)+\Lambda(t+1)=2.}
\tag{3.6}
\]

Thus the near-resonant tail approaches an alternating unit-spacing law whose
two consecutive spacings always sum to exactly two.

## Corollary 3.3 -- exact lattice resonance in the tangent

For every base phase `y`,

\[
G_\infty(y)+G_\infty(y+3)
-G_\infty(y+1)-G_\infty(y+2)=0.
\]

Hence the generalized inverse tangent is exactly resonant at

\[
(H_1,H_2,H_3)=(1,3,2)
\]

for every base phase.

If `Q_\infty` denotes the generalized inverse of `G_\infty`, then

\[
\boxed{Q_\infty(x+2)=Q_\infty(x)+2.}
\tag{3.7}
\]

So the entire limiting profile is equivariant under the spatial/phase
translation `(t,q)->(t+2,q+2)`.

### Interpretation

A clearance-collapsing tail on which the residue orientation eventually stops
switching cannot develop an arbitrary new profile.  It is forced onto the
2-periodic exact-resonance manifold.

This is the principal structural advance of v173.

---

# 4. If the sign does not settle, return jumps remain unavoidable

Suppose `R` is not identically zero and is not eventually one-signed.
Then both signs recur arbitrarily far out.

At any point where all four translates

\[
g(y),\ g(y+1),\ g(y+2),\ g(y+3)
\]

are continuous, `R` is continuous.  Therefore a square-free profile with
`R(y)!=0` can change sign only through the translated jump set

\[
\mathcal J\cup(\mathcal J-1)\cup(\mathcal J-2)\cup(\mathcal J-3),
\]

where `\mathcal J` is the jump set of `g`.

The exact jump formula from v172 remains

\[
\boxed{
\Delta R(y)
=J(y)+J(y+3)-J(y+1)-J(y+2).
}
\tag{4.1}
\]

Thus every nonsettling square-free tail is carried by an infinite sequence of
record-return events.  There are only two possibilities:

1. some subsequence of involved jump widths stays bounded below, producing the
   macroscopic-return branch already isolated in v172; or
2. every sign-switching jump width tends to zero, producing a genuine
   **vanishing-jump resonance staircase**.

So the clearance-collapse obstruction has the global trichotomy

\[
\boxed{
\begin{array}{c}
\text{eventual sign}\Rightarrow\text{2-periodic resonant tangent},\\[1mm]
\text{recurrent sign switches + macroscopic jumps}\Rightarrow
\text{positive-width return branch},\\[1mm]
\text{recurrent sign switches + vanishing jumps}\Rightarrow
\text{vanishing-jump staircase}.
\end{array}}
\tag{4.2}
\]

This is more informative than the scalar statement `dist(C,Z)->0`.

---

# 5. Compact clearance-collapse dichotomy in the phase profile

The previous sections concern the first-hit graph.  We now return directly to
the third phase.

For a profile `q_n`, define

\[
g_n(y)=\min q_n^{-1}(y),
\]

\[
R_n(y)
=g_n(y)+g_n(y+3)-g_n(y+1)-g_n(y+2),
\]

and

\[
C_n(y)
=q_n\!\left(g_n(y)+g_n(y+3)-g_n(y+1)\right)-y.
\]

Thus

\[
\rho_n(y):=C_n(y)-2.
\tag{5.1}
\]

Assume:

1. `|q_n(t)-t|<=B` for all `n,t`;
2. the `q_n` share a common modulus of continuity `omega`;
3. there are base phases `y_n` such that

   \[
   \boxed{\rho_n(y_n)\to0.}
   \tag{5.2}
   \]

Set

\[
x_n=g_n(y_n+2),
\qquad
r_n=R_n(y_n),
\]

and translate the target first hit to the origin:

\[
\boxed{
Q_n(t)=q_n(x_n+t)-(y_n+2).
}
\tag{5.3}
\]

Because

\[
|x_n-(y_n+2)|\le B,
\]

one has

\[
\boxed{|Q_n(t)-t|\le2B.}
\tag{5.4}
\]

Also

\[
Q_n(0)=0
\tag{5.5}
\]

and, by the first-hit property,

\[
\boxed{Q_n(t)<0\qquad(t<0).}
\tag{5.6}
\]

Finally, the v172 identity gives

\[
\boxed{Q_n(r_n)=\rho_n(y_n).}
\tag{5.7}
\]

Since `|r_n|<=4B`, Arzela--Ascoli gives the following.

## Theorem 5.1 -- compact near-resonance dichotomy

After passing to a subsequence,

\[
r_n\to r\in[-4B,4B]
\]

and

\[
Q_n\to Q
\]

locally uniformly, where

\[
\boxed{Q(0)=Q(r)=0}
\tag{5.8}
\]

and

\[
\boxed{Q(t)\le0\qquad(t\le0).}
\tag{5.9}
\]

Exactly one of the following occurs.

### Case A: `r<0`

Then

\[
Q(r)=Q(0)=0,
\qquad
Q\le0\text{ on }[r,0].
\]

So `[r,0]` is a positive-width lower return object.  It is either a plateau
or contains a positive-depth lower return arch.

### Case B: `r>0`

Again `Q(0)=Q(r)=0`.  If `Q` is identically zero on `[0,r]`, there is a
positive-width plateau.  Otherwise some connected component of

\[
\{t\in(0,r):Q(t)\ne0\}
\]

has endpoints at level zero and fixed sign in its interior.  Hence `Q`
contains a positive-width, positive-depth lower or upper excursion arch.

### Case C: `r=0`

The spatial additive defect itself collapses.  Define the translated first-hit
positions

\[
a_n=g_n(y_n)-x_n,
\]

\[
b_n=g_n(y_n+1)-x_n,
\]

\[
d_n=g_n(y_n+3)-x_n.
\]

They lie in a fixed compact interval and satisfy

\[
Q_n(a_n)=-2,
\quad
Q_n(b_n)=-1,
\quad
Q_n(0)=0,
\quad
Q_n(d_n)=1.
\]

After another subsequence,

\[
a_n\to a,
\qquad
b_n\to b,
\qquad
d_n\to d.
\]

The common modulus prevents distinct phase levels from collapsing to one
spatial point, so

\[
\boxed{a<b<0<d.}
\tag{5.10}
\]

Since

\[
r_n=a_n+d_n-b_n,
\]

we obtain

\[
\boxed{a+d-b=0.}
\tag{5.11}
\]

Therefore the limiting profile has exact contacts

\[
Q(a)=-2,
\quad
Q(b)=-1,
\quad
Q(0)=0,
\quad
Q(d)=1
\]

with

\[
a+d=b+0.
\]

Equivalently, the parameter order is

\[
\boxed{a<b<0<d}
\]

and the fourth contact determined by the first three is exactly `0`, the
`0132` sector.  The phase target is exactly

\[
\boxed{(1,3,2).}
\tag{5.12}
\]

So the `r=0` branch is an **exact lattice-resonant tangent**.

### Consequence

Under a common modulus, clearance collapse has only two compact geometric
outputs:

\[
\boxed{
\text{exact lattice-resonant tangent}
\quad\text{or}\quad
\text{positive-width excursion/plateau tangent}.
}
\tag{5.13}
\]

---

# 6. Why the resonant tangent is not automatically stable

The `r=0` conclusion is strong but not yet sufficient for the original
prelimit problem.  The first-hit equation `R=0` can fail at every prelimit
scale while the first-hit graphs converge uniformly to the identity.

The following explicit family shows the issue.

Let the 4-periodic sequence

\[
E_0=0,
\quad
E_1=0,
\quad
E_2=\frac1{10},
\quad
E_3=\frac15,
\qquad
E_{n+4}=E_n.
\tag{6.1}
\]

For `0<epsilon<1`, put

\[
s_\varepsilon=1-\frac\varepsilon2.
\]

Define a left-continuous strictly increasing function `g_epsilon` by

\[
\boxed{
g_\varepsilon(y)
=n+\varepsilon E_n+s_\varepsilon(y-n),
\qquad n<y\le n+1.
}
\tag{6.2}
\]

At each integer there is an upward jump.  The jump after the `n`th cell is

\[
J_{n+1}
=1-s_\varepsilon
+\varepsilon(E_{n+1}-E_n)
=\varepsilon\left(\frac12+E_{n+1}-E_n\right),
\]

whose four values are

\[
\boxed{
\frac\varepsilon2,
\quad
\frac{3\varepsilon}{5},
\quad
\frac{3\varepsilon}{5},
\quad
\frac{3\varepsilon}{10}.
}
\tag{6.3}
\]

All are positive.  Moreover

\[
\boxed{
\|g_\varepsilon-\mathrm{id}\|_\infty\le\frac\varepsilon2.
}
\tag{6.4}
\]

On the four unit cells the mixed difference takes the values

\[
\boxed{
R_\varepsilon
\in
\left\{
\frac\varepsilon{10},
-\frac{3\varepsilon}{10},
-\frac\varepsilon{10},
\frac{3\varepsilon}{10}
\right\},
}
\tag{6.5}
\]

including the corresponding left-continuous endpoint values.  Hence

\[
\boxed{R_\varepsilon(y)\ne0\quad\text{for every }y.}
\tag{6.6}
\]

Yet

\[
g_\varepsilon\to\mathrm{id}
\]

uniformly, and the limit has `R=0` identically.

Every such `g_epsilon` is the generalized first-hit inverse of a continuous
nondecreasing balanced profile `q_epsilon`; the upward jumps become plateaus of
`q_epsilon`.  The plateaus have widths `O(epsilon)` and vanish in the limit.

This is a sharp warning:

\[
\boxed{
\text{exact resonant tangent}
\not\Longrightarrow
\text{stable prelimit first-hit root}.
}
\tag{6.7}
\]

The example is **not** a counterexample to the square theorem.  Its purpose is
only to show that first-hit resonance can be destroyed by vanishing plateaus
while converging uniformly to an exactly resonant tangent.

Thus the final information lost in the clearance-collapse limit is the scale
and arrangement of the vanishing jumps.

---

# 7. A regular sign-skipping jump can be resolved through its arch

The sharpness example above uses depth-zero plateaus.  Positive-depth regular
return arches behave better.

Here is a local theorem that will be useful in the next stage.

## Theorem 7.1 -- simple-arch sign-skip resolution

Suppose a sign change of the consecutive-level additive defect is carried by a
single phase level `z=y_0+j`, `j in {0,1,2,3}`.  Assume:

1. the jump at `z` comes from a **simple lower return arch** `[a,b]` of depth
   `D>0`, with one continuous decreasing side and one continuous increasing
   side meeting at a unique bottom;
2. for the other three consecutive phase levels there are continuous inverse
   selections throughout the phase interval `[z-D,z]`;
3. the corresponding four-contact configurations stay in the same admissible
   contact sector throughout this continuation; and
4. at the top level `z`, choosing the left versus right endpoint of the return
   arch gives additive defects of opposite sign.

Then some phase `theta in [z-D,z]` and one of the two arch branches gives

\[
\boxed{x_0+x_3-x_1-x_2=0}
\tag{7.1}
\]

with the four exact consecutive phase values

\[
\theta-j,
\quad
\theta-j+1,
\quad
\theta-j+2,
\quad
\theta-j+3.
\]

Hence the corresponding phase target is exactly `(1,3,2)`.

### Proof

Let `S_L(theta)` and `S_R(theta)` be the additive defects obtained by using the
left and right sides of the simple arch, with the other three contacts
continued continuously.  Both are continuous in `theta`.  At the top
`theta=z`, they have opposite signs by assumption.  At the bottom of the arch
the two branch contacts coalesce, so

\[
S_L(z-D)=S_R(z-D).
\]

If this common value is nonnegative, the branch whose top value is negative
crosses zero.  If it is nonpositive, the branch whose top value is positive
crosses zero.  The sector assumption preserves the intended contact order.
QED.

Thus a regular positive-depth sign-skipping return arch cannot be a terminal
obstruction.  A survivor must lose one of the hypotheses: another translated
level branches simultaneously, the arch has a plateau/critical bottom, the
sector degenerates, or the branch structure becomes infinite.

This is the exact-level analogue of the regular-chamber theorem from v159.

---

# 8. Revised clearance-collapse obstruction ledger

Combining the new results gives the following late-stage picture.

Assume the first-hit consecutive-level lattice target is never attained.
Then `R` never vanishes at a valid first-hit quadruple.

By Theorem 2.1, `R` cannot keep one global sign.  On a remote tail, one of the
following must occur.

## Branch I -- eventual sign

If `R` eventually keeps one sign, Theorem 3.1 produces an exact 2-periodic
resonant tangent

\[
G_\infty(y+2)=G_\infty(y)+2.
\]

The remaining obstruction is **stability of this resonant manifold against
vanishing record jumps/plateaus**.

## Branch II -- recurrent sign switches with nonvanishing jumps

Then a subsequence of record-return widths is bounded below.  This is the
macroscopic-arch branch of v172.  Under compactness it produces a plateau or a
positive-depth return arch; regular simple arches are killed by Theorem 7.1.

## Branch III -- recurrent sign switches with vanishing jumps

This is the true staircase branch.  The v173 example shows that vanishing
plateaus can indeed make `R` jump over zero at scale `O(epsilon)` while the
whole first-hit graph tends to an exactly resonant profile.

## Branch IV -- modulus/noncompactness loss

If the translated phase profiles have no common modulus, the compact
near-resonance theorem does not apply.  This remains the tertiary roughness
branch inherited from v155, v164, and v170.

So the former scalar clearance-collapse branch has been replaced by the much
more concrete alternative

\[
\boxed{
\text{2-periodic resonant tangent}
\quad\text{or}\quad
\text{macroscopic return arch}
\quad\text{or}\quad
\text{vanishing-jump staircase}
\quad\text{or}\quad
\text{roughness}.
}
\tag{8.1}
\]

---

# 9. What v173 proves

1. `R=L(y+2)-L(y)` with `L(y)=g(y+1)-g(y)`.
2. `P(y)=g(y+2)-g(y)` satisfies
   `P(y+2)-P(y)=R(y)+R(y+1)`.
3. For arbitrary strictly increasing balanced first-hit graphs, one global sign
   of `R` forces `R=0` identically.  Continuity is unnecessary.
4. `R=0` identically is equivalent to the exact translation law
   `g(y+2)=g(y)+2`.
5. If `R` is eventually one-signed, phase translations by `2n` converge
   pointwise to a 2-periodic first-hit displacement.
6. The limiting generalized inverse profile satisfies
   `Q_infty(t+2)=Q_infty(t)+2` and is exactly `(1,3,2)` resonant at every base
   phase.
7. Under a common modulus, any sequence with `C_n(y_n)->2` has a compact
   subsequence in which either the spatial additive defect tends to zero or a
   positive-width equal-level excursion survives.
8. If the spatial defect tends to a nonzero number, the limit contains a
   plateau or positive-depth lower/upper return arch.
9. If the spatial defect tends to zero, the limit contains an exact 0132
   consecutive-level lattice quadruple.
10. Exact tangent resonance is not stable under `C^0` convergence of first-hit
    graphs: the explicit vanishing-plateau family `g_epsilon` has no first-hit
    zero of `R` while converging uniformly to the identity.
11. In that example both the resonance defect and plateau widths are `O(eps)`.
12. A regular simple positive-depth return arch whose two endpoint choices skip
    across zero can be resolved through the arch to an exact consecutive-level
    additive relation.

---

# 10. What remains open

v173 still does **not** prove the full conjecture.

## A. Stability of the 2-periodic resonant tangent

This is now the cleanest compact clearance-collapse blocker.  A sequence may
converge to

\[
G_\infty(y+2)=G_\infty(y)+2
\]

while tiny plateaus or return arches make every prelimit first-hit defect skip
over zero.

A proof must use more than uniform convergence.  It has to retain the signed
jump data at the vanishing-jump scale.

## B. Vanishing-jump staircase

The explicit example in Section 6 shows the correct scale.  One should
normalize by a jump size `epsilon_n` and study the graph of

\[
\frac{g_n(y)-G_\infty(y)}{\epsilon_n}
\]

together with the jump measure of `g_n`.  The expected terminal object is a
periodic signed staircase whose four translated jump measures determine the
normalized defect.

## C. Singular positive-depth arches

Theorem 7.1 kills only a regular isolated simple arch.  Simultaneous translated
branching, critical bottoms, plateaus, and infinite branch accumulation remain.
This connects directly back to v159--v162.

## D. Roughness / noncompactness

As before, loss of a common modulus bypasses the compact near-resonance
argument and returns to the pressure/roughness branches from v163--v167.

## E. Final Jordan transfer

The inherited shrinking-window/profile-extraction step remains outside the
scope of this continuation.

---

# 11. Recommended v174 target

The cleanest next object is the **vanishing-jump perturbation of the resonant
manifold**.

Suppose

\[
G_n\to G_\infty,
\qquad
G_\infty(y+2)=G_\infty(y)+2,
\]

and let `epsilon_n` be the largest relevant first-hit jump on one four-phase
cell.  Define

\[
\boxed{
Z_n(y)=\frac{G_n(y)-G_\infty(y)}{\epsilon_n}.
}
\tag{11.1}
\]

Then

\[
\frac{R_n(y)}{\epsilon_n}
=Z_n(y)+Z_n(y+3)-Z_n(y+1)-Z_n(y+2).
\tag{11.2}
\]

The next theorem should classify possible nonzero limits of this normalized
mixed difference when `Z_n` comes from monotone first-hit graphs with positive
jump measures.

The key question is:

\[
\boxed{
\text{Can a bounded monotone-compatible periodic staircase have its four-point
mixed difference avoid zero everywhere?}
}
\tag{11.3}
\]

The Section 6 example shows that the answer is **yes** if one looks only at the
first-hit graph.  Therefore the missing ingredient must be the geometry of the
underlying continuous profile across those jump plateaus/return arches.  v174
should carry both the normalized staircase and its excursion filling, not just
`g`.

That is now a sharply defined terminal-scale problem rather than a vague
clearance collapse.
