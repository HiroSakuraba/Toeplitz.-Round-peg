# Project Handoff v174: Record-Envelope Resonance and Excursion Synchronization

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the v173 vanishing-jump staircase at the piece of information v173
showed was missing: the continuous excursion geometry filling the jumps of the
first-hit inverse.

The central correction is that the first-hit staircase cannot be analyzed by
its jump graph alone.  For a continuous profile, every first-hit jump is the
shadow of a record excursion, and the running-record envelope retains a
monotone object whose level fibers are whole intervals.  That extra interval
geometry is strong enough to prove an exact lattice theorem for every
continuous nondecreasing balanced profile, including profiles with arbitrary
plateaus.

For a general nonmonotone profile the same argument produces an exact **spatial
resonance on the running-record envelope**.  The only obstruction to turning
that resonance into an actual consecutive-level phase resonance is a mismatch
between four excursion depths sampled inside the corresponding record
plateaus.  This gives a precise terminal-scale object for the staircase branch.

The main v174 results are:

1. **Exact lattice resonance for every monotone balanced profile.**  If
   `Q:R->R` is continuous, nondecreasing, and `|Q(t)-t|<=B`, then there are
   `y` and

   \[
   x_0<x_1<x_3<x_2
   \]

   such that

   \[
   Q(x_0)=y,\quad Q(x_1)=y+1,\quad Q(x_3)=y+2,\quad Q(x_2)=y+3,
   \]

   and

   \[
   \boxed{x_0+x_2=x_1+x_3.}
   \]

   This includes arbitrary plateaus.  In particular, the explicit monotone
   vanishing-plateau staircase from v173 is **not** an obstruction once the
   plateau filling is retained.

2. **Record-envelope resonance for every balanced continuous profile.**  For

   \[
   q(t)=t+h(t),\qquad |h(t)|\le B,
   \]

   let

   \[
   M(t)=\max_{s\le t}q(s).
   \]

   Then `M` is continuous, nondecreasing, and `|M(t)-t|<=B`.  Applying the
   monotone theorem to `M` gives four record-plateau points satisfying the
   exact spatial additive relation.

3. **Excursion-deficit formula.**  If the envelope resonance is at levels
   `y,y+1,y+2,y+3` and the selected points are `x_j`, define

   \[
   \delta_j=M(x_j)-q(x_j)\ge0.
   \]

   Then the actual phase vector of `q` is

   \[
   \boxed{
   \bigl(
   1+\delta_0-\delta_1,
   3+\delta_0-\delta_3,
   2+\delta_0-\delta_2
   \bigr).
   }
   \]

   Hence the envelope resonance is an actual `(1,3,2)` lattice resonance iff

   \[
   \boxed{\delta_0=\delta_1=\delta_2=\delta_3.}
   \]

   The missing staircase datum is therefore not an abstract jump measure: it
   is the **relative excursion depth** of the four synchronized contacts.

4. **Common interpolation parameter.**  At a sign-skipping monotone-envelope
   jump, the four resonance points may be chosen with one common parameter

   \[
   x_j(t)=(1-t)a_j+t b_j,
   \]

   where `[a_j,b_j]` is the corresponding record plateau.  The spatial defect
   is affine in `t`.  Thus the four excursion filling profiles

   \[
   \phi_z(t)=z-q((1-t)a(z)+t b(z))
   \]

   are sampled at the **same relative horizontal position** `t=t_*`.

5. **Exact synchronized-slice formulation.**  For a record plateau
   `I_j=[a_j,b_j]` at level `z_j=y+j`, define

   \[
   A_j(d)=\{x\in I_j:q(x)=z_j-d\}.
   \]

   An actual consecutive-level resonance carried by those four record
   excursions exists exactly when, for some common depth `d`,

   \[
   \boxed{
   0\in A_0(d)+A_3(d)-A_1(d)-A_2(d).
   }
   \]

6. **Equal-depth simple arches cannot obstruct.**  Suppose the four record
   excursions are simple arches, each with a unique bottom, and all four have
   the same depth `D`.  Then the envelope resonance forces an actual
   consecutive-level resonance of `q`.  At depth zero, zero lies in the convex
   hull of the 16 endpoint defects.  At the common bottom all 16 continuous
   branch defects coalesce.  One branch must cross zero.

7. **Unequal depth is a real obstruction.**  The equal-depth theorem cannot be
   extended by a naive continuity argument.  An explicit four-tent branch
   model has zero in the top convex hull while none of its 16 synchronized
   branch defects crosses zero before the shallowest arch reaches its bottom.

8. **Shallowest-bottom survival inequality.**  For simple arches, let
   `D_* = min_j D_j`.  If there is no actual resonance for
   `0<=d<=D_*`, then zero must remain strictly inside the convex hull of the
   branch defects at `d=D_*`.  If `c_j(d)` and `w_j(d)` are the center and
   left-right separation of the `j`th slice and

   \[
   C(d)=c_0(d)+c_3(d)-c_1(d)-c_2(d),
   \]

   then

   \[
   \boxed{
   |C(D_*)|<\frac12\sum_{j:D_j>D_*}w_j(D_*).
   }
   \]

   Thus a survivor must retain enough horizontal width in the **deeper**
   excursions when the shallowest one collapses.  This is the precise
   depth-desynchronization condition missing from v173.

The v174 frontier is therefore not “classify all staircases.”  The staircase
has been replaced by a finite synchronized-excursion problem: an exact
record-envelope resonance exists, and failure of the actual lattice target
requires the four return fillings to desynchronize in depth strongly enough
that deeper arches still carry the zero-straddling width after the shallowest
arch disappears.

---

# 1. Setup

Let

\[
q:\mathbb R\to\mathbb R
\]

be continuous with

\[
\boxed{|q(t)-t|\le B.}
\tag{1.1}
\]

The v173 first-hit inverse is

\[
g(y)=\min q^{-1}(y).
\tag{1.2}
\]

The v173 consecutive-level spatial resonance defect is

\[
R_g(y)=g(y)+g(y+3)-g(y+1)-g(y+2).
\tag{1.3}
\]

If `R_g(y)=0`, the four first-hit contacts have phase target `(1,3,2)` and
satisfy the additive contact relation.

v173 proved that for every strictly increasing `g` with `|g(y)-y|<=B`, a
global one-sign condition on `R_g` forces `R_g=0` identically.  Therefore if a
first-hit root never occurs, `R_g` must take both signs and sign changes must be
carried by jumps of `g`.

The v173 sharpness example showed that the first-hit graph can indeed jump over
zero at every prelimit scale.  The key point of v174 is that such a jump graph
is not the whole continuous profile.

---

# 2. Monotone profiles: every skipped first-hit zero is filled exactly

We first isolate the case in which the profile itself is monotone.

## Theorem 2.1 -- exact consecutive-level resonance for monotone balanced profiles

Let

\[
Q:\mathbb R\to\mathbb R
\]

be continuous and nondecreasing, with

\[
|Q(t)-t|\le B.
\]

Then there exist `y in R` and points

\[
x_0<x_1<x_3<x_2
\]

such that

\[
Q(x_0)=y,
\qquad
Q(x_1)=y+1,
\qquad
Q(x_3)=y+2,
\qquad
Q(x_2)=y+3,
\tag{2.1}
\]

and

\[
\boxed{x_0+x_2=x_1+x_3.}
\tag{2.2}
\]

### Proof

For each phase `z`, the level fiber of a continuous nondecreasing proper map is
a compact interval

\[
Q^{-1}(z)=[a(z),b(z)].
\tag{2.3}
\]

The left endpoint `a(z)` is strictly increasing and satisfies

\[
|a(z)-z|\le B.
\tag{2.4}
\]

Define

\[
R_a(y)=a(y)+a(y+3)-a(y+1)-a(y+2).
\tag{2.5}
\]

If `R_a(y)=0` for some `y`, choose the four left endpoints and we are done.

Assume instead that `R_a` never vanishes.  By the branch-free sign theorem of
v173, `R_a` takes both signs.  Because `a` is monotone, it has one-sided limits
everywhere, so `R_a` is regulated.  Hence there is a phase `y_*` at which the
sign changes through a jump.  For a continuous nondecreasing `Q`,

\[
a(z+)=b(z).
\tag{2.6}
\]

Therefore the two one-sided mixed differences at `y_*` are

\[
R_-=a_0+a_3-a_1-a_2,
\tag{2.7}
\]

and

\[
R_+=b_0+b_3-b_1-b_2,
\tag{2.8}
\]

where

\[
a_j=a(y_*+j),\qquad b_j=b(y_*+j).
\]

They have opposite signs.

For `0<=t<=1`, put

\[
x_j(t)=(1-t)a_j+t b_j.
\tag{2.9}
\]

Since the whole interval `[a_j,b_j]` is a level fiber,

\[
Q(x_j(t))=y_*+j.
\tag{2.10}
\]

The additive defect is

\[
D(t)=x_0(t)+x_3(t)-x_1(t)-x_2(t)
=(1-t)R_-+tR_+.
\tag{2.11}
\]

Thus some `t_*` has `D(t_*)=0`.  Because the four phase values are strictly
ordered, monotonicity gives the required spatial order.  QED.

### Consequence for v173

The explicit staircase in v173 Section 6 is the generalized inverse of a
continuous **nondecreasing** profile whose jumps are filled by plateaus.  Its
first-hit mixed difference never vanishes, but Theorem 2.1 shows that the full
profile nevertheless has an exact consecutive-level resonance.  The skipped
first-hit value is filled by the plateau product.

So the v173 example remains a valid warning about first-hit stability, but it
is not a terminal obstruction once the filling is retained.

---

# 3. The running-record envelope of a general profile

For a general nonmonotone `q`, define

\[
\boxed{M(t)=\max_{s\le t}q(s).}
\tag{3.1}
\]

## Lemma 3.1 -- envelope bounds

`M` is continuous and nondecreasing, and

\[
\boxed{|M(t)-t|\le B.}
\tag{3.2}
\]

### Proof

Because `q` is continuous and proper toward `-infinity`, the running maximum is
attained and varies continuously.  Monotonicity is immediate.  Also

\[
M(t)\ge q(t)\ge t-B,
\]

while for every `s<=t`,

\[
q(s)\le s+B\le t+B,
\]

so `M(t)<=t+B`.  QED.

Theorem 2.1 applies to `M`.

## Theorem 3.2 -- exact record-envelope spatial resonance

There exist `y` and

\[
x_0<x_1<x_3<x_2
\]

such that

\[
M(x_0)=y,
\quad
M(x_1)=y+1,
\quad
M(x_3)=y+2,
\quad
M(x_2)=y+3,
\tag{3.3}
\]

and

\[
\boxed{x_0+x_2=x_1+x_3.}
\tag{3.4}
\]

This theorem is completely general under (1.1).

The obstruction is now visible: points in a plateau of `M` need not be points
where `q=M`.  They may lie inside a record excursion where `q` has fallen below
its previous record.

---

# 4. Excursion deficits are the exact missing phase data

At an envelope resonance from Theorem 3.2 define

\[
\boxed{\delta_j=M(x_j)-q(x_j)\ge0.}
\tag{4.1}
\]

The convention is that `j=0,1,2,3` refers to the phase levels
`y,y+1,y+2,y+3`, while the geometric contact labels are `x_0,x_1,x_3,x_2`.

Thus

\[
q(x_0)=y-\delta_0,
\]

\[
q(x_1)=y+1-\delta_1,
\]

\[
q(x_3)=y+2-\delta_2,
\]

\[
q(x_2)=y+3-\delta_3.
\tag{4.2}
\]

Because the spatial additive relation already holds, the actual relative phase
vector is

\[
\boxed{
\mathcal H_q
=
\bigl(
1+\delta_0-\delta_1,
3+\delta_0-\delta_3,
2+\delta_0-\delta_2
\bigr)
}
\tag{4.3}
\]

if the components are ordered as `(x1-x0 phase, x2-x0 phase, x3-x0 phase)`.
Equivalently, using the phase-indexed deficits `(delta_0,delta_1,delta_2,delta_3)`,

\[
\boxed{
(H_1,H_2,H_3)
=
(1+\delta_0-\delta_1,
3+\delta_0-\delta_3,
2+\delta_0-\delta_2).
}
\tag{4.4}
\]

Hence

\[
\boxed{
\delta_0=\delta_1=\delta_2=\delta_3
\Longleftrightarrow
(H_1,H_2,H_3)=(1,3,2).
}
\tag{4.5}
\]

Since

\[
0\le M(t)-q(t)\le2B,
\tag{4.6}
\]

the four deficits always lie in a compact interval.

Define their spread

\[
\operatorname{spr}(\delta)
=\max_j\delta_j-\min_j\delta_j.
\tag{4.7}
\]

Then

\[
\max_{j=1,2,3}|\delta_j-\delta_0|
\le \operatorname{spr}(\delta)
\le
2\max_{j=1,2,3}|\delta_j-\delta_0|.
\tag{4.8}
\]

Therefore a fixed sup-norm clearance `chi` from the lattice target `(1,3,2)`
at every envelope resonance implies

\[
\boxed{\operatorname{spr}(\delta)\ge\chi.}
\tag{4.9}
\]

This is the first exact formulation of **excursion-depth desynchronization**.

---

# 5. Common interpolation parameter and the filling profiles

Let

\[
I(z)=M^{-1}(z)=[a(z),b(z)].
\tag{5.1}
\]

For every record level `z`, define the filling profile

\[
\boxed{
\phi_z(t)
=z-q\bigl((1-t)a(z)+t b(z)\bigr),
\qquad 0\le t\le1.
}
\tag{5.2}
\]

Because `M=z` throughout `[a(z),b(z)]`,

\[
\phi_z(t)\ge0,
\qquad
\phi_z(0)=\phi_z(1)=0.
\tag{5.3}
\]

At a sign-skipping event in the proof of Theorem 2.1, the envelope resonance is
obtained with one common interpolation parameter `t_*`:

\[
x_j=(1-t_*)a(y+j)+t_*b(y+j).
\tag{5.4}
\]

Therefore

\[
\boxed{
\delta_j=\phi_{y+j}(t_*).
}
\tag{5.5}
\]

The v173 staircase data consisted essentially of the four plateau widths
`b(y+j)-a(y+j)`.  v174 shows that the missing terminal datum is the four-vector

\[
\boxed{
\bigl(
\phi_y(t_*),
\phi_{y+1}(t_*),
\phi_{y+2}(t_*),
\phi_{y+3}(t_*)
\bigr).
}
\tag{5.6}
\]

An actual lattice resonance occurs exactly when this vector lies on the
diagonal of `R^4`.

---

# 6. Exact synchronized-depth formulation

The interpolation parameter is useful for identifying the obstruction, but the
actual profile sees **common phase depth**, not common horizontal fraction.

For a fixed envelope resonance at levels

\[
z_j=y+j,
\]

let

\[
I_j=[a_j,b_j]=M^{-1}(z_j).
\]

Define the depth slices

\[
\boxed{
A_j(d)=\{x\in I_j:q(x)=z_j-d\},
\qquad d\ge0.
}
\tag{6.1}
\]

If `x_j in A_j(d)` for all four `j`, then the four actual `q`-phases are

\[
y-d,
\quad
y+1-d,
\quad
y+2-d,
\quad
y+3-d,
\]

so their relative phases are exactly consecutive integers.

Hence the record excursions carry an actual lattice resonance precisely when

\[
\boxed{
0\in A_0(d)+A_3(d)-A_1(d)-A_2(d)
}
\tag{6.2}
\]

for some common `d`.

This is the terminal-scale synchronization equation that the first-hit graph
alone cannot see.

---

# 7. Equal-depth simple arches always synchronize

We now obtain a genuine closure theorem for a nontrivial class of return
fillings.

Call a record excursion `I_j=[a_j,b_j]` a **simple lower arch of depth `D_j`**
if there is a unique point `m_j in (a_j,b_j)` such that

\[
q(m_j)=z_j-D_j,
\]

`q` decreases strictly from `a_j` to `m_j`, and increases strictly from `m_j`
to `b_j`.

For `0<=d<D_j`, the slice `A_j(d)` then has exactly two points

\[
\ell_j(d)<r_j(d),
\]

which vary continuously with `d`, and at the bottom

\[
\ell_j(D_j)=r_j(D_j)=m_j.
\]

## Theorem 7.1 -- equal-depth simple-arch synchronization

Suppose the four record excursions selected by an envelope resonance are
simple and

\[
D_0=D_1=D_2=D_3=D.
\tag{7.1}
\]

Then there is an actual consecutive-level resonance of `q` carried by those
four excursions.

### Proof

At depth `d=0`, each `A_j(0)` contains the two record-plateau endpoints
`a_j,b_j`.  The envelope resonance says

\[
0\in I_0+I_3-I_1-I_2.
\tag{7.2}
\]

The latter set is an interval whose extrema occur at endpoint choices.
Therefore among the 16 top endpoint defects

\[
S_\sigma(0)
=x_0+x_3-x_1-x_2,
\qquad
x_j\in\{a_j,b_j\},
\]

there are values of opposite sign unless one already vanishes.

For each of the 16 left/right choices `sigma`, continue the corresponding
branches synchronously to depth `d`.  This gives a continuous function

\[
S_\sigma:[0,D]\to\mathbb R.
\]

At the common bottom all branches coalesce, so

\[
S_\sigma(D)=C
\]

for the same number `C`, independently of `sigma`.

If `C>0`, choose a top branch with `S_sigma(0)<0`; it crosses zero.  If `C<0`,
choose a positive top branch.  If `C=0`, the common bottom itself is a root.
In every case (6.2) holds for some common depth.  QED.

Thus **equal excursion depth is not a staircase obstruction**.

---

# 8. Unequal depth is genuinely different

The previous theorem cannot be extended by simply replacing equality of depths
with comparability.

For a simple arch define

\[
c_j(d)=\frac{\ell_j(d)+r_j(d)}2,
\qquad
w_j(d)=r_j(d)-\ell_j(d).
\tag{8.1}
\]

For a fixed common depth `d`, the 16 branch defects have convex hull

\[
\boxed{
J(d)
=
\left[
C(d)-\frac12W(d),
C(d)+\frac12W(d)
\right],
}
\tag{8.2}
\]

where

\[
C(d)=c_0(d)+c_3(d)-c_1(d)-c_2(d),
\tag{8.3}
\]

and

\[
W(d)=w_0(d)+w_1(d)+w_2(d)+w_3(d).
\tag{8.4}
\]

The envelope resonance guarantees

\[
0\in J(0).
\tag{8.5}
\]

Let

\[
D_*=\min_jD_j.
\tag{8.6}
\]

## Theorem 8.1 -- shallowest-bottom survival inequality

Assume no branch defect vanishes for any

\[
0\le d\le D_*.
\]

Then

\[
\boxed{0\in\operatorname{int}J(d)
\quad\text{for every }0\le d\le D_*.}
\tag{8.7}
\]

In particular,

\[
\boxed{
|C(D_*)|
<
\frac12\sum_{j:D_j>D_*}w_j(D_*).
}
\tag{8.8}
\]

### Proof

The 16 branch defects are continuous on `[0,D_*]`, hence the minimum and
maximum of those finitely many functions are continuous.  At `d=0`, zero lies
between them by (8.5).  If zero left the convex hull at some first depth, then
at the exit depth either the minimum or maximum branch value would be exactly
zero, contradicting the no-root assumption.  Therefore zero stays in the
interior throughout.  At `D_*`, every arch whose depth equals `D_*` has
`w_j(D_*)=0`, giving (8.8).  QED.

This is the precise finite-dimensional form of **depth desynchronization**:
when the shallowest excursion collapses, the deeper excursions must still
retain enough horizontal separation to straddle the additive relation.

### Corollary 8.2 -- common-depth recovery

If all four depths equal `D_*`, the right side of (8.8) is zero, impossible.
Thus Theorem 8.1 immediately recovers Theorem 7.1.

### Corollary 8.3 -- smaller-scale alternative

Let `epsilon_n` be the top horizontal jump scale.  If

\[
\sum_{j:D_{j,n}>D_{*,n}}w_{j,n}(D_{*,n})=o(\epsilon_n),
\]

then every no-root sequence must satisfy

\[
\boxed{|C_n(D_{*,n})|=o(\epsilon_n).}
\tag{8.9}
\]

So if the deeper arches have almost collapsed by the time the shallowest one
reaches its bottom, failure of exact synchronization produces a **new smaller
spatial resonance scale**.

---

# 9. Explicit unequal-depth branch model

To verify that Theorem 8.1 identifies a real phenomenon rather than a proof
artifact, consider four symmetric simple-arch models with fixed centers and
linearly shrinking widths

\[
w_j(d)=W_j\left(1-\frac d{D_j}\right),
\qquad 0\le d\le D_*.
\tag{9.1}
\]

Take

\[
C=-0.6608978677929342,
\]

\[
(W_0,W_1,W_2,W_3)
=
(0.15044483216697024,
0.78917697133121,
0.7413595899383292,
0.9137436541638764),
\]

and

\[
(D_0,D_1,D_2,D_3)
=
(1,
7.11541438766307,
2.2000860417813355,
4.200234546952954).
\]

At depth zero the 16 branch defects have range approximately

\[
[-1.95826,\ 0.636465],
\]

so zero lies well inside their convex hull.  Nevertheless every one of the 16
individual affine branch-defect functions keeps a fixed nonzero sign on
`0<=d<=1`; the minimum endpoint margin is approximately

\[
0.104895.
\]

Thus no synchronized branch crosses zero before the shallowest arch collapses.

This is an abstract local branch model, not a global Toeplitz counterexample.
Its role is to prove that **unequal depth can genuinely disconnect the simple
continuation argument**.  A correct proof must use the residual deeper-arch
structure after the shallowest bottom rather than assume all branch choices
coalesce together.

---

# 10. What v174 proves

1. Every continuous nondecreasing balanced profile has an exact consecutive
   `(1,3,2)` lattice resonance.
2. The proof remains valid with arbitrary plateaus and requires no derivative
   assumptions.
3. The v173 monotone vanishing-plateau staircase is therefore killed once its
   plateau filling is retained.
4. The running-record envelope `M` of every continuous balanced profile is
   continuous, nondecreasing, and balanced with the same constant `B`.
5. Every balanced profile therefore has an exact **record-envelope spatial
   resonance** at four consecutive envelope levels.
6. The actual phase error at that spatial resonance is exactly controlled by
   four excursion deficits `delta_j=M-q`.
7. Equality of the four deficits is equivalent to the exact `(1,3,2)` phase
   target.
8. At a sign-skipping envelope resonance, the four deficits are samples of
   four record-excursion filling profiles at one common horizontal interpolation
   parameter.
9. Exact actual resonance inside the four record plateaus is equivalent to a
   common-depth sumset condition
   `0 in A0(d)+A3(d)-A1(d)-A2(d)`.
10. Four simple record arches of equal depth always satisfy that condition.
11. If simple arches have unequal depths and no exact root before the shallowest
    bottom, zero must remain strictly inside the branch-defect convex hull at
    that bottom.
12. This forces the remaining deeper arches to retain quantitatively nonzero
    horizontal width, according to (8.8).
13. An explicit unequal-depth four-tent model shows that this residual-width
    obstruction is genuine.

---

# 11. Corrections to the v173 obstruction picture

v173 correctly showed that a first-hit staircase can avoid `R=0` while
converging to an exact resonant tangent.  v174 sharpens the interpretation.

## A. Pure monotone plateaus are no longer an obstruction

A jump-only first-hit model is incomplete.  If the jump is filled by a plateau
of a monotone profile, the skipped additive value is filled continuously and
an exact lattice resonance exists.

## B. The real staircase datum is a synchronized excursion profile

For a nonmonotone profile the running-record envelope always contains the
monotone resonance.  The escape mechanism is that the four selected contacts
sit at **different depths below their four record levels**.

## C. Equal-depth simple excursions are also closed

Even genuine positive-depth arches do not obstruct if their bottoms are
synchronized.

## D. Unequal depth creates a new finite-scale hierarchy

A survivor must preserve zero-straddling horizontal width in deeper arches
when the shallowest one disappears.  If that residual width also collapses, a
new smaller spatial resonance scale appears.

Thus the former phrase “vanishing-jump staircase” should now be replaced by

\[
\boxed{
\text{record-envelope resonance}
\;\longrightarrow\;
\text{excursion-depth desynchronization}
\;\longrightarrow\;
\text{residual deeper-arch width or smaller resonance scale}.
}
\tag{11.1}
\]

---

# 12. What remains open

v174 still does **not** prove the full conjecture.

## A. Unequal-depth synchronized excursions

Theorem 8.1 gives a necessary survival inequality but does not continue the
configuration after the shallowest arch reaches its bottom.  The corresponding
phase level still exists globally, but the local record excursion no longer
contains it.  Continuing it may require a spatial jump to another level-set
component.

## B. Singular/non-simple excursion fillings

Multiple bottoms, plateaus inside a return arch, infinitely many local extrema,
and accumulation of excursion components remain.  These reconnect to the
v159--v162 multivalued-current machinery.

## C. Repeated depth-scale loss

Corollary 8.3 identifies a smaller spatial resonance scale when the residual
width at the shallowest bottom tends to zero.  It remains to prove that this
scale descent cannot iterate indefinitely without entering the roughness
regime already isolated in v155/v164.

## D. Noncompact roughness

Loss of a common modulus remains outside the compact staircase analysis.

## E. Final Jordan transfer

The inherited profile-extraction and shrinking-window transfer to the original
Jordan curve remain separate.

---

# 13. Recommended v175 target

The cleanest next target is a **post-bottom continuation theorem**.

At a simple four-arch envelope resonance, let `D_*` be the smallest excursion
depth.  If no exact resonance occurs before `D_*`, Theorem 8.1 shows that the
remaining deeper arches still straddle zero at the bottom phase.

The missing contact at the shallow level must then relocate to another
component of the same exact phase level when the base phase is lowered further.
The next theorem should classify that relocation:

\[
\boxed{
\text{shallow-bottom relocation}
\Longrightarrow
\begin{cases}
\text{exact lattice degree},\\
\text{a new macroscopic record arch},\\
\text{or a strictly smaller synchronized resonance scale}.
\end{cases}
}
\tag{13.1}
\]

A useful object is the full level-set correspondence

\[
\mathcal A_j(d)=q^{-1}(y+j-d)
\]

rather than only the local record slice `A_j(d)`.  The local slice disappears
at `D_*`, but the global correspondence never does.  The topology of the jump
from the local bottom to the next global component is exactly where the v159
signed-current and v161 record-envelope formalisms should re-enter.

This is now a finite, geometrically explicit continuation problem.  The first-
hit staircase itself is no longer the terminal object.
