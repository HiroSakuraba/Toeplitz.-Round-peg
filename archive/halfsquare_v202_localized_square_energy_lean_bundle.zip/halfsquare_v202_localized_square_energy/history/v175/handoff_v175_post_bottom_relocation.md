# Project Handoff v175: Post-Bottom Relocation and Clearance Descent

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the precise finite-scale obstruction left by v174: four synchronized
record excursions have unequal depths, the shallowest excursion reaches its
bottom without producing the consecutive-level additive relation, and the
remaining deeper excursions still straddle zero.

The main point of v175 is that the shallow contact does not simply disappear at
its bottom.  For a balanced degree-one profile it is forced to **relocate** to
another component of the same phase level.  In the regular finite-component
case, the relocation is an actual upper co-return arch.  Combining this with
the sign cube left by v174 gives a quantitative post-bottom trichotomy:

\[
\boxed{
\text{post-bottom survival}
\Longrightarrow
\begin{cases}
\text{exact lattice resonance},\\
\text{a macroscopic same-level relocation arch},\\
\text{or a strictly smaller spatial-resonance clearance.}
\end{cases}}
\tag{0.1}
\]

The last alternative feeds directly back into the v172--v173 clearance-collapse
machinery.  Thus the regular unequal-depth branch no longer ends at the first
bottom; it either creates another macroscopic arch or descends in resonance
scale.

The main v175 results are:

1. **Bottom relocation is unavoidable.**  If `m` is a strict local minimum of
   a balanced continuous profile `q`, with `q(m)=lambda`, then there is a last
   point `p<m` with `q(p)=lambda`, and

   \[
   q(x)>\lambda\qquad(p<x<m).
   \]

   Hence `[p,m]` is an upper co-return arch.

2. **The relocation width is quantitatively visible.**  If `m` is the bottom
   of a lower arch whose top level is `z` and depth is `D=z-lambda`, then its
   left top endpoint `a` satisfies `p<a<m`.  Therefore

   \[
   m-p>m-a.
   \]

   For a common modulus of continuity `omega`,

   \[
   D\le \omega(m-a),
   \]

   so

   \[
   \boxed{m-p\ge r_\omega(D)},
   \qquad
   r_\omega(D):=\inf\{r>0:\omega(r)\ge D\}.
   \tag{0.2}
   \]

   Thus a depth bounded below forces a relocation arch of width bounded below.

3. **A sign-changing cube edge always survives at the shallowest bottom.**  At
   `d=D_*`, v174 shows the branch-defect hypercube has both positive and
   negative vertices.  Since a hypercube graph is connected, some adjacent
   pair differs in exactly one deeper excursion and satisfies

   \[
   A_*<0<B_*.
   \tag{0.3}
   \]

4. **Common-jump straddle lemma.**  Continue the two configurations together.
   Their only difference is left-versus-right choice on one deeper simple
   arch.  Hence their separation shrinks continuously to zero at that arch's
   bottom, while every relocation of the other three contacts shifts both
   additive defects by the same amount.  For

   \[
   0<\eta<\min(-A_*,B_*),
   \]

   either one defect hits zero, some common relocation jump has magnitude at
   least `eta`, or one defect comes within `eta` of zero before coalescence.

5. **Large common jump means a large level arch.**  In the regular
   nearest-component continuation, each contact jump is a genuine same-level
   return/co-return arch.  If three common coordinates jump simultaneously and
   the total additive jump has magnitude at least `eta`, at least one of those
   arches has width at least

   \[
   \boxed{\eta/3.}
   \tag{0.4}
   \]

6. **Quantitative half-clearance descent.**  Let

   \[
   \gamma_*:=\min_\sigma |S_\sigma(D_*)|>0
   \]

   be the minimum nonzero branch-defect clearance at the shallowest bottom.
   Choosing `eta=gamma_*/2` gives

   \[
   \boxed{
   \text{exact root}
   \quad\text{or}\quad
   \text{arch width}\ge\gamma_*/6
   \quad\text{or}\quad
   |S|\le\gamma_*/2.
   }
   \tag{0.5}
   \]

   Thus if no macroscopic relocation occurs, the spatial resonance clearance
   decreases by at least a factor of two.

7. **Near spatial resonance is near lattice resonance.**  For exact consecutive
   phase contacts `x_0,x_1,x_2,x_3` with

   \[
   q(x_j)=y+j-d,
   \]

   define

   \[
   E=x_0+x_3-x_1-x_2.
   \]

   The parallelogram-predicted fourth point is

   \[
   w=x_1+x_2-x_0=x_3-E.
   \]

   Hence

   \[
   \boxed{|q(w)-q(x_3)|\le\omega(|E|).}
   \tag{0.6}
   \]

   Therefore the half-clearance branch in (0.5) is exactly a smaller
   third-phase lattice-clearance scale, provided the `0132` sector remains
   admissible.

8. **Sector loss is itself macroscopic under a common modulus.**  Consecutive
   phase contacts differ in phase by one.  If

   \[
   r_1:=\inf\{r>0:\omega(r)\ge1\},
   \]

   then adjacent exact-level contacts are at least `r_1` apart.  A relocation
   that jumps across another phase contact therefore has horizontal size at
   least `r_1`.  Thus a no-macroscopic-jump continuation automatically keeps
   the phase-indexed order.

9. **Residual width and remaining depth are linked.**  For a simple deeper
   arch `j`, at the shallowest common depth `D_*`,

   \[
   D_j-D_*\le \omega(w_j(D_*)).
   \tag{0.7}
   \]

   Hence genuine phase-depth desynchronization forces visible residual
   horizontal width.  Conversely, if all residual widths collapse, all four
   depths synchronize in phase.

The new frontier is therefore no longer an unspecified post-bottom level-set
jump.  In the regular compact branch, post-bottom continuation is a
**clearance-descent mechanism**.  The remaining hard cases are singular
relocation (plateaus, infinitely many level components, accumulation of
critical points), repeated factor-two descent with no compact scale, and the
inherited final Jordan transfer.

---

# 1. Setup and phase-indexed notation

We use phase-indexed contacts throughout v175.  Thus

\[
q(x_j)=y+j-d,
\qquad j=0,1,2,3,
\tag{1.1}
\]

and the additive square relation is

\[
\boxed{x_0+x_3=x_1+x_2.}
\tag{1.2}
\]

The corresponding additive defect is

\[
\boxed{S=x_0+x_3-x_1-x_2.}
\tag{1.3}
\]

For the `0132` geometric sector, these phase-indexed points occur in increasing
spatial order

\[
x_0<x_1<x_2<x_3.
\tag{1.4}
\]

This convention avoids the inherited geometric-label ambiguity corrected in
v172.

Assume throughout that

\[
q:\mathbb R\to\mathbb R
\]

is continuous and balanced:

\[
\boxed{|q(t)-t|\le B.}
\tag{1.5}
\]

Then

\[
q(t)\to-\infty\quad(t\to-\infty),
\qquad
q(t)\to+\infty\quad(t\to+\infty).
\tag{1.6}
\]

Any two equal-level points satisfy the useful universal bound

\[
q(a)=q(b),\ a<b
\quad\Longrightarrow\quad
\boxed{b-a\le2B.}
\tag{1.7}
\]

Indeed

\[
b-a=h(a)-h(b)
\]

for `q(t)=t+h(t)` and `|h|<=B`.

---

# 2. A strict lower bottom forces an upper relocation arch

The missing local contact after a shallow bottom is not arbitrary.

## Theorem 2.1 -- bottom-relocation arch

Let `m` be a strict local minimum of `q`, and write

\[
q(m)=\lambda.
\]

Then there is a point `p<m` such that

\[
q(p)=q(m)=\lambda
\tag{2.1}
\]

and

\[
\boxed{q(x)>\lambda\qquad(p<x<m).}
\tag{2.2}
\]

Thus `[p,m]` is an upper co-return arch.

### Proof

Because `m` is a strict local minimum, there is `delta>0` such that

\[
q(x)>\lambda
\qquad
m-\delta<x<m.
\]

On the other hand `q(t)->-infinity` as `t->-infinity`, so there is a point to
the left of `m` where `q<lambda`.  By the intermediate value theorem the set

\[
E=\{x<m:q(x)=\lambda\}
\]

is nonempty.  Let

\[
p=\sup E.
\]

The level set is closed, so `q(p)=lambda`; strict local minimality gives
`p<m`.  By maximality of `p`, `q` has no further value `lambda` on `(p,m)`.
Since it is above `lambda` near `m`, continuity forces it to remain above
`lambda` throughout `(p,m)`.  QED.

This is the exact topological event hidden by the phrase “the shallow contact
relocates.”

## Corollary 2.2 -- relocation width versus shallow depth

Suppose `m` is the bottom of a lower record arch with left top endpoint `a`,
top level `z`, and depth

\[
D=z-q(m)>0.
\]

Then the relocation point from Theorem 2.1 satisfies

\[
\boxed{p<a<m.}
\tag{2.3}
\]

Hence

\[
\boxed{m-p>m-a.}
\tag{2.4}
\]

If `q` has modulus of continuity `omega`, define

\[
r_\omega(D)=\inf\{r>0:\omega(r)\ge D\}.
\tag{2.5}
\]

Since

\[
D=|q(a)-q(m)|\le\omega(m-a),
\]

we obtain

\[
\boxed{m-p\ge r_\omega(D).}
\tag{2.6}
\]

So in a compact family with a common modulus, a shallowest depth bounded below
by `D_0>0` automatically yields a new co-return arch of uniformly positive
width `r_omega(D_0)`.

The only way for the first relocation width to vanish is for the shallow depth
itself to vanish in phase.

---

# 3. The branch cube at the shallowest bottom contains a sign edge

Return to the v174 four simple record arches.  Let

\[
D_*=\min_jD_j.
\]

Assume no exact synchronized root occurs for `0<=d<=D_*`.

At `d=D_*`, every arch with `D_j=D_*` has collapsed to its bottom; every deeper
arch still has two slice points.  Theorem 8.1 of v174 gives

\[
\min S_\sigma(D_*)<0<\max S_\sigma(D_*),
\tag{3.1}
\]

where `sigma` runs over the left/right choices of the still-active deeper
arches.

## Lemma 3.1 -- adjacent sign edge

There are two branch choices `sigma^-` and `sigma^+` that differ in exactly one
deeper arch `j` and satisfy

\[
\boxed{
A_*:=S_{\sigma^-}(D_*)<0
< S_{\sigma^+}(D_*)=:B_*.
}
\tag{3.2}
\]

### Proof

The branch choices form a finite hypercube graph.  It is connected.  Since its
vertices carry both signs by (3.1), any graph path from a negative vertex to a
positive vertex contains an edge whose endpoints have opposite signs.  QED.

Define the finite branch clearance

\[
\boxed{
\gamma_*=\min_\sigma|S_\sigma(D_*)|>0.
}
\tag{3.3}
\]

Then every sign-changing edge satisfies

\[
-A_*\ge\gamma_*\qquad\text{and}\qquad B_*\ge\gamma_*.
\tag{3.4}
\]

This is the quantitative seed for post-bottom continuation.

---

# 4. Regulated post-bottom continuation

We first state the regular continuation model used by the main v175 theorem.
It is deliberately separated from the singular infinite-component case.

For the distinguished deeper arch `j` from Lemma 3.1, keep its two simple slice
branches

\[
\ell_j(d)<r_j(d),
\qquad D_*\le d<D_j.
\tag{4.1}
\]

They coalesce at its bottom:

\[
\ell_j(d),r_j(d)\to m_j
\qquad(d\uparrow D_j).
\tag{4.2}
\]

For each of the other three coordinates, use the same level-set continuation
in the two configurations.  In a regular finite-component chamber this is
constructed by following the current local monotone branch while it exists;
at a strict lower bottom, jump to the nearest left component supplied by
Theorem 2.1 and continue there.  Repeating gives a regulated selection

\[
X_i(d)\in q^{-1}(y+i-d).
\tag{4.3}
\]

Every discontinuity of `X_i` is then a genuine same-level relocation arch.

Let the additive coefficient vector be

\[
(c_0,c_1,c_2,c_3)=(+1,-1,-1,+1).
\tag{4.4}
\]

The two opposite-sign defects continued from (3.2) are

\[
A(d)=\sum_{i\ne j}c_iX_i(d)+c_jx_j^-(d),
\tag{4.5}
\]

\[
B(d)=\sum_{i\ne j}c_iX_i(d)+c_jx_j^+(d),
\tag{4.6}
\]

where `x_j^-` and `x_j^+` denote the two active branches ordered so that

\[
A(D_*)=A_*<0<B_*=B(D_*).
\]

Between common relocation jumps, `A` and `B` are continuous.  At every jump of
one or more shared coordinates,

\[
\boxed{\Delta A=\Delta B.}
\tag{4.7}
\]

And because their only difference is the active arch `j`,

\[
\boxed{|B(d)-A(d)|=w_j(d)\to0}
\qquad(d\uparrow D_j).
\tag{4.8}
\]

Equation (4.7), together with the collapsing gap (4.8), is the whole
post-bottom mechanism.

---

# 5. The common-jump straddle lemma

## Lemma 5.1 -- straddle, jump, or smaller clearance

Let `A,B` be regulated on `[a,b)` such that

- `A(a)<0<B(a)`;
- between jumps, both are continuous;
- every jump is common: `Delta A=Delta B`;
- `B-A>0` between jumps; and
- `B(d)-A(d)->0` as `d->b-`.

Fix

\[
0<\eta<\min(-A(a),B(a)).
\]

Then at least one of the following occurs before `b`:

1. `A(d)=0` or `B(d)=0`;
2. `min(|A(d)|,|B(d)|)<=eta`;
3. there is a common jump with

   \[
   \boxed{|\Delta A|=|\Delta B|\ge\eta.}
   \tag{5.1}
   \]

### Proof

Assume (1) and (2) never occur.  As long as the two functions straddle zero,
we then have

\[
A\le-\eta,
\qquad
B\ge\eta.
\]

A continuous segment cannot change either sign without hitting zero.  A common
jump of magnitude less than `eta` cannot change either sign because both
values are at least `eta` from zero.  Therefore, if all common jumps had size
less than `eta`, the straddle would persist all the way to `b`.  But then

\[
B(d)-A(d)\ge2\eta,
\]

contradicting `B-A->0`.  QED.

This lemma is purely one-dimensional and does not use differentiability.

---

# 6. Large common jumps are geometric arches

In the regular continuation of Section 4, a common additive jump is the signed
sum of jumps of at most three shared contacts:

\[
\Delta A
=
\sum_{i\ne j}c_i\Delta X_i.
\tag{6.1}
\]

Therefore

\[
\sum_{i\ne j}|\Delta X_i|
\ge|\Delta A|.
\tag{6.2}
\]

## Lemma 6.1 -- common jump produces a large relocation arch

If

\[
|\Delta A|\ge\eta,
\]

then at least one shared contact has

\[
\boxed{|\Delta X_i|\ge\eta/3.}
\tag{6.3}
\]

Under nearest-component continuation, that jump is the width of a genuine
same-level return or co-return arch.

Thus the jump alternative in Lemma 5.1 is not an algebraic artifact: it
produces another geometric arch of controlled width.

If a continuation reaches a plateau, nonisolated critical level, or infinitely
accumulating level components instead, it leaves the regular chamber and
returns to the singular machinery of v159--v162.  v175 does not relabel those
singularities as ordinary jumps.

---

# 7. Main post-bottom trichotomy

## Theorem 7.1 -- regular post-bottom clearance descent

Assume:

1. the four v174 record excursions are simple lower arches;
2. no synchronized exact root occurs before the shallowest depth `D_*`;
3. at `D_*`, choose an adjacent sign edge `A_*<0<B_*` as in Lemma 3.1;
4. continue the three shared coordinates by the regular nearest-component
   rule of Section 4 while the distinguished deeper arch remains active; and
5. the `0132` phase-indexed order is retained unless a relocation jump itself
   crosses another contact.

Let `gamma_*` be (3.3).  Then before the distinguished deeper branch
coalesces, at least one of the following occurs:

### (i) Exact consecutive-level spatial resonance

\[
\boxed{S=0.}
\tag{7.1}
\]

Since the four contacts already lie on consecutive exact phase levels, this is
an actual `(1,3,2)` lattice resonance.

### (ii) Macroscopic relocation arch

There is a same-level return/co-return arch of width at least

\[
\boxed{\gamma_*/6.}
\tag{7.2}
\]

### (iii) Half-clearance descent

There are four exact consecutive-level contacts with

\[
\boxed{0<|S|\le\gamma_*/2.}
\tag{7.3}
\]

### Proof

Apply Lemma 5.1 with

\[
\eta=\gamma_*/2.
\]

The initial sign-edge endpoints are at least `gamma_*` from zero.  Alternative
(1) of Lemma 5.1 gives (i).  Alternative (2) gives (iii).  In alternative (3),
Lemma 6.1 gives a shared-coordinate relocation arch of width at least

\[
\frac{\eta}{3}=\frac{\gamma_*}{6},
\]

which is (ii).  QED.

This is the central v175 theorem.  It turns the v174 post-bottom problem into a
finite quantitative descent.

### Concrete value on the v174 unequal-depth model

For the explicit four-tent model of v174, at `D_*=1` the surviving widths are

\[
(0,\ 0.6782660773,\ 0.4043911370,\ 0.6961977900).
\]

The minimum nonzero branch clearance is

\[
\gamma_*\approx0.1758615026.
\]

One adjacent sign edge, differing only in the fourth phase-indexed arch, has

\[
A_*\approx-0.4676681557,\qquad
B_*\approx0.2285296343.
\]

Thus Theorem 7.1 says that any regular post-bottom continuation of that edge
must produce either an exact root, a relocation arch of width at least

\[
\gamma_*/6\approx0.02931025,
\]

or a new spatial resonance with clearance at most

\[
\gamma_*/2\approx0.08793075.
\]

So the abstract v174 countermodel no longer leaves an unquantified continuation
gap.

---

# 8. A small spatial defect is a small phase-lattice defect

The half-clearance alternative is useful because it is exactly the spatial
quantity entering the square parallelogram relation.

Suppose

\[
q(x_j)=y+j-d,
\qquad j=0,1,2,3,
\]

and set

\[
E=x_0+x_3-x_1-x_2.
\tag{8.1}
\]

Define the parallelogram-predicted fourth point

\[
w=x_1+x_2-x_0.
\tag{8.2}
\]

Then

\[
w-x_3=-E.
\tag{8.3}
\]

Therefore, for any modulus of continuity `omega`,

\[
\boxed{
|q(w)-(y+3-d)|
=|q(w)-q(x_3)|
\le\omega(|E|).
}
\tag{8.4}
\]

The other two relative phases are still exactly `1` and `2`.  Thus a spatial
clearance `|E|<=eta` gives a third-phase lattice clearance at most
`omega(eta)`.

This returns alternative (iii) of Theorem 7.1 directly to the v172--v173
clearance-collapse branch, at a strictly smaller scale.

---

# 9. Sector preservation and order-loss cost

The additive relation is useful only in the correct contact sector.
Fortunately, under a common modulus, changing the phase-indexed order has a
macroscopic cost.

Let

\[
r_1=\inf\{r>0:\omega(r)\ge1\}.
\tag{9.1}
\]

If

\[
q(x')-q(x)=1,
\]

then

\[
\boxed{|x'-x|\ge r_1.}
\tag{9.2}
\]

Therefore two consecutive exact phase contacts cannot approach more closely
than `r_1`.  If a discontinuous relocation causes one contact to jump across
another, the jump has magnitude at least `r_1`.

Hence, in any branch in which all relocation arches are `o(1)` under a fixed
common modulus, the phase-indexed order

\[
x_0<x_1<x_2<x_3
\]

is automatically preserved.

Moreover, in alternative (iii), if

\[
|E|<r_1,
\]

then the predicted point `w=x_3-E` remains to the right of `x_2`, so the
`0132` sector remains admissible when converting spatial clearance to phase
clearance via (8.4).

---

# 10. Residual width measures remaining phase desynchronization

The v174 residual-width inequality also has a useful modulus interpretation.

For a simple deeper arch `j`, at common depth `D_*` the two slice points
`ell_j(D_*),r_j(D_*)` surround the bottom `m_j`.  Their common phase is

\[
z_j-D_*,
\]

while

\[
q(m_j)=z_j-D_j.
\]

Thus

\[
D_j-D_*
=|q(\ell_j(D_*))-q(m_j)|
\le\omega(|\ell_j(D_*)-m_j|)
\le\omega(w_j(D_*)).
\]

Therefore

\[
\boxed{
D_j-D_*\le\omega(w_j(D_*)).
}
\tag{10.1}
\]

Equivalently, if `D_j-D_*>=tau`, then

\[
\boxed{w_j(D_*)\ge r_\omega(\tau).}
\tag{10.2}
\]

So depth desynchronization cannot remain phase-visible while all residual
horizontal widths disappear.  In a compact family, either the deeper arches
retain a visible spatial scale or the excursion depths themselves converge
toward synchronization.

This gives a direct geometric interpretation of v174 Theorem 8.1.

---

# 11. A jump budget on compact depth windows

The balance condition supplies a useful finite-event estimate.

Every equal-level arch has width at most `2B` by (1.7).  Every lower record
arch has depth at most `4B`: if `[a,b]` is its top level and `m` its bottom,

\[
D=q(a)-q(m)
\le |a-m|+2B
\le4B.
\tag{11.1}
\]

For the first-hit inverse `g`,

\[
|g(y)-y|\le B.
\]

Hence over a phase interval of length at most `4B`, its total spatial increase
is at most `6B`.  The sum of all jump widths of `g` on that interval is no
larger than this total variation.

Thus at any fixed clearance threshold `eta>0`, only finitely many
`eta`-macroscopic first-hit relocations can occur during one bounded depth
cascade.  Repeated escape at a fixed clearance cannot hide in infinitely many
large jumps; after finitely many such events, the mechanism must either hit a
root or descend in clearance.

This is not yet a global termination theorem because the clearance threshold
itself may decrease indefinitely.  It is, however, the finite-scale compactness
statement needed for the next renormalization step.

---

# 12. Sharpness of the trichotomy

The three alternatives in Theorem 7.1 are genuinely distinct.

## A. Common jump can skip a root

Take a pair of defects that initially straddles zero, then apply a common
positive jump before their gap collapses.  Both defects can jump from opposite
signs to the same positive sign without either attaining zero.  Thus ordinary
continuity cannot eliminate alternative (ii).

## B. Vanishing gap can force a smaller scale without an earlier root

If there are no common jumps and the two defects remain on opposite sides of
zero while their separation tends to zero, then both defects necessarily tend
to zero.  This is alternative (iii): an exact root may occur only at the
terminal singular event, while preterminal configurations exhibit arbitrarily
small clearance.

These examples are included in the verifier.  v175 therefore does **not** claim
that regular post-bottom continuation always closes immediately.  It proves
that failure to close has only the two quantitative outputs needed by the
existing program: a new visible arch or a smaller resonance scale.

---

# 13. What v175 proves

1. Every strict local minimum of a balanced profile has a same-level point to
   its left forming an upper co-return arch.
2. If that minimum is the bottom of a lower record arch of depth `D`, the
   relocation co-arch is wider than the left half of the original arch.
3. Under a common modulus, its width is at least `r_omega(D)`.
4. At the v174 shallowest bottom, the surviving branch-defect cube contains an
   adjacent opposite-sign edge.
5. Along post-bottom continuation of that edge, the two defects have identical
   relocation jumps and a gap that collapses to zero at the distinguished
   deeper bottom.
6. The common-jump straddle lemma forces a root, a large common jump, or smaller
   clearance.
7. In a regular nearest-component continuation, a large common jump produces a
   genuine same-level return/co-return arch of width at least one third of the
   additive jump.
8. Choosing half the initial finite branch clearance gives the explicit
   root/`gamma_*/6`-arch/`gamma_*/2`-clearance trichotomy.
9. A small spatial additive defect gives a third-phase lattice clearance at
   most `omega(|E|)`.
10. Under a common modulus, contact-order loss itself requires a macroscopic
    relocation jump.
11. Residual deeper-arch width controls the remaining phase-depth mismatch by
    `D_j-D_*<=omega(w_j(D_*))`.
12. Large first-hit relocation jumps have a finite budget on every bounded
    depth window.

---

# 14. What remains open

v175 still does **not** prove the full conjecture.

## A. Singular post-bottom relocation

If the nearest-component continuation encounters a plateau, a nonisolated
critical level, infinitely many accumulating components, or a nowhere-locally-
injective interval, the regulated finite-jump model is no longer sufficient.
Those cases must be routed through the v159--v162 current/persistence machinery.

## B. Infinite clearance descent

Theorem 7.1 can repeatedly halve the spatial resonance clearance.  It remains
to show that an infinite factor-two descent either produces an exact lattice
root in a compact limit or forces the noncompact roughness already isolated in
v155/v164.

## C. Macroscopic co-return arches

v157--v160 were formulated primarily around lower return arches.  The upper
co-return arches produced by Theorem 2.1 are locally dual but should be folded
into the signed-current formalism explicitly rather than treated by analogy.

## D. Noncompact roughness

Loss of a common modulus remains a separate branch.

## E. Final Jordan transfer

The profile extraction and shrinking-window transfer to the original Jordan
curve remain inherited terminal tasks.

---

# 15. Recommended v176 target

The cleanest next target is now a **clearance-renormalization theorem**.

Suppose Theorem 7.1 repeatedly chooses alternative (iii), producing exact
consecutive-level contacts with spatial defects

\[
\varepsilon_n\downarrow0.
\]

Center the predicted fourth contact and normalize horizontally by
`epsilon_n`.  Equation (8.4) says the third-phase error is controlled by
`omega(epsilon_n)`.  The desired theorem is

\[
\boxed{
\text{infinite factor-two clearance descent}
\Longrightarrow
\begin{cases}
\text{exact resonant compact tangent},\\
\text{visible return/co-return tangent},\\
\text{or loss of equicontinuity.}
\end{cases}}
\tag{15.1}
\]

The key advantage over the earlier v168 shear hierarchy is that the first two
phase differences are now **exact integers at every stage**.  Only the spatial
parallelogram defect is being renormalized.  There is no additional phase-label
compression problem.

A parallel task is to write the v159 signed interval current in a sign-symmetric
form that treats lower return arches and upper co-return arches uniformly.
That would absorb alternative (ii) of Theorem 7.1 back into the same degree
machinery instead of creating another branch name.

The v174 post-bottom obstruction has therefore been converted into a controlled
renormalization problem rather than an unresolved level-set relocation.
