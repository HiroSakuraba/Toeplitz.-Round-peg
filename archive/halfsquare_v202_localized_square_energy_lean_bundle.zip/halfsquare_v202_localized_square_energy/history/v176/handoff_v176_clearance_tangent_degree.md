# Project Handoff v176: Clearance Tangent Compactness and Degree Reconnection

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the exact v175 frontier: repeated post-bottom continuation keeps
choosing the smaller-clearance alternative

\[
|E_{n+1}|\le \frac12 |E_n|,
\qquad E_n\ne0,
\tag{0.1}
\]

where the four contacts already lie on four consecutive exact phase levels.

The main simplification is that the first compactness step does **not** require
rescaling horizontally by \(|E_n|\).  Translation alone is enough.  If the
profiles have a common modulus of continuity, balance gives uniform local
bounds and the unit phase gaps give uniform spatial separation.  Therefore a
subsequence converges to a nondegenerate exact consecutive-level resonant
profile.

The second main point is that this exact tangent is useful only if its root has
nonzero local degree.  In the \(C^1\) case the corresponding four-variable
Jacobian factors through exactly the reciprocal-slope mixed difference that
appeared much earlier in the affine/shifted-log analysis:

\[
\boxed{
\det D\Phi
=q'_0q'_1q'_2q'_3
\left(
\frac1{q'_1}+\frac1{q'_2}
-\frac1{q'_0}-\frac1{q'_3}
\right).
}
\tag{0.2}
\]

Thus a square-free compact clearance descent cannot converge to a regular
resonant root.  It must converge to a **degree-degenerate resonant tangent**.
If that reciprocal-slope degeneracy persists on an open family of additive
quadruples, continuity forces \(1/q'\) to be affine, hence \(q\) is affine or a
shifted logarithm.  This reconnects the v175--v176 clearance hierarchy to the
v151--v156 exceptional family rather than creating an unrelated terminal
object.

A third result closes the regular combinatorial loophole.  On any bounded depth
window whose continuation graph has only finitely many branch states/events,
a nonzero continuous defect has a positive minimum on each closed regulated
segment.  Hence an infinite factor-two root-free descent is impossible.  A
root-free infinite chain must accumulate infinitely many critical or
level-component events and therefore leaves the regular finite-component
chamber for the singular-current/persistence branch of v159--v162.

The main v176 conclusions are:

1. **Compact clearance tangent theorem.**  Common modulus + balance +
   \(E_n\to0\) gives an exact, spatially nondegenerate \((1,3,2)\) resonant
   tangent.
2. **Visible arch tangent theorem.**  Same-level return/co-return arches whose
   widths stay bounded below converge to either a positive-depth arch or a
   genuine plateau.
3. **C0 degree-stability criterion.**  If the tangent root has nonzero local
   Brouwer degree, exact lattice roots occur in all sufficiently large
   prelimits.
4. **C1 reciprocal-slope criterion.**  A square-free compact descent with a
   differentiable noncritical tangent must satisfy the reciprocal-slope mixed
   equality at the limiting four contacts.
5. **Open-family classification.**  If that equality holds for all additive
   quadruples in an interval, then \(1/q'\) is affine and \(q\) is affine or
   shifted logarithmic.
6. **Finite regulated continuation terminates.**  Infinite factor-two descent
   forces infinitely many branch/critical events or a singular event.
7. **Return/co-return current symmetry.**  Lower return arches and upper
   co-return arches are opposite orientations of the same distributional
   level current; v175 alternative (ii) therefore belongs naturally to the
   v159 current formalism.

The new frontier is not merely “take a compact limit.”  It is:

\[
\boxed{
\text{degree-degenerate exact resonant tangent}
\quad\text{or}\quad
\text{singular critical-event accumulation}
\quad\text{or}\quad
\text{loss of equicontinuity}.
}
\tag{0.3}
\]

The cleanest v177 target is a **degenerate-root renormalization theorem**:
show that repeated degree-zero resonant tangents either generate an open
reciprocal-slope-degenerate family (hence affine/log), produce a visible
return/co-return tangent, or create a new noncompact rough scale.

---

# 1. Phase-indexed setup

As in v175, use phase-indexed contacts

\[
q_n(x_{j,n})=a_n+j,
\qquad j=0,1,2,3,
\tag{1.1}
\]

in increasing spatial order

\[
x_{0,n}<x_{1,n}<x_{2,n}<x_{3,n}.
\tag{1.2}
\]

The additive square defect is

\[
\boxed{
E_n=x_{0,n}+x_{3,n}-x_{1,n}-x_{2,n}.
}
\tag{1.3}
\]

An exact consecutive-level resonance is \(E_n=0\).  In the `0132` phase
coordinates used by the program this is the exact lattice target

\[
(H_1,H_2,H_3)=(1,3,2).
\tag{1.4}
\]

Assume the profiles are balanced with one constant \(B\):

\[
|q_n(t)-t|\le B.
\tag{1.5}
\]

When compactness is invoked, assume a common modulus \(\omega\):

\[
|q_n(s)-q_n(t)|\le \omega(|s-t|),
\qquad \omega(r)\downarrow0\quad(r\downarrow0).
\tag{1.6}
\]

Define

\[
r_1:=\inf\{r>0:\omega(r)\ge1\}>0.
\tag{1.7}
\]

Every pair of contacts whose phases differ by one is separated by at least
\(r_1\).

---

# 2. Translation compactness needs no clearance blow-up

For each near-resonant configuration translate the phase-\(a_n+3\) contact to
zero:

\[
Q_n(t):=q_n(x_{3,n}+t)-q_n(x_{3,n}).
\tag{2.1}
\]

Then

\[
Q_n(0)=0
\tag{2.2}
\]

and, by balance,

\[
\begin{aligned}
|Q_n(t)-t|
&=|q_n(x_{3,n}+t)-q_n(x_{3,n})-t|\\
&\le
|q_n(x_{3,n}+t)-(x_{3,n}+t)|
+|q_n(x_{3,n})-x_{3,n}|\\
&\le2B.
\end{aligned}
\tag{2.3}
\]

Thus the translated family is uniformly bounded on every compact interval and
inherits exactly the same modulus \(\omega\).  Arzela--Ascoli therefore gives a
locally uniformly convergent subsequence

\[
Q_n\longrightarrow Q.
\tag{2.4}
\]

Set

\[
p_{j,n}:=x_{j,n}-x_{3,n}.
\tag{2.5}
\]

Then

\[
Q_n(p_{j,n})=j-3.
\tag{2.6}
\]

Equation (2.3) gives

\[
|p_{j,n}-(j-3)|\le2B,
\tag{2.7}
\]

so after another subsequence

\[
p_{j,n}\to p_j,
\qquad p_3=0.
\tag{2.8}
\]

The unit phase gaps and (1.6) give

\[
p_{j+1,n}-p_{j,n}\ge r_1,
\tag{2.9}
\]

hence

\[
p_0<p_1<p_2<p_3=0
\tag{2.10}
\]

with the same positive separation in the limit.

Finally

\[
E_n=p_{0,n}-p_{1,n}-p_{2,n}.
\tag{2.11}
\]

Therefore, if \(E_n\to0\),

\[
\boxed{p_0+p_3=p_1+p_2.}
\tag{2.12}
\]

Uniform convergence and (2.6) give

\[
Q(p_j)=j-3.
\tag{2.13}
\]

We have proved the basic compactness theorem.

## Theorem 2.1 -- exact resonant compact tangent

Let \(q_n\) satisfy (1.5)--(1.6), and suppose there are consecutive exact phase
contacts (1.1)--(1.2) with \(E_n\to0\).  Then, after translating by
\((x_{3,n},q_n(x_{3,n}))\) and passing to a subsequence, there is a continuous
balanced tangent \(Q\) and nondegenerate contacts

\[
p_0<p_1<p_2<p_3=0
\]

such that

\[
Q(p_j)=j-3,
\qquad
p_0+p_3=p_1+p_2.
\tag{2.14}
\]

In particular the limit contains an exact consecutive-level lattice resonance.
No horizontal or vertical rescaling is required.

### Consequence

The v175 desired trichotomy

\[
\text{exact resonant compact tangent}
\quad\text{or}\quad
\text{visible arch tangent}
\quad\text{or}\quad
\text{loss of equicontinuity}
\]

is now rigorous.  The visible-arch case is made explicit next.

---

# 3. Visible return/co-return arches have compact tangents

Consider lower return arches or upper co-return arches

\[
[a_n,b_n],
\qquad
q_n(a_n)=q_n(b_n)=z_n,
\qquad
d_n=b_n-a_n.
\tag{3.1}
\]

Assume

\[
d_n\ge d_0>0.
\tag{3.2}
\]

Balance gives \(d_n\le2B\), so after translating \(a_n\) to zero and taking a
subsequence,

\[
d_n\to d\in[d_0,2B].
\tag{3.3}
\]

For a lower arch define its depth

\[
D_n=z_n-\min_{[a_n,b_n]}q_n\ge0,
\tag{3.4}
\]

and for an upper co-return arch use the dual depth

\[
D_n=\max_{[a_n,b_n]}q_n-z_n\ge0.
\tag{3.5}
\]

The translated profiles are compact under the common modulus.

If \(D_n\to D>0\), a minimizing/maximizing point also has a convergent
subsequence, and the limit contains a positive-width, positive-depth return or
co-return arch.

If \(D_n\to0\), then on the entire arch

\[
|q_n(t)-z_n|\le D_n,
\]

so the limit is constant on an interval of width \(d\ge d_0\).

## Theorem 3.1 -- visible arch compactness

A common-modulus sequence of same-level arches whose horizontal widths stay
bounded below has a subsequence converging either to a positive-depth arch or
to a genuine plateau of positive width.

Thus v175 alternative (ii) cannot disappear under compactness.

---

# 4. The correct C0 stability object is local Brouwer degree

An exact tangent resonance is not by itself automatically stable.  Define the
four-variable resonance map

\[
\Phi_Q(z_0,z_1,z_2,z_3)
=
\begin{pmatrix}
Q(z_1)-Q(z_0)-1\\
Q(z_2)-Q(z_0)-2\\
Q(z_3)-Q(z_0)-3\\
z_0+z_3-z_1-z_2
\end{pmatrix}.
\tag{4.1}
\]

At the v176 tangent contact tuple \(p=(p_0,p_1,p_2,p_3)\),

\[
\Phi_Q(p)=0.
\tag{4.2}
\]

Let \(U\subset\mathbb R^4\) be a bounded open neighborhood of \(p\) such that

\[
0\notin \Phi_Q(\partial U).
\tag{4.3}
\]

If

\[
\deg(\Phi_Q,U,0)\ne0,
\tag{4.4}
\]

then local uniform convergence \(Q_n\to Q\) implies uniform convergence of
\(\Phi_{Q_n}\to\Phi_Q\) on \(\overline U\).  Brouwer-degree stability gives

\[
\deg(\Phi_{Q_n},U,0)=\deg(\Phi_Q,U,0)\ne0
\tag{4.5}
\]

for all sufficiently large \(n\).  Hence \(\Phi_{Q_n}\) has an exact zero.

## Theorem 4.1 -- robust resonant tangent closes the prelimit

If a compact clearance tangent has a resonant root carrying nonzero local
Brouwer degree, then all sufficiently large prelimits contain exact
consecutive-level lattice resonances.

Therefore a square-free compact clearance descent can converge only to a
**degree-zero / degree-degenerate resonant tangent**.

This is the precise replacement for the informal phrase “exact resonant tangent
should persist.”

---

# 5. C1 determinant: the reciprocal-slope defect returns

Assume now that \(Q\) is \(C^1\) near the four contacts and

\[
Q'(p_j)\ne0.
\tag{5.1}
\]

Write

\[
a=Q'(p_0),\quad b=Q'(p_1),\quad
c=Q'(p_2),\quad d=Q'(p_3).
\tag{5.2}
\]

The Jacobian of (4.1) at the resonant root is

\[
D\Phi_Q(p)
=
\begin{pmatrix}
-a&b&0&0\\
-a&0&c&0\\
-a&0&0&d\\
1&-1&-1&1
\end{pmatrix}.
\tag{5.3}
\]

A direct determinant computation gives

\[
\begin{aligned}
\det D\Phi_Q(p)
&=-abc+abd+acd-bcd\\
&=abcd
\left(
\frac1b+\frac1c-\frac1a-\frac1d
\right).
\end{aligned}
\tag{5.4}
\]

Hence a noncritical \(C^1\) root is degree-regular unless

\[
\boxed{
\frac1{Q'(p_0)}+\frac1{Q'(p_3)}
=
\frac1{Q'(p_1)}+\frac1{Q'(p_2)}.
}
\tag{5.5}
\]

This is exactly the parallelogram defect of the reciprocal slope.

## Corollary 5.1 -- C1 square-free compact descent is reciprocal-slope degenerate

If the prelimits are square-free, the v176 compact tangent is \(C^1\) near the
four contacts, and all four derivatives are nonzero, then (5.5) must hold.
Otherwise the tangent root has nonzero local degree and Theorem 4.1 gives exact
prelimit roots.

### Relation to v150--v156

The factor in (5.5) is the same reciprocal-slope additive defect that appeared
in the raw square-map Jacobian factorization in v152.  This is not accidental.
The clearance-descent endpoint has returned to the same exceptional geometry:
affine reciprocal slope.

---

# 6. Open-family degeneracy forces affine or shifted logarithmic form

The single equality (5.5) can occur accidentally.  The useful rigidity begins
when it persists on an open family.

Let

\[
r(x):=\frac1{Q'(x)}
\tag{6.1}
\]

be continuous on an interval \(I\).  Suppose that for every additive
quadruple in \(I\),

\[
x_0+x_3=x_1+x_2,
\tag{6.2}
\]

we have

\[
r(x_0)+r(x_3)=r(x_1)+r(x_2).
\tag{6.3}
\]

Choosing

\[
x_0=x-h,\qquad x_3=x+h,\qquad x_1=x_2=x
\]

gives Jensen's midpoint identity

\[
r(x-h)+r(x+h)=2r(x).
\tag{6.4}
\]

Continuity therefore forces

\[
\boxed{r(x)=\alpha+\beta x.}
\tag{6.5}
\]

Since \(Q'=1/r\), integration gives exactly two local possibilities:

\[
\boxed{Q(x)=Ax+C}
\qquad(\beta=0),
\tag{6.6}
\]

or

\[
\boxed{Q(x)=\frac1\beta\log|\alpha+\beta x|+C}
\qquad(\beta\ne0).
\tag{6.7}
\]

These are the affine and shifted-log families already identified in v151--v156.

## Theorem 6.1 -- open degree-degeneracy classification

Persistent reciprocal-slope degeneracy on an open additive family is
**equivalent**, in the noncritical \(C^1\) category, to the affine/shifted-log
exceptional family.

This gives the next renormalization target a precise form: one degenerate root
is not enough, but a cloud of degenerate resonant tangents collapses back to the
known exceptional manifold.

---

# 7. Infinite descent cannot remain in a finite regulated continuation graph

The v175 regular continuation consists of continuous branch segments separated
by bottom/coalescence/relocation events.  Abstract this as follows.

Let \(\mathcal G\) be a finite collection of regulated branch segments.  On
segment \(e\), parameterized by a compact depth interval \(I_e\), the selected
four contacts are continuous and therefore the additive defect

\[
S_e:I_e\to\mathbb R
\tag{7.1}
\]

is continuous.  Assume one-sided branch contacts extend continuously to every
regular event endpoint before any discrete relocation is applied.

Suppose there is no exact root anywhere in this finite graph:

\[
S_e(d)\ne0
\qquad
\text{for all }e,d.
\tag{7.2}
\]

If \(|S_e|\) approached zero at an endpoint of a regulated segment, the
continuous pre-event extension would itself give a zero at that bottom or
coalescence configuration.  Therefore every closed regulated segment has

\[
\min_{d\in I_e}|S_e(d)|>0.
\tag{7.3}
\]

Because \(\mathcal G\) is finite,

\[
\boxed{
\varepsilon_*
:=\min_e\min_{d\in I_e}|S_e(d)|>0.
}
\tag{7.4}
\]

Hence no root-free path through \(\mathcal G\) can realize a sequence of
clearances tending to zero.

## Theorem 7.1 -- regular finite-event termination

An infinite factor-two clearance descent cannot remain inside a finite
regulated continuation graph.  It must produce at least one of:

1. an exact additive root;
2. infinitely many distinct branch/critical events in a bounded depth window;
3. a singular event for which the finite continuous branch description fails.

In particular, a finite piecewise-monotone chamber cannot support the v175
infinite-descent obstruction by itself.

### Accumulation consequence

The relevant depth interval is bounded (record depths are at most \(4B\)).
Thus infinitely many event depths have an accumulation point.  The associated
contacts also remain in a bounded horizontal window after phase translation.
If their arch widths stay bounded below, Theorem 3.1 gives a visible arch or
plateau tangent.  If the widths tend to zero, their accumulation point is
non-locally-injective at arbitrarily small scales and belongs to the singular
critical-set regime of v159--v162.

So the regular/singular routing is now explicit rather than terminological.

---

# 8. Lower and upper arches are one oriented level current

v175 produced upper co-return arches, while much of v157--v160 was written for
lower return arches.  No new current formalism is actually needed.

For a continuous profile \(q\), define the oriented level current

\[
\boxed{
R_y:=D_t\mathbf 1_{\{q>y\}}.
}
\tag{8.1}
\]

On a simple lower return arch \([a,b]\) with

\[
q(a)=q(b)=y,
\qquad q<y\text{ on }(a,b),
\]

and the adjacent exterior lying above the level, the local contribution is

\[
\boxed{R_y|_{[a,b]}=\delta_b-\delta_a.}
\tag{8.2}
\]

On a simple upper co-return arch with

\[
q(a)=q(b)=y,
\qquad q>y\text{ on }(a,b),
\]

and adjacent exterior below the level, the contribution is

\[
\boxed{R_y|_{[a,b]}=\delta_a-\delta_b.}
\tag{8.3}
\]

Thus one can write both as

\[
\boxed{
J_{a,b}^{\sigma}=\sigma(\delta_b-\delta_a),
\qquad \sigma\in\{+1,-1\}.
}
\tag{8.4}
\]

The sign records lower versus upper orientation.  Every signed-current identity
from v159 therefore has an immediate sign-symmetric formulation.  The upper
co-return arches of v175 are not a new topological species.

---

# 9. What the clearance normalization actually says

v175 proposed horizontal normalization by \(\varepsilon_n=|E_n|\).  This is
still useful, but it is a **secondary** diagnostic rather than the first
compactness step.

Center at \(x_{3,n}\) and let

\[
r_n=|E_n|,
\qquad
\widehat Q_n(s)
=
\frac{q_n(x_{3,n}+r_n s)-q_n(x_{3,n})}{\omega(r_n)}.
\tag{9.1}
\]

The predicted fourth contact is at

\[
s=-\operatorname{sgn}(E_n).
\tag{9.2}
\]

and

\[
\left|\widehat Q_n(-\operatorname{sgn}E_n)\right|\le1.
\tag{9.3}
\]

The normalized family is equicontinuous on compact \(s\)-intervals only if
there is scale control of the form

\[
\frac{\omega(r_n R)}{\omega(r_n)}
\le \Omega(R)
\tag{9.4}
\]

with \(\Omega(\rho)\to0\) as \(\rho\to0\).  If such control fails, the
clearance zoom itself loses equicontinuity.  This is the precise noncompact
alternative anticipated in v175.

If (9.4) holds, the secondary tangent records how the degree-degenerate exact
resonance is approached.  That is the natural setting for v177, but the global
translation tangent of Theorem 2.1 should be extracted first.

---

# 10. A C1 local inverse interpretation

When \(Q\) is strictly monotone near each resonant contact, let \(\xi_j(c)\)
be the local inverse branch satisfying

\[
Q(\xi_j(c))=c+j.
\tag{10.1}
\]

The exact consecutive-level additive defect is

\[
\mathcal S(c)
=
\xi_0(c)+\xi_3(c)-\xi_1(c)-\xi_2(c).
\tag{10.2}
\]

At a differentiable root,

\[
\mathcal S'(c)
=
\frac1{Q'(p_0)}+\frac1{Q'(p_3)}
-\frac1{Q'(p_1)}-\frac1{Q'(p_2)}.
\tag{10.3}
\]

Thus (5.5) is exactly

\[
\mathcal S'(c)=0.
\tag{10.4}
\]

A sign-changing zero of \(\mathcal S\) is stable under uniform perturbation;
a square-free compact descent can only land on a touching/degree-zero zero.
This gives a one-dimensional way to visualize the four-dimensional degree
criterion.

---

# 11. What v176 proves

1. Translation of a balanced family preserves a uniform \(2B\) distance from
   the identity.
2. A common modulus makes every translated near-resonant family locally
   precompact.
3. Exact unit phase gaps give a uniform positive spatial separation between
   the four contacts.
4. Any \(E_n\to0\) sequence therefore has a nondegenerate exact resonant compact
   tangent.
5. Same-level arches of nonvanishing width converge to either a positive-depth
   return/co-return arch or a positive-width plateau.
6. A tangent resonance with nonzero local Brouwer degree persists to the
   prelimit.
7. In the noncritical \(C^1\) case, local degree is controlled by the mixed
   reciprocal-slope defect (5.5).
8. Open-family vanishing of that defect forces affine or shifted-log form.
9. Infinite root-free clearance descent cannot remain in a finite regulated
   continuation graph.
10. Hence a root-free infinite chain with a common modulus must accumulate
    singular level-set/critical events unless a visible arch tangent appears.
11. Lower return and upper co-return arches are opposite orientations of one
    level current.
12. Horizontal clearance normalization is a secondary tangent; its failure of
    compactness is measured by the modulus ratios (9.4).

---

# 12. What v176 does not prove

v176 still does **not** prove the full Toeplitz conjecture.

## A. A single degree-degenerate tangent root need not classify the profile

Equation (5.5) at one quadruple is only one scalar equality.  The affine/log
classification requires persistence on an open additive family.  The program
still needs a mechanism turning repeated clearance descent into enough nearby
degenerate roots to invoke Theorem 6.1, or else extracting a new residual
profile from the failure.

## B. Singular event accumulation remains hard

Infinitely many vanishing-width return/co-return events can accumulate at a
point while respecting a common modulus.  This is exactly where the
v159--v167 persistence/core machinery becomes relevant again.

## C. The secondary clearance tangent can be noncompact

A common modulus for the untranslated profiles does not imply normalized
compactness after dividing by \(\omega(r_n)\).  Scale-by-scale modulus ratios
may blow up.

## D. Final transfer to the original Jordan curve remains inherited

All previous shrinking-window, lattice-capture, and Jordan-transfer caveats
remain in force.

---

# 13. Recommended v177 target

The best next target is a **degenerate-root renormalization theorem**.

Start with the compact exact tangent \(Q\) and a degree-zero resonant quadruple
\(p\).  There are then two promising branches.

### Branch I: local degeneracy spreads

If nearby resonant configurations also have vanishing reciprocal-slope defect,
show that the degenerate set has interior in the additive-quadruple surface.
Theorem 6.1 then forces

\[
1/Q'\text{ affine}
\]

and hence the affine/shifted-log exceptional family.  v152--v156 already know
how to renormalize deviations from that family.

### Branch II: degeneracy is isolated

If the mixed reciprocal-slope defect becomes nonzero arbitrarily close to the
limiting root, the surrounding regular configurations carry nonzero degree.
The task is to show that the clearance-descent path or its excursion fillings
must enter one of those regular cells.  Failure should generate a smaller
secondary profile concentrated on the degree-zero set.

In the pure \(C^0\) branch, replace derivatives by the local degree of
\(\Phi_Q\) and study the closed zero-degree resonant set directly.

The important conceptual simplification is that v176 has closed the first
compactness loop: **infinite clearance descent is no longer an unclassified
limit process.  It lands on the same reciprocal-slope exceptional geometry
that the program had already isolated at much earlier scales.**
