# Project Handoff v177: Local-Degree Reduction and Fold Renormalization

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the exact v176 frontier: a compact clearance descent converges to an
exact consecutive-level resonant tangent, but the limiting root is not known to
carry nonzero Brouwer degree.

The most important correction is that v176's phrase **degree-degenerate root**
was too closely identified with a zero Jacobian determinant.  At a regular
four-contact configuration the resonance map admits an exact local
Lyapunov--Schmidt reduction to one scalar inverse-branch defect

\[
S(c)=\xi_0(c)+\xi_3(c)-\xi_1(c)-\xi_2(c).
\]

The four-dimensional local degree is nonzero precisely when the one-dimensional
zero of \(S\) has nonzero degree.  Therefore

\[
S'(c_0)=0
\]

is only a **Jacobian degeneracy condition**.  It does not imply zero local
degree.  For example, a cubic crossing has \(S'(c_0)=0\) but still has local
degree \(\pm1\) and is stable.

A square-free compact tangent can therefore land only on one of two genuinely
nonrobust possibilities:

1. an **isolated touching root**, where \(S\) has the same sign on the two
   sides; or
2. a **nonisolated zero set**.

For an isolated \(C^2\) touching root, the generic case is quadratic.  If
root-free prelimits approach such a tangent, their scalar resonance defects
have the universal fold blow-up

\[
\boxed{
\frac{S_n(c_n+\rho_n t)}{\mu_n}\longrightarrow 1+t^2,
\qquad
\rho_n=\sqrt{\mu_n/\kappa},
}
\]

where \(\mu_n\) is the minimum positive clearance and
\(S''(c_0)=2\kappa>0\).  At the same scale the reciprocal-slope mixed defect
has the universal odd tangent

\[
\boxed{
\frac{S_n'(c_n+\rho_n t)}{2\sqrt{\kappa\mu_n}}
\longrightarrow t.
}
\]

Thus an isolated degree-zero resonance does **not** automatically spread into
the affine/shifted-log exceptional family.  Generically it is a fold
catastrophe with a new \(\sqrt{\mu_n}\) base-phase scale.

A second correction concerns what “spread” would mean.  If the consecutive
resonance identity \(S(c)=0\) holds for every base phase on one global monotone
inverse branch, balance forces

\[
\boxed{x(c+2)=x(c)+2.}
\]

This is a large **2-periodic resonant manifold**, not the affine/log family.
Affine/shifted-log rigidity requires degeneracy in an open family of *phase-gap
directions*, as in the additive-quadruple theorem of v176, not merely a
one-parameter continuum of consecutive lattice resonances.

The third new result is a transverse-gap calculation.  For the general local
phase-gap defect

\[
\mathcal A(c;u,v)
=\zeta_0(c)+\zeta_3(c+u+v)-\zeta_1(c+u)-\zeta_2(c+v),
\]

at the consecutive root \((u,v)=(1,2)\), with reciprocal slopes
\(r_j=1/Q'(p_j)\),

\[
\partial_c\mathcal A=r_0+r_3-r_1-r_2,
\]
\[
\partial_u\mathcal A=r_3-r_1,
\qquad
\partial_v\mathcal A=r_3-r_2.
\]

Hence a base-phase-degenerate root is transversely regular in some phase-gap
direction unless

\[
\boxed{r_0=r_1=r_2=r_3.}
\]

This identifies a stronger slope-synchronization submanifold inside the
reciprocal-slope-degenerate set.

The new v177 frontier is therefore

\[
\boxed{
\text{quadratic/higher touching fold}
\quad\text{or}\quad
\text{2-periodic resonant zero continuum}
\quad\text{or}\quad
\text{branch-event/singular accumulation}.
}
\]

The cleanest next target is to couple the fold clearance scale to the nearest
branch-event/return-arch scale.  A generic fold by itself is a genuine local
root-avoidance mechanism; the missing theorem has to use the geometry that
terminates the local inverse branches, not determinant algebra alone.

---

# 1. Four-variable resonance map

Let \(Q\) be continuous and locally one-to-one near four contacts

\[
p_0<p_1<p_2<p_3
\]

satisfying

\[
Q(p_j)=c_0+j,
\qquad j=0,1,2,3,
\]

and

\[
p_0+p_3=p_1+p_2.
\]

The exact consecutive-level resonance map is

\[
\Phi_Q(z_0,z_1,z_2,z_3)=
\begin{pmatrix}
Q(z_1)-Q(z_0)-1\\
Q(z_2)-Q(z_0)-2\\
Q(z_3)-Q(z_0)-3\\
z_0+z_3-z_1-z_2
\end{pmatrix}.
\tag{1.1}
\]

The root \(p=(p_0,p_1,p_2,p_3)\) is the tangent lattice target
\((1,3,2)\) in the `0132` phase convention.

Because \(Q\) is locally one-to-one near each \(p_j\), there are local inverse
branches \(\zeta_j\) with

\[
Q(\zeta_j(y))=y,
\qquad
\zeta_j(c_0+j)=p_j.
\]

Define phase-indexed branches

\[
\xi_j(c):=\zeta_j(c+j).
\tag{1.2}
\]

Then

\[
Q(\xi_j(c))=c+j.
\]

The scalar additive defect is

\[
\boxed{
S(c):=\xi_0(c)+\xi_3(c)-\xi_1(c)-\xi_2(c).
}
\tag{1.3}
\]

At \(c=c_0\), \(S(c_0)=0\).

---

# 2. Exact local Lyapunov--Schmidt reduction

Define local coordinates

\[
c=Q(z_0),
\]

and

\[
u_1=Q(z_1)-Q(z_0)-1,
\quad
u_2=Q(z_2)-Q(z_0)-2,
\quad
u_3=Q(z_3)-Q(z_0)-3.
\tag{2.1}
\]

Because each local branch of \(Q\) is a homeomorphism, the change of variables

\[
(z_0,z_1,z_2,z_3)\longleftrightarrow(c,u_1,u_2,u_3)
\]

is itself a local homeomorphism.

In these coordinates the first three components of \(\Phi_Q\) are simply

\[
(u_1,u_2,u_3).
\]

The fourth component is a continuous function \(A(c,u)\).  On the zero slice
\(u=0\),

\[
A(c,0)=S(c).
\tag{2.2}
\]

Thus the root problem is locally triangular:

\[
\boxed{
\Phi_Q\sim(u_1,u_2,u_3,A(c,u)),
\qquad
A(c,0)=S(c).
}
\tag{2.3}
\]

## Theorem 2.1 -- local degree equals scalar degree up to orientation

Let \(c_0\) be an isolated zero of \(S\).  On a sufficiently small product
neighborhood, the local Brouwer degree of \(\Phi_Q\) is, up to the fixed
orientation sign of the local coordinate change, exactly the one-dimensional
local degree of \(S\) at \(c_0\).

In particular,

\[
\boxed{
\deg_{\rm loc}(\Phi_Q,p)\ne0
\iff
S\text{ changes sign across }c_0.
}
\tag{2.4}
\]

### Proof

The first three target equations force \(u=0\).  Hence every zero in the local
box lies on the one-dimensional slice \(u=0\), where the fourth coordinate is
exactly \(S(c)\).  Standard product-degree reduction, composed with the local
homeomorphism above, gives (2.4).

This statement is purely \(C^0\) once the four local inverse branches exist.

---

# 3. Correction: determinant zero is not degree zero

Assume now \(Q\in C^1\) near the contacts and \(Q'(p_j)\ne0\).  Put

\[
r_j:=\frac1{Q'(p_j)}.
\]

Then

\[
S'(c_0)=r_0+r_3-r_1-r_2.
\tag{3.1}
\]

The v176 determinant factorization can be rewritten as

\[
\det D\Phi_Q(p)
=-Q'(p_0)Q'(p_1)Q'(p_2)Q'(p_3)\,S'(c_0).
\tag{3.2}
\]

Therefore

\[
\det D\Phi_Q(p)=0
\iff
S'(c_0)=0.
\]

But (3.2) says only that the root is not a *simple differentiable* root.  It
says nothing by itself about its topological degree.

For example,

\[
S(c)=(c-c_0)^3
\]

has

\[
S'(c_0)=0
\]

but changes sign, so its one-dimensional local degree is \(+1\).  The
four-dimensional root is therefore Brouwer-stable despite its zero Jacobian.

## Corollary 3.1 -- actual square-free tangent restriction

A square-free compact tangent with an isolated locally invertible resonance can
survive only if the scalar zero is **non-sign-changing**.

If \(S\) is \(C^m\) and its first nonzero derivative at \(c_0\) has finite
order \(m\), then

\[
\boxed{m\text{ must be even}.}
\tag{3.3}
\]

Every odd-order zero has nonzero local degree and therefore persists to the
prelimit.

This is strictly stronger and more accurate than the v176 condition
\(S'(c_0)=0\).

---

# 4. Generic isolated obstruction: quadratic fold

Assume

\[
S(c_0)=0,
\qquad
S'(c_0)=0,
\qquad
S''(c_0)=2\kappa>0.
\tag{4.1}
\]

Then \(c_0\) is a strict local minimum of \(S\).

Let \(S_n\to S\) in \(C^2\) on a fixed neighborhood of \(c_0\), and suppose
that \(S_n\) has no zero there.  For sufficiently large \(n\), the boundary of
a small fixed neighborhood has positive \(S_n\), so root-freeness forces

\[
S_n>0
\]

throughout that neighborhood.

Let \(c_n\) be a point of minimum and define

\[
\mu_n:=S_n(c_n)>0.
\tag{4.2}
\]

Then

\[
c_n\to c_0,
\qquad
\mu_n\to0,
\qquad
S_n'(c_n)=0.
\]

Set

\[
\boxed{
\rho_n:=\sqrt{\frac{\mu_n}{\kappa}}.
}
\tag{4.3}
\]

## Theorem 4.1 -- universal fold tangent

For every fixed \(R<\infty\),

\[
\boxed{
\sup_{|t|\le R}
\left|
\frac{S_n(c_n+\rho_n t)}{\mu_n}-(1+t^2)
\right|
\longrightarrow0.
}
\tag{4.4}
\]

### Proof

Taylor's theorem at the minimum gives

\[
S_n(c_n+\rho_n t)
=
\mu_n+
\frac12S_n''(c_n+\theta_{n,t}\rho_n t)\rho_n^2t^2.
\]

Uniform \(C^2\) convergence gives

\[
S_n''(c_n+\theta_{n,t}\rho_n t)\to2\kappa
\]

uniformly for bounded \(t\).  Divide by \(\mu_n=\kappa\rho_n^2\).

The negative touching case is identical after replacing \(S_n\) by \(-S_n\).

### Reciprocal-slope tangent

Because

\[
S_n'(c)
=
\frac1{Q_n'(\xi_{0,n}(c))}
+\frac1{Q_n'(\xi_{3,n}(c))}
-\frac1{Q_n'(\xi_{1,n}(c))}
-\frac1{Q_n'(\xi_{2,n}(c))},
\]

we also obtain

\[
\boxed{
\frac{S_n'(c_n+\rho_n t)}
{2\sqrt{\kappa\mu_n}}
\longrightarrow t
}
\tag{4.5}
\]

uniformly on compact \(t\)-intervals.

Thus the scalar resonance clearance is order \(\mu_n\), while the reciprocal-
slope mixed defect becomes visible at the larger order

\[
\boxed{\sqrt{\mu_n}.}
\tag{4.6}
\]

This is the correct secondary scale for an isolated generic degenerate root.

---

# 5. Explicit smooth local fold model

An isolated touching root is not merely a formal possibility.

Define

\[
p_4(c)=
\frac{11}{24}c^2-
\frac14c^3+
\frac1{24}c^4.
\tag{5.1}
\]

A direct finite-difference calculation gives

\[
\boxed{
\Delta_1\Delta_2p_4(c)
:=p_4(c)+p_4(c+3)-p_4(c+1)-p_4(c+2)
=c^2.
}
\tag{5.2}
\]

Hence on any fixed compact phase interval, for sufficiently small
\(\lambda>0\),

\[
x(c)=c+\lambda p_4(c)
\tag{5.3}
\]

is strictly increasing and has consecutive resonance defect

\[
\boxed{S(c)=\lambda c^2.}
\tag{5.4}
\]

It has an isolated degree-zero resonance at \(c=0\), but it is not an
affine/shifted-log inverse law.

Moreover, because

\[
\Delta_1\Delta_2(c^2/4)=1,
\]

the local perturbation

\[
x_n(c)=c+\lambda p_4(c)+\frac{\mu_n}{4}c^2
\tag{5.5}
\]

has

\[
\boxed{S_n(c)=\lambda c^2+\mu_n>0.}
\tag{5.6}
\]

Thus \(x_n\to x\) smoothly while the entire local resonance disappears on the
root-free side of the fold.

This example proves that **isolated reciprocal-slope degeneracy does not spread
automatically**.  Any closure theorem must use additional phase-gap freedom,
branch-event geometry, or global balance.

### A complementary odd-order model

Define

\[
p_5(c)=
-\frac38c^2+
\frac{11}{24}c^3-
\frac3{16}c^4+
\frac1{40}c^5.
\]

Then

\[
\Delta_1\Delta_2p_5(c)=c^3.
\]

Thus zero Jacobian can coexist with a sign-changing, nonzero-degree resonance.
This realizes the correction in Section 3 inside the same inverse-defect
formalism.

---

# 6. Phase-gap unfolding

The consecutive target uses phase offsets

\[
(c,c+1,c+2,c+3).
\]

To see which degeneracies are intrinsic, allow the two independent phase gaps
to vary continuously.  Let \(\zeta_j\) denote the four fixed local inverse
branches and define

\[
\boxed{
\mathcal A(c;u,v)
=
\zeta_0(c)
+\zeta_3(c+u+v)
-\zeta_1(c+u)
-\zeta_2(c+v).
}
\tag{6.1}
\]

At \((c,u,v)=(c_0,1,2)\), write

\[
r_j=\zeta_j'(c_0+j)=\frac1{Q'(p_j)}.
\]

Then

\[
\boxed{
\partial_c\mathcal A=r_0+r_3-r_1-r_2,
}
\tag{6.2}
\]

\[
\boxed{
\partial_u\mathcal A=r_3-r_1,
\qquad
\partial_v\mathcal A=r_3-r_2.
}
\tag{6.3}
\]

## Theorem 6.1 -- slope synchronization is the only first-order fully degenerate point

Suppose the base-phase reciprocal-slope defect vanishes,

\[
r_0+r_3-r_1-r_2=0.
\]

If both continuous phase-gap derivatives also vanish, then

\[
r_3=r_1,
\qquad
r_3=r_2,
\]

and therefore

\[
\boxed{r_0=r_1=r_2=r_3.}
\tag{6.4}
\]

Consequently, unless all four reciprocal slopes synchronize, an isolated
base-phase fold is **transversely regular in phase-gap space**.

This is stronger than the single parallelogram relation of v176.

### Fine-mesh conditional closure

Suppose a prelimit quadratic fold has minimum clearance \(\mu_n\), one
transverse coefficient tends to \(\tau\ne0\), and admissible phase-gap targets
near the fold lie on a mesh of spacing \(h_n\).  If

\[
\boxed{h_n=o(\mu_n),}
\tag{6.5}
\]

then one can choose a neighboring mesh gap whose transverse shift changes the
fold minimum by more than \(\mu_n\).  The shifted scalar defect becomes
negative at its center while remaining positive at the boundary of the fold
neighborhood, and the intermediate value theorem gives two exact resonances.

Thus a generic fold can survive a sufficiently fine phase-gap lattice only if
the four reciprocal slopes synchronize.

**Current limitation.**  In the secondary normalization used in v171--v176,
the lattice mesh is fixed at one, so (6.5) does not by itself close the current
branch.  The theorem is included because it identifies the exact comparison
needed if a later renormalization restores a fine gap mesh.

---

# 7. Base-phase spread is not the affine/log exceptional family

There are two different notions of “degeneracy spreading” and they must not be
conflated.

Assume first that all four contacts come from one global strictly increasing
inverse

\[
x:\mathbb R\to\mathbb R,
\qquad
|x(c)-c|\le B.
\tag{7.1}
\]

Then

\[
S(c)=x(c)+x(c+3)-x(c+1)-x(c+2).
\tag{7.2}
\]

Let

\[
L(c)=x(c+1)-x(c).
\]

Then

\[
\boxed{S(c)=L(c+2)-L(c).}
\tag{7.3}
\]

If

\[
S(c)\equiv0
\quad\text{for all }c,
\]

then \(L\) is 2-periodic.  Hence

\[
P(c):=x(c+2)-x(c)=L(c)+L(c+1)
\]

is 2-periodic as well.  Iterating gives

\[
x(c+2N)-x(c)=NP(c).
\]

Balance (7.1) gives

\[
x(c+2N)-x(c)=2N+O(1),
\]

so necessarily

\[
P(c)=2.
\]

Therefore

\[
\boxed{x(c+2)=x(c)+2.}
\tag{7.4}
\]

Equivalently, the profile itself satisfies the 2-translation law

\[
\boxed{Q(t+2)=Q(t)+2.}
\tag{7.5}
\]

when \(x=Q^{-1}\).

This admits many non-affine examples, such as

\[
x(c)=c+\varepsilon\sin(\pi c),
\qquad |\varepsilon|<1/\pi.
\tag{7.6}
\]

Its inverse defect is 2-periodic and every consecutive phase quadruple is an
exact resonance.

Thus

\[
\boxed{
\text{one-parameter spread of consecutive resonances}
\not\Rightarrow
\text{affine/shifted-log profile}.
}
\tag{7.7}
\]

What v176 Theorem 6.1 needs is much stronger: reciprocal-slope degeneracy on an
open family of **additive phase-gap quadruples**.  That condition yields the
Jensen equation in spatial variables and hence affine reciprocal slope.

This distinction corrects the recommended Branch I in v176.

---

# 8. Global monotone inverse branches cannot terminate at an isolated fold

Still assume a global strictly increasing balanced inverse \(x\) as in (7.1).
The scalar defect \(S\) is continuous.

## Theorem 8.1 -- global sign rigidity

If

\[
S(c)\ge0\quad\text{for all }c
\]

or

\[
S(c)\le0\quad\text{for all }c,
\]

then

\[
\boxed{S\equiv0.}
\tag{8.1}
\]

### Proof

Suppose \(S\ge0\).  Set

\[
P(c)=x(c+2)-x(c)=L(c)+L(c+1).
\]

Then

\[
P(c+2)-P(c)=S(c)+S(c+1)\ge0.
\tag{8.2}
\]

For fixed \(c\), the two-sided sequence

\[
a_k=P(c+2k)-2
\]

is nondecreasing.  But

\[
\sum_{k=0}^{N-1}a_k
=x(c+2N)-x(c)-2N
\]

is uniformly bounded by \(2B\), and the analogous backward sums are also
uniformly bounded.  A two-sided nondecreasing sequence with bounded forward
and backward partial sums must vanish identically.  Hence \(P(c)=2\), so

\[
S(c)+S(c+1)=0.
\]

Because both terms are nonnegative, \(S(c)=0\).  The case \(S\le0\) is
identical.

## Corollary 8.2 -- robust degree or exact 2-periodicity

For a global monotone balanced inverse, either

1. \(S\equiv0\), giving the exact 2-translation resonant family of Section 7;
   or
2. \(S\) takes both signs.

In the second case there is a phase interval \([a,b]\) with

\[
S(a)S(b)<0.
\]

The one-dimensional Brouwer degree of \(S\) on that interval is nonzero,
regardless of whether the zero set inside is simple, degenerate, or contains
intervals.  Via Theorem 2.1 this gives a nonzero relative degree for the full
four-contact resonance map.

Therefore an isolated touching fold can be a terminal obstruction only because
the relevant inverse branches **terminate, relocate, or become singular**
before the global compensation in Theorem 8.1 can be used.

This reconnects the fold branch directly to the return-arch / level-current
machinery of v159--v175.

---

# 9. Quantitative regular-chain observation

Suppose on a regular single-inverse chamber the scalar defect is root-free and
has one sign with

\[
|S(c)|\ge\mu>0
\]

throughout every point needed for \(N\) consecutive two-step translations.
Then from

\[
P(c+2)-P(c)=S(c)+S(c+1)
\]

we obtain a change of at least \(2N\mu\) in \(P\).  Balance gives

\[
|P(c)-2|\le2B,
\]

so

\[
\boxed{N\mu\le2B.}
\tag{9.1}
\]

Thus a root-free one-sign chamber with clearance \(\mu\) cannot continue
through arbitrarily many lattice periods without a branch event.

For a quadratic fold \(\mu_n\to0\), this bound is only \(O(B/\mu_n)\), so it
does not close the fold by itself.  It does, however, quantify where the
missing geometry must enter.

---

# 10. What v177 proves

1. The four-variable resonance map has an exact local scalar reduction to the
   inverse-branch additive defect \(S(c)\).
2. The local Brouwer degree is nonzero exactly when an isolated scalar root
   changes sign.
3. Zero determinant / zero reciprocal-slope mixed derivative is therefore not
   equivalent to zero topological degree.
4. Odd-order degenerate roots are still Brouwer-stable and cannot be terminal
   square-free tangents.
5. A generic isolated square-free tangent root is an even touching root; the
   quadratic case has universal fold tangent \(1+t^2\).
6. Its reciprocal-slope mixed defect lives on the larger
   \(\sqrt{\mu_n}\)-scale and converges to the linear tangent \(t\).
7. There are explicit smooth local inverse models realizing both quadratic
   touching and cubic sign-changing zero-Jacobian roots.
8. Continuous phase-gap unfolding is transverse unless all four reciprocal
   slopes are equal.
9. A sufficiently fine phase-gap lattice would kill a generic fold; the current
   secondary unit lattice is not fine enough for that argument.
10. A continuum of consecutive base-phase resonances gives a 2-periodic
    translation law, not affine/log rigidity.
11. A global monotone balanced inverse either has exact 2-periodic resonance
    everywhere or carries a nonzero relative degree across some phase interval.
12. Hence an isolated fold can survive only in conjunction with branch-event,
    return-arch, singular-current, or noncompact geometry.

---

# 11. What v177 does not prove

v177 does **not** prove the Toeplitz conjecture.

## A. The quadratic fold is a genuine local obstruction

The explicit model (5.5) shows that smooth root-free prelimits can converge to
an isolated degree-zero tangent.  Degree theory alone cannot remove this
branch.

## B. The current phase-gap lattice is too coarse

The transversality theorem becomes a lattice-capture theorem only when the
available gap mesh is \(o(\mu_n)\).  In the normalized v171--v176 secondary
problem the mesh equals one.

## C. Branch termination remains the essential missing geometry

The global sign theorem closes an inverse branch only when it can be continued
through all relevant phases.  Nonmonotone profiles terminate or relocate local
branches at return arches and critical level events.  That is where the next
proof step has to operate.

## D. Base-phase spread does not imply affine/log

The affine/log theorem from v176 requires open additive-gap degeneracy.  Fixed
consecutive-lattice resonance spread instead gives the much larger 2-periodic
resonant manifold.

## E. Pure C0 touching roots can be much flatter than quadratic

Without quantitative regularity, a non-sign-changing scalar root can have
arbitrarily flat or fractal local structure.  The C0 formulation should use
one-dimensional degree and zero-set topology rather than derivatives.

---

# 12. Recommended v178 target

The best next target is a **fold-to-branch-event coupling theorem**.

Let \(S_n\) have quadratic fold clearance \(\mu_n\) and fold scale

\[
\rho_n\asymp\sqrt{\mu_n}.
\]

Track the four local inverse branches from the fold center until the first
bottom, plateau, relocation, or branch-collision event.  There are then two
natural regimes.

### Branch I -- event visible at fold scale

If the nearest event occurs within

\[
O(\!\sqrt{\mu_n})
\]

in base phase, extract a joint tangent containing both the universal fold
\(1+t^2\) and the return/co-return geometry.  The aim is to show that the event
unfolds the fold to the root-producing side or gives a visible level current.

### Branch II -- event far beyond fold scale

If the event distance divided by \(\sqrt{\mu_n}\) tends to infinity, the
normalized fold lives on an expanding regular phase interval.  One should then
combine the global sign/translation identity of Section 8 with quantitative
bounds on the inverse spacing to show that a pure \(1+t^2\) fold cannot persist
indefinitely without creating a second sign sector or a new smaller-scale
modulation.

The key conceptual correction from v177 is:

\[
\boxed{
\text{isolated degeneracy is a fold problem, not yet an affine/log problem.}
}
\]

The affine/log family re-enters only if degeneracy also spreads in the
phase-gap directions.
