# Project Handoff v178: Fold-to-Branch-Event Capture

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It attacks the exact v177 frontier: a root-free prelimit may converge to an
isolated degree-zero consecutive-level resonance.  In the generic case the
scalar inverse-branch defect has a quadratic touching fold

\[
S_n(c_n+\rho_n t)=\mu_n(1+t^2+o(1)),
\qquad
\rho_n\asymp\sqrt{\mu_n}.
\]

v177 correctly concluded that the local fold by itself is a genuine
root-avoidance mechanism.  The missing information is the event that terminates
one of the four local inverse branches.

v178 introduces the **polarity** and **opening law** of that event.  The key
point is elementary but strong: when two inverse branches coalesce at an event,
their additive defects differ by exactly the signed spatial branch separation.
If the companion branch moves toward zero and opens sufficiently rapidly, the
quadratic fold cannot survive.

The main new scale law is

\[
\boxed{\eta_{\rm cap}\asymp a^m,}
\]

where \(a\) is the additive clearance at the branch event and

\[
W(\eta)\gtrsim \eta^{1/m}
\]

is the spatial opening of the two level branches at phase depth \(\eta\).
For a Morse extremum \(m=2\), the capture layer is quadratic in the event
clearance:

\[
\boxed{\eta_{\rm cap}=O(a^2).}
\]

When the event lies at distance \(d_n\to0\) from the quadratic fold center,

\[
a_n\asymp \mu_n+d_n^2.
\]

Consequently, once \(d_n\gg\sqrt{\mu_n}\),

\[
\eta_{\rm cap}\asymp d_n^{2m}.
\]

Thus the exponent \(m=1/2\) is the fold/event threshold:

\[
\boxed{
 m>\tfrac12
 \Longrightarrow
 \eta_{\rm cap}=o(d_n).
}
\]

Every ordinary finite-order smooth extremum has \(m\ge1\), and a Morse event
has \(m=2\).  Such a favorable event approaching the fold center is therefore
root-producing unless another branch/critical event intervenes on a strictly
smaller scale.

This corrects the v177 recommendation that the primary split should be
\(d_n/\sqrt{\mu_n}=O(1)\) versus \(\to\infty\).  The more intrinsic quantity is
the event clearance \(a_n\), its signed opening law, and whether the clean
branch chamber survives through the capture depth \(a_n^m\).

---

# 1. Scalar fold and event notation

Keep the v177 local scalar reduction.  Four local inverse branches satisfy

\[
Q(\xi_j(c))=c+j,
\]

and the additive resonance defect is

\[
S(c)=\xi_0(c)+\xi_3(c)-\xi_1(c)-\xi_2(c).
\tag{1.1}
\]

Write the coefficient vector as

\[
\sigma=(+1,-1,-1,+1),
\]

so

\[
S(c)=\sum_{j=0}^3\sigma_j\xi_j(c).
\tag{1.2}
\]

Assume that branch \(k\) terminates at a level event at base phase \(e\).  On
the two-valued side of the event there are two local inverse branches

\[
x^-(\eta)<x^+(\eta),
\qquad
\eta\ge0,
\]

with

\[
x^-(0)=x^+(0)=x_*.
\]

Here \(\eta\) denotes phase depth away from the event.  The other three contact
branches are kept fixed.

The corresponding two additive defects are

\[
S^\pm(\eta)=A(\eta)+\sigma_k x^\pm(\eta),
\tag{1.3}
\]

where \(A\) contains the other three contacts.

Define the branch width

\[
W(\eta)=x^+(\eta)-x^-(\eta)\ge0
\tag{1.4}
\]

and midpoint defect

\[
M(\eta)=\frac{S^+(\eta)+S^-(\eta)}2.
\tag{1.5}
\]

Then **exactly**

\[
\boxed{
S^\pm(\eta)=M(\eta)\pm\frac{W(\eta)}2
}
\tag{1.6}
\]

up to interchange of the labels \(+\) and \(-\).  At the event

\[
S^+(0)=S^-(0)=M(0)=:a.
\tag{1.7}
\]

The quantity \(a\) is the **event clearance**.

---

# 2. Exact C0 branch-opening criterion

## Theorem 2.1 -- width versus midpoint

Assume \(a>0\).  If for some admissible phase depth \(\eta_1\)

\[
\boxed{
\frac{W(\eta_1)}2\ge M(\eta_1),
}
\tag{2.1}
\]

then one of the two branch defects has a zero on \([0,\eta_1]\).

The same statement holds with all signs reversed when \(a<0\).

### Proof

At \(\eta=0\), both defects equal \(a>0\).  At \(\eta_1\), (1.6) gives

\[
\min\{S^+(\eta_1),S^-(\eta_1)\}
=M(\eta_1)-\frac{W(\eta_1)}2\le0.
\]

Each branch defect is continuous up to the event, so the intermediate value
theorem gives a zero.

## Corollary 2.2 -- root-free event inequality

A root-free event with positive clearance must satisfy

\[
\boxed{
W(\eta)<2M(\eta)
}
\tag{2.2}
\]

at every admissible two-branch phase depth for which \(M(\eta)>0\).

This is the exact C0 obstruction.  No derivative or Taylor expansion is used.

---

# 3. Event polarity

For coupling to the *particular* scalar fold branch from v177 it is useful to
mark which of the two event branches is the pre-existing branch.

Let \(x^{\rm old}(\eta)\) be that branch and \(x^{\rm cmp}(\eta)\) its local
companion.  Their additive defects differ by

\[
\boxed{
S^{\rm cmp}(\eta)-S^{\rm old}(\eta)
=\sigma_k\bigl(x^{\rm cmp}(\eta)-x^{\rm old}(\eta)\bigr).
}
\tag{3.1}
\]

For a positive fold define the event to be

- **favorable** if the right-hand side is negative;
- **unfavorable** if it is positive.

At a favorable event, the companion branch lowers the additive clearance.  A
zero is forced as soon as its signed spatial separation exceeds the clearance
of the old branch.

At an unfavorable event, the companion moves *away* from zero.  Local splitting
alone therefore does not close the fold.  The old branch terminates as the
lower-clearance member and any continuation past the event must use a nonlocal
level component.  This is precisely the post-bottom/relocation geometry studied
in v174--v175.

Polarity is therefore not cosmetic.  A theorem that says only “a branch event
occurs near the fold” is insufficient.

---

# 4. Quadratic/Morse branch event

Assume now that the branch event is a nondegenerate local extremum of a
\(C^3\) profile.  In spatial coordinates centered at the critical point,

\[
Q(x_*+z)=Q(x_*)-\frac{\lambda}{2}z^2+O(z^3),
\qquad
\lambda>0,
\tag{4.1}
\]

for a local maximum; the minimum case is identical after reversing phase.

At phase depth \(\eta\), the two inverse branches satisfy

\[
x^\pm(\eta)
=x_*\pm\sqrt{\frac{2\eta}{\lambda}}+O(\eta),
\tag{4.2}
\]

hence

\[
\boxed{
W(\eta)
=2\sqrt{\frac{2\eta}{\lambda}}+O(\eta).
}
\tag{4.3}
\]

The midpoint moves only by \(O(\eta)\).  If the other three inverse branches
are regular through the event, their total contribution to \(M\) also changes
by \(O(\eta)\).  Therefore

\[
\boxed{
M(\eta)=a+O(\eta).
}
\tag{4.4}
\]

## Theorem 4.1 -- Morse event capture

There are constants \(a_0,C>0\), depending only on uniform local regularity
bounds, such that whenever

\[
0<a<a_0
\]

and the two-branch chamber survives through phase depth

\[
\boxed{\eta\ge Ca^2,}
\tag{4.5}
\]

an exact additive resonance occurs.

### Proof

Set \(\eta=Ca^2\).  From (4.3),

\[
\frac{W(\eta)}2
=\sqrt{\frac{2C}{\lambda}}\,a+O(a^2).
\]

Choose \(C\) so that the leading coefficient is larger than \(2\).  Equation
(4.4) gives

\[
M(\eta)=a+O(a^2).
\]

For all sufficiently small \(a\),

\[
W(\eta)/2>M(\eta).
\]

Theorem 2.1 gives the root.

### Consequence

A root-free Morse branch event with small event clearance can survive only if

1. another branch/critical event intervenes inside an \(O(a^2)\) phase layer;
2. the contact sector ceases to be admissible inside that layer; or
3. the assumed regularity degenerates.

Thus a clean Morse event is **not** a terminal absorber of the v177 fold.

---

# 5. Universal fold--return tangent

Theorem 4.1 has a canonical local model.  Let

\[
h(\eta)=\sqrt{\frac{2\eta}{\lambda}}
\]

be the half-width of the two event branches.  At the event scale

\[
\eta=a^2t,
\]

we obtain

\[
M(a^2t)=a+o(a),
\]

and

\[
h(a^2t)
=a\sqrt{\frac{2t}{\lambda}}+o(a).
\]

Therefore the two normalized additive branches satisfy

\[
\boxed{
\frac{S^\pm(a^2t)}a
\longrightarrow
1\pm\sqrt{\frac{2t}{\lambda}}.
}
\tag{5.1}
\]

One branch crosses zero at

\[
\boxed{t=\lambda/2.}
\tag{5.2}
\]

This is the joint **fold--return tangent** promised in v177.  The v177 base
fold \(1+t^2\) lives at the larger phase scale \(\sqrt\mu\); a regular Morse
branch event introduces an even thinner root-producing layer of order
\(a^2\).

When the event itself lies at fold-scale distance and hence \(a\asymp\mu\),

\[
\boxed{
\eta_{\rm event-root}=O(\mu^2),
}
\tag{5.3}
\]

while

\[
\rho_{\rm fold}=O(\mu^{1/2}).
\]

The ratio is

\[
O(\mu^{3/2})\to0.
\]

So the exact root is invisible in the first fold blow-up unless the excursion
filling is retained.

---

# 6. General finite-order opening

The Morse square root is not special.  Suppose a simple event has opening order
\(m>0\) in the sense that

\[
\boxed{
W(\eta)\ge c\,\eta^{1/m}
}
\tag{6.1}
\]

for sufficiently small \(\eta\), while

\[
M(\eta)=a+o(a)
\]

uniformly when \(\eta=O(a^m)\).

Then choosing

\[
\eta=Ca^m
\]

with \(C\) sufficiently large gives

\[
W(\eta)/2>a
\]

and hence a root.

## Theorem 6.1 -- opening-order capture law

Under the preceding hypotheses,

\[
\boxed{
\eta_{\rm cap}=O(a^m).
}
\tag{6.2}
\]

For a smooth finite-order extremum

\[
Q(x_*)-Q(x)\asymp|x-x_*|^m,
\qquad m\ge2,
\]

this is the natural opening order.  In particular every finite-order smooth
extremum is strongly root-producing once its clearance is small.

The corresponding normalized event tangent is

\[
\boxed{
S^\pm/a\to1\pm C_m t^{1/m}.
}
\tag{6.3}
\]

---

# 7. Coupling to the quadratic fold distance

Let

\[
S_n(c_n)=\mu_n>0,
\qquad
S_n(c_n+\rho_nt)/\mu_n\to1+t^2,
\qquad
\rho_n\asymp\sqrt{\mu_n}.
\]

Let a branch event occur at

\[
e_n=c_n+d_n,
\qquad d_n\to0.
\]

Whenever the quadratic expansion remains uniform on the interval between the
fold center and the event,

\[
\boxed{
a_n:=S_n(e_n)\asymp\mu_n+d_n^2.}
\tag{7.1}
\]

If

\[
d_n\gg\sqrt{\mu_n},
\]

then

\[
a_n\asymp d_n^2.
\]

Combining this with Theorem 6.1 gives

\[
\boxed{
\eta_{\rm cap}\asymp d_n^{2m}.
}
\tag{7.2}
\]

Hence

\[
\boxed{
\frac{\eta_{\rm cap}}{d_n}
\asymp d_n^{2m-1}.
}
\tag{7.3}
\]

This yields the critical opening threshold

\[
\boxed{m=\frac12.}
\tag{7.4}
\]

### Supercritical opening: \(m>1/2\)

Then

\[
\eta_{\rm cap}=o(d_n).
\]

A favorable event approaching the fold center therefore creates an exact root
*before one can return to the fold center*, provided no second branch event
intervenes on that smaller phase layer.

### Critical opening: \(m=1/2\)

The capture depth and event-to-fold distance are comparable.  Constants and the
other branches matter.

### Sharp-cusp opening: \(m<1/2\)

Then

\[
\eta_{\rm cap}\gg d_n.
\]

The local event can terminate the branch before its companion separates enough
to overcome the fold clearance.  This is a genuine local escape mechanism.

This threshold is internal to the one-dimensional phase profile.  It should
not be identified without further work with a regularity exponent of the
original Jordan curve.

---

# 8. The fold-scale regime is a special case, not a separate theory

If

\[
d_n\asymp\rho_n\asymp\sqrt{\mu_n},
\]

then

\[
a_n\asymp\mu_n.
\]

The capture law becomes

\[
\boxed{
\eta_{\rm cap}\asymp\mu_n^m.
}
\tag{8.1}
\]

For a Morse event,

\[
\eta_{\rm cap}\asymp\mu_n^2.
\]

For every \(m>1/2\),

\[
\frac{\mu_n^m}{\sqrt{\mu_n}}
=\mu_n^{m-1/2}\to0.
\]

Thus any favorable event of opening order \(m>1/2\) visible at the fold scale
is actually resolved on a much thinner root-producing sublayer.

This is why the v177 split

\[
d_n/\sqrt{\mu_n}=O(1)
\quad\text{versus}\quad
\to\infty
\]

was not intrinsic.  Both cases are governed by the same event-clearance/opening
law whenever \(d_n\to0\).

---

# 9. Sharp-cusp countermodel

The threshold \(m=1/2\) is not a proof artifact.

Consider a symmetric local maximum with

\[
Q(x_*)-Q(x)\asymp |x-x_*|^m,
\qquad 0<m<1/2.
\]

At phase depth \(\eta\),

\[
W(\eta)\asymp \eta^{1/m}.
\]

Suppose the event lies a phase distance \(d\) from a quadratic fold center and
its clearance satisfies

\[
a\asymp d^2.
\]

To make the branch separation comparable with the clearance requires

\[
\eta\asymp a^m\asymp d^{2m}.
\]

But \(2m<1\), so

\[
d^{2m}\gg d.
\]

Hence the entire interval from the event back to the fold center may be too
short for the companion branch to reach the root-producing separation.

For the concrete cusp

\[
Q(x_*)-Q(x)=|x-x_*|^{1/3},
\]

we have

\[
W(\eta)=2\eta^3.
\]

If \(a=d^2\), then at the fold center \(\eta=d\),

\[
W(d)=2d^3=o(d^2)=o(a).
\]

More directly, the root-producing depth solves

\[
2\eta^3\asymp d^2,
\]

so

\[
\eta\asymp d^{2/3}\gg d.
\]

No local root is forced before the fold center.

This shows that a very sharp C0 cusp can absorb the local fold geometry.  A
successful full proof must either exclude such cusp events using the original
curve geometry or feed them into the roughness/current branch developed in
v159--v167.

---

# 10. Plateau events

Suppose the event level itself contains a plateau interval \([x_-,x_+]\) of
width

\[
W_0=x_+-x_->0.
\]

The additive defect varies affinely with the selected point of that plateau.
If the event clearance is \(a>0\), then the plateau immediately forces a root
whenever its signed span reaches the origin.  In particular, in the symmetric
midpoint formulation,

\[
\boxed{W_0\ge2|a|\Longrightarrow\text{exact root at the event level}.}
\tag{10.1}
\]

Therefore a root-free plateau event with \(a\to0\) must have

\[
\boxed{W_0=O(a)}
\tag{10.2}
\]

unless its polarity/sector geometry prevents the plateau interval from being
used.  This is the plateau analogue of the sharp-cusp microevent: the entire
level fiber collapses onto the additive-clearance spatial scale.

---

# 11. What unfavorable events do

At an unfavorable event, the local companion branch raises the positive
additive defect.  The width criterion therefore cannot force a local root.

However, the event still terminates the lower-clearance branch.  To continue
the phase target beyond the local extremum, one must relocate that contact to a
nonlocal component of the same level set.  That is exactly the geometry
isolated in v175:

\[
\boxed{
\text{unfavorable local event}
\Longrightarrow
\text{nonlocal relocation / co-return problem}.
}
\tag{11.1}
\]

The v175 trichotomy then applies in the regular finite-component chamber:

\[
\text{exact root}
\quad\text{or}\quad
\text{visible new arch}
\quad\text{or}\quad
\text{smaller resonance clearance}.
\]

Thus v178 does not need a second independent theory for unfavorable events.
They are routed back into the existing relocation descent.

This routing remains conditional on the same regular finite-component
assumptions as v175.  Infinite level-component accumulation still belongs to
the singular-current branch.

---

# 12. Revised fold-to-event dichotomy

The v177 fold can now be organized as follows.

Let \(a_n\) be the additive clearance at the first branch event encountered by
the regular fold chamber.

## A. Favorable event with opening order \(m>1/2\)

If the event approaches the fold center and its two-branch chamber survives
through the capture depth \(O(a_n^m)\), an exact resonance is forced.

For a Morse event this capture depth is \(O(a_n^2)\).

## B. Favorable event but no capture

Then at least one of the following occurs:

1. another branch/critical event lies inside the predicted capture layer;
2. the event opening is critical/sharp, effectively \(m\le1/2\);
3. plateau width and all usable branch widths are only \(O(a_n)\);
4. sector admissibility fails;
5. compact regularity is lost.

This is a **singular event cluster**, not a generic fold.

## C. Unfavorable event

The local companion moves the defect away from zero.  Continuation requires a
nonlocal level relocation and enters the v175 post-bottom descent.

## D. Event stays macroscopically separated from the fold center

If the event distance does not tend to zero, the local fold and event decouple.
v178 does not close this macro branch.  The tangent contains a genuine isolated
fold on a fixed regular phase neighborhood, and global compensation must occur
outside that neighborhood through a later branch event or singular current.

This is the only part of the original v177 “far event” regime that remains
truly independent.

---

# 13. What v178 proves

1. An exact C0 width-versus-midpoint criterion for root production at a
   two-branch level event.
2. A precise polarity notion for coupling a branch event to the selected v177
   scalar fold branch.
3. A regular Morse event with small additive clearance forces an exact root in
   an \(O(a^2)\) phase layer.
4. The corresponding joint fold--return tangent is
   \(1\pm C\sqrt t\).
5. More generally, an opening law \(W(\eta)\gtrsim\eta^{1/m}\) gives capture
   depth \(O(a^m)\).
6. When an event approaches a quadratic fold center from distance \(d\) with
   \(d\gg\sqrt\mu\), its clearance is \(a\asymp d^2\), so capture occurs at
   \(O(d^{2m})\).
7. The sharp threshold for capture before returning to the fold center is
   \(m>1/2\).
8. At fold-scale distance, every \(m>1/2\) event has a strictly smaller
   root-producing phase layer; a Morse event gives \(O(\mu^2)\).
9. Very sharp C0 cusp events with \(m<1/2\) are a genuine local escape
   mechanism.
10. A root-free plateau at small clearance must collapse to clearance-scale
    spatial width unless sector/polarity restrictions intervene.
11. Unfavorable local events route naturally into the v175 nonlocal relocation
    descent.
12. The ratio event-distance/fold-scale is therefore not the fundamental
    invariant; event clearance, polarity, opening order, and event clustering
    are.

---

# 14. What v178 does not prove

v178 does **not** prove the Toeplitz conjecture.

## A. Polarity matters

A regular event can be unfavorable: its local companion may move the additive
defect away from zero.  The event then has to be handled through relocation,
not local branch opening.

## B. Sharp C0 cusps remain

Opening order \(m\le1/2\) can be too sharp for the companion branch to overcome
the fold clearance before the local chamber ends.

## C. Event clusters remain

Even for \(m>1/2\), another critical/branch event may occur inside the predicted
capture layer.  Iterating this possibility leads back toward the singular
persistence-current machinery.

## D. Macroscopic event separation remains

A branch event that stays a fixed positive phase distance from the fold center
is not controlled by the local quadratic asymptotic alone.

## E. The theorem is local-sector conditional

The branch-produced resonance must remain in the admissible `0132` contact
sector.  Sector degeneration has to be routed separately.

---

# 15. Recommended v179 target

The cleanest next target is now an **event-cluster renormalization theorem**.

Suppose a favorable event has \(m>1/2\), but root production is prevented by a
second branch/critical event inside the capture layer

\[
\eta_n=O(a_n^m).
\]

Normalize phase by \(a_n^m\) and spatial branch separation by \(a_n\).  There
are then two possibilities.

### Branch I -- finite event cluster

A finite number of event branches survive in the normalized window.  Build the
signed configuration graph explicitly.  The v178 width criterion should force
one edge to cross zero unless all root-producing polarities cancel through a
closed event cycle.  Such a cycle can then be compared with the signed-current
orientation theorem of v159.

### Branch II -- infinite event cluster

Infinitely many events survive in every normalized capture window.  Then the
local inverse relation has infinite level-component complexity exactly on the
scale where the fold clearance is visible.  This should feed directly into the
persistence-core / Stieltjes current formalism of v161--v167.

The key new invariant is the **signed event-opening profile**

\[
\boxed{
\mathcal W_n(t)
=
\frac{\sigma_k\bigl(x^{\rm cmp}_n-x^{\rm old}_n\bigr)
      (a_n^m t)}{a_n}.
}
\]

A generic favorable event has a nontrivial negative branch in this
normalization.  A root-free sequence must either destroy that branch by another
event before it crosses \(-1\), or concentrate infinitely many event changes
on the same scale.

This is now a more concrete and local terminal object than the generic
“branch-event geometry” left by v177.
