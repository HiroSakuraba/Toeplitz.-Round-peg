# Project Handoff v179: Selected-Branch Routing and Morse Cluster Exclusion

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.
It addresses the exact v178 recommendation: a favorable branch event of opening
order `m>1/2` is root-producing on a capture layer `O(a^m)`, unless another
branch/critical event intervenes inside that layer.

The main correction is that the phrase **event cluster** was too broad.  Once
v178 has selected the root-lowering companion configuration, unrelated inverse
branches are irrelevant.  The additive defect of the selected four contacts is
one continuous scalar function.  If all four selected contact lifts survive to
the predicted capture depth, the intermediate value theorem gives the exact
resonance, no matter how many other branches are born elsewhere.

Thus a root-free favorable event can be blocked only if one selected lift
itself ceases to exist as a continuous inverse branch, or if the branch becomes
singular/nonselectable.  In a regular finite piecewise-monotone chamber, loss of
a selected lift means termination at a local extremum.  Global balance then
forces a same-level nonlocal return/co-return arch.  This routes the obstruction
back into the v174--v175 relocation machinery.

The second main result is quantitative.  Under uniform Morse nondegeneracy, a
termination cannot remain microscopic unless curvature regularity itself
collapses.  If

\[
|q''(x_*)|\ge \lambda>0
\]

at every relevant extremum and `q''` has a common modulus of continuity, then
the forced return/co-return arch has a fixed positive width and phase depth.
In the `C^3` specialization

\[
\|q'''\|_\infty\le M,
\]

one may take

\[
\boxed{
\text{width}\ge \frac{\lambda}{2M},
\qquad
\text{depth}\ge \frac{\lambda^3}{16M^2}.
}
\]

Conversely, if a return arch from a nondegenerate extremum has width `d`, then

\[
\boxed{\omega_{q''}(d)\ge \lambda,}
\]

and in `C^3`

\[
\boxed{\|q'''\|_\infty\ge \lambda/d.}
\]

Therefore a microscopic root-free event cluster is an explicit **curvature
roughness certificate**.  Under regular Morse geometry there is no independent
finite event-cluster branch.

---

# 1. Selected contact lifts

Let `q:R->R` be continuous and balanced,

\[
|q(t)-t|\le B.
\tag{1.1}
\]

Use **phase-ordered labels** throughout this handoff.  Thus the four selected
contacts satisfy

\[
q(x_j(\eta))=c(\eta)+j,\qquad j=0,1,2,3.
\tag{1.2}
\]

In the geometric `0132` notation used earlier these are

\[
(x_0,x_1,x_2,x_3)=(u_0,u_1,u_3,u_2),
\]

so the correct spatial order is simply

\[
x_0<x_1<x_2<x_3.
\]

Define the additive resonance defect

\[
S(\eta)=x_0(\eta)+x_3(\eta)-x_1(\eta)-x_2(\eta).
\tag{1.3}
\]

This is exactly the coefficient pattern `(+,-,-,+)` from v177--v178.

## Lemma 1.1 — selected-lift persistence

If

\[
S(0)>0,
\qquad
S(T)\le0,
\]

then there is `eta_* in [0,T]` with

\[
S(\eta_*)=0.
\]

This is just the intermediate value theorem, but its interpretation is
important: **births, deaths, or folds of inverse branches that are not among the
four selected lifts do not affect this conclusion.**

## Lemma 1.2 — contact order cannot change on surviving lifts

Suppose two selected contacts correspond to distinct phase offsets `p_i !=
p_j`.  Then

\[
x_i(\eta)\ne x_j(\eta)
\]

for every common parameter value, because one point cannot satisfy

\[
q(x)=c+p_i=c+p_j.
\]

Hence the sign of `x_i-x_j` is constant on every connected interval on which
both lifts survive.  In particular, the one-dimensional `0132` contact order is
automatically preserved along a surviving selected configuration.

This removes another overly broad escape clause from v178: an unrelated branch
birth cannot change the order of already selected contacts.

---

# 2. Consequence for the v178 favorable companion

At a favorable event v178 produces a companion additive branch `S^-(eta)` with

\[
S^-(0)=a>0
\]

and, under the opening hypotheses, a predicted capture depth

\[
T_a=C a^m
\tag{2.1}
\]

for which

\[
S^-(T_a)<0
\tag{2.2}
\]

provided the four selected inverse branches remain admissible through that
layer.

Combining (2.2) with Lemma 1.1 gives:

## Theorem 2.1 — no independent local finite-event obstruction

A root-free favorable v178 event can avoid the exact resonance before `T_a`
only if at least one of the four selected contact lifts fails before `T_a`.

Additional inverse branches may be born inside the same capture layer, but if
the four selected lifts remain continuous, those extra branches are irrelevant
to the root.

Thus the v178 phrase

> another branch/critical event intervenes

should be replaced by the more precise statement

> **one of the selected contact lifts terminates or becomes singular before the
> capture depth.**

This sharply reduces the proposed finite event-cluster problem.

---

# 3. What regular lift failure means

Assume now that on the relevant compact spatial window `q` is piecewise
strictly monotone with finitely many ordinary extrema.

A maximal continuous inverse lift of a moving phase level can fail only when it
reaches an endpoint of one monotonicity interval, i.e. an ordinary local maximum
or minimum.  A flat but monotone critical point does not terminate the inverse
lift; it may destroy differentiability of the inverse but not continuity.

Therefore, in the regular finite-component chamber,

\[
\boxed{
\text{failure of a selected lift}
\Longrightarrow
\text{termination at a local extremum}.
}
\tag{3.1}
\]

Plateaus, infinitely accumulating extrema, or nowhere-locally-injective pieces
belong to the singular branch already isolated in v159--v167.

---

# 4. Every regular termination creates a return/co-return arch

Balance implies

\[
q(t)\to-\infty\quad(t\to-\infty),
\qquad
q(t)\to+\infty\quad(t\to+\infty).
\tag{4.1}
\]

This makes a terminating local extremum globally reconnect to its own phase
level.

## Theorem 4.1 — maximum termination

Let `x_*` be a strict local maximum and

\[
q(x_*)=y_*.
\]

Then there exists a first point `z>x_*` with

\[
q(z)=y_*,
\]

and

\[
q(t)<y_*
\qquad(x_*<t<z).
\tag{4.2}
\]

Thus `[x_*,z]` is a lower return arch.

### Proof

Immediately to the right of a strict local maximum, `q<y_*`.  By (4.1),
`q(t)>y_*` for all sufficiently large `t`.  The first return exists by
continuity, and minimality gives (4.2).

## Theorem 4.2 — minimum termination

Let `x_*` be a strict local minimum with `q(x_*)=y_*`.  Then there is a last
point `z<x_*` with

\[
q(z)=y_*,
\]

and

\[
q(t)>y_*
\qquad(z<t<x_*).
\tag{4.3}
\]

Thus `[z,x_*]` is an upper co-return arch.

Consequently,

\[
\boxed{
\text{selected-branch termination}
\Longrightarrow
\text{nonlocal same-level return/co-return geometry}.
}
\tag{4.4}
\]

This is exactly the object treated by the v174--v175 continuation framework.

---

# 5. Uniform Morse geometry makes the relocation macroscopic

Assume `q` is `C^2` near a terminating maximum `x_*` and

\[
q''(x_*)\le-\lambda<0.
\tag{5.1}
\]

Let `omega_2` be a common modulus for `q''`:

\[
|q''(x)-q''(y)|\le\omega_2(|x-y|).
\tag{5.2}
\]

Choose `r_lambda>0` such that

\[
\omega_2(r_\lambda)\le\lambda/2.
\tag{5.3}
\]

Then for `0<=s<=r_lambda`,

\[
q''(x_*+s)\le-\lambda/2.
\]

Since `q'(x_*)=0`,

\[
q'(x_*+s)\le-\frac\lambda2s,
\]

and hence

\[
q(x_*)-q(x_*+r_\lambda)
\ge\frac\lambda4r_\lambda^2.
\tag{5.4}
\]

The first same-level return cannot occur inside this interval.

## Theorem 5.1 — modulus-controlled termination arch

Under (5.1)--(5.3), the lower return arch forced by Theorem 4.1 has

\[
\boxed{
\text{width}>r_\lambda,
\qquad
\text{depth}\ge\frac\lambda4r_\lambda^2.
}
\tag{5.5}
\]

The corresponding statement holds for a local minimum by reversing signs and
orientation.

Thus uniform nondegenerate curvature plus equicontinuity of the curvature
forbids microscopic termination arches.

---

# 6. C3 specialization

If

\[
\|q'''\|_\infty\le M,
\tag{6.1}
\]

then one may take

\[
r_\lambda=\frac{\lambda}{2M}.
\tag{6.2}
\]

Theorem 5.1 becomes

\[
\boxed{
\text{width}\ge\frac{\lambda}{2M},
\qquad
\text{depth}\ge\frac{\lambda^3}{16M^2}.
}
\tag{6.3}
\]

The constants are deliberately conservative; only a positive uniform lower
bound is important.

This gives a strong routing statement:

> A root-free favorable Morse fold with uniform `C^3` geometry cannot be saved
> by a microscopic local event cluster.  If a selected branch dies before the
> `O(a^2)` capture layer completes, it ejects the problem into a fixed-size
> return/co-return arch.

---

# 7. Shrinking return arches certify curvature roughness

The converse is also quantitative.

Let `x_*` be a local maximum with

\[
q'(x_*)=0,
\qquad
q''(x_*)\le-\lambda,
\]

and suppose `z>x_*` is a same-level return,

\[
q(z)=q(x_*),
\qquad
d=z-x_*.
\]

Rolle's theorem applied to `q` gives a point `xi in (x_*,z)` with

\[
q'(\xi)=0.
\]

Applying Rolle to `q'` on `[x_*,xi]` gives `zeta` with

\[
q''(\zeta)=0.
\]

Therefore

\[
\boxed{
\omega_{q''}(d)\ge\lambda.
}
\tag{7.1}
\]

If `q` is `C^3`, then

\[
\boxed{
\|q'''\|_{L^\infty([x_*,z])}\ge\frac\lambda d.
}
\tag{7.2}
\]

The minimum/co-return version is identical.

Hence a sequence of termination arches with

\[
d_n\to0,
\qquad
|q_n''(x_{*,n})|\ge\lambda
\]

forces loss of equicontinuity of `q_n''`; in `C^3`, the third derivative blows
up at least like `1/d_n`.

This is the promised **curvature-roughness certificate**.

---

# 8. Uniform bound on ordinary Morse event count

The same argument controls event multiplicity in a balanced spatial window.
Assume every relevant critical point is nondegenerate with

\[
|q''(x_c)|\ge\lambda,
\]

and `q''` has common modulus `omega_2`.  Choose `delta>0` so that

\[
\omega_2(\delta)<2\lambda.
\tag{8.1}
\]

Consecutive nondegenerate extrema have opposite signs of `q''`, so they must be
separated by at least `delta`.  Thus an interval of spatial length `L` contains
at most

\[
\boxed{1+L/\delta}
\tag{8.2}
\]

ordinary extrema.

For four consecutive phase levels over a base-phase window of width `H`,
balance confines all relevant contacts to an interval of length at most

\[
L=3+H+2B.
\tag{8.3}
\]

Therefore the total number of ordinary Morse events in the whole capture
chamber is uniformly bounded.

In the `C^3` specialization one may take `delta=2\lambda/M` up to an arbitrarily
small safety factor when comparing opposite signs, yielding the rough count

\[
N_{\rm crit}=O\!\left(1+\frac{M(3+H+2B)}{\lambda}\right).
\tag{8.4}
\]

The exact integer constant is not important; uniform finiteness is.

Conversely, if `N` nondegenerate extrema of curvature magnitude at least
`lambda` occur in an interval of length `L`, then some consecutive pair is
within `L/(N-1)`, so

\[
\boxed{
\omega_{q''}\!\left(\frac{L}{N-1}\right)\ge2\lambda.
}
\tag{8.5}
\]

For `C^3` profiles,

\[
\boxed{
\|q'''\|_\infty
\ge\frac{2\lambda(N-1)}{L}.
}
\tag{8.6}
\]

Thus high event multiplicity itself is a derivative-roughness certificate.

---

# 9. Collapse of the proposed finite event-cluster branch

The v178 recommendation split event clusters into finite and infinite normalized
clusters.  The selected-lift audit changes that split.

## Theorem 9.1 — finite regular cluster routing

Assume:

1. the v178 event is favorable and has an opening law that predicts a root at
   capture depth `T_a=O(a^m)`;
2. the four selected contacts form continuous inverse lifts until they hit an
   ordinary finite-component branch termination;
3. the one-dimensional contact sector is the inherited `0132` order.

Then exactly one of the following occurs before `T_a`:

- an exact additive resonance;
- a selected branch terminates and creates a nonlocal return/co-return arch;
- the selected inverse relation becomes singular (plateau, accumulating folds,
  nowhere-local-injective behavior, or loss of compactness).

There is no fourth possibility consisting only of finitely many unrelated
local branch events.

### Proof

If all four selected lifts survive through `T_a`, Theorem 2.1 and the v178
capture estimate force the root.  An unrelated event does not alter any
selected lift.  Therefore root avoidance requires failure of a selected lift.
In the regular finite-component chamber, Section 3 identifies that failure with
an ordinary extremum, and Section 4 produces the return/co-return arch.  If
Section 3 fails, the branch is singular by definition.

## Corollary 9.2 — uniformly Morse clusters route to visible arches

Under the additional hypotheses of Theorem 5.1, the return/co-return alternative
has fixed positive width and depth.  Hence a microscopic finite cluster cannot
be terminal.

This is the main v179 simplification.

---

# 10. Relationship to v159--v175

The routing is now clean.

### A. Selected branch survives

v178 capture gives an exact root.

### B. Selected branch terminates regularly

Section 4 creates a lower return or upper co-return arch.  The v174--v175
depth-synchronization and post-bottom relocation results apply.

### C. Repeated relocations remain finite and regular

The v175 factor-two clearance descent and v176 compact tangent machinery apply.

### D. Relocations/folds accumulate infinitely

The inverse relation ceases to be finite and regular.  This is exactly the
setting for the v159 signed current and the v161 record-envelope/Stieltjes
formalism.

### E. Termination arches shrink while curvature remains nondegenerate

Section 7 forces curvature roughness.  This joins the noncompact/rough branch
rather than producing a new topological mechanism.

Thus v179 bridges the fold-event analysis back into the already-developed
return/current branches rather than creating a separate event-cluster theory.

---

# 11. What remains genuinely new after v179

The regular finite-event branch is no longer independent.  The unresolved
local mechanisms are now:

1. **sharp event opening** (`m<=1/2` in the v178 notation), where the companion
   branch opens too slowly in space to beat the quadratic fold clearance;
2. **degenerate critical events**, where no uniform Morse curvature scale
   exists;
3. **microscopic return/co-return arches with curvature roughness**;
4. **infinitely accumulating level components**, requiring the Stieltjes/current
   formalism;
5. **loss of equicontinuity / noncompactness**;
6. the inherited global transfer from the phase-profile construction back to
   the original Jordan curve.

A useful conceptual compression is

\[
\boxed{
\text{root-free local cluster}
\Longrightarrow
\text{return geometry or analytic roughness}.
}
\tag{11.1}
\]

There is no longer a generic finite combinatorial cluster sitting between those
branches.

---

# 12. Recommended v180 target

The cleanest next target is the **sharp/degenerate event branch**, because the
regular Morse case now routes away.

Two related quantities should be tracked at a terminating event:

- the phase opening law `W(eta)`;
- the smallest same-level return width `R(eta)` forced by global balance.

A sharp local cusp may have

\[
W(\eta)\ll a
\]

through the fold interval, but it cannot eliminate the global same-level return
structure.  The desired theorem is a two-scale alternative:

\[
\boxed{
\text{local opening too sharp to capture}
\Longrightarrow
\begin{cases}
\text{a visible nonlocal return/co-return arch},\\
\text{or a nested sequence of shrinking returns with a quantitative}\
\text{modulus/variation cost}.
\end{cases}}
\]

The second branch should be compared directly with the v160 variation-density
bound and the v163--v167 critical-entropy machinery.

A second useful route is to replace derivatives entirely by a **curvature-free
turning modulus**: the smallest horizontal scale on which a selected inverse
branch can reverse orientation.  v179 shows that any such scale tending to zero
is precisely the data that must be fed into the singular current.

---

# 13. Audit of claims

### Proved in v179

- Selected continuous contact lifts make the additive defect continuous.
- Unrelated inverse-branch events cannot block the v178 IVT crossing.
- Contact order of distinct exact phase levels is fixed while lifts survive.
- An ordinary selected-branch termination forces a same-level return/co-return
  arch by global balance.
- Uniform Morse curvature plus a common modulus for `q''` gives a fixed lower
  bound on the width and depth of that arch.
- In `C^3`, the explicit conservative bounds are
  `lambda/(2M)` and `lambda^3/(16M^2)`.
- A shrinking return arch at a nondegenerate extremum forces
  `omega_{q''}(d)>=lambda`; in `C^3`, `||q'''||>=lambda/d`.
- Uniform Morse regularity bounds the number of ordinary extrema in every
  balanced compact phase chamber.
- Therefore the finite regular event-cluster branch routes into exact resonance,
  return/co-return geometry, or singularity.

### Not proved in v179

- A sharp cusp (`m<=1/2`) cannot survive.
- Every microscopic return arch forces the square under only `C^0` hypotheses.
- Infinite Stieltjes current cancellation is impossible.
- The remaining phase-profile argument has been transferred to an arbitrary
  Jordan curve.

