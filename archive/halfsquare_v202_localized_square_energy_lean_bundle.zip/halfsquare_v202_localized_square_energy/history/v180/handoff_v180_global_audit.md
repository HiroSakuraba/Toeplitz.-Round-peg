# Project Handoff v180: Global Obstruction Audit and Primitive-Anomaly Extraction

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Status

This continuation does **not** prove the full Toeplitz square-peg conjecture.

It deliberately stops the local branch-by-branch program of v150--v179 and
asks a different question:

> Which obstructions are genuinely independent, which were merely rerouted,
> which proposed closures were later falsified, and what global quantity is
> actually capable of organizing the surviving rough branch?

The audit changes the shape of the program.

The main conclusions are:

1. The thirty-version chain contains many useful local theorems, but only a few
   genuinely independent terminal mechanisms. Most of the apparent branches
   eventually route into **singular infinite folding / loss of compactness**.
2. There is no plausible finite scalar budget for fold count, return count,
   total variation, curvature, or excursion count under the balanced profile
   normalization `q(t)=t+O(1)`. Explicit balanced profiles can have infinitely
   many increasingly sharp folds and infinite variation while their total
   excursion area stays finite.
3. A much better global object is the **second-order area/Liouville primitive**
   of smooth Jordan approximations. The recent Asano--Ike theorem says that
   local-uniform primitive convergence already forces every prescribed
   rectangle class. Li--Pan (4 September 2026) verify this criterion for finite
   `p`-variation with `p<2`.
4. Therefore a hypothetical counterexample must have **primitive
   noncompactness**. By Arzela--Ascoli, this forces fixed primitive jumps on
   parameter intervals shrinking to zero. Uniform convergence of the curves
   makes the corresponding spatial arc diameters tend to zero, so the
   scale-normalized area anomaly diverges.
5. Simplicity turns that analytic anomaly into topology: a simple arc with
   large area relative to its diameter must cross the line through its
   endpoints many times. Quantitatively, normalized primitive anomaly forces
   endpoint-line crossing multiplicity to diverge.
6. The same simple-arc estimate appears strong enough to close the **bounded
   `2`-variation endpoint** of the recent Li--Pan theorem. A self-contained
   project proof is included in `finite_2variation_endpoint_note.md`. This is a
   potentially significant result and should be independently checked before
   any novelty claim.

The practical recommendation is to stop extending the v179 local cusp/event
case tree. The next serious target should be a **primitive-anomaly to intrinsic
Jordan-crossing extraction theorem** and, if the endpoint `p=2` proof survives
external audit, a short standalone note on that theorem.

---

# 1. What v150--v179 actually accomplished

The detailed row-by-row audit is in `audit_v149_v179.csv`. The compressed view
is more useful.

## 1.1 Exceptional smooth geometry: v149--v156

The high-angular-mass shrinking-window map from v149 has a clean smooth
classification.

- Nonexceptional stable profiles force a three-dimensional phase cell.
- Everywhere rank-degenerate smooth profiles are affine or shifted logarithmic.
- The apparent quadratic/cubic/quartic resonance tower is exactly the Taylor
  jet of one moving shifted logarithm.
- Nested shifted-log fits cannot drift independently while both remain accurate
  at the same visible phase scale.
- A continuous nonquadratic residual after exact log flattening already forces
  degree; `C^1` convergence is unnecessary.
- In the strictly monotone balanced critical profile, absence of phase-root
  drift again forces the affine/log exceptional family.

This part of the project is coherent and should be retained as one structural
module rather than thirty separate scale calculations.

## 1.2 Ordinary compact backtracking: v157--v161

The monotone compact branch is essentially closed.

- Plateaus themselves produce degree.
- Genuine nonmonotonicity gives first-hit jumps / return arches.
- Two usable inverse channels around an arch force a phase cell.
- Absence of a single channel is not enough to escape: a folded band still
  carries Brouwer degree.
- Finite regular branches are represented by a signed third-phase interval
  current.
- Persistent finite-branch critical locking forces an interval of
  non-local-injectivity.
- Infinite branch lists admit the exact Stieltjes current identity

  \[
  D_t\mathbf 1_{\{f>y\}}
  =
  \delta_{g(y)}-D_t\mathbf 1_{A_y}.
  \]

This is the correct branch-free language for the singular compact tail.

## 1.3 Fractal persistence and scale proliferation: v162--v170

This section produced several useful bounds, but also several false closure
ideas.

The following proposed implications are **false** and should not be revived
without additional hypotheses:

- flat-small persistence components have small nonlinear third-phase effect;
- large upper-box entropy must ascend to a thicker child core;
- near-level persistence multiplicity compresses to one thick exact phase;
- spatial density plus phase density produces a two-dimensional incidence
  rectangle.

The counterexamples were valuable because they exposed the true critical
objects:

- a critical image of vanishing-persistence cores;
- `2/3`-scale roughness and `1/3` level-set entropy;
- a positive-volume three-patch tangent

  \[
  T(x,y)=\bigl(F(x),G(y),H(x+y)-F(x)\bigr);
  \]

- phase shear below the parent scale;
- lattice residue saturation.

The correct conclusion is not that these form four new terminal obstructions.
They are different manifestations of the same fact: **compactness keeps failing
at successively finer second-order scales**.

## 1.4 Lattice resonance and record excursions: v171--v179

This section made two important corrections.

First, ordinary real Brouwer degree is not enough. The square condition is a
phase-lattice condition. v171 produced an explicit profile with lattice-aligned
first two phases and a third-phase interval trapped around `1/2`.

Second, zero Jacobian is not zero local degree. v177 reduced the four-variable
root to one scalar defect and showed that odd-order touching still has nonzero
degree.

The most durable lattice-aware scalar is the first-hit mixed difference

\[
R(y)=g(y)+g(y+3)-g(y+1)-g(y+2).
\]

`R(y)=0` gives the exact consecutive-level lattice target `(1,3,2)`.

The later record-envelope and relocation work shows that ordinary finite
continuations, regular Morse events, and unrelated finite event clusters are
not independent terminal branches. They either produce a root or route into
return/co-return geometry. A root-free survivor must therefore become sharp,
degenerate, infinitely folded, or noncompact.

---

# 2. The minimal obstruction tree after the audit

The file `obstruction_tree_v180.md` gives the one-page tree. The important
compression is this.

After one enters the v149 high-mass profile regime, every regular finite branch
we have found routes toward one of two genuinely rough objects:

\[
\boxed{
\begin{array}{l}
\textbf{S1.}\ \text{infinite/singular return structure: infinite-perimeter
Stieltjes current,}\\
\qquad\text{critical-image concentration, nowhere-local-injectivity, sharp
cusps;}\\[1mm]
\textbf{S2.}\ \text{loss of compactness/equicontinuity at a new phase or
spatial scale.}
\end{array}}
\]

There is also an **upstream** obstruction inherited from v149:

\[
\boxed{
\textbf{U.}\ \text{bounded-angular-mass packets or failure to extract a stable
high-mass profile.}
}
\]

The local v150--v179 chain never closed `U`. That point is important: even a
perfect cleanup of the current sharp-cusp branch would not by itself prove the
full conjecture.

This is why continuing to v180 as another local event lemma would have been the
wrong allocation of effort.

---

# 3. Why there is no simple one-dimensional termination budget

The balanced critical normalization

\[
q(t)=t+h(t),\qquad |h(t)|\le C
\]

places almost no bound on the number or sharpness of folds.

## Proposition 3.1 -- bounded displacement permits infinite fold complexity

There exists a continuous compactly supported `h` on `[0,1]` such that

\[
\|h\|_\infty\le1,
\]

`q(t)=t+h(t)` has infinitely many local fold events accumulating at `0`, and

\[
\operatorname{Var}(h;[0,1])=\infty,
\]

while

\[
\int_0^1|h(t)|\,dt<\infty.
\]

### Construction

Take pairwise disjoint intervals centered near `2^{-n}` with half-width

\[
w_n=2^{-4n}
\]

and place on the `n`th interval a downward triangular dent of amplitude

\[
a_n=\frac1n.
\]

Then `a_n ->0`, so the dents remain continuous at the accumulation point, but

\[
\sum_n 2a_n=\infty
\]

while

\[
\sum_n a_n w_n<\infty.
\]

The descending side has slope `-a_n/w_n`, whose magnitude tends to infinity, so
`q` is locally decreasing there for all sufficiently large `n`.

This simple example rules out the hope that any of the following can be a
finite universal resource under the balanced profile hypothesis alone:

- number of folds;
- number of return arches;
- total variation;
- curvature / derivative complexity;
- unweighted event count.

Even the basic excursion-area budget can remain finite while infinitely many
folds occur. An effective global invariant has to use information inherited
from the **original planar Jordan geometry**, not merely the one-dimensional
balanced phase profile.

---

# 4. The external global criterion we should now organize around

Let

\[
\lambda=y\,dx
\]

be the Liouville one-form in the planar cotangent coordinates used by
Asano--Ike.

Their theorem can be stated, in the form needed here, as follows.

> If a Jordan curve is uniformly approximated by smooth Jordan curves and the
> corresponding primitives of `lambda` converge locally uniformly, then the
> limiting Jordan curve inscribes a rectangle of every prescribed similarity
> class.

They prove this for rectifiable curves and locally monotone curves.

Li--Pan (arXiv:2609.04918, 4 September 2026) prove that every Jordan curve of
finite `p`-variation with

\[
1\le p<2
\]

satisfies the criterion. Their mechanism is `q`-variation approximation with
`q<2` followed by Young integration.

Thus **primitive compactness is already a complete global route to the square**.

The arbitrary Jordan problem can be reframed as:

\[
\boxed{
\text{Can a Jordan curve fail primitive compactness without forcing the square
by some other mechanism?}
}
\]

That question is much closer to the actual roughness boundary than the local
cusp taxonomy of v179.

---

# 5. Primitive noncompactness forces a shrinking area anomaly

Use the symmetric area form

\[
\alpha=\frac12(x\,dy-y\,dx).
\tag{5.1}
\]

It differs from the Liouville form by an exact term:

\[
y\,dx=\frac12d(xy)-\alpha.
\tag{5.2}
\]

Therefore, under uniform convergence of the curves, precompactness of the two
primitive conventions is equivalent.

Let `c_n:S^1 -> R^2` be smooth Jordan embeddings converging uniformly to a
fixed Jordan parametrization `c`, and normalize

\[
A_n(0)=0,
\qquad
A_n(t)=\int_0^t c_n^*\alpha.
\]

## Theorem 5.1 -- primitive-spike extraction

If `{A_n}` has no uniformly convergent subsequence, then there exist

\[
\varepsilon_0>0,
\qquad
s_n,t_n\in S^1,
\qquad
|s_n-t_n|\to0,
\]

such that

\[
\boxed{
|A_n(t_n)-A_n(s_n)|\ge\varepsilon_0.
}
\tag{5.3}
\]

### Proof

If the normalized family `{A_n}` were equicontinuous, equicontinuity together
with `A_n(0)=0` would imply uniform boundedness on the compact parameter circle.
Arzela--Ascoli would then give a uniformly convergent subsequence. Therefore
failure of precompactness is failure of equicontinuity, which is exactly (5.3).
`square`

For a hypothetical square-free Jordan curve, the Asano--Ike criterion means
that **every** smooth Jordan approximation sequence must fail primitive
precompactness. Hence every such sequence carries primitive spikes of the form
(5.3).

Uniform convergence `c_n -> c` and continuity of `c` imply that the spatial
diameters

\[
r_n=
\operatorname{diam}
 c_n([s_n,t_n])
\]

satisfy

\[
r_n\to0.
\tag{5.4}
\]

Define the scale-normalized primitive anomaly

\[
\boxed{
\mathfrak A_n
=
\frac{|A_n(t_n)-A_n(s_n)|}{r_n^2}.
}
\tag{5.5}
\]

Then

\[
\boxed{
\mathfrak A_n\to\infty.
}
\tag{5.6}
\]

This is the first genuinely global coercive quantity found in the audit. It is
not a finite budget; rather, a hypothetical counterexample is forced to create
arbitrarily large **second-order area density** on shrinking simple arcs.

---

# 6. Primitive anomaly forces diverging line-crossing multiplicity

The primitive increment by itself depends on the chosen origin. Close the
small arc by the straight segment between its endpoints.

Let

\[
\Gamma_n=c_n|_{[s_n,t_n]},
\]

let `L_n` be the line through its endpoints, and define the closed signed area

\[
\mathcal S_n
=
\int_{\Gamma_n}\alpha
+
\int_{[c_n(t_n),c_n(s_n)]}\alpha.
\tag{6.1}
\]

Because all approximants stay in a fixed bounded set, the chord term is
`O(r_n)`. Therefore (5.3)--(5.4) imply

\[
|\mathcal S_n|\ge\frac{\varepsilon_0}{2}
\tag{6.2}
\]

for all sufficiently large `n`.

## Theorem 6.1 -- chord-line crossing lower bound

Let `Gamma` be a simple piecewise `C^1` arc of diameter `r`. Let `L` be the line
through its endpoints. If the interior of `Gamma` meets `L` in `N` points and
the intersection set is finite, then

\[
\boxed{
\left|
\int_\Gamma\alpha+
\int_{\text{endpoint chord}}\alpha
\right|
\le
\pi(N+1)r^2.
}
\tag{6.3}
\]

If the intersection set is infinite, the conclusion `N=infinity` is already the
required complexity statement.

### Proof

Enumerate consecutive line-hit parameters. Every subarc between consecutive
hits, closed by the line segment joining its endpoints, is a Jordan curve. It
lies in a disk of radius `r`, so its area has magnitude at most `pi r^2`.
The line-segment integrals telescope because the restriction of `alpha` to one
fixed affine line is an exact one-dimensional form. Summing the signed loop
areas gives (6.3). `square`

Combining (6.2) and (6.3),

\[
\boxed{
N_n
\ge
\frac{\varepsilon_0}{2\pi r_n^2}-1
\longrightarrow\infty.
}
\tag{6.4}
\]

This is the most useful new global consequence of v180:

\[
\boxed{
\text{primitive noncompactness}
\Longrightarrow
\text{shrinking simple arcs with diverging endpoint-line crossing multiplicity.}
}
\tag{6.5}
\]

This statement is intrinsic to planar simplicity. It does not depend on the
moving-log normal form, first-hit choices, persistence truncations, or local
Morse regularity.

It also explains why the local program kept seeing more and more folds. Those
folds are not an accidental pathology of the chosen phase coordinate. A global
failure of the area primitive literally forces unbounded local crossing
complexity.

---

# 7. A stronger simple-arc estimate: area costs quadratic variation

The crossing proof gives a sharper estimate if each line-separated subarc is
charged by its own diameter.

## Theorem 7.1 -- simple-arc `2`-variation area inequality

For a simple polygonal arc `sigma`,

\[
\boxed{
\left|
\int_\sigma\alpha
+
\int_{\text{endpoint chord}}\alpha
\right|
\le
\pi\|\sigma\|_{2\text{-var}}^2.
}
\tag{7.1}
\]

The proof is in `finite_2variation_endpoint_note.md`. It decomposes at
intersections with the endpoint line, bounds each Jordan loop by the square of
its diameter, and observes that the sum of those diameter squares is dominated
by one common `2`-variation partition.

This estimate is unavailable for arbitrary nonsimple rough paths. It is exactly
the additional geometric input supplied by Jordan simplicity.

---

# 8. Potential endpoint improvement: bounded `2`-variation

Theorem 7.1 appears to close the critical endpoint omitted by the current
Li--Pan theorem.

## Project Theorem 8.1 -- endpoint rectangular peg theorem

Let `c:S^1 -> R^2` be a Jordan parametrization with bounded `2`-variation:

\[
\|c\|_{2\text{-var}}<\infty.
\]

Then `c` satisfies the Asano--Ike primitive-convergence criterion and therefore
inscribes a rectangle of every prescribed similarity class.

The complete proof is separated into
`finite_2variation_endpoint_note.md`. Its structure is:

1. choose simple polygonal interpolants through points of `c`;
2. polygonal interpolation does not increase local `2`-variation;
3. finite `2`-variation gives a continuous local variation control;
4. Theorem 7.1 makes the polygonal area primitives equicontinuous;
5. Arzela--Ascoli gives a primitive-convergent subsequence;
6. smooth each polygon in arbitrarily small `1`-variation;
7. a direct integration-by-parts estimate shows the primitives change by `o(1)`;
8. switch from the symmetric area primitive to the Liouville primitive using
   the exact identity (5.2);
9. apply Asano--Ike.

This would strengthen Li--Pan's

\[
p<2
\]

result to

\[
\boxed{p\le2}
\]

for Jordan curves, with the endpoint relying essentially on simplicity rather
than Young integration.

### Audit warning

A targeted web search on 8 September 2026 did not locate this endpoint theorem,
but that is **not** a novelty claim. Given the number of corrections found in
v159--v179, this result should be independently checked line by line before
circulation. In particular, the simple-arc area decomposition and the local
polygonal `2`-variation estimate deserve external verification.

The result is nevertheless sufficiently clean that it should be separated from
the main Toeplitz labyrinth and audited on its own.

---

# 9. Relation to the v149 radial phase profile

The global primitive viewpoint is not separate from the phase-profile work. On
a smooth radial arc

\[
\gamma(T)=e^{-T}e^{iF(T)},
\]

one has exactly

\[
\boxed{
\gamma^*\alpha
=
\frac12e^{-2T}\,dF(T).
}
\tag{9.1}
\]

Suppose

\[
\frac{F(T_n+\delta_nt)-F(T_n)}{A_n}
\to f(t)
\]

uniformly on a fixed profile interval, with `delta_n ->0`. Then integration by
parts gives

\[
\boxed{
\frac{2e^{2T_n}}{A_n}
\left(
A(T_n+\delta_nt)-A(T_n)
\right)
\to f(t).
}
\tag{9.2}
\]

Indeed, with `G_n(u)=F(T_n+u)-F(T_n)`,

\[
\int_0^{\delta_nt}e^{-2u}\,dG_n(u)
=
e^{-2\delta_nt}G_n(\delta_nt)
+2\int_0^{\delta_nt}e^{-2u}G_n(u)\,du,
\]

and the integral term is `o(A_n)` because `delta_n ->0`.

Thus the v149 high-angular-mass profile `f` is, to leading order, exactly a
**blow-up profile of the area primitive**.

This is the conceptual unification the local program was missing.

The affine/shifted-log profile classification, the critical rough residuals,
the first-hit return currents, and the lattice-resonance defects can all be
viewed as increasingly singular normal forms for failure of primitive
compactness.

---

# 10. The global program after v180

The next work should not be “v181: sharper cusp case.” It should address the
primitive anomaly directly.

## Target A -- audit the bounded `2`-variation endpoint theorem

This is now the cleanest discrete mathematical deliverable. Check the proof
against:

- the exact Asano--Ike hypotheses;
- local `2`-variation control for Boedihardjo--Geng interpolants;
- degenerate collinear cases in Theorem 7.1;
- smoothing while preserving primitive convergence;
- parameter-lift periodicity.

If it survives, write it as a short standalone note.

## Target B -- transfer primitive anomaly to the actual Jordan curve

Theorem 6.1 currently produces large endpoint-line crossing multiplicity in
**smooth approximants**. Choose canonical simple polygonal interpolants through
actual curve points, then smooth them with primitive error tending to zero.
The desired bridge is:

\[
\boxed{
\text{large polygonal endpoint-line crossing multiplicity}
\Longrightarrow
\text{large intrinsic crossing/return complexity of the corresponding
Jordan subarc}.
}
\]

Transverse polygon-edge crossings already transfer by the intermediate value
theorem because the edge endpoints lie on the actual curve. The hard part is
controlling tangencies, collinear degeneracies, and concentration near the
subarc endpoints.

## Target C -- connect crossing multiplicity back to the lattice map

Once actual shrinking Jordan subarcs carry `N_n -> infinity` crossings of a
single line, ask for a direct configuration-space consequence rather than
reintroducing all v159--v179 cases. The ideal theorem would convert high
crossing multiplicity into either:

1. a nonexceptional high-mass profile already closed by v149--v156;
2. a first-hit consecutive-level resonance already closed by v172--v174; or
3. a genuinely scale-invariant singular current with a nonzero lattice shadow.

This is the right place to reuse the local machinery.

---

# 11. What should be frozen

Until Targets A--C are resolved, the following lines of work should be frozen:

- fifth/sixth/... shifted-log jet calculations;
- new finite branch enumeration;
- new local Morse subcases;
- another phase-shear normalization without a global primitive interpretation;
- upper-box entropy escalation by itself;
- real-valued Brouwer cells without an explicit lattice-shadow statement.

They have already yielded the structural information we need. Continuing them
now is more likely to reproduce the labyrinth than to close it.

---

# 12. Bottom line

The v150--v179 program was not wasted. It identified how a hypothetical
counterexample must become pathological. But the audit shows that pathology is
not a finite resource at the one-dimensional profile level.

The new global statement is cleaner:

\[
\boxed{
\text{square-free Jordan curve}
\Longrightarrow
\text{failure of primitive compactness}
\Longrightarrow
\text{diverging normalized local area anomaly}
\Longrightarrow
\text{diverging local line-crossing complexity}.
}
\]

And, subject to independent audit, simplicity may already push the known
variation threshold from

\[
p<2
\]

to

\[
\boxed{p\le2.}
\]

That is a more promising direction than adding another layer to the local
obstruction tree.


---

# 13. Verification status

`code/verify_v180.py` passes **12/12 grouped checks**.  The verifier audits the
Liouville/area algebra, radial primitive identity, smoothing expansion,
simple-polygon `2`-variation area inequality on deterministic and randomized
samples, endpoint-line crossing bound, the absence of a one-dimensional fold
budget, primitive-anomaly scaling, and polygonal interpolation sanity checks.

The separate `results/theorem_audit_v180.md` records which statements are
proved internally and why the bounded-`2`-variation endpoint theorem should
still receive an independent referee-level audit before any novelty claim.
