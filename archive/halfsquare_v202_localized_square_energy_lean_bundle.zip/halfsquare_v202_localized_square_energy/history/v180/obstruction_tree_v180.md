# v180 obstruction tree

This is the compressed obstruction tree after auditing v149--v179. `CLOSED`
means closed under the stated local hypotheses, not that the full Toeplitz
conjecture is proved.

```text
Hypothetical square-free Jordan collision tail
|
+-- A. Primitive-compact approximation exists
|      -> CLOSED EXTERNALLY by Asano--Ike rectangular-peg criterion.
|
+-- B. Primitive approximation is noncompact
       |
       +-- B1. High normalized area/angular mass admits a stable local profile
       |      |
       |      +-- nonexceptional profile
       |      |      -> CLOSED (v149, v154)
       |      |
       |      +-- affine / shifted-log exceptional profile
       |             -> resummed and overlap-coherent (v150--v153)
       |             -> first visible nonquadratic residual CLOSED (v154)
       |             -> critical balanced profile (v155)
       |                    |
       |                    +-- monotone / plateau
       |                    |      -> CLOSED (v156--v157, v174)
       |                    |
       |                    +-- finite regular backtracking
       |                    |      -> channels/current/relocation/fold events
       |                    |      -> CLOSED OR ROUTED (v158--v160, v172--v179)
       |                    |
       |                    +-- singular / infinitely folded / rough
       |                           -> OPEN CORE
       |                           -> Stieltjes infinite-perimeter current,
       |                              persistence critical image, sharp cusps,
       |                              loss of equicontinuity (v161--v179)
       |
       +-- B2. No stable high-mass profile / bounded-mass packet cascade
              -> OPEN UPSTREAM CORE (already present in v149)
```

## What is not an independent terminal branch anymore

The following mechanisms were useful intermediate descriptions but are not
independent leaves after the later audits:

- moving shifted-log pole drift -- absorbed by overlap coherence (v153);
- monotone plateaus -- closed (v157, v174);
- absence of a single inverse channel -- replaced by multivalued degree (v159);
- finite regular signed branch cycles -- eliminated/routed into singularity
  (v159--v160);
- dense tiny first-hit jumps -- approximate channels recover them (v161);
- generic persistence truncation -- false, replaced by critical image (v162);
- exact-phase compression -- false (v168);
- literal 2D persistence rectangle -- false (v170);
- real Brouwer degree away from the lattice -- insufficient (v171);
- zero Jacobian determinant -- insufficient to diagnose zero degree (v177);
- finite unrelated event clusters -- irrelevant once selected branches survive
  (v179).

## Minimal internal frontier

After compression, the local profile program has only two genuinely different
unresolved mechanisms:

1. **upstream extraction failure:** bounded-mass packets / no stable profile;
2. **downstream singular roughness:** infinitely accumulating return structure,
   infinite-perimeter excursion current, sharp/degenerate critical events, or
   loss of equicontinuity.

v180 reframes both as manifestations of **failure of second-level area/primitive
compactness** of the original Jordan curve.
