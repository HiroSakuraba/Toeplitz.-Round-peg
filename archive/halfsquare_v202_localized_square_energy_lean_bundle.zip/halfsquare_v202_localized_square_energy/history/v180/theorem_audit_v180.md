# v180 theorem audit

**Date:** 8 September 2026

This audit distinguishes statements that are elementary consequences of the
project setup from the one potentially publishable endpoint theorem.

## A. Global primitive anomaly package

### A1. Primitive-spike extraction — PASS

For normalized continuous primitives on a compact parameter circle,
non-precompactness implies non-equicontinuity by Arzelà–Ascoli. Therefore there
are shrinking parameter intervals carrying a fixed primitive jump.

### A2. Spatial diameter collapse — PASS

If smooth Jordan approximants converge uniformly to a fixed Jordan
parametrization, images of parameter intervals whose lengths tend to zero have
diameters tending uniformly to zero.

### A3. Endpoint-line crossing estimate — PASS

For a simple piecewise-C1 arc, finite intersection with the endpoint line
splits the arc into simple loops after chord closure. Each loop is contained in
a disk of radius equal to the diameter of its subarc. The line integrals
telescope. If the endpoint-line intersection is infinite, the desired
complexity conclusion is already present.

Thus a fixed chord-closed area on arcs of diameter `r_n -> 0` forces crossing
multiplicity `N_n -> infinity`, quantitatively `N_n = Omega(r_n^{-2})`.

## B. Simple-arc quadratic-variation estimate

### B1. Polygonal chord-closed area inequality — PASS

For a simple polygonal arc `sigma`, cut at its intersections with the line
through its endpoints. If the resulting subarc diameters are `D_j`,

`|closed area| <= pi sum_j D_j^2`.

A common parameter partition can contain one diameter-realizing pair in every
disjoint subarc, hence

`sum_j D_j^2 <= ||sigma||_{2-var}^2`.

Therefore

`|closed area| <= pi ||sigma||_{2-var}^2`.

The numerical verifier checks this on 500 random simple x-monotone polygons in
addition to deterministic oscillatory examples.

### B2. Polygonal interpolation variation bound — PASS

For `p>=1`, the `p`-variation of a piecewise affine interpolation is attained
on a subsequence of polygon vertices: for a partition point moving on one
straight edge, the adjacent contribution is a convex function of the edge
parameter, so its maximum occurs at an endpoint. Iterating removes all
interior-edge partition points. Hence interpolation through values of the
original path does not increase `p`-variation.

### B3. Local 2-variation control — PASS, standard

For a continuous path with finite 2-variation,
`omega(s,t)=||x||_{2-var;[s,t]}^2` is a continuous control. Therefore its local
2-variation tends uniformly to zero as `t-s -> 0`.

## C. Candidate endpoint theorem

### Statement

Every planar Jordan curve admitting a parametrization of finite 2-variation
satisfies the Asano–Ike primitive-compactness criterion and therefore inscribes
a rectangle of every prescribed similarity class.

### Internal proof chain

1. Use Boedihardjo–Geng arbitrarily fine simple piecewise-geodesic interpolation
   of a Jordan curve. In the Euclidean plane these are simple polygons.
2. The interpolants converge uniformly and do not increase 2-variation.
3. Local finite 2-variation plus the simple-arc area inequality gives
   equicontinuity of the polygonal symmetric-area primitives.
4. Arzelà–Ascoli supplies a uniformly convergent primitive subsequence.
5. Smooth each finite polygon inside disjoint tiny vertex neighborhoods. The
   difference path can be arranged to have arbitrarily small 1-variation;
   Lemma 3.1 then makes the primitive perturbation arbitrarily small.
6. The symmetric-area primitive and the Liouville primitive differ by an exact
   endpoint term, so Liouville primitives converge locally uniformly on the
   lifted parameter line.
7. Apply Asano–Ike.

### External consistency checks

- Boedihardjo–Geng explicitly construct arbitrarily fine simple piecewise
  geodesic interpolations of Jordan curves.
- Li–Pan explicitly use those interpolants in their 2026 finite-p-variation
  rectangular-peg theorem, but state their result for `p<2`.
- General 2-variation area continuity is known to be critical/delicate for
  arbitrary paths. The v180 estimate exploits simplicity, so it does not
  contradict general rough-path counterexamples.

### Status

**INTERNALLY CONSISTENT / INDEPENDENT AUDIT REQUIRED.**

No priority or novelty claim should be made from the targeted literature search
alone. Before circulation, the proof should be checked independently at least
for:

- the local 2-variation estimate on the particular Boedihardjo–Geng
  interpolation sequence;
- the 1-variation-small smoothing construction with a common parametrization;
- exact matching of primitive normalization/orientation conventions in the
  Asano–Ike criterion;
- whether an endpoint finite-2-variation result already exists under different
  terminology.

## D. Computational verifier

`code/verify_v180.py` passes 12/12 grouped checks. These checks validate algebra
and finite models only; they are not a substitute for a proof of the endpoint
theorem.
