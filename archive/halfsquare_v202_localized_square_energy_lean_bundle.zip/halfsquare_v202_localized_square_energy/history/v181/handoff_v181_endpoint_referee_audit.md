# Project Handoff v181: Referee audit of the finite-2-variation endpoint

**Author:** Benjamin John Schulz  
**Date:** 8 September 2026

## Result

v181 does not continue the local Toeplitz obstruction tree. It audits the most
consequential new statement from v180:

> Every planar Jordan curve admitting a finite-2-variation parametrization
> satisfies the Asano--Ike primitive-convergence criterion and therefore
> inscribes every prescribed rectangle similarity class.

After a hostile internal audit, no fatal gap was found. The proof has been
rewritten in `finite_2variation_endpoint_revised.md` with two repairs:

1. endpoint-line subsegments are handled by an exact component decomposition and
   telescoping identity;
2. local quadratic-variation control is stated quantitatively on the actual
   simple interpolation partitions.

The remaining status is **candidate theorem / external review required**.

## Why the theorem is plausible

Li--Pan's September 4 paper already supplies two of the three approximation
ingredients:

- simple affine interpolants through arbitrarily fine partitions;
- arbitrarily small 1-variation smoothing of every Jordan polygon.

The new endpoint ingredient is the simple-arc estimate

\[
\left|
\int_\sigma\alpha+
\int_{[q,p]}\alpha
\right|
\le
\pi\|\sigma\|_{2\mathrm{-var}}^2.
\]

For simple polygonal interpolants this turns finite local 2-variation into
primitive equicontinuity. Arzelà--Ascoli gives a primitive-convergent subsequence,
and Li--Pan's smoothing lemma transfers it to smooth Jordan embeddings.
Asano--Ike then gives the rectangles.

## What changed relative to v180

### Strengthened

- The chord decomposition now works verbatim even when polygonal segments lie on
  the endpoint line.
- The local interpolation estimate is explicit:

\[
V_2(P_n;[s,t])^2
\le
\Omega_*(|t-s|+2\delta_n).
\]

- The ordinary spatial diameter term is explicitly bounded by

\[
\omega_c(|t-s|)+2\omega_c(\delta_n).
\]

- The periodic lift of the Liouville primitive is written out rather than
  asserted.
- Li--Pan's published/preprint interpolation and smoothing lemmas are used
  directly, reducing the amount of new proof machinery.

### Downgraded / still open

- No novelty claim is made.
- No claim is made that area is continuous on the whole 2-variation path space.
- The proof still needs independent expert scrutiny, especially because the
  endpoint is known to be delicate in rough-path theory.

## Referee verdict

`referee_audit_v181.md` reaches:

**LIKELY CORRECT AFTER REPAIR; INDEPENDENT REVIEW REQUIRED.**

This is materially stronger than v180's "internally consistent" status, but is
not equivalent to peer review.

## Consequence for the Toeplitz program if the theorem survives

A hypothetical Jordan counterexample must have

\[
\boxed{V_2(c)=\infty}
\]

for every parametrization (equivalently, for the curve's reparametrization
class). Combined with Li--Pan, this moves the known variation boundary from
"infinite p-variation for every p<2" to the endpoint itself.

That is a more useful global constraint than another local cusp lemma.

## Recommended next action

Do **not** return immediately to v179-style local branching. The next two tasks
should be:

1. seek independent mathematical criticism of the endpoint theorem;
2. if it survives, investigate whether v180's primitive anomaly can be upgraded
   from "many endpoint-line crossings" to a quantitative lower bound on local
   2-variation, potentially linking a general square-free curve directly to
   unavoidable infinite quadratic variation.
