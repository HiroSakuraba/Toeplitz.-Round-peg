# Literature snapshot for v181

Checked 8 September 2026.

## Asano--Ike

*The rectifiable rectangular peg problem*, arXiv:2412.21057v3.

Theorem 1.1 assumes a Jordan curve is uniformly approximated by smooth Jordan
curves and that lifted primitives of the Liouville form converge locally
uniformly. Under those hypotheses every prescribed rectangle angle occurs.

## Li--Pan

*Rectangular Pegs on Jordan Curves of Finite p-Variation*, arXiv:2609.04918v1,
4 September 2026.

They prove the rectangular peg theorem for finite p-variation with
\(1\le p<2\). Their paper supplies two ingredients used in v181:

- affine polygonal interpolation does not increase p-variation (Lemma 2.2);
- every Jordan polygon can be smoothed through Jordan embeddings with
  arbitrarily small 1-variation difference (Lemma 3.1).

Their endpoint restriction arises because their primitive convergence uses
Young integration after convergence in some q-variation with q<2.

## Boedihardjo--Geng

*Simple Piecewise Geodesic Interpolation of Simple and Jordan Curves with
Applications*, Constr. Approx. 42 (2015), 161--180, arXiv:1309.1576.

They construct arbitrarily fine simple piecewise-geodesic interpolations of
Jordan curves. In the Euclidean plane these are simple polygonal interpolants.

## Critical rough-path obstruction

D. Yang, *Notes on area operator, geometric 2-rough paths and Young integral
when p^{-1}+q^{-1}=1*, arXiv:1204.0112.

This documents the critical nature of area at p=2 for general paths. v181 does
not claim general 2-variation continuity; it uses simplicity of a special
approximating sequence.

## Priority search

Targeted searches for "finite 2-variation", "bounded 2-variation",
"quadratic variation", "Jordan curve", and "rectangular/square peg" found the
Li--Pan p<2 paper but no p=2 endpoint theorem. This is only a negative targeted
search, not a proof of novelty.
