# Referee audit of the finite-2-variation endpoint argument

**Date:** 8 September 2026  
**Object audited:** `finite_2variation_endpoint_note.md` from v180  
**Verdict:** mathematically plausible and internally complete after repair; no fatal gap found; independent expert audit still required

## 1. Executive verdict

I tried to break the v180 endpoint theorem at the four places where a critical
\(p=2\) argument is most likely to fail:

1. the chord-closed area estimate for a simple polygonal arc;
2. localization of quadratic variation on the actual simple interpolants;
3. smoothing without losing primitive convergence;
4. exact compatibility with the Asano--Ike hypothesis.

No counterexample was found. Two statements in v180 were too compressed, but
both admit clean repairs:

- polygonal subsegments lying on the endpoint line must be retained in the
  telescoping identity rather than informally "collapsed";
- local \(2\)-variation decay must be applied through the continuous
  p-variation control and the nearest interpolation vertices.

After those repairs, the proof chain is coherent.

My referee-style recommendation would be **major revision, then external
review**, not rejection. The remaining uncertainty is priority and the
possibility of a subtle literature-level endpoint obstruction not exposed by
this internal audit.

## 2. Audit of the key area lemma

### Claim

For a simple polygonal arc \(\sigma\) with endpoint chord,

\[
|A_{\rm chord}(\sigma)|\le \pi V_2(\sigma)^2.
\]

### Stress test A: many crossings of the endpoint line

Cut at connected components of the complement of the endpoint line, rather
than merely enumerating isolated intersections. Every off-line component closes
with a line segment to a Jordan loop. The line restriction of
\(\alpha=\tfrac12(x\,dy-y\,dx)\) is exact, so the loop-closing line integrals
and the genuine line portions of \(\sigma\) telescope to the single endpoint
chord. This repairs the only real presentation issue in v180.

### Stress test B: another part of the arc crosses the closing chord

This does not invalidate the Jordan property of a single off-line subarc plus
its chord. The subarc itself avoids the endpoint line in its interior; external
parts of the original arc are irrelevant to whether that closed subarc is a
simple Jordan loop.

### Stress test C: area larger than the subarc diameter budget

A Jordan loop made from a subarc of diameter \(D\) and its chord has boundary
inside a disk of radius \(D\); the bounded component is inside that convex disk.
Hence its area is at most \(\pi D^2\). A common partition can contain one
pair realizing each disjoint subarc diameter, giving
\(\sum D_j^2\le V_2^2\).

### Verdict

**PASS after wording repair.**

## 3. Audit of the interpolation step

Li--Pan prove explicitly that affine interpolation through a partition does not
increase \(p\)-variation for any \(p\ge1\). They also quote
Boedihardjo--Geng's theorem in the exact form needed here: arbitrarily fine
parameter partitions can be chosen whose affine interpolants remain Jordan.

For an arbitrary short interval \([s,t]\), enlarge to the nearest interpolation
vertices. If the polygon mesh is \(\delta_n\), the enlarged interval has length
at most \(|t-s|+2\delta_n\). Therefore

\[
V_2(P_n;[s,t])^2
\le
\Omega_*(|t-s|+2\delta_n),
\]

where \(\Omega_*\) is the local quadratic-variation control of the original
curve. This is the correct endpoint localization.

### Verdict

**PASS.** The v180 phrase "standard" should be replaced by the explicit local
inequality.

## 4. Audit of local 2-variation decay

For a continuous path of finite \(p\)-variation, the map

\[
(s,t)\mapsto \|c\|_{p\mathrm{-var};[s,t]}^p
\]

is the standard continuous p-variation control. Thus local p-variation tends
uniformly to zero on shrinking parameter intervals. This is a standard rough
paths fact and is exactly what is required; no Young integral is invoked.

### Verdict

**PASS, standard theorem.** A formal citation should be added in any paper
version.

## 5. Audit of primitive equicontinuity

For a short polygonal subarc,

\[
|A_n(t)-A_n(s)|
\le
\pi V_2(P_n;[s,t])^2
+\frac R2\operatorname{diam}P_n([s,t]).
\]

The first term is controlled by local \(2\)-variation. The second tends to zero
uniformly because the polygons converge uniformly to the continuous limiting
curve. This gives tail equicontinuity; finitely many initial primitives cause no
problem.

Arzelà--Ascoli then supplies a convergent subsequence, which is enough because
Asano--Ike require the existence of a suitable smooth approximating sequence.

### Verdict

**PASS.**

## 6. Audit of smoothing

The v180 smoothing assertion need not be reproved. Li--Pan Lemma 3.1 already
states: for every parametrized Jordan polygon \(P\) and \(\eta>0\), there is a
smooth Jordan embedding \(S\) with the same base point and

\[
\|S-P\|_{1\mathrm{-var}}<\eta.
\]

Their proof uses periodic mollification, proves local regularity at every
vertex, then uses uniform closeness and compactness to preserve global
injectivity.

The elementary primitive stability estimate

\[
\|A_S-A_P\|_\infty
\le \frac32R\eta+\frac12\eta^2
\]

then transfers the primitive limit to the smooth curves.

### Verdict

**PASS, now externally supported by Li--Pan's exact lemma.**

## 7. Audit of Asano--Ike compatibility

Li--Pan restate the Asano--Ike criterion in the exact form needed:

- smooth Jordan parametrizations converge uniformly to the target Jordan curve;
- after periodic lifting, primitives of \(y\,dx\) converge locally uniformly.

The symmetric area form satisfies

\[
y\,dx=\frac12d(xy)-\alpha,
\]

so uniform convergence of the curves plus uniform convergence of
\(\alpha\)-primitives gives uniform convergence of the Liouville primitives on
one period. Since the one-period increments also converge, the periodic lifts
converge locally uniformly on \(\mathbb R\).

### Verdict

**PASS.**

## 8. Audit against critical rough-path counterexamples

The known endpoint failure says that Lévy area is not a continuous operator on
arbitrary \(2\)-variation paths. That does not contradict this theorem. The
proof never asserts such continuity. It uses a special sequence of **simple
Jordan interpolants** and an area estimate that is false without simplicity.

The distinction is substantive, not semantic: general counterexamples create
anomalous area by small loops; the simple-arc lemma prices those loops against
quadratic variation because the approximants cannot self-intersect.

### Verdict

**NO CONTRADICTION FOUND.**

## 9. Attempts to find a literature collision

Searches on 8 September 2026 for combinations of

- finite / bounded 2-variation;
- quadratic variation;
- Jordan curves;
- rectangular peg / square peg;

returned Li--Pan's new \(p<2\) theorem but no endpoint \(p=2\) statement.
Boedihardjo--Geng's paper discusses finite \(p\)-variation applications only
for \(p<2\). This does not establish novelty.

### Verdict

**PRIORITY UNRESOLVED.**

## 10. Referee recommendation

If this were submitted as a short note, I would ask for the following before
acceptance:

1. replace the informal endpoint-line "collapse" by the exact component
   decomposition and telescoping identity;
2. state and cite the continuity of the p-variation control;
3. use Li--Pan's Lemmas 2.2 and 3.1 directly for interpolation and smoothing;
4. write the lifted Liouville primitive convergence explicitly;
5. add a paragraph explaining why Yang-type critical rough-path examples do not
   violate the simple-arc estimate;
6. obtain at least one independent expert check of the area lemma and endpoint
   localization;
7. make no priority claim until a broader literature search is completed.

Subject to those points, **I currently regard the theorem as likely correct.**
