# v181 theorem status

## Candidate theorem

Every planar Jordan curve admitting a finite-2-variation parametrization
inscribes a rectangle of every prescribed similarity class.

## Internal status

**PASS AFTER REPAIR / EXTERNAL REVIEW REQUIRED**

### Proof dependencies checked

- [x] simple polygonal interpolants with mesh -> 0;
- [x] interpolation does not increase 2-variation;
- [x] exact chord-line decomposition including line-contained polygon pieces;
- [x] chord-closed area <= pi times local 2-variation squared;
- [x] local 2-variation control tends uniformly to zero;
- [x] area primitives of polygonal interpolants are equicontinuous;
- [x] Arzela--Ascoli subsequence is sufficient;
- [x] 1-variation-small Jordan smoothing exists (Li--Pan Lemma 3.1);
- [x] primitive perturbation under 1-variation smoothing is controlled;
- [x] symmetric-area and Liouville primitives differ by an exact endpoint term;
- [x] one-period primitive convergence implies local-uniform convergence on the periodic lift;
- [x] Asano--Ike criterion matches the resulting approximation.

### Nonclaims

- [ ] no claim of priority;
- [ ] no claim of continuity of Levy area on arbitrary 2-variation paths;
- [ ] no claim that this has received independent peer review.

## Referee-style recommendation

Prepare a short standalone note only after at least one external expert has
checked Theorem 2.1 and the local 2-variation localization. If that check is
positive, this endpoint theorem is more important than continuing the local
v150--v179 obstruction tree.
