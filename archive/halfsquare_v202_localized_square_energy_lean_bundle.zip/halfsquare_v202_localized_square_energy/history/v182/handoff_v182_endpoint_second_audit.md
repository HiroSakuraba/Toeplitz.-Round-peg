# Handoff v182 - second independent audit of the finite-2-variation endpoint

## Executive result

The candidate endpoint theorem survives a second audit performed from a different proof perspective.

The critical new estimate improves to

\[
\boxed{
\left|\int_\sigma \frac12(x\,dy-y\,dx)
+\int_{[q,p]}\frac12(x\,dy-y\,dx)
\right|
\le \frac\pi4 V_2(\sigma)^2
}
\]

for every injective polygonal arc `sigma` from `p` to `q`.

The revised standalone theorem is:

\[
\boxed{
\text{Jordan parametrization of finite 2-variation}
\Longrightarrow
\text{rectangle of every prescribed similarity class}.
}
\]

This remains a project theorem pending independent external verification and priority checking.

---

## 1. Why the new `pi/4` proof is stronger

v180-v181 bounded each lobe cut off by the endpoint line using a disk of radius equal to the subarc diameter, giving the coarse constant `pi`.

The independent audit instead observes:

1. the lobe boundary is the simple subarc plus a chord in the endpoint line;
2. that whole boundary lies in the convex hull of the subarc;
3. the convex hull has the same diameter `D` as the subarc;
4. the Jordan domain lies in that convex hull;
5. the planar isodiametric inequality gives area at most `pi D^2 / 4`.

No cancellation among different lobes is required.

The sum of `D_k^2` is bounded by one 2-variation partition because the endpoint-line components are disjoint in parameter.

---

## 2. Endpoint-line degeneracy is explicitly handled

A polygonal arc may itself contain nontrivial segments lying in its endpoint line. These are not deleted or collapsed.

The restriction of

\[
\alpha=\frac12(x\,dy-y\,dx)
\]

to a fixed affine line is exact. The line-segment contributions, the lobe-closing chords, and the final endpoint chord therefore telescope algebraically.

This repairs the main presentation weakness identified in the first audit.

---

## 3. The approximation chain is now minimal

Only one endpoint-specific lemma is new.

The remaining inputs are already available:

- **Boedihardjo--Geng:** arbitrarily fine simple polygonal interpolation of a Jordan curve.
- **Li--Pan Lemma 2.2:** affine interpolation does not increase p-variation and converges uniformly as the mesh shrinks.
- **Li--Pan Lemma 3.1:** every Jordan polygon admits a smooth Jordan embedding arbitrarily close in 1-variation, with base point fixed.
- **Asano--Ike Theorem 1.1:** uniform smooth Jordan approximation plus locally uniform convergence of Liouville primitives forces every prescribed rectangle class.

The endpoint proof does not use Young integration.

---

## 4. Local 2-variation control

For the limiting parametrization `c`, set

\[
\Omega_*(\delta)
=
\sup_{|t-s|\le\delta}V_2(c;[s,t])^2.
\]

For a continuous path of finite 2-variation,

\[
\Omega_*(\delta)\to0.
\]

If `P_n` is a simple interpolation of mesh `delta_n`, enlarging `[s,t]` to the nearest interpolation vertices gives

\[
V_2(P_n;[s,t])^2
\le
\Omega_*(|t-s|+2\delta_n).
\]

Together with the ordinary modulus of continuity and the simple-arc estimate, this gives equicontinuity of the polygonal area primitives.

No convergence in the 2-variation norm is claimed.

---

## 5. Primitive smoothing remains endpoint-safe

If `S=P+H`, `H(0)=0`, and `||H||_{1-var}<=eta`, then

\[
\sup_t|A_S(t)-A_P(t)|
\le
\frac32R\eta+\frac12\eta^2.
\]

The important feature is the absence of `Var(P)` on the right-hand side. Polygonal lengths may diverge without damaging primitive convergence.

---

## 6. Asano--Ike normalization repaired

Asano--Ike normalize the area of the limiting Jordan domain to `pi`.

v181 implicitly used scale invariance but did not explicitly perform the normalization. v182 does:

\[
s=\sqrt{\pi/|D|}.
\]

Scale the curve before constructing approximants. Finite 2-variation is preserved up to the expected multiplicative factor, and the conclusion concerns rectangle similarity classes, so the normalization is harmless.

---

## 7. Why general p=2 rough-path counterexamples do not refute this

The general area operator is critical at p=2 and is not a bounded continuous operator on the whole path space.

The candidate theorem says something narrower:

- start from a **Jordan embedding**;
- choose **simple Jordan polygonal interpolants**;
- use a planar simple-arc inequality to prove primitive compactness for that sequence;
- smooth those polygons in 1-variation.

The proof never asserts that arbitrary 2-variation approximations have convergent area.

---

## 8. Computational checks

`code/verify_v182.py` checks:

- 3,000 random injective x-monotone polygonal arcs;
- deterministic high-crossing endpoint-line weaves through 129 vertices;
- exact dynamic-programming computation of polygonal 2-variation squared;
- similarity scaling;
- 1,000 primitive-stability perturbations.

All pass. The worst random observed ratio was well below `pi/4`.

---

## 9. Current verdict

### Mathematical correctness

No fatal gap found in two independent audit passes. The proof is now short enough that the critical new mathematical content can be stated as one lemma.

### Literature/priority

A targeted search on 8 September 2026 found Li--Pan's theorem for `p<2` and no endpoint `p=2` rectangular-peg theorem. This is not enough to establish novelty.

### Recommended next move

Do not return to the local Toeplitz obstruction labyrinth yet.

The highest-value action is external mathematical review of the five-page standalone note, especially:

1. the `pi/4` simple-arc area lemma;
2. the use of local 2-variation control on interpolants;
3. the transfer of primitive convergence through Li--Pan smoothing;
4. exact compatibility with Asano--Ike Theorem 1.1.

If external review agrees, this endpoint theorem should be treated as a standalone result and then imported back into the Toeplitz program as the global exclusion

\[
\boxed{\text{hypothetical counterexample} \Longrightarrow V_2=\infty.}
\]
