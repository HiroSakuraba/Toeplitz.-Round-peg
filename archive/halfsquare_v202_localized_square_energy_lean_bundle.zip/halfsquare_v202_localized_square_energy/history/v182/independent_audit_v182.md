# Independent second audit of the finite-2-variation endpoint

**Date:** 8 September 2026  
**Conclusion:** no fatal gap found; proof strengthened in two places; one omitted normalization repaired.

## 1. What was re-audited from scratch

The v181 proof was not assumed correct. The second pass decomposed it into five logically independent obligations:

1. A simple polygonal arc plus its endpoint chord has signed area controlled by local 2-variation.
2. Arbitrarily fine simple polygonal *interpolants* exist and do not increase 2-variation.
3. Finite 2-variation supplies a local control that tends to zero on short parameter intervals.
4. Smoothing a Jordan polygon in small 1-variation does not change the area primitive appreciably.
5. The resulting smooth approximants satisfy the exact Asano--Ike primitive criterion after the required area normalization.

No step was allowed to use Young integration at the endpoint.

## 2. Strengthening of the critical new lemma

The v181 constant `pi` can be replaced by `pi/4`.

For each connected component of a simple polygonal arc lying off its endpoint line, close that subarc by the segment in the endpoint line. The resulting Jordan domain has diameter no larger than the diameter `D_k` of the subarc. The isodiametric inequality gives area at most

\[
\frac{\pi}{4}D_k^2.
\]

The endpoint-line integrals telescope exactly because the restriction of

\[
\alpha=\tfrac12(x\,dy-y\,dx)
\]

to a fixed affine line is exact. If the arc itself contains nontrivial intervals on that line, they are included in the telescoping identity rather than discarded.

Since the off-line parameter components are disjoint, all diameter-realizing pairs can be inserted in one partition, giving

\[
\sum_k D_k^2\le V_2(\sigma)^2.
\]

Therefore

\[
\boxed{
\left|\int_\sigma\alpha+\int_{[q,p]}\alpha\right|
\le \frac{\pi}{4}V_2(\sigma)^2.
}
\]

This proof does not depend on cancellation between lobes.

## 3. Approximation inputs independently checked

The relevant statements are explicitly present in the current literature:

- Boedihardjo--Geng construct arbitrarily fine simple piecewise-geodesic interpolations of Jordan curves; in the plane these are simple polygonal interpolants.
- Li--Pan Lemma 2.2 proves that affine interpolation does not increase p-variation and gives the uniform interpolation error estimate.
- Li--Pan Lemma 3.1 proves that a Jordan polygon can be smoothed to a smooth Jordan embedding with arbitrarily small 1-variation error while fixing the base point.

Thus the endpoint extension does not need a new smoothing or interpolation theorem.

## 4. Local 2-variation control

For a continuous path of finite p-variation, the local p-variation to the p-th power is a continuous control. In particular

\[
\Omega_*(\delta)
=
\sup_{|t-s|\le\delta}V_2(c;[s,t])^2
\to0.
\]

For a simple interpolant `P_n` of mesh `delta_n`, enlarge an arbitrary interval `[s,t]` to the nearest interpolation vertices. Li--Pan's interpolation lemma then gives

\[
V_2(P_n;[s,t])^2
\le
\Omega_*(|t-s|+2\delta_n).
\]

This is sufficient for the primitive equicontinuity estimate. No convergence in 2-variation of `P_n-c` is claimed or needed.

## 5. Primitive stability under smoothing

With `S=P+H`, `H(0)=0`, and `||H||_{1-var} <= eta`, integration by parts gives

\[
A_S-A_P
=
\int\det(P,dH)
-\frac12\det(P,H)\big|_0^t
+\frac12\int\det(H,dH).
\]

Hence, if `sup |P| <= R`,

\[
\sup_t|A_S-A_P|
\le
\frac32R\eta+\frac12\eta^2.
\]

The estimate deliberately does not contain `Var(P)`, so polygonal lengths may diverge.

## 6. Asano--Ike criterion: repaired normalization

Asano--Ike state their theorem after normalizing the area of the bounded Jordan domain to `pi`. v181 used their criterion correctly at the primitive level but did not explicitly perform this normalization.

This is harmless but should be written. Any Jordan domain has positive finite area; scale the entire curve and all subsequent approximants by

\[
s=\sqrt{\pi/|D|}.
\]

Finite 2-variation, the simple-arc inequality, and the rectangular similarity class are all similarity invariant in the required way.

Their Theorem 1.1 requires precisely:

- smooth Jordan curves converging in C0 to the limiting Jordan curve; and
- primitives of the pulled-back Liouville form converging locally uniformly on the real periodic lift.

The revised proof establishes exactly those properties.

## 7. Critical rough-path objection

The general p=2 area operator is not a bounded continuous map on finite-2-variation path space. This does not contradict the endpoint theorem. The argument never asserts such continuity. It chooses simple Jordan polygonal approximants and obtains compactness of their primitives from the planar simple-arc lemma.

This distinction should remain explicit in any paper version.

## 8. Computational adversarial checks

The v182 verifier performs:

- 3,000 random injective x-monotone polygonal arcs with many endpoint-line crossings;
- deterministic high-crossing weave families up to 129 vertices;
- exact dynamic-programming evaluation of polygonal 2-variation squared;
- similarity-scaling checks;
- 1,000 primitive-stability perturbation checks.

No violation of the strengthened `pi/4` area bound was found. These checks are evidence only, not part of the proof.

## 9. Referee verdict

**Mathematical status:** likely correct on the present audit.  
**Novelty status:** unresolved. A targeted search found Li--Pan's p<2 theorem but no finite-2-variation endpoint result; that is not a priority proof.  
**Recommended next action:** send the short standalone proof, especially the simple-arc lemma, to independent experts in rough paths / planar geometric measure theory / rectangular pegs before making a novelty claim.
