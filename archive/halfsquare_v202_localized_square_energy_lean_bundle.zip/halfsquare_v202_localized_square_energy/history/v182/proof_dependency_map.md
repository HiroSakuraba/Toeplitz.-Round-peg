# Proof dependency map

The endpoint theorem uses one new geometric lemma and four external/standard inputs.

```text
Finite 2-variation Jordan parametrization
        |
        +--> Boedihardjo--Geng: arbitrarily fine simple polygonal interpolation
        |           |
        |           +--> Li--Pan Lemma 2.2: interpolation does not increase 2-var
        |                           |
        |                           +--> local 2-var control on short arcs
        |                                       |
        |                                       v
        |                    NEW: simple-arc chord-area inequality
        |                    |area| <= (pi/4) V_2^2
        |                                       |
        |                                       v
        |                          equicontinuous alpha-primitives
        |                                       |
        |                              Arzela--Ascoli subsequence
        |                                       |
        +--> Li--Pan Lemma 3.1: 1-var-small smooth Jordan smoothing
                                                |
                                     primitive stability lemma
                                                |
                                                v
                              smooth Jordan approximants with
                              convergent Liouville primitives
                                                |
                                   area-normalize limiting curve
                                                |
                                                v
                              Asano--Ike Theorem 1.1
                                                |
                                                v
                         every prescribed rectangle similarity class
```

## The sole endpoint-specific bridge

For `p<2`, Li--Pan use Young integration after obtaining convergence in some `q<2` variation topology.

For `p=2`, that route is unavailable. The replacement is exactly:

\[
\left|\int_\sigma \alpha+\int_{[q,p]}\alpha\right|
\le \frac\pi4 V_2(\sigma)^2
\]

for a simple polygonal arc `sigma`.

Everything downstream of that estimate is compactness or previously established approximation machinery.
