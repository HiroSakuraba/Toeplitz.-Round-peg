# Handoff v183 — third audit of the finite-2-variation endpoint

## Executive result

The finite-2-variation endpoint theorem survived a third independent audit. The proof is now organized around a more general **local quadratic-tightness criterion** rather than around an implied endpoint area integral.

### Candidate theorem

If a planar Jordan curve admits a finite-2-variation parametrization, then it inscribes a rectangle of every prescribed similarity class.

### New mechanism

For simple Jordan polygonal approximants `P_n -> c`, define

\[
\Theta(\delta)=\limsup_n\sup_{|t-s|\le\delta}V_2(P_n;[s,t])^2.
\]

If `Theta(delta) -> 0`, then the chord-closed simple-arc estimate implies equicontinuity of polygonal area primitives. Li--Pan smoothing preserves the primitive limit, and Asano--Ike applies.

Finite 2-variation gives this condition because `V_2(c;[s,t])^2` is a continuous rough-path control and affine interpolation does not increase 2-variation.

## Critical new lemma

For an injective polygonal arc `sigma` with endpoint chord,

\[
\left|\int_\sigma \frac12(xdy-ydx)+\int_{[q,p]}\frac12(xdy-ydx)\right|
\le \frac\pi4 V_2(\sigma)^2.
\]

The clean proof rigidly moves the endpoint line to the x-axis, where the form vanishes on line pieces. Off-line components are simple lobes. Isodiametric area gives `pi D_k^2/4`; disjoint parameter components allow all `D_k^2` to be charged to one 2-variation partition.

## What v183 specifically repaired or clarified

- Removed unnecessary reliance on area normalization in our proof. Asano--Ike's theorem statement already packages that issue.
- Made explicit that no limiting Green theorem on the rough curve is used.
- Recast local finite-2-variation as the standard continuous control `omega(s,t)=V_2^2`.
- Abstracted the proof to a local quadratic-tightness criterion.
- Simplified the endpoint-line argument by a Euclidean-motion normalization.
- Noted Asano--Ike's separate positive-measure result: the difficult endpoint case is measure-zero.

## Current theorem-status assessment

**Internal mathematical status:** likely correct; no fatal gap found in three deliberately different audits.

**External status:** candidate theorem. Do not claim novelty or publication-level correctness without independent expert review.

**Literature currently checked:**

- Asano--Ike, arXiv:2412.21057v3: exact primitive-compactness criterion.
- Li--Pan, arXiv:2609.04918v1: finite p-variation theorem for p<2; interpolation and smoothing lemmas used here.
- Boedihardjo--Geng, arXiv:1309.1576: arbitrarily fine simple interpolating polygons.
- Yang, arXiv:1204.0112: critical p=2 area obstruction for general paths.

No finite-2-variation rectangular-peg endpoint theorem was found in the targeted searches. This is not a priority proof.

## Consequence for the broader Toeplitz program if validated

A hypothetical counterexample must have infinite 2-variation. More intrinsically, it must exhibit **quadratic variation concentration on shrinking arcs in every useful simple interpolation scheme**. This is a global second-order obstruction and should replace the v150--v179 local fold taxonomy as the main frontier.

## Recommended next action

1. Send the standalone note to an expert in rough paths / planar GMT / rectangular pegs.
2. In parallel, develop the contrapositive global obstruction: quantify the shrinking-arc quadratic concentration forced by failure of primitive compactness.
3. Do not return to the local phase labyrinth until that global concentration route has been exhausted.
