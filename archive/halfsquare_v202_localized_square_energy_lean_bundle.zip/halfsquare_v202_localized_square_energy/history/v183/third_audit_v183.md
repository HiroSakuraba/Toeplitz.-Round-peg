# Third independent audit: finite-2-variation endpoint

**Date:** 8 September 2026  
**Method:** classical planar topology + geometric measure theory + exact check against the current Asano--Ike and Li--Pan statements.  
**Verdict:** no fatal gap found. The proof can be simplified and made more robust. The theorem remains a project/candidate theorem until independently checked by an expert.

## 1. The proof was attacked from a different angle

The audit ignored the computational tests and asked what can fail in the chain

1. simple polygonal arc -> chord-closed area estimate;
2. simple Jordan interpolation -> local quadratic control;
3. local quadratic control -> primitive equicontinuity;
4. 1-variation-small smoothing -> same primitive limit;
5. primitive convergence -> Asano--Ike.

The key question was whether any step secretly invokes a limiting Green theorem or endpoint Young integral. It does not.

## 2. The simple-arc lemma is elementary after normalizing the endpoint line

The cleanest proof rigidly moves the endpoint line to the x-axis. An orientation-preserving Euclidean motion changes `alpha = 1/2(x dy - y dx)` only by an exact differential, so the integral around the closed arc-plus-chord cycle is unchanged.

On the x-axis `alpha` vanishes. The connected components of the polygonal arc off that axis are therefore independent lobes. Each lobe plus its axis chord is a polygonal Jordan curve. If `D_k` is the lobe diameter, its enclosed domain lies in the convex hull of the lobe and hence has diameter at most `D_k`. The planar isodiametric inequality gives

\[
|A_k|\le \frac{\pi}{4}D_k^2.
\]

The lobe parameter intervals are disjoint. Diameter-realizing pairs from all lobes can be inserted into one partition, so

\[
\sum_k D_k^2\le V_2(\sigma)^2.
\]

Thus

\[
\left|\oint_{\sigma+[q,p]}\alpha\right|
\le \frac{\pi}{4}V_2(\sigma)^2.
\]

This version eliminates any possible ambiguity about cancellation or portions of the polygon lying on the endpoint line.

## 3. The local 2-variation statement is a standard rough-path control

For a continuous finite-p-variation path,

\[
\omega(s,t)=\|c\|_{p\text{-var};[s,t]}^p
\]

is a continuous superadditive control. Therefore

\[
\sup_{|t-s|\le\delta}V_2(c;[s,t])^2\to0.
\]

This is not an endpoint Young statement. It is part of the basic topology of continuous finite-p-variation paths.

For a Boedihardjo--Geng simple interpolation `P_n`, Li--Pan's interpolation lemma gives variation monotonicity on intervals whose endpoints are interpolation vertices. Enlarging an arbitrary `[s,t]` to neighboring vertices yields

\[
V_2(P_n;[s,t])^2
\le
\Omega_*(|t-s|+2\delta_n).
\]

Hence local quadratic variation is uniformly tight along the chosen simple interpolants.

## 4. A more general mechanism emerged

Finite 2-variation is sufficient but not logically essential. The proof only needs a sequence of simple Jordan polygons `P_n -> c` for which

\[
\lim_{\delta\downarrow0}
\limsup_n\sup_{|t-s|\le\delta}
V_2(P_n;[s,t])^2=0.
\]

Together with uniform convergence, the chord-closed area lemma makes the polygonal area primitives equicontinuous. This gives a **quadratic-control compactness criterion** for the Asano--Ike hypothesis.

The finite-2-variation theorem is the immediate corollary supplied by the Li--Pan variation estimate.

## 5. The Asano--Ike theorem was checked against the current text

Their Theorem 1.1 assumes exactly:

- smooth Jordan curves converging in C0 to the limiting Jordan curve; and
- primitives of the pulled-back Liouville form converging locally uniformly on the real periodic lift.

No limiting Green theorem for the rough curve is assumed.

Their proof handles area normalization internally. It also observes separately that positive-planar-measure Jordan curves already inscribe every prescribed rectangle class. Consequently there is no need for the endpoint proof to identify a limiting enclosed-area integral for the rough curve.

## 6. Smoothing does not import polygonal length

Li--Pan provide a smoothing `S_n` with

\[
\|S_n-P_n\|_{1\text{-var}}\to0
\]

and the same base point. Writing `H_n=S_n-P_n`, the exact integration-by-parts identity gives

\[
\|A_{S_n}-A_{P_n}\|_\infty
\le
\frac32 R\|H_n\|_{1\text{-var}}
+\frac12\|H_n\|_{1\text{-var}}^2.
\]

No factor involving `Var(P_n)` occurs. Thus polygonal lengths may diverge without damaging primitive convergence.

## 7. The critical rough-path objection remains compatible

General finite-2-variation paths do not have a continuous area operator in the 2-variation topology. The endpoint theorem does not claim otherwise. It uses the extra topology of *simple planar approximants* and a chord-closed area inequality that fails for loop-reusing arbitrary paths.

## 8. New global interpretation for the Toeplitz program

The useful obstruction is no longer simply `V_2(c)=infinity`. A square-free measure-zero Jordan curve must fail the stronger approximation property:

> no sequence of arbitrarily fine simple polygonal interpolants may have uniformly tight local quadratic variation while converging uniformly to the curve.

Equivalently, along every usable simple interpolation scheme there must be quadratic-variation concentration on shrinking parameter arcs.

This is much closer to a genuine global termination invariant than fold count, curvature, or local phase complexity.

## 9. Remaining external-review questions

1. Have endpoint results equivalent to this simple-arc lemma appeared under a different rough-path or Jordan-domain formulation?
2. Is there a classical theorem giving the same primitive compactness for simple finite-2-variation curves?
3. Can the local quadratic-tightness criterion be recognized as an existing notion of a continuous Legendrian lift?
4. Is the constant `pi/4` relevant or can the chord-closed inequality be sharpened?

None of these questions presently identifies a mathematical gap.
