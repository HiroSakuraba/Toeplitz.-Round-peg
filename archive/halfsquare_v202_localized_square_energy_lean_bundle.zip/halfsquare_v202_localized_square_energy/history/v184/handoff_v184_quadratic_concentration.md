# Handoff v184 — quadratic concentration and winding blow-up

## Executive result

The v183 endpoint theorem has now been used contrapositively. The broad local obstruction tree is replaced by a quantitative global anomaly attached to any simple polygonal interpolation scheme.

For area primitives \(A_n\), define the primitive defect
\[
\Lambda=\lim_{\delta\downarrow0}\limsup_n\sup_{|t-s|\le\delta}|A_n(t)-A_n(s)|,
\]
and the quadratic defect
\[
\Theta=\lim_{\delta\downarrow0}\limsup_n\sup_{|t-s|\le\delta}V_2(P_n;[s,t])^2.
\]
Then
\[
\Lambda\le\frac\pi4\Theta.
\]
If the prescribed rectangle does not exist, then \(\Lambda>0\), hence \(\Theta>0\), for every admissible simple interpolation scheme.

## Main geometric consequence

For every \(0<\varepsilon<\Lambda\), there are shrinking arcs of diameter \(r_k\to0\) whose chord-closed signed area is at least \(\varepsilon/2\). Consequently
\[
V_2^2\ge\frac{2\varepsilon}{\pi},
\qquad
\|\operatorname{wind}\|_\infty\ge\frac{2\varepsilon}{\pi r_k^2},
\]
and the number of endpoint-line lobes is at least the same order. A near-optimal quadratic-variation partition requires at least \(\varepsilon/(\pi r_k^2)\) increments, and polygonal length is at least \(\varepsilon/(\pi r_k)\).

Thus a counterexample must develop *shrinking arcs with arbitrarily large winding multiplicity around their own endpoint chord closure*. More strongly, if `z_k` realizes the winding multiplicity `N_k`, the arc itself has unwrapped angular displacement at least
\[
2\pi N_k-\pi\gtrsim r_k^{-2}.
\]
Every generic ray from `z_k` is therefore crossed at least `N_k-1` times by the arc. The obstruction is not merely combinatorial folding; it is ordered spiral-like winding.

## Intrinsic transfer

For affine interpolants through the original Jordan curve, the concentrated local \(2\)-variation transfers back to the curve. There is a parameter point \(t_*\) and \(\kappa>0\) such that every neighborhood \(U\ni t_*\) satisfies
\[
V_2(c;U)^2\ge\kappa.
\]
This is an intrinsic quadratic concentration point.

## Why this is better than `V_2=\infty`

Infinite total \(2\)-variation could in principle be spread thinly over the whole curve. The new result says a fixed amount of quadratic variation must remain trapped inside arbitrarily small parameter and spatial neighborhoods. The normalized density therefore diverges.

The area primitive also converts this analytic packet into a topological one: the endpoint-chord closure has winding number \(\gtrsim r^{-2}\).

## Sharpness model

A simple monotone-radius spiral with \(N\) turns and overall radius \(r\asymp N^{-1/2}\) has:

- diameter \(O(r)\),
- winding number \(N\asymp r^{-2}\),
- chord-closed signed area of order one,
- local quadratic variation of order one.

So the v184 scaling is geometrically feasible; it does not close Toeplitz by itself. It identifies the next genuine object: **high-winding shrinking Jordan arcs**.

## Recommended v185 target

Study the topology/geometry of an injective arc \(\sigma\) whose closure by its endpoint chord has winding number \(N\gg1\).

Two promising formulations:

1. **Radial-layer theorem.** v184 already gives `\gtrsim r^{-2}` ordered crossings of every generic ray through a high-winding center. Exploit those radial layers to extract four contacts forcing a square/rectangle or a lattice phase cell.
2. **Spiral tangent theorem.** Normalize the shrinking concentration arcs by their diameter and choose a high-winding center. Determine whether a subsequence admits a monotone-angle spiral tangent, or whether failure of such compactness creates an even stronger concentration packet.

Do not return to the old local phase taxonomy unless one of these global winding routes explicitly recreates it.
