# Quadratic concentration forced by failure of primitive compactness

## Setup

Let \(c:\mathbb T\to\mathbb R^2\) be a Jordan parametrization, and let \(P_n\to c\) be a sequence of simple affine interpolants with interpolation mesh tending to zero. Put
\[
\alpha=\frac12(x\,dy-y\,dx),\qquad
A_n(t)=\int_0^t P_n^*\alpha,
\]
with \(A_n(0)=0\). Assume the interpolants are parametrized on one fixed period.

For \(\delta>0\), define
\[
M_n(\delta)=\sup_{|t-s|\le\delta}|A_n(t)-A_n(s)|,
\]
\[
Q_n(\delta)=\sup_{|t-s|\le\delta}V_2(P_n;[s,t])^2,
\]
and
\[
U_n(\delta)=\sup_{|t-s|\le\delta}|P_n(t)-P_n(s)|.
\]
Define the asymptotic defects
\[
\Lambda(P_\bullet)=\lim_{\delta\downarrow0}\limsup_{n\to\infty}M_n(\delta),
\]
\[
\Theta(P_\bullet)=\lim_{\delta\downarrow0}\limsup_{n\to\infty}Q_n(\delta).
\]
The limits exist in \([0,\infty]\) because the expressions are monotone in \(\delta\).

## Theorem 1 — defect inequality

For every uniformly convergent sequence of simple Jordan polygons \(P_n\to c\),
\[
\boxed{\Lambda(P_\bullet)\le \frac\pi4\Theta(P_\bullet).}
\]

### Proof

Fix a radius \(R\) containing all sufficiently large \(P_n(\mathbb T)\). The simple-arc estimate from v183 gives, on every parameter interval \([s,t]\),
\[
|A_n(t)-A_n(s)|
\le
\frac\pi4V_2(P_n;[s,t])^2
+
\frac R2|P_n(t)-P_n(s)|.
\]
Hence
\[
M_n(\delta)
\le
\frac\pi4Q_n(\delta)+\frac R2U_n(\delta).
\]
Uniform convergence to the continuous curve \(c\) gives
\[
\lim_{\delta\downarrow0}\limsup_n U_n(\delta)=0.
\]
Take \(\limsup_n\), then \(\delta\downarrow0\).

## Theorem 2 — contrapositive concentration theorem

Assume the Asano--Ike rectangle conclusion fails for the prescribed rectangle class. Then for every admissible simple interpolation sequence \(P_n\to c\) to which the v183 smoothing step applies,
\[
\boxed{\Lambda(P_\bullet)>0,\qquad
\Theta(P_\bullet)\ge\frac4\pi\Lambda(P_\bullet)>0.}
\]

Indeed, if \(\Lambda=0\), the anchored primitives \(A_n\) are asymptotically equicontinuous. They are then uniformly bounded on one period, so Arzela--Ascoli gives a uniformly convergent primitive subsequence. Li--Pan smoothing preserves the primitive limit, and Asano--Ike forces the rectangle.

Thus failure of the rectangle criterion cannot be expressed merely as infinite total \(2\)-variation. It forces a fixed nonzero amount of quadratic variation to remain concentrated on arbitrarily short parameter intervals.

## Theorem 3 — shrinking-arc anomaly

Let \(0<\varepsilon<\Lambda(P_\bullet)\). Then there are indices \(n_k\to\infty\) and intervals \(I_k=[s_k,t_k]\) with \(|I_k|\to0\) such that
\[
|A_{n_k}(t_k)-A_{n_k}(s_k)|\ge\varepsilon.
\]
Write
\[
r_k=\operatorname{diam}P_{n_k}(I_k).
\]
Then \(r_k\to0\). Let \(\Gamma_k\) be the polygonal arc \(P_{n_k}|_{I_k}\) closed by its endpoint chord, and let
\[
\mathcal A_k=\int_{\Gamma_k}\alpha.
\]
For all sufficiently large \(k\),
\[
\boxed{|\mathcal A_k|\ge\frac\varepsilon2,}
\]
\[
\boxed{V_2(P_{n_k};I_k)^2\ge\frac{2\varepsilon}{\pi}.}
\]

The first estimate follows because the endpoint-chord integral is \(O(r_k)\); the second follows from the v183 simple-arc area inequality.

Consequently the scale-free quadratic density diverges:
\[
\boxed{
\frac{V_2(P_{n_k};I_k)^2}{r_k^2}
\ge
\frac{2\varepsilon}{\pi r_k^2}
\longrightarrow\infty.
}
\]

## Theorem 4 — winding multiplicity blow-up

Let \(w_k(z)=\operatorname{wind}(\Gamma_k,z)\). The support of \(w_k\) lies in the convex hull of \(P_{n_k}(I_k)\), whose diameter is at most \(r_k\). By the planar isodiametric inequality its area is at most \(\pi r_k^2/4\). The winding-area formula for a polygonal closed curve gives
\[
\mathcal A_k=\int_{\mathbb R^2}w_k(z)\,dz.
\]
Therefore
\[
\boxed{
\|w_k\|_{L^\infty}
\ge
\frac{2\varepsilon}{\pi r_k^2}
\longrightarrow\infty.
}
\]

Thus failure of primitive compactness forces shrinking simple arcs whose endpoint-chord closures wind around some point with multiplicity of order at least \(r^{-2}\).

A robust equivalent combinatorial formulation uses the endpoint line. Decompose the arc into connected components lying off the line through its endpoints. If \(m_k\) is the number of such lobes, then
\[
\boxed{m_k\ge \frac{2\varepsilon}{\pi r_k^2}.}
\]
This avoids any ambiguity caused by portions of the arc lying on the endpoint line.

## Theorem 5 — length and partition complexity

Choose a partition of \(I_k\) whose quadratic sum is at least half the local \(2\)-variation lower bound. Every partition chord has length at most \(r_k\). Hence the number \(N_k\) of partition increments and the polygonal length \(L_k\) of the arc obey
\[
\boxed{N_k\ge\frac{\varepsilon}{\pi r_k^2},}
\]
\[
\boxed{L_k\ge\frac{\varepsilon}{\pi r_k}.}
\]

The obstruction is therefore simultaneously a quadratic-variation concentration, a high-winding phenomenon, and a divergent local-length phenomenon.

## Theorem 6 — transfer to the original Jordan curve

Assume \(P_n\) are affine interpolants through points of \(c\), with interpolation mesh \(\delta_n\to0\). Enlarge \(I_k\) to the nearest interpolation vertices, obtaining \(J_k\). Then
\[
|J_k|\le |I_k|+2\delta_{n_k}\to0,
\]
and the Li--Pan interpolation estimate gives
\[
V_2(c;J_k)^2
\ge
V_2(P_{n_k};J_k)^2
\ge
V_2(P_{n_k};I_k)^2
\ge
\frac{2\varepsilon}{\pi}.
\]
After passing to a subsequence, the intervals \(J_k\) converge to a parameter point \(t_*\). Hence every parameter neighborhood \(U\ni t_*\) satisfies
\[
\boxed{V_2(c;U)^2\ge\frac{2\varepsilon}{\pi}.}
\]

We call such a point a **quadratic concentration point**. This is intrinsic to the original Jordan parametrization, not merely to the polygonal approximants.

## Interpretation

The v150--v179 local labyrinth can now be viewed as possible local realizations of one global second-order anomaly. A hypothetical counterexample must support, at arbitrarily small scales,

- a nonvanishing quadratic-variation packet;
- normalized quadratic density diverging like at least \(r^{-2}\);
- endpoint-chord winding multiplicity diverging like at least \(r^{-2}\);
- local polygonal length diverging like at least \(r^{-1}\).

This is much stronger than the statement \(V_2(c)=\infty\).

## What this does not yet prove

A simple Jordan arc can realize this scaling by forming an increasingly tight spiral. Therefore the concentration theorem is not itself a contradiction. The next problem is to exploit the *ordered winding* forced by simplicity: does sufficiently high chord-closed winding of a shrinking Jordan arc force a rectangular peg, or force a repeatable renormalized spiral tangent incompatible with global Jordan topology?

## Theorem 7 — ordered angular sweep

Choose a point \(z_k\notin\Gamma_k\) for which
\[
|\operatorname{wind}(\Gamma_k,z_k)|=\|w_k\|_\infty=:N_k.
\]
Along the polygonal arc and its closing chord one may choose continuous lifts of the polar angle about \(z_k\). The total angle change around the closed path is
\[
2\pi N_k.
\]
A straight segment not passing through \(z_k\) changes polar angle by strictly less than \(\pi\). Therefore the open arc itself has net unwrapped angular displacement satisfying
\[
\boxed{
|\Delta\arg_{z_k}(P_{n_k}|_{I_k})|
\ge 2\pi N_k-\pi
\ge \frac{4\varepsilon}{r_k^2}-\pi.
}
\]

Equivalently, for every generic ray from \(z_k\), the algebraic intersection number of the chord-closed path with that ray is \(N_k\). Since the closing chord contributes at most one intersection, the simple arc has at least \(N_k-1\) ray intersections. Thus the concentration packet contains \(\gtrsim r_k^{-2}\) ordered radial layers.

This is the most geometric formulation of the v184 obstruction: a counterexample must pack a diverging number of turns into a shrinking Jordan arc.
