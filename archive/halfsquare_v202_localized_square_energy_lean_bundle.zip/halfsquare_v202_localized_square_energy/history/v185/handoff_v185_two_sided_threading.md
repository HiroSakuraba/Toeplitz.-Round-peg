# Handoff v185 — two-sided threading and cubic spiral corridor

## Executive result

v184's one-sided high-winding packet is impossible as a description of a Jordan counterexample. If a small subarc `A` closed by its endpoint chord has winding `N`, the complementary arc `B` closed by the opposite chord has winding `-N+O(1)` about the same center.

More strongly, Jordan crossing alternation forces this cancellation to occur inside the same radius-`r` packet. On every generic ray from the high-winding center,

- `A` has algebraic intersection magnitude at least `N-1` inside radius `r`;
- `B` has algebraic intersection magnitude at least `N-2` inside the same radius;
- the radial crossing sequence has at least `2N-4` transitions between the two parameter sides.

Therefore
\[
\min\Delta\rho\le \frac{r}{2N-4}.
\]
Under the v184 law `N \gtrsim r^{-2}`, this gives
\[
\Delta\rho=O(r^3).
\]
At least order `r^{-2}` side-to-side transition pairs have this cubic-scale spacing up to a fixed constant.

## Why the cubic exponent is natural

The critical spiral
\[
r(\theta)=a\theta^{-1/2}
\]
has exactly
\[
N\asymp r^{-2},
\qquad
\Delta r_{\rm turn}\asymp r^3,
\]
and a dyadic angular block carries order-one signed area. Interleaving the two spirals
\[
a\theta^{-1/2},\qquad a(\theta+\pi)^{-1/2}
\]
produces a simple double-spiral corridor with the same cubic side-to-side spacing. The obstruction is therefore feasible and scale-sharp.

## Locality in the original Jordan curve

At a v184 concentration point `t_*`, the high-winding centers satisfy `z_k\to c(t_*)`. Since `c` has continuous inverse on its image, complementary crossings lying inside the shrinking packet must also come from parameters tending to `t_*`. The winding cancellation cannot be exported to a remote part of the curve.

Thus a hypothetical counterexample must have a genuinely local **two-sided threading germ** at the quadratic concentration point.

The precise `O(r^3)` metric gap is currently established for the simple polygonal interpolants. Passing that rate to the original curve would require approximation error `o(r^3)` and is deliberately not claimed.

## Why this is better than v184

v184 allowed the mental picture of a one-sided spiral whose rest of the Jordan curve remained geometrically irrelevant. v185 rules that out. The rest of the curve must thread back through the concentration packet with the opposite winding and with cubic transverse spacing.

This converts the global anomaly into a **spiral corridor** rather than a spiral strand.

## Recommended v186 target

Study one adjacent opposite-side pair at the anisotropic scales
\[
\text{tangential }\sim r,
\qquad
\text{transverse }\sim r^3.
\]

Prove a cubic-corridor dichotomy:

1. if the pair is graph-like with controlled slope on tangential length much larger than `r^3`, force a genuine local square on the original Jordan curve; or
2. if no such graph-like pair exists among `\asymp r^{-2}` radial layers, quantify the required oscillation and show that it creates a stronger hereditary concentration packet.

Do not revert to the v150-v179 phase taxonomy unless this anisotropic corridor analysis explicitly recreates one of those objects.
