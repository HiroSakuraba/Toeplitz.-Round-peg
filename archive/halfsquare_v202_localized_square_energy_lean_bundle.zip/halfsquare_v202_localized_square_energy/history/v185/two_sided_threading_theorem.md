# Two-sided threading forced by a quadratic concentration packet

## 1. Setup

Let `C` be an oriented Jordan polygon. Split it at two points `p,q` into the oriented subarc
\[
A:p\to q
\]
and the complementary oriented subarc
\[
B:q\to p.
\]
Let `e` denote the straight chord from `q` to `p`, so that
\[
\Gamma_A=A+e,
\qquad
\Gamma_B=B-e,
\qquad
C=\Gamma_A+\Gamma_B
\]
as oriented one-chains.

Assume `A` has diameter at most `r`, and choose
\[
z\notin C\cup e
\]
with
\[
N:=|\operatorname{wind}(\Gamma_A,z)|\ge 3.
\]
Whenever `N\ne0`, `z` lies in the convex hull of `A`; hence every point of `A` is within distance `r` of `z`.

The v184 concentration packet gives precisely this situation with
\[
N\ge \frac{2\varepsilon}{\pi r^2}.
\]

## 2. Complementary-winding identity

Because the closing chords cancel,
\[
C=\Gamma_A+\Gamma_B.
\]
Therefore
\[
\boxed{
\operatorname{wind}(\Gamma_B,z)
=
\operatorname{wind}(C,z)-\operatorname{wind}(\Gamma_A,z).
}
\]
For a Jordan curve,
\[
\operatorname{wind}(C,z)\in\{0,\pm1\}.
\]
Thus
\[
\boxed{
|\operatorname{wind}(\Gamma_B,z)|\ge N-1.
}
\]
A large winding packet on `A` necessarily has a comparably large opposite winding on the complementary arc.

This identity alone does not yet say where the complementary winding occurs. The Jordan property does.

## 3. Initial-ray cancellation theorem

Choose a generic ray `R` from `z` which is transverse to `C` and the chord and misses all polygon vertices. Let `R_r` be the initial portion of that ray up to the maximal radius at which `A` meets the ray (and then an arbitrarily small amount farther, so its endpoint is not on `C`).

Let
\[
I_A(R_r),\qquad I_B(R_r)
\]
be the algebraic intersection numbers of `A` and `B` with this initial ray segment.

The closed path `\Gamma_A` has ray intersection number `\pm N`. The straight chord contributes at most one crossing. Hence, after fixing sign,
\[
\boxed{|I_A(R_r)|\ge N-1.}
\]

Crossing signs of an oriented Jordan curve along one transverse ray alternate. Therefore the algebraic intersection number of the *whole* Jordan curve with any initial ray segment has absolute value at most one:
\[
|I_C(R_r)|\le1.
\]
Since
\[
I_C(R_r)=I_A(R_r)+I_B(R_r),
\]
we obtain
\[
\boxed{|I_B(R_r)|\ge N-2.}
\]

Thus the complementary arc cannot postpone the winding cancellation to a macroscopic radius. It must enter the same radius-`r` packet at least `N-2` times algebraically.

## 4. Alternating-run theorem

List the transverse intersections of the full Jordan curve with `R_r` in increasing radial order. Label each intersection by `A` or `B`.

Within any maximal run of consecutive `A` labels, the Jordan crossing signs alternate, so the algebraic contribution of one `A`-run belongs to `{-1,0,1}`. Therefore the number `R_A` of `A`-runs obeys
\[
R_A\ge |I_A(R_r)|\ge N-1.
\]
Similarly
\[
R_B\ge |I_B(R_r)|\ge N-2.
\]
The label runs alternate. Hence the number `T` of adjacent crossing pairs whose labels change from `A` to `B` or from `B` to `A` satisfies
\[
\boxed{T\ge R_A+R_B-1\ge 2N-4.}
\]

Every such transition is a pair of consecutive crossings of *opposite parameter sides* of the Jordan curve.

## 5. Cubic threading law

The radial gaps associated with the `T` label transitions are pairwise disjoint subintervals of a ray segment of length at most `r`. Consequently
\[
\boxed{
\min_{\text{A/B transition}}\Delta\rho
\le
\frac{r}{2N-4}.
}
\]
Moreover at least half of the transitions satisfy
\[
\boxed{
\Delta\rho\le \frac{r}{N-2}.
}
\]

Insert the v184 winding lower bound
\[
N\ge\frac{2\varepsilon}{\pi r^2}.
\]
For sufficiently small `r`,
\[
\boxed{
\min\Delta\rho
\le
\frac{\pi}{4\varepsilon}\,r^3(1+o(1)),
}
\]
and at least order `r^{-2}` opposite-side crossing pairs have radial separation
\[
\boxed{
\Delta\rho=O_\varepsilon(r^3).
}
\]

This is the **cubic threading law**.

The concentration packet is therefore not a single tight spiral. It is a two-sided Jordan corridor whose two parameter sides repeatedly pass within cubic transverse distance at spatial scale `r`.

## 6. Localization back to the concentration point

Now return to the v184 polygonal interpolants `P_n\to c`. Let `A_k=P_{n_k}(I_k)` be the shrinking concentration arcs, let `r_k=\operatorname{diam}A_k\to0`, and let `z_k` be a high-winding center. After passing to a subsequence, the parameter intervals converge to a quadratic concentration point `t_*` and
\[
z_k\to c(t_*).
\]

Because a Jordan parametrization is a homeomorphism onto its image, for every parameter neighborhood `U` of `t_*`,
\[
\operatorname{dist}\bigl(c(t_*),c(\mathbb T\setminus U)\bigr)>0.
\]
Uniform convergence `P_n\to c` therefore implies that, for all sufficiently large `k`, **every complementary-arc crossing inside the radius-`r_k` packet comes from parameters in `U`**.

Thus the complementary winding forced above is local in parameter as well as in space. The concentration point is a genuinely two-sided threading point; cancellation cannot be exported to a distant portion of the Jordan curve.

The `O(r_k^3)` metric gap is proved at the polygonal level. Transferring that exact cubic metric rate to `c` requires interpolation error `o(r_k^3)` and is not claimed here.

## 7. Critical calibration: the root spiral

Consider
\[
r(\theta)=a\theta^{-1/2}.
\]
A dyadic angular block `[\Theta,2\Theta]` has
\[
N\asymp\Theta\asymp r^{-2}
\]
turns and signed polar area
\[
\frac12\int_\Theta^{2\Theta}r(\theta)^2\,d\theta
=
\frac{a^2}{2}\log2,
\]
which is independent of `\Theta`.

The radial separation of consecutive turns is
\[
r(\theta)-r(\theta+2\pi)
=
\frac{\pi}{a^2}r(\theta)^3+o(r^3).
\]
Thus the cubic law above is exactly the spacing law of the scale-critical spiral.

A two-sided model is obtained from the interleaved spirals
\[
r_A(\theta)=a\theta^{-1/2},
\qquad
r_B(\theta)=a(\theta+\pi)^{-1/2}.
\]
At a common angle,
\[
r_A-r_B
=
\frac{\pi}{2a^2}r_A^3+o(r_A^3).
\]
Joining the two spirals by short radial segments at their inner and outer ends gives finite simple Jordan polygons approximating a **double root-spiral corridor**.

Hence the v185 scaling is topologically feasible and essentially sharp.

## 8. What has changed

The terminal global obstruction is no longer adequately described by

> a shrinking arc with huge winding.

The Jordan property forces the stronger structure
\[
\boxed{
\text{shrinking packet}
\;\Longrightarrow\;
\text{oppositely winding complementary packet}
\;\Longrightarrow\;
\text{two-sided radial threading at }O(r^3)\text{ spacing}.
}
\]

That is a much more rigid geometric object.

## 9. What is not yet proved

A double root-spiral corridor is compatible with Jordan topology. So v185 is not a contradiction.

The next problem is anisotropic: at tangential scale `r`, the two sides are separated transversely on scale `r^3`. A regular corridor should look, after a suitable anisotropic blow-up, like two long nearly parallel strands, which would strongly favor tiny inscribed squares. A survivor must instead destroy this local graph structure at the same cubic scale.

The natural next target is therefore a **cubic-corridor dichotomy**:

1. a graph-like adjacent pair persists over tangential length `\gg r^3`, forcing a local square; or
2. graph structure fails at cubic resolution, producing a new quantitative roughness/concentration anomaly.
