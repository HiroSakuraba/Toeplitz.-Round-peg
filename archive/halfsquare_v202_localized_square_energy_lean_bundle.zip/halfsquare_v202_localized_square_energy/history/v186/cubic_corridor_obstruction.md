# Cubic corridor obstruction and the seventh-order square defect

## 1. Purpose

v185 reduced primitive noncompactness to a local two-sided threading packet.  In the scale-critical model the packet has radius `r`, roughly `r^{-2}` turns, and opposite-side gaps of order `r^3`.

The first proposed v186 route was:

> if two adjacent strands are sufficiently graph-like on a tangential interval much longer than their `r^3` gap, force a local square.

That statement is false without additional recurrence.  This note records the counterexample and the sharper obstruction supplied by the critical double spiral.

## 2. Two graph-like strands do not suffice

Take the lower strand
\[
L=\{(x,0):0\le x\le L_0\}
\]
and the upper strand
\[
U=\{(x,1+\varepsilon x):0\le x\le L_0\},\qquad \varepsilon>0.
\]
Any square having two consecutive vertices on `L` has horizontal lower side.  Its opposite side is horizontal, so its two upper vertices must have equal height.  Since the upper graph is strictly monotone, no such two-strand square exists.

Thus narrowness, graph structure, and arbitrarily large aspect ratio do not by themselves force a square.

## 3. The scale-critical double spiral

Consider
\[
A_\beta(\theta)=a\theta^{-\beta}e^{i\theta},\qquad
B_\beta(\theta)=a(\theta+\pi)^{-\beta}e^{i\theta},
\qquad \beta>0.
\]
The v184 area-critical case is `beta=1/2`.

At a large base phase `T`, put
\[
r=aT^{-\beta}.
\]
The radial half-turn gap is
\[
A_\beta(T)-B_\beta(T)
= a\beta\pi T^{-\beta-1}+O(T^{-\beta-2}).
\]
For `beta=1/2`,
\[
\boxed{
A(T)-B(T)
=\frac{\pi}{2a^2}r^3+O(r^5).
}
\]
This recovers the cubic corridor scale from v185.

## 4. Cubic lamination tangent

Use the local angular scale
\[
\theta=T+\frac{x}{T}.
\]
After rotating by `e^{-iT}`, subtracting the base point, and dividing spatial coordinates by
\[
aT^{-\beta-1},
\]
the two arms converge on compact `x`-sets to
\[
A_\infty(x)=ix,
\qquad
B_\infty(x)=-\beta\pi+ix.
\]
Further half-turn layers give a parallel-line lamination with spacing `beta*pi` in these normalized coordinates and alternating `A/B` labels.

For `beta=1/2`, the normalized spacing is `pi/2`.

The leading tangent therefore contains a one-parameter family of exact Euclidean squares between every neighboring pair of lines.

The crucial question is whether those tangent squares persist at finite `T`.

## 5. Power-law local-square expansion

Write `epsilon=1/T`.  A local square between adjacent arms must have parameters of the form
\[
\theta_j=T+O(T^{-1}).
\]
In normalized coordinates, for
\[
\theta=T+\alpha\epsilon+\beta_1\epsilon^2+\gamma\epsilon^3,
\]
the arm expansions are obtained from
\[
\frac{(1+\epsilon u)^{-\beta}e^{iu}-1}{\epsilon},
\qquad
\frac{(1+\epsilon(u+\pi))^{-\beta}e^{iu}-1}{\epsilon}.
\]

At leading order the square equations force
\[
\alpha_1-\alpha_0=\beta\pi,
\qquad
\alpha_{B,0}=\alpha_0,
\qquad
\alpha_{B,1}=\alpha_1.
\]
The first correction equations are soluble and leave the expected common tangential translation gauge.

At the next order the two nominally redundant radial square equations differ by
\[
\boxed{
\pi^2\beta^2(\beta+1).
}
\]
This quantity is strictly positive for every `beta>0` and is independent of the tangential gauge.

Consequently the parallel-line square family fails its finite-scale solvability condition.

In physical coordinates the corresponding unavoidable mismatch is
\[
\boxed{
\Delta_{\rm sq}(T)
\asymp
 a\pi^2\beta^2(\beta+1)T^{-\beta-3}.
}
\]
The least-squares norm has leading coefficient
\[
\frac{\pi^2\beta^2(\beta+1)}{\sqrt2}
\]
under the normalization above.

### Critical exponent

For `beta=1/2`,
\[
\boxed{
\Delta_{\rm sq}(T)
\asymp
\frac{3\pi^2}{8}\,aT^{-7/2}.
}
\]
Since `r=aT^{-1/2}`,
\[
\boxed{
\Delta_{\rm sq}
\asymp
\frac{3\pi^2}{8a^6}r^7.
}
\]
Thus the critical packet has
\[
\text{corridor width}\asymp r^3,
\qquad
\text{local square defect}\asymp r^7.
\]
The relative defect is `O(r^4)`.

This is the main v186 structural result.

## 6. Exact half-turn residue

The union of the two power-law arms meets a fixed geometric ray at radii
\[
\boxed{
a(\theta+\pi m)^{-\beta},\qquad m\in\mathbb Z
}
\]
where defined.

A ray rotated by `pi/2` has the corresponding arguments
\[
\theta+\frac\pi2+\pi n.
\]
Equality of radii between the two rays would require
\[
\theta+\pi m
=
\theta+\frac\pi2+\pi n,
\]
i.e.
\[
m-n=\frac12,
\]
which is impossible.

Hence the canonical double spiral has no square centered at the winding center whose vertices lie on four quadrature rays.  The cubic radial mismatch is the finite-scale manifestation of this half-turn residue.

## 7. Interpretation

The v185 regular-corridor proposal was too optimistic.

The critical double spiral is simultaneously:

- simple and two-sided;
- `r^{-2}`-winding;
- cubically threaded;
- asymptotically an exact parallel-line lamination;
- and nevertheless locally square-obstructed beyond leading order.

The square-rich cubic tangent loses its square family at the seventh physical order.

Therefore a proof cannot use only one adjacent pair and its leading `r^3` corridor geometry.  It must use one of:

1. many radial layers at once;
2. angular motion on a scale much larger than the square-size scale;
3. nonlocal return of the two parameter sides;
4. or a topological/index invariant that survives the degeneration of the tangent square family.

## 8. Status

The symbolic coefficient `pi^2 beta^2(beta+1)` is exact and machine-verified.
The numerical minimization agrees with the predicted `T^{-7/2}` law in the critical case.

For a formal paper-level theorem excluding *all* possible local squares in a prescribed `O(T^{-1})` parameter window, the Lyapunov--Schmidt expansion should be written with explicit remainder bounds.  v186 establishes the asymptotic solvability obstruction and verifies it computationally; it does not claim a global square-free theorem for the double spiral.
