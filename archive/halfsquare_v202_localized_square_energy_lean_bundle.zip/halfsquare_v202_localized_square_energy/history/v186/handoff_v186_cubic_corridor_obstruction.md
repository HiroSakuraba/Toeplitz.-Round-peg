# Handoff v186 — cubic corridor obstruction and seventh-order defect

## Executive result

v185's suggested `regular narrow corridor -> local square` route is false in that form.

Two graph-like strands do not suffice: a straight lower strand and a strictly monotone upper graph can be arbitrarily narrow and long while supporting no square whose two lower vertices lie on the lower strand and two upper vertices lie on the upper strand.

More importantly, the scale-critical v185 double spiral supplies a canonical countermodel to the *local* corridor intuition.

For
\[
A_\beta(\theta)=a\theta^{-\beta}e^{i\theta},\qquad
B_\beta(\theta)=a(\theta+\pi)^{-\beta}e^{i\theta},
\]
its large-`T` cubic-scale blow-up is an alternating parallel-line lamination.  The tangent contains a continuum of exact squares.

Nevertheless the finite-scale square equations have a universal second-order solvability obstruction
\[
\boxed{\pi^2\beta^2(\beta+1)}.
\]
In physical coordinates the mismatch is
\[
\Delta_{\rm sq}\asymp
 a\pi^2\beta^2(\beta+1)T^{-\beta-3}.
\]

For the area-critical exponent `beta=1/2`, with local packet radius `r=aT^{-1/2}`,
\[
\boxed{
\text{opposite-side gap}\asymp r^3,
\qquad
\text{local square defect}\asymp r^7.
}
\]
The exact critical coefficient before conversion to `r` is `3 pi^2/8`.

Numerical minimization gives
\[
\|\mathrm{residual}\|T^{7/2}
\to \frac{3\pi^2}{8\sqrt2},
\]
in agreement with the symbolic expansion.

## Exact residue picture

On a fixed ray the combined A/B layers have radii
\[
a(\theta+\pi m)^{-\beta}.
\]
On a quadrature ray the arguments are shifted by `pi/2`.  Exact equal-radius matching would require an integer difference equal to `1/2`, which is impossible.

Thus the winding center itself carries an exact half-turn residue obstruction to centered squares.

## What changed

The v185 terminal geometry does **not** collapse under a purely local two-strand theorem.

The leading cubic tangent is too degenerate: it is square-rich, but those squares have zero transverse stability.  The first invariant distinguishing the real spiral from its lamination tangent appears four relative powers later (`r^7` versus side `r^3`).

This is analogous in spirit to the earlier phase degeneracy hierarchy, but it is now derived from the global quadratic-concentration geometry rather than introduced as a separate local ansatz.

## What remains open

The critical double spiral can still contain nonlocal squares; v186 does not claim otherwise.  The local obstruction says only that a square using one adjacent strand pair on the natural `r^3` square scale is not forced and, in the canonical model, has a sign-definite asymptotic mismatch.

The next proof attempt must exploit the **layer stack**, not one corridor cell.

## Recommended v187 target

Analyze the multi-layer / quarter-turn regime.

At radius `r`, the packet contains `N~r^{-2}` alternating layers.  Over an angular displacement `O(1)` the union is an `O(r^3)` perturbation of a circle, so quarter-turn quadruples are approximate squares of side `O(r)`.  The layer index changes the radial correction in steps of order `r^3`.

This creates a discrete-continuous resonance problem:

- angular variables provide continuous adjustment;
- turn indices provide an integer radial lattice;
- the canonical half-turn residue gives the leading offset.

The v187 target should determine whether the many available layer indices force one exact noncentered square, or whether they generate a new coherent lattice obstruction.

Do not return yet to generic C0 corridor roughness.  The canonical critical model already shows the correct next scale is multi-layer/nonlocal.
