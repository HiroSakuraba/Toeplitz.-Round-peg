# Handoff v187 — nonlocal phase-lattice squares in the critical double spiral

## Executive result

v186's half-turn residue and seventh-order local corridor defect do **not** make the canonical critical double spiral square-free.

For
\[
\Sigma_a=\{z\ne0:a^2/|z|^2-\arg z\in\pi\mathbb Z\},
\]
which is exactly the union of the two critical `r(theta)~theta^{-1/2}` spiral arms near the winding center, there are exact noncentered squares at **every sufficiently small scale**.

The proof is a three-dimensional phase-lattice matching argument on square shape space.

## Square-shape phase map

Fix normalized orientation and write
\[
w_0=c+s,\quad w_1=c+is,\quad w_2=c-s,\quad w_3=c-is,
\qquad c=x+iy.
\]
An actual square is `z_j=rho exp(i theta) w_j`.

Define
\[
G=(|w_1|^{-2}-|w_0|^{-2},
   |w_2|^{-2}-|w_0|^{-2},
   |w_3|^{-2}-|w_0|^{-2}).
\]
The three relative spiral phases are
\[
D_\rho=(a^2/\rho^2)G-A,
\]
where `A` is the corresponding three-vector of argument differences.

The exact Jacobian factorization is
\[
\boxed{
\det DG=
\frac{-128s^3(x-y)(x+y)(s^2-x^2-y^2)}
{\prod_{j=0}^3|w_j|^4}.
}
\]
Thus the radial shape map has full rank at every generic off-center shape.

A convenient exact reference point is
\[
(x,y,s)=(1/3,2/3,1),
\]
where
\[
\det DG=1594323/135200>0.
\]

## Lattice theorem

Let `L=a^2/rho^2`.  The nearest point of `pi Z^3` to `D_rho(u_*)` is only `O(1)` away.  Since the derivative of `D_rho` is `L DG+O(1)`, an `O(1/L)=O(rho^2)` change of normalized shape hits that lattice point exactly.

The physical vertex displacement is therefore only
\[
\boxed{O(\rho^3)}.
\]

Once the three phase differences are lattice-aligned, a common rotation shifts all four phases equally and can make the first phase an integer multiple of `pi`.  All four vertices then lie on `Sigma_a`.

Hence
\[
\boxed{
\text{for every sufficiently small }\rho,
\ \Sigma_a\text{ contains an exact square of side }\asymp\rho.
}
\]

## Why this matters

The v186 local cubic lamination was deceptive in the opposite direction from what we feared.  A single adjacent corridor square is obstructed at order `r^7`, and centered squares are excluded by a half-turn residue, but the full layer stack restores enough shape freedom to hit the phase lattice exactly.

The correction scale is physically `O(r^3)`, exactly the v185 inter-side layer spacing.  So the global stack, not one corridor, is the right object.

## Numerical construction

The verifier solves the three lattice-difference equations for the reference shape at decreasing `rho`.  Representative exact phase-index vectors are:

- `rho=0.1`: `(15,11,36,144)`;
- `rho=0.05`: `(59,45,144,575)`;
- `rho=0.025`: `(228,175,571,2291)`;
- `rho=0.0125`: `(917,705,2291,9168)`.

The lattice residuals are at floating-point roundoff and the square equations are exact by construction.

## What remains open

The canonical critical spiral germ is now **closed** as a terminal obstruction.

The general v185 packet need not admit the exact phase law
\[
\Psi(z)=a^2/|z|^2-\arg z.
\]
The next question is therefore a stability/rigidity dichotomy:

1. **coherent cubic phase law:** after normalization, the ordered layers are `o(r^3)`-close to a critical phase lattice; then the v187 square should persist by degree;
2. **incoherent cubic phase law:** layer positions fluctuate by order `r^3` or more; that fluctuation is a new transverse roughness quantity and should itself carry quadratic concentration.

This is the recommended v188 target.

## Status correction

Do not describe the half-turn residue as a global square obstruction.  It is only a centered-square obstruction.

Do not describe the seventh-order defect as excluding all small squares in the double spiral.  It excludes the particular adjacent-corridor family analyzed in v186.

The full noncentered shape space contains exact lattice squares.
