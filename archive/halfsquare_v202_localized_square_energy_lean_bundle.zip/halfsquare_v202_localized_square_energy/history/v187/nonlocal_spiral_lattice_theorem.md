# Nonlocal lattice squares in the critical double spiral

## 1. The critical layer set

Fix `a>0`.  The critical double-spiral layer set near the origin can be written without choosing an arm label as

\[
\Sigma_a=\left\{z\ne0:\ \Psi(z):=\frac{a^2}{|z|^2}-\arg z\in\pi\mathbb Z\right\}.
\]

The condition is independent of the branch of `arg`, because changing `arg` by `2\pi` does not change membership in `\pi\mathbb Z`.

Equivalently, on a ray of geometric angle `\phi`, the allowed radii are

\[
r_m(\phi)=a(\phi+\pi m)^{-1/2}
\]

whenever the quantity in parentheses is positive.  Even/odd `m` recover the two interleaved spiral arms.

## 2. A three-parameter square shape

Fix the orientation of a normalized square and write

\[
\begin{aligned}
w_0&=c+s,\\
w_1&=c+is,\\
w_2&=c-s,\\
w_3&=c-is,
\end{aligned}
\qquad c=x+iy,\quad s>0.
\]

An actual square is

\[
z_j=\rho e^{i\theta}w_j,
\]

with side length `\sqrt2\,\rho s`.

Put

\[
H_j(x,y,s)=|w_j|^{-2},
\qquad
G=(H_1-H_0,H_2-H_0,H_3-H_0).
\]

Let

\[
A=(\arg w_1-\arg w_0,\arg w_2-\arg w_0,\arg w_3-\arg w_0)
\]

on any small shape neighborhood avoiding the origin.  The three phase differences of the square are

\[
\boxed{
D_\rho(x,y,s)=\frac{a^2}{\rho^2}G(x,y,s)-A(x,y,s).
}
\]

They are independent of the common rotation `\theta`.

## 3. Exact radial-shape Jacobian

A direct calculation gives

\[
\boxed{
\det DG=
\frac{-128s^3(x-y)(x+y)(s^2-x^2-y^2)}
{|w_0|^4|w_1|^4|w_2|^4|w_3|^4}.
}
\]

Hence `G` is a local diffeomorphism whenever

\[
x\ne y,\qquad x\ne-y,\qquad x^2+y^2\ne s^2,
\]

and none of the four vertices equals the origin.

For example, at

\[
(x_*,y_*,s_*)=(1/3,2/3,1),
\]

\[
\det DG(x_*,y_*,s_*)=\frac{1594323}{135200}>0.
\]

The three excluded loci have simple geometric meanings: center on a square diagonal, or the winding center lying on the square itself.

## 4. Lattice matching theorem

### Theorem

Let `(x_*,y_*,s_*)` be any normalized square shape at which `DG` is nonsingular.  Then there exists `\rho_0>0` such that for every `0<\rho<\rho_0` there are

\[
(x_\rho,y_\rho,s_\rho)
=(x_*,y_*,s_*)+O(\rho^2)
\]

and a rotation `\theta_\rho` for which all four vertices

\[
z_{j,\rho}=\rho e^{i\theta_\rho}w_j(x_\rho,y_\rho,s_\rho)
\]

belong to `\Sigma_a`.

Consequently the critical double spiral contains an exact square at every sufficiently small spatial scale, with

\[
\text{side}(Q_\rho)=\sqrt2\,s_*\rho+O(\rho^3).
\]

### Proof

Write

\[
L=\frac{a^2}{\rho^2}\to\infty.
\]

At the reference shape `u_*=(x_*,y_*,s_*)`, choose a nearest lattice point

\[
\pi k_L\in\pi\mathbb Z^3
\]

to `D_\rho(u_*)`.  The discrepancy

\[
b_L=\pi k_L-D_\rho(u_*)
\]

is uniformly bounded, for example `|b_L|\le \sqrt3\pi/2` in Euclidean norm.

Seek a corrected shape

\[
u=u_*+\frac{v}{L}.
\]

Taylor expansion on a fixed compact shape neighborhood gives, uniformly for bounded `v`,

\[
D_\rho\!\left(u_*+\frac vL\right)-D_\rho(u_*)
=DG(u_*)v+O(L^{-1}).
\]

Because `DG(u_*)` is invertible, the bounded linear solution

\[
v_L^{(0)}=DG(u_*)^{-1}b_L
\]

can be corrected by the quantitative inverse-function theorem (or contraction mapping) to an exact bounded solution `v_L=v_L^{(0)}+O(L^{-1})` of

\[
D_\rho\!\left(u_*+\frac{v_L}{L}\right)=\pi k_L.
\]

Thus

\[
u_\rho-u_*=O(L^{-1})=O(\rho^2).
\]

At this corrected shape, the four phases differ from the phase of vertex zero by integer multiples of `\pi`.  Rotation by `\theta` changes every phase by exactly `-\theta`.  Choose `\theta_\rho` modulo `\pi` so that

\[
\Psi(\rho e^{i\theta_\rho}w_0)\in\pi\mathbb Z.
\]

Then all four phases lie in `\pi\mathbb Z`, so all four vertices lie on `\Sigma_a`.  They form a Euclidean square by construction.  The physical shape correction is

\[
\rho\,O(\rho^2)=O(\rho^3).
\]

This proves the theorem. `\square`

## 5. Interpretation

v186 found two genuine local obstructions:

1. centered square matching fails by the exact half-turn residue;
2. one adjacent cubic corridor has a sign-definite seventh-order square defect.

The theorem above shows that neither obstruction survives the full three-dimensional shape freedom of a noncentered square.  The phase lattice becomes denser in shape coordinates at rate `\rho^{-2}`, while only `O(\rho^3)` physical motion is needed to correct all three relative phases.  Rotation then supplies the fourth lattice coordinate.

Thus the scale-critical double spiral is **not** a terminal counterexample geometry.  It is in fact asymptotically square-rich.

## 6. What this does and does not prove for the general Jordan problem

This theorem is exact for the canonical critical layer set `\Sigma_a`.  It does not yet prove that every v185 high-winding packet is close enough to `\Sigma_a` to inherit one of these squares.

The relevant stability scale is now visible: the square correction itself is physical order `\rho^3`, exactly the inter-layer scale from v185.  Therefore a general packet that admits a coherent critical phase law with error `o(\rho^3)` should inherit the lattice hit by degree stability.  A hypothetical counterexample must prevent such a coherent phase-law approximation at the cubic layer scale.

That is the next global obstruction.
