# Handoff v188 — subleading phase stability and radial exceptional classification

## Executive result

v187's proposed coherence threshold was far too strict.  The exact-square degree argument survives any coherent phase perturbation of size
\[
E_L=o(L),\qquad L\asymp r^{-2},
\]
not merely positional errors `o(r^3)`.

For the critical double spiral this means that, under a coherent radial phase parametrization, even positional errors `o(r)` remain square-forcing.  In particular, bounded phase corrugations that move the layers by `O(r^3)`—even with `O(r^{-2})` angular frequency—do **not** create a new escape branch.

The same calculation gives an exact determinant for a general radial phase law and classifies the only laws whose leading three-dimensional square-shape map is everywhere singular: affine and logarithmic laws in squared radius.

## Exact general radial determinant

For
\[
G_h=(h(q_1)-h(q_0),h(q_2)-h(q_0),h(q_3)-h(q_0)),
\]
with the usual square radii `q_j`,
\[
\det DG_h
=16s(x^2+y^2-s^2)
\prod_{j=0}^3h'(q_j)
\left(
\frac1{h'(q_3)}-\frac1{h'(q_2)}
+\frac1{h'(q_1)}-\frac1{h'(q_0)}
\right).
\]

For `h(q)=1/q` this specializes exactly to the v187 Jacobian.

If the reciprocal-slope factor vanishes for every generic square, then with `R=1/h'` the `y=0` family gives
\[
R(m+a)+R(m-a)=2R(m).
\]
Hence `R''=0`, so
\[
1/h'(q)=\alpha+\beta q.
\]
Thus the leading radial exceptional laws are precisely affine `h(q)=Aq+B` and logarithmic `h(q)=A log|alpha+beta q|+B`.

Do **not** call these square-free families.  They are only the families where the leading radial rank argument fails.

## Stability theorem

For a coherent packet
\[
\Phi_L(re^{i\vartheta})=Lh(r^2)-\vartheta+e_L(r,\vartheta),
\qquad \|e_L\|_\infty=E_L=o(L),
\]
if `DG_h` is nonsingular at one generic reference square, then for all large `L` the lattice level set
\[
\Sigma_L=\{\Phi_L\in\pi\mathbb Z\}
\]
contains an exact square.  The normalized shape correction is
\[
O((E_L+1)/L).
\]

The proof uses a four-dimensional anisotropic Brouwer cylinder.  On the three-dimensional shape boundary, `L DG_h` dominates every `O(E_L)` phase perturbation.  On the rotation boundary, the exact `-theta` term dominates.  Homotopy to the affine map `(DG_h v, ell dot v-theta)` gives nonzero degree.

No derivative bound on `e_L` is needed.

## Critical consequence

For `h(q)=1/q` and `L=a^2/rho^2`, every coherent phase perturbation with
\[
\|e_\rho\|_\infty=o(\rho^{-2})
\]
is square-rich.

A relatively `o(1)` perturbation of indexed layer radii on a fixed normalized annulus induces `o(L)` phase error; physically this is an `o(rho)` positional error.  Thus the square theorem is stable vastly beyond the cubic `rho^3` corridor spacing.

## Correction to the proposed v188 branch

`O(r^3)` layer fluctuation is **not** by itself a quadratic roughness obstruction.  The explicit phase corrugation
\[
\Phi_L=L/r^2-\theta+\varepsilon\sin(L\theta)
\]
has bounded phase error, moves layers by `O(r^3)` physically, and oscillates `O(r^{-2})` times per turn, yet remains inside the square-forcing stability theorem.  Its naive transverse squared-increment cost is only `O(r^4)`.

So the remaining escape is not ordinary cubic noise.  It must be leading-order phase disorder, radial affine/log degeneracy, genuinely nonradial leading phase, or failure to organize the winding crossings into an annular phase lamination.

## Recommended v189

Attack the topology of the v185 packet:

1. use the `N~r^-2` alternating ray crossings and planarity to try to extract a large annular braid/sublamination with coherent layer index;
2. if such a sublamination exists, normalize its phase law and apply v188;
3. if extraction fails, encode the births/backtracking as a braid or Stieltjes current rather than returning to local fold enumeration;
4. separately audit the affine/log leading exceptions to see whether lower-order angular terms restore square degree.

## Files

- `phase_lattice_stability_theorem.md` — detailed theorem and proof;
- `code/verify_v188.py` — determinant/classification/scaling checks;
- `results/verify_v188_output.txt` — verifier output;
- `prior/halfsquare_v187_nonlocal_spiral_lattice_bundle.zip` — prior cumulative bundle.
