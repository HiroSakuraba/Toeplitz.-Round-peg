# v188 status corrections

1. **Do not use `o(r^3)` as the stability threshold.**  Under a coherent phase coordinate the v187 lattice degree survives every subleading phase error `E=o(L)`, `L~r^-2`.  For the critical radial law this can include positional errors `o(r)`.

2. **Do not claim `O(r^3)` corrugation spends a fixed quadratic-variation budget.**  A layer displacement of amplitude `r^3` repeated `r^-2` times has naive squared transverse cost only `O(r^4)`.

3. **Do not call affine/log radial laws counterexamples.**  They are only the laws for which the leading three-dimensional radial square-shape Jacobian is identically rank deficient.  Lower-order angular terms may still force squares.

4. **Do not claim v188 applies to an arbitrary v185 threading packet.**  v188 requires a coherent scalar phase-lattice description on the relevant annulus.  Extracting such a lamination from the purely topological v185 crossings is still open.

5. **The canonical critical double spiral remains closed as a terminal obstruction.**  v187 already proves exact noncentered squares at every sufficiently small scale; v188 makes that conclusion robust under broad coherent subleading perturbations.
