# Handoff v189 — nested lobe lamination and the failure of purely topological braid extraction

## Executive result

The v188 topological question has a clean answer.

A primitive-concentration packet of diameter `r` and chord-closed area bounded below by a fixed constant contains a point lying in
\[
N\gtrsim r^{-2}
\]
same-sign endpoint-line Jordan lobes.  Those lobes form a nested chain.  Moving from that point along the normal direction away from the endpoint line crosses the **actual arc pieces** of all selected lobes inside distance `r`, hence two consecutive layers are separated by
\[
O(r/N)=O(r^3).
\]

Thus a deep lamination really is forced, and the cubic transverse scale is intrinsic.

However, the forced lamination is only topological.  It need not be a Euclidean radial/annular phase lattice.  A chord-fixing planar homeomorphism preserves the nested lobe tree and winding while changing radial geometry by order `r`.  So v188 cannot be activated from Jordan topology alone.

## Exact lobe decomposition

For a simple polygonal arc `sigma` and its endpoint line `ell`, cut `sigma` into off-line excursion components `sigma_i`.  Close each with its chord interval on `ell` to obtain a simple Jordan loop `L_i` with domain `D_i` and orientation sign `eps_i`.

As oriented chains,
\[
Gamma=sigma+\text{endpoint chord}=\sum_i L_i.
\]
Therefore
\[
A(Gamma)=\sum_i eps_i |D_i|.
\]
After orienting so `A(Gamma)>0`, the sum of positive lobe areas is at least `A(Gamma)`.

All lobe domains lie in the convex hull `K` of the arc, and
\[
|K|\le \pi r^2/4.
\]
The positive multiplicity
\[
m_+(z)=\#\{i:eps_i=+1, z\in D_i\}
\]
therefore satisfies
\[
\max m_+\ge 4A(Gamma)/(\pi r^2).
\]
For the v184 packets `|A(Gamma)|>=eps/2`, so
\[
N\ge 2eps/(\pi r^2).
\]

## Nested-chain theorem

All positive lobes containing the maximizing point `z` lie in the same half-plane bounded by the endpoint line.  Their off-line boundaries are pairwise disjoint crosscuts.

Two such crosscuts have noninterlacing endpoint pairs; their caps are disjoint or nested.  Since the selected caps all contain `z`, they cannot be disjoint.  Hence
\[
D_1\supset D_2\supset\cdots\supset D_N\ni z.
\]

This makes explicit the laminar structure hidden behind the v184 high-winding estimate.

## Same-side cubic spacing

Take the normal ray from `z` pointing away from the endpoint line.  It never hits an artificial chord interval.  It exits each selected domain through the actual excursion arc.  The first-exit distances are strictly ordered and all lie in an interval of length at most `r`, so
\[
\min \Delta t\le r/(N-1)=O(r^3).
\]

This is independent of the v185 complementary-side cancellation theorem.  We now have two manifestations of the cubic scale:

- v185: opposite parameter sides interthread at `O(r^3)`;
- v189: same-sign nested lobes inside the concentration arc itself have `O(r^3)` transverse gaps.

## Critical rainbow calibration

There is a simple nonspiral sharpness family.

Set `q_j=1-j/(3N)` and scale by `lambda=N^-1/2`.  Alternate:

- an upper semicircle from `q_j` to `-q_{j+1}`;
- a lower semicircle from `-q_{j+1}` to `q_{j+1}`.

The upper caps are nested and all contain one upper-half-plane point.  The chord closure has winding exactly `N` there.  After scaling,
\[
r\asymp N^{-1/2},\qquad A\asymp1,\qquad N\asymp r^{-2}.
\]
On the normal line `x=0`, upper crossing heights satisfy
\[
y_j-y_{j+1}\sim \frac13\lambda^3.
\]
Thus `r^3` spacing is sharp even in a chord-rainbow rather than root-spiral geometry.

## Correction to the v188 plan

High winding plus simplicity does **not** force a Euclidean radial braid.  The lobe stack is preserved by arbitrary chord-fixing ambient homeomorphisms.  A fixed anisotropic affine map already distorts circular layers by order `r`, outside the radial `o(r)` coherence class highlighted in v188.

So the next step should not be another attempt to prove radiality from topology.

## Recommended v190 target

Generalize phase-lattice stability from radial laws to an arbitrary coherent scalar phase `H(x,y)`.

For square vertices
\[
z_j=c+sR_\theta v_j,
\]
study
\[
F_H(c_x,c_y,s,\theta)=
(H(z_0),H(z_1),H(z_2),H(z_3)).
\]
If `det D F_H != 0` at one square, a large multiplier `L H + o(L)` should hit `pi Z^4` by Brouwer degree, forcing exact squares.

This would cover elliptic/sheared/nonradial laminations and leave one genuinely structural exceptional problem: classify scalar phase functions whose four-square phase map is rank-deficient at **every** square.
