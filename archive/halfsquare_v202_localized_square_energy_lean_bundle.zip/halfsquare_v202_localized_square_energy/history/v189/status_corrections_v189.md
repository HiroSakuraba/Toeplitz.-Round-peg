# Status corrections after v189

1. **Do not claim that high winding forces a Euclidean annular braid.**
   The forced object is a nested family of endpoint-line Jordan lobes. An ambient homeomorphism preserves that topology while changing Euclidean radial geometry by order the packet scale.

2. **Do not treat the root spiral as the unique critical geometry.**
   The critical rainbow model has the same `N ~ r^-2` multiplicity and `r^3` transverse spacing while being organized by nested chord caps rather than annular turns.

3. **The cubic law remains real.**
   v189 derives `O(r^3)` same-side spacing directly from lobe depth, independently of the v185 complementary-side ray argument.

4. **v188 remains useful but needs a broader phase class.**
   Radial phase coherence is not topologically forced. The next theorem should use an arbitrary scalar phase function `H(x,y)` and the full four-dimensional square phase map.

5. **The new hard object is metric lamination.**
   Topology supplies depth and order. What remains is to obtain enough Euclidean coherence of the nested layers, or else turn failure of such coherence into a new quantitative invariant.
