# Proof audit v190

## What was checked

### Full-rank degree theorem
The perturbation `e_L` is allowed to be continuous and arbitrarily oscillatory. The proof only compares its total amplitude `o(L)` with the `L`-amplified invertible derivative of the leading square-phase map. On a ball of radius
\[
r_L\asymp \|e_L\|_\infty/L+1/L,
\]
the linear boundary displacement dominates:

- nearest `pi Z^4` rounding error: `O(1)`;
- perturbation variation: `O(||e_L||_infty)`;
- nonlinear `F_H` remainder: `o(L r_L)`.

Thus ordinary Brouwer degree is sufficient; no derivative estimate on `e_L` is being smuggled in.

### Determinant geometry
The four square parameters are the four parameters of the direct-similarity group. Replacing local `(center, scale, angle)` derivatives by global translation/dilation/rotation generators is an invertible column change, hence does not affect rank.

The determinant is row-homogeneous in the four gradients. Therefore its zero set depends only on the gradient line field.

### Angle identity
For an axis square, after normalizing each gradient to angle `phi_j`, exact symbolic expansion gives
\[
D=\sin(\phi_E-\phi_N+\phi_W-\phi_S)
+\sin(\phi_E-\phi_W)\sin(\phi_N-\phi_S).
\]
The verifier checks this against the raw `4 x 4` determinant for 100 random angle quadruples.

### Small-square PDE
Expanding `D=0` to second order in square radius gives
\[
\phi_{uu}-\phi_{vv}+4\phi_u\phi_v=0
\]
for every orthonormal direction pair `(u,v)`. Fourier expansion in the square orientation gives exactly two independent equations:
\[
\phi_{xx}-\phi_{yy}+4\phi_x\phi_y=0,
\qquad
\phi_{xy}=\phi_x^2-\phi_y^2.
\]

### Riccati rigidity
With `w=phi_x+i phi_y`, the PDE becomes
\[
w_{\bar z}=i w^2,
\qquad
R:=w_z=\tfrac12\Delta\phi\in\mathbb R.
\]
Commuting mixed derivatives gives
\[
R_{\bar z}=2iwR.
\]
If `R` is nonzero on a neighborhood, then
\[
(\log|R|)_x=-4\phi_y,
\qquad
(\log|R|)_y=4\phi_x.
\]
Hence `log|R|-4i phi` is holomorphic, forcing `phi` harmonic. But then `R=Delta phi/2=0`, contradiction. Thus `R=0` everywhere.

The remaining anti-holomorphic ODE has only
\[
w=0
\]
or
\[
w=i/(\bar z-\bar z_0).
\]
This yields constant gradient direction or radial-plus-constant-offset gradient direction.

### Regularity
The elementary proof differentiates the angle field through third order. To avoid burying a weak-regularity argument, v190 assumes `H in C4` and `grad H != 0` on the classified patch. Lowering this hypothesis is left open.

## What is not proved

- v190 does not extract a scalar phase from the raw v189 topological lamination.
- v190 does not yet force squares in the similarity-symmetric rank-three family; it identifies that family exactly.
- v190 makes no priority or novelty claim.
