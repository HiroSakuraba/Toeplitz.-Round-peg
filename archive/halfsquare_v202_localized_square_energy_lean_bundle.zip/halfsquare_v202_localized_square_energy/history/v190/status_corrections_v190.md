# v190 status and corrections

1. **Do not claim topology alone supplies a scalar phase.** v189 only forces a nested topological lamination.
2. **Do not classify all rough laminations by v190.** The classification assumes a `C4` scalar phase with nonvanishing gradient.
3. **Do not say rank deficiency means radiality.** The full exceptional family consists of parallel-line and one-parameter similarity foliations, including circles, rays, and logarithmic spirals.
4. **Do not require smooth subleading error in the full-rank degree theorem.** Continuity plus `o(L)` amplitude is enough.
5. **The classification is local on angular lifts.** Genuine spiral/angular coordinates can be multivalued around the similarity center.
6. **No novelty claim is made.** This is a project theorem requiring independent audit before external use.
