# v191 research direction — a conformal four-point Fourier transform for arbitrary Jordan curves

## 1. Why introduce a different transform?

The v189-v191 phase program is powerful once a dense nested packet can be organized by a scalar metric phase. An arbitrary Jordan curve need not provide that organization.

A Fourier representation can be made available for **every** Jordan curve by using its conformal parameterization rather than an arbitrary topological parameterization. This gives a second route that starts before the scalar-phase extraction step.

The useful object is not a single ordinary Fourier transform. It is a two-level transform:

1. a conformal Fourier/Taylor spectrum of the whole Jordan boundary;
2. a four-point discrete Fourier transform of candidate vertex quadruples.

Adding disk automorphisms makes the transform local in both position and scale.

---

## 2. Canonical conformal parameterization

Let `Gamma` be a Jordan curve and `Omega` its bounded Jordan domain. Let
\[
f:\mathbb D\to\Omega
\]
be a Riemann map. By the Caratheodory boundary theorem, `f` extends to a homeomorphism
\[
f:\overline{\mathbb D}\to\overline\Omega.
\]
After fixing the three real disk-automorphism normalization freedoms, the boundary parameterization
\[
\gamma(\theta)=f(e^{i\theta})
\]
is canonical for the domain.

Inside the disk,
\[
\boxed{f(z)=a_0+\sum_{n\ge1}a_nz^n.}
\]
For `0<r<1`, the Abel-smoothed boundary
\[
\gamma_r(\theta)=f(re^{i\theta})
=a_0+\sum_{n\ge1}a_nr^n e^{in\theta}
\]
is analytic and converges uniformly to the Jordan boundary as `r -> 1`.

Because `f` is univalent,
\[
\boxed{
\operatorname{Area}(\Omega)
=\int_{\mathbb D}|f'(z)|^2\,dA
=\pi\sum_{n\ge1}n|a_n|^2.
}
\]
Thus every Jordan domain comes with a finite weighted spectral-energy budget, even when its boundary is nonrectifiable.

---

## 3. The four-point DFT is exactly adapted to squares

Take four complex points `Z_0,...,Z_3` and define
\[
\boxed{
\widehat Z_k=\frac14\sum_{j=0}^3 Z_j i^{-kj},
\qquad k=0,1,2,3.
}
\]
The inverse transform is
\[
Z_j=\widehat Z_0+\widehat Z_1 i^j+\widehat Z_2(-1)^j+\widehat Z_3(-i)^j.
\]

A positively ordered nondegenerate square is exactly
\[
Z_j=c+a i^j,
\qquad a\ne0.
\]
Therefore
\[
\boxed{
\widehat Z_2=\widehat Z_3=0,
\qquad
\widehat Z_1\ne0.
}
\]
The opposite orientation is characterized by
\[
\widehat Z_1=\widehat Z_2=0,
\qquad
\widehat Z_3\ne0.
\]
So the square condition is the vanishing of **two complex Fourier modes**, i.e. four real equations.

This is the same dimension as the configuration space of four ordered points on a circle.

---

## 4. The square transform of a Jordan curve

For four boundary parameters `zeta_j in S^1`, set
\[
Z_j=f(\zeta_j).
\]
Define
\[
\boxed{
\mathcal T_f^+(\zeta_0,\ldots,\zeta_3)
=(\widehat Z_2,\widehat Z_3)\in\mathbb C^2.
}
\]
A zero with `widehat Z_1 != 0` is an inscribed square in the positive vertex order. The reverse-order transform is
\[
\mathcal T_f^-=(\widehat Z_1,\widehat Z_2).
\]
Taking the finitely many cyclic-order chambers of distinct quadruples covers the fact that the Jordan curve need not visit the four geometric square vertices in geometric cyclic order.

The important spectral identity is linearity in the conformal coefficients:
\[
\boxed{
\widehat Z_k
=\sum_{n\ge0}a_n
\left[\frac14\sum_{j=0}^3\zeta_j^n i^{-kj}\right].
}
\]
Thus the square-test map is a superposition of explicitly known responses of the monomials `z^n`.

---

## 5. Equal conformal spacing gives an exact residue-class filter

For the special quartet
\[
\zeta_j=e^{i(\theta+j\pi/2)},
\]
we obtain
\[
\boxed{
\widehat Z_k(\theta)
=\sum_{m\ge0}a_{4m+k}e^{i(4m+k)\theta}.
}
\]
For the Abel-smoothed curve, insert the factor `r^{4m+k}`.

So the four-point DFT separates the Riemann-map Fourier spectrum into the four congruence classes
\[
n\pmod4.
\]
In particular, if the `2 mod 4` and `3 mod 4` classes vanish, every quarter-spaced conformal quartet is an exact square of the positive orientation, provided the `1 mod 4` component is nonzero.

Parseval gives
\[
\int_0^{2\pi}|\widehat Z_k(r,\theta)|^2\,d\theta
=2\pi\sum_{m\ge0}|a_{4m+k}|^2r^{2(4m+k)}.
\]
This supplies a quantitative measure of how far the quarter-spaced quartets are, on average, from square shape.

Equal spacing is only a one-dimensional subfamily and cannot settle Toeplitz by itself. Its value is that it exposes the exact spectral algebra.

---

## 6. Cover all four-point configurations with Möbius localization

The boundary automorphism group of the disk has three real parameters. An ordered cyclic quadruple on `S^1` has four real parameters. Modulo a disk automorphism, only one real cross-ratio parameter remains.

Choose, in each cyclic-order chamber, a canonical quartet
\[
q_0(\tau),\ldots,q_3(\tau)\in S^1,
\qquad 0<\tau<1,
\]
representing the cross-ratio modulus. Let `g in PSU(1,1)` be a disk automorphism. Then
\[
\boxed{
\zeta_j=g(q_j(\tau))
}
\]
parameterizes all distinct ordered boundary quadruples in that chamber, up to only finite redundancy.

Define the **Möbius-Fourier square transform**
\[
\boxed{
\mathfrak S_f(g,\tau)
=
\left(
\frac14\sum_j f(gq_j(\tau))(-1)^j,
\frac14\sum_j f(gq_j(\tau))i^j
\right),
}
\]
with the convention adjusted to the desired orientation.

Domain dimension:
\[
3+1=4.
\]
Target dimension:
\[
\dim_\mathbb R\mathbb C^2=4.
\]
Toeplitz becomes a zero problem for this four-dimensional transform.

This is essentially the configuration-space test map written in coordinates that diagonalize square geometry and expose the analytic spectrum of the Jordan domain.

---

## 7. A local spectrum at every position and scale

The Möbius action can do more than enumerate quadruples. It gives a conformally natural zoom transform.

Let
\[
\phi_a(z)=\frac{a+z}{1+\bar a z},
\qquad a\in\mathbb D,
\]
so `phi_a(0)=a`, and define the normalized blow-up
\[
\boxed{
\mathcal C_a f(z)
=
\frac{f(\phi_a(z))-f(a)}{(1-|a|^2)f'(a)}.
}
\]
Then
\[
\mathcal C_a f(0)=0,
\qquad
(\mathcal C_a f)'(0)=1,
\]
and
\[
\mathcal C_a f(z)=z+b_2(a)z^2+b_3(a)z^3+\cdots.
\]
For every `a`, this is a normalized univalent function. The coefficients `b_n(a)` form a **local conformal Fourier spectrum** of the Jordan domain at the hyperbolic position/scale `a`.

As `|a| -> 1`, the automorphism concentrates fixed boundary arcs near one prime end while the affine normalization magnifies the image. Hence the family `b_n(a)` is a natural multiscale transform of arbitrarily rough Jordan boundaries.

Classical coefficient bounds for normalized univalent functions give universal compactness of these local spectra on every fixed inner disk. That is much more structure than an arbitrary Fourier series of an arbitrary topological parameterization.

---

## 8. How this could connect to the v189 lamination

The standard smooth-approximation obstruction is that squares on
\[
f(rS^1),\qquad r\uparrow1,
\]
may shrink to zero. In the Möbius-Fourier coordinates, such collapse is not merely 'side length goes to zero'. It means the configuration parameters escape toward the boundary of the disk-automorphism/cross-ratio space.

That gives a concrete dichotomy:

1. **compact spectral zero branch:** a sequence of square-transform zeros stays in a compact part of `(g,tau)`; then uniform convergence `f_r -> f` yields a nondegenerate boundary square;
2. **escaping zero branch:** the Möbius parameter tends to the disk boundary or the cross ratio degenerates. Renormalize by the same automorphisms. The normalized maps `C_a f` have a normal-family subsequence and produce a nontrivial local conformal spectrum.

The second case is exactly where the v189 deep nested lamination should live in physical coordinates. Instead of trying to guess a scalar phase directly from the lamination, one can ask whether an escaping square branch forces a restricted limit spectrum `b_n(a_m)`.

A useful future target is therefore:

> **Spectral escape classification.** Classify normal-family limits of `C_{a_m}f` compatible with persistent square-transform escape and with the v189 `r^{-2}` multiplicity / `r^3` spacing law. Show that either the limit transform has a nondegenerate square zero or its spectrum falls into an explicitly rigid exceptional family.

This would be the spectral analogue of v190's scalar-phase classification.

---

## 9. Why this is broader than the scalar-phase approach

The scalar-phase theorem requires a patch of many physical layers that can be indexed by one sufficiently coherent `H(x,y)`.

The conformal-Fourier transform instead requires only that `Gamma` be a Jordan curve. It automatically supplies:

- a canonical boundary parameterization up to disk automorphism;
- analytic Abel approximants at every scale;
- a finite weighted global Fourier-energy budget;
- a four-real-dimensional transform whose zeros are exactly squares;
- Möbius localization capable of following arbitrarily small boundary features;
- normalized univalent blow-ups with compact coefficient families.

It therefore covers the entire Jordan class from the outset.

It does **not** by itself solve the degeneration problem. The hard theorem would be a boundary/escape estimate proving that zeros of `mathfrak S_f` cannot all disappear into the compactification without producing a new zero after conformal renormalization.

---

## 10. Recommended computational experiments

The transform is unusually testable.

For a library of polygonal, fractal-like, zipper, rainbow, spiral, and randomly warped Jordan curves:

1. compute a numerical Riemann map and its coefficients `a_n`;
2. evaluate the four DFT residue energies;
3. search the four-dimensional `(g,tau)` transform for zeros;
4. record the local normalized spectra `b_n(a)` near shrinking-square events;
5. cluster the escape spectra and compare them with the v190 similarity families;
6. test whether a small set of spectral moments predicts full-rank square zeros.

The most valuable outcome would not be another numerical verification that squares exist. It would be evidence for a **finite spectral obstruction**: a small number of coefficient relations that every escaping sequence must satisfy. That could become an analytic theorem.
