# Handoff v191

## Main theorem

The v190 rank-three exceptional family now has a general mixed-scale closure criterion.

In symmetry-adapted coordinates, the leading four-phase map is independent of the symmetry variable `t` and has a three-dimensional transverse derivative. Let `lambda` be its one-dimensional left cokernel. For
\[
\Phi_L=L H_0+M_LH_1+e_L,
\]
the missing fourth equation is governed by
\[
\psi(t)=\lambda\cdot F_{H_1}(g_tQ_*).
\]
If `M_L=o(L)`, `||e_L||=o(M_L)`, and `M_L |psi(b)-psi(a)| -> infinity`, exact phase-lattice squares exist for every sufficiently large `L`, with transverse correction `O(M_L/L)`. If `M_L=1`, a reduced sweep larger than `pi` suffices.

This uses a four-dimensional Brouwer cylinder. Three boundary directions are controlled by the leading rank-three derivative. The two symmetry faces are controlled by the cokernel-projected subleading phase. The leading leakage into the cokernel is quadratic and equals `O(M_L^2/L)=o(M_L)`.

## Important diagnostic

If `H_1(g_tz)=H_1(z)+ct`, then
\[
\psi'(t)=c\,lambda\cdot 1.
\]
So a common phase drift is useful only when `lambda dot 1 != 0`. The linear example `H_0=x`, `H_1=y` correctly fails: `Lx+My` is still a parallel-line phase. Nonlinear ridge examples generically pass.

## Current coherent-phase frontier

- rank four somewhere: v190 closes it;
- rank three + nonzero subleading cokernel sweep: v191 closes it;
- rank three + cokernel-flat subleading hierarchy: still open but much narrower;
- no coherent scalar metric phase from the v189 lamination: still the main general-Jordan gap.

## Conformal-Fourier route

A second route avoids scalar phase extraction.

For the Riemann map `f:D->Omega` of any Jordan domain, the boundary homeomorphism `f(e^{it})` gives a conformally natural Fourier/Taylor representation. For any four boundary points `Z_j`, their 4-point DFT satisfies:

- positive square iff modes 2 and 3 vanish and mode 1 is nonzero;
- reverse square iff modes 1 and 2 vanish and mode 3 is nonzero.

Disk automorphisms contribute three real parameters, and the cross-ratio of a boundary quadruple contributes one. Therefore all ordered quadruples in a cyclic-order chamber can be tested by a four-real-dimensional Möbius-Fourier map into `C^2`.

The transform is linear in the Riemann-map coefficients. Equal quarter-spacing filters coefficients exactly by `n mod 4`. More generally, normalized maps
\[
C_af(z)=[f(phi_a(z))-f(a)]/[(1-|a|^2)f'(a)]
\]
provide a local conformal spectrum at every hyperbolic position and scale.

The next spectral target is to classify transform zeros that escape as smooth Abel approximants approach the boundary. An escaping disk automorphism gives a normalized univalent blow-up; combine its compact coefficient limit with v189's forced `r^-2` lamination and `r^3` spacing.

## Recommended v192 targets

1. Prove a higher-order closure theorem for the `psi == constant` rank-three branch by projecting the first nonzero term in a hierarchy `L H0 + M1 H1 + M2 H2 + ...` onto the evolving cokernel.
2. Build the Möbius-Fourier numerical experiment on exact polygonal Riemann maps / high-accuracy zipper maps and identify escape-spectrum signatures.
3. Derive an analytic boundary compactification of the four-point DFT map and compare it directly with Fulton-MacPherson collision coordinates.
4. Test whether the area identity `sum n|a_n|^2=Area/pi` plus univalent coefficient bounds can rule out one or more escape-spectrum classes.
