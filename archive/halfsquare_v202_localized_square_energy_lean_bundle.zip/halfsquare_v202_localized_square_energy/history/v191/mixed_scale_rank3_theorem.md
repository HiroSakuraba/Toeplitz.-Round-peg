# v191 — Mixed-scale forcing in the rank-three similarity-degenerate branch

## 1. Purpose

v190 reduces every coherent smooth scalar phase to two cases. If the four-square phase map has rank four somewhere, the large-phase lattice theorem forces a square. If it is singular on every sufficiently small square, the leading foliation is invariant under a one-parameter direct similarity: parallel lines or a logarithmic-spiral family.

The remaining coherent-phase problem is therefore rank three. This note gives a general mixed-scale degree theorem for that case.

The key point is that the fourth equation does not disappear. After the three transverse phase equations are solved at scale `M_L/L`, the remaining equation is the projection of the subleading phase onto the one-dimensional cokernel of the leading four-square map. Variation of that reduced phase along the exact symmetry orbit supplies the missing degree.

---

## 2. Adapted symmetry coordinates

Let `H_0` be `C^2` on a planar region and suppose a one-parameter direct-similarity group `g_t` preserves it:
\[
H_0(g_t z)=H_0(z).
\]
Let `Q_*` be a reference square whose symmetry orbit `g_t Q_*`, `a\le t\le b`, stays in the region.

Choose a three-dimensional transverse section through `Q_*`. In adapted square coordinates `(y,t)`, with `y\in R^3` small,
\[
Q(y,t)=g_t Q(y,0).
\]
For a scalar function `H`, write its four-vertex evaluation vector as
\[
F_H(y,t)=\bigl(H(z_0(y,t)),\ldots,H(z_3(y,t))\bigr)\in\mathbb R^4.
\]
Then the leading symmetry is exact:
\[
\boxed{F_{H_0}(y,t)=F_{H_0}(y,0).}
\]
Assume the leading map has rank exactly three at `y=0`:
\[
\operatorname{rank}D_yF_{H_0}(0)=3.
\]
Let `lambda` span its left cokernel,
\[
\lambda^T D_yF_{H_0}(0)=0.
\]
Choose an index `ell` with `lambda_ell != 0` and normalize
\[
\lambda_\ell=1.
\]
Let `I={0,1,2,3}\setminus\{\ell\}`. Then the `3 x 3` minor
\[
A=D_y(F_{H_0})_I(0)
\]
is invertible. This is the standard cofactor relation between a rank-three matrix and its left-null vector.

---

## 3. Mixed-scale phase

Consider
\[
\boxed{
\Phi_L=L H_0+M_L H_1+e_L,
}
\]
where
\[
L\to\infty,
\qquad
1\le M_L=o(L),
\qquad
\|e_L\|_\infty=o(M_L).
\]
`H_1` need only be continuous on the compact square-orbit neighborhood. No derivative bound is required on `e_L`.

Define the **reduced cokernel phase** along the symmetry orbit by
\[
\boxed{
\psi(t)=\lambda\cdot F_{H_1}(0,t).
}
\]
This is the unique scalar component of the subleading four-phase vector that cannot be cancelled to first order by changing the three transverse square parameters.

---

## 4. Rank-three mixed-scale theorem

### Theorem 4.1

Under the assumptions above, suppose there are `a<b` such that
\[
\Delta\psi:=\psi(b)-\psi(a)\ne0.
\]
If
\[
M_L\,|\Delta\psi|\longrightarrow\infty,
\]
then for every sufficiently large `L` there is an exact square `Q_L` in the adapted neighborhood with
\[
\Phi_L(z_j(Q_L))\in\pi\mathbb Z,
\qquad j=0,1,2,3.
\]
Its transverse displacement from the symmetry orbit is
\[
\boxed{|y_L|=O(M_L/L).}
\]
The symmetry coordinate `t_L` may move by order one.

More generally, if `M_L` stays bounded and `e_L=o(1)`, the same conclusion holds whenever, eventually,
\[
\boxed{M_L|\Delta\psi|>\pi+\delta}
\]
for some fixed `\delta>0`.

Thus in the literal v190 expansion
\[
\Phi_L=L H_0+H_1+o(1),
\]
a reduced-phase sweep of more than one lattice spacing `pi` is an unconditional sufficient condition.

### Proof

Choose `t_0 in [a,b]` with
\[
\psi(t_0)=\frac{\psi(a)+\psi(b)}2,
\]
which exists by continuity.

For the three rows in `I`, choose integers `k_I` nearest to
\[
\frac1\pi\bigl(L(F_{H_0})_I(0)+M_L(F_{H_1})_I(0,t_0)\bigr).
\]
After `k_I` is fixed, choose the remaining integer `k_ell` so that
\[
\boxed{
\left|\lambda\cdot\bigl(LF_{H_0}(0)+M_LF_{H_1}(0,t_0)-\pi k\bigr)\right|\le\frac\pi2.
}
\]
This is possible because changing `k_ell` by one changes the displayed scalar by exactly `pi lambda_ell=pi`.

Put
\[
y=v/L.
\]
On a transverse sphere `|v|=C M_L`, Taylor expansion gives
\[
L\bigl((F_{H_0})_I(v/L)-(F_{H_0})_I(0)\bigr)
=A v+O(M_L^2/L).
\]
Uniform continuity of `H_1` gives an `o(M_L)` correction from moving `y=v/L`, while the variation of `M_LF_{H_1}(0,t)` over the compact `t` interval is `O(M_L)`. The evaluated error is `o(M_L)`. Choosing `C` large compared with `\|A^{-1}\|` makes the first three transformed residuals nonzero on the entire transverse boundary.

For the fourth transformed coordinate use the cokernel projection. Since
\[
\lambda^T D_yF_{H_0}(0)=0,
\]
the leading leakage is quadratic:
\[
\lambda\cdot L\bigl(F_{H_0}(v/L)-F_{H_0}(0)\bigr)
=O(M_L^2/L)=o(M_L).
\]
Likewise the transverse change in the subleading term is `o(M_L)`, and the error contributes `o(M_L)`. Hence on the two symmetry faces
\[
\lambda\cdot\bigl(F_{\Phi_L}(v/L,t)-\pi k\bigr)
=c_L+M_L\bigl(\psi(t)-\psi(t_0)\bigr)+o(M_L),
\]
where `|c_L|<=pi/2`.

At `t=a,b`, the main terms are
\[
c_L\mp\frac{M_L\Delta\psi}{2}+o(M_L).
\]
They have opposite signs under either hypothesis of the theorem.

Apply the invertible target change
\[
R\longmapsto (R_I,\lambda\cdot R).
\]
On the boundary of the four-dimensional cylinder
\[
|v|\le C M_L,
\qquad a\le t\le b,
\]
zeros are excluded: the first three coordinates exclude them on the transverse wall, and the cokernel coordinate excludes them on the two `t` faces.

Homotope the interior map, without creating a boundary zero, to the block map
\[
(v,t)\longmapsto
\bigl(A v,\ c_L+M_L(\psi(t)-\psi(t_0))\bigr).
\]
The first block has degree `sign det A`; the one-dimensional second block has nonzero degree because its endpoint signs are opposite. Therefore the full Brouwer degree is nonzero, so the original map has a zero.

At that zero all four vertex phases are in `pi Z`. The cylinder radius gives
\[
|y_L|=O(M_L/L).
\]
`\square`

---

## 5. What the theorem says geometrically

The leading similarity-symmetric phase gives only three independent phase controls. Its symmetry motion is an exact kernel direction.

The subleading phase is not required to restore a full `4 x 4` Jacobian pointwise. It only has to accumulate a nonzero component in the one-dimensional **left cokernel** while the square moves along the symmetry orbit. This is weaker and is stable under arbitrarily oscillatory `o(M_L)` errors.

For `M_L -> infinity`, any fixed nonzero endpoint difference of the reduced phase is enough. For an `O(1)` subleading phase, a sweep exceeding `pi` is a simple arithmetic-free condition that works for every large `L`.

---

## 6. A necessary diagnostic: common-mode motion may do nothing

Suppose along the symmetry orbit
\[
H_1(g_t z)=H_1(z)+c t.
\]
Then
\[
F_{H_1}(0,t)=F_{H_1}(0,0)+ct\,\mathbf 1,
\]
so
\[
\boxed{\psi'(t)=c\,\lambda\cdot\mathbf 1.}
\]
Therefore a conjugate symmetry coordinate restores the missing direction only if
\[
\boxed{\lambda\cdot\mathbf 1\ne0.}
\]
If `lambda dot 1=0`, the common phase drift is already contained in the leading transverse image. The nominal symmetry-breaking term has merely moved the phase into another rank-three family.

The simplest example is
\[
H_0=x,
\qquad H_1=y.
\]
Then `L H_0+M H_1=Lx+My` is still a linear phase with parallel level lines. No mixed-scale theorem should call it generic, and indeed the cokernel test gives `lambda dot 1=0`.

By contrast, for nonlinear ridge laws such as `H_0=x^2/2` at a generic off-axis square, `lambda dot 1` is generally nonzero, so a transverse `H_1=y` produces a genuine cokernel drift.

---

## 7. Consequence for the v190 exceptional families

### Parallel family
Write locally
\[
H_0=f(q),\qquad q=n\cdot z,
\]
with symmetry translation in the perpendicular direction. Any subleading phase whose four-vertex evaluation has nonzero cokernel drift along that translation is square-forcing by Theorem 4.1.

### Similarity-spiral family
Write
\[
q=\beta\log|z-z_0|-\alpha\arg(z-z_0),
\qquad
H_0=f(q),
\]
with symmetry flow
\[
\dot z=(\alpha+i\beta)(z-z_0).
\]
A convenient conjugate coordinate is
\[
p=\alpha\log|z-z_0|+\beta\arg(z-z_0),
\]
for which
\[
\frac{dp}{dt}=\alpha^2+\beta^2.
\]
A subleading term containing `p` gives common phase drift along the symmetry orbit. It closes the branch whenever its cokernel projection is nonzero; if that projection vanishes, the term is algebraically absorbed and one must inspect a genuinely vertex-dependent subleading component.

The v187 radial/angular mechanism is one member of this general pattern.

---

## 8. What remains after v191

Within the coherent scalar-phase branch, the remaining obstruction is now narrower:

1. leading rank four: closed by v190;
2. leading rank three plus nontrivial cokernel sweep: closed by this theorem;
3. leading rank three with every available subleading term cokernel-flat: a higher-order similarity-degenerate branch;
4. no coherent scalar metric phase extractable from the v189 topological lamination: still the main general-Jordan gap.

The fourth item remains the deepest issue. The accompanying conformal-Fourier note proposes a route that does not assume scalar-phase extraction at all.
