# Status corrections v191

- v191 does not prove the Toeplitz conjecture.
- The mixed-scale theorem closes only rank-three coherent phases whose subleading evaluation has nonzero cokernel sweep along the leading symmetry orbit.
- A common-mode subleading drift can be ineffective when `lambda dot 1 = 0`; such a term can leave the total phase inside a similarity-degenerate family.
- The conformal-Fourier construction is a reformulation/research direction, not a proof. Its unresolved issue is control of zeros escaping to the compactification (colliding boundary parameters / boundary-going disk automorphisms).
- Ordinary Fourier coefficients of an arbitrary Jordan parameterization are not canonical. The proposed spectrum uses a Riemann-map boundary parameterization and disk automorphisms.
- Equal conformal quarter-spacing is only a restricted one-parameter quartet family. Full coverage requires the three disk-automorphism parameters plus one cross-ratio parameter, and the relevant order chambers.
