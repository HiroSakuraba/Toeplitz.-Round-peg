# v192 — compactification picture and next targets

## 1. The escape tree has simplified

Before v192, the conformal-Fourier route had an undifferentiated warning: zeros of the four-point transform might disappear into the compactification.

For exact square zeros on Abel curves `f(rS^1)`, the first boundary behavior is now much more specific.

If no boundary square survives, all four parameters first collide at one boundary point. The universal angular-floor theorem removes collisions below the Abel depth `1-r`.

Therefore every bad sequence has a subsequence of one of two types:

### Type B — balanced
\[
\delta\asymp1-r.
\]
The first Möbius blow-up resolves all four vertices as distinct points on the fixed horocycle. A normalized univalent tangent contains a square there. This event is detectable in finitely many low coefficients.

### Type R — runaway
\[
\delta\gg1-r.
\]
At least part of the quartet escapes toward the horocycle tangency point. A second blow-up is required.

There is no Type U with `delta=o(1-r)`.

## 2. Runaway subtypes

Use the half-plane coordinate
\[
X=G(u)=\frac{u}{1+u}.
\]
On the limiting horocycle, `X=is`.

Then runaway means at least one `|X_j|->infinity`.

There are three qualitatively different second-stage patterns.

### R1. Interior cross-ratio, all-four secondary cluster

All four `|X_j|` diverge at comparable rates and their affine-normalized real positions have four distinct limits. The first blow-up sees a total collision at `u=-1`; the second resolves a four-point configuration with interior cross-ratio.

The explicit Möbius calibration `M_c` realizes exactly this geometry as `c->1`.

### R2. Degenerate cross-ratio

Some pair or triple separation is parametrically smaller than the total `X` span. The second-stage cross-ratio approaches an endpoint. A deeper Fulton–MacPherson tree is required.

### R3. Mixed finite/runaway

One or more first-stage points stay at finite `X`, while others run to infinity. This is a genuine boundary stratum of the normalized transform and cannot yet be excluded from univalent compactness alone.

## 3. The next theorem should be recursive, not global

The right v193 target is not “classify all possible tangent domains.” That is too broad.

The useful target is an **iterated square-resolution lemma**:

> At each runaway node, normalize the escaping subset by a second Möbius/affine coordinate. Either the square equations become compact and produce a finite low-mode spectral defect at that level, or another proper subcluster runs away.

Since there are only four vertices, the combinatorial depth of a pure vertex-collision tree is finite. What can still be unbounded is the **metric scale separation** between levels.

So the key analytic quantity is the cost of one scale jump.

## 4. Candidate costs for a scale jump

Three quantities deserve priority.

### A. Schwarzian activity

The exact identity
\[
b_3-b_2^2=\frac{(1-|a|^2)^2}{6}S_f(a)
\]
makes the Schwarzian the cleanest local spectral curvature observable.

Question:

> Does a runaway jump by a factor `R` force a definite integral of `|S_f|` along the associated hyperbolic corridor?

If yes, repeated jumps may violate a global or local integrability budget available for bounded Jordan maps.

### B. Extremal length / modulus

A deep nested lobe packet from v189 resembles a stack of channels. In conformal coordinates, repeated resolution scales should correspond to annuli or quadrilaterals with large modulus.

Question:

> Can the `N~r^-2` nested lobes be converted into `N` essentially disjoint modulus contributions, while a runaway tree supplies only logarithmically many scale decades?

This is currently the most plausible bridge from v189 topology to conformal analysis.

### C. Harmonic measure compression

The boundary parameter is harmonic measure seen from `f(0)`. A physical packet of tiny diameter carrying a large amount of combinatorial layering may require extreme compression of harmonic measure.

Question:

> Can the v189 lobe multiplicity force either a balanced tangent defect or a harmonic-measure ratio so extreme that it creates a controlled second-stage tangent?

This may be more robust than trying to construct a scalar phase directly.

## 5. A concrete v193 computational experiment

For a library of exact or high-accuracy conformal maps:

1. choose `r` values approaching `1` geometrically;
2. locate all numerically stable inscribed squares on `f(rS^1)`;
3. track branches in `r` rather than solving independently at each radius;
4. for every shrinking branch record
   \[
   \delta/(1-r),\quad \tau,\quad b_2,\quad b_3-b_2^2,\quad b_4,b_5;
   \]
5. when `delta/(1-r)` exceeds a threshold, perform the second half-plane normalization and record the secondary cross-ratio;
6. compare the resulting escape trees against warped-rainbow and zipper examples modeled on v189.

The experiment should specifically seek **counterexamples to the hoped-for spectral simplification**. If arbitrary warped Jordan examples fill a high-dimensional coefficient region, the route is weak. If escape events cluster on a few low-dimensional strata, those strata become theorem targets.

## 6. Current proof architecture after v192

\[
\text{arbitrary Jordan curve}
\]
\[
\Downarrow\quad\text{Riemann map + Abel curves}
\]
\[
\text{square on every analytic }f(rS^1)
\]
\[
\Downarrow
\]
\[
\begin{cases}
\text{compact square branch}&\Rightarrow\text{boundary square},\\
\text{collapsing branch}&\Rightarrow\delta\ge(1-r)/100.
\end{cases}
\]
\[
\Downarrow
\]
\[
\begin{cases}
\delta=O(1-r)&\Rightarrow\text{balanced tangent + finite spectral defect},\\
\delta/(1-r)\to\infty&\Rightarrow\text{iterated runaway tree}.
\end{cases}
\]

The spectral route has therefore reduced its vague “compactification problem” to one explicit branch:

\[
\boxed{\text{iterated runaway in conformal scale}.}
\]

That is the branch v193 should attack.
