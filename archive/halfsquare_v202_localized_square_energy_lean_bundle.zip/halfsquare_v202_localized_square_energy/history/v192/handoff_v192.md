# Handoff v192 — Möbius–Fourier escape compactification

## Executive result

The conformal-Fourier route now has a genuine reduction theorem rather than a generic compactification warning.

Let `f:D->Omega` be the Riemann map of a Jordan domain and let `Gamma_r=f(rS^1)`. If squares on `Gamma_r` fail to converge to a boundary square, all four parameters collapse to one boundary point. Their conformal angular diameter `delta` cannot be smaller than a fixed multiple of the Abel depth:
\[
\boxed{\delta>(1-r)/100.}
\]
This follows from the universal pre-Schwarzian bound `||(1-|z|^2)f''/f'||<=6`: on a shorter arc the map is uniformly close to an affine map, so the four images lie in a tube too thin to be a square.

Hence every bad sequence has only two regimes.

### Balanced
\[
\delta/(1-r)=O(1).
\]
After the disk automorphism sending the radial point to `0`, the preimages converge to four distinct points of the horocycle
\[
H:|z+1/2|=1/2,
\qquad U(s)=is/(1-is).
\]
The normalized maps
\[
F_r(z)=[f(phi_r(z))-f(r)]/[(1-r^2)f'(r)]
\]
converge subsequentially in the normalized univalent class, and the limit `F_infty` maps those four horocycle points to an exact square.

The regular tangent
\[
G(z)=z/(1+z)
\]
obeys `G(U(s))=is`, so regular boundary points cannot support balanced collapse.

Moreover, for every fixed balance window there is a finite low-mode obstruction: writing
\[
F(z)=z+sum_{n>=2}b_nz^n,
\qquad d_n=b_n-(-1)^{n-1},
\]
there exist finite `N_C` and positive `kappa_C` such that every square-producing balanced tangent satisfies
\[
sum_{n=2}^{N_C}|d_n|rho_C^n>=kappa_C.
\]
This uses compactness of the normalized univalent class plus de Branges' `|b_n|<=n` tail bound.

### Runaway
\[
\boxed{\delta/(1-r)->infinity.}
\]
Then the first blow-up does not resolve the configuration compactly; one or more points run toward the horocycle tangency point `-1`. A second Möbius/half-plane blow-up is necessary. This is now the only spectral compactification branch left.

## Exact spectral coordinates

For
\[
C_af(z)=[f(phi_a(z))-f(a)]/[(1-|a|^2)f'(a)]
=z+b_2z^2+b_3z^3+...,
\]
with `P=f''/f'` and Schwarzian `S_f`,
\[
\boxed{b_2=-bar(a)+(1-|a|^2)P(a)/2,}
\]
\[
\boxed{b_3-b_2^2=(1-|a|^2)^2S_f(a)/6.}
\]
Thus the first two nonlinear local Fourier coefficients are exactly the scaled pre-Schwarzian and Schwarzian.

Power-law calibration `f_alpha=1-(1-z)^alpha` gives
\[
b_2=-alpha,
\qquad b_3=(1+2alpha^2)/3.
\]

## Sharp limitation / calibration

The normalized Möbius family
\[
M_c(z)=z/(1+cz),\quad 0<=c<1,
\]
maps the limiting horocycle to a circle and contains exact squares. For an explicit square,
\[
max|s_j|=(1+sqrt2)/(1-c),
\]
while the first spectral defect is
\[
|b_2+1|=1-c.
\]
Therefore
\[
\boxed{|b_2+1| max|s_j|=1+sqrt2.}
\]
This shows why the balanced finite-mode theorem cannot be promoted to a global coefficient-only exclusion: a tangent can approach the regular spectrum while its square escapes to the next scale.

## Best next target (v193)

Build an **iterated runaway theorem**.

At each escaping node:

1. use the half-plane coordinate `X=u/(1+u)`;
2. isolate the subset with `|X|->infinity`;
3. affine/Möbius normalize that subset;
4. either obtain a compact square-producing tangent with a finite low-mode defect at that level, or pass to a proper deeper subcluster;
5. assign a quantitative cost to the scale jump.

The best candidate costs are:

- hyperbolically scaled Schwarzian activity;
- extremal length/modulus;
- harmonic-measure compression.

Then compare total escape-tree cost with v189's forced packet geometry:
\[
N\gtrsim r^{-2},
\qquad
\min gap=O(r^3).
\]

The objective is no longer to extract a smooth scalar phase from the whole lamination. It is to prove that the amount of conformal scale hierarchy required to hide all square zeros is incompatible with the amount of nested topology v189 forces.

## Verification

`code/verify_v192.py` checks:

- four-point DFT square identities;
- canonical cross-ratio formula;
- disk-automorphism inversion;
- horocycle scaling limit;
- regular tangent straightening;
- power-law tangent formulas;
- `b_2/b_3/Schwarzian` identities;
- the ultralocal constant margin;
- the exact Möbius escape-square law;
- finite spectral tail bounds.

Result: **324/324 checks pass**.
