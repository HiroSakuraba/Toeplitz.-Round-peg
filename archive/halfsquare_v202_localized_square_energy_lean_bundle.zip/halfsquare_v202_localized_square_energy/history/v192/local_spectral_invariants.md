# v192 technical note — local spectral invariants and tangent calibrations

## 1. The local conformal spectrum

For a Riemann map `f` and `a in D`, define
\[
\phi_a(z)=\frac{a+z}{1+\bar a z},
\qquad A=1-|a|^2,
\]
\[
\mathcal C_af(z)
=\frac{f(\phi_a(z))-f(a)}{A f'(a)}
=z+b_2z^2+b_3z^3+\cdots.
\]

This is the Möbius-localized Fourier/Taylor fingerprint proposed in v191.

The first two nonlinear coefficients have exact differential meaning.

## 2. Coefficient calculation

The automorphism expands as
\[
\phi_a(z)
=a+A z-\bar a A z^2+\bar a^2A z^3+O(z^4).
\]
Writing `P=f''/f'` and `Q=f'''/f'`, Taylor expansion gives
\[
b_2=-\bar a+\frac A2P(a),
\]
\[
b_3=\bar a^2-\bar a A P(a)+\frac{A^2}{6}Q(a).
\]
Since
\[
S_f=P'-\frac12P^2
=Q-\frac32P^2,
\]
one obtains
\[
\boxed{b_3-b_2^2=\frac{A^2}{6}S_f(a).}
\]

Thus define the first two defect coordinates
\[
\boxed{D_2(a):=b_2(a)+\bar a=\frac A2P_f(a),}
\]
\[
\boxed{D_3(a):=b_3(a)-b_2(a)^2=\frac{A^2}{6}S_f(a).}
\]

`D_2` measures hyperbolic pre-Schwarzian activity; `D_3` measures hyperbolic Schwarzian activity.

## 3. Regular tangent baseline

For the identity map,
\[
\mathcal C_a \operatorname{id}(z)
=\frac{z}{1+\bar a z}
=z-\bar a z^2+\bar a^2z^3-\cdots.
\]
As `a->xi in S^1`, the regular tangent spectrum is
\[
\boxed{b_n^{reg}=(-\bar\xi)^{n-1}.}
\]
At `xi=1`,
\[
G(z)=\frac{z}{1+z}
=z-z^2+z^3-z^4+\cdots.
\]
A conformally smooth boundary point approaches this spectrum.

## 4. Power-law boundary tangent

For
\[
f_\alpha(z)=1-(1-z)^\alpha,
\]
radial blow-up at `1` gives
\[
F_\alpha(z)=
\frac{1-
\left(\frac{1-z}{1+z}\right)^\alpha}{2\alpha}.
\]
The coefficient pair is
\[
(b_2,b_3)
=
\left(-\alpha,\frac{1+2\alpha^2}{3}\right).
\]
Hence
\[
D_2=1-\alpha,
\qquad
D_3=\frac{1-\alpha^2}{3}.
\]
The exponent is already visible in `b_2`.

This is useful computationally: if an observed escape spectrum clusters near a power-law tangent, `alpha approx -b_2` is the first estimator, while `b_3-b_2^2` supplies a consistency check.

## 5. Möbius tangent locus

For
\[
M_c(z)=\frac{z}{1+cz},
\]
\[
b_n=(-c)^{n-1}
\]
and
\[
\boxed{b_3-b_2^2=0.}
\]
Thus the Möbius tangents lie on the zero-Schwarzian algebraic locus
\[
D_3=0.
\]

The regular tangent at `xi=1` is the endpoint `c=1`.

This gives a simple first spectral classification plane:

- near `D_2=0,D_3=0`: conformally regular;
- `D_2 != 0,D_3 approx 0`: Möbius-like singular tangent candidate;
- power-law relation `D_3=(1-\alpha^2)/3` with `alpha=1-D_2`: corner/power tangent;
- neither relation: genuinely higher-order tangent geometry.

## 6. Four-point Fourier response in coefficient form

For a quartet `u_j` and
\[
F(z)=\sum_{n\ge1}b_nz^n,
\]
the square-error modes are
\[
\widehat Z_k
=\sum_{n\ge1}b_n M_{n,k}(u),
\]
where
\[
M_{n,k}(u)
=\frac14\sum_{j=0}^3u_j^n i^{-kj}.
\]
A positive-order square satisfies
\[
\sum_n b_nM_{n,2}=0,
\qquad
\sum_n b_nM_{n,3}=0.
\]

This is a linear functional of the infinite coefficient vector `b=(b_1,b_2,...)` once the preimage quartet is fixed.

In a balanced escape window `|u_j|<=rho<1`, high modes are exponentially suppressed by `rho^n`. This is the mechanism behind the finite-mode theorem in `mobius_fourier_escape_theorem.md`.

## 7. Recommended numerical feature vector

For each candidate shrinking-square event, record
\[
\boxed{
(\delta/(1-r),\;b_2,\;b_3-b_2^2,\;b_4,\;b_5,\;\tau)
}
\]
where `tau` is the four-preimage cross-ratio.

This separates six effects:

1. balance versus runaway scale;
2. pre-Schwarzian activity;
3. Schwarzian activity;
4. first genuinely higher-order spectral terms;
5. cross-ratio degeneration;
6. approach to the regular tangent.

The most informative empirical question is no longer “does a numerical square exist?” It is:

> As square branches shrink, which low-dimensional spectral strata do their tangent maps approach, and does `delta/(1-r)` remain bounded or run away?
