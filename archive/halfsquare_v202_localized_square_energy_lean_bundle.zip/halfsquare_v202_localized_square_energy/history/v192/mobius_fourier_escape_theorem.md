# v192 — Möbius–Fourier escape theorem for Abel squares

## 1. Setup

Let `Gamma` be a Jordan curve, `Omega` its bounded Jordan domain, and
\[
f:\mathbb D\to\Omega
\]
a Riemann map. By the Osgood–Carathéodory theorem, `f` extends to a homeomorphism of the closed disk.

For `0<r<1`, define the analytic Jordan curve
\[
\Gamma_r=f(rS^1).
\]
For each `r`, smooth square-peg results supply at least one inscribed square on `Gamma_r`. The classical approximation obstruction is that every such square may shrink as `r\uparrow1`.

This note puts that degeneration into conformal blow-up coordinates and proves that one entire collision regime is impossible.

---

## 2. First compactness reduction: only the total diagonal matters

Take `r_n\uparrow1` and square vertices
\[
Z_{j,n}=f(r_n\zeta_{j,n}),\qquad \zeta_{j,n}\in S^1,
\]
listed in one geometric square order.

### Proposition 2.1 — compact zero versus total collapse

After passing to a subsequence, exactly one of the following occurs.

1. The square side lengths stay bounded below. Then the boundary curve `Gamma` contains a nondegenerate square.
2. The side lengths tend to zero. Then all four boundary parameters converge to one and the same point
   \[
   \zeta_{0,n},\ldots,\zeta_{3,n}\to\xi\in S^1.
   \]

### Proof

The maps `f(r\cdot)` converge uniformly on `S^1` to the boundary homeomorphism `f|_{S^1}`. If the square side has a positive subsequential limit, compactness of `(S^1)^4` gives four limiting boundary parameters whose images form a nondegenerate square.

Otherwise the square diameter tends to zero. Any subsequential limits `\zeta_j^*` satisfy
\[
f(\zeta_0^*)=\cdots=f(\zeta_3^*).
\]
Boundary injectivity forces all four `\zeta_j^*` to coincide. ∎

**Consequence.** For an exact square branch, pair-only or triple-only collision strata cannot appear as the first unrenormalized limit. The first ordinary compactification boundary is the **total diagonal**. Fulton–MacPherson subcollision data only enters after that total collision is blown up.

---

## 3. A universal lower scale: squares cannot be ultralocal

Let `delta` be the length in radians of the shortest boundary-parameter arc containing the four preimages of a square on `Gamma_r`.

### Theorem 3.1 — conformal angular floor

For every univalent `f` and every `r>=1/2`, an inscribed square on `f(rS^1)` satisfies
\[
\boxed{\delta>\frac{1-r}{100}.}
\]

The constant `1/100` is deliberately crude; the point is the scale law.

### Proof

Assume the four parameters lie in
\[
\theta\le t\le\theta+\delta,
\qquad
\delta\le\frac{1-r}{100}.
\]
Set
\[
h(t)=f(re^{it}).
\]
Writing `P_f=f''/f'`,
\[
\frac{d}{dt}\log h'(t)=i+i\,re^{it}P_f(re^{it}).
\]
For a univalent function on the disk, the universal pre-Schwarzian estimate is
\[
(1-|z|^2)|P_f(z)|\le6.
\]
Let `epsilon=1-r`. Since `r>=1/2`,
\[
\left|\frac{d}{dt}\log h'(t)\right|
\le1+\frac{6r}{1-r^2}
\le1+\frac3\epsilon.
\]
Across an interval of length `delta<=epsilon/100`, the logarithmic derivative changes by at most
\[
L\le \frac\epsilon{100}+\frac3{100}\le0.035.
\]
Hence
\[
\left|\frac{h'(t)}{h'(\theta)}-1\right|
\le e^{0.035}-1=:\eta<0.036.
\]
Integrating, every one of the four image points lies within
\[
\eta |h'(\theta)|\delta
\]
of the affine tangent line
\[
h(\theta)+h'(\theta)\mathbb R.
\]
The two extreme parameter values are separated in the image by at least
\[
(1-\eta)|h'(\theta)|\delta.
\]
If the four image points formed a square of side `s`, its diameter is `s\sqrt2`, so
\[
s\ge\frac{(1-\eta)|h'(\theta)|\delta}{\sqrt2}.
\]
But for every line, at least one vertex of a square of side `s` is at distance at least `s/2` from that line. Therefore a square would require
\[
\eta\ge\frac{1-\eta}{2\sqrt2}.
\]
The right-hand threshold is equivalent to
\[
\eta\ge\frac1{1+2\sqrt2}\approx0.2612,
\]
contradicting `eta<0.036`. ∎

### Interpretation

The Abel smoothing depth `1-r` is a genuine spectral resolution scale. A square cannot hide on a conformal angular scale asymptotically smaller than that depth.

Thus any collapsing square branch has only two asymptotic regimes:

\[
\boxed{
\frac{\delta_n}{1-r_n}=O(1)
\quad\text{or}\quad
\frac{\delta_n}{1-r_n}\to\infty.
}
\]

There is no `o(1-r_n)` regime.

---

## 4. Exact first blow-up coordinates

After rotation, suppose the common collision point is `1`. Put
\[
\phi_r(z)=\frac{r+z}{1+rz},
\qquad
\phi_r(0)=r.
\]
The inverse image of a point `w=re^{it}` on the Abel circle is
\[
\boxed{
u_r(t)=\phi_r^{-1}(re^{it})
=\frac{re^{it}-r}{1-r^2e^{it}}.}
\]
Let
\[
d_r=1-r^2.
\]
If
\[
t=d_rs
\]
with `s` bounded, then
\[
\boxed{
u_r(d_rs)\longrightarrow U(s):=\frac{is}{1-is}.}
\]
The limiting points satisfy
\[
\boxed{|U(s)+1/2|=1/2.}
\]
So a microscopic arc of the Abel circle becomes the fixed horocycle
\[
\mathcal H=\{z:|z+1/2|=1/2\},
\]
tangent to `S^1` at `-1`.

The associated half-plane coordinate is
\[
G(z)=\frac{z}{1+z}.
\]
On the horocycle,
\[
\boxed{G(U(s))=is.}
\]
Thus `s` is literally the vertical coordinate on the straightened horocycle.

There is also an exact finite-`r` formula:
\[
G(\nu_r(t))
=\frac{r(e^{it}-1)}{(1-r)(1+re^{it})}.
\]
Its size measures angular separation divided by Abel depth.

---

## 5. Normalized univalent tangent maps

Define
\[
F_r(z)
=\frac{f(\phi_r(z))-f(r)}{(1-r^2)f'(r)}.
\]
Then
\[
F_r(0)=0,
\qquad
F_r'(0)=1,
\]
and every `F_r` is univalent on `D`. The normalized schlicht class is compact for locally uniform convergence, so along a subsequence
\[
F_{r_n}\to F_\infty
\]
on compact subsets of the disk.

An affine similarity was used in the normalization, hence an exact square remains an exact square.

### Theorem 5.1 — balanced escape produces a horocycle square tangent

Suppose a collapsing square sequence satisfies
\[
0<c\le\frac{\delta_n}{1-r_n}\le C<\infty.
\]
Then, after passing to a subsequence, there exist four distinct finite numbers
\[
s_0<s_1<s_2<s_3
\]
and a normalized univalent limit `F_infty` such that
\[
\boxed{
F_\infty(U(s_0)),\ldots,F_\infty(U(s_3))
}
\]
are the vertices of a nondegenerate square.

### Proof sketch

Center the minimal parameter interval and write
\[
t_{j,n}=d_{r_n}s_{j,n}.
\]
The upper bound makes all `s_{j,n}` bounded. Theorem 3.1 gives a positive lower bound on their total span. Therefore the points
\[
u_{j,n}=\nu_{r_n}(t_{j,n})
\]
stay in a fixed compact subset of the disk and at least two remain separated.

Pass to subsequences `s_{j,n}->s_j` and `F_{r_n}->F_infty`. Local uniform convergence transfers the square equations to the limit. If two limiting `s_j` coincided, one square side would tend to zero, hence all square sides would; univalence of `F_infty` would then force all four limiting preimages to coincide, contradicting the positive total span. Thus all four are distinct and the limit square is nondegenerate. ∎

### Corollary 5.2 — balanced escape has no nested cross-ratio collision

In the balanced regime, the first blow-up resolves all four points as distinct points of the horocycle. Equivalently, the cross-ratio remains in the interior of the one-dimensional four-point moduli interval after this blow-up.

Nested Fulton–MacPherson collision trees are therefore needed only in the runaway regime.

---

## 6. Regular boundary points are excluded from balanced escape

The identity
\[
\phi_r(z)-r=(1-r^2)\frac{z}{1+rz}
\]
shows that if `f` is conformally differentiable at the boundary point with a finite nonzero limiting derivative, then
\[
F_r(z)\longrightarrow
\boxed{G(z)=\frac{z}{1+z}}
\]
locally uniformly.

But
\[
G(U(s))=is,
\]
so the entire limiting horocycle is sent to a straight line. Four distinct collinear points cannot form a square.

### Corollary 6.1

A balanced collapsing square cannot concentrate at a conformally regular boundary point. It requires genuinely singular boundary-scale behavior of the Riemann map.

This is stronger than saying merely that the square shrinks: the collapse must be accompanied by a nontrivial conformal tangent.

---

## 7. The first local Fourier coefficients are classical conformal invariants

For arbitrary `a in D`, let
\[
\phi_a(z)=\frac{a+z}{1+\bar a z},
\qquad
A=1-|a|^2,
\]
and define
\[
\mathcal C_af(z)
=\frac{f(\phi_a(z))-f(a)}{A f'(a)}
=z+b_2(a)z^2+b_3(a)z^3+\cdots.
\]
Let
\[
P_f=\frac{f''}{f'},
\qquad
S_f=P_f'-\frac12P_f^2
\]
be the pre-Schwarzian and Schwarzian derivatives.

Direct Taylor expansion gives
\[
\boxed{
b_2(a)
=-\bar a+\frac{A}{2}P_f(a).
}
\]
The next coefficient is
\[
\boxed{
b_3(a)
=\bar a^2-\bar a A P_f(a)
+\frac{A^2}{6}\frac{f'''(a)}{f'(a)}.
}
\]
The cancellation in the combination `b_3-b_2^2` is exact:
\[
\boxed{
b_3(a)-b_2(a)^2
=\frac{A^2}{6}S_f(a).
}
\]

So the beginning of the local conformal Fourier spectrum is not arbitrary:

- `b_2+bar(a)` is exactly the hyperbolically scaled pre-Schwarzian;
- `b_3-b_2^2` is exactly the hyperbolically scaled Schwarzian.

The universal bounds for univalent functions immediately give
\[
|A P_f(a)|\le6,
\qquad
|A^2S_f(a)|\le6,
\]
so
\[
|b_3-b_2^2|\le1.
\]

This supplies concrete low-dimensional coordinates for the proposed spectral escape classification.

---

## 8. A power-law tangent calibration

Consider the local univalent model
\[
f_\alpha(z)=1-(1-z)^\alpha,
\qquad 0<\alpha<2.
\]
Its normalized boundary blow-up is
\[
\boxed{
F_\alpha(z)
=\frac{1-
\left(\frac{1-z}{1+z}\right)^\alpha}{2\alpha}.
}
\]
At `alpha=1`, this is the regular tangent `G(z)=z/(1+z)`.

Its first coefficients are
\[
\boxed{b_2=-\alpha,}
\]
\[
\boxed{b_3=\frac{1+2\alpha^2}{3},}
\]
and hence
\[
\boxed{
b_3-b_2^2=\frac{1-\alpha^2}{3}.}
\]

Thus the local spectrum detects the corner/power exponent directly. The regular case `alpha=1` is the point
\[
(b_2,b_3)=(-1,1).
\]

---

## 9. Finite spectral detectability of every balanced escape

Let
\[
G(z)=\frac{z}{1+z}
=z-z^2+z^3-z^4+\cdots
\]
be the regular tangent.

Write a normalized tangent map as
\[
F(z)=z+\sum_{n\ge2}b_nz^n,
\]
and define its regular-spectrum defect
\[
d_n=b_n-(-1)^{n-1}.
\]

### Theorem 9.1 — bounded-window escape has a finite low-mode signature

Fix an upper balance constant `C`. There exist
\[
\rho_C<1,
\qquad
N_C<\infty,
\qquad
\kappa_C>0
\]
with the following property.

If a normalized univalent tangent `F` maps an admissible horocycle quartet arising from a balanced collapse with
\[
\delta/(1-r)\le C
\]
to an exact nondegenerate square, then
\[
\boxed{
\sum_{n=2}^{N_C}|d_n|\rho_C^n\ge\kappa_C.
}
\]
In particular, at least one of finitely many low Fourier coefficients stays a definite distance from its regular value.

### Proof

The balance bound places all four horocycle parameters `s_j` in a fixed compact interval. Theorem 3.1 places a fixed positive lower bound on their total span. The normalized schlicht class is compact.

Consider the closed set of pairs `(F,Q)` for which `Q` is such an admissible quartet and `F(Q)` is a square. The square side length has a positive minimum on this compact set: otherwise a limiting square would collapse, and univalence would force all four preimages to coincide, contradicting the span lower bound.

The regular map `G` sends every admissible quartet to one line. Therefore every square-producing `F` must differ from `G` by at least some `eta_C>0` at one of the four vertices. All vertices lie in `|z|<=rho_C<1`, hence
\[
\sum_{n\ge2}|d_n|\rho_C^n\ge\eta_C.
\]
By de Branges' coefficient theorem, `|b_n|<=n`, so
\[
|d_n|\le n+1.
\]
The tail
\[
\sum_{n>N}(n+1)\rho_C^n
\]
tends to zero. Choose `N_C` so the tail is less than `eta_C/2`. Then the first `N_C` modes carry at least `eta_C/2`; take `kappa_C=eta_C/2`. ∎

### Meaning

A balanced collapse cannot be an arbitrarily high-frequency phenomenon. **Some finite set of low conformal Fourier modes must announce it.**

This is the first rigorous version of the “finite spectral obstruction” proposed in v191.

---

## 10. Why the runaway branch is real: an exact Möbius model

Normalized univalence by itself cannot eliminate horocycle squares.

For `0<=c<1`, define
\[
M_c(z)=\frac{z}{1+cz}.
\]
This is normalized and univalent. Put
\[
d=1-c.
\]
On the limiting horocycle,
\[
\boxed{
M_c(U(s))=\frac1d U(ds).
}
\]
Therefore `M_c(H)` is a circle of radius `1/(2d)` and contains exact squares.

Choose
\[
\varphi_j=-\frac{3\pi}{4}+\frac{j\pi}{2},
\qquad
s_j=\frac1d\tan\frac{\varphi_j}{2}.
\]
Then `s_0<s_1<s_2<s_3`, and the four points `M_c(U(s_j))` are an exact square.

The largest parameter is
\[
\boxed{
\max_j|s_j|=\frac{1+\sqrt2}{1-c}.
}
\]
Meanwhile
\[
M_c(z)=z-cz^2+c^2z^3-\cdots,
\]
so its first defect from the regular tangent is
\[
\boxed{|b_2-(-1)|=1-c.}
\]
Consequently
\[
\boxed{
|b_2+1|\;\max_j|s_j|=1+\sqrt2.
}
\]

This is an exact spectral-position tradeoff:

- as the spectrum approaches the regular tangent (`c->1`),
- the square is forced farther and farther out along the horocycle (`|s|->infinity`).

So Theorem 9.1 is essentially sharp in structure. Low spectral defect can disappear only by leaving every fixed balanced window.

This model is **not** a Toeplitz counterexample. It is a tangent-space calibration showing what a surviving escape mechanism would have to resemble.

---

## 11. The remaining spectral branch

Combining the preceding results, a no-boundary-square scenario must generate one of the following.

### Balanced branch

\[
\frac{\delta_n}{1-r_n}=O(1).
\]
Then a normalized tangent map contains a square on a compact horocycle window, and finitely many low coefficients differ definitely from the regular spectrum.

This branch is now a finite-dimensional spectral target.

### Runaway branch

\[
\boxed{
\frac{\delta_n}{1-r_n}\to\infty.
}
\]
Then one or more first-blow-up coordinates escape toward the horocycle tangency point `-1`, equivalently `|G(u)|->infinity`.

This is the true compactification boundary left by v192. It includes:

- one secondary all-four collision with interior cross-ratio;
- pair/triple hierarchical subcollisions when the cross-ratio also degenerates;
- mixtures in which some first-stage points remain finite while others run to the repelling point.

These are naturally encoded by Fulton–MacPherson collision trees or, equivalently here, by iterated Möbius/half-plane blow-ups.

---

## 12. Connection to v189

v189 forces a no-square Jordan curve, inside the primitive-concentration packets, to create
\[
N\gtrsim r^{-2}
\]
nested same-sign lobes and `O(r^3)` transverse gaps.

v192 does **not** yet prove a theorem converting those physical layers into coefficient restrictions. What it does is identify where such a conversion should be sought.

A no-square boundary cannot lose every Abel square by an ultralocal collapse. If collapse is balanced, finitely many normalized conformal coefficients detect it. If the low spectrum tries to revert to the regular tangent, the square must run to a second scale.

The next bridge should therefore compare:

\[
\boxed{
\text{v189 deep lamination}
}
\]
with
\[
\boxed{
\text{depth of the Möbius/Fulton–MacPherson escape tree}.
}
\]

A promising target is to show that repeated runaway consumes a definite amount of extremal length, harmonic measure, or low-mode Schwarzian activity per level. Since v189 demands `~r^{-2}` layers in a packet of diameter `r`, any such per-level budget could become a contradiction.

---

## 13. What is proved versus conjectural

### Proved in this v192 note

- exact square collapse reaches the total diagonal first;
- the universal angular floor `delta>(1-r)/100`;
- balanced collapse produces a normalized horocycle-square tangent;
- balanced collapse cannot occur at a conformally regular boundary point;
- exact formulas relating `b_2,b_3` to the pre-Schwarzian and Schwarzian;
- finite low-mode detectability of balanced escape;
- the explicit Möbius calibration showing why runaway must remain.

### Still open

- exclusion of all balanced tangent spectra;
- classification/exclusion of runaway collision trees;
- a theorem linking the v189 `r^{-2}` / `r^3` lamination quantitatively to the conformal tangent spectrum;
- a complete Toeplitz proof.

---

## 14. Standard analytic inputs

The proof uses standard results from univalent-function theory:

- Osgood–Carathéodory boundary extension for Jordan domains;
- compactness/Koebe distortion for the normalized schlicht class;
- the universal pre-Schwarzian bound `||(1-|z|^2)f''/f'||_infty <= 6`;
- the universal Schwarzian bound `||(1-|z|^2)^2 S_f||_infty <= 6`;
- de Branges' coefficient bound `|b_n|<=n`.

The configuration-space interpretation is compatible with the Fulton–MacPherson/cyclohedral compactification used in the polygonal-pegs literature; v192 specializes that boundary structure to exact square zeros and conformal blow-up coordinates.
