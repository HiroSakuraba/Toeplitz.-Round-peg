# v192 status corrections

1. **Refinement of v191's compactification language.** For exact squares on the Abel curves `f(rS^1)`, a degenerating sequence reaches the total four-point diagonal first. Pair/triple strata arise only after blow-up as nested collision data.

2. **New universal exclusion.** The conformal angular diameter of a square on `f(rS^1)` is never `o(1-r)`; the explicit crude bound `delta>(1-r)/100` holds for `r>=1/2`.

3. **Normalized univalent compactness is not itself enough.** The Möbius family `M_c(z)=z/(1+cz)` maps the limiting horocycle to a circle and contains exact horocycle squares for every `c<1`. Therefore v191's hoped-for “classify the limit spectrum and rule it out by coefficient bounds” cannot work without controlling where on the horocycle the square sits.

4. **Balanced escape is finitely detectable.** On every fixed `delta/(1-r)<=C` window, a finite number of low coefficients must stay away from the regular tangent spectrum. This is a theorem, but the constants are presently nonconstructive.

5. **The genuine remaining spectral obstruction is runaway.** Low-mode defects can tend to zero only while the square moves out of every fixed first-blow-up window. The explicit Möbius model exhibits the exact tradeoff.

6. **No v189-to-spectrum bridge is claimed yet.** v189's `r^-2` multiplicity and `r^3` gaps motivate an extremal-length/harmonic-measure attack on runaway, but v192 does not prove that bridge.
