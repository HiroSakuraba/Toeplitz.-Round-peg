# Handoff v193 — runaway spectral cascade

## Executive result

The v192 runaway branch is now substantially more rigid.

Let \(f:\mathbb D\to\Omega\) be a Riemann map and let an exact square on \(f(rS^1)\) have four conformal parameters contained in a minimal arc of span \(\delta\).  Set
\[
R=\delta/(1-r).
\]
After centering that arc and applying the usual automorphism \(\phi_r\), write the normalized map as
\[
F_r(u)=u+\sum_{n\ge2}b_nu^n,
\]
and subtract the identity-domain baseline
\[
G_r(u)=u/(1+ru)=u+\sum_{n\ge2}(-r)^{n-1}u^n.
\]
The coefficient defects are
\[
d_n=b_n-(-r)^{n-1}.
\]

### 1. Runaway is hyperbolically intrinsic

The hyperbolic distance between the two extreme Abel parameters is exactly
\[
2\operatorname{arsinh}\left(\frac{2r\sin(\delta/2)}{1-r^2}\right).
\]
Thus \(R\to\infty\) iff this diameter tends to infinity.  Disk automorphisms are hyperbolic isometries, so no second automorphism can put all four runaway points in a fixed compact subset of the disk.  v192's proposed recursion into another all-interior tangent chart is therefore invalid.

### 2. Square equations force growing spectral mass

A real four-vector of range \(\delta\) has DFT square-error norm at least \(\delta/4\).  A circular arc of span \(\delta\le1/2\) differs from its tangent line by only \(O(\delta^2)\), giving an arc error at least \(\delta/8\).

The baseline values satisfy
\[
G_r(u_j)=r(e^{it_j}-1)/(1-r^2).
\]
Since the actual values \(F_r(u_j)\) form a square, the defect must cancel both baseline square-error modes.  Hence
\[
\boxed{
\sum_{n\ge2}|d_n|\rho^n
\ge R/(24\sqrt2).}
\]
This is the core v193 spectral theorem.

### 3. Better universal floor

Combining the lower bound with de Branges' \(|b_n|\le n\) gives a contradiction if \(R\le1/4\).  Therefore
\[
\boxed{\delta>(1-r)/4.}
\]
This replaces the v192 \((1-r)/100\) floor.

### 4. Frequency migration

Define low and high cutoffs by the maximum possible de Branges mass.  Then a fixed fraction of the required defect lies in a corridor
\[
\Theta(\sqrt R)<n<O(R^2\log R).
\]
Thus arbitrary runaway cannot be carried by \(b_2,b_3\), or any other fixed finite jet.  The square-correcting mechanism must move to higher conformal frequencies.

### 5. Energy form

Cauchy-Schwarz converts the \(\ell^1\) bound into
\[
\boxed{
\sum n|d_n|^2\rho^n
\ge
R^2/[1152\log((R^2+16)/8)].}
\]
Equivalently,
\[
\int |(F_r-G_r)'|^2
\gtrsim R^2/\log R.
\]
After changing back to the original disk this is exactly
\[
\frac1{(1-r^2)^2|f'(r)|^2}
\int_{B_{r,\sqrt\rho}}|f'(z)-f'(r)|^2dA(z).
\]
This is the best current candidate for a quantity that can be packed globally.

## Strategic corrections

- **Schwarzian charge is dead as a universal route:** the Möbius runaway family has \(S\equiv0\) at arbitrary runaway factor.
- **Naive modulus counting is dead:** the v189 critical rainbow's \(N\) nested layers have only \((1/\pi)\log(3/2)\) total natural radial modulus.
- **Harmonic measure is still open**, but topology alone cannot control it.

## Recommended v194 target

Prove a bounded-overlap sampling/packing theorem for the strain regions.  The goal is to extract from a v189 packet many runaway centers whose normalized local energies cannot all be paid for by the single finite global budget
\[
\int_{\mathbb D}|f'|^2dA=\operatorname{Area}(\Omega).
\]

If that packing theorem fails, construct an explicit recycling example and abandon the strain route early.
