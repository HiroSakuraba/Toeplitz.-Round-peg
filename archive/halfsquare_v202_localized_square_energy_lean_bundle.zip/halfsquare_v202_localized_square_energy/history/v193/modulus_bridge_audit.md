# v193 audit — why the naive Schwarzian/modulus charges do not close the runaway branch

v192 proposed three possible scalar costs for each runaway scale jump: Schwarzian activity, extremal length/modulus, and harmonic-measure compression.  v193 can now separate what survives from what does not.

## 1. Schwarzian cost per jump is impossible in general

The v192 calibration family
\[
M_c(z)=\frac{z}{1+cz},\qquad 0\le c<1,
\]
has
\[
S_{M_c}\equiv0
\]
identically, yet maps the limiting horocycle to a circle and supports exact horocycle squares whose position satisfies
\[
\max|s_j|=\frac{1+\sqrt2}{1-c}\to\infty.
\]
The corresponding hyperbolic diameter diverges like
\[
2\log\frac1{1-c}.
\]

Therefore there cannot be a theorem of the form

> every runaway scale jump by factor \(R\) forces a positive amount of Schwarzian activity depending only on \(R\),

without additional geometric hypotheses.  Arbitrarily large runaway is compatible with exactly zero Schwarzian.

This removes candidate A from v192 as a standalone global charge.

## 2. Runaway does have an exact logarithmic modulus

Use the Cayley coordinate
\[
C(z)=\frac{1-z}{1+z},
\qquad
\eta_r=C(r)=\frac{1-r}{1+r}.
\]
A boundary angular scale \(\delta\) corresponds to
\[
|C(e^{i\delta})|=\tan(\delta/2).
\]
Consider the right-half-plane semi-annulus
\[
A^+(\eta_r,\tau)
=\{\Re w>0:\eta_r<|w|<\tau\},
\qquad
\tau=\tan(\delta/2).
\]
Under \(w\mapsto\log w\), this is a rectangle of width
\[
\log(\tau/\eta_r)
\]
and height \(\pi\).  With the convention that modulus measures curves joining the two semicircular sides,
\[
\boxed{
\operatorname{mod}A^+(\eta_r,\tau)
=\frac1\pi\log\frac{\tau}{\eta_r}.}
\]
For \(r\uparrow1\), \(\delta\downarrow0\),
\[
\frac{\tau}{\eta_r}
\sim\frac{\delta}{1-r}=R,
\]
so
\[
\boxed{\operatorname{mod}\sim\frac1\pi\log R.}
\]
This is the correct conformal corridor length associated with one runaway event.

## 3. But nested scale moduli merely telescope

For nested radii
\[
0<\rho_0<\rho_1<\cdots<\rho_m,
\]
the adjacent semi-annuli have moduli
\[
\frac1\pi\log\frac{\rho_{j+1}}{\rho_j}.
\]
Their sum is exactly
\[
\boxed{
\sum_{j=0}^{m-1}\operatorname{mod}A^+(\rho_j,\rho_{j+1})
=\frac1\pi\log\frac{\rho_m}{\rho_0}.}
\]
Thus subdividing a scale corridor into many runaway levels creates no extra modulus beyond the logarithm of the total endpoint ratio.

There is no fixed positive modulus charge per combinatorial level.

## 4. The v189 critical rainbow kills the naive \(N\)-modulus bridge

The v189 sharpness model uses
\[
q_j=1-\frac{j}{3N},\qquad j=0,\ldots,N,
\]
with \(q_0=1\) and \(q_N=2/3\).  Its \(N\) nested upper lobes realize the critical depth
\[
N\asymp r^{-2}
\]
and the critical transverse gap
\[
\Delta\asymp r^3.
\]

If one models the nested radial layers by the natural semi-annuli between successive \(q_j\), their total modulus is
\[
\sum_{j=0}^{N-1}\frac1\pi\log\frac{q_j}{q_{j+1}}
=
\boxed{\frac1\pi\log\frac32},
\]
independent of \(N\).

Therefore the v189 facts

- \(N\asymp r^{-2}\) nested layers,
- one or more gaps of order \(r^3\),

**do not by themselves imply an \(\Omega(N)\) extremal-length budget.**

This invalidates the simplest version of candidate B from v192.

## 5. Why this failure is structural

v189 controls:

- incidence and nesting;
- the number of layers;
- ordering along one transverse ray;
- an upper bound on at least one physical gap.

It does **not** control:

- a lower bound on channel length divided by channel width;
- a corkscrew ball on either side of each layer;
- a uniform harmonic-measure share for each lobe;
- a conformal modulus bounded below for each adjacent pair.

Without one of those extra metric statements, a stack can contain arbitrarily many layers while each individual modulus tends to zero and the total stays bounded.

## 6. What survives from the modulus idea

The modulus is still useful as a **coordinate for one runaway factor**:
\[
R\leftrightarrow \frac1\pi\log R.
\]
It is not, by itself, a finite budget capable of defeating v189's layer count.

The better v193 invariant is the spectral/Dirichlet strain forced by the square equations:
\[
\sum |d_n|\rho^n\gtrsim R,
\]
\[
\sum n|d_n|^2\rho^n\gtrsim \frac{R^2}{\log R}.
\]
That quantity grows polynomially rather than logarithmically with runaway and therefore has a much better chance of interacting with a packing theorem.

## 7. Harmonic measure remains unresolved

Candidate C is not killed by the calculations above.  However, v189 topology alone cannot determine harmonic measure: chord-fixing ambient homeomorphisms preserve the lobe tree while changing fjord geometry and conformal welding drastically.

A useful harmonic-measure theorem would therefore need additional **two-sided** or **packing** information.  The promising form is not “each lobe has definite harmonic measure,” which is false in wild domains, but something closer to:

> either many nested lobe layers receive enough conformal parameter mass to produce bounded-overlap spectral strain regions, or the harmonic measure is compressed so severely that the same packet becomes balanced after a different conformal centering.

That dichotomy remains open.
