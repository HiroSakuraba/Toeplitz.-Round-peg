# v194 target — globalize the runaway strain by packing

v193 changes the preferred next step.

The old plan was to assign a scalar cost to every runaway scale jump and compare the sum with the v189 lobe count.  Two of the three simplest costs are now inadequate:

- Schwarzian cost can be exactly zero for arbitrary runaway (Möbius calibration);
- modulus costs only \(\log R\), and the critical rainbow has \(N\) layers with only \(O(1)\) total natural radial modulus.

The new object is the local derivative-strain energy
\[
\mathcal E(r,q)
:=\frac1{(1-r^2)^2|f'(r)|^2}
\int_{B_{r,q}}|f'(z)-f'(r)|^2\,dA(z).
\]
A runaway square of factor \(R\) forces
\[
\mathcal E\gtrsim \frac{R^2}{\log R}.
\]

## Primary v194 problem

Prove a **bounded-overlap packing dichotomy** for a family of shrinking square events.

A useful statement would have the form:

> From a deep v189 packet, either one obtains a balanced/finite-window square event, or one can select many runaway centers \(a_k\) whose pseudohyperbolic strain regions \(B_k\) have bounded overlap and whose local conformal scales \((1-|a_k|^2)|f'(a_k)|\) are not too disparate.

If such a selection exists, summing the v193 strain lower bounds can be compared with the finite Bergman area
\[
\int_{\mathbb D}|f'|^2\,dA=\operatorname{Area}(\Omega).
\]

## Three concrete subtargets

### 1. Strain-region geometry

For the exact radius
\[
q=\sqrt\rho,
\qquad
\rho\le\frac{R/4}{\sqrt{1+(R/4)^2}},
\]
describe the pseudohyperbolic disk
\[
B_{r,q}=\phi_r(q\mathbb D)
\]
in ordinary Carleson-box coordinates near the collision boundary point.

Determine explicit inner/outer radial depths and angular aperture as functions of \((1-r,R)\).  This tells us when two strain regions at different scales are essentially disjoint.

### 2. Weighted packing inequality

Seek a deterministic inequality of the form
\[
\sum_k (1-|a_k|^2)^2|f'(a_k)|^2
\lesssim
\int_{\mathbb D}|f'|^2\,dA
\]
for a suitably separated sequence \(a_k\).

This resembles a Bergman/Carleson sampling estimate and is plausible for pseudohyperbolically separated centers.  If available with constants independent of the Jordan curve, it provides the missing finite global budget.

### 3. Lobe-to-center selection

Use the v189 nested lobe chain to produce either:

- many separated conformal centers at comparable local scale; or
- a quantitative failure of separation/harmonic-measure compression.

The second branch must then be converted into a new square mechanism rather than merely recorded as pathology.

## Secondary spectral target

The v193 corridor only gives
\[
N_-(R)=\Theta(\sqrt R),
\qquad
N_+(R)=O(R^2\log R).
\]
This is deliberately crude because it uses only \(|b_n|\le n\).

Try to improve the lower activation scale using:

- Grunsky inequalities;
- area-theorem constraints after a Möbius/exterior normalization;
- orthogonality of the two square-error channels \(k=2,3\);
- the exact phase structure of the moments \(M_{n,k}(u)\).

The Möbius calibration suggests that the physically natural activation scale may be closer to \(n\asymp R\) than \(n\asymp\sqrt R\).

## Status criterion for v194

A meaningful v194 advance would be any one of:

1. a proved bounded-overlap sampling inequality strong enough to sum v193 strain;
2. a lobe-to-conformal-center lemma producing a packable family;
3. an explicit counterexample showing that even the strain energy can be recycled across all nested layers, thereby killing this route early;
4. a stronger spectral activation theorem, ideally \(n\gtrsim R^\alpha\) with \(\alpha>1/2\).
