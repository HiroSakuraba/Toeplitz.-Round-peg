# v193 proof audit

This note records the main failure modes checked before banking the v193 statements.

## A. Does the DFT argument depend on curve-order = square-order?

No.  The four image vertices can always be labeled in geometric square order so that
\[
Z_j=c+a i^j.
\]
The corresponding conformal parameters \(t_j\) may then appear in any permutation.  Lemma 3.1 was deliberately proved for a real four-vector **in arbitrary order**, using only its range.  Therefore no graceful/non-graceful ordering assumption enters Theorems 4.1 or 5.1.

## B. Does centering the minimal angular arc lose generality?

No in the regime used.  The spectral lemmas are invoked only when \(\delta\le1/2\), so the shortest containing arc is unambiguous after choosing a lift.  Precomposing the Riemann map with a rotation moves its midpoint to \(1\); the normalization changes only by an affine similarity in the image and preserves exact squares.

## C. Is the identity baseline really the correct finite-r comparison?

Yes.  With
\[
\phi_r(u)=\frac{r+u}{1+ru},
\]
identity mapping gives exactly
\[
G_r(u)=\frac{\phi_r(u)-r}{1-r^2}=\frac{u}{1+ru}.
\]
For an Abel point \(re^{it}\),
\[
G_r(\phi_r^{-1}(re^{it}))
=\frac{r(e^{it}-1)}{1-r^2}.
\]
Thus the baseline DFT error is an exact scaled circular-arc error; there is no asymptotic horocycle replacement in the main spectral theorem.

This is important: v193's spectral forcing remains valid in the runaway regime where the bounded-\(s\) horocycle approximation is not uniform.

## D. Could the defect series fail to be absolutely summable at \(\rho\)?

No.  For every fixed event \(\rho<1\).  The normalized map is schlicht, so de Branges gives \(|b_n|\le n\), while \(|(-r)^{n-1}|\le1\).  Hence
\[
\sum_{n\ge2}|d_n|\rho^n
\le\sum_{n\ge2}(n+1)\rho^n<\infty.
\]
All DFT/coefficient rearrangements are therefore justified absolutely.

## E. Check of the \((1-r)/4\) floor constants

Under the contradictory assumption
\[
R=\delta/(1-r)\le1/4,
\]
we have \(\delta\le1/8\) and
\[
\rho\le R/4\le1/16.
\]
The circular DFT lower constant is
\[
9/40=0.225.
\]
After the \(1/\sqrt2\) two-channel estimate and \(r/(1+r)\ge1/3\), the spectral lower coefficient is
\[
\frac{3}{40\sqrt2}=0.0530330085\ldots.
\]
The de Branges upper estimate gives
\[
\frac{33}{160}R^2
\le \frac{33}{640}R
=0.0515625R.
\]
The margin is positive:
\[
\frac{3}{40\sqrt2}-\frac{33}{640}
\approx1.4705\times10^{-3}.
\]
So the stated \(1/4\) constant has a real, though not enormous, analytic margin.

## F. Does hyperbolic divergence really rule out every second Möbius normalization?

It rules out a normalization in which **all four vertices** stay in a common compact subset of \(\mathbb D\).  It does not rule out resolving one bounded subcluster while other vertices approach the boundary.  That mixed interior/boundary compactification is exactly what remains.

Accordingly, v193 does not claim that iterated Fulton--MacPherson analysis is useless.  It corrects only the stronger v192 idea that the balanced all-interior tangent theorem can simply be repeated at each runaway level.

## G. Is the Schwarzian route completely dead?

Only as a universal positive **per-runaway** charge.  Möbius maps have \(S\equiv0\) and the v192 family realizes arbitrarily large horocycle runaway.  Schwarzian information may still become useful after imposing fixed-map consistency, boundary normalization, or excluding the Möbius-like branch by another theorem.

## H. Does the rainbow prove that every conceivable modulus route fails?

No.  It proves that **layer count + cubic spacing alone** do not supply a fixed positive natural radial modulus per layer.  A stronger theorem could still use additional channel-length, two-sided accessibility, or harmonic-measure data.  The audit therefore downgrades the naive modulus count rather than eliminating extremal length from the project.

## I. Is the derivative-strain energy globally summable already?

No.  The exact identity
\[
\int |(F_r-G_r)'|^2
=\frac{1}{(1-r^2)^2|f'(r)|^2}
\int |f'(z)-f'(r)|^2
\]
has a center-dependent normalization and the relevant pseudohyperbolic regions may overlap strongly.  Finite area of \(\Omega\) does not by itself let us sum the normalized lower bounds.

This is the principal open analytic step after v193.

## J. Verification status

`code/verify_v193.py` performs deterministic checks of:

- square DFT mode identities;
- the real-vector DFT range bound;
- short circular-arc lower bounds;
- disk-automorphism and baseline identities;
- the exact hyperbolic distance formula;
- the \(\rho\)-versus-\(R\) bounds;
- the constant margin in the \((1-r)/4\) theorem;
- spectral corridor tail formulas;
- Cauchy--Schwarz energy conversion;
- critical-rainbow modulus telescoping;
- Möbius zero-Schwarzian calibration;
- pointwise change-of-variables density for the strain identity.

Current result: **1215/1215 checks pass**.
