# v193 — runaway hyperbolic and spectral-cascade theorem

## 1. Setup

Let \(f:\mathbb D\to\Omega\) be univalent, with \(\Omega\) a bounded Jordan domain.  For \(0<r<1\), let
\[
\Gamma_r=f(rS^1).
\]
Suppose \(Z_j=f(re^{i\theta_j})\), \(j=0,1,2,3\), are the vertices of an exact nondegenerate square.  Let \(\delta\) be the length of the shortest angular arc containing the four parameters.  Rotate so the midpoint of that minimal arc is \(0\), and write
\[
\theta_j=t_j,\qquad -\delta/2\le t_j\le \delta/2,
\qquad \max_j t_j-\min_j t_j=\delta.
\]
We are interested in collapsing sequences \(r\uparrow1\), \(\delta\downarrow0\), and in particular the runaway ratio
\[
R:=\frac{\delta}{1-r}.
\]

Let
\[
\phi_r(u)=\frac{r+u}{1+ru},\qquad A_r=1-r^2,
\]
and normalize the local conformal microscope by
\[
F_r(u)=\frac{f(\phi_r(u))-f(r)}{A_r f'(r)}
      =u+\sum_{n\ge2} b_n u^n.
\]
The identity-map baseline is
\[
G_r(u)=\frac{u}{1+ru}
      =u+\sum_{n\ge2}(-r)^{n-1}u^n.
\]
Define the local spectral defects
\[
\boxed{d_n:=b_n-(-r)^{n-1}.}
\]
For the four preimages
\[
u_j:=\phi_r^{-1}(re^{it_j}),
\]
put
\[
\rho:=\max_j |u_j|.
\]

The four-point DFT convention is
\[
\widehat W_k=\frac14\sum_{j=0}^3W_j i^{-kj}.
\]
After labeling the geometric square in positive cyclic order, an exact square satisfies
\[
\widehat W_2=\widehat W_3=0.
\]

---

## 2. Runaway is exactly divergent hyperbolic diameter

For the curvature \(-1\) Poincare metric on \(\mathbb D\),
\[
\sinh\frac{d_{\mathbb D}(z,w)}2
=\frac{|z-w|}{\sqrt{(1-|z|^2)(1-|w|^2)}}.
\]
For two points on \(rS^1\) with angular gap \(\alpha\), this is exactly
\[
\boxed{
 d_{\mathbb D}(re^{it},re^{i(t+\alpha)})
 =2\operatorname{arsinh}\!\left(
 \frac{2r|\sin(\alpha/2)|}{1-r^2}
 \right).}
\]
Taking the two extreme parameters of the minimal arc gives
\[
\boxed{
D_{\rm hyp}
=2\operatorname{arsinh}\!\left(
\frac{2r\sin(\delta/2)}{1-r^2}
\right).}
\]
Hence, along every collapsing sequence,
\[
R\to\infty
\quad\Longleftrightarrow\quad
D_{\rm hyp}\to\infty,
\]
and more precisely
\[
D_{\rm hyp}=2\log R+O(1).
\]

### Corollary 2.1 — no recursive interior compactification

Let \(\psi_n\) be arbitrary disk automorphisms.  If \(R_n\to\infty\), the four points
\[
\psi_n(r_ne^{it_{j,n}})
\]
cannot all remain in one fixed compact subset of \(\mathbb D\).

This is immediate because disk automorphisms preserve \(d_{\mathbb D}\), while every compact subset of \(\mathbb D\) has finite hyperbolic diameter.

**Correction to the v192 plan.**  A runaway quartet cannot be handled by simply repeating the balanced tangent theorem with another disk automorphism.  Any second normalization necessarily places at least part of the quartet on the boundary of the next compactification chart.  Runaway is therefore a genuinely mixed interior/boundary phenomenon.

---

## 3. A universal DFT defect for four points on a short line segment

We first isolate a finite-dimensional fact.

### Lemma 3.1 — real four-vector DFT gap

Let \(x_0,\ldots,x_3\in\mathbb R\), in any order, and let
\[
\max_jx_j-\min_jx_j=\delta.
\]
Then
\[
\boxed{
\sqrt{|\widehat x_2|^2+|\widehat x_3|^2}\ge \frac\delta4.}
\]

### Proof

For a real vector, \(\widehat x_3=\overline{\widehat x_1}\) and \(\widehat x_2\in\mathbb R\).  Parseval gives
\[
\sum_{j=0}^3|x_j-\bar x|^2
=4\bigl(2|\widehat x_3|^2+|\widehat x_2|^2\bigr).
\]
The two extreme entries alone contribute at least \(\delta^2/2\), so
\[
2|\widehat x_3|^2+|\widehat x_2|^2\ge\frac{\delta^2}{8}.
\]
Since
\[
2\bigl(|\widehat x_3|^2+|\widehat x_2|^2\bigr)
\ge 2|\widehat x_3|^2+|\widehat x_2|^2,
\]
the claim follows. \(\square\)

### Lemma 3.2 — short circular arc DFT gap

If
\[
|t_j|\le\delta/2,\qquad \operatorname{range}(t_j)=\delta,
\qquad \delta\le\frac12,
\]
then, for \(q_j=e^{it_j}-1\),
\[
\boxed{
\sqrt{|\widehat q_2|^2+|\widehat q_3|^2}\ge \frac\delta8.}
\]

Indeed,
\[
e^{it}-1=it+E(t),\qquad |E(t)|\le t^2/2\le\delta^2/8.
\]
Lemma 3.1 gives a line contribution at least \(\delta/4\), while the two DFT error channels together contribute at most \(\sqrt2\,\delta^2/8\).  For \(\delta\le1/2\), the remainder is at least \(\delta/8\).

A slightly sharper form, used below, is that if \(\delta\le1/8\), then
\[
\boxed{
\sqrt{|\widehat q_2|^2+|\widehat q_3|^2}\ge \frac{9\delta}{40}.}
\]

---

## 4. Exact spectral forcing from a square on a short Abel arc

The identity baseline is explicit at the four preimages:
\[
G_r(u_j)
=\frac{r(e^{it_j}-1)}{1-r^2}.
\]
Therefore Lemma 3.2 gives
\[
\sqrt{|\widehat{G_r(u)}_2|^2+|\widehat{G_r(u)}_3|^2}
\ge \frac{r\delta}{8(1-r^2)}
\qquad(\delta\le1/2).
\]
But the actual values \(F_r(u_j)\) are a square, hence their two square-error modes vanish.  Thus the defect
\[
D_r:=F_r-G_r=\sum_{n\ge2}d_nu^n
\]
must cancel the entire baseline DFT error.

Put
\[
M_{n,k}(u)=\frac14\sum_{j=0}^3u_j^ni^{-kj}.
\]
Then
\[
\sum_{n\ge2}d_nM_{n,k}(u)
=-\widehat{G_r(u)}_k,
\qquad k=2,3.
\]
Since
\[
|M_{n,k}(u)|\le\rho^n,
\]
we obtain the main spectral inequality.

### Theorem 4.1 — runaway spectral mass lower bound

For \(r\ge1/2\), \(\delta\le1/2\), and any exact square on \(f(rS^1)\) contained in an angular arc of span \(\delta\),
\[
\boxed{
\sum_{n\ge2}|d_n|\rho^n
\ge
\frac{r\delta}{8\sqrt2(1-r^2)}
\ge
\frac{R}{24\sqrt2}.}
\]

Thus a runaway square with \(R\to\infty\) cannot become spectrally invisible.  Its square-correcting defect must carry weighted local Fourier mass growing at least linearly in \(R\).

This is the opposite of a fixed-low-mode picture: if the first few coefficients approach the regular values, the required cancellation must migrate to progressively higher modes.

---

## 5. Stronger universal angular floor

v192 proved the crude but useful bound
\[
\delta>\frac{1-r}{100}.
\]
The spectral forcing inequality improves this by more than an order of magnitude.

### Theorem 5.1 — spectral angular floor

For every univalent \(f\), every \(r\ge1/2\), and every exact square on \(f(rS^1)\),
\[
\boxed{
\delta>\frac{1-r}{4}.}
\]

### Proof

Assume for contradiction that \(R\le1/4\).  Then
\[
\delta=R(1-r)\le1/8.
\]
Using the sharpened circular-arc estimate,
\[
\sum_{n\ge2}|d_n|\rho^n
\ge
\frac{9}{40\sqrt2}\frac{r\delta}{1-r^2}
\ge
\frac{3R}{40\sqrt2}.
\]

On the other hand, if the minimal arc is centered at zero, then
\[
|u_j|
\le
\frac{H}{\sqrt{1+H^2}},
\qquad
H=\frac{2r\sin(\delta/4)}{1-r^2}
\le \frac R4.
\]
Hence \(\rho\le R/4\le1/16\).

By de Branges' coefficient estimate \(|b_n|\le n\),
\[
|d_n|\le n+1.
\]
Therefore
\[
\sum_{n\ge2}|d_n|\rho^n
\le
\sum_{n\ge2}(n+1)\rho^n
=
\frac{\rho^2(3-2\rho)}{(1-\rho)^2}.
\]
For \(0\le\rho\le1/16\),
\[
\frac{3-2\rho}{(1-\rho)^2}<\frac{33}{10},
\]
so
\[
\sum_{n\ge2}|d_n|\rho^n
<\frac{33R^2}{160}
\le\frac{33R}{640}.
\]
Finally,
\[
\frac{33}{640}<\frac{3}{40\sqrt2},
\]
contradicting the lower bound. \(\square\)

The constant \(1/4\) is not claimed sharp; it was chosen because the proof is fully explicit and comfortable.  Numerically optimizing only the inequalities above gives a somewhat larger constant, but no importance is attached to that optimization.

---

## 6. Runaway forces a frequency cascade

Theorem 4.1 gives total weighted mass.  We can also locate the range of modes that must carry a definite fraction of it.

Define
\[
c_0:=\frac1{24\sqrt2},
\qquad
\bar\rho(R):=
\frac{R/4}{\sqrt{1+(R/4)^2}}.
\]
The centered-arc calculation gives
\[
\rho\le\bar\rho(R).
\]

Let \(N_-(R)\) be the largest integer \(N\ge2\) such that
\[
\sum_{n=2}^{N}(n+1)\le \frac{c_0R}{4}.
\]
Let \(N_+(R)\) be the smallest integer \(N\) such that
\[
\sum_{n>N}(n+1)\bar\rho(R)^n
\le\frac{c_0R}{4}.
\]

### Theorem 6.1 — spectral corridor

For every sufficiently large runaway factor \(R\),
\[
\boxed{
\sum_{N_-(R)<n\le N_+(R)}|d_n|\rho^n
\ge \frac{c_0R}{2}.}
\]
Moreover,
\[
\boxed{N_-(R)=\Theta(\sqrt R),}
\qquad
\boxed{N_+(R)=O(R^2\log R).}
\]

### Proof

The low modes can contribute at most \(c_0R/4\) by \(|d_n|\le n+1\) and the definition of \(N_-\).  The modes above \(N_+\) contribute at most \(c_0R/4\), again by \(|d_n|\le n+1\) and \(\rho\le\bar\rho\).  Theorem 4.1 supplies total mass at least \(c_0R\), leaving at least \(c_0R/2\) in the middle corridor.

The first asymptotic follows from
\[
\sum_{n=2}^{N}(n+1)=\frac{(N+1)(N+2)}2-3.
\]
For the upper cutoff, note
\[
1-\bar\rho(R)
\ge\frac{8}{R^2+16}.
\]
The exact tail formula
\[
\sum_{n>N}(n+1)x^n
=x^{N+1}\frac{(N+2)-(N+1)x}{(1-x)^2}
\]
then gives \(N_+=O(R^2\log R)\). \(\square\)

### Dyadic-band corollary

Partition the corridor into dyadic bands.  Since it contains only \(O(\log R)\) such bands, at least one band
\[
N<n\le2N
\]
carries weighted defect
\[
\boxed{\Omega(R/\log R).}
\]
Thus every sufficiently large runaway event selects at least one genuinely active local spectral scale.

---

## 7. A Dirichlet-energy form of the cascade

The weighted \(\ell^1\) lower bound can be converted into an analytic energy lower bound.

By Cauchy-Schwarz,
\[
\left(\sum_{n\ge2}|d_n|\rho^n\right)^2
\le
\left(\sum_{n\ge2}n|d_n|^2\rho^n\right)
\left(\sum_{n\ge2}\frac{\rho^n}{n}\right).
\]
Since
\[
1-\rho\ge \frac{8}{R^2+16},
\]
we have
\[
\sum_{n\ge2}\frac{\rho^n}{n}
\le -\log(1-\rho)
\le \log\frac{R^2+16}{8}.
\]
Combining this with Theorem 4.1 yields:

### Theorem 7.1 — conformal strain energy lower bound

For every square in the short-arc regime,
\[
\boxed{
\sum_{n\ge2}n|d_n|^2\rho^n
\ge
\frac{R^2}
{1152\,\log((R^2+16)/8)}.}
\]
Equivalently, with \(q=\sqrt\rho\),
\[
\boxed{
\int_{|u|<q}|(F_r-G_r)'(u)|^2\,dA(u)
\ge
\frac{\pi R^2}
{1152\,\log((R^2+16)/8)}.}
\]
Thus runaway costs at least
\[
\Omega(R^2/\log R)
\]
in dimensionless local derivative-strain energy.

This lower bound detects the zero-Schwarzian Möbius runaway family as well: Schwarzian curvature may vanish, yet the normalized map can still accumulate large multiscale derivative strain relative to the regular baseline.

---

## 8. Exact physical-coordinate form of the strain energy

The energy above is not just a formal coefficient norm.  It has an exact expression in the original conformal map.

Let
\[
B_{r,q}:=\phi_r(q\mathbb D).
\]
Because
\[
(F_r-G_r)'(u)
=\frac1{(1+ru)^2}
\left(\frac{f'(\phi_r(u))}{f'(r)}-1\right)
\]
and
\[
|\phi_r'(u)|^2
=\frac{(1-r^2)^2}{|1+ru|^4},
\]
change of variables gives the exact identity
\[
\boxed{
\int_{|u|<q}|(F_r-G_r)'|^2\,dA
=
\frac1{(1-r^2)^2|f'(r)|^2}
\int_{B_{r,q}}|f'(z)-f'(r)|^2\,dA(z).}
\]
Therefore Theorem 7.1 can be rewritten as
\[
\boxed{
\int_{B_{r,\sqrt\rho}}
|f'(z)-f'(r)|^2\,dA(z)
\ge
\frac{\pi\,(1-r^2)^2|f'(r)|^2R^2}
{1152\,\log((R^2+16)/8)}.}
\]

The natural local length scale
\[
\ell_r=(1-r^2)|f'(r)|
\]
is comparable, by Koebe distortion, to the Euclidean distance from \(f(r)\) to \(\partial\Omega\).  Thus runaway forces large derivative oscillation measured in units of the local conformal radius.

This is the first v191--v193 spectral quantity with a plausible route to a **global packing argument**: unlike the Schwarzian, \(f'\) has the finite area budget
\[
\int_{\mathbb D}|f'|^2\,dA=\operatorname{Area}(\Omega)<\infty.
\]
The missing step is to pack sufficiently many of the strain regions \(B_{r,q}\) with controlled overlap and normalization weights.

---

## 9. What v193 proves, and what it does not

### Banked

1. Runaway is exactly divergent hyperbolic diameter.
2. No disk-automorphism recursion can compactify all four runaway vertices into the interior.
3. Every short-arc square forces local spectral defect of size \(\Omega(R)\).
4. The universal angular floor improves from \((1-r)/100\) to
   \[
   \boxed{(1-r)/4}.
   \]
5. A runaway event forces a growing-frequency cascade; a fixed finite jet cannot carry the cancellation.
6. The dimensionless derivative-strain energy is at least \(\Omega(R^2/\log R)\).
7. That strain energy has an exact original-coordinate expression involving \(|f'(z)-f'(r)|^2\).

### Still open

The new energy estimate is **local and normalized**.  It does not yet show that a single fixed Jordan domain has insufficient total budget to support all possible runaway square branches.  To get a contradiction one needs a packing/orthogonality theorem that prevents the same global area from paying for arbitrarily many nested runaway events.

That packing problem is the recommended v194 target.
