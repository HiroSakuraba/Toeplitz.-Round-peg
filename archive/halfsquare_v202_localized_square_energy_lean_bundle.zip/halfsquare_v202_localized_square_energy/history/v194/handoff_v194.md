# Handoff v194 — parabolic runaway and failure of naive strain packing

## Executive result

v194 finds the missing scale in the Fourier/conformal runaway program:
\[
\boxed{X=(1-r)R^2=\delta^2/(1-r).}
\]
Here \(R=\delta/(1-r)\) is the v193 runaway factor.

The natural v193 strain disk \(B_{r,q}\) has an exact Euclidean center/radius.  Along a collapsing runaway sequence with \(X\to x\), it converges to
\[
\boxed{B\!\left(\frac4{x+4},\frac{x}{x+4}\right).}
\]
Thus:

- \(X\to0\): the strain disk remains local;
- \(X\asymp1\): it converges to a fixed horodisk;
- \(X\to\infty\): it exhausts the unit disk.

## Banked positive theorem

For pseudohyperbolically \(\eta\)-separated centers,
\[
\sum_k(1-|a_k|^2)^2|f'(a_k)|^2
\le C(\eta)\operatorname{Area}(\Omega).
\]
This is an explicit Bergman sampling inequality proved directly from disjoint fixed-radius hyperbolic disks and the analytic mean inequality.

## Main negative theorem

Center separation does not propagate to the v193 strain regions.

Take
\[
r_k=1-2^{-k},\quad \delta_k=2^{-k/2}.
\]
Then \(R_k=2^{k/2}\to\infty\), \(X_k=1\), and the centers are uniformly separated by more than \(1/3\).  Nevertheless
\[
B_{r_k,q_k}\to B(4/5,1/5),
\]
so every strict compact subdisk is contained in all sufficiently large strain regions.

## Explicit recycling calibration

For
\[
f_\alpha(z)=1-(1-z)^\alpha,\qquad0<\alpha<1,
\]
the image is a bounded Jordan domain and \(f_\alpha'\in A^2\).  On the parabolic sequence, the same fixed interior disk yields
\[
\mathcal E(r_k,q_k)\gtrsim (1-r_k)^{-2}=R_k^4,
\]
even though the total Bergman area is finite.

Therefore the raw v193 strain is not a globally summable charge.

## Corrected decomposition

For \(B_{r,q}=B(C,S)\),
\[
\boxed{
\int_B|f'-f'(r)|^2
=
\int_B|f'-f'(C)|^2
+\pi S^2|f'(C)-f'(r)|^2.}
\]
The first term is mean-corrected variance and is globally chargeable under bounded overlap.  The second is derivative transport and can recycle.

Thus actual runaway square events divide into:

- variance-rich events, potentially packable;
- transport-rich events, requiring a new rigidity/classification theorem.

## Secondary negative result

The \(\Theta(\sqrt R)\) low-frequency activation floor from v193 cannot be improved using only better individual coefficient bounds for bounded Jordan domains.  The analytic Jordan maps
\[
k_s(z)=z/(1-sz)^2
\]
have coefficients \(n s^{n-1}\) and approach the Koebe extremal \(n\) on arbitrarily long finite blocks.

## Recommended v195 work

1. classify transport-rich runaway, aiming for power/cusp tangent models;
2. prove bounded-overlap packing in the subparabolic variance branch;
3. connect v189's disjoint nested lobe arcs to harmonic-measure compression;
4. improve spectral activation only through square-specific coefficient correlations, not one-coefficient estimates.
