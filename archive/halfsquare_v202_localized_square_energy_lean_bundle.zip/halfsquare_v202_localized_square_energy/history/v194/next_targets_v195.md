# v195 targets — transport-rich runaway and the v189 harmonic-measure bridge

v194 divides the runaway program twice:

\[
R\to\infty
\quad\leadsto\quad
X=(1-r)R^2
\]
with subparabolic/parabolic/superparabolic geometry, and
\[
\text{strain}=\text{variance}+\text{transport}.
\]

The next work should avoid trying to sum the raw strain.

## Target 1 — transport-rich rigidity

Assume a sequence of actual runaway square events is transport-rich:
\[
\pi S_k^2|f'(C_k)-f'(r_k)|^2
\gtrsim
(1-r_k^2)^2|f'(r_k)|^2\frac{R_k^2}{\log R_k}.
\]
Study the normalized derivative ratios along the real hyperbolic segment from \(r_k\) to
\[
C_k=\phi_{r_k}(-r_kq_k^2).
\]
Try to prove a dichotomy:

- either the logarithmic derivative has substantial oscillatory mass, which returns to a variance/Carleson charge;
- or it is approximately one-dimensional over many scales, forcing a power/cusp tangent model
  \[
  f'(z)\approx A(1-\bar\xi z)^{\alpha-1}.
  \]

Then attack that model directly with the four-point square transform.

## Target 2 — subparabolic variance packing

When
\[
X_k\to0,
\]
Theorem 3.1 gives a genuinely shrinking strain disk of Euclidean radius
\[
S_k\sim X_k/4.
\]
Derive explicit separation conditions on \((r_k,X_k)\) under which these disks have bounded overlap.  Combine with the variance-rich branch to obtain a real global summability theorem.

## Target 3 — harmonic measure of the v189 lobe arcs

The off-line lobe arcs in v189 are disjoint subarcs of the Jordan boundary.  Under the Carathéodory boundary map they correspond to disjoint angular intervals \(I_j\subset S^1\), so
\[
\sum_j |I_j|\le2\pi.
\]
A depth-\(N\asymp r^{-2}\) packet therefore contains many arcs with harmonic measure \(O(r^2)\) or smaller.

The missing quantitative question is:

> how much Bergman/Half-Sobolev energy is required for a boundary interval of harmonic length \(h\) to make a macroscopic lobe excursion of physical size comparable to the packet scale \(r\), while remaining part of a simple nested lobe stack?

A useful theorem must exploit the *simultaneous nesting and cubic transverse spacing*, because critical \(H^{1/2}\) scaling by itself only charges order \(r^2\) per macroscopic lobe, and \(N r^2\asymp1\) is still compatible with finite area.

## Target 4 — square-specific spectral correlations

The Koebe approximation kills any hope of improving the \(\sqrt R\) mode floor from individual coefficient estimates.  The next spectral improvement must use the coupled equations
\[
\sum_{n\ge2}d_nM_{n,2}=-\widehat G_2,
\qquad
\sum_{n\ge2}d_nM_{n,3}=-\widehat G_3.
\]
Try:

- Grunsky inequalities applied to the same linear combinations that appear in \(M_{n,k}\);
- two-channel orthogonality between \(k=2\) and \(k=3\);
- asymptotics of \(M_{n,k}\) in the parabolic chart \(t=\sqrt\varepsilon\,s\);
- proving that near-Koebe coefficient vectors cannot align with both square-error channels over a long initial block.

## Success criterion

A meaningful v195 advance is one of:

1. a proved transport-rich rigidity lemma;
2. a bounded-overlap theorem for subparabolic variance disks strong enough to sum actual square events;
3. a lobe-to-harmonic-measure inequality that uses more than critical \(H^{1/2}\) scaling;
4. a square-specific spectral activation bound strictly stronger than \(\Theta(\sqrt R)\).
