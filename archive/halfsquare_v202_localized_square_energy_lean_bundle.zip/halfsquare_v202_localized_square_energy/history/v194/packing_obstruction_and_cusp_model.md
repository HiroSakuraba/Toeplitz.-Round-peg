# Packing obstruction and the explicit cusp calibration

This note isolates the main negative result of v194.

## Separated centers are not enough

Take
\[
r_k=1-2^{-k},\qquad \delta_k=2^{-k/2}.
\]
Then
\[
R_k=\frac{\delta_k}{1-r_k}=2^{k/2}\to\infty
\]
and
\[
X_k=(1-r_k)R_k^2=1.
\]
The centers satisfy
\[
\beta(r_k,r_{k+1})=\frac1{3-2^{-k}}>\frac13,
\]
yet the natural v193 strain disks converge to
\[
B(4/5,1/5).
\]
Hence every compact subset of this horodisk lies in infinitely many strain regions.

This is fatal to a direct bounded-overlap argument based only on pseudohyperbolic separation of the centers.

## A finite-area Jordan domain that recycles the strain

For \(0<\alpha<1\),
\[
f_\alpha(z)=1-(1-z)^\alpha
\]
is a bounded Jordan Riemann map with
\[
f_\alpha'(z)=\alpha(1-z)^{\alpha-1}\in A^2(\mathbb D).
\]
On the parabolic sequence above, \(|f_\alpha'(r_k)|\to\infty\), while \(f_\alpha'\) stays bounded on every compact subset of \(B(4/5,1/5)\).  Therefore the same fixed compact disk produces
\[
\mathcal E(r_k,q_k)\gtrsim (1-r_k)^{-2}=R_k^4.
\]
The normalized local strain can diverge much faster than the v193 lower bound while the global area remains finite.

The lesson is precise: the term \(f'(r_k)\) being subtracted changes from event to event.  Reusing the same physical area against larger and larger subtraction constants creates arbitrarily large center-normalized strain without spending new \(|f'|^2\) mass.

## Corrected charge

For a Euclidean strain disk \(B=B(C,S)\),
\[
\int_B|f'-f'(r)|^2
=
\underbrace{\int_B|f'-f'(C)|^2}_{\text{variance}}
+
\underbrace{\pi S^2|f'(C)-f'(r)|^2}_{\text{transport}}.
\]
The first term is bounded by \(\int_B|f'|^2\) and can be summed under bounded overlap.  The second cannot.

Accordingly, a future area-budget proof has to show either that enough square events are variance-rich, or that the transport-rich alternative has a rigid geometry that can be killed separately.
