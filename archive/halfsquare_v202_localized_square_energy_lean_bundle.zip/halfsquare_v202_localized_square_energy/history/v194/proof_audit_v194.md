# Proof audit v194

## Bankable statements

### A. Euclidean pseudohyperbolic-disk formulas

Exact.  Directly expanding
\[
|z-r|^2<q^2|1-rz|^2
\]
and completing the square gives the stated center and radius.  The real intercept formulas are also exactly \(\phi_r(\pm q)\).

### B. Parabolic tangent-disk law

The only asymptotic input is
\[
H=\frac{2r\sin(\delta/4)}{1-r^2}\sim R/4
\]
for \(r\to1\), \(\delta\to0\).  Hence
\[
1-q^2=1-\rho\sim8/R^2.
\]
Writing \(X=(1-r)R^2\) and substituting into the exact center/radius formulas yields the tangent-disk limit.  The verifier checks finite \(X\), \(X\to0\), and large \(X\) sequences.

### C. Separated-center Bergman sampling

Self-contained.  The chosen radius
\[
q_0=\tanh(\tfrac12\operatorname{arctanh}\eta)
\]
makes the associated hyperbolic balls disjoint.  The analytic mean inequality plus the exact automorphism Jacobian gives the explicit constant.

### D. Infinite-overlap counterexample

Exact separation is
\[
\beta(r_k,r_{k+1})=(3-2^{-k})^{-1}>1/3.
\]
The tangent-disk theorem with \(X=1\) gives convergence to \(B(4/5,1/5)\), so every strict compact subdisk is eventually contained in all regions.

### E. Cusp recycling model

The branch choice is safe because \(1-\overline{\mathbb D}\) lies in a closed half-plane of argument width \(\pi\), and multiplication by \(\alpha<1\) keeps the power map injective.  The derivative is square-integrable because its singular exponent is strictly greater than \(-2\) in two dimensions.

The strain lower bound uses only a fixed compact disk on which \(f_\alpha'\) is bounded and \(|f_\alpha'(r_k)|\to\infty\).  No claim is made that the chosen \((r_k,\delta_k)\) are actual square events for this cusp domain.  The example is a counterexample to the *packing inference*, not to Toeplitz or to v193.

### F. Variance/transport identity

Exact Hilbert-space Pythagoras.  Since the area average of an analytic function over a Euclidean disk equals its center value, the cross term vanishes.

### G. Koebe-block sharpness

For \(s<1\), \(k_s(z)=z/(1-sz)^2\) is a scaled restriction of the Koebe map to the smaller disk \(s\mathbb D\).  It is univalent on a neighborhood of the closed unit disk and therefore has bounded analytic Jordan image.  Its coefficients are exactly \(n s^{n-1}\), proving arbitrarily long near-saturation of the linear coefficient envelope.

## What v194 does not prove

1. It does not select conformal centers from the v189 lobe stack.
2. It does not prove that actual runaway square events can realize the cusp recycling model.
3. It does not show that the transport-rich branch is rigid; that is a v195 target.
4. It does not improve the v193 \(\Theta(\sqrt R)\) low-frequency cutoff.
5. It does not convert harmonic-measure compression of the v189 lobe arcs into a contradiction.

## Strategic conclusion

The naive global strain budget is dead in parabolic and superparabolic runaway.  The surviving quantitative route is a two-branch argument:

- pack the mean-corrected variance where the strain disks remain local or have bounded overlap;
- classify/kill transport-rich runaway separately.
