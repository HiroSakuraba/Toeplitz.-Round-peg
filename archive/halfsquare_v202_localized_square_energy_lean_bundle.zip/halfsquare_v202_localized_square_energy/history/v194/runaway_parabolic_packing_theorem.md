# v194 — Parabolic scale law, Bergman sampling, and the packing obstruction

## 1. Setup

Let \(f:\mathbb D\to\Omega\) be univalent, with \(\Omega\) a bounded Jordan domain.  As in v193, suppose an exact square on the Abel curve \(f(rS^1)\) is contained in a minimal angular arc of span \(\delta\).  Put
\[
\varepsilon:=1-r,
\qquad
R:=\frac{\delta}{\varepsilon}.
\]
The runaway regime is
\[
\varepsilon\downarrow0,
\qquad
\delta\downarrow0,
\qquad
R\to\infty.
\]
After centering the minimal angular arc at zero, the two extreme parameters are \(t=\pm\delta/2\).  With
\[
\phi_r(u)=\frac{r+u}{1+ru},
\]
their common pseudohyperbolic radius is
\[
\rho
=\left|\phi_r^{-1}(re^{i\delta/2})\right|
=\frac{H}{\sqrt{1+H^2}},
\qquad
H:=\frac{2r\sin(\delta/4)}{1-r^2}.
\]
v193 obtains its Dirichlet-energy lower bound on the larger pseudohyperbolic disk
\[
B_{r,q}:=\phi_r(q\mathbb D),
\qquad
q:=\sqrt\rho.
\]
The purpose of v194 is to understand the Euclidean geometry and packability of these disks.

---

## 2. Exact Euclidean geometry of a pseudohyperbolic strain disk

For real \(0<r<1\) and \(0<q<1\),
\[
B_{r,q}=\left\{z:\left|\frac{z-r}{1-rz}\right|<q\right\}
\]
is the Euclidean disk with center
\[
\boxed{
C(r,q)=\frac{r(1-q^2)}{1-r^2q^2}}
\]
and radius
\[
\boxed{
S(r,q)=\frac{q(1-r^2)}{1-r^2q^2}.}
\]
Its two real-axis boundary points are
\[
z_+=\frac{r+q}{1+rq},
\qquad
z_- =\frac{r-q}{1-rq},
\]
so the outer and inner boundary depths relative to the collision point \(1\) are
\[
\boxed{
d_+(r,q)=1-z_+
=\frac{(1-r)(1-q)}{1+rq},}
\]
\[
\boxed{
d_-(r,q)=1-z_-
=\frac{(1-r)(1+q)}{1-rq}.}
\]
The transverse half-width is exactly \(S(r,q)\).  Equivalently, in the local coordinate \(w=1-z\), the strain region is the disk centered at
\[
1-C(r,q)
=\frac{(1-r)(1+r q^2)}{1-r^2q^2}
\]
with radius \(S(r,q)\).

These formulas give the missing Carleson-box description requested in v193.  In particular, the strain region is not controlled by \(R\) alone.

---

## 3. The second runaway scale: \(X=\delta^2/(1-r)\)

Define
\[
\boxed{
X:=\varepsilon R^2
=\frac{\delta^2}{\varepsilon}.}
\]
This is the parabolic scale ratio.  It compares the square's tangential angular scale \(\delta\) with the square root of the radial Abel depth \(\sqrt\varepsilon\).

Because \(\delta\to0\),
\[
H\sim \frac R4,
\qquad
\rho=1-\frac8{R^2}+o(R^{-2}),
\qquad
q=1-\frac4{R^2}+o(R^{-2}).
\]
Substitute this into the exact disk formulas.

### Theorem 3.1 — parabolic tangent-disk law

Along a runaway sequence, suppose
\[
X=\varepsilon R^2\to x\in[0,\infty].
\]
Then the Euclidean strain disks \(B_{r,q}\) have the following limits.

For finite \(x\),
\[
\boxed{
C(r,q)\longrightarrow \frac4{x+4},
\qquad
S(r,q)\longrightarrow \frac{x}{x+4}.}
\]
Thus \(B_{r,q}\) converges to the disk
\[
\boxed{
\left|z-\frac4{x+4}\right|<\frac{x}{x+4},}
\]
which is tangent to \(S^1\) at \(1\).

For \(x=\infty\),
\[
\boxed{C(r,q)\to0,\qquad S(r,q)\to1,}
\]
so the strain disk exhausts \(\mathbb D\).

### Consequence — three runaway regimes

The runaway branch splits naturally into
\[
\boxed{
\begin{array}{lll}
X\to0
&\Longleftrightarrow&
\delta\ll\sqrt{1-r}
\quad\text{(subparabolic runaway)},\\[1mm]
X\asymp1
&\Longleftrightarrow&
\delta\asymp\sqrt{1-r}
\quad\text{(parabolic runaway)},\\[1mm]
X\to\infty
&\Longleftrightarrow&
\delta\gg\sqrt{1-r}
\quad\text{(superparabolic runaway)}.
\end{array}}
\]

Only the subparabolic branch keeps the v193 strain region genuinely local in the disk.  Parabolic runaway produces a fixed nontrivial horodisk, while superparabolic runaway makes the strain region macroscopic and eventually almost global.

This is a structural correction to the v193 packing plan: a family of centers can be very well separated while their relevant strain regions have enormous overlap.

---

## 4. A banked Bergman sampling inequality for separated centers

There is nevertheless a clean sampling theorem for the *centers*.

For \(a,b\in\mathbb D\), write
\[
\beta(a,b):=\left|\frac{a-b}{1-\bar a b}\right|
\]
for pseudohyperbolic distance.

### Theorem 4.1 — explicit separated-center sampling

Let \(\{a_k\}\subset\mathbb D\) satisfy
\[
\beta(a_j,a_k)\ge\eta>0
\qquad(j\ne k).
\]
Set
\[
q_0:=\tanh\!\left(\frac12\operatorname{arctanh}\eta\right).
\]
Then for every analytic \(g\in A^2(\mathbb D)\),
\[
\boxed{
\sum_k (1-|a_k|^2)^2 |g(a_k)|^2
\le
\frac{(1+q_0)^4}{\pi q_0^2}
\int_{\mathbb D}|g(z)|^2\,dA(z).}
\]
In particular, with \(g=f'\),
\[
\boxed{
\sum_k (1-|a_k|^2)^2 |f'(a_k)|^2
\le C(\eta)\operatorname{Area}(\Omega).}
\]

### Proof

The hyperbolic distance is \(2\operatorname{arctanh}\beta\).  The pseudohyperbolic disks \(B(a_k,q_0)\) are therefore pairwise disjoint by the hyperbolic triangle inequality.

For
\[
\phi_a(w)=\frac{a+w}{1+\bar a w},
\]
the function \(h(w)=g(\phi_a(w))\) is analytic.  The mean inequality gives
\[
|g(a)|^2
\le\frac1{\pi q_0^2}
\int_{|w|<q_0}|g(\phi_a(w))|^2\,dA(w).
\]
Since
\[
|\phi_a'(w)|
=\frac{1-|a|^2}{|1+\bar a w|^2},
\]
change variables to \(z=\phi_a(w)\), multiply by \((1-|a|^2)^2\), and use \(|1+\bar a w|\le1+q_0\).  This yields
\[
(1-|a|^2)^2|g(a)|^2
\le
\frac{(1+q_0)^4}{\pi q_0^2}
\int_{B(a,q_0)}|g(z)|^2\,dA(z).
\]
Summing over the disjoint disks proves the theorem. \(\square\)

The theorem banks subtarget 2 from the v193 handoff.  However, the next section shows why it is not enough to globalize the v193 strain estimate.

---

## 5. Uniformly separated centers can have infinitely overlapping runaway strain disks

Take
\[
\varepsilon_k=2^{-k},
\qquad
r_k=1-\varepsilon_k,
\qquad
\delta_k=\sqrt{\varepsilon_k},
\qquad
R_k=\varepsilon_k^{-1/2}.
\]
Then
\[
R_k\to\infty,
\qquad
\delta_k\to0,
\qquad
X_k=\varepsilon_kR_k^2=1.
\]
Thus this is the canonical parabolic runaway scale.

The centers are uniformly pseudohyperbolically separated.  Indeed, for consecutive terms,
\[
\beta(r_k,r_{k+1})
=
\frac{\varepsilon_k/2}{(3/2)\varepsilon_k-(1/2)\varepsilon_k^2}
=
\boxed{\frac1{3-\varepsilon_k}>\frac13.}
\]
Nonconsecutive pairs are farther apart.

But Theorem 3.1 gives
\[
B_{r_k,q_k}\longrightarrow B\!\left(\frac45,\frac15\right).
\]
Therefore every compact disk
\[
K\Subset B\!\left(\frac45,\frac15\right)
\]
is contained in \(B_{r_k,q_k}\) for all sufficiently large \(k\).

### Theorem 5.1 — failure of strain-region packing

There exists a uniformly pseudohyperbolically separated runaway sequence \(\{r_k\}\) such that the natural v193 strain regions \(B_{r_k,q_k}\) have infinite overlap on a fixed open subset of \(\mathbb D\).

In particular, no theorem of the form

> uniformly separated runaway centers \(\Rightarrow\) uniformly bounded overlap of the v193 strain regions

can hold.

Any infinite subsequence still has infinite overlap on the same compact set.  Sparsifying the centers does not repair the problem.

---

## 6. Explicit strain recycling inside a bounded Jordan domain

The overlap obstruction is not merely geometric.  The normalized v193 strain can genuinely be recycled through the same fixed physical region while the total Bergman area remains finite.

Fix \(0<\alpha<1\) and define
\[
\boxed{
f_\alpha(z)=1-(1-z)^\alpha,}
\]
using the principal branch on the right half-plane.

### Lemma 6.1 — the cusp model belongs to the admissible Jordan class

The map \(f_\alpha\) is holomorphic and univalent on \(\mathbb D\), extends continuously and injectively to \(\overline{\mathbb D}\), and has bounded Jordan image.

Moreover
\[
f_\alpha'(z)=\alpha(1-z)^{\alpha-1}
\]
and
\[
\boxed{
\int_{\mathbb D}|f_\alpha'(z)|^2\,dA(z)<\infty.}
\]

### Proof

The set \(1-\overline{\mathbb D}\) lies in the closed right half-plane and meets zero only at \(z=1\).  On this half-plane the principal argument lies in \([-\pi/2,\pi/2]\).  Multiplication of the argument by \(0<\alpha<1\) has range of width strictly less than \(\pi\), so the power map \(w\mapsto w^\alpha\) is injective there.  Hence \(f_\alpha\) is injective on the closed disk and its boundary image is Jordan.

Near \(z=1\),
\[
|f_\alpha'(z)|^2=\alpha^2|1-z|^{2\alpha-2}.
\]
The exponent \(2\alpha-2>-2\), so this is locally area-integrable. \(\square\)

Now use the parabolic sequence from Section 5.  Choose for example
\[
K=B\!\left(\frac45,\frac1{20}\right)
\Subset B\!\left(\frac45,\frac15\right).
\]
For all sufficiently large \(k\), \(K\subset B_{r_k,q_k}\).  The derivative \(f_\alpha'\) is bounded on \(K\), while
\[
|f_\alpha'(r_k)|
=\alpha\varepsilon_k^{\alpha-1}\to\infty.
\]
Thus eventually
\[
|f_\alpha'(z)-f_\alpha'(r_k)|
\ge\frac12|f_\alpha'(r_k)|
\qquad(z\in K).
\]
Therefore
\[
\int_{B_{r_k,q_k}}
|f_\alpha'(z)-f_\alpha'(r_k)|^2\,dA(z)
\ge
\frac{|K|}{4}|f_\alpha'(r_k)|^2.
\]
With the v193 dimensionless normalization
\[
\mathcal E(r,q)
:=\frac1{(1-r^2)^2|f'(r)|^2}
\int_{B_{r,q}}|f'(z)-f'(r)|^2\,dA(z),
\]
and \(|K|=\pi/400\), we obtain for all sufficiently large \(k\)
\[
\boxed{
\mathcal E(r_k,q_k)
\ge \frac{\pi}{6400\,\varepsilon_k^2}
=\frac\pi{6400}R_k^4.}
\]

### Theorem 6.2 — explicit recycling obstruction

There is a bounded Jordan domain of finite area and a uniformly pseudohyperbolically separated parabolic-runaway sequence for which

1. all natural v193 strain regions eventually contain the same fixed disk \(K\);
2. the normalized strain energies diverge at least like \(R_k^4\);
3. the global Bergman budget \(\int_{\mathbb D}|f'|^2\) remains finite.

Hence the v193 normalized strain energy is **not itself a globally summable charge**.  The same fixed physical region can be counted again and again because the subtraction constant \(f'(r_k)\) changes with the center.

This kills the naive form of the v194 area-budget strategy.

It does **not** produce a square-free Jordan curve, and it does not refute the v193 local square theorem.  It shows only that local strain lower bounds plus center separation cannot by themselves yield a global contradiction.

---

## 7. Exact mean-variance decomposition: what part of strain is globally chargeable?

Let \(B_{r,q}\) have Euclidean center \(C=C(r,q)\) and radius \(S=S(r,q)\).  Because \(f'\) is analytic, its area mean over this Euclidean disk is exactly its value at the center:
\[
\frac1{\pi S^2}\int_{B_{r,q}} f'(z)\,dA(z)=f'(C).
\]
Therefore the strain admits an exact Pythagorean decomposition.

### Theorem 7.1 — variance/transport decomposition

\[
\boxed{
\int_{B_{r,q}}|f'(z)-f'(r)|^2\,dA(z)
=
V(r,q)+T(r,q),}
\]
where
\[
\boxed{
V(r,q)
:=\int_{B_{r,q}}|f'(z)-f'(C)|^2\,dA(z)}
\]
and
\[
\boxed{
T(r,q)
:=\pi S(r,q)^2|f'(C)-f'(r)|^2.}
\]
Moreover
\[
\boxed{
V(r,q)
=
\int_{B_{r,q}}|f'(z)|^2\,dA(z)
-
\pi S(r,q)^2|f'(C)|^2
\le
\int_{B_{r,q}}|f'(z)|^2\,dA(z).}
\]

Thus only the variance term \(V\) is automatically chargeable to the global area measure when the underlying Euclidean disks have bounded overlap.  The transport term \(T\) is precisely the part that the cusp example can recycle.

Combining with v193 gives a new dichotomy.  If a runaway square forces
\[
\int_{B_{r,q}}|f'-f'(r)|^2\,dA
\ge
L(r,R),
\]
where
\[
L(r,R)
=
\frac{\pi(1-r^2)^2|f'(r)|^2R^2}
{1152\log((R^2+16)/8)},
\]
then at least one of
\[
\boxed{V(r,q)\ge\frac12L(r,R)}
\]
or
\[
\boxed{T(r,q)\ge\frac12L(r,R)}
\]
must hold.

Call these respectively the **variance-rich** and **transport-rich** runaway branches.

If a selected variance-rich family has overlap multiplicity at most \(M\), then
\[
\boxed{
\sum_k
\frac{(1-r_k^2)^2|f'(r_k)|^2R_k^2}
{\log((R_k^2+16)/8)}
\le
\frac{2304M}{\pi}\operatorname{Area}(\Omega).}
\]
So a genuine global budget survives on the variance-rich branch.

The transport-rich branch is the new obstruction.

---

## 8. Why pure coefficient bounds cannot improve the \(\sqrt R\) activation threshold

v193's lower spectral cutoff \(N_-(R)=\Theta(\sqrt R)\) came from the sharp coefficient bound \(|b_n|\le n\).  One might hope that restricting to bounded Jordan domains gives a substantially smaller universal bound on the first many coefficients.  It does not.

For \(0<s<1\), define the analytic Jordan approximation to the Koebe map
\[
\boxed{
k_s(z)=\frac{z}{(1-sz)^2}
=\sum_{n\ge1}n s^{n-1}z^n.}
\]
It is univalent on a neighborhood of \(\overline{\mathbb D}\), has bounded analytic Jordan image, and
\[
\boxed{b_n(k_s)=n s^{n-1}.}
\]
Given any finite \(N\) and \(\eta>0\), choosing \(s\) sufficiently close to \(1\) gives
\[
\boxed{b_n(k_s)\ge(1-\eta)n
\qquad(1\le n\le N).}
\]
Thus the de Branges linear envelope is asymptotically saturable on an arbitrarily long initial block even inside the bounded analytic-Jordan class.

### Consequence

No improvement from \(N_-(R)=\Theta(\sqrt R)\) to a larger power of \(R\) can come merely from replacing \(|b_n|\le n\) by a better *individual* universal coefficient bound for bounded Jordan domains.  Any stronger activation theorem must exploit correlations between coefficients (for example Grunsky structure) or the exact four-point square moments \(M_{n,2},M_{n,3}\).

---

## 9. Revised frontier after v194

The original v194 hope was
\[
\text{separated centers}
\Longrightarrow
\text{bounded-overlap strain packets}
\Longrightarrow
\text{finite area contradiction}.
\]
The first implication is false in the runaway regime.

The corrected architecture is
\[
\boxed{
\text{runaway square}
\Longrightarrow
\begin{cases}
\text{subparabolic }(X\to0),\\
\text{parabolic/superparabolic }(X\not\to0),
\end{cases}}
\]
and independently
\[
\boxed{
\text{v193 strain}
=
\text{variance}
+
\text{transport}.}
\]

The most promising next questions are therefore:

1. **Subparabolic localization.**  Can the v189 lobe stack force enough separated subparabolic events that their variance regions can be packed?
2. **Transport-rich classification.**  If most runaway events are transport-rich, does repeated derivative transport force a cusp/power-law tangent model?  Such models should then be attacked directly by the four-point square transform rather than by area packing.
3. **Square-specific spectral correlations.**  Improve the \(\sqrt R\) mode floor using the two coupled DFT equations, not coefficient magnitudes alone.
4. **Harmonic-measure bridge to v189.**  The lobe arcs are disjoint boundary arcs.  Their conformal angular lengths therefore have a finite total budget.  The issue is to combine this harmonic-measure budget with physical lobe depth/spacing in a way that cannot be recycled by a single cusp singularity.

v194 therefore records both a theorem and a route correction: the Bergman-center sampling estimate is valid, but the natural runaway strain disks are too large to inherit that packing.  The globally chargeable object is the mean-corrected variance, not the raw center-subtracted strain.
