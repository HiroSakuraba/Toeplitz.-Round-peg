# Status corrections v194

1. **Do not say that pseudohyperbolically separated runaway centers give bounded-overlap v193 strain regions.**  This is false.  A uniformly separated parabolic sequence can have every strain disk converge to the same fixed horodisk.

2. **Do not treat the v193 normalized strain as a globally summable area charge.**  The cusp model shows that the same fixed physical region can generate divergent normalized strain at infinitely many separated centers while \(f'\in A^2\).

3. **The correct second scale is**
   \[
   X=(1-r)R^2=\delta^2/(1-r).
   \]
   Runaway \(R\to\infty\) by itself does not determine whether the strain region is local or global.

4. **The globally chargeable part of the strain is the Euclidean mean-corrected variance**
   \[
   V=\int_B|f'-f'(C_B)|^2,
   \]
   not the full \(\int_B|f'-f'(r)|^2\).

5. **The v193 \(\sqrt R\) spectral activation floor cannot be improved merely by a better individual coefficient bound valid for bounded Jordan domains.**  Analytic Jordan approximants to Koebe saturate \(|b_n|\approx n\) on arbitrarily long finite coefficient blocks.

6. **v194 is a route correction, not a Toeplitz proof.**  It banks a center-sampling theorem, identifies the parabolic threshold, and kills the naive strain-packing inference.
