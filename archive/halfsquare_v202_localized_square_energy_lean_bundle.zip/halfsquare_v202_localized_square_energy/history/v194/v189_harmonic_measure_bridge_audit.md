# v189 → conformal harmonic-measure bridge: what is automatic and what is not

v194 also checked the most immediate way to connect the v189 lobe stack to the conformal/Fourier coordinates.

## 1. Automatic angular compression

Let
\[
D_1\supset\cdots\supset D_N
\]
be the selected same-sign v189 lobe chain.  The off-line boundaries \(\sigma_j\) are pairwise disjoint subarcs of the original Jordan curve.  Under a Carathéodory boundary parametrization
\[
F(e^{it})=f(e^{it}),
\]
they correspond to pairwise disjoint angular intervals \(I_j\subset S^1\).  Therefore
\[
\boxed{\sum_{j=1}^N |I_j|\le2\pi.}
\]
Consequently at least half of them satisfy
\[
\boxed{|I_j|\le\frac{4\pi}{N}.}
\]
For the v189 multiplicity bound
\[
N\ge\frac{2\varepsilon_0}{\pi r^2},
\]
this gives at least \(N/2\) lobe arcs with
\[
\boxed{|I_j|\le\frac{2\pi^2}{\varepsilon_0}r^2.}
\]
Thus the topological lamination automatically creates order \(r^{-2}\) boundary excursions, many of which occupy only order \(r^2\) harmonic angle.

This is a genuine bridge between v189 and the conformal coordinates, but by itself it is only critical-scale information.

## 2. Why the obvious \(H^{1/2}\) budget is critical rather than contradictory

For
\[
f(z)=\sum_{n\ge0}a_nz^n,
\]
finite area is exactly
\[
\operatorname{Area}(\Omega)
=\pi\sum_{n\ge1}n|a_n|^2.
\]
The boundary trace has the equivalent half-Sobolev identity
\[
\boxed{
\frac1{4\pi^2}
\int_0^{2\pi}\!\int_0^{2\pi}
\frac{|F(e^{it})-F(e^{is})|^2}
{|e^{it}-e^{is}|^2}
\,dt\,ds
=
\sum_{n\ge1}n|a_n|^2.}
\]

This is an attractive global Fourier budget.  However, the v189 scaling is exactly critical for it.

In the critical rainbow,
\[
N\asymp r^{-2}
\]
and each macroscopic lobe has diameter of order \(r\).  Any localized half-Sobolev charge that scales only like
\[
\text{(excursion amplitude)}^2\asymp r^2
\]
therefore sums to
\[
N r^2\asymp1.
\]
That is fully compatible with one finite global \(H^{1/2}\)/area budget.

Moreover, \(H^{1/2}\) in one dimension is scale invariant: compressing a bump-like excursion into a shorter angular interval does not automatically create a power-law penalty.  Therefore the mere fact that \(|I_j|=O(r^2)\) is not enough.

## 3. What a useful bridge must add

A successful v189/Fourier bridge needs a gain beyond critical scaling.  Plausible sources are:

1. **simultaneous nesting:** all selected chord-closed lobes contain the same point;
2. **ordered transverse spacing:** actual arc layers occur with an \(O(r^3)\) gap somewhere;
3. **square-free geometry:** the boundary is not merely an arbitrary family of compressed bumps;
4. **two-channel phase information:** the square DFT imposes coupled \(k=2,3\) cancellation, not a scalar energy constraint.

An inequality that charges only each lobe separately by \(O(r^2)\) cannot close the proof.  The needed estimate must detect an interaction between many lobes, or obtain a logarithmic/supercritical enhancement from the square-free constraint.
