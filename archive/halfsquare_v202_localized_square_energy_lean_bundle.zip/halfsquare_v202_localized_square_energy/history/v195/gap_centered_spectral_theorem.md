# v195 — Gap-centered Möbius normalization and the \(R^{2/3}\) spectral floor

## 1. Setup

Let \(f:\mathbb D\to\Omega\) be univalent, with \(\Omega\) a bounded Jordan domain.  Suppose four points
\[
z_j=r e^{i\theta_j},\qquad j=0,1,2,3,
\]
map to the vertices of an exact nondegenerate square under \(f\).  Let \(\delta\in(0,1/8]\) be the length of the minimal circular arc containing the four parameters, and put
\[
\varepsilon:=1-r,\qquad R:=\frac{\delta}{\varepsilon}.
\]
The runaway regime is \(R\to\infty\).

v193 centered the Möbius microscope at the midpoint of the minimal arc.  That normalization is natural geometrically but can leave one square parameter close to the microscope center, preventing cancellation of low Fourier modes.  The key observation of v195 is that the center is free: it need not be a square parameter or the midpoint of the packet.

## 2. Largest-gap center

Order the four angular parameters along their minimal containing arc:
\[
x_1<x_2<x_3<x_4,\qquad x_4-x_1=\delta.
\]
The three internal gaps sum to \(\delta\), so one has length at least \(\delta/3\).  Choose \(y\) to be the midpoint of such a largest internal gap and rotate so that \(y=0\).  Writing
\[
t_j:=\theta_j-y,
\]
we have
\[
\boxed{\operatorname{range}(t_j)=\delta,\qquad |t_j|\le\delta,\qquad |t_j|\ge\delta/6\ \text{for every }j.}
\]
This elementary choice is the source of the stronger spectral cancellation.

Define
\[
\phi_r(u)=\frac{r+u}{1+ru},
\qquad
u_j:=\phi_r^{-1}(r e^{it_j})
=\frac{r(e^{it_j}-1)}{1-r^2e^{it_j}}.
\]
After rotating the original map, normalize it at the interior point \(r\):
\[
F(u)=\frac{\tilde f(\phi_r(u))-\tilde f(r)}{(1-r^2)\tilde f'(r)}
=u+\sum_{n\ge2}b_nu^n.
\]
The normalized identity baseline is
\[
G_r(u)=\frac{u}{1+ru}
=\sum_{n\ge1}(-r)^{n-1}u^n.
\]
Put
\[
d_n:=b_n-(-r)^{n-1},\qquad n\ge2.
\]
By de Branges,
\[
|d_n|\le n+1.
\]

For the four-point DFT define
\[
\widehat Z_k=\frac14\sum_{j=0}^3 Z_j i^{-kj},
\qquad
M_{n,k}=\frac14\sum_{j=0}^3\nu_j^n i^{-kj}.
\]
Because \(F(\nu_j)\) are square vertices,
\[
\widehat{F(\nu)}_2=\widehat{F(\nu)}_3=0.
\]
Hence
\[
\sum_{n\ge2}d_nM_{n,k}=-\widehat{G_r(\nu)}_k,
\qquad k=2,3.
\]

## 3. Baseline square-error remains order \(R\)

For any real four-vector of range \(\delta\), Parseval gives
\[
\sqrt{|\widehat t_2|^2+|\widehat t_3|^2}\ge\frac\delta4.
\]
Since \(|t_j|\le\delta\le1/8\),
\[
e^{it_j}-1=it_j+E_j,
\qquad |E_j|\le\frac{t_j^2}{2}\le\frac{\delta^2}{2}.
\]
Therefore
\[
\sqrt{\left|\widehat{(e^{it}-1)}_2\right|^2+
      \left|\widehat{(e^{it}-1)}_3\right|^2}
\ge \frac\delta8.
\]
At the interpolation points,
\[
G_r(\nu_j)=\frac{r(e^{it_j}-1)}{1-r^2},
\]
so
\[
\boxed{
\sqrt{|\widehat G_2|^2+|\widehat G_3|^2}
\ge\frac{r\delta}{8(1-r^2)}
\ge\frac{R}{24}.}
\]
Thus the gap-center does not weaken the order-\(R\) forcing from v193.

## 4. All four preimages are close to the same boundary point

The exact identity
\[
1+\nu_j
=\frac{(1-r)(1+r e^{it_j})}{1-r^2e^{it_j}}
\]
combined with
\[
|1-r^2e^{it}|^2=(1-r^2)^2+4r^2\sin^2(t/2)
\]
gives, for \(|t|\le1/8\) and \(r\ge1/2\),
\[
|1-r^2e^{it}|\ge\frac{|t|}{\pi}.
\]
Using \(|t_j|\ge\delta/6\),
\[
\boxed{|1+\nu_j|\le\frac{12\pi}{R}.}
\]
Hence every one of the four interpolation points approaches the same boundary point \(-1\) as \(R\to\infty\).

For every \(n\ge1\), since \(|\nu_j|<1\),
\[
|\nu_j^n-(-1)^n|
\le n|\nu_j+1|
\le\frac{12\pi n}{R}.
\]
The constant vector \(((-1)^n,\dots,(-1)^n)\) has zero DFT in modes \(2\) and \(3\).  Consequently
\[
\boxed{|M_{n,k}|\le\frac{12\pi n}{R},\qquad k=2,3.}
\]
This is the new square-specific gain.  v193 only used \(|M_{n,k}|\le\rho^n\le1\).

## 5. The \(R^{2/3}\) low-frequency exclusion

For any \(N\ge2\), the contribution of modes \(2\le n\le N\) to the two square-error channels satisfies
\[
\begin{aligned}
\left\|\sum_{n=2}^N d_n(M_{n,2},M_{n,3})\right\|_2
&\le \frac{12\pi\sqrt2}{R}
\sum_{n=2}^N n(n+1)\\
&\le \frac{12\pi\sqrt2}{R}\,\frac{N(N+1)(N+2)}3.
\end{aligned}
\]
Thus for
\[
N_*(R):=\left\lfloor\frac{R^{2/3}}{64}\right\rfloor,
\]
the entire initial block contributes \(o(R)\); in particular, for all sufficiently large \(R\),
\[
\left\|\sum_{n=2}^{N_*(R)} d_n(M_{n,2},M_{n,3})\right\|_2
\le\frac{R}{48}.
\]
But the baseline vector has norm at least \(R/24\).  Therefore the modes above \(N_*(R)\) must supply at least half of the cancellation:
\[
\boxed{
\left\|\sum_{n>N_*(R)} d_n(M_{n,2},M_{n,3})\right\|_2
\ge\frac{R}{48}.}
\]
If
\[
\rho:=\max_j|\nu_j|,
\]
then \(\|(M_{n,2},M_{n,3})\|_2\le\sqrt2\rho^n\), hence
\[
\boxed{
\sum_{n>N_*(R)}|d_n|\rho^n
\ge\frac{R}{48\sqrt2}.}
\]

### Theorem 5.1 — gap-centered spectral activation

Every sufficiently large runaway square admits a Möbius normalization for which a weighted spectral defect of order \(R\) is forced strictly above frequencies
\[
\boxed{n\asymp R^{2/3}.}
\]

This improves the unconditional v193 low-frequency exclusion
\[
N_-(R)=\Theta(\sqrt R)
\]
to
\[
\boxed{N_-(R)=\Omega(R^{2/3}).}
\]
The improvement comes neither from a stronger coefficient bound nor from regularity of the Jordan boundary.  It comes from using the four-point geometry to choose a normalization in a parameter gap, after which the constant part of \(\nu_j^n\) cancels exactly in the two square-error DFT channels.

## 6. Upper frequency remains \(O(R^2\log R)\)

Because \(|t_j|\le\delta\), the exact formula for \(|\nu_j|\) gives
\[
1-\rho\gtrsim R^{-2}.
\]
Combining this with \(|d_n|\le n+1\) gives the same exponentially damped upper tail as v193.  Thus the active spectral corridor can be sharpened to
\[
\boxed{
R^{2/3}\lesssim n\lesssim R^2\log R.}
\]
At least one dyadic band in this corridor carries weighted defect \(\Omega(R/\log R)\).

## 7. Interpretation

The square cannot be repaired by a fixed jet, and v195 shows that it cannot even be repaired by the first \(O(R^{2/3})\) normalized modes.  Runaway forces genuinely finer spectral structure than v193 could certify.

The gap-center trick is robust because it uses only four facts:

1. there are exactly four square parameters;
2. their minimal containing arc has three internal gaps;
3. one gap has length at least \(\delta/3\);
4. square-error is encoded by DFT modes \(2\) and \(3\), which annihilate constants.

That combination is specific to the square problem and is unavailable to a scalar one-channel energy estimate.
