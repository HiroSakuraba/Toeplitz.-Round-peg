# Handoff v195 — gap-centered spectrum and power-tangent exclusion

## Executive result

v195 makes two positive advances and one important route correction.

### 1. Unconditional spectral floor upgrade

Given any runaway exact square with minimal conformal angular span \(\delta\) and
\[
R=\delta/(1-r)\to\infty,
\]
place the Möbius normalization point at the midpoint of the largest internal parameter gap.  Then all four normalized preimages satisfy
\[
\nu_j=-1+O(R^{-1}).
\]
Because the square-error DFT modes 2 and 3 annihilate the common constant \((-1)^n\),
\[
M_{n,k}=O(n/R).
\]
Thus the first \(N\) coefficient modes can cancel only \(O(N^3/R)\), whereas the baseline square error is \(\Omega(R)\).  Therefore
\[
\boxed{N\gtrsim R^{2/3}.}
\]
A conservative explicit version gives
\[
\sum_{n>\lfloor R^{2/3}/64\rfloor}|d_n|\rho^n
\ge\frac{R}{48\sqrt2}
\]
for all sufficiently large \(R\).

The active local spectral corridor is now
\[
\boxed{R^{2/3}\lesssim n\lesssim R^2\log R.}
\]
This replaces the v193 \(\sqrt R\) low-frequency floor.

### 2. Power/cusp tangent branch is killed

If a boundary point has a genuine power tangent
\[
f(z)=p+A(1-z)^\alpha(1+o(1)),\qquad0<\alpha<2,
\]
a centered runaway square packet would rescale to a nondegenerate square whose vertices all lie on two rays.  This is impossible.

Thus the v194 cusp calibration can recycle raw strain but cannot realize the square-specific runaway geometry.  If a future square-specific transport rigidity theorem forces a power tangent, that branch is already excluded.

### 3. Scalar transport-richness is not enough

The v194 threshold
\[
T\ge L/2
\]
requires a relative derivative change tending to zero in every runaway regime.  Even the smooth analytic map
\[
f(z)=z+az^2
\]
is eventually transport-rich on the parabolic calibration.  Hence one cannot derive cusp rigidity from \(T\ge L/2\) alone.

Future transport work must use the exact two-channel square equations or repeated-scale coherence.

## Strategic meaning

The strongest new object is the **parameter gap**.  Four points on an interval automatically leave an internal gap of size at least one third of the total span.  Centering conformal coordinates there converts runaway from a generic high-hyperbolic-diameter event into a coherent four-point collision at one boundary point of the normalized disk.  The two square DFT channels then erase the leading constant term automatically.

This is the first spectral exponent improvement in the program that comes directly from four-point square geometry rather than from stronger analytic regularity.

## Still open

1. whether the \(2/3\) exponent can be improved by cancelling the first-order \(O(n/R)\) term;
2. a square-specific transport-rigidity theorem;
3. off-center power-tangent packets;
4. the bridge from the v189 lobe lamination to enough controlled conformal square tests.

## Recommended next move

Attack the first-order gap-centered expansion and the off-center homogeneous tangent classification in parallel.  Both are finite, explicit problems and both feed directly into the remaining runaway branch.
