# v196 targets

## Target 1 — iterate the gap-center expansion

v195 uses only the zeroth-order cancellation
\[
\nu_j^n=(-1)^n+O(n/R).
\]
Expand one order farther:
\[
\nu_j^n=(-1)^n\left(1+n\eta_j+\frac{n(n-1)}2\eta_j^2+\cdots\right),
\qquad \eta_j=O(R^{-1}).
\]
Ask whether the freedom to choose the gap-center \(y\), together with the two square-error channels, can cancel part of the first-order term.  Any systematic first-order cancellation would improve the spectral floor beyond \(R^{2/3}\), potentially toward \(R^{3/4}\).

## Target 2 — square-specific transport rigidity

The scalar transport-rich inequality is too weak.  Add the exact two-channel equations and study the normalized derivative ratio along the radial segment.  Aim for:

- either a nontrivial Grunsky/variance charge;
- or convergence to a homogeneous power tangent.

The second branch is now killed by the v195 power-tangent exclusion theorem.

## Target 3 — off-center power tangents

Generalize the power-tangent exclusion from packets centered at the singular boundary point to packets whose centers approach the singularity at an arbitrary rate relative to their angular spans.  Expected limiting models are either a line, one ray, two rays, or a translated power profile.  Classify which of those can contain nondegenerate squares.

## Target 4 — v189 parameter-gap bridge

The v189 lobe arcs already give many disjoint harmonic intervals.  Try to associate a four-point square test to selected quadruples whose parameter gaps are quantitatively controlled by those intervals.  The gap-centered theorem then converts each such test into a high-frequency demand at scale \(R^{2/3}\), stronger than the critical \(H^{1/2}\) per-lobe budget.

## Success criterion

A meaningful v196 advance is one of:

1. a spectral floor exponent strictly larger than \(2/3\);
2. a square-specific transport-rigidity lemma whose rigid branch is covered by the power-tangent exclusion;
3. a general off-center homogeneous-tangent exclusion;
4. a quantitative v189-to-gap-centered spectral bridge.
