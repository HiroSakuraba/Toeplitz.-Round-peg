# v195 — Power/corner tangents cannot support runaway square packets

## 1. Motivation

v194 used
\[
f_\alpha(z)=1-(1-z)^\alpha,
\qquad 0<\alpha<1,
\]
as an explicit finite-area calibration showing that raw derivative transport can be recycled.  That example did **not** contain actual runaway square events.  v195 closes that logical gap: the very power-law geometry that recycles transport is incompatible with a runaway exact-square packet centered at its singular boundary point.

More generally, suppose a Jordan Riemann map has the boundary asymptotic
\[
\boxed{
f(z)=p+A(1-z)^\alpha(1+o(1)),
\qquad A\ne0,
\qquad 0<\alpha<2,}
\]
as \(z\to1\) from inside the disk.  The \(o(1)\) is meant in the usual full two-dimensional sense, so it is uniform along every sequence approaching \(1\).

We show that exact square packets collapsing at \(1\) cannot have
\[
\frac{\delta}{1-r}\to\infty.
\]

## 2. Geometric lemma: a square cannot lie on two rays

### Lemma 2.1

Let \(L_+\) and \(L_-\) be two rays with common endpoint \(0\).  Their union contains no four distinct vertices of a nondegenerate square.

### Proof

If four square vertices lie on two rays, at least two lie on the same ray.  Three cannot lie on one ray, so exactly two lie on each.

The line through two vertices of a square is either a side-line or a diagonal-line.

- If the two vertices on \(L_+\) form a side, the remaining two vertices lie on the opposite side-line, which is parallel to the first.  But the supporting lines of \(L_+\) and \(L_-\) meet at the common endpoint \(0\); distinct intersecting lines cannot be parallel.
- If the two vertices on \(L_+\) are opposite vertices, their line is a diagonal and passes through the square center.  The other two vertices lie on the perpendicular diagonal.  Since the two ray-supporting lines meet at \(0\), this would force \(0\) to be the square center.  Opposite vertices then lie on opposite half-rays from \(0\), contradicting that both lie on the same ray \(L_+\).

The collinear-ray case is even simpler.  Hence no nondegenerate square is contained in two rays. \(\square\)

## 3. Runaway scaling of a power tangent

Suppose, toward contradiction, that there is a sequence of exact square packets
\[
z_{k,j}=r_k e^{it_{k,j}},\qquad j=0,1,2,3,
\]
with
\[
r_k\uparrow1,
\qquad
\operatorname{range}(t_{k,j})=\delta_k\downarrow0,
\qquad
|t_{k,j}|\le\delta_k/2,
\]
and
\[
R_k:=\frac{\delta_k}{1-r_k}\to\infty.
\]
The centering means the two extreme parameter values are \(-\delta_k/2\) and \(+\delta_k/2\).

Write
\[
\varepsilon_k=1-r_k,
\qquad
s_{k,j}=\frac{t_{k,j}}{\delta_k}\in[-1/2,1/2].
\]
After a subsequence, \(s_{k,j}\to s_j\).

Since \(\varepsilon_k/\delta_k\to0\),
\[
\frac{1-r_ke^{it_{k,j}}}{\delta_k}
=\frac{\varepsilon_k}{\delta_k}-is_{k,j}+o(1)
\longrightarrow -is_j.
\]
Normalize the four physical vertices by the similarity
\[
W_{k,j}
:=\frac{f(z_{k,j})-p}{A\delta_k^\alpha}.
\]
The power tangent gives
\[
\boxed{W_{k,j}\longrightarrow(-is_j)^\alpha.}
\]
The limiting set lies in the union of the two rays
\[
\arg w=\pm\frac{\pi\alpha}{2}
\]
(with the origin allowed when \(s_j=0\)).

Every \(W_k=(W_{k,0},\dots,W_{k,3})\) is still an exact square because the normalization is a similarity.

## 4. The limit square is nondegenerate

The two extreme parameters have scaled limits \(s=-1/2\) and \(s=+1/2\).  Their limiting images differ by
\[
\left|(i/2)^\alpha-(-i/2)^\alpha\right|
=2^{1-\alpha}\sin\frac{\pi\alpha}{2}>0
\]
for every fixed \(0<\alpha<2\).

Hence the diameter of the normalized square sets is bounded below away from zero.  A convergent subsequence therefore limits to a **nondegenerate** square.

But all four limiting vertices lie on two rays, contradicting Lemma 2.1.

### Theorem 4.1 — power-tangent exclusion

If
\[
f(z)=p+A(1-z)^\alpha(1+o(1)),
\qquad 0<\alpha<2,
\]
then there is no sequence of exact square packets centered at the boundary point \(1\) with
\[
\delta\downarrow0,
\qquad
\frac{\delta}{1-r}\to\infty.
\]
Equivalently, a pure power/corner tangent cannot be the terminal geometry of a runaway square branch.

## 5. Consequence for the v194 cusp calibration

For
\[
f_\alpha(z)=1-(1-z)^\alpha,
\qquad0<\alpha<1,
\]
the v194 transport calculation remains correct: the map can recycle arbitrarily large normalized transport strain over the same physical region.

But Theorem 4.1 shows that this recycling geometry cannot simultaneously realize the runaway exact-square packet whose Fourier equations generated the v193 strain lower bound.

So the v194 cusp is a valid counterexample to **raw strain packing**, but it is not a counterexample to a future **square-specific transport theorem**.

This substantially improves the strategic position: if repeated square-specific transport can be shown to converge to a power tangent, that branch is already dead.
