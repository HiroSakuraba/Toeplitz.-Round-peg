# Proof audit v195

This audit separates the proved statements from the strategic conjectures.

## A. Gap-centered spectral theorem

### A1. Largest-gap geometry

With four points on a minimal interval of length \(\delta\), the two endpoints are occupied and the three internal gaps sum to \(\delta\).  Hence a largest internal gap has length at least \(\delta/3\).  Its midpoint is at distance at least \(\delta/6\) from all four points and at distance at most \(\delta\) from each.  This step is exact.

### A2. Baseline DFT lower bound

The real-vector range lemma is label-independent.  For a real four-vector of range \(\delta\),
\[
\sqrt{|\widehat t_2|^2+|\widehat t_3|^2}\ge\delta/4.
\]
The exponential remainder on the gap-centered packet satisfies \(|E_j|\le\delta^2/2\), rather than the smaller midpoint-centered remainder used in v193.  For \(\delta\le1/8\), the conservative lower bound \(\delta/8\) is valid.

### A3. Common-boundary-point estimate

The identity
\[
1+\nu=\frac{(1-r)(1+r e^{it})}{1-r^2e^{it}}
\]
is exact.  Using \(|t|\ge\delta/6\), \(r\ge1/2\), and \(|\sin(t/2)|\ge|t|/\pi\), one gets
\[
|1+\nu|\le12\pi/R.
\]
No regularity of \(f\) enters here.

### A4. Moment cancellation

For \(|\nu|<1\),
\[
|\nu^n-(-1)^n|\le n|\nu+1|.
\]
The constant vector \((-1)^n(1,1,1,1)\) has zero DFT in modes 2 and 3, hence
\[
|M_{n,k}|\le12\pi n/R.
\]
This is the load-bearing new estimate.

### A5. Frequency exponent

With \(|d_n|\le n+1\), the low block contributes at most
\[
\frac{12\pi\sqrt2}{R}\sum_{n\le N}n(n+1)=O(N^3/R).
\]
The baseline defect is \(\Omega(R)\).  Equating scales gives \(N^3/R\asymp R\), hence
\[
N\asymp R^{2/3}.
\]
The explicit conservative choice \(N_*=\lfloor R^{2/3}/64\rfloor\) works for all sufficiently large \(R\).  The verifier checks this numerically over a wide range but the theorem is asymptotic, not a claim that 64 is sharp.

### A6. Upper corridor

Since every gap-centered \(|t_j|\le\delta\),
\[
|\nu_j|\le \frac{A}{\sqrt{1+A^2}},
\qquad A\le\frac{R}{2}.
\]
Thus \(1-\rho\gtrsim R^{-2}\), and the v193 de-Branges tail calculation still yields an \(O(R^2\log R)\) upper cutoff.  No sharper upper exponent is claimed.

## B. Power-tangent exclusion

### B1. Scaling

For a centered packet with \(\varepsilon/\delta\to0\),
\[
\frac{1-r e^{it}}{\delta}\to-is
\]
when \(t/\delta\to s\).  The assumed full asymptotic
\[
f(z)-p=A(1-z)^\alpha(1+o(1))
\]
then gives convergence to \((-is)^\alpha\).

### B2. Nondegeneracy

The two packet endpoints tend to the two ray values \((\pm i/2)^\alpha\), whose distance is
\[
2^{1-\alpha}\sin(\pi\alpha/2)>0
\]
for \(0<\alpha<2\).  Therefore the limiting square cannot collapse.

### B3. Two-ray obstruction

A nondegenerate square cannot have all four vertices on two rays with common endpoint.  The proof by side/diagonal cases is elementary and exact.

### Scope

The theorem currently assumes the shrinking packet is centered at the power-tangent boundary point.  Off-center packets are left to v196.  Do not silently generalize the statement beyond this hypothesis.

## C. Transport-rich audit

The algebraic threshold derived from \(T\ge L/2\) is exact.  Its asymptotics tend to zero in subparabolic, parabolic, and superparabolic runaway.  Therefore no fixed amount of derivative transport follows from the v194 definition.

The quadratic calibration \(f_a(z)=z+az^2\), \(|a|<1/2\), is univalent on a neighborhood of the closed disk because distinct preimages would require \(z_1+z_2=-1/a\), whose modulus exceeds 2.  On the parabolic calibration, \(T\to4\pi|a|^2/625\) while \(L\to0\).

This example is **not an actual runaway square sequence**.  It refutes only the proposed inference from the scalar transport inequality to cusp rigidity.

## D. Computer verification

`verify_v195.py` checks:

- largest-gap constants;
- exact Möbius formulas;
- common-boundary-point estimates;
- the real and circular DFT gaps;
- the \(O(n/R)\) moment estimate under random labels;
- explicit low-block constants;
- transport-threshold asymptotics in all three runaway regimes;
- the smooth quadratic calibration;
- power-tangent endpoint separation and ray phases;
- direct finite-scale convergence to the power tangent.

Current result: **2145/2145 checks pass**.

These checks support algebra and constants; they are not a replacement for the proofs above.
