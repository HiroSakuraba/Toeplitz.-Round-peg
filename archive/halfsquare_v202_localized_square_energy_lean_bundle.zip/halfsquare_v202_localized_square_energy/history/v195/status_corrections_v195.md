# Status corrections v195

1. **Do not claim transport-richness implies cusp rigidity.**  The v194 threshold is asymptotically vanishing in every runaway regime.  A smooth quadratic Jordan map can satisfy the transport-rich inequality on a parabolic calibration.

2. **The cusp calibration remains valid only as a packing counterexample.**  v195 proves that an actual power/corner tangent cannot support a centered runaway exact-square packet.

3. **The v193 \(\Theta(\sqrt R)\) low-frequency floor is no longer best in the current program.**  Gap-centered Möbius normalization improves it to an unconditional \(\Omega(R^{2/3})\) floor for the weighted square-correcting spectrum.

4. **The improvement is square-specific.**  It uses the existence of a parameter gap among four vertices and annihilation of constants by DFT modes \(2\) and \(3\); it does not follow from individual coefficient bounds.

5. **No full Toeplitz proof is claimed.**  The remaining bridge from the v189 topological lamination to enough controlled Fourier/conformal square events is still open.
