# v195 — Audit of the transport-rich rigidity target

## 1. The v194 transport-rich threshold is asymptotically weak

The v194 decomposition writes the local strain as
\[
V+T,
\qquad
T=\pi S^2|f'(C)-f'(r)|^2.
\]
A transport-rich event was defined by
\[
T\ge\frac12L(r,R),
\]
where
\[
L(r,R)=
\frac{\pi(1-r^2)^2|f'(r)|^2R^2}
{1152\log((R^2+16)/8)}.
\]
Therefore transport-richness alone implies only
\[
\boxed{
\frac{|f'(C)-f'(r)|}{|f'(r)|}
\ge
\frac{(1-r^2)R}
{48S\sqrt{\log((R^2+16)/8)}}.}
\]

Let
\[
X=(1-r)R^2.
\]
Using the v194 strain-disk asymptotics gives:

- subparabolic \(X\to0\):
  \[
  S\sim \frac{(1-r)R^2}{4},
  \qquad
  \text{threshold}\sim\frac1{6R\sqrt{\log R}}\to0;
  \]
- parabolic \(X\to x\in(0,\infty)\):
  \[
  S\to\frac{x}{x+4},
  \qquad
  \text{threshold}=O\!\left(\frac1{R\sqrt{\log R}}\right)\to0;
  \]
- superparabolic \(X\to\infty\):
  \[
  S\to1,
  \qquad
  \text{threshold}=O\!\left(\frac{\delta}{\sqrt{\log R}}\right)\to0.
  \]

Thus in every collapsing runaway regime, the condition labelled “transport-rich” can be triggered by a **vanishingly small relative derivative change**.

## 2. Smooth analytic calibration

This means transport-richness by itself cannot force a cusp or power law.  A completely smooth analytic Jordan map already demonstrates this.

Take
\[
f_a(z)=z+a z^2,
\qquad0<|a|<1/2.
\]
It is univalent on a neighborhood of the closed disk and has
\[
f_a'(z)=1+2az.
\]
On the canonical parabolic sequence
\[
r_k=1-\varepsilon_k,
\qquad
R_k=\varepsilon_k^{-1/2},
\qquad
X_k=1,
\]
the v194 disk center and radius satisfy
\[
C_k\to\frac45,
\qquad
S_k\to\frac15.
\]
Hence
\[
T_k
=\pi S_k^2|2a(C_k-r_k)|^2
\longrightarrow
\frac{4\pi|a|^2}{625}>0.
\]
Meanwhile
\[
L(r_k,R_k)
=O\!\left(\frac{\varepsilon_k}{\log(1/\varepsilon_k)}\right)
\to0.
\]
So \(f_a\) is eventually “transport-rich” along this geometric runaway calibration despite being analytic through the boundary and having no cusp singularity.

This calibration is **not** asserted to be a sequence of runaway square events.  Its purpose is narrower and decisive: the scalar inequality \(T\ge L/2\) itself contains nowhere near enough information to prove cusp rigidity.

## 3. Corrected target

Any successful transport theorem must reinsert square-specific information.  Plausible strengthened hypotheses are:

1. transport-richness **plus both exact DFT cancellation equations**;
2. coherent transport across a nested family of runaway scales;
3. control of the phase of \(f'(C)/f'(r)\), not only its modulus difference;
4. an affine-or-curved alternative for \(\log f'\), with the curved branch feeding a genuinely summable variance/Grunsky quantity.

The power-tangent exclusion proved elsewhere in v195 is then the natural terminal theorem: once a square-specific rigidity argument really does produce a power tangent, runaway is impossible.
