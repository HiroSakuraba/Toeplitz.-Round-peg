# v196 — Angular collision strata for runaway square parameters

Let the ordered four parameters occupy a minimal interval of length \(\delta\), with internal gaps
\[
g_1,g_2,g_3>0,
\qquad
g_1+g_2+g_3=\delta.
\]
Normalize
\[
\lambda_q=\frac{g_q}{\delta},
\qquad
\lambda_1+\lambda_2+\lambda_3=1.
\]
The normalized angular shape therefore lies in the open two-simplex.

If the shape-compact hypothesis fails along a sequence, pass to a subsequence so \(\lambda\) converges to the boundary of the closed simplex.  There are only three geometric collision types.

## 1. One vanishing gap: \(2+1+1\)

Exactly one \(\lambda_q\) tends to zero while the other two have positive limits.  One adjacent pair of parameters collides on a scale \(o(\delta)\), while the remaining two points stay separated on the full packet scale.

## 2. Two adjacent vanishing gaps: \(3+1\)

Either
\[
\lambda_1,\lambda_2\to0
\]
or
\[
\lambda_2,\lambda_3\to0.
\]
Three consecutive parameters form a subcluster of diameter \(o(\delta)\), separated from the fourth point at the full packet scale.

## 3. Two nonadjacent vanishing gaps: \(2+2\)

If
\[
\lambda_1,\lambda_3\to0,
\]
then the four parameters split into two tight adjacent pairs separated by a distance comparable with \(\delta\).

No other boundary type exists because all three normalized gaps cannot vanish while summing to one.

## 4. Consequence for the spectral program

v196 therefore replaces the vague phrase “transversality may fail” with a finite compactification ledger:
\[
\boxed{
\text{shape-compact interior}
\quad\text{or}\quad
2+1+1,
\ 3+1,
\ 2+2.
}
\]
Each boundary stratum carries a smaller intrinsic scale.  The next operation should not be another global Möbius normalization of the whole quartet; v193 already showed that runaway hyperbolic diameter cannot be removed that way.  Instead one should blow up the collapsing **parameter subcluster** inside the angular configuration and retain the other vertices as marked points at infinity/boundary in the compactified picture.

This is the natural v197 continuation.
