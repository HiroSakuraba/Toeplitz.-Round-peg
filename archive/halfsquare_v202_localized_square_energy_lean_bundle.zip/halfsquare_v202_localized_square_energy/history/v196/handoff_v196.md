# Project handoff — v196

## Current strongest chain

1. v189: a hypothetical bad Jordan region forces a very deep microscopic lamination.
2. v190: any sufficiently coherent smooth scalar phase is square-forcing except a classified similarity-symmetric family.
3. v191: rank-three similarity phases are generically killed by the first subleading cokernel phase.
4. v192-v194: conformal/Möbius Fourier coordinates cover arbitrary Jordan domains and isolate runaway; naive raw-strain packing fails.
5. v195: gap-centering forces spectral activity above \(R^{2/3}\); homogeneous centered power tangents cannot be terminal runaway geometries.
6. **v196:** on every normalized angular shape that stays away from collision strata, projection of the common first-order Fourier direction improves the floor to
\[
\boxed{R^{3/4}}.
\]
Power-tangent exclusion now holds at arbitrary relative offset.

## Main remaining obstruction

A disappearing square branch can still approach the boundary of the normalized angular shape simplex.  There are only three such types:
\[
2+1+1,\quad3+1,\quad2+2.
\]
These are the v197 targets.

## Conceptual change

The conformal-Fourier problem is no longer simply “can the square zero run to infinity?”  It now has a finite compactification tree:
\[
\text{shape-compact runaway}
\Rightarrow R^{3/4}\text{ high-frequency demand},
\]
while all failure of uniform first-order transversality is pushed into explicit lower-scale collision strata.

The best next move is to derive the two-scale DFT limit on each collision stratum, starting with \(2+2\), which has the most symmetry and may factor into two pair-centroid and pair-separation channels.
