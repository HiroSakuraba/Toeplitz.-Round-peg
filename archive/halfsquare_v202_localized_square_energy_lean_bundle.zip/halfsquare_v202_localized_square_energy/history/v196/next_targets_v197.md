# v197 targets

## Target 1 — blow up the three angular collision strata

Treat separately:

- \(2+1+1\): one tight pair;
- \(3+1\): one tight triple;
- \(2+2\): two tight pairs.

Introduce the subcluster scale \(\sigma\ll\delta\) and retain the remote square vertices as marked boundary/infinite points.  Derive the square-error DFT equations in the two-scale limit.

The immediate question is whether the lower-scale cluster supplies another annihilated common moment, recovering an \(R^{3/4}\) or stronger frequency floor after replacing \(R=\delta/\varepsilon\) by the appropriate two-scale ratios.

## Target 2 — classify two-scale tangent models

The arbitrary-offset power theorem kills homogeneous one-scale tangents.  The collision strata may converge instead to translated or composite profiles.  Classify the possible analytic limits of the form
\[
A(\lambda+s)^\alpha+B
\]
and two-center variants, and test the exact square equations directly.

## Target 3 — v189 to shape-simplex occupancy

Use the \(N\asymp r^{-2}\) disjoint lobe arcs to ask whether many candidate four-tuples must have all three normalized gaps bounded below.  If a positive fraction are shape compact, v196 gives the \(R^{3/4}\) demand immediately.  If almost all are collision-degenerate, that concentration itself should impose a hierarchical clustering structure on harmonic measure.

## Target 4 — coefficient correlation

v196 uses only \(|d_n|\le n+1\).  In the projected channel, investigate Grunsky inequalities for the correlated coefficients \(d_n\).  Any square-summable gain over independent de-Branges saturation could lower the energy cost of proving contradiction.

## Success criterion

A meaningful v197 advance is one of:

1. resolve one collision stratum completely;
2. prove a uniform spectral floor on all three strata;
3. show v189 forces a positive density of shape-compact four-tuples;
4. produce a square-specific Grunsky/variance inequality in the projected channel.
