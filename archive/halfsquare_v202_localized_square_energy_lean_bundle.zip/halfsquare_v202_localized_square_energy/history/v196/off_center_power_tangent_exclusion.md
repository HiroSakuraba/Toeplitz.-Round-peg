# v196 — Off-center homogeneous power tangents cannot support runaway squares

## 1. Hypothesis

Assume a boundary point has been moved to \(1\) and
\[
f(z)=p+A(1-z)^\alpha(1+o(1)),
\qquad
A\ne0,
\qquad
0<\alpha<2,
\]
as \(z\to1\) from within the disk.

Consider four parameters
\[
z_{j,m}=r_m e^{it_{j,m}}
\]
whose images are exact nondegenerate squares, and suppose the entire four-point packet approaches the same boundary point:
\[
\max_j|t_{j,m}|\to0.
\]
Let \(\delta_m\) be the minimal angular span and assume runaway collapse
\[
\frac{1-r_m}{\delta_m}\to0.
\]
No centering assumption is made relative to the singular point \(t=0\).

Write
\[
t_{j,m}=c_m+\delta_m s_{j,m},
\]
where, after passing to a subsequence,
\[
\min_j s_{j,m}\to s_-,
\qquad
\max_j s_{j,m}\to s_+,
\qquad
s_+-s_-=1.
\]
There are two cases.

## 2. Comparable offset: \(c_m/\delta_m\to\lambda\in\mathbb R\)

Uniformly over the four points,
\[
\frac{1-r_me^{it_{j,m}}}{\delta_m}
\longrightarrow
-i(\lambda+s_j).
\]
Therefore
\[
\frac{f(z_{j,m})-p}{A\delta_m^\alpha}
\longrightarrow
[-i(\lambda+s_j)]^\alpha.
\]
Every limiting point lies on one of the two rays
\[
\arg w=\pm\frac{\pi\alpha}{2}.
\]
The two extreme normalized parameters differ by one.  Their limiting power values are distinct for \(0<\alpha<2\): on one ray the radius is strictly monotone, while across the two rays equality would require the excluded phase coincidence \(\pi\alpha=0\) or \(2\pi\).

Hence the limiting square is nondegenerate and all four of its vertices lie on one or two rays with a common endpoint.  This is impossible.

## 3. Large offset: \(|c_m|/\delta_m\to\infty\)

Now the packet is much narrower than its distance from the singular parameter.  Put
\[
q_m:=1-r_me^{ic_m}.
\]
Since \((1-r_m)/\delta_m\to0\) and \(|c_m|/\delta_m\to\infty\),
\[
|q_m|\asymp |c_m|,
\qquad
\frac{\delta_m}{|q_m|}\to0.
\]
For bounded \(s\),
\[
1-r_me^{i(c_m+\delta_ms)}
=q_m-i r_me^{ic_m}\delta_m s+o(\delta_m).
\]
Taylor expansion of the power gives
\[
(1-r_me^{i(c_m+\delta_ms)})^\alpha
=q_m^\alpha
-\alpha i r_me^{ic_m}q_m^{\alpha-1}\delta_m s
+o(|q_m|^{\alpha-1}\delta_m).
\]
After subtracting the common term and dividing by the nonzero linear scale, the four images converge to the real parameters \(s_j\) on a straight line.

Because \(s_+-s_-=1\), the limiting configuration is nondegenerate.  A nondegenerate square cannot lie on a line.

## 4. Theorem

### Theorem 4.1 — arbitrary-offset power-tangent exclusion
A full homogeneous boundary tangent
\[
f(z)=p+A(1-z)^\alpha(1+o(1)),
\qquad0<\alpha<2,
\]
cannot support a disappearing runaway exact-square packet approaching that boundary point, regardless of how the packet center approaches the singular parameter relative to its width.

The only limiting models are:

- one ray;
- two rays;
- a straight line.

All exclude a nondegenerate square.

This strictly extends the centered result in v195.
