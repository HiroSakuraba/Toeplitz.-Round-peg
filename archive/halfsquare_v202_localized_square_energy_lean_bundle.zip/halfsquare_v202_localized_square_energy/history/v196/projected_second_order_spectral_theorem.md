# v196 — Projected second-order cancellation and the \(R^{3/4}\) spectral floor

## 1. Scope

Let \(f:\mathbb D\to\Omega\) be univalent, with \(\Omega\) a bounded Jordan domain.  Consider a sequence of exact nondegenerate squares on analytic Abel curves \(f(r_mS^1)\), with four boundary parameters contained in a minimal angular interval of length \(\delta_m\).  Put
\[
\varepsilon_m:=1-r_m,
\qquad
R_m:=\frac{\delta_m}{\varepsilon_m}.
\]
We study the disappearing-square runaway regime
\[
\delta_m\to0,
\qquad
R_m\to\infty.
\]
Order the four angular parameters along their minimal containing interval and write the three internal gaps as \(g_{1,m},g_{2,m},g_{3,m}\), so
\[
g_{1,m}+g_{2,m}+g_{3,m}=\delta_m.
\]

The new hypothesis for the main theorem is **shape compactness**: for some fixed \(\eta>0\),
\[
\boxed{g_{q,m}\ge \eta\delta_m\quad(q=1,2,3)}.
\]
This says that no two neighboring parameters collide on a scale asymptotically smaller than the full four-point packet.

## 2. Normalized angular shape

After translating and dividing by \(\delta_m\), write the ordered parameter positions as
\[
0=x_0<x_1=a<x_2=b<x_3=1,
\]
with
\[
a\ge\eta,
\qquad b-a\ge\eta,
\qquad1-b\ge\eta.
\]
The assignment of these ordered points to the cyclic square labels has, modulo the dihedral symmetries of a square, only three inequivalent order types:
\[
p_0=(0,1,2,3),\qquad
p_1=(0,1,3,2),\qquad
p_2=(0,2,1,3).
\]
For a center \(y\) lying safely inside one of the three parameter gaps, define the two-channel vectors
\[
V_p:=\left(\widehat{x_p}_2,\widehat{x_p}_3\right),
\qquad
Q_p(y):=
\left(
\widehat{(x_p-y)^{-1}}_2,
\widehat{(x_p-y)^{-1}}_3
\right).
\]
Here hats denote the four-point DFT in square-label order.

The load-bearing fact is that one can choose \(y\) so that these two complex vectors are uniformly transverse when the gap shape remains in a compact subset of the simplex.

## 3. First-order transversality lemma

Define the complex determinant
\[
D_p(a,b;y):=
(V_p)_2(Q_p(y))_3-(V_p)_3(Q_p(y))_2.
\]
Direct symbolic elimination gives the following resultants of the real and imaginary parts of the numerator of \(D_p\), with respect to \(y\):
\[
\begin{aligned}
\operatorname{Res}_y(p_0)
&=\pm2ab(1-a)(b-a)(1-b)(1+a-b),\\
\operatorname{Res}_y(p_1)
&=\pm2ab(1-a)(b-a)(1-b)(a+b-1),\\
\operatorname{Res}_y(p_2)
&=\pm2ab(1-a)(b-a)(1-b)(1+b-a).
\end{aligned}
\]
For \(p_0\) and \(p_2\) this is never zero in the open shape simplex.  For \(p_1\), the only interior exceptional shape locus is
\[
a+b=1.
\]
On that locus the unique common zero is
\[
y=\frac12;
\]
the determinant is not identically zero on any open gap.

Therefore, for every interior angular shape and every square-order type, there exists a gap center at which
\[
D_p(a,b;y)\ne0.
\]
Restrict \(y\) to the middle third of one of the three gaps.  The shape set
\[
K_\eta=
\{(a,b):a\ge\eta,\ b-a\ge\eta,\ 1-b\ge\eta\}
\]
is compact.  Continuity and the preceding non-identical-vanishing statement imply:

### Lemma 3.1 — uniform first-order transversality
For every \(\eta>0\) there is \(c_\eta>0\) such that for every shape in \(K_\eta\) and every square-order type, one can choose a safe gap center \(y\) satisfying
\[
\boxed{
\operatorname{dist}_{\mathbb C^2}
\left(
\frac{V_p}{\|V_p\|},
\mathbb C Q_p(y)
\right)
\ge c_\eta.
}
\]

The constant is not claimed sharp.  What matters is that it depends only on the normalized gap lower bound \(\eta\), not on \(m\), \(R_m\), or the Jordan curve.

## 4. Exact Möbius normalization

Use the physical angular center \(\theta=y\delta_m\).  After rotating it to zero, put
\[
t_j=\delta_m(x_{p(j)}-y).
\]
Normalize at the interior point \(r_m\) as in v195:
\[
F(u)=
\frac{\widetilde f(\phi_r(u))-\widetilde f(r)}
{(1-r^2)\widetilde f'(r)}
=u+\sum_{n\ge2}b_nu^n,
\]
where
\[
\phi_r(u)=\frac{r+u}{1+ru}.
\]
The four parameter preimages are
\[
\nu_j=
\frac{r(e^{it_j}-1)}{1-r^2e^{it_j}}.
\]
Write
\[
s_j:=1+\nu_j
=
\frac{(1-r)(1+r e^{it_j})}{1-r^2e^{it_j}}.
\]
Because the chosen center stays a fixed fraction of \(\delta\) away from every parameter,
\[
\boxed{|s_j|\le \frac{C_\eta}{R}.}
\]
Moreover, since \(\delta\to0\) and \(R\to\infty\), uniformly over the compact shape family,
\[
\frac{R}{2i}s_j
\longrightarrow
\frac1{x_{p(j)}-y}.
\]
Thus the exact first-order two-channel vector
\[
S:=\left(\widehat s_2,\widehat s_3\right)
\]
converges in direction to \(Q_p(y)\).

The identity baseline satisfies
\[
G_r(\nu_j)=\frac{r(e^{it_j}-1)}{1-r^2},
\]
so its two-channel vector \(B=(\widehat G_2,\widehat G_3)\) obeys
\[
\frac{B}{R}\longrightarrow \frac{i}{2}V_p
\]
up to a harmless common unit phase.  Hence Lemma 3.1 implies that, for all sufficiently large \(m\), if \(P\) denotes orthogonal projection in \(\mathbb C^2\) onto the complex orthogonal complement of \(S\), then
\[
\boxed{\|PB\|\ge c'_\eta R.}
\]

## 5. Project away the first-order Fourier direction

For each Taylor mode define
\[
M_n:=\left(M_{n,2},M_{n,3}\right),
\qquad
M_{n,k}=\frac14\sum_{j=0}^3\nu_j^ni^{-kj}.
\]
Since \(\nu_j=-1+s_j\),
\[
\nu_j^n=(-1)^n(1-s_j)^n.
\]
The constant term has zero DFT in modes \(2,3\), and the linear term is exactly a scalar multiple of \(S\):
\[
M_n=(-1)^{n+1}nS+E_n.
\]
For \(n\max_j|s_j|\le1/2\), the binomial remainder gives
\[
\boxed{\|E_n\|\le C_\eta\frac{n^2}{R^2}.}
\]
By construction \(PS=0\), hence
\[
\boxed{\|PM_n\|\le C_\eta\frac{n^2}{R^2}.}
\]
This is the extra order of cancellation that v195 did not use.

Let
\[
d_n=b_n-(-r)^{n-1}.
\]
By de Branges,
\[
|d_n|\le n+1.
\]
The exact square equations are
\[
\sum_{n\ge2}d_nM_n=-B.
\]
After applying \(P\),
\[
\sum_{n\ge2}d_nPM_n=-PB.
\]
Therefore the first \(N\) modes contribute at most
\[
\begin{aligned}
\left\|
\sum_{n=2}^{N}d_nPM_n
\right\|
&\le
\frac{C_\eta}{R^2}
\sum_{n=2}^{N}(n+1)n^2\\
&\le
C'_\eta\frac{N^4}{R^2}.
\end{aligned}
\]
The projected baseline is \(\Omega_\eta(R)\).  Balancing scales gives
\[
\frac{N^4}{R^2}\asymp R,
\]
so
\[
\boxed{N\asymp R^{3/4}.}
\]

### Theorem 5.1 — shape-compact \(R^{3/4}\) spectral activation
Fix \(\eta>0\).  For every disappearing runaway exact-square sequence whose three normalized internal angular gaps are at least \(\eta\), there are constants \(c_\eta,C_\eta>0\) and an adaptive safe gap-center normalization such that, for all sufficiently large \(R\),
\[
\boxed{
\sum_{n>c_\eta R^{3/4}}
|d_n|\rho^n
\ge C_\eta R,
}
\]
where \(\rho=\max_j|\nu_j|\).

Thus the low-frequency exclusion improves from
\[
R^{2/3}
\]
to
\[
\boxed{R^{3/4}}
\]
whenever the normalized four-parameter shape stays away from the collision boundary.

## 6. Why the theorem is not unconditional

The transversality constant \(c_\eta\) deteriorates when one or more normalized gaps tend to zero.  This is not merely a weakness of the estimate.  In the boundary shape \((0,0,0,1)\), for example, the first-order reciprocal moment and the baseline direction can become asymptotically parallel under natural labelings.

Therefore the correct global statement is a dichotomy:

\[
\boxed{
\text{runaway square}
\Rightarrow
\begin{cases}
\text{shape compact} &\Rightarrow n\gtrsim R^{3/4},\\
\text{shape degenerates} &\Rightarrow \text{finite angular collision stratum.}
\end{cases}}
\]

The second branch is not an unclassified continuum.  It has only the collision types recorded in `collision_strata.md`.

## 7. Why the projection trick naturally stops at second order

Before projection, the constant DFT component vanishes automatically.  Projection removes the common first-order vector \(S\).  The image of \(P\) is a one-complex-dimensional space.  The projected second-order vector already occupies that remaining channel in general, so there is no further universal cokernel in the two square-error channels.

Thus \(R^{3/4}\) is the natural ceiling of this particular two-channel Taylor-projection mechanism.  Improving it further would require additional structure: a special relation among second moments, another geometric parameter, or information from the collision strata.
