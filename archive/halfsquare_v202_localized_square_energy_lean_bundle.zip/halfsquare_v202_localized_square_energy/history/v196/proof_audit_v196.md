# Proof audit v196

## A. \(R^{3/4}\) theorem

### A1. Scope is narrower than v195
The theorem concerns a **sequence of disappearing runaway squares** with \(\delta_m\to0\), not an arbitrary fixed-width packet with \(R\to\infty\).  This is the regime relevant to loss of nondegeneracy when passing from the analytic Abel curves to the Jordan boundary.

### A2. Shape compactness
The lower gap condition \(g_q\ge\eta\delta\) is essential to the current proof.  It provides a compact normalized shape set and a safe center a fixed fraction of \(\delta\) from every parameter.

### A3. Transversality computation
Modulo square dihedral relabeling there are three parameter-order types.  The symbolic determinant/resultant computation shows that the leading baseline vector \(V_p\) and reciprocal first-order vector \(Q_p(y)\) cannot remain complex-parallel for every \(y\) in a gap.  The interleaved type has a symmetric isolated alignment at \(a+b=1,y=1/2\), but nearby centers break it.  Compactness upgrades pointwise non-identical vanishing to a positive \(c_\eta\).

### A4. Exact first-order projection
Writing \(s_j=1+\nu_j\), the expansion
\[
\nu_j^n=(-1)^n(1-s_j)^n
\]
has a constant term killed by DFT modes 2 and 3 and a linear term exactly proportional to
\[
S=(\widehat s_2,\widehat s_3).
\]
Orthogonal projection to \(S^\perp\) therefore removes the entire first-order contribution, not merely its asymptotic leading part.

### A5. Second-order remainder
For \(n\max|s_j|\le1/2\), Taylor/binomial remainder gives \(O(n^2\max|s|^2)\).  Safe centering gives \(\max|s|=O_\eta(R^{-1})\).  Hence projected mode \(n\) is \(O_\eta(n^2/R^2)\).

### A6. Exponent
With \(|d_n|\le n+1\), the projected low block is
\[
O_\eta(N^4/R^2).
\]
The projected baseline remains \(\Omega_\eta(R)\) by transversality.  Thus \(N\ll R^{3/4}\) cannot cancel it.

### A7. No unconditional \(3/4\) claim
When normalized gaps tend to zero, the compact transversality constant can vanish.  v196 classifies rather than solves those boundary strata.

## B. Collision classification
The normalized gap vector belongs to the simplex \(\lambda_1+\lambda_2+\lambda_3=1\).  Its boundary has exactly the stated one-zero and two-zero patterns.  The geometric names \(2+1+1\), \(3+1\), and \(2+2\) are exhaustive.

## C. Off-center power tangent

### C1. Comparable offset
If \(c/\delta\) stays bounded, scaling by \(\delta^\alpha\) gives \([-i(\lambda+s)]^\alpha\), lying on one/two rays.  Extreme normalized parameters remain distinct for \(0<\alpha<2\), so the square limit is nondegenerate.

### C2. Large offset
If \(|c|/\delta\to\infty\), the packet width is small relative to the local power-law base point.  First-order Taylor expansion yields an affine line limit after subtracting the common value and rescaling by \(|q|^{\alpha-1}\delta\).

### C3. Scope
The theorem assumes the full asymptotic \(f(z)=p+A(1-z)^\alpha(1+o(1))\) along the relevant interior approaches.  It does not claim that every Jordan boundary point possesses such a tangent.

## D. Verification role
The verifier checks determinant identities/resultants, numerical transversality on compact gap sets, the projected \(O(n^2/R^2)\) scaling, the \(R^{3/4}\) balance, collision-type classification, and both off-center power limits.  It supports algebra and constants but is not a replacement for the proofs.
