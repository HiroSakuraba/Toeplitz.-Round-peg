# Status corrections and theorem ledger — v196

## Banked in v196

1. **Conditional \(R^{3/4}\) floor.**  If all three normalized internal gaps of a disappearing runaway square stay uniformly positive, an adaptive gap-center plus projection of the common first-order two-channel direction forces spectral activity above \(c_\eta R^{3/4}\).

2. **Finite collision ledger.**  Failure of normalized-gap compactness reduces, after subsequence, to exactly three angular collision strata: \(2+1+1\), \(3+1\), or \(2+2\).

3. **Arbitrary-offset power-tangent exclusion.**  The v195 two-ray obstruction extends to packets approaching a homogeneous power singularity at any relative offset.  Comparable offsets give one/two rays; much larger offsets linearize to a line.

## Corrections to the v195 forecast

- The hoped-for \(R^{3/4}\) improvement is **not presently unconditional**.  The first-order baseline/moment transversality degenerates as normalized parameter gaps collapse.
- Choosing a clever center does not remove the collision strata.  The correct next object is the compactified angular configuration, not a single universal center choice.
- The first-order projection mechanism has only one remaining complex square-error channel after projection.  There is no automatic third universal cancellation that would iterate the exponent again.

## Still open

- Prove an \(R^{3/4}\)-type or stronger bound on each collision stratum after subcluster blow-up.
- Connect v189's deep lobe lamination to quantitative occupancy of the angular shape simplex or its boundary strata.
- Derive a square-specific transport/Grunsky identity strong enough to rule out repeated collision-tree escape.
- Convert the conformal-spectral compactification into a complete nondegeneracy theorem for the Jordan limit.
