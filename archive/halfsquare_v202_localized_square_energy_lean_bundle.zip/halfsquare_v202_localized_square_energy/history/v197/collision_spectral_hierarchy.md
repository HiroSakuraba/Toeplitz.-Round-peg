# v197 — Collision-stratum spectral hierarchy

## 1. Setting

Let \(f:\mathbb D\to\Omega\) be univalent, with \(\Omega\) a bounded Jordan domain.  Consider exact nondegenerate squares on the analytic Abel curves \(f(r_mS^1)\).  Assume the four conformal parameters lie in a minimal angular interval of length \(\delta_m\), with
\[
\varepsilon_m:=1-r_m,\qquad R_m:=\frac{\delta_m}{\varepsilon_m}\to\infty,
\qquad \delta_m\to0.
\]
Order the four parameters along that interval and write the three internal gaps
\[
g_1,g_2,g_3>0,\qquad g_1+g_2+g_3=\delta,
\]
and normalized gaps
\[
\lambda_j:=\frac{g_j}{\delta},\qquad \lambda_1+\lambda_2+\lambda_3=1.
\]
As in v196, after affine normalization of the parameter packet write
\[
0=x_0<x_1=a<x_2=b<x_3=1.
\]
Modulo square dihedral symmetry, the three possible assignments of ordered parameter positions to cyclic square labels are
\[
p_0=(0,1,2,3),\qquad p_1=(0,1,3,2),\qquad p_2=(0,2,1,3).
\]
For a safe center \(y\notin\{0,a,b,1\}\), define
\[
V_p:=\left(\widehat{x_p}_2,\widehat{x_p}_3\right),\qquad
Q_p(y):=\left(\widehat{(x_p-y)^{-1}}_2,\widehat{(x_p-y)^{-1}}_3\right),
\]
where hats denote the four-point DFT in square-label order.

The v196 projected argument depends on transversality between \(V_p\) and \(Q_p(y)\).  v197 determines how that transversality behaves all the way to the boundary of the gap simplex.

## 2. The one-collision edge is not exceptional

The shape-compact hypothesis in v196 required all three normalized gaps to be bounded below.  That is stronger than necessary.

Suppose at least two normalized gaps remain bounded below:
\[
\boxed{\text{the second-largest of }\{\lambda_1,\lambda_2,\lambda_3\}\text{ is at least }\eta>0.}
\]
This includes the full interior of the simplex and every compact subset of the three open edges, hence permits one gap to tend to zero.  Geometrically this is precisely the \(2+1+1\) collision stratum.

On the edge \(a=0\), direct substitution into the DFT determinant
\[
D_p(a,b;y):=(V_p)_2(Q_p(y))_3-(V_p)_3(Q_p(y))_2
\]
gives, up to nonzero constant unit factors,
\[
D_p(0,b;y)\propto \frac{b(1-b)}{y(y-b)(y-1)}
\]
for all three order types.  Hence it is nonzero for every safe center.  On the edge \(b=a\),
\[
D_p(a,a;y)\propto \frac{a(1-a)}{y(y-a)(y-1)},
\]
and on the edge \(b=1\),
\[
D_p(a,1;y)\propto \frac{a(1-a)}{y(y-a)(y-1)}.
\]
Again the omitted factors are nonzero constants depending only on the order type.

By choosing a center in the middle third of one of the two noncollapsed gaps and using compactness of each closed edge subsegment, one obtains:

### Theorem 2.1 — edge-stable transversality
For every \(\eta>0\) there exists \(c_\eta>0\) such that whenever at least two normalized gaps are at least \(\eta\), one can choose a safe gap center \(y\) for which
\[
\boxed{
\operatorname{dist}_{\mathbb C^2}
\left(\frac{V_p}{\|V_p\|},\mathbb C Q_p(y)\right)
\ge c_\eta
}
\]
for every square-order type \(p\).

Therefore the entire v196 projected second-order argument survives unchanged on the \(2+1+1\) stratum.

### Corollary 2.2 — \(2+1+1\) retains the full spectral floor
Every disappearing runaway exact-square sequence whose normalized shape stays in a compact subset of the interior plus open edges satisfies
\[
\boxed{n\gtrsim R^{3/4}}
\]
in the precise tail-mass sense of v196.

Thus a single tight pair is **not** a genuine exceptional branch.

## 3. Only the simplex vertices are genuinely degenerate

The only remaining shape degenerations are neighborhoods of the three simplex vertices.  They correspond to:

- \(3+1\) on the left: \(a,b\to0\), so three parameters form a tight triple and the fourth is remote;
- \(3+1\) on the right: \(a,b\to1\);
- \(2+2\): \(a\to0\), \(b\to1\), so two tight pairs are separated by the full packet scale.

Define the **vertex thickness**
\[
\boxed{\tau:=1-\max(\lambda_1,\lambda_2,\lambda_3).}
\]
Thus \(\tau\to0\) precisely at a simplex vertex.  Its physical counterpart is
\[
\kappa:=\tau\delta,
\]
and the associated **inner runaway ratio** is
\[
\boxed{\Lambda:=\frac{\kappa}{\varepsilon}=R\tau.}
\]
For \(3+1\), \(\kappa\) is the diameter of the tight triple.  For \(2+2\), \(\kappa\) is the sum of the two tight-pair widths.

## 4. Outer-gap transversality is exactly first order in \(\tau\)

Choose the Möbius center in the dominant gap, a fixed fraction of \(\delta\) away from every parameter.  Then all four normalized preimages satisfy
\[
\nu_j=-1+s_j,\qquad |s_j|\le \frac{C}{R}.
\]
At a simplex vertex the baseline vector and first reciprocal-moment vector become parallel, but the loss is only linear in \(\tau\).

For the left \(3+1\) vertex write
\[
a=\alpha\tau,\qquad b=\tau,\qquad 0\le\alpha\le1,
\]
and take \(y=1/2\).  The exact shape determinant has the expansions
\[
\frac{D_{p_0}}{\tau}\to
\frac{-1+i}{2}\bigl(\alpha(1-i)+i\bigr),
\]
\[
\frac{D_{p_1}}{\tau}\to
\frac{1-i}{2}(\alpha+i),
\]
\[
\frac{D_{p_2}}{\tau}\to
-i\frac{1-i}{2}(\alpha-1-i).
\]
Their squared moduli are respectively
\[
\alpha^2-\alpha+\frac12,
\qquad
\frac{\alpha^2+1}{2},
\qquad
\frac{(\alpha-1)^2+1}{2},
\]
so they are uniformly bounded away from zero on \([0,1]\).  The right \(3+1\) vertex follows by reflection.

For the \(2+2\) vertex put
\[
a=\alpha\tau,\qquad b=1-(1-\alpha)\tau.
\]
For \(p_0\) and \(p_2\), \(y=1/2\) gives nonzero \(D_p/\tau\) uniformly in \(\alpha\).  For \(p_1\), the leading term is proportional to
\[
y-\alpha.
\]
Choosing adaptively between \(y=1/3\) and \(y=2/3\) gives
\[
\max\{|1/3-\alpha|,|2/3-\alpha|\}\ge1/6,
\]
so the same uniform linear lower bound follows.

Hence:

### Lemma 4.1 — vertex transversality law
There are universal constants \(0<c<C<\infty\) such that, for every sufficiently small \(\tau\), every vertex type, and every square-order type, one can choose a safe center in the dominant gap satisfying
\[
\boxed{c\tau\le \operatorname{trans}(V_p,Q_p(y))\le C\tau.}
\]
The lower bound is the load-bearing direction; the upper bound records that linear loss is sharp.

## 5. Outer microscope: a mixed \(R\)-\(\Lambda\) spectral floor

Normalize the Riemann map at the dominant-gap center exactly as in v195-v196:
\[
F(u)=u+\sum_{n\ge2}b_nu^n,
\qquad d_n:=b_n-(-r)^{n-1}.
\]
Let
\[
B=(\widehat G_2,\widehat G_3)
\]
be the identity-domain baseline vector and let
\[
S=(\widehat s_2,\widehat s_3).
\]
If \(P\) is orthogonal projection onto \(S^\perp\), Lemma 4.1 transfers to the exact Möbius normalization as
\[
\boxed{\|PB\|\ge c\,R\tau=c\Lambda.}
\]
As before,
\[
M_n=(-1)^{n+1}nS+E_n,
\qquad
\|PE_n\|\le C\frac{n^2}{R^2}
\]
for \(n\max|s_j|\le1/2\).  Since \(|d_n|\le n+1\), the first \(N\) modes contribute at most
\[
C\frac{N^4}{R^2}.
\]
Balancing this with the projected defect \(\Lambda\) gives the outer-collision threshold
\[
\boxed{
N_{\rm out}\asymp (\Lambda R^2)^{1/4}.
}
\]
More precisely, for sufficiently small universal \(c_0>0\),
\[
N\le c_0(\Lambda R^2)^{1/4}
\]
implies that at least a fixed fraction of the projected defect remains in the tail, and therefore
\[
\boxed{
\sum_{n>N}|d_n|\rho^n\ge c_1\Lambda,
}
\]
where \(\rho=\max_j|\nu_j|\).

This is complementary to the unconditional v195 floor \(R^{2/3}\).  In particular, the outer microscope forces activation at least up to
\[
\boxed{
\max\left\{R^{2/3},\ (\Lambda R^2)^{1/4}\right\}.
}
\]
When \(\Lambda\asymp R\), this becomes the v196 \(R^{3/4}\) scale.  When \(\Lambda\ll R\), the loss of angular-shape transversality is measured exactly by the inner scale \(\Lambda\).

## 6. Inner microscope: the cluster itself supplies a second spectral constraint

Assume now
\[
\boxed{\Lambda=R\tau\to\infty.}
\]
Then the small cluster thickness \(\kappa=\tau\delta\) is itself large compared with the radial scale \(\varepsilon\).  One may place a second Möbius microscope **inside the collapsing subcluster**, not on the whole quartet.

### 6.1 The \(3+1\) vertex

Choose the larger of the two internal gaps of the tight triple; its width is at least \(\kappa/2\).  Center in its middle third.  At this center:

- the three clustered parameters are at angular distance \(O(\kappa)\), hence their normalized \(s\)-coordinates are \(O(1/\Lambda)\);
- the remote fourth parameter is at angular distance \(\asymp\delta\), hence its \(s\)-coordinate is only \(O(1/R)\);
- the identity baseline is dominated by the remote vertex and has norm \(\asymp R\).

After rescaling the triple to \(0,\alpha,1\), the remote point becomes a marked point at infinity.  The limiting baseline direction is the DFT of a single remote label, whereas the first reciprocal-moment vector is supported on the three finite cluster labels.  Their determinant is nonzero for every order type and every \(0\le\alpha\le1\) after the adaptive safe-center choice.  Thus the inner transversality is **order one**, not order \(\tau\).

### 6.2 The \(2+2\) vertex

Choose the larger of the two tight-pair gaps; it has width at least \(\kappa/2\), and center inside it.  Scale that local pair to \(0,1\).  The other pair becomes remote.  At the midpoint \(c=1/2\), the limiting local reciprocal vector and remote-pair baseline vectors are, for the three order types, transverse with determinants
\[
-\frac{1+i}{4},\qquad -\frac{1+i}{4},\qquad \frac12,
\]
up to harmless common normalization factors.  Hence inner transversality is again uniformly order one.

### Theorem 6.1 — inner-cluster spectral activation
For either vertex type, if \(\Lambda\to\infty\), there is an inner-cluster normalization
\[
\widetilde F(u)=u+\sum_{n\ge2}\widetilde b_nu^n
\]
with baseline coefficients \(\widetilde d_n\) and preimage radius \(\widetilde\rho\) such that
\[
\boxed{\|\widetilde P\widetilde B\|\ge cR,}
\qquad
\boxed{\|\widetilde P\widetilde M_n\|\le C\frac{n^2}{\Lambda^2}.}
\]
Consequently the first \(N\) modes contribute at most \(CN^4/\Lambda^2\), and balancing against the \(O(R)\) projected baseline gives
\[
\boxed{
N_{\rm in}\asymp (R\Lambda^2)^{1/4}.
}
\]
For sufficiently small universal \(c_0\), if
\[
N\le c_0(R\Lambda^2)^{1/4},
\]
then
\[
\boxed{
\sum_{n>N}|\widetilde d_n|\widetilde\rho^n\ge c_1R.
}
\]

The outer and inner coefficient sequences belong to different normalized univalent maps.  They must **not** be identified term-by-term.  The point is that the same physical square forces large spectral activity under two different, geometrically linked Möbius microscopes.

## 7. The resulting collision hierarchy

The runaway branch now has the following finite ledger.

### A. Interior or \(2+1+1\)
If at least two normalized gaps stay bounded below,
\[
\boxed{n\gtrsim R^{3/4}.}
\]
There is no additional collision analysis.

### B. Vertex degeneration with \(\Lambda\to\infty\)
For \(3+1\) or \(2+2\), the outer microscope gives
\[
N_{\rm out}\asymp (\Lambda R^2)^{1/4}
\]
with tail mass \(\Omega(\Lambda)\), while the inner microscope gives
\[
N_{\rm in}\asymp (R\Lambda^2)^{1/4}
\]
with tail mass \(\Omega(R)\).

Since \(\Lambda\le R\),
\[
N_{\rm in}\le N_{\rm out},
\]
but the inner microscope carries the larger baseline load.  The two constraints are complementary.

### C. Vertex degeneration with \(\Lambda=O(1)\)
The collapsing subcluster has only bounded hyperbolic diameter at its own scale.  The inner high-frequency expansion no longer applies.  This is a genuine compactified tangent branch and remains open.

For \(3+1\), after centering on the triple, three marked preimages remain at finite points of a limiting horocycle while the fourth tends to the tangency point.  Local univalence alone cannot exclude this geometry: Möbius images of the horocycle are circles and can contain a square with one vertex at the tangency image.

For \(2+2\), one local pair remains finite while the remote pair collapses to the tangency point and requires an additional boundary-scale resolution.  Thus \(2+2\) retains a genuinely hierarchical compactification when \(\Lambda\) stays bounded.

## 8. What v197 changes

v196 treated all three boundary strata as unresolved exceptions.  v197 sharpens that picture:

1. \(2+1+1\) is not exceptional at all; it retains the full \(R^{3/4}\) floor.
2. Only the \(3+1\) and \(2+2\) simplex vertices genuinely lose first-order transversality.
3. The loss is quantitatively linear in the vertex thickness \(\tau\).
4. If the inner scale \(\Lambda=R\tau\) is itself runaway, the same square activates a second spectral microscope with an order-one transversality constant.
5. The only new terminal branch is therefore the **bounded-inner-scale vertex compactification** \(\Lambda=O(1)\).

This replaces a three-stratum exception list by one stable edge theorem, one two-scale vertex theorem, and one sharply defined finite-scale compactification problem.
