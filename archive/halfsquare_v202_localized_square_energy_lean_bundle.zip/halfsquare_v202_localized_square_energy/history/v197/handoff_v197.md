# Handoff v197 — collision-stratum spectral hierarchy

## Banked results

- v195: every runaway square activates spectral frequencies at least \(R^{2/3}\).
- v196: if all three normalized angular gaps stay bounded below, projection of the first reciprocal-moment direction improves this to \(R^{3/4}\).
- v197: the \(R^{3/4}\) theorem extends across the entire \(2+1+1\) edge stratum.  A single collapsing gap is not exceptional.
- Only \(3+1\) and \(2+2\) vertex degenerations remain.
- Put \(\tau=1-\max\lambda_j\) and \(\Lambda=R\tau\).  Outer-gap transversality is \(\Theta(\tau)\), yielding a projected spectral threshold \((\Lambda R^2)^{1/4}\) with tail load \(\Omega(\Lambda)\).
- If \(\Lambda\to\infty\), centering a second Möbius microscope inside the collapsing cluster gives order-one transversality, threshold \((R\Lambda^2)^{1/4}\), and tail load \(\Omega(R)\).
- These are different local coefficient sequences and should not be directly summed.
- If \(\Lambda=O(1)\), the collision becomes a finite compactified tangent problem.  This is now the sharply isolated unresolved branch.

## Best next move

Work on bounded-inner-scale compactifications, starting with \(3+1\).  Three preimages remain finite on a limiting horocycle and the fourth approaches the tangency point.  A Möbius image of the horocycle can contain a square, so exclusion must use the fact that the tangent comes from repeated blow-ups of one fixed Jordan map, not merely abstract univalence.
