# v198 targets

## Target 1 — classify the bounded-inner-scale \(3+1\) tangent

Assume \(\Lambda=R\tau\to\Lambda_*<\infty\).  Normalize at the tight triple.  Three preimages remain on a finite portion of the limiting horocycle and the remote fourth approaches its tangency point.  Derive the exact limiting square equations, including the boundary cluster value at the tangency point.

Determine which normalized univalent limits can realize this four-point configuration.  Möbius circle models show that local univalence alone is insufficient, so the target must use compatibility with being a blow-up of one fixed Jordan map or with the continuation of the square branch.

## Target 2 — resolve bounded-inner-scale \(2+2\)

Normalize at one tight pair.  The second pair collapses to the tangency point at a still smaller scale.  Derive the second boundary blow-up and the induced relation between the two pair-centroid/diagonal channels.  This is the cleanest genuinely hierarchical compactification left after v197.

## Target 3 — transition law between outer and inner spectra

The outer and inner Taylor coefficients come from two normalizations of the same Riemann map related by an explicit disk automorphism.  Derive the exact coefficient-transfer law and ask whether the two tail lower bounds can be combined through Grunsky inequalities, rather than treated as independent spectra.

## Target 4 — v189 occupancy versus vertex thickness

For the \(N\asymp r^{-2}\) nested lobe stack, translate harmonic-measure clustering into a distribution of normalized gap triples.  Either a positive density of candidate quartets lies in the edge-stable region, activating \(R^{3/4}\), or most quartets have \(\tau\ll1\), forcing a hierarchical cluster tree.  Quantify that alternative.

## Success criterion

A meaningful v198 advance is one of:

1. exclude or classify the bounded-\(\Lambda\) \(3+1\) tangent using fixed-map compatibility;
2. derive the second blow-up theorem for bounded-\(\Lambda\) \(2+2\);
3. prove a nontrivial coefficient-transfer inequality between the two v197 microscopes;
4. connect v189 lobe depth to a quantitative lower bound on edge-stable shape occupancy.
