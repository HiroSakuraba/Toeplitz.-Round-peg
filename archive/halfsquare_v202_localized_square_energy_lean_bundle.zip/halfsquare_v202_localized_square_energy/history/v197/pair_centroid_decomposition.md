# v197 — Pair-centroid decomposition for the \(2+2\) stratum

The \(2+2\) degeneration is especially transparent directly in physical square coordinates.

## Adjacent-pair order

For order types in which the two tight parameter pairs correspond to adjacent square vertices, write
\[
Z_0=A+d,\qquad Z_1=A-d,
\]
\[
Z_2=B+e,\qquad Z_3=B-e.
\]
Then the square-error DFT channels are exactly
\[
\widehat Z_2=\frac{d+e}{2},
\]
\[
\widehat Z_3=\frac{1-i}{4}\bigl(i(A-B)+d-e\bigr).
\]
Hence the square equations \(\widehat Z_2=\widehat Z_3=0\) are equivalent to
\[
e=-d,
\qquad
A-B=2id.
\]
Thus the two tiny conformal pair separations must map to equal-and-opposite physical side vectors, while the distance between their centroids is a quarter-turn of the same physical scale.

The key two-scale fact is therefore explicit: parameter widths of order \(\kappa\) and a centroid separation of order \(\delta\gg\kappa\) must be converted by the same conformal map into comparable Euclidean vectors.

## Opposite-pair order

For the interleaved order, the tight parameter pairs correspond to opposite square vertices.  Put
\[
A=\frac{Z_0+Z_2}{2},\qquad
B=\frac{Z_1+Z_3}{2}.
\]
Then
\[
\widehat Z_2=\frac{A-B}{2}.
\]
Thus every exact square satisfies
\[
\boxed{A=B.}
\]
The two tight parameter pairs must therefore map to the two diagonals of a square with exactly the same midpoint.

This identity explains why the \(2+2\) branch naturally produces two linked Möbius microscopes.  The local pair scale controls a diagonal or side vector, while the outer scale controls the relation between the two pair centroids.  v197's outer- and inner-gap spectral bounds are the Fourier version of this exact geometric decomposition.
