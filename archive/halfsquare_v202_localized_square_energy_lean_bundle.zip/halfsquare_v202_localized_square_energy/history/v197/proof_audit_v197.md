# v197 proof audit

## A. Statements regarded as banked within this program

### A1. Open-edge stability
The determinant calculations on the three open edges of the normalized gap simplex are exact.  When one gap vanishes but the other two remain positive, the two-channel baseline vector and reciprocal-moment vector are not parallel at any safe generic center.  Compactness therefore extends the v196 projected argument to every compact subset of the interior plus open edges.

This removes \(2+1+1\) from the genuinely exceptional list.

### A2. Linear vertex degeneracy
At each simplex vertex the determinant vanishes because the four-point shape has only two distinct parameter locations (\(2+2\)) or one triple location plus one remote location (\(3+1\)).  Expanding away from the vertex gives a nonzero first derivative in the vertex thickness \(\tau\).  The explicit left-\(3+1\) and \(2+2\) formulas show uniform nonvanishing over the internal split parameter \(\alpha\in[0,1]\), after the adaptive center choice for the interleaved \(2+2\) order.

Therefore the best safe dominant-gap transversality is \(\Theta(\tau)\).

### A3. Outer mixed-scale spectral estimate
The v196 mode expansion
\[
M_n=(-1)^{n+1}nS+O(n^2/R^2)
\]
remains valid because the dominant-gap center stays a fixed fraction of \(\delta\) from all four parameters.  Projecting perpendicular to \(S\) leaves a baseline of size \(\Theta(R\tau)=\Theta(\Lambda)\).  The de Branges bound then gives the low-block estimate \(O(N^4/R^2)\) and threshold
\[
N_{\rm out}\asymp(\Lambda R^2)^{1/4}.
\]

### A4. Inner-cluster microscope when \(\Lambda\to\infty\)
Choose a gap inside the collapsing subcluster whose width is at least a fixed fraction of \(\kappa=\tau\delta\).  Then the local normalized preimage deviations satisfy \(s=O(1/\Lambda)\), while the remote baseline remains order \(R\).  The limiting local reciprocal moment is uniformly transverse to the remote baseline for all three square-order types.  Thus the same projected second-order argument gives
\[
N_{\rm in}\asymp(R\Lambda^2)^{1/4}.
\]

The numerical verifier directly checks the exact Möbius formulas in both normalizations across random \(3+1\) and \(2+2\) packets.

## B. Important qualifications

### B1. Outer and inner coefficients are different
The outer and inner microscopes normalize the same fixed Riemann map at different points.  Their coefficient sequences are related, but not equal.  The two tail lower bounds cannot be summed or compared term-by-term without an explicit automorphism/coefficient-transfer theorem.

### B2. The mixed threshold does not supersede v195 automatically
The outer threshold \((\Lambda R^2)^{1/4}\) can be below \(R^{2/3}\) when \(\Lambda\) is small.  The correct necessary activation scale is the maximum of the v195 unconditional floor and the new outer projected floor.  The tail loads also differ: v195 carries an \(O(R)\) unprojected load, while the new outer projected channel carries only \(O(\Lambda)\).

### B3. \(\Lambda=O(1)\) is genuinely outside the inner high-frequency theorem
When \(\kappa/(1-r)\) stays bounded, the collapsing subcluster has bounded hyperbolic diameter at its own scale.  The estimate \(s=O(1/\Lambda)\) is not a small parameter and the second-order Fourier truncation does not produce a growing frequency floor.

This branch is therefore not solved by v197.

### B4. Local univalence cannot by itself kill bounded-\(\Lambda\) \(3+1\)
A normalized Möbius map
\[
M_c(z)=\frac{z}{1+cz},\qquad 0<c<1,
\]
maps the limiting horocycle to a Euclidean circle.  Choosing a square on that circle with one vertex at the image of the horocycle tangency point gives three finite horocycle preimages plus one tangency preimage.  Hence the abstract compactified four-point geometry is compatible with univalence.

Any exclusion theorem must use additional fixed-map information, boundary blow-up compatibility, or continuation of the square branch.

### B5. No global energy contradiction is claimed
v194 already showed that normalized local strain can recycle the same physical region.  v197 is a spectral localization theorem.  It does not restore the discarded naive area-packing argument.

## C. Independent sanity checks included in the verifier

The deterministic verifier checks:

- all three open edge types and all three square-order types;
- random edge-compact shapes with one gap as small as \(10^{-10}\);
- linear-in-\(\tau\) outer transversality near all three simplex vertices;
- order-one inner-cluster transversality;
- exact Möbius formulas for the outer and inner microscopes;
- projected second-order remainder bounds;
- the \((\Lambda R^2)^{1/4}\) and \((R\Lambda^2)^{1/4}\) scaling balances;
- exact pair-centroid DFT identities;
- the finite-\(\Lambda\) Möbius-circle calibration.

Result: see `verification_results.txt`.
