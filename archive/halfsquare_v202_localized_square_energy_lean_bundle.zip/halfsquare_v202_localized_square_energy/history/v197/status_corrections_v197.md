# v197 status corrections

1. **v196 shape compactness was not sharp.**  A single normalized gap may tend to zero without destroying first-order transversality.  The \(2+1+1\) edge stratum retains the full \(R^{3/4}\) projected spectral floor.

2. **Only simplex vertices are genuinely degenerate.**  The remaining first-order losses occur only for \(3+1\) and \(2+2\), when two normalized gaps vanish.

3. **The degeneracy has a measured strength.**  If \(\tau=1-\max\lambda_j\), the best outer-gap transversality is \(\Theta(\tau)\), so the surviving projected baseline is \(\Theta(R\tau)=\Theta(\Lambda)\).

4. **There are two different local spectra.**  The outer-gap and inner-cluster normalizations are different Möbius microscopes and have different Taylor coefficients.  Their tail bounds cannot be added coefficient-by-coefficient.

5. **No contradiction is claimed from the dual spectral bounds alone.**  They are local necessary conditions for a runaway exact square, not yet a finite global budget.

6. **The bounded-inner-scale branch is real.**  When \(\Lambda=O(1)\), the cluster does not enter another high-frequency runaway regime.  It becomes a compactified tangent problem.  Local univalence alone does not exclude the \(3+1\) model.

7. **Power-law tangent exclusion from v195-v196 remains valid.**  v197 does not reopen homogeneous power/cusp tangents; the new bounded-\(\Lambda\) tangent may be a more general nonhomogeneous univalent limit.
