# v198 — Bounded-inner-scale 2+2: cross-ratio and modulus load

## 1. Setting

Let four ordered conformal parameters on the Abel circle have angular gaps
\[
g_1,g_2,g_3>0,
\qquad
\delta=g_1+g_2+g_3.
\]
The \(2+2\) vertex regime means that the middle gap is dominant:
\[
g_1+g_3=o(\delta).
\]
Put
\[
\varepsilon=1-r,
\qquad
R=\frac{\delta}{\varepsilon}\to\infty,
\]
and assume the inner pair thickness is bounded:
\[
\boxed{
\Lambda:=\frac{g_1+g_3}{\varepsilon}\le L<\infty.
}
\]
Unlike \(3+1\), this branch has a genuine four-point conformal-modulus degeneration.

## 2. Exact input cross-ratio

For ordered points
\[
z_j=re^{i\theta_j},
\qquad
\theta_0<\theta_1<\theta_2<\theta_3,
\]
define
\[
\chi(z_0,z_1,z_2,z_3)
=
\frac{(z_1-z_0)(z_3-z_2)}{(z_2-z_0)(z_3-z_1)}.
\]
The common factor \(r\) cancels.  Using
\[
e^{i\beta}-e^{i\alpha}
=2ie^{i(\alpha+\beta)/2}\sin\frac{\beta-\alpha}{2},
\]
one obtains the exact positive real formula
\[
\boxed{
\chi
=
\frac{
\sin(g_1/2)\sin(g_3/2)
}{
\sin((g_1+g_2)/2)\sin((g_2+g_3)/2)
}.
}
\]
For a collapsing packet \(\delta\to0\) with \(g_1+g_3=o(\delta)\),
\[
\boxed{
\chi
=
\frac{g_1g_3}{\delta^2}(1+o(1)).
}
\]
Since
\[
g_1g_3\le\frac{(g_1+g_3)^2}{4}
\le\frac{L^2\varepsilon^2}{4},
\]
we get
\[
\boxed{
\chi\le\frac{L^2}{4R^2}(1+o(1)).
}
\]
Thus the \(2+2\) input configuration approaches the boundary of ordinary four-point moduli at least quadratically in \(R^{-1}\).

## 3. Exact square cross-ratios

Take the standard square
\[
1,\ i,\ -1,\ -i.
\]
Modulo square dihedral symmetry, the three possible assignments of parameter order to square labels are
\[
p_0=(0,1,2,3),
\qquad
p_1=(0,1,3,2),
\qquad
p_2=(0,2,1,3).
\]
The corresponding ordered Euclidean cross-ratios are exactly
\[
\boxed{
q_{p_0}=\frac12,
\qquad
q_{p_1}=-1,
\qquad
q_{p_2}=2.
}
\]
Translation, rotation, and scaling of the square do not change these values.

Therefore, if
\[
Z_j=f(z_j)
\]
are exact square vertices in one of these order types,
\[
\boxed{
\left|
\frac{\chi(Z_0,Z_1,Z_2,Z_3)}
{\chi(z_0,z_1,z_2,z_3)}
\right|
\ge
c_LR^2
}
\]
for all sufficiently large \(R\).  With only the bound \(\Lambda\le L\), one may take any fixed \(c_L<2/L^2\) eventually.

This is a genuine conformal distortion load.  It is absent in the bounded-\(\Lambda\) \(3+1\) branch.

## 4. Divided-difference form

Define the two-point divided difference
\[
D_f(z,w)=\frac{f(z)-f(w)}{z-w}.
\]
The cross-ratio distortion factors exactly as
\[
\boxed{
\frac{\chi(f(z_0),f(z_1),f(z_2),f(z_3))}
{\chi(z_0,z_1,z_2,z_3)}
=
\frac{D_f(z_0,z_1)D_f(z_2,z_3)}
{D_f(z_0,z_2)D_f(z_1,z_3)}.
}
\]
Thus bounded-inner-scale \(2+2\) requires the product of the two close-pair secant derivatives to exceed the product of the two long secant derivatives by order \(R^2\).

The square geometry gives a slightly more concrete statement.  Every nonzero distance between two square vertices is either \(s\) or \(\sqrt2s\).  Hence, for small \(\delta\),
\[
\boxed{
\frac{|D_f(z_0,z_1)|}{|D_f(z_0,z_2)|}
\gtrsim
\frac{\delta}{g_1},
\qquad
\frac{|D_f(z_2,z_3)|}{|D_f(z_1,z_3)|}
\gtrsim
\frac{\delta}{g_3}.
}
\]
Since \(g_1,g_3\le L\varepsilon\), both amplification factors are at least order
\[
\boxed{R/L.}
\]
So the branch needs two separated close-pair amplification events, not just one anomalous derivative.

## 5. Quadrilateral modulus

Let \(K(m)\) denote the complete elliptic integral with parameter \(m\).  For four cyclically ordered points with cross-ratio \(0<\chi<1\), the corresponding disk quadrilateral modulus, in the convention used here, is
\[
M(\chi)=\frac{K(1-\chi)}{K(\chi)}.
\]
As \(\chi\downarrow0\),
\[
\boxed{
M(\chi)
=
\frac1\pi\log\frac{16}{\chi}+o(1).
}
\]
Therefore bounded-inner-scale \(2+2\) gives
\[
\boxed{
M\ge\frac{2}{\pi}\log R-O_L(1).
}
\]

Geometrically, the analytic Jordan domain
\[
\Omega_r=f(r\mathbb D)
\]
contains a marked boundary quadrilateral whose four marked points happen to be the corners of a Euclidean square, but whose intrinsic conformal aspect ratio diverges logarithmically.

This is a precise “deep fjord / long corridor” certificate.  It does **not** by itself contradict simple connectivity or the Jordan property: the unmarked boundary arcs are free to make arbitrarily long excursions.  The theorem therefore supplies a load to be combined with additional topology, not a completed exclusion.

## 6. Why 3+1 is different

At a left \(3+1\) vertex write the affine-normalized positions as
\[
0,\ \alpha\tau,\ \tau,\ 1,
\qquad
\tau\to0.
\]
Then the same ordered input cross-ratio satisfies
\[
\boxed{
\chi\to\alpha.
}
\]
By the three-vertex noncollapse lemma in the companion note, bounded-inner-scale square sequences keep \(\alpha\) away from \(0\) and \(1\) after subsequence extraction.  Thus the four-point cross-ratio remains in a compact subset of ordinary moduli space even though the hyperbolic separation from the triple to the remote fourth vertex diverges like \(\log R\).

Hence:

\[
\boxed{
\text{ordinary four-point cross-ratio sees bounded }2+2,
\text{ but is blind to bounded }3+1.
}
\]

The missing datum in \(3+1\) is the Abel depth \(1-r\), or equivalently the location of the four points relative to the outer unit boundary.  That is why the parabolic tangent-flow formulation is needed there.
