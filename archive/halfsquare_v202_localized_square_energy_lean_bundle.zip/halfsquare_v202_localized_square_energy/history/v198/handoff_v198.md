# Handoff v198 — parabolic tangent flow and 2+2 modulus load

## Banked results from v195–v197

- Every runaway square activates modes at least \(R^{2/3}\).
- Interior and \(2+1+1\) shapes improve to \(R^{3/4}\).
- Only \(3+1\) and \(2+2\) simplex vertices genuinely lose first-order transversality.
- With vertex thickness \(\tau\) and inner runaway ratio \(\Lambda=R\tau\), the outer spectral threshold is \((\Lambda R^2)^{1/4}\).
- If \(\Lambda\to\infty\), a second inner microscope yields threshold \((R\Lambda^2)^{1/4}\) with \(\Omega(R)\) tail load.
- The unresolved branch is bounded \(\Lambda\).

## New v198 results

### 1. Exact microscope cocycle

For
\[
\mathcal C_af(z)=\frac{f(\phi_a(z))-f(a)}{(1-|a|^2)f'(a)},
\]
any two centers satisfy
\[
\boxed{
\mathcal C_bf=\mathscr R_{\phi_a^{-1}\phi_b}(\mathcal C_af).
}
\]
The scale ratio is exactly
\[
\boxed{
\frac{(1-|b|^2)f'(b)}{(1-|a|^2)f'(a)}.
}
\]

### 2. Parabolic tangent flow

Equal-radius center shifts of angular size \((1-r^2)t\) converge to
\[
P_t=G_0^{-1}(G_0+it),
\qquad
G_0(z)=\frac{z}{1+z}.
\]
The full tangent set at a boundary point is invariant under
\[
\mathscr P_tF=\mathscr R_{P_t}F.
\]

### 3. Stationary tangent classification

The only normalized univalent map fixed by every \(\mathscr P_t\) is
\[
\boxed{G_0(z)=z/(1+z).}
\]
Therefore a finite tangent set is necessarily the singleton \(\{G_0\}\).

### 4. Bounded 3+1 requires tangent richness

Three square vertices cannot occupy an angular interval shorter than \((1-r)/100\).  In a bounded-\(\Lambda\) \(3+1\) sequence, the three cluster preimages therefore resolve as three distinct finite horocycle points after subsequence extraction.  Their tangent images are three noncollinear square vertices, so the tangent is not \(G_0\).

Hence
\[
\boxed{
\text{bounded }3+1
\Rightarrow
\text{uncountably many conformal tangents at the collision point}.
}
\]

### 5. Möbius calibration becomes an orbit, not an isolated model

For \(M_c=z/(1+cz)\),
\[
\mathscr P_tM_c=M_{c_t},
\qquad
c_t=1-\frac{1-c}{1-i(1-c)t},
\]
and \(M_{c_t}\to G_0\) as \(|t|\to\infty\).  If such a tangent occurs for one fixed map, the entire orbit and its regular limit belong to the tangent hull.

### 6. Bounded 2+2 carries an \(R^2\) cross-ratio load

If the two close-pair gaps are \(g_1,g_3\) and \((g_1+g_3)/\varepsilon\le L\), then
\[
\chi_{\rm in}
\sim\frac{g_1g_3}{\delta^2}
\le\frac{L^2}{4R^2}(1+o(1)).
\]
The image cross-ratio of a square is one of \(1/2,-1,2\), so
\[
\boxed{|\mathrm{CRD}_f|\ge c_LR^2.}
\]
Equivalently the marked quadrilateral modulus satisfies
\[
\boxed{
M\ge\frac{2}{\pi}\log R-O_L(1).
}
\]

### 7. 3+1 is ordinary-cross-ratio invisible

For \(3+1\), positions \(0,\alpha\tau,\tau,1\) have
\[
\chi\to\alpha\in(0,1),
\]
so ordinary four-point moduli do not record the runaway scale \(R\).  The Abel depth is an essential fifth datum.

## Best next move

Split v199 by branch:

1. **2+2:** expand the logarithmic cross-ratio distortion through the Grunsky kernel and seek an \(\ell^2\) coefficient charge of size \(\Omega(\log R)\).
2. **3+1:** study the parabolic tangent hull together with *continuation of the exact square branch in the Abel radius*.  Tangent richness alone is not contradictory; branch bifurcation data may be.
