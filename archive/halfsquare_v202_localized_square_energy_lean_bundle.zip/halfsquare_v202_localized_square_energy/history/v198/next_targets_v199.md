# v199 targets

## Target 1 — Grunsky charge for bounded 2+2

The exact identity
\[
\frac{\chi(f(z_j))}{\chi(z_j)}
=
\frac{D_{01}D_{23}}{D_{02}D_{13}}
\]
forces logarithmic distortion
\[
\log|\mathrm{CRD}|\ge2\log R-O(1).
\]
Write this distortion as a four-point second difference of the logarithmic secant kernel
\[
L_f(z,w)=\log\frac{f(z)-f(w)}{z-w}.
\]
Derive the corresponding Grunsky expansion and determine whether \(2\log R\) forces a quantitative \(\ell^2\) coefficient charge in modes that can be combined with v195-v197 spectral floors.

## Target 2 — dynamics of the 3+1 tangent hull

Bounded-inner-scale \(3+1\) requires a nontrivial continuous orbit
\[
\{\mathscr P_tF\}_{t\in\mathbb R}
\]
inside one boundary tangent set.  Study its omega-limit sets.

Priority questions:

1. If the orbit contains a tangent mapping three finite horocycle points to three square vertices, what must its \(|t|\to\infty\) limits look like?
2. Can the no-boundary-square hypothesis prohibit a parabolic-periodic or almost-periodic tangent hull?
3. Can repeated appearance of the regular tangent \(G_0\) in the orbit closure be combined with the square branch to force a transition zero?

## Target 3 — branch continuation in the Abel radius

For analytic \(\Gamma_r\), square solutions are zeros of a four-real-dimensional analytic test map.  At a transverse square, use the implicit-function theorem to continue the square as \(r\) varies.  Determine whether a bounded-\(\Lambda\) \(3+1\) endpoint must be accompanied by a Jacobian degeneracy, and classify that degeneracy spectrally.

This is probably the strongest way to use the fact that the compactified tangent comes from a *square branch*, not merely from one isolated square at each radius.

## Target 4 — v189 lamination versus tangent richness

The new \(3+1\) obstruction is “uncountably many tangents at one point.”  Translate the v189 nested lobe packet into conformal blow-up tangents and ask whether:

- a positive-density subset of layers forces a finite/rigid tangent hull, excluding \(3+1\); or
- tangent richness itself forces oscillatory phase data sufficient for v190-v191.

## Target 5 — modulus occupancy for 2+2

A single bounded \(2+2\) event costs \((2/\pi)\log R-O(1)\) quadrilateral modulus.  Find a topologically natural way to extract many essentially disjoint marked quadrilaterals from the v189 stack.  The naive successive-annulus modulus sum failed in v194, but these square-marked quadrilaterals are different objects and may have better additivity.
