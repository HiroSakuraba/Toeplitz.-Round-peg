# v198 — Proof audit

## A. Exact algebra checked

The verifier checks the following identities over thousands of random complex samples:

1. transition automorphism
   \[
   h_{a,b}=\phi_a^{-1}\circ\phi_b
   =\phi_{c_{a,b}}(\omega_{a,b}z);
   \]
2. \(|\omega_{a,b}|=1\) and \(|h'_{a,b}(0)|=1-|c_{a,b}|^2\);
3. exact microscope cocycle
   \[
   \mathcal C_bf=\mathscr R_{h_{a,b}}\mathcal C_af;
   \]
4. exact affine scale ratio
   \[
   (\mathcal C_af)'(c)h'(0)
   =\frac{(1-|b|^2)f'(b)}{(1-|a|^2)f'(a)};
   \]
5. parabolic group law \(P_sP_t=P_{s+t}\);
6. \(G_0\) is fixed by the full parabolic renormalization flow;
7. the Möbius calibration orbit formula for \(M_c\).

## B. Stationary tangent theorem

The proof that full parabolic stationarity forces \(G_0\) is analytic, not numerical.  Its load-bearing steps are:

- conjugate by \(G_0\) to vertical translations of a half-plane;
- derive
  \[
  H(X+it)=H(it)+H'(it)H(X);
  \]
- differentiate twice and use the identity theorem to get \(H''=aH'\);
- exclude \(a\ne0\) because the exponential solution is periodic and hence not injective on a half-plane.

No boundary extension of the tangent map is assumed.

## C. Three-vertex angular floor

The proof uses only the banked universal pre-Schwarzian estimate and elementary Euclidean geometry.  The geometric fact needed is that any triangle consisting of three square vertices has minimum strip width \(s/\sqrt2\).  The verifier samples all four three-vertex subsets over 720 strip directions and confirms the sharp floor numerically.

The constant \(1/100\) is intentionally conservative.

## D. Internal triple noncollapse

This is a compactness argument.  It does not give an explicit lower constant for each internal gap unless an upper bound for \(\Lambda\) is fixed.  What is proved is sufficient for subsequence arguments: in a bounded-\(\Lambda\) exact-square sequence, after triple-centering, the three finite preimages cannot have a collision in the limit.

## E. Tangent-set cardinality statement

The theorem requires the *full canonical tangent set at the common boundary point*, not merely tangents along one preselected radial sequence.  Invariance is obtained by shifting each representing center by an angular amount \((1-r^2)t\) at the same radius.  These shifted centers still approach the same boundary point.

The conclusion is necessity only:

\[
\text{bounded }3+1\Rightarrow\text{uncountably many tangents}.
\]

The converse is not claimed.

## F. Cross-ratio and modulus theorem

The exact sine formula is algebraic and verified over random cyclic quadruples.  The asymptotic
\[
\chi\sim g_1g_3/\delta^2
\]
is uniform in the bounded-inner-thickness \(2+2\) regime because \((g_1+g_3)/\delta=\Lambda/R\to0\).

The square output cross-ratios \(1/2,-1,2\) are checked directly.

The modulus convention is
\[
M(\chi)=K(1-\chi)/K(\chi),
\]
with \(K\) using the elliptic *parameter* rather than elliptic modulus.  Under this convention
\[
M(\chi)=(1/\pi)\log(16/\chi)+o(1).
\]
The verifier checks this asymptotic for \(\chi=10^{-3}\) through \(10^{-12}\).

## G. Negative calibration

The parabolic-periodic family
\[
H_{T,\eta}(X)
=\frac{X+\eta(e^{2\pi X/T}-1)}{1+2\pi\eta/T}
\]
is used only to show that invariance under one discrete time \(T\) does not force Möbius regularity.  Its univalence follows from \(\operatorname{Re}H'>0\) on the convex half-plane when
\[
(2\pi\eta/T)e^{\pi/T}<1.
\]
This family is **not** claimed to arise as the tangent hull of a Jordan Riemann map.

## H. Claims deliberately not made

- v198 does not solve bounded \(3+1\).
- v198 does not prove that a continuum tangent set is impossible for a Jordan curve.
- v198 does not sum the \(2+2\) modulus load over the v189 lamination.
- v198 does not yet convert cross-ratio distortion into a Grunsky/Bergman budget.
