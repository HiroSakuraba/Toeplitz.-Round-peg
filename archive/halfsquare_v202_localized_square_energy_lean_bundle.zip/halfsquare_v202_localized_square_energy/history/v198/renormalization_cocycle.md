# v198 — Exact two-center renormalization cocycle

## 1. Canonical conformal microscopes

Let
\[
f:\mathbb D\to\Omega
\]
be univalent.  For \(a\in\mathbb D\), put
\[
\phi_a(z)=\frac{a+z}{1+\bar a z},\qquad A_a=1-|a|^2,
\]
and define the normalized microscope
\[
\boxed{
\mathcal C_a f(z)
=\frac{f(\phi_a(z))-f(a)}{A_a f'(a)}.
}
\]
Then
\[
\mathcal C_af(0)=0,\qquad (\mathcal C_af)'(0)=1,
\]
so every microscope belongs to the normalized schlicht class.

Take two centers \(a,b\in\mathbb D\).  Define the transition automorphism
\[
h_{a,b}=\phi_a^{-1}\circ\phi_b.
\]
Its center and rotation are
\[
\boxed{
c_{a,b}=h_{a,b}(0)=\frac{b-a}{1-\bar a b},
}
\]
\[
\boxed{
\omega_{a,b}=\frac{1-a\bar b}{1-\bar a b},\qquad |\omega_{a,b}|=1,
}
\]
and therefore
\[
\boxed{
h_{a,b}(z)=\phi_{c_{a,b}}(\omega_{a,b}z).}
\]
In particular,
\[
h'_{a,b}(0)=\omega_{a,b}(1-|c_{a,b}|^2).
\]

## 2. Exact cocycle identity

For any normalized univalent \(F\) and any disk automorphism \(h\), define
\[
\mathscr R_hF(z)
:=
\frac{F(h(z))-F(h(0))}{F'(h(0))h'(0)}.
\]
This is again normalized at \(0\).

### Theorem 2.1 — exact two-center transfer

For every univalent \(f\) and every \(a,b\in\mathbb D\),
\[
\boxed{
\mathcal C_bf
=
\mathscr R_{h_{a,b}}(\mathcal C_af).
}
\]
Moreover the affine scale factor is exactly
\[
\boxed{
(\mathcal C_af)'(c_{a,b})h'_{a,b}(0)
=
\frac{(1-|b|^2)f'(b)}{(1-|a|^2)f'(a)}.
}
\]
Thus the two local spectra used in v197 are not independent objects.  They are re-expansions of one and the same conformal map under an exact automorphism/affine renormalization cocycle.

### Proof

Since
\[
\phi_b=\phi_a\circ h_{a,b},
\]
we have
\[
f(\phi_b(z))-f(b)
=A_af'(a)
\left[
(\mathcal C_af)(h_{a,b}(z))-(\mathcal C_af)(c_{a,b})
\right].
\]
Differentiating \(\phi_b=\phi_a\circ h_{a,b}\) at \(0\) gives
\[
A_b=\phi_a'(c_{a,b})h'_{a,b}(0).
\]
Also
\[
(\mathcal C_af)'(c_{a,b})
=
\frac{f'(b)\phi_a'(c_{a,b})}{A_af'(a)}.
\]
Multiplying the last two identities gives the displayed scale factor, and division yields the cocycle identity. ∎

## 3. Cocycle composition

If \(h,k\in\operatorname{Aut}(\mathbb D)\), direct substitution gives
\[
\boxed{
\mathscr R_k(\mathscr R_hF)
=
\mathscr R_{h\circ k}F.
}
\]
Thus re-centering is an honest right action of the automorphism group after the affine normalization has been quotiented out.

## 4. Transfer of the first local spectral invariants

Let
\[
G=\mathscr R_hF,
\qquad c=h(0),
\qquad h(z)=\phi_c(\omega z),
\]
so
\[
h'(0)=\omega(1-|c|^2),
\qquad
P_h(0)=-2\bar c\,\omega.
\]
The pre-Schwarzian composition law gives
\[
P_G(0)=P_F(c)h'(0)+P_h(0).
\]
Since the second Taylor coefficient of a normalized map is \(b_2=P(0)/2\),
\[
\boxed{
(b_2)_G
=
\omega\left[
-\bar c+\frac{1-|c|^2}{2}P_F(c)
\right].
}
\]
This is exactly the canonical \(b_2\)-coefficient of the microscope of \(F\) at \(c\), up to the transition rotation \(\omega\).

For the Schwarzian,
\[
S_G(0)=S_F(c)h'(0)^2
\]
because disk automorphisms have zero Schwarzian.  Hence
\[
\boxed{
(b_3-b_2^2)_G
=
\frac{h'(0)^2}{6}S_F(c).
}
\]
The v192 invariants therefore transfer exactly between microscopes; they are not merely analogous observables.

## 5. The parabolic transition flow

Set
\[
G_0(z)=\frac{z}{1+z},
\qquad
G_0^{-1}(X)=\frac{X}{1-X}.
\]
The disk is mapped by \(G_0\) to the half-plane
\[
\Pi=\{\operatorname{Re}X<1/2\}.
\]
Define
\[
\boxed{
P_t(z)=G_0^{-1}(G_0(z)+it),\qquad t\in\mathbb R.
}
\]
Then
\[
P_{s+t}=P_s\circ P_t,
\]
\[
P_t(0)=U(t)=\frac{it}{1-it},
\]
and
\[
P_t'(0)=\frac{1}{(1-it)^2}.
\]
These automorphisms fix the horocycle tangency point \(-1\) and translate the straightened horocycle by \(it\).

Now take equal-radius centers
\[
a_n=r_ne^{i\theta_n},
\qquad
b_n=r_ne^{i(\theta_n+d_nt)},
\qquad
d_n=1-r_n^2,
\]
with \(r_n\uparrow1\) and \(\theta_n\to0\).  Then
\[
c_{a_n,b_n}
=e^{i\theta_n}
\frac{r_n(e^{id_nt}-1)}{1-r_n^2e^{id_nt}}
\longrightarrow U(t),
\]
and
\[
\omega_{a_n,b_n}
=\frac{1-r_n^2e^{-id_nt}}{1-r_n^2e^{id_nt}}
\longrightarrow
\frac{1+it}{1-it}.
\]
Therefore
\[
\boxed{h_{a_n,b_n}\longrightarrow P_t}
\]
locally uniformly on \(\mathbb D\).

This is the exact limiting flow underlying the informal “move the Möbius microscope along the horocycle” language in v192–v197.
