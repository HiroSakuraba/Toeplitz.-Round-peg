# v198 — Status corrections

## Correction 1 — “fixed-map compatibility should classify the 3+1 tangent” was too optimistic

The exact two-center cocycle does impose real structure, but it does not force a unique tangent.  A general Jordan boundary point may support a whole compact family of normalized conformal tangents.  The correct theorem is conditional but sharp:

- the tangent set is invariant under a continuous parabolic re-centering flow;
- if that tangent set is finite, it collapses to the regular Möbius tangent;
- therefore bounded-inner-scale \(3+1\) requires an uncountable continuum of tangents.

Do **not** state that fixed-map compatibility alone excludes \(3+1\).

## Correction 2 — the v197 Möbius-circle calibration cannot be treated as an isolated fixed-map tangent

For
\[
M_c(z)=\frac{z}{1+cz},
\]
the exact parabolic orbit is
\[
\mathscr P_tM_c=M_{c_t},
\qquad
c_t=1-\frac{1-c}{1-i(1-c)t}.
\]
If one \(M_c\) belongs to the tangent set of a fixed map, the entire orbit belongs as well, and \(G_0=M_1\) lies in the orbit closure.  This does not rule out \(M_c\), but it changes how the calibration must be interpreted.

## Correction 3 — one discrete recurrence does not imply regularity

There are explicit non-Möbius univalent functions fixed by \(\mathscr P_T\) for one nonzero \(T\).  Therefore a proof may not replace continuous tangent-flow rigidity by “the same tangent reappears after one scale shift.”

## Correction 4 — bounded 2+2 and bounded 3+1 should no longer be grouped together

They have fundamentally different ordinary four-point moduli:

- bounded \(3+1\): cross-ratio stays interior;
- bounded \(2+2\): cross-ratio is \(O(R^{-2})\) and quadrilateral modulus is \(\ge(2/\pi)\log R-O(1)\).

The next proof architecture should treat them separately.

## What remains open

1. A continuum of tangents is possible for a wild Jordan boundary.  v198 has not shown that the required tangent flow contradicts the no-square assumption.
2. The logarithmic modulus load in \(2+2\) is not yet globally chargeable; wild boundary arcs can create long conformal corridors inside a small Euclidean region.
3. No Grunsky/Bloch inequality has yet been used to convert the \(R^2\) cross-ratio distortion into a summable spectral quantity.
4. The v189 lamination has not yet been proved to force or forbid the tangent-rich behavior isolated here.
