# Referee proof audit of halfsquare v199

## Bottom line

The v199 bundle contains a strong and, after independent checking, essentially sound **bounded-2+2 Grunsky theorem**. The main 2+2 chain survives:

1. logarithmic cross-ratio distortion factors exactly through the Grunsky matrix;
2. bounded-2+2 geometry gives a required real logarithmic load `2 log R + O(1)`;
3. Grunsky contraction forces both tight pair widths to be comparable to `1-r`;
4. the explicit Grunsky vectors asymptotically saturate the contraction inequality;
5. hence the fixed Grunsky operator has norm `1`;
6. because the normalized extremizers are weakly null while their images have norm tending to `1`, the **essential norm is also `1`**;
7. the extremizing vectors carry their diverging mass through the logarithmic frequency corridor `1/delta ... 1/(1-r)`.

Those statements are suitable to bank, subject to the hypotheses stated below.

The **bounded-3+1 rank-three endpoint theorem is not bankable as written**. Two distinct issues occur:

- local compact convergence does not justify replacing a moving remote evaluation by an asymptotic value of one fixed tangent map;
- even under the stronger fixed-tangent hypothesis, the claimed loss of the remote Jacobian column is coordinate-dependent. In the natural compactifying coordinate `q=1/T`, that column need not vanish. The Möbius calibration already demonstrates this.

Accordingly, v199 should be split into a banked 2+2 theorem and a provisional 3+1 analysis.

---

# A. Bounded 2+2: detailed audit

## A1. Global logarithm and Grunsky expansion — PASS

For a univalent `f` on the disk,

`D_f(z,w)=(f(z)-f(w))/(z-w)`

extends holomorphically across the diagonal with value `f'(z)` and never vanishes. Since `D x D` is simply connected, `D_f` has a global holomorphic logarithm `L_f` after a choice of additive `2 pi i` constant.

For a normalized disk schlicht map, the Taylor expansion may be written

`L_f(z,w)=ell(z)+ell(w)-sum_{m,n>=1} c_mn z^m w^n`,

with symmetric Grunsky coefficients `c_mn=c_nm`. The standard Grunsky inequality makes `B_mn=sqrt(mn)c_mn` a contraction on `l^2` (equivalently one can use the generalized bilinear Grunsky inequality directly).

The v199 use of the real part avoids every branch ambiguity that matters to coercion:

`Re Q_f = log |chi_out/chi_in|`.

## A2. Exact cross-ratio/Grunsky factorization — PASS

With

`Q_f=L01+L23-L02-L13`,

all one-variable terms cancel. The remaining double sum is

`Q_f=-sum c_mn (z0^m-z3^m)(z1^n-z2^n)`.

Writing

`u_m=(z0^m-z3^m)/sqrt(m)`,

`v_n=(z1^n-z2^n)/sqrt(n)`,

gives exactly

`Q_f=-u^T B v`.

This algebra was independently rechecked. The Koebe calibration `B=I` is also correct in this convention.

## A3. Exact vector norm identity — PASS

The identity

`sum_{n>=1}|a^n-b^n|^2/n`

`= log( |1-a conjugate(b)|^2 / ((1-|a|^2)(1-|b|^2)) )`

follows immediately by expanding the square and using `sum z^n/n=-log(1-z)`. For `|a|=|b|=r` and angular separation `Delta`, it becomes

`log(1+4 r^2 sin^2(Delta/2)/(1-r^2)^2)`.

No issue found.

## A4. Bounded-2+2 cross-ratio asymptotics — PASS

Take cyclic angular gaps `g1,g2,g3`, total packet width `delta`, `eps=1-r`, and `R=delta/eps -> infinity`, with

`g1+g3 <= C eps`, `delta -> 0`.

Then `g2=delta-O(eps)=delta(1+o(1))`, and the exact circular cross ratio gives

`chi_in = (g1 g3/delta^2)(1+o(1))`.

For an exact square the output cross-ratio has modulus in `{1/2,1,2}`, hence

`Re Q_f=log(delta^2/(g1 g3))+O(1)`.

The two long Grunsky vectors have angular separations `delta` and `g2=delta-O(eps)`, so

`||u||^2=2 log R+O(1)`,

`||v||^2=2 log R+O(1)`.

The `O(1)` terms are uniform along a bounded-inner-scale sequence once the bound `C` is fixed.

## A5. Pair-width coercion — PASS

Grunsky contraction gives

`Re Q_f <= |Q_f| <= ||u||||v|| = 2 log R+O(1)`.

Substituting `delta=R eps` yields

`log(eps^2/(g1 g3)) <= O(1)`,

so

`g1 g3 >= c eps^2`.

Together with `g1+g3<=C eps`, this implies

`g1 asymp eps`, `g3 asymp eps`.

This is a genuine theorem and does not assume the individual lower bounds it proves.

## A6. Grunsky saturation and norm one — PASS

The pair-width conclusion gives

`Re Q_f=2 log R+O(1)`.

The sharp Grunsky upper bound is

`|Q_f|<=2 log R+O(1)`.

Therefore

`|u^T Bv|/(||u||||v||) -> 1`.

If `||B||=kappa<1`, the right side would be at most `kappa`, contradiction. Thus

`||B||=1`.

A useful strengthening not emphasized enough in v199: if the Riemann map had a quasiconformal extension, its Grunsky norm would be `<1`. Hence this bounded-2+2 branch is impossible for **quasidisks/quasicircles**, not merely for asymptotically conformal boundaries.

## A7. Approximate singular-vector relation — PASS

Set

`U=conjugate(u)/||u||`, `V=v/||v||`.

Near equality gives

`|<U,BV>|=1-O(1/log R)`.

Since `||BV||<=1`, after choosing the phase of the pairing,

`||BV-e^{i phi}U||^2 <= 2(1-|<U,BV>|)=O(1/log R)`.

Thus the normalized error is `O((log R)^(-1/2))`, and the unnormalized error is `O(1)`. Correct.

## A8. Weak escape and essential norm one — PASS

For every fixed frequency `n`, the two long endpoints coalesce angularly, so the `n`th coordinate of `v_R` tends to zero; after normalization it certainly tends to zero. The normalized vectors are bounded, so coordinatewise convergence to zero implies weak convergence to zero in `l^2`.

Saturation gives `||B V_R|| -> 1`. Every compact `K` satisfies `||K V_R|| -> 0`. Consequently

`||B-K|| >= ||(B-K)V_R|| -> 1`.

Taking the infimum over compact `K` and using `||B||<=1` proves

`||B||_ess=1`.

This is a fully analytic argument; it is not established by the numerical verifier.

## A9. Logarithmic spectral corridor — PASS, with wording caveat

For a long pair,

`|u_n|^2=4 r^(2n) sin^2(n delta/2)/n`.

Frequencies `n<=1/delta` contribute only `O(1)`, and the tail `n>=A/eps` is `O_A(1)` with arbitrarily small constant for large fixed `A`. Since the total is `2 log R+O(1)`, the diverging mass occupies the multiplicative corridor

`1/delta lesssim n lesssim 1/eps`,

containing `Theta(log R)` dyadic octaves.

Because one octave has only `O(1)` possible mass while the total mass is `Theta(log R)`, a positive proportion of octaves carry a fixed positive amount of energy. This is correct as an averaged/pigeonhole statement; it should not be phrased as a uniform lower bound on every octave.

The `O(1)` global output error then implies that all but `O(1)` of a suitably chosen positive-mass subcollection of octaves are reproduced to nontrivial accuracy. This is also sound.

## A10. Geometric interpretation of compact Grunsky behavior — PASS with scope clarification

The standard compact-Grunsky/asymptotically-conformal equivalence is classical in the usual Jordan/quasiconformal framework. v199 should cite a primary source rather than Wikipedia/workshop notes for the Grunsky expansion itself.

The project-specific theorem does not need this equivalence: `||B||_ess=1` already proves maximal noncompactness directly.

One should avoid turning the global statement `||B||_ess=1` into a pointwise claim about the particular collision point without an additional localization theorem.

---

# B. Bounded 3+1: detailed audit

## B1. Half-plane coordinate in the file — NOTATIONAL ERROR

With the stated straightening map

`G(z)=z/(1+z)`,

the unit disk maps to

`Re X < 1/2`,

because `|X/(1-X)|<1` is equivalent to `Re X<1/2`.

The v199 file instead writes `Pi={Re X>-1/2}`. That is inconsistent with the stated `G` and with its Möbius calibration. The conformal-radius argument along the imaginary axis is unaffected (the radius is `1` either way after the corresponding normalization), but the domain must be corrected.

## B2. Fixed-tangent finite asymptotic value implies derivative decay — CONDITIONAL PASS

Assume one has a **single fixed** univalent map `H` on the straightened half-plane and a sequence `T->infinity` such that

`H(iT)->L` finite.

Then `L` cannot lie in the interior of `H(Pi)`, since continuity of the analytic inverse would force `iT` to converge to a finite preimage. Therefore `L` lies on the image boundary.

The source conformal radius at `iT` is constant. Koebe quarter yields

`dist(H(iT), boundary H(Pi)) >= c |H'(iT)|`.

Since the left side tends to zero,

`H'(iT)->0`.

This lemma is correct.

### But the hypothesis is not yet obtained from the original bounded-3+1 branch

The actual renormalized Abel maps converge only **locally uniformly on compact subsets**. Their remote fourth parameter is a moving point `iT_n` with `T_n->infinity`. Local convergence gives no control at those moving points.

Thus a sequence of original bounded-3+1 squares does not yet imply the existence of one fixed tangent `H` satisfying `H(iT)->L` along its own tail. A separate tail-compactness/prime-end theorem would be needed.

The v199 section notices this at the end, but the README/status overstates the result by banking it as a theorem about the branch rather than a conditional tangent-model lemma.

## B3. Vanishing `T`-column — PASS only in the noncompact `T` coordinate

For the square-defect map, differentiation with respect to `T` gives a remote column proportional to

`i H'(iT)`.

Under the conditional hypothesis above, that column tends to zero. Correct.

## B4. “Compactified rank <=3 endpoint” — FAIL AS STATED

The endpoint is at `T=infinity`. A legitimate compactifying coordinate is

`q=1/T`.

Then

`dZ_3/dq = (dZ_3/dT)(dT/dq) = -T^2 i H'(iT)`.

Koebe gives only `H'(iT)->0`; it gives no `o(T^-2)` rate. Consequently the compactified column may vanish, converge to a nonzero vector, or fail to have a finite limit.

The bundle's own Möbius calibration makes the problem explicit. Take

`H_a(X)=X/(1-aX)`

with the domain convention corrected and `0<a<1`. Then

`H_a'(iT)=1/(1-aiT)^2 = O(T^-2)`,

so the `T`-column vanishes. But in `q=1/T`,

`Z_3(q)=H_a(i/q)=i/(q-ai)`,

and therefore

`dZ_3/dq |_(q=0) = i/a^2 != 0`.

Thus the statement “the fourth column disappears at the compactified endpoint” is false. It disappears only in a coordinate whose derivative degenerates at the boundary.

Rank of a differential is invariant under smooth **nonsingular** coordinate changes; `T <-> 1/T` is singular at the endpoint. Therefore the rank-`<=3` conclusion cannot be attached to the compactified endpoint without first specifying the correct smooth compactification and proving a rate in that chart.

## B5. Rank-three cokernel reduction — DEMOTE

If one deliberately works with the asymptotic `T`-Jacobian, then the three finite columns can indeed have a one-dimensional left cokernel and the remote tail enters as a smaller term. That is a potentially useful singular-perturbation formulation.

It is **not**, however, a proved rank-three property of the compactified square map. The v191 analogy should be labeled heuristic/conditional until the correct boundary chart and asymptotic rate are established.

---

# C. Verifier audit

The supplied verifier was rerun independently and again reports

`PASS=703498`, `FAIL=0`.

This is consistent with the algebraic claims it actually tests.

However, the verifier does not test the main defect above. It verifies that

`H_a'(iT)->0`

and that the `T`-Jacobian column is proportional to `H_a'(iT)`. It never changes to a compactifying coordinate such as `q=1/T`. Therefore its 3+1 checks are compatible with the false compactified-rank inference.

A small countercheck is included in this audit bundle and explicitly verifies

`d/dq H_a(i/q)|_(q=0)=i/a^2`.

---

# D. Recommended corrected status

## Bank as theorem

- exact logarithmic cross-ratio/Grunsky factorization;
- exact long-pair vector norm;
- bounded-2+2 cross-ratio asymptotics;
- pair-width coercion `g1,g3 asymp 1-r`;
- asymptotic Grunsky saturation;
- `||B||=1` necessity;
- `||B||_ess=1` necessity;
- approximate extremizing-vector transport;
- logarithmic spectral corridor and positive-density octave activity.

## Bank only as a conditional lemma

- for one fixed straightened tangent `H` with a finite asymptotic value along `iT`, `H'(iT)->0`;
- therefore the derivative with respect to the noncompact parameter `T` tends to zero.

## Withdraw / rewrite

- “bounded 3+1 is necessarily a rank-<=3 compactified square-map endpoint”;
- “the remote column disappears at the compactified endpoint”;
- the unconditional rank-three/cokernel reduction for the original bounded-3+1 Abel branch.

## Additional strengthening worth recording

Since a quasiconformally extendible schlicht map has Grunsky norm strictly below `1`, the sound 2+2 theorem already implies:

`bounded-2+2 runaway => the fixed Jordan domain is not a quasidisk (its boundary is not a quasicircle).`

This is stronger geometrically than merely saying that its Grunsky operator is noncompact.

---

# E. Best next repair

For 3+1, stop differentiating with respect to `T` and choose an actual boundary-defining coordinate, most naturally `q=1/T` or the corresponding cross-ratio/prime-end coordinate inherited from the four-point configuration. Then classify the possible asymptotic rates of

`A(T)=H(iT)-L`.

If

`A(T) ~ c/T^beta`,

then in `q=1/T`,

`Z_3(q)-L ~ c q^beta`.

The remote compactified derivative behaves as follows:

- `beta>1`: remote column vanishes;
- `beta=1`: remote column survives at finite nonzero order;
- `0<beta<1`: the map is not differentiable in the naive `q` chart and a different weighted compactification is required.

The Möbius/circle model is exactly the critical `beta=1` case. Therefore any future rank-three theorem must prove `beta>1` from **fixed-Jordan-domain square geometry**, not merely from Koebe quarter.

That is the precise missing theorem exposed by this audit.
