# Detailed handoff — v199

## Project state entering v199
The conformal/Fourier branch began by encoding an exact square as the vanishing of the `k=2,3` modes of the four-point DFT. Abel approximants `f(rS^1)` guarantee analytic curves, and disappearing squares were analyzed through Möbius blow-ups.

Key prior milestones:

- v192: no ultralocal collapse below a constant multiple of `1-r`; balanced versus runaway dichotomy.
- v193: runaway `R=delta/(1-r)` forces large local spectral defect and derivative strain.
- v194: raw strain is not globally packable; parabolic scale `X=(1-r)R^2` discovered.
- v195: largest-gap centering gives the unconditional `R^(2/3)` frequency floor; pure power/corner tangents excluded.
- v196: projected first-order cancellation raises the nondegenerate-shape floor to `R^(3/4)`; collision strata isolated.
- v197: `2+1+1` retains `R^(3/4)`; only bounded-inner-scale `3+1` and `2+2` remain genuinely special.
- v198: bounded `3+1` requires a continuum of parabolic tangents; bounded `2+2` creates `2 log R+O(1)` conformal-modulus/cross-ratio distortion.

## New v199 insight: the 2+2 modulus is a Grunsky extremal problem
The logarithm of the cross-ratio distortion is

`Q=L01+L23-L02-L13`,

where

`L(z,w)=log((f(z)-f(w))/(z-w))`.

The one-variable logarithmic coefficients cancel, leaving only the positive-positive Grunsky coefficients. The exact factorization is

`Q=-u^T B v`,

with

`u_m=(z0^m-z3^m)/sqrt(m)`,

`v_m=(z1^m-z2^m)/sqrt(m)`,

and `B_mn=sqrt(mn)c_mn`.

The Grunsky inequality gives

`|Q|<=||u|| ||v||`.

In bounded 2+2, both long separations are `delta(1+o(1))`, hence

`||u||^2,||v||^2=2 log R+O(1)`.

The exact-square cross-ratio gives

`Re Q=log(delta^2/(g1g3))+O(1)`.

The upper bound therefore forces

`g1g3>=c(1-r)^2`.

Combined with `g1+g3=O(1-r)`, both tight gaps satisfy

`g1,g3 asymp 1-r`.

Then

`Re Q=2 log R+O(1)`,

so the Grunsky inequality is asymptotically saturated.

## Operator-theoretic consequence
If the fixed Grunsky norm were `kappa<1`, the right side would be `2 kappa log R+O(1)`, impossible. Therefore `kappa=1`.

More strongly, the normalized extremizing vectors drift to high frequency and converge weakly to zero, while their images under `B` keep norm `1-o(1)`. Therefore

`||B||_essential=1`.

This excludes any bounded-2+2 mechanism carried by a compact Grunsky operator. Classical results identify compact Grunsky behavior with asymptotic conformality for the relevant Jordan setting, so the surviving point must be maximally rough in this operator sense.

## Spectral geometry of the extremizer
The test-vector energy is

`4 r^(2n) sin^2(n delta/2)/n`.

Frequencies below `1/delta` contribute only `O(1)`; frequencies above a fixed multiple of `1/(1-r)` contribute only `O(1)`. The diverging `2 log R` energy therefore lives in

`1/delta lesssim n lesssim 1/(1-r)`,

a corridor spanning a factor `R`, i.e. `Theta(log R)` dyadic octaves.

Near equality gives an unnormalized `l^2` approximation

`Bv approximately phase * conjugate(u)`

with only `O(1)` total squared error. Hence the Grunsky output must reproduce the target wave packet over a growing number of scales.

This is the best bridge so far between the disappearing-square geometry and a genuinely global operator attached to the fixed Jordan domain.

## New v199 insight: bounded 3+1 is rank-three at infinity
In straightened tangent coordinates `X`, the horocycle is `X=is`. A bounded-3+1 tangent has three finite marked points and a fourth point `iT`, `T->infinity`, whose image tends to a finite asymptotic value `L`.

Koebe quarter gives

`H'(iT)->0`.

The remote column of the four-real-dimensional square-map Jacobian is proportional to this derivative, so it vanishes. Therefore the compactified endpoint has rank at most three.

If the three finite columns have rank three, introduce their one-dimensional left cokernel `lambda`. The leading cluster motions solve three equations; the fourth is controlled only by the projected remote tail and by how the tangent itself changes under the parabolic tangent flow. This recovers the v191 mixed-scale architecture in a new setting.

## Highest-value next move
The 2+2 branch currently looks more promising because the new conclusion is global and sharp: essential Grunsky norm one with explicit approximate singular vectors.

The next calculation should dyadically block the Grunsky operator. There are two possible wins:

1. show near extremality forces substantial same-scale or near-scale coupling on `Theta(log R)` octaves, then compare those scales with v189's nested-lobe hierarchy;
2. if the operator instead uses far-off-diagonal transport, prove that such transport forces a separate geometric singularity (for example a slit/tree/power tangent) already incompatible with prior exclusions.

On the 3+1 side, compute the explicit left-cokernel scalar equation and study the parabolic tail `H(iT)-L` under the tangent flow.
