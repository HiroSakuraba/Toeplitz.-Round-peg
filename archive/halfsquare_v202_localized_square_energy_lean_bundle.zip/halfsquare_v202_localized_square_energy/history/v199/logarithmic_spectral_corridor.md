# Logarithmic spectral corridor and essential Grunsky norm

## 1. The extremizing vectors move to high frequency
For a long pair of conformal parameters with radius `r=1-eps` and angular separation

`delta=R eps`, `R->infinity`,

the Grunsky test vector has entries

`u_n = (z_a^n-z_b^n)/sqrt(n)`.

Its energy is

`|u_n|^2 = 4 r^(2n) sin^2(n delta/2)/n`.

The exact total is

`||u||^2 = log(1+4r^2 sin^2(delta/2)/(1-r^2)^2)`

`=2 log R+O(1)`.

### Low frequencies contribute only `O(1)`
For `n <= 1/delta`, use `sin x <= x`:

`sum_{n<=1/delta}|u_n|^2 <= delta^2 sum_{n<=1/delta} n = O(1)`.

### Very high frequencies contribute only `O(1)`
For `n >= A/eps`, radial damping gives

`r^(2n) <= exp(-2 eps n)`,

and therefore

`sum_{n>=A/eps}|u_n|^2 <= 4 sum_{n>=A/eps} exp(-2 eps n)/n = O_A(1)`,

with the tail made arbitrarily small by large fixed `A`.

Thus essentially all of the diverging `2 log R` norm lies in the corridor

`1/delta lesssim n lesssim 1/eps`.

Its multiplicative width is exactly

`(1/eps)/(1/delta)=R`.

So it contains `Theta(log R)` dyadic octaves.

## 2. Positive fraction of octaves carry order-one mass
Each dyadic octave contributes at most a universal constant because

`sum_{N<=n<2N} 4/n <= 4 log 2+o(1)`.

The corridor contains `Theta(log R)` octaves and carries total energy `2 log R+O(1)`. Hence a positive proportion of those octaves must carry `Omega(1)` energy.

This is a useful strengthening of the phrase "high-frequency activity": bounded 2+2 is intrinsically multiscale.

## 3. Near saturation forces multiscale output resonance
From v199's Grunsky saturation theorem,

`B v`

approximates a phase multiple of `conjugate(u)` in `l^2`, with **bounded unnormalized error**:

`||Bv - e^{i phi} alpha_R conjugate(u)||_2=O(1)`,

where `alpha_R=||v||/||u||=1+o(1)`.

Since `u` has `Omega(1)` mass on `Theta(log R)` separated octaves, only `O(1)` of those octaves can suffer an `Omega(1)` squared-error loss. Thus the output of the Grunsky operator must reproduce the explicit target wave packet on a growing collection of scales.

Important limitation: this does **not** yet prove that the input frequency in each octave couples mainly to the same output octave. The Grunsky matrix may use off-diagonal frequency transport. The theorem is an output-side multiscale resonance statement.

## 4. Weak convergence and essential norm one
Normalize

`V_R=v_R/||v_R||`.

For each fixed coordinate `n`, the angular separation tends to zero, so

`(V_R)_n -> 0`.

The vectors have unit norm, hence finite-support test sequences show

`V_R weakly -> 0` in `l^2`.

Yet Grunsky saturation gives

`||B V_R||_2 -> 1`.

Let `K` be any compact operator. Weak convergence implies

`||K V_R||_2 -> 0`.

Therefore

`||(B-K)V_R||_2 >= ||BV_R||_2-||KV_R||_2 ->1`.

Taking the infimum over compact `K`,

`||B||_essential >=1`.

Since `||B||<=1`,

`boxed: ||B||_essential=1`.

This is stronger than ordinary Grunsky norm one. Bounded 2+2 runaway requires a **maximally noncompact** Grunsky operator.

## 5. Geometric interpretation
Classical work relates compactness of the Grunsky operator for Jordan boundaries to asymptotic conformality. Consequently v199's bounded-2+2 branch cannot occur where the relevant fixed conformal map has compact Grunsky operator.

The surviving geometry must therefore be non-asymptotically-conformal at arbitrarily fine scales and must support approximate Grunsky extremizers that escape to high frequency.

This is consistent with, but stronger in operator language than, the v196/v198 observation that ordinary corners and power tangents are not terminal runaway geometries.
