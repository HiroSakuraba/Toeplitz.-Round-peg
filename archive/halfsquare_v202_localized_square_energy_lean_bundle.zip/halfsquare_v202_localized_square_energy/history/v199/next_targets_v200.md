# v200 targets

## Target A — off-diagonal Grunsky transport
Bounded 2+2 now forces

`B V_R approximately phase * U_R`

for explicit boundary wave packets supported across `Theta(log R)` frequency octaves.

The next question is whether a Grunsky operator coming from one Jordan domain can accomplish this mainly by long-range off-diagonal frequency transport.

Useful subtargets:

1. decompose `B` into dyadic blocks `B_{jk}`;
2. use the exact logarithmic kernel / Schwarzian relation to constrain far-off-diagonal blocks;
3. prove either
   - significant near-diagonal resonance on `Theta(log R)` octaves, or
   - a large off-diagonal transport cost that has an independent geometric interpretation;
4. compare the resulting scale cascade with the v189 nested-lobe hierarchy.

A strong theorem would say that essential norm one extremizers of this *specific difference-vector form* force a slit/cusp/tree-like tangent incompatible with the square geometry already excluded in v195-v196.

## Target B — essential Grunsky norm localization
The present theorem is global for the fixed map. Localize it to the boundary point carrying the 2+2 sequence.

Goal: show the essential-norm-one behavior is supported at that prime end rather than elsewhere on the boundary. Candidate tools:

- cutoff logarithmic kernels;
- localized Dirichlet-space Grunsky forms;
- Schwarzian/Bergman kernel localization;
- conformal welding intervals corresponding to the two tight pairs.

## Target C — bounded 3+1 cokernel tail equation
Assume the finite-cluster Jacobian has rank three. Compute the left-cokernel functional explicitly and derive the scalar endpoint equation in terms of

`A(T)=H(iT)-L`

and the infinitesimal parabolic deformation of the tangent map.

Then classify whether:

- a monotone argument/phase of `A(T)` excludes continuation;
- repeated zero crossings force a nontrivial recurrent tangent-flow orbit;
- recurrence plus a finite asymptotic value forces the regular tangent.

## Target D — degenerate finite-cluster Jacobian
If the three finite columns have rank `<3`, classify that geometry separately. This is a lower-dimensional tangent condition and may be rigid enough to eliminate directly.
