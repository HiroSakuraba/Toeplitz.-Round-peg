# Proof audit v199

## A. Exact logarithmic-kernel identity
The key identity is

`Q_f = L01+L23-L02-L13`

with

`L(z,w)=ell(z)+ell(w)-sum c_mn z^m w^n`.

All one-variable terms cancel because each of `z0,z1,z2,z3` appears once with plus sign and once with minus sign. After using symmetry `c_mn=c_nm`, the remaining double sum factors as

`-sum c_mn (z0^m-z3^m)(z1^n-z2^n)`.

This factorization was verified symbolically and numerically against the Koebe function, for which the full sum is explicit.

## B. Branch of logarithm
Only the real part is used for the asymptotic coercion:

`Re Q_f = log |chi_out/chi_in|`.

Therefore the possible `pi i` jump when the square cross-ratio equals `-1` does not affect the proof. The full complex identity can be fixed by analytic continuation from a base configuration.

## C. Grunsky operator convention
The sign of the coefficient convention is irrelevant for norm estimates. The chosen convention makes

`B_mn=sqrt(mn)c_mn`

a contraction. For Koebe, `B=I`, which is the correct extremal calibration.

## D. Pair-width coercion
The conclusion `g1 g3 >= c eps^2` uses:

- `g1+g3<=C eps` (the bounded-inner-scale 2+2 hypothesis),
- `delta/eps=R->infinity`,
- `delta->0` (the collapsing-square packet),
- exact-square output cross-ratio bounded away from `0` and `infinity`.

It does not assume individual lower bounds on `g1` or `g3`; those are consequences.

## E. Essential norm one
The normalized vectors `V_R` converge weakly to zero because every fixed coordinate tends to zero and the vectors stay bounded in `l^2`. Grunsky saturation implies `||B V_R||->1`. Hence for every compact `K`, `||K V_R||->0` and `||B-K||>=1-o(1)`. Because `||B||<=1`, the essential norm equals one.

This conclusion is stronger than noncompactness and does not rely on an external characterization of compact Grunsky operators.

## F. Frequency corridor
The lower cutoff `1/delta` follows from `sin(n delta/2)<=n delta/2`; the upper cutoff `1/eps` follows from radial damping `r^n approximately exp(-eps n)`. The statement that `Theta(log R)` octaves carry order-one mass is an averaged/pigeonhole statement. It does not claim uniform lower mass in every octave.

## G. 3+1 derivative vanishing
For a fixed tangent map `H` on the straightened half-plane, a finite asymptotic value `L` lies on the boundary of the image domain. Koebe quarter then gives `H'(iT)->0` because the source conformal radius along the vertical line is constant.

The theorem is about the compactified tangent model. Passing a quantitative derivative rate back to the original varying Abel maps would require additional uniform tail control and is not claimed.

## H. 3+1 Jacobian rank
The square map has four real input parameters and four real outputs. At the compactified endpoint the remote real column vanishes, so rank is at most three. If the other three columns are independent, rank is exactly three and there is a one-dimensional left cokernel.

The cokernel reduction is structural, not yet a contradiction.

## I. Main unresolved risks
1. A fixed rough Jordan domain can in principle have essential Grunsky norm one.
2. The Grunsky operator could satisfy the wave-packet relation using strongly off-diagonal frequency transport.
3. Compactified 3+1 tangent sets can be uncountable and dynamically complicated, so the rank-three endpoint equation may still have solutions.
4. None of the v199 theorems alone closes the general Jordan case.
