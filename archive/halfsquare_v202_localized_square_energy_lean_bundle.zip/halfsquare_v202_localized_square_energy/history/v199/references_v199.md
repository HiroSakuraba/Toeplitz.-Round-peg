# References used in v199

These are used only for standard geometric-function-theory facts; the project-specific deductions are derived in the accompanying notes.

1. Standard Grunsky expansion and inequality for univalent functions. A convenient formula is summarized at:
   - https://en.wikipedia.org/wiki/Grunsky_matrix
   - Y. C. Kim and T. Sugawa, *Univalence criteria and analogues of the John constant*, Bull. Aust. Math. Soc. (contains the disk logarithmic-kernel definition).

2. Grunsky norm and quasiconformal extension background:
   - A. Z. Grinshpan and Ch. Pommerenke, *The Grunsky norm and some coefficient estimates for bounded functions*, Bull. London Math. Soc. 29 (1997), 705–712.

3. Compactness of the Grunsky operator and asymptotic conformality:
   - Becker–Pommerenke / Gardiner–Sullivan theorem as summarized in Tim Mesikepp's 2026 Grunsky compactness workshop notes.
   - N. Stylianopoulos et al., *Bergman Orthogonal Polynomials and the Grunsky Matrix*, Constructive Approximation 47 (2018), 211–235, especially the compact-Grunsky/asymptotically-conformal equivalence cited there.

4. For current context on Grunsky operators for rough Jordan domains:
   - K. Johansson and F. Viklund, *Coulomb gas and the Grunsky operator on a Jordan domain with corners*, Inventiones mathematicae (2026).
