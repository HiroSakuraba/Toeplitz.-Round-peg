# Status corrections introduced by v199

1. **v198's `2 log R` modulus load is not merely an energy lower bound.** It is exactly a Grunsky bilinear form and asymptotically reaches the sharp Grunsky upper bound.

2. **Bounded 2+2 cannot contain a hidden sub-Abel pair.** The Grunsky inequality itself forces both tight gaps to be comparable to `1-r`.

3. **Ordinary Grunsky norm one is not the full conclusion.** The extremizing vectors escape weakly to zero, forcing essential Grunsky norm one. Compact Grunsky behavior is ruled out.

4. **Do not infer a diagonal coefficient cascade.** The near-extremizer theorem controls the output wave packet in `l^2`; the Grunsky matrix may still move mass between widely separated frequencies.

5. **Bounded 3+1 really is an endpoint singularity.** The remote vertex approaches a finite asymptotic boundary value and its derivative vanishes, so its square-map Jacobian column disappears.

6. **The rank-three analogy with v191 is valid only after compactification.** It does not by itself supply a continuation contradiction because the tangent map can vary through the parabolic tangent set.
