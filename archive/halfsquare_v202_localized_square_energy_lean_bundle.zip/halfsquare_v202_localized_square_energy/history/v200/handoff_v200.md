# Handoff v200

## What changed

The v199 referee audit was correct: bounded 3+1 is not automatically a rank-three endpoint. v200 replaces the defective statement with the natural disk compactification and gives an explicit full-rank beta=1 calibration.

At the same time, the banked 2+2 Grunsky theorem becomes more structured: its two long-pair vectors collapse to one explicit broadband packet, and essentially every interior dyadic octave is loaded.

## Banked formulas

### 3+1 compactification

`z_T=J(iT)=iT/(1-iT)`,

`z_T+1=1/(1-iT)`,

`F'(z_T)=(1-iT)^2 H'(iT)`.

### 3+1 full-rank calibration

`Psi_e(z)=z+e[((z+1/2)^4-1/16)(i+(2z+1)^2)]`,

`H_e=Psi_e o J`,

`det D(S2,S3)=-e^2/512` at `(s0,s1,q,s3)=(0,1,0,-1)`.

### 2+2 one-packet theorem

`||v-D_g1 u||=O(1)`,

`conjugate(u)=-D_{-delta}u`,

and therefore

`||(D_delta B D_g1 + exp(i phi_R)I) W_R||=O((log R)^(-1/2))`.

### octave loading

For `I_M=[M/delta,2M/delta)` and `M0<=M<=cR`,

`sum_{n in I_M}|u_n|^2=Theta(1)`.

## Recommended next move

Do not return to the v199 cokernel calculation unless an independent theorem puts the 3+1 remote germ in the superlinear/flat class.

The highest-value next calculations are:

1. prove the critical beta=1 parabolic orbit tends to the regular tangent and track where the compactified square goes;
2. dyadically block the twisted Grunsky operator and quantify near-diagonal resonance versus long-range scale transport.

## Additional beta=1 structure

If the disk representation of the remote endpoint extends `C^1` with nonzero derivative, the straightened parabolic re-centerings satisfy

`[H(X+it)-H(it)]/H'(it) -> X`

locally uniformly. Thus the critical regular branch flows toward the regular tangent; the associated square escapes the compact window rather than yielding an immediate contradiction.
