# v201 targets

## A. Critical 3+1 realizability from one fixed Jordan map

The beta=1 full-rank calibration shows that local tangent geometry does not exclude the branch. The missing constraint is recurrence from one fixed Riemann map.

Questions:

1. If a tangent `F` has a finite nonzero endpoint derivative at the remote prime end, prove the parabolic re-centering orbit converges to the regular tangent.
2. Track the compactified 3+1 square under that parabolic flow: does the square necessarily escape to the opposite end, creating a renormalization chain?
3. Determine whether such a heteroclinic tangent orbit can recur at one Jordan prime end without creating one of the v189/v190 forbidden phase structures.

## B. Nonsmooth 3+1 endpoint

Classify the case where `F(-1+sigma)-L` is not differentiable to first order. Candidate invariant: local Hölder exponent / prime-end modulus rather than a Jacobian rank.

## C. Dyadic Grunsky transport matrix

For the v200 packet, decompose `l^2` into corridor octaves `E_j` and set

`B_jk=P_j D_delta B D_g1 P_k`.

Prove a quantitative dichotomy:

- near-diagonal resonance on a positive proportion of the `Theta(log R)` octaves; or
- a definite fraction of the packet norm undergoes long-range octave transport.

Then seek geometric interpretations of each case.

## D. Limit-operator/localization viewpoint

The diagonal phases `D_delta` and `D_g1` shrink pointwise but not in operator norm on the escaping packet. Treat `D_delta B D_g1` as a boundary-scale limit operator and ask whether its unimodular approximate point spectrum can be localized to the collision prime end.

This may be the right bridge from the global essential-norm-one theorem to a local boundary obstruction.
