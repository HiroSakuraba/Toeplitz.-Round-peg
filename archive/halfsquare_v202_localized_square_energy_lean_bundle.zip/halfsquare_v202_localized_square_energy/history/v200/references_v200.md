# Classical references used in the v199-v200 Grunsky branch

- H. Grunsky, *Koeffizientenbedingungen für schlicht abbildende meromorphe Funktionen*, Mathematische Zeitschrift 45 (1939), 29–61. Classical Grunsky inequalities.
- E. Schippers and W. Staubach, *Analysis on quasidisks: A unified approach through transmission and jump problems*, EMS Surveys in Mathematical Sciences, DOI 10.4171/EMSS/53. Their Theorem 6.13 records the equivalence between a Jordan curve being a quasicircle and strict Grunsky norm `<1`.
- S. A. Tang, C. Wu, X. G. Feng, *Essential Norm of the Grunsky Operator*, Acta Mathematica Sinica, Chinese Series 60(2) (2017), 253–260, DOI 10.12386/A2017sxxb0020. Gives essential-norm estimates and compactness criteria for Grunsky operators.

The new v200 compactification and calibration arguments are elementary calculations and do not depend on a new external theorem beyond the banked classical univalent-function framework.
