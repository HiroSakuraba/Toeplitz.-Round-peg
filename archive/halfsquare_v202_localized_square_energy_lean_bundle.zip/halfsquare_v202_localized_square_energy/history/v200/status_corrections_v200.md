# Status corrections through v200

## Withdrawn from v199

The following statements must not be cited as banked theorems:

- `bounded 3+1 => compactified rank <=3`;
- `the remote column disappears at the endpoint`;
- an unconditional one-dimensional cokernel reduction for bounded 3+1.

They used the noncompact coordinate `T` as though it were a regular coordinate at `T=infinity`.

## Retained from v199

- the bounded-2+2 Grunsky factorization;
- pair-width coercion `g1,g3 asymp 1-r`;
- asymptotic Grunsky saturation;
- Grunsky norm `1` and essential norm `1`;
- logarithmic frequency corridor;
- the conditional fixed-`H` lemma `H(iT)->L => H'(iT)->0`.

## Added in v200

- exact compactified derivative relation `F'(z_T)=(1-iT)^2 H'(iT)`;
- remote-germ beta trichotomy;
- explicit beta=1 full-rank compactified 3+1 calibration;
- one-packet phase-twisted Grunsky near-eigenvector theorem;
- uniform loading of every interior dyadic octave.

## Current strongest branch statement

### bounded 2+2

Requires a fixed Grunsky operator of essential norm `1` carrying a prescribed weakly-null broadband packet almost isometrically through `Theta(log R)` loaded octaves.

### bounded 3+1

Requires the v198 uncountable tangent-flow behavior, but the endpoint may be:

- flat/superlinear (rank loss possible),
- critical linear (full rank possible),
- nonsmooth/sublinear (no ordinary endpoint Jacobian).

No universal rank-three reduction is currently proved.
