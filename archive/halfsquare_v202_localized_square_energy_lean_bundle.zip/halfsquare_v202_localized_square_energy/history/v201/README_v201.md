# Half-square / Toeplitz research — v201

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Starting point:** v200 corrected 3+1 and Grunsky wavepacket bundle

This is a focused continuation and a cleaned research archive. It adds finite-point Grunsky energy, an explicit complementary-domain dipole, a conditional crossing obstruction, and a lobe-entropy compactness criterion. The full square-peg conjecture is not solved here.

## Start here

1. [Current theorem ledger](../../THEOREM_LEDGER.md): the progress worth preserving, with hypotheses and current scope.
2. [New directions and worked ideas](../../notes/new_directions_v201.md): five routes, their results, and the missing steps.
3. [Fixed positive Grunsky form](../../notes/finite_point_grunsky_energy.md): sign, pair-width constant, and finite-point compatibility matrix.
4. [Explicit dipole and transmission energy](../../notes/transmission_energy_target.md): geometric energy formula, crossing criterion, and the clearance barrier.
5. [Lobe-entropy compactness](../../notes/lobe_entropy_compactness.md): a sufficient approximation criterion for prescribed rectangles.
6. [Scope corrections](../../notes/scope_corrections_v201.md): the withdrawn rank claim, fixed-map coordinates, and local versus global phase classification.

## The existing endpoint theorem has a prominent home

The latest complete source for **Rectangular Pegs on Jordan Curves of Finite 2-Variation** is
[finite_2variation_endpoint_v183.tex](../../theorems/finite_2variation_endpoint_v183.tex).
Its simple-arc area estimate and primitive-compactness argument remain a central part of the program. The retained audits support the project proof; external acceptance and priority are not asserted.

## A smaller, flat archive

The v200 input contained 53 distinct ZIP containers and 51 levels of nesting below the root. This bundle contains **no nested ZIPs**.

- 277 unique source files are retained.
- 86 unique obsolete or generated files are removed.
- 24 repeated leaf references were eliminated.
- The removal record includes redundant READMEs and manifests, bytecode, superseded endpoint drafts, generated PDFs, and the withdrawn rank-three proof.

Relevant proof history, failed approaches, counterexamples, correction records, mathematical audits, verifiers, and recorded results remain available through the [history index](../../history/INDEX.md). The [cleanup record](../../provenance/CLEANUP.md) and [file-level mapping](../../provenance/files.tsv) show exactly what happened to each source file.

Older text remains dated and may contain assertions corrected later. The current ledger and scope corrections take precedence. This cleanup does not certify every historical argument anew.

## Verification

Run from the extracted bundle directory:

    python3 code/verify_v201.py

The new verifier passed 187 exact SymPy checks. See [code instructions](../../code/README.md), [recorded results](../../results/verify_v201_output.txt), and [proof audit](../../notes/proof_audit_v201.md). Historical verification outputs are retained as historical records; their large test counts do not prove the analytical theorems.

The contents have a SHA256SUMS.txt manifest. To keep future versions small, update this tree directly and regenerate its one outer ZIP. Do not place this ZIP, the uploaded v200 ZIP, or earlier bundles inside the next version.
