# A monotone energy and the work of moving its charges

**Author:** Benjamin John Schulz  
**Version:** v202, 10 September 2026  
**Status:** exact identities and a calibration. No claim to exclude the remaining collision branches.

## 1. Fixed physical charges do give a monotone budget

Fix a univalent \(f:\mathbb D\to\Omega\), real neutral charges \(\lambda_j\), and fixed preimages \(z_j\). Put \(r_*=\max_j|z_j|\), and consider the growing domains \(\Omega_t=f(t\mathbb D)\), \(r_*<t<1\).

Let \(c_{mn}\) be the fixed-map Grunsky coefficients with the v201 sign convention, and write

\[
M_n=\sum_j\lambda_jz_j^n.
\]

The rescaled map \(f_t(\zeta)=f(t\zeta)\) has mixed coefficients \(t^{m+n}c_{mn}\). The physical charge \(f(z_j)\) has coordinate \(z_j/t\). The two scalings cancel exactly in the Grunsky term:

\[
\boxed{\displaystyle
q_t=\sum_{n\ge1}\frac{|M_n|^2}{nt^{2n}}
+\Re\sum_{m,n\ge1}c_{mn}M_mM_n.}
\tag{1.1}
\]

Hence

\[
\boxed{\displaystyle
\frac{dq_t}{dt}
=-2\sum_{n\ge1}\frac{|M_n|^2}{t^{2n+1}}\le0.}
\tag{1.2}
\]

All differentiations are justified by uniform absolute convergence on compact subintervals of \(t>r_*\). The operator contraction also gives the equivalent Hilbert-space justification.

This is an explicit version of domain monotonicity in the [locality note](localized_square_energy_v202.md). It has a legitimate finite integrated budget on any interval beginning at \(t_0>r_*\). Starting exactly at charge insertion does not have this property.

For distinct charge points, as \(t\downarrow r_*>0\),

\[
q_t=-\left(\sum_{|z_j|=r_*}\lambda_j^2\right)
\log(t-r_*)+O(1).
\tag{1.3}
\]

Indeed only the diagonal terms of

\[
\sum_n\frac{|M_n|^2}{nt^{2n}}
=-\sum_{j,k}\lambda_j\lambda_k
\log\left|1-\frac{z_j\overline z_k}{t^2}\right|
\]

diverge. Distinct points on the outermost circle have distinct angles. Zero charges can be omitted. Thus a new packet generally arrives with an infinite self-energy at its insertion boundary, not with a fresh uniformly bounded budget.

## 2. Moving squares add a term of unrestricted sign

Now allow \(z_j=z_j(t)\) to be \(C^1\), with \(|z_j(t)|<t\), and keep the charges fixed. Let \(M_n(t)=\sum_j\lambda_jz_j(t)^n\). The exact derivative is

\[
\boxed{\frac{dq_t}{dt}=-\mathcal D_t+\mathcal W_t,}
\tag{2.1}
\]

where

\[
\mathcal D_t=2\sum_{n\ge1}\frac{|M_n|^2}{t^{2n+1}}\ge0
\tag{2.2}
\]

and

\[
\mathcal W_t
=2\Re\sum_{n\ge1}\frac{\overline{M_n}M_n'}{nt^{2n}}
+2\Re\sum_{m,n\ge1}c_{mn}M_m'M_n.
\tag{2.3}
\]

Symmetry of \(c_{mn}\) accounts for the factor two in the last term. The expression is valid on intervals with a uniform local margin between \(\max|z_j(t)|\) and \(t\). It does not put charges on the boundary of the domain whose energy is being used.

Thus

\[
\int_a^b\mathcal D_t\,dt
=q_a-q_b+\int_a^b\mathcal W_t\,dt.
\tag{2.4}
\]

An upper bound on \(q\) does not bound the dissipated integral unless the transport work is also controlled. Actual square lineages move their four vertices; fixed-charge monotonicity cannot be substituted for (2.1).

## 3. An exact geometric calibration

Take \(f(z)=z\), so the Grunsky matrix vanishes. Fix \(0<\kappa<1\), and put four actual square vertices in the growing disk:

\[
z_j(t)=\kappa t\,i^j,\qquad \lambda_j=(-1)^j.
\]

The moments are

\[
M_n(t)=
\begin{cases}
4(\kappa t)^n,&n\equiv2\pmod4,\\
0,&\text{otherwise}.
\end{cases}
\]

Consequently

\[
\boxed{\displaystyle
q_t=4\log\frac{1+\kappa^4}{1-\kappa^4}}
\tag{3.1}
\]

is constant, while

\[
\boxed{\displaystyle
t\mathcal D_t=t\mathcal W_t
=\frac{32\kappa^4}{1-\kappa^8}>0.}
\tag{3.2}
\]

Both integrals diverge logarithmically over \(0<t<t_0\), and they cancel exactly. Every square has clearance \((1-\kappa)t\), comparable to its side, and its local regularized energy budget is independent of scale.

This is a calibration with a smooth disk and genuine interior squares. It is **not** a square-free Jordan counterexample, a bounded-2+2 collision, or a construction of chamber escapes. Its precise conclusion is that a constant bounded local energy can coexist with an infinite dissipation integral when its charges move. A proof of event quantization must use additional event geometry to avoid this mechanism.

## 4. A sufficient budget condition, stated without hiding the gap

Suppose a selected lineage can be represented in this energy framework on an interval, and one proves:

- a uniform initial energy bound;
- a uniform upper bound on the positive transport work;
- disjoint parameter intervals for genuine escape events, each carrying at least \(\varepsilon>0\) of \(\int\mathcal D_t\,dt\).

Then (2.4), together with \(q_b\ge0\), bounds the number of events by the initial energy plus the transport bound, divided by \(\varepsilon\).

This is a sufficient condition, not a theorem that the selected Toeplitz lineage satisfies those hypotheses. The full problem is concentrated in proving those geometric hypotheses, including a suitable parametrization or a replacement for (2.1) when the lineage is not differentiable.

The useful change from v201 is that remote-domain effects can now be bounded by the locality theorem. The remaining uncontrolled term is the transport of the marked four-point configuration itself.
