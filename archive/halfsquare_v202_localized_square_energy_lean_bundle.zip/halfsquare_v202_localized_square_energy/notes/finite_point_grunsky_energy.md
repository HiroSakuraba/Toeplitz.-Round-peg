# A fixed positive Grunsky form and finite-point compatibility

**Author:** Benjamin John Schulz  
**Version:** v201, 10 September 2026  
**Status:** proved deductions from the v199 cross-ratio identity and Grunsky contraction. These deductions do not exclude every bounded 2+2 collision and do not prove Toeplitz.

## 1. Keep the conformal map fixed

Let $f:\mathbb D\to\Omega$ be one univalent map. Its symmetric Grunsky matrix is

\[
 B_{mn}=\sqrt{mn}\,c_{mn},\qquad \|B\|\le1,
\]

with the v199 convention

\[
 L_f(z,w)=\log\frac{f(z)-f(w)}{z-w}
 =\ell(z)+\ell(w)-\sum_{m,n\ge1}c_{mn}z^mw^n.
\]

Use the global conformal parameters of each square:

\[
 z_0=re^{i\theta},\quad z_1=re^{i(\theta+g_1)},\quad
 z_2=re^{i(\theta+\delta-g_3)},\quad z_3=re^{i(\theta+\delta)}.
\]

Here $\theta$ may vary with the square. Put $\varepsilon=1-r$, assume

\[
 \delta\to0,\quad R=\delta/\varepsilon\to\infty,
 \qquad g_1+g_3\le C\varepsilon,
\]

and suppose the four images are the distinct vertices of a square. Define

\[
 u_n=\frac{z_0^n-z_3^n}{\sqrt n},\qquad
 v_n=\frac{z_1^n-z_2^n}{\sqrt n}.
\]

Writing each event with $z_0=r$ requires a corresponding rotation of the map and matrix. It cannot silently preserve one fixed $B$. In global coordinates the conjugacy identity is

\[
 \overline u=-D_{-(2\theta+\delta)}u.
\]

The argument below needs no moving rotation of $B$.

## 2. An exact nonnegative four-point deficit

For the cross ratio

\[
 \chi(w_0,w_1,w_2,w_3)
 =\frac{(w_1-w_0)(w_3-w_2)}{(w_2-w_0)(w_3-w_1)},
\]

set $Q=L_{01}+L_{23}-L_{02}-L_{13}$. The exact v199 identity is

\[
 Q=-u^TBv,\qquad
 \Re Q=\log\left|\frac{\chi_{\rm out}}{\chi_{\rm in}}\right|.
\]

There is no branch choice in this real part. Define

\[
 \boxed{D=\|u\|^2+\|v\|^2-2\Re Q.}
\tag{2.1}
\]

Then the following exact identity gives positivity, including its equality conditions:

\[
 \boxed{
 D=\bigl(\|v\|^2-\|Bv\|^2\bigr)
       +\|Bv+\overline u\|^2\ge0.}
\tag{2.2}
\]

Indeed, expand the last squared norm and use

\[
 \Re\langle\overline u,Bv\rangle=\Re(u^TBv)=-\Re Q.
\]

Thus the sign is fixed: $Bv$ approximates **minus** $\overline u$. The unspecified phase in v200 is unnecessary for this real-part estimate.

### Proposition 2.1 — explicit pair-width floor

Let $k=|\chi_{\rm out}|\in\{1/2,1,2\}$. Along the sequence above,

\[
 \boxed{D=2\log\frac{g_1g_3}{4k\varepsilon^2}+o(1).}
\tag{2.3}
\]

Consequently

\[
 \boxed{\liminf\frac{g_1g_3}{4k\varepsilon^2}\ge1.}
\tag{2.4}
\]

The value of $k$ is used event by event; alternatively pass to a subsequence with fixed square ordering. This is an explicit necessary constant, with no optimality assertion.

**Proof.** For equal-radius endpoints separated by $\Delta$,

\[
 N_r(\Delta)=\left\|\frac{a^n-b^n}{\sqrt n}\right\|^2
 =\log\left(1+\frac{4r^2\sin^2(\Delta/2)}{(1-r^2)^2}\right).
\]

Both long separations are $\delta(1+o(1))$. Hence each of $\|u\|^2,\|v\|^2$ equals $2\log R-\log4+o(1)$. The circular cross ratio satisfies

\[
 \chi_{\rm in}=\frac{g_1g_3}{\delta^2}(1+o(1)),
 \qquad \Re Q=\log\frac{k\delta^2}{g_1g_3}+o(1).
\]

Substitution proves (2.3), and $D\ge0$ proves (2.4). These relative asymptotics remain valid if an individual $g_j/\varepsilon$ initially tends to zero, so the argument is not circular. Together with $g_1+g_3\le C\varepsilon$, (2.4) recovers $g_1,g_3\asymp\varepsilon$, and gives $D=O_C(1)$. ∎

## 3. The positive form belongs to one fixed operator

Regard $\ell^2(\mathbb C)$ as a real Hilbert space with inner product

\[
 (x,y)_{\mathbb R}=\Re\sum\overline{x_n}y_n.
\]

Let $C_0x=\overline x$ and $A=C_0B$. Symmetry $B^T=B$ makes $A$ self-adjoint on this **real** Hilbert space. It is an antilinear contraction as a map on the complex space. Therefore

\[
 E=I+A\ge0,\qquad 0\le E\le2I,
\]

and

\[
 \boxed{q_f(x)=(x,Ex)_{\mathbb R}
              =\|x\|^2+\Re(x^TBx)\ge0.}
\tag{3.1}
\]

### Theorem 3.1 — fixed-sign positive-energy packet

The actual global-coordinate long-pair vector satisfies

\[
 \boxed{q_f(u)=O_C(1),\qquad \|Bu+\overline u\|=O_C(1).}
\tag{3.2}
\]

For $W=u/\|u\|$,

\[
 q_f(W)=O_C((\log R)^{-1}),\qquad
 \|(A+I)W\|=O_C((\log R)^{-1/2}).
\tag{3.3}
\]

**Proof.** The difference $u-v$ is the sum of the two short-pair vectors. The exact norm formula gives

\[
 \|u-v\|\le \sqrt{N_r(g_1)}+\sqrt{N_r(g_3)}=O_C(1).
\]

Put $m=(u+v)/2$, $d=(u-v)/2$, and

\[
 q_-(x)=\|x\|^2-\Re(x^TBx)\ge0.
\]

Polarization gives the exact identity

\[
 D=2q_f(m)+2q_-(d).
\]

The seminorm $q_f^{1/2}$ obeys the triangle inequality, and $q_f(d)\le2\|d\|^2$. Thus

\[
 q_f(u)\le2q_f(m)+2q_f(d)
          \le D+\|u-v\|^2=O_C(1).
\]

Finally $E^2\le2E$ gives $\|(A+I)u\|^2\le2q_f(u)$. Normalize using $\|u\|^2=2\log R+O(1)$. ∎

The normalized vectors are weakly null. Hence $-1$ has a weakly null approximate eigenvector sequence for this single real self-adjoint $A$. This is a fixed-operator refinement of the phase-twisted formulation. It is not a claim that $B$ has a complex-linear eigenvalue $-1$. Antilinearity also gives an approximate $+1$ sequence $iW$.

For any $\eta>0$, the spectral mass of $W$ where $A\ge-1+\eta$ is at most $O_C(1/(\eta\log R))$. This follows directly from (3.3) and positivity.

## 4. The form has a finite-point geometric formula

For $a,b\in\mathbb D$, write

\[
 u(a,b)_n=(a^n-b^n)/\sqrt n,
 \quad \rho(a,b)=\left|\frac{a-b}{1-a\overline b}\right|,
 \quad r_f(a)=(1-|a|^2)|f'(a)|.
\]

### Proposition 4.1 — long-pair energy

For $a\ne b$,

\[
 \boxed{
 q_f(u(a,b))=
 \log\frac{|f(a)-f(b)|^2}{\rho(a,b)^2r_f(a)r_f(b)}.}
\tag{4.1}
\]

**Proof.** Cancelling the one-variable terms in $L_f$ gives

\[
 \Re\bigl(u(a,b)^TBu(a,b)\bigr)
 =\log\frac{|f(a)-f(b)|^2}{|a-b|^2|f'(a)f'(b)|}.
\]

Add the exact pair norm. ∎

Thus positivity is a two-point conformal distortion inequality. It already concerns specific points, although the map whose values appear is global. Bounded 2+2 packets have bounded values of this explicit energy.

For a family of long pairs $(a_j,b_j)$, define the real matrix

\[
 \mathcal E_{jk}=(u(a_j,b_j),E u(a_k,b_k))_{\mathbb R}.
\]

### Theorem 4.2 — finite-point compatibility matrix

Every finite matrix $\mathcal E$ is real symmetric positive semidefinite. If its four arguments are pairwise distinct, its entries use no derivatives:

\[
 \boxed{
 \mathcal E_{jk}=
 \log\left[
 \left|\frac{(f(a_j)-f(b_k))(f(b_j)-f(a_k))}
 {(f(a_j)-f(a_k))(f(b_j)-f(b_k))}\right|
 \frac{\rho(a_j,a_k)\rho(b_j,b_k)}
 {\rho(a_j,b_k)\rho(b_j,a_k)}
 \right].}
\tag{4.2}
\]

For coincident arguments use the continuous divided-difference extension, equivalently the kernel below. The diagonal is (4.1).

**Proof.** Put

\[
 K_f(a,c)=-\log\left|(1-a\overline c)
                         \frac{f(a)-f(c)}{a-c}\right|,
\]

where $K_f(a,a)=-\log r_f(a)$. Expanding the geometric series and the Grunsky series gives

\[
 \mathcal E_{jk}=K_f(a_j,a_k)-K_f(a_j,b_k)
                -K_f(b_j,a_k)+K_f(b_j,b_k).
\]

For real scalars $t_j$, its quadratic form is

\[
 \sum_{j,k}t_jt_k\mathcal E_{jk}
 =q_f\left(\sum_jt_j u(a_j,b_j)\right)\ge0.
\]

Expanding $K_f$, or using $K_f(a,c)=-\log(|f(a)-f(c)|/\rho(a,c))$ off the diagonal, proves (4.2). ∎

### A concrete contradiction test

If events have a common bound $\mathcal E_{jj}\le M$, then

\[
 |\mathcal E_{jk}|\le M.
\]

More generally, every principal determinant must be nonnegative. Therefore a proposed configuration of several collision events is impossible if its **joint** geometric and conformal data force a negative principal determinant, or force one interaction to diverge while the diagonal energies stay bounded.

This is a conditional incompatibility certificate, not a proof that an impossible matrix necessarily occurs. The missing input is a theorem relating distinct actual collision events of one Jordan map. Neither their existence nor their separate extremality supplies that input automatically.

## 5. Two tempting deductions that fail

### Positivity does not make octave costs additive

For each $N\ge2$, take a block of $N$ orthonormal coordinate vectors, put $w_N=N^{-1/2}(1,\ldots,1)$, and let

\[
 B_N=-(1-1/N)w_Nw_N^T.
\]

On the direct sum of disjoint growing blocks, $B=\bigoplus B_N$ is one symmetric contraction. For the real vector $u_N=\sqrt N w_N$,

\[
 q(u_N)=1,\quad \|u_N\|^2=N,
\]

whereas the sum of the energies of its individual unit coordinate pieces is

\[
 \sum_{j=1}^N q(e_j)=N-1+1/N.
\]

The normalized $u_N$ are weakly null and approximately extremizing. Coordinates may be placed in distinct dyadic octaves. Thus even strict positivity on each finite block, the correct bounded total energy, and many populated octaves do not justify summing separate octave energies. This is an **abstract operator calibration**, not a realization by a Jordan Grunsky matrix or by the prescribed dipole vectors.

### The simplest imaginary-overlap test is automatic

For any two disk dipoles, $\langle u(a,b),u(c,d)\rangle$ is a signed sum of four logarithms of numbers $1-z\overline w$. Each such number lies in the open right half-plane. Consequently

\[
 |\Im\langle u(a,b),u(c,d)\rangle|<2\pi.
\]

Normalized long dipoles therefore have asymptotically real overlaps even without square geometry. An argument based only on this isotropy cannot supply the required incompatibility. The real matrix (4.2), with its actual image cross ratios, retains more information.

## 6. Provenance and next use

The project-specific inputs are v199's exact identity and v200's collision setup; the fixed-sign and finite-point deductions above are established here. The classical contraction and the Dirichlet interpretation are covered by Schippers--Staubach, *Analysis on quasidisks*, §§6.2–6.3; see [references](references_v201.md).

The next task is to derive joint restrictions from the selected square lineage or the nested-lobe geometry, then insert them into (4.2). A separate complementary-domain approach to (2.2) is developed in [transmission_energy_target.md](transmission_energy_target.md).
