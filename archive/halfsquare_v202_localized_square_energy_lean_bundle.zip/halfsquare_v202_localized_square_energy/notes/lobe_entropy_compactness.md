# Lobe entropy as an alternative approximation criterion

**Author:** Benjamin John Schulz  
**Version:** v201, 10 September 2026  
**Status:** proved sufficient criterion and quantified obstruction. No claim that every Jordan curve satisfies the criterion.

## 1. Why introduce another criterion?

The finite-\(2\)-variation theorem in v183 is an actual sufficient condition for squares and all prescribed rectangles. The full problem could also be approached by constructing good simple approximations of a rough curve. This note replaces a variation bound by a direct condition on the areas and overlap of endpoint-line lobes.

It is a different possible approximation target. We do not claim a strict enlargement of the class covered by the endpoint theorem.

## 2. Lobe multiplicity

Let \(P_n:\mathbb T\to\mathbb R^2\) be simple Jordan polygons converging uniformly to a Jordan parametrization \(c\). For a proper parameter interval \(I=[s,t]\), let \(\sigma=P_n|_I\), and split it at the line through its two endpoints. Close each off-line component by its segment on that line.

Write \(D_k\) for the bounded lobe domains, with orientation signs \(\epsilon_k\), and define the **unsigned** multiplicity

\[
 m_{n,I}(z)=\sum_k\mathbf1_{D_k}(z).
\]

The v183/v189 decomposition yields

\[
 \left|\int_\sigma\alpha+\int_{[P_n(t),P_n(s)]}\alpha\right|
 \le\int_{\mathbb R^2}m_{n,I}(z)\,dA(z),
 \qquad \alpha=\tfrac12(x\,dy-y\,dx).
 \tag{2.1}
\]

If \(r=\operatorname{diam}\sigma\), the support lies in its convex hull and therefore has area at most

\[
 A_r=\pi r^2/4.
\]

All lobes are counted, including ones whose signed areas cancel. Segments on the endpoint line have zero contribution after moving that line to the horizontal axis.

## 3. An elementary entropy estimate

### Lemma 3.1

If \(m\ge0\) is supported on a set of area at most \(A\), with \(0<A\le1\), and

\[
 \int m\log(1+m)\,dA\le K,
\]

then

\[
 \boxed{\int m\,dA
 \le\sqrt A+\frac{K}{\log(1+A^{-1/2})}.}
 \tag{3.1}
\]

**Proof.** Split at \(T=A^{-1/2}\). The portion with \(m\le T\) contributes at most \(TA=\sqrt A\). On \(m>T\),
\(m\le m\log(1+m)/\log(1+T)\). ∎

In particular a uniform entropy bound makes these area masses uniformly small when their supports shrink.

## 4. Rectangular-peg consequence

### Theorem 4.1 — lobe-entropy compactness criterion

Suppose there are simple Jordan polygons \(P_n\to c\) uniformly, a number \(0<\delta_0<1\), and \(K<\infty\), such that

\[
 \boxed{
 \sup_n\sup_{\substack{I=[s,t]\\0<t-s\le\delta_0}}
 \int m_{n,I}\log(1+m_{n,I})\,dA\le K.}
 \tag{4.1}
\]

Then \(c\) inscribes a rectangle of every prescribed similarity class, including a square.

**Proof.** Uniform convergence to continuous \(c\) implies asymptotic equicontinuity of \(P_n\). Consequently the diameters of their subarcs on shrinking parameter intervals tend uniformly to zero along the tail. Equations (2.1) and (3.1) make their chord-closed area increments uniformly small.

All sufficiently large polygons lie in a fixed disk of radius \(R_0\). The closing chord contributes at most \(R_0|P_n(t)-P_n(s)|/2\), which also tends uniformly to zero. Hence the normalized area primitives

\[
 A_n(t)=\int_0^tP_n^*\alpha
\]

are equicontinuous on one period after including the finitely many initial terms. Their normalization at zero also gives boundedness. Arzelà–Ascoli supplies a uniformly convergent subsequence.

As in v183, smooth each retained polygon by a perturbation of arbitrarily small \(1\)-variation with the same base point. The explicit primitive stability estimate

\[
 \|A_{S_n}-A_{P_n}\|_\infty
 \le\tfrac32R_0\|S_n-P_n\|_{1\text{-var}}
   +\tfrac12\|S_n-P_n\|_{1\text{-var}}^2
\]

preserves the limit. Since \(y\,dx=\tfrac12d(xy)-\alpha\), the Liouville primitives converge on one period and locally uniformly on the periodic lift. Apply Asano–Ike's primitive-convergence criterion. ∎

The same proof works with any uniformly integrable family of multiplicities. The logarithm is an explicit sufficient choice, not a claimed critical exponent.

## 5. What a primitive spike costs

There is a converse quantitative warning. If a simple subarc of diameter \(r\) has chord-closed signed area of magnitude at least \(a>0\), then \(\int m\ge a\). Convexity of \(x\log(1+x)\), Jensen's inequality on the convex hull, and the isodiametric bound give

\[
 \boxed{\int m\log(1+m)\,dA
 \ge a\log\left(1+\frac{4a}{\pi r^2}\right).}
 \tag{5.1}
\]

Thus a fixed area spike in a shrinking arc forces logarithmically diverging lobe entropy. A primitive increment of size \(\varepsilon\) has \(a\ge\varepsilon/2\) once the closing-chord contribution is small.

The v189 scaled rainbow has \(r^2\asymp1/N\), order-one signed area, and multiplicity at most order \(N\). Its entropy is therefore \(\Theta(\log N)\). This shows why (4.1) cannot be deduced from simplicity or the nested-lobe theorem alone.

## 6. The proposed use

Try to build simple polygonal approximants for which large overlapping lobe stacks can be replaced by a controlled traversal while preserving uniform approximation and the Jordan property. A successful construction must control endpoint-line lobes for **all sufficiently short subarcs**, not just a preselected collection of packets.

This is a direct approximation problem leading to the existing rectangle criterion. It avoids assuming that every deep lamination has a smooth metric phase. The uniform entropy construction remains open; merely adding (5.1) to a list of necessary conditions would not advance the contradiction.
