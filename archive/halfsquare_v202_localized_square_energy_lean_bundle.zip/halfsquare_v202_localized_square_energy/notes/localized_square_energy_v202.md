# Locality of the full finite-point energy

**Author:** Benjamin John Schulz  
**Version:** v202, 10 September 2026  
**Status:** proved deductions below; no priority claim. These are locality and energy estimates, not a proof of the full square-peg conjecture.

## 1. What this resolves

The v201 Grunsky form concerns specific points, but it still depends on an entire conformal domain. This note makes that dependence quantitative. For a square with interior clearance and a boundary point nearby, changing the domain only beyond distance \(R\) changes its alternating-charge energy by \(O(s/R)\), where \(s\) is the square side.

The estimate controls the harmonic correction as well as the explicit exterior potential. It does not compare different moving squares, and it does not make their energies additive. The separate [transport note](charge_transport_v202.md) explains why that distinction is essential.

## 2. Energy as a projection problem

Let \(\Omega\) be a bounded Jordan domain. Take distinct points \(x_j=f(z_j)\in\Omega\), real charges \(\lambda_j\), and assume

\[
\sum_j\lambda_j=0.
\]

Write \(g_\Omega(x,y)=-\log\rho(z_x,z_y)\) for the positive Green function, with

\[
\rho(z,w)=\left|\frac{z-w}{1-z\overline w}\right|.
\]

The regular-part kernel is

\[
K_\Omega(x,y)=-\log|x-y|-g_\Omega(x,y)
\quad(x\ne y),
\]

and \(K_\Omega(x,x)=-\log r_\Omega(x)\), where \(r_\Omega\) is conformal radius. Define

\[
q_\Omega(\lambda)=\sum_{j,k}\lambda_j\lambda_kK_\Omega(x_j,x_k).
\tag{2.1}
\]

This is exactly v201's \(q_f(u)\) for

\[
u_n=\frac{\sum_j\lambda_jz_j^n}{\sqrt n}.
\tag{2.2}
\]

The cancellation \(\sum\lambda_j=0\) removes the one-variable terms of the Grunsky expansion.

Choose closed, pairwise disjoint disks \(\overline B(x_j,d_j)\subset\Omega\). Introduce the regularized physical potential

\[
P(w)=-\sum_j\lambda_j\log\max(|w-x_j|,d_j),
\qquad
p(w)=-\sum_j\lambda_j\log|w-x_j|.
\tag{2.3}
\]

Their gradients agree outside those disks. Neutrality makes \(P\) a finite-Dirichlet-energy function on the plane. Its additive constant is fixed by \(P(\infty)=0\).

Let \(V_\Omega=H^1_0(\Omega)\), extended by zero to the plane, with the Dirichlet inner product. Let \(v_\Omega\) be the orthogonal projection of \(P\) onto \(V_\Omega\), and put \(H_\Omega=P-v_\Omega\). Thus \(H_\Omega\) is harmonic inside \(\Omega\) and equals \(p\) outside \(\Omega\). It is the potential after the point charges have been replaced by their induced boundary charges.

### Theorem 2.1 — exact whole-plane identity

\[
\boxed{\displaystyle
q_\Omega(\lambda)=\frac1{2\pi}
\int_{\mathbb R^2}|\nabla H_\Omega|^2\,dA.}
\tag{2.4}
\]

Furthermore,

\[
\int|\nabla P|^2
=\int|\nabla H_\Omega|^2+\int|\nabla v_\Omega|^2.
\tag{2.5}
\]

**Proof for smooth domains.** Orthogonality gives (2.5) and

\[
\int|\nabla H_\Omega|^2
=\int\nabla P\cdot\nabla H_\Omega
=2\pi\sum_j\lambda_jH_\Omega(x_j).
\]

For the last equality, \(-\Delta P\) is \(2\pi\) times the sum of the charged uniform probability measures on the circles \(|w-x_j|=d_j\). The mean-value property applies because \(H_\Omega\) is harmonic on the disks. Neutrality and decay remove the term at infinity.

Away from the regularization disks,

\[
v_\Omega(w)=\sum_j\lambda_jg_\Omega(w,x_j).
\]

Hence \(H_\Omega(w)=\sum_j\lambda_jK_\Omega(w,x_j)\), with its harmonic extension across the charge points. Substitution proves (2.4).

**Passage to a Jordan domain.** Exhaust \(\Omega=f(\mathbb D)\) by the analytic Jordan domains \(f(r\mathbb D)\), \(r\uparrow1\), taking \(r\) large enough to contain the disks. The union of their \(H^1_0\) spaces is dense in \(H^1_0(\Omega)\), since every compact subset of \(\Omega\) lies in one exhaustion domain. Their projections therefore converge in Dirichlet norm. The Green functions and conformal radii converge, also directly from the rescaled conformal coordinates described next. Thus both sides of (2.4) converge to the asserted expressions. ∎

For clarity, the exhaustion parametrization is \(f_r(\zeta)=f(r\zeta)\), with a fixed physical charge represented by \(z_j/r\).

The integral in (2.4) is over the **whole plane**. For a positive-area Jordan boundary it must not silently be replaced by the sum over the two open complementary domains. The boundary can carry the additional nonnegative integral of \(|\nabla p|^2\). No zero-boundary-area hypothesis is needed for (2.4).

### Corollary 2.2 — monotonicity and a finite local upper bound

If \(D\subset\Omega\) are bounded open sets containing the regularization disks, define their energies by the projection formula. Then

\[
0\le q_\Omega\le q_D\le \frac1{2\pi}\int|\nabla P|^2.
\tag{2.6}
\]

Moreover,

\[
2\pi(q_D-q_\Omega)
=\|\nabla(v_\Omega-v_D)\|_{L^2}^2.
\tag{2.7}
\]

These statements follow from nested orthogonal projections. The set \(D\) may be disconnected. This matters when truncating a domain whose charge points lie in different local components.

The local upper bound has the exact value

\[
\frac1{2\pi}\int|\nabla P|^2
=-\sum_j\lambda_j^2\log d_j
-\sum_{j\ne k}\lambda_j\lambda_k\log|x_j-x_k|.
\tag{2.8}
\]

To check (2.8), apply the same circle-charge integration to \(P\) itself. The mean of each other charge's logarithm equals its value at the circle center, because the closed disks are disjoint.

## 3. A square cancels its far dipole

Write the square vertices in physical cyclic order as

\[
x_j=c+a\,i^j,\qquad \lambda_j=(-1)^j,
\]

where \(a\in\mathbb C\setminus\{0\}\), \(A=|a|\), and the side is \(s=\sqrt2A\). Then \(\sum\lambda_jx_j=0\), in addition to neutrality. On \(|w-c|>A\), the analytic potential with real part \(p\) and value zero at infinity is

\[
F(w)=\log\frac{(w-c)^2+a^2}{(w-c)^2-a^2},
\qquad
F'(w)=\frac{-4a^2(w-c)}{(w-c)^4-a^4}.
\tag{3.1}
\]

In particular this is the physical alternating quadrupole, regardless of the order of the corresponding conformal preimages.

### Proposition 3.1 — exact exterior tail

For \(R>A\), put \(t=A/R\). Then

\[
\boxed{\displaystyle
\frac1\pi\int_{|w-c|>R}|F'(w)|^2\,dA
=4\log\frac{1+t^4}{1-t^4}.}
\tag{3.2}
\]

Thus the tail is \(8t^4+O(t^{12})\), and is at most

\[
\frac{8t^4}{1-t^8}.
\tag{3.3}
\]

**Proof.** Expand the branch at infinity:

\[
F(w)=2\sum_{k\ge0}\frac{a^{4k+2}}{(2k+1)(w-c)^{4k+2}}.
\]

Orthogonality of Laurent modes gives

\[
\frac1\pi\int_{|w-c|>R}|F'|^2
=8\sum_{k\ge0}\frac{t^{8k+4}}{2k+1}
=4\log\frac{1+t^4}{1-t^4}.
\]

For (3.3), bound \(1/(2k+1)\le1\). ∎

The same upper bound holds when integrating only over the complementary domain outside the disk. By itself this does not bound the far energy of the interior harmonic correction. That is the role of the next section.

If all four regularization radii equal \(d<s/2\), (2.8) becomes

\[
\boxed{\displaystyle C_{\square}
=\frac1{2\pi}\int|\nabla P|^2
=4\log(s/d)-\log4.}
\tag{3.4}
\]

Here the four adjacent products of charges are negative, and the two opposite products are positive; the latter distances are \(s\sqrt2\). All constants are invariant under a common dilation.

## 4. Annular decay of the grounded Green potential

Assume the regularization disks are contained in \(B(c,R_0)\), and the connected complement \(\mathbb R^2\setminus\Omega\) meets \(\overline B(c,R_0)\). Define

\[
E_v(R)=\int_{|w-c|>R}|\nabla v_\Omega|^2\,dA.
\]

### Lemma 4.1 — a quantitative tail bound

For \(R\ge R_0\),

\[
\boxed{E_v(R)\le \frac{R_0}{R}E_v(R_0)
\le\frac{R_0}{R}\int|\nabla P|^2.}
\tag{4.1}
\]

**Proof for smooth domains.** The connected unbounded complement meets every circle about \(c\) of radius \(r>R_0\). The zero extension of \(v_\Omega\) therefore has a zero on every such circle. Cut the angular parameter at that zero. The interval Poincaré inequality on an interval of length \(2\pi\), with zero endpoint values, gives

\[
\int_{\partial B_r}v_\Omega^2\,ds
\le4r^2\int_{\partial B_r}|\partial_\tau v_\Omega|^2\,ds.
\tag{4.2}
\]

Outside the charge disks, \(v_\Omega\) is harmonic in \(\Omega\), with zero boundary value on \(\partial\Omega\). Integration by parts on the part outside \(B_r\) gives, for almost every \(r\),

\[
E_v(r)=-\int_{\partial B_r}v_\Omega\,\partial_rv_\Omega\,ds.
\]

Using (4.2), Cauchy–Schwarz, and \(2\sqrt{NT}\le N+T\),

\[
E_v(r)\le
2r\sqrt{
\int_{\partial B_r}|\partial_rv_\Omega|^2
\int_{\partial B_r}|\partial_\tau v_\Omega|^2}
\le-rE_v'(r).
\]

Consequently \(rE_v(r)\) is nonincreasing. This proves the first inequality in (4.1); (2.5) proves the second.

For a general Jordan domain, use the analytic exhaustion from Theorem 2.1. The same missing point remains outside each exhaustion domain, so the same \(R_0\) works once the charge disks are contained. Convergence of the projections in Dirichlet norm passes the estimate to the limit. ∎

The exponent one is an energy consequence of connected complement and angular Poincaré. We do not claim it is optimal. The argument uses no curvature or boundary length bound.

### Corollary 4.2 — the full energy density has a local tail

For the square charges and \(R\ge R_0\), with \(R>A\),

\[
\boxed{\displaystyle
\frac1{2\pi}\int_{|w-c|>R}|\nabla H_\Omega|^2
\le4\log\frac{1+(A/R)^4}{1-(A/R)^4}
+2\frac{R_0}{R}C_\square.}
\tag{4.3}
\]

Indeed, outside the regularization disks \(H_\Omega=p-v_\Omega\), so
\(|\nabla H_\Omega|^2\le2|\nabla p|^2+2|\nabla v_\Omega|^2\).
Apply (3.2) and (4.1). Thus the nonnegative density of the whole-plane energy itself, including its harmonic correction, is uniformly concentrated near the cleared square. In the bounded-2+2 application \(R_0=2A\), and the right side tends to zero uniformly as \(R/A\to\infty\).

## 5. Locality of the full energy

### Theorem 5.1 — remote-domain comparison

Let \(\Omega_1,\Omega_2\) be bounded Jordan domains. Suppose:

1. They coincide inside \(B(c,R)\).
2. They contain the same pairwise disjoint regularization disks, all lying in \(B(c,R_0)\).
3. Their common complement inside \(\overline B(c,R_0)\) is nonempty.
4. \(R\ge2R_0\).

For the same neutral physical charges,

\[
\boxed{\displaystyle
|q_{\Omega_1}-q_{\Omega_2}|
\le68\,\frac{R_0}{R}\,
\frac1{2\pi}\int|\nabla P|^2.}
\tag{5.1}
\]

**Proof.** Let

\[
D=\Omega_1\cap B(c,R)=\Omega_2\cap B(c,R).
\]

Use the projection definition if \(D\) is disconnected. Choose a radial Lipschitz cutoff \(\chi\) equal to one on \(B(c,R/2)\), zero outside \(B(c,R)\), with \(|\nabla\chi|\le2/R\). The function \(\chi v_{\Omega_j}\) belongs to \(H^1_0(D)\). This follows first for compactly supported approximations in \(H^1_0(\Omega_j)\), with cutoffs supported slightly inside \(B_R\), and then by passage to the limit.

The best-approximation property and (2.7) give

\[
2\pi(q_D-q_{\Omega_j})
\le\int|\nabla((1-\chi)v_{\Omega_j})|^2.
\]

The product estimate, followed by (4.2) on the annulus, yields

\[
\begin{aligned}
\int|\nabla((1-\chi)v)|^2
&\le2E_v(R/2)+\frac8{R^2}
\int_{R/2<|w-c|<R}v^2\\
&\le 2E_v(R/2)+32E_v(R/2)\\
&=34E_v(R/2).
\end{aligned}
\]

Here \(r\le R\) in the annular integral. Apply Lemma 4.1 to obtain

\[
0\le q_D-q_{\Omega_j}
\le68\frac{R_0}{R}\frac1{2\pi}\int|\nabla P|^2.
\]

Both energies lie in this same interval below \(q_D\), proving (5.1) without doubling the constant. The same argument works for the limits of analytic exhaustion, or directly in the projection spaces. ∎

### Corollary 5.2 — cleared squares with a nearby boundary

Suppose the four square vertices have clearance strictly greater than \(d\), with \(0<d\le s/4\), and \(\Omega^c\) meets \(\overline B(c,2A)\). If another Jordan domain coincides with \(\Omega\) in \(B(c,R)\), \(R\ge4A\), then

\[
\boxed{\displaystyle
|q_\Omega-q_{\widetilde\Omega}|
\le136\,\frac{A}{R}
\left(4\log(s/d)-\log4\right).}
\tag{5.2}
\]

The charge disks lie in \(B(c,2A)\), and the hypotheses transfer to the second domain.

This is an actual localization theorem for the finite-point energy, not just a decay estimate for an arbitrarily chosen density.

## 6. Why bounded 2+2 provides these hypotheses

Use the v201 collision assumptions and its interior-clearance theorem. Choose a fixed \(c_C>0\), reduced if necessary, so that the four closed disks of radius

\[
d=c_Cs\le s/4
\]

are strictly inside the fixed conformal domain. Thus \(C_\square=O_C(1)\).

For a long source pair, \(\rho(z_j,z_k)\to1\). Eventually it exceeds \(4/5\). If \(B(c,2A)\subset\Omega\), Schwarz–Pick applied to this disk's inclusion gives, for any two square vertices,

\[
\rho_\Omega(x_j,x_k)
\le\max_{|u|=|v|=1/2}\rho_{\mathbb D}(u,v)
=\frac45.
\]

This is a contradiction. If the ball contained no boundary point, its connectedness and its containing an interior vertex would imply that it was contained in \(\Omega\). Therefore a boundary point lies within distance \(2A\), as required.

Consequently all bounded-2+2 square events have the uniform locality estimate (5.2), with a constant depending only on the tight-pair bound.

## 7. What is still missing

The positive form is now local in the following precise sense: for fixed cleared square vertices, geometry arbitrarily far away has only a vanishing effect. This does not show that its value must be positive by a uniform amount at a chamber crossing. It also does not compare the energies of successive squares with different vertices or scales.

To finish the energy strategy, one needs a selected-lineage theorem that both detects genuine escape events and places their local costs under a single finite budget. Positivity, locality, and a separate bounded energy at each event do not supply that theorem. The [moving-charge calculation](charge_transport_v202.md) gives an exact obstruction to dropping this last requirement.
