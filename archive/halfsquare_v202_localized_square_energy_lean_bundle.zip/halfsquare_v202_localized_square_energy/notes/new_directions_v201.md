# New directions after v200

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

The strongest progress already in the bundle is the finite-\(2\)-variation rectangle theorem, followed by the phase classification, collision hierarchy, and explicit Grunsky saturation theorem. Those results justify changing the next questions. We need either a sufficient geometric construction or an incompatibility between actual configurations, rather than another unconnected list of necessary properties.

## 1. Compare several candidate squares through a positive matrix

**Idea.** One fixed map supplies one fixed positive real quadratic form. Each bounded 2+2 event gives a vector with bounded energy but a norm growing like \(\sqrt{\log R}\). Polarizing these energies gives a matrix whose off-diagonal entries are explicit four-point expressions.

**Worked result.** [The Grunsky note](finite_point_grunsky_energy.md) proves the fixed-sign statement, a quantitative pair-width floor, and the finite-point compatibility formula. A negative principal determinant would be an actual contradiction, not a statement that a counterexample must be more irregular.

**Next experiment.** Take two or three events connected by the existing selected lineage. Keep their actual conformal endpoints and image endpoints. Determine whether nested, alternating, or returning configurations constrain both cross ratios strongly enough to violate positivity.

**Failure test.** If every candidate arrangement has a positive compatible matrix, identify its limiting geometric form. Do not infer incompatibility merely from weak convergence or essential norm one. The simplest imaginary-overlap test is already automatic for arbitrary disk dipoles.

## 2. Use transmission energy inside one collision packet

**Idea.** The cross-ratio deficit splits into two nonnegative terms, one of which bounds the complementary-domain Dirichlet energy of a canonical Faber function.

**Worked result.** [The transmission note](transmission_energy_target.md) identifies the Faber function explicitly as \(\log((w-b)/(w-a))\) for two square vertices \(a,b\). It proves that \(N\) disjoint bounded-aspect quadrilaterals with fixed trace separation cost at least a constant times \(N\). Since the total packet energy is \(O(1)\), constructing \(N\to\infty\) would exclude bounded 2+2.

**Why this is promising.** It asks for local costs within a single selected four-point configuration. The frequency corridor has many scales, but the budget does not grow with their number.

**Hard step.** Turn actual Jordan geometry into separated traces of the Faber function. Frequency mass alone does not do this. Cusp models should be used immediately to test trace decay, large aspect ratios, and overlapping regions.

**Barrier established in this continuation.** The tight-pair hypotheses already give interior balls of radius comparable to the square side at every vertex. This makes bounded physical dipole energy automatic. The remaining information lies in the long connecting passage or interactions between events, so a bare local energy bound cannot finish the branch.

## 3. Construct better polygonal approximants using lobe overlap

**Idea.** The existing endpoint proof only needs primitive compactness. It may be possible to choose approximants that control overlap of chord-closed lobes even when quadratic variation is unbounded.

**Worked result.** [The lobe-entropy note](lobe_entropy_compactness.md) proves a sufficient criterion: uniform \(L\log L\) control of unsigned lobe multiplicities on short subarcs gives the Asano–Ike primitive hypothesis and hence all prescribed rectangles.

**Next construction problem.** Simplify deep polygonal excursion stacks inside small neighborhoods while preserving injectivity and uniform convergence. Control every short subarc's endpoint-line decomposition after the modification.

**Failure test.** The scaled rainbow has logarithmically divergent entropy, so simplicity alone gives no bound. A successful approximation must alter that concentration mechanism while staying close to the same limiting curve.

## 4. Compactify marked 3+1 configurations

**Idea.** The unmarked tangent flow loses the square as its marks escape. A useful compactification should retain the square marks and their physical normalization simultaneously.

**Calculation.** Suppose \(H=F\circ J\) has a regular remote endpoint, with \(F'(-1)=d\ne0\), \(F(-1)=L\), and the genuine \(C^1\) neighborhood hypothesis of v200. For the parabolic renormalization

\[
 H_t(X)=\frac{H(X+it)-H(it)}{H'(it)},
\]

the regular limit is \(H_t(X)\to X\) on compact sets. But an original finite mark \(is_j\) moves to \(i(s_j-t)\). Moreover

\[
 H(it)=L+\frac{id}{t}+o(1/t),\qquad
 H'(it)=-\frac d{t^2}(1+o(1)).
\]

For a finite mark with \(H(is_j)\ne L\),

\[
 H_t(i(s_j-t))
 =-\frac{t^2}{d}(H(is_j)-L)+o(t^2).
\]

The remote value \(L\), transformed by the same affine normalization, is \(it+o(t)\). Thus the old marked configuration escapes while the maps converge regularly on compact sets. There is no contradiction between these facts.

**Next theorem needed.** Find a compact marked state space in which a selected collision lineage has a nonescaping recurrent portion, or prove that its escape forces one of the finite-point or lobe-entropy contradictions above. This is a new compactness requirement; compactness of the unmarked schlicht class does not imply it.

## 5. Replace a smooth phase assumption by quantitative rigidity

**Idea.** v190 classifies smooth coherent phases whose square-evaluation Jacobian is everywhere singular. The missing topology-to-metric step might be approached by a stability theorem: approximate singularity on many squares should force closeness to a parallel or similarity foliation.

**Precise restricted target.** On a fixed convex patch, assume a normalized family of \(C^4\) phases has uniformly bounded \(C^4\) norm and gradients bounded away from zero. If its square determinants tend uniformly to zero, compactness produces a subsequential \(C^3\) limit satisfying the local rigidity equations. With sufficient control to justify the limit classification, the limit should lie in the exceptional local family.

**What this does not solve.** The nested-lobe stack has not been shown to admit such phase functions or uniform derivative bounds. First prove a quantitative result on a genuinely controlled patch, then ask what geometric hypothesis produces that patch. The globalization correction in [scope_corrections_v201.md](scope_corrections_v201.md) must be respected.

## Suggested order

Start with the finite-point matrix and the Faber transmission calculation, which use the exact structures already available in v199–v200. Keep the approximation route as a separate possible sufficient-condition proof. For 3+1, focus on marked compactness rather than another rank calculation.

The numerical task, if pursued, is to search for a specific incompatible interaction pattern or to identify exactly how a cusp defeats the transmission hypothesis. Large counts of passing algebra checks are not a substitute for either result.
