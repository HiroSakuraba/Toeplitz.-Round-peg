# v201 proof and packaging audit

**Date:** 10 September 2026  
**Scope:** internal audit of the new deductions, plus targeted checks of the current dependency chain. This is not independent expert review.

## Mathematical checks

1. **Deficit sign.** Expanding \(\|Bv+\bar u\|^2\) gives \(+2\Re(u^TBv)\), hence the required \(-2\Re Q\). The sign is fixed by the real cross ratio.
2. **Pair-width constant.** Each long squared norm is \(2\log R-\log4+o(1)\); combining both norms and the cross ratio yields \(2\log(g_1g_3/(4k\varepsilon^2))+o(1)\). The lower-gap conclusion is not assumed in deriving this expression.
3. **Fixed operator.** The global first angle is retained. The real self-adjoint operator is \(C_0B\); the argument does not assert complex-linear self-adjointness of \(B\).
4. **Bounded positive energy.** The midpoint/difference decomposition controls the quadratic form by the deficit plus the squared short-pair difference. A residual bound alone would have given only a weaker estimate by Cauchy–Schwarz.
5. **Finite-point kernel.** Divided differences extend across coincidences. Off-diagonal formulas with distinct arguments use the squared pseudohyperbolic factors in the exact algebra check. Positivity applies to the real interaction matrix.
6. **Dipole convention.** The Faber generating function gives \(\Phi_n\) as the coefficient of \(-n\log(1-f(z)/w)\). Its pullback coefficients agree with \(n c_{nm}\). Applying it to the selected antiholomorphic logarithmic difference gives the explicit physical dipole.
7. **Transmission normalization.** The external Faber identity is used with Dirichlet integral divided by \(\pi\). Equality requires zero boundary area; the inequality suffices throughout. The local crossing cost therefore has the factor \(1/\pi\).
8. **Clearance.** Tight-pair pseudohyperbolic separation is bounded away from one. The schlicht growth bound and Koebe quarter imply a uniform interior ball at each vertex relative to square size. This also proves that bounded dipole energy alone is not a new contradiction.
9. **Entropy criterion.** Unsigned multiplicity is used so cancellation cannot hide area. Its support has small planar area; the entropy estimate supplies uniform integrability. The remainder of the argument follows the retained primitive-compactness proof and the external Asano–Ike criterion.
10. **Globalization counterexample.** The bump has vanishing derivatives through order four at both join points, positive horizontal phase gradient, and different values on disconnected vertical slices. The domain is explicitly contractible. This affects global representation, not the local classification.

## Verification scope

The exact verifier passed 187 checks with zero failures. Its saved output is in results/verify_v201_output.txt. It checks algebra and explicit finite models, including the essential v200 rank correction. The argument did not use floating-point or interval certification.

All 58 Python sources were parsed for syntax. Historical numerical suites were not rerun, because the cleanup preserves their mathematical source and code rather than changing their algorithms. Their recorded outputs remain clearly dated.

The checked external statements are listed in references_v201.md. The full finite-2-variation proof and the v199/v200 corrections were read in their current source forms; the earlier phase-routing history was indexed and retained without representing every step as freshly audited.

## Packaging checks

The build checks all 277 retained sources against their recorded hashes, accounting for the two explicitly documented prefatory warnings. It accounts for every original leaf reference, checks 320 active navigation links, parses Python sources, and checks the final ZIP's CRC and checksum manifest. No nested ZIP or bytecode cache is included.

## What remains unproved

The positive interaction matrix has not been shown to fail for a forced lineage. The complementary crossing geometry has not been constructed. The lobe-entropy approximation hypothesis has not been established for arbitrary Jordan curves. The nonsmooth 3+1 branch and marked compactness issue remain open. No full square-peg proof or priority claim follows from these computations.
