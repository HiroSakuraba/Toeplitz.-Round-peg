# v202 proof audit

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Scope:** internal mathematical audit and exact algebra checks. This is not independent expert review.

## New results checked

1. **Green-kernel sign.** The positive Green function is minus the logarithm of pseudohyperbolic distance. Subtracting it from the physical negative logarithm gives the v201 kernel, including the diagonal minus logarithm of conformal radius.
2. **Projection normalization.** The regularized negative logarithm has negative Laplacian equal to \(2\pi\) times a uniform circle charge. This gives whole-plane energy divided by \(2\pi\), not by \(\pi\), for the real harmonic boundary potential. The analytic potential's exterior Dirichlet convention remains division by \(\pi\).
3. **Positive-area boundaries.** The whole-plane identity includes any energy on the Jordan boundary. Dropping that term would require an additional hypothesis. The projection proof and exhaustion argument avoid that mistake.
4. **Jordan exhaustion.** A fixed physical charge \(f(z_j)\) has coordinate \(z_j/r\) under \(f_r(\zeta)=f(r\zeta)\). The projection spaces exhaust \(H^1_0(\Omega)\); this supplies convergence in energy as well as convergence of finite-point Green data.
5. **Neutrality.** Total charge zero makes the regularized trial potential finite in Dirichlet energy at infinity. The square additionally cancels its dipole moment. These are different conditions.
6. **Square constants.** Alternating charge signs give regularized energy \(4\log(s/d)-\log4\), equivalently \(4\log(A/d)\). The exact exterior tail is \(4\log((1+t^4)/(1-t^4))\). Direct Laurent-mode integration and the independent identity-disk kernel calculation agree.
7. **Annular zero.** The grounded potential, extended by zero, has a zero on each circle beyond the nearby complement point because the complement is connected and unbounded. This is where the Jordan-domain topology enters the decay estimate.
8. **Poincaré factor.** Cutting the circle at a zero gives an interval of length \(2\pi\) with zero endpoint values, whose angular Poincaré constant is four. Combined with the radial flux identity this gives \(E(r)\le-rE'(r)\), and hence inverse-radius decay.
9. **Tail domains.** The energy is that of the grounded Green potential, not of an arbitrary harmonic function. It is harmonic away from the regularized sources in the domain and vanishes on the domain boundary. These hypotheses justify the flux identity. General Jordan domains are obtained by the same analytic exhaustion, with a common nearby missing point.
10. **Truncation can disconnect.** The common truncated domain need not connect all four charges. The locality proof deliberately uses the projection definition for arbitrary bounded open sets; it does not assume a conformal parametrization of that truncation.
11. **Cutoff constants.** The product estimate gives \(2+8\cdot4=34\). Evaluating the tail at \(R/2\) gives 68; taking \(R_0=2A\) gives 136. Both domain energies lie below the same truncated-domain energy, so no extra factor two is needed in their difference.
12. **Full-density localization.** Applying the elementary squared-gradient estimate to \(H=p-v\) gives (4.3). This is distinct from the remote-domain comparison and includes the interior harmonic correction.
13. **Collision applicability.** The clearance theorem gives disjoint interior charge disks. A long-pair pseudohyperbolic distance greater than \(4/5\) prevents the entire disk of radius \(2A\) about the square center from lying in the domain. Thus a nearby boundary point is forced.
14. **Transport differentiation.** The fixed physical-charge Grunsky term is independent of exhaustion radius. When charge points move, the symmetric bilinear term contributes twice its one-slot derivative. The exact check includes nonreal coefficients and moving complex moments.
15. **Calibration scope.** The disk example contains genuine squares and verifies cancellation. It does not instantiate a square-free curve or a bounded-2+2 chamber escape. It invalidates a proposed inference from bounded moving energy alone, not every possible event-quantization theorem.

## Computational verification

The new script passed **75 exact SymPy checks**, with zero failures and no floating point or interval arithmetic. The saved record is [verify_v202_output.txt](../results/verify_v202_output.txt).

The checks cover the quadrupole derivative and moments, the full Laurent congruence pattern, tail normalization, local trial energy, an independent disk-kernel product, fixed and moving charge derivatives, the insertion singularity, annular constants, the nearby-boundary threshold, and the projection-energy sign.

They do not prove the functional-analytic, topological, or exhaustion arguments. Those are supplied in the written proofs above.

The v201 verifier and its existing 187-check record are preserved unchanged. Historical test records remain historical records; they were not silently reclassified as fresh audits.

## What this version does not establish

- A uniformly positive cost for a genuine chamber escape.
- A summable energy budget for different marked squares.
- Control of positive transport work along the selected continuous lineage.
- A contradiction for the remaining 3+1 or other collision branches.
- A universal primitive-compactness theorem or a square-free-arc area theorem.
- A solution of the full Toeplitz conjecture.

The new locality result removes one specific ambiguity about remote energy absorption. The distinction between a localized per-configuration energy and a finite budget across configurations remains explicit.
