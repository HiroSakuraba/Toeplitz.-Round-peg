# External sources checked for v201

Checked 10 September 2026. These are primary research sources or an author-written treatment of the underlying operator theory. The new deductions are proved in the accompanying notes; they are not attributed to these sources.

1. **Eric Schippers and Wolfgang Staubach**, *Analysis on quasidisks: A unified approach through transmission and jump problems*, EMS Surveys in Mathematical Sciences, DOI 10.4171/EMSS/53.  
   https://ems.press/content/serial-article-files/37030  
   Relevant: Theorem 6.9, the Faber–Grunsky Dirichlet inequality and equality for measure-zero boundaries; Theorem 6.13, the quasicircle/strict-Grunsky equivalence; Theorem 6.17, the integral realization. The norm convention in v201 is Dirichlet integral divided by \(\pi\).

2. **Tomohiro Asano and Yuichi Ike**, *The rectifiable rectangular peg problem*, arXiv:2412.21057v3.  
   https://arxiv.org/html/2412.21057v3  
   Relevant: the primitive-convergence criterion for continuous Jordan curves. The v183 endpoint proof and the new lobe-entropy sufficient criterion both use this external theorem.

3. **Xiangfei Li and Yichen Pan**, *Rectangular Pegs on Jordan Curves of Finite \(p\)-Variation*, arXiv:2609.04918v1, 4 September 2026.  
   https://arxiv.org/html/2609.04918v1  
   Relevant: prescribed rectangles for \(1\le p<2\), variation-controlled simple interpolation and smoothing. Its stated range does not include \(p=2\). This is not by itself evidence of priority for the project endpoint theorem.

4. **Joshua Evan Greene and Andrew Lobb**, *Square pegs between two graphs*, arXiv:2407.07798; published online in Commentarii Mathematici Helvetici, 2026.  
   https://arxiv.org/abs/2407.07798  
   Relevant background: squares for a Jordan curve formed from two graphs with Lipschitz constants less than \(1+\sqrt2\). No claim is made here to improve that theorem.

The retained historical notes contain their own earlier references. This short list records the external statements actually used or checked for this continuation, rather than reproducing every historical bibliography.
