# Primary sources checked for v202

Checked 10 September 2026. The new locality and transport deductions are proved in this bundle. No priority claim is made for these elementary potential-theory consequences.

1. **Richard Evan Schwartz**, *Inscribed Rectangle Coincidences*, manuscript dated 16 November 2019.  
   https://www.math.brown.edu/reschwar/Papers/coincidence.pdf  
   Section 2, especially Lemma 2.1: the differential formula for the alternating chord-closed areas along an inscribed-rectangle path.

2. **Richard Evan Schwartz**, *A Trichotomy for Rectangles Inscribed in Jordan Loops*, arXiv:1804.00740v4.  
   https://arxiv.org/abs/1804.00740  
   https://arxiv.org/pdf/1804.00740  
   Theorem 1.1: the connected-family trichotomy for arbitrary Jordan loops.

3. **Gregory R. Chambers**, *On the square peg problem*, arXiv:2203.02613.  
   https://arxiv.org/abs/2203.02613  
   Consulted while assessing near-circular winding packets. Its stated closeness condition uses a map of a whole Jordan curve to a smooth comparison curve, together with winding one. A stack of open arcs does not automatically satisfy that condition. The result is not used in the new proofs.

The Grunsky convention, conformal-radius formula, and the primitive-convergence dependencies are recorded in [references_v201.md](references_v201.md). The present projection proof avoids needing an equality between only the two open complementary-domain energies when the Jordan boundary has positive area.
