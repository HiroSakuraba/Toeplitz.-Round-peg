# Worked directions and the next decisive question

**Author:** Benjamin John Schulz  
**Version:** v202, 10 September 2026

The full Toeplitz conjecture remains open in this project. This continuation worked through localization and transport, rather than adding another list of unavoidable irregularities.

## 1. Localize the charged four-point energy — carried through

The [main note](localized_square_energy_v202.md) proves:

- the positive finite-point form equals a whole-plane Dirichlet energy;
- a square's alternating potential has an exact quartic far tail;
- the grounded Green potential has an inverse-radius energy tail;
- changing a Jordan domain outside radius \(R\), while preserving a cleared square and a nearby boundary point, changes its energy by \(O(s/R)\).

The last statement includes the interior harmonic correction. Its hypotheses follow from the existing bounded-2+2 clearance and long-pair separation estimates.

This gives a precise answer to one part of Claude's criticism. For this energy and these hypotheses, sufficiently distant geometry has a quantitatively small effect on the value attached to the fixed four points. It cannot change that value by an arbitrary amount. However, a whole collapsing sequence still changes its points, scale, and nearby geometry; the theorem does not identify the energies at those different configurations.

## 2. Turn localization into a common budget — tested and still incomplete

The [transport note](charge_transport_v202.md) identifies an exact monotone quantity when the physical charges stay fixed and the domain grows. It then derives the extra work term when the charges move.

The disk calibration is a strong warning: four actual square vertices can move homothetically with constant energy while dissipation and transport work are both nonzero at every logarithmic scale and have divergent integrals toward zero. The cancellation is exact.

Thus the most promising next lemma is a bound on **transport work along the actual selected lineage**, or an alternative invariant that is unchanged by its allowed relabelings and movements. Any claimed epsilon-regularity theorem should specify both its positive event cost and the one finite budget from which all those costs are paid.

This requirement is additional to locality. The calibration does not refute the possibility of a positive cost for genuine chamber escapes, because the disk example does not realize those escapes.

## 3. Use actual rectangle families — a literature connection, not a new theorem

Schwartz's integral formula on a piecewise smooth inscribed-rectangle path is

\[
d\mathcal A=Y\,dX-X\,dY,
\]

where \(\mathcal A\) is an alternating sum of four chord-closed arc areas. In shape polar coordinates \(X=\ell\cos\phi\), \(Y=\ell\sin\phi\), it becomes

\[
d\mathcal A=-\ell^2\,d\phi.
\]

It therefore already lives on actual four-point configurations. Along a differentiable square path it gives \(d\mathcal A=0\). This is a useful candidate to compare with the transport work.

Schwartz's separate trichotomy supplies a connected family of gracefully inscribed rectangles. The case relevant to a hypothetical square-free curve can have arbitrarily small rectangles while its vertices cover all but at most two curve points.

Neither result controls primitive concentration in the continuous limit. We have not identified \(\mathcal A\) with the Grunsky energy or shown that its conservation controls \(\mathcal W_t\). These are possible bridges to investigate, not consequences of the formulas. Sources and exact theorem locations are in [references](references_v202.md).

## 4. Can nested cubic gaps force a positive voltage? — a scaling obstruction

The existing winding argument yields many closely spaced strands. Their number alone is insufficient for the fixed-voltage transmission estimate.

Here is a precise local check. Away from the four charge disks of radius \(d\), the square potential satisfies

\[
|\nabla p(w)|\le\sum_{j=0}^3\frac1{|w-x_j|}\le\frac4d.
\]

If the line segment between two test points remains in this cleared region, then

\[
|p(w_1)-p(w_2)|\le\frac4d|w_1-w_2|.
\]

In a calibration where the square side and packet diameter are both comparable to \(r\), \(d\asymp r\), and opposing traces are \(O(r^3)\) apart, their potential difference can be bounded above by \(O(r^2)\). Even \(N\asymp r^{-2}\) such bounded-aspect test regions would then produce a sum of the squared trace differences of only \(O(r^2)\), not a fixed positive charge.

This is a scaling check, not a theorem that every lobe packet has those square locations or trace pairings. It explains exactly why the cubic-gap theorem does not automatically verify the transmission criterion. A successful argument must force genuinely separated potential levels, a different test field, or a compensating modulus.

## 5. A direct square-free arc area estimate — decisive but unproved

Another route would bypass charge transport. A uniform estimate

\[
\left|\oint_{\sigma+[q,p]}\tfrac12(x\,dy-y\,dx)\right|
\le C\,\operatorname{diam}(\sigma)^2
\]

for every square-free simple arc \(\sigma\) would be extremely useful. No such estimate is established here. In particular, one must not apply an estimate for square-free arcs to arbitrary polygonal approximants merely because their limit is square-free.

A rigorous version adapted to approximants would allow very small squares but bound the arc area whenever the arc contains no square above a specified relative scale. If that forced a noncollapsing square out of every fixed primitive spike, the existing primitive-compactness program could close its remaining concentration alternative.

The double-spiral calculations already in the archive distinguish local narrow corridors from nonlocal square configurations. They are relevant tests for this proposed area principle, not a proof of it.

## Recommendation for the next continuation

Work on one of two explicit bridges:

1. Relate the local charged energy to the selected rectangle family's area invariant strongly enough to bound positive transport work.
2. Prove that a fixed primitive spike forces a square at a controlled scale, with a statement that applies to the approximating curves.

The first bridge now has a locality theorem available. The second would connect the winding packet directly to the exact four-point object. Neither bridge is completed by the present results.
