# Scope corrections and limits

**Author:** Benjamin John Schulz  
**Version:** v201, 10 September 2026

## 1. Preserve the v200 withdrawal

The v199 assertion that bounded 3+1 always has compactified rank at most three is withdrawn. Its two problems are independent:

- Locally uniform convergence of tangent maps does not control a moving remote evaluation.
- Decay of the derivative in \(T\) does not imply decay in the compactifying coordinate \(q=1/T\).

The v200 analytic calibration has compactified Jacobian determinant \(-e^2/512\ne0\). The corrected bundle retains that calibration and the full referee audit. The superseded rank-three proof itself is removed; its mathematical content and failure are documented in those retained sources.

## 2. One fixed Grunsky matrix requires global coordinates

If the first conformal angle of an event is \(\theta_R\), replacing it by zero rotates the matrix:

\[
 B^{(\theta_R)}=D_{\theta_R}BD_{\theta_R}.
\]

The actual long-pair vector obeys

\[
 \overline u=-D_{-(2\theta_R+\delta_R)}u.
\]

Thus the zero-angle equations of v200 are valid in a rotated event chart. Any statement about one fixed operator must retain this rotation, unless the first angle is genuinely fixed. The v201 positive-form theorem uses the global parameters and avoids this bookkeeping issue. The v199 norm-one and essential-norm-one arguments already work in global coordinates.

## 3. A globalization correction to the v190 phase classification

The local v190 classification should be retained as local. Its wording that the representation globalizes on any simply connected subregion is too strong without a connected-level-set or equivalent compatibility hypothesis.

Here is an explicit \(C^4\) counterexample to that globalization, leaving the local classification intact. Let

\[
\begin{aligned}
 U={}&((-2,2)\times(1,2))\\
 &\cup((-2,2)\times(-2,-1))\\
 &\cup((1,2)\times(-2,2)).
\end{aligned}
\]

This open U-shaped region is contractible: first move each point horizontally to \(x=3/2\), then vertically to \(y=0\). Both stages remain inside the region.

Define

\[
 \psi(x)=
 \begin{cases}
 [-x(x+1)]^5,&-1<x<0,\\
 0,&\text{otherwise}.
 \end{cases}
\]

Its derivatives through order four vanish at both joining points, so \(\psi\in C^4(\mathbb R)\). Also

\[
 |\psi'(x)|\le5/256<1.
\]

Set \(H(x,y)=x+\psi(x)\) on the lower horizontal arm and \(H(x,y)=x\) on the upper arm and the right connector. The definitions agree on overlaps because \(\psi=0\) for \(x>1\).

Then \(H\in C^4(U)\) and its gradient is everywhere a positive horizontal vector. Every contained square-phase Jacobian is singular because vertical translation annihilates every row. Locally this is exactly the parallel family.

However

\[
 H(-1/2,3/2)=-1/2,\qquad
 H(-1/2,-3/2)=-1/2+1/1024.
\]

There is no single function \(h\) with \(H(x,y)=h(x)\) on all of \(U\). Any fixed direction in a parallel-family representation would have to be horizontal, by the gradient direction. A finite-center similarity normal form has a varying gradient direction on an open set and cannot repair the example. Simple connectivity did not make the vertical slices connected.

**Corrected scope:** use the v190 normal forms locally, or on regions with the additional level-set compatibility needed to descend \(H\) to one scalar coordinate. The local PDE calculation, the full-rank phase-lattice forcing theorem, and the local list of exceptional foliations are unaffected. No global representation is used in the new v201 arguments.

## 4. What the new positive energy does not establish

- It gives no automatic additive budget for dyadic pieces. The explicit symmetric-contraction model in the Grunsky note refutes that inference.
- It gives a real positive semidefinite interaction matrix. It is not a complex Hermitian positivity assertion for the same formula.
- The complementary quadrilateral criterion requires separated traces of the specific Faber function, bounded aspect ratios, and controlled overlap.
- A uniform lobe-entropy approximation scheme has not been constructed for every Jordan curve.
- None of these statements eliminates the general nonsmooth 3+1 branch.

## 5. Research status

The finite-\(2\)-variation rectangle theorem remains a project theorem supported by the retained elementary proof and audits. The current external Li–Pan preprint proves the \(p<2\) result; this bundle makes no claim of external acceptance or priority for the endpoint.

The v201 results are proved deductions and sufficient criteria under their displayed hypotheses. The continuous Jordan square-peg problem remains unresolved by this work.
