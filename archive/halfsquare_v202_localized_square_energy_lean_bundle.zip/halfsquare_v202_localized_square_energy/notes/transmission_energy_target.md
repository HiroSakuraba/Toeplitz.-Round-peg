# A complementary-domain energy target for one collision packet

**Author:** Benjamin John Schulz  
**Version:** v201, 10 September 2026  
**Status:** exact energy consequence and proved conditional exclusion criterion. The geometric hypothesis in Section 4 is open.

## 1. The available energy is bounded for each packet

Use the fixed-map notation of [finite_point_grunsky_energy.md](finite_point_grunsky_energy.md). Its exact identity is

\[
 D=\|v\|^2-\|Bv\|^2+\|Bv+\overline u\|^2=O_C(1).
 \tag{1.1}
\]

This gives a positive, bounded energy for one four-point configuration. In particular, it gives more useful information than the normalized statement that the contraction defect tends to zero.

The classical Faber–Grunsky inequality realizes the first difference as a Dirichlet-energy bound on the complementary domain. Under the coefficient convention matching \(B\), let

\[
 h_v(\bar z)=\sum_{n\ge1}\frac{v_n}{\sqrt n}\bar z^n,
 \qquad F_v=I_f^\infty h_v.
\]

Here \(I_f^\infty\) is the Faber operator into the holomorphic Dirichlet space of \(\Omega^*=\widehat{\mathbb C}\setminus\overline\Omega\), normalized at infinity. Its definition and extension to arbitrary Jordan boundaries are given in Schippers–Staubach, Theorem 6.9. With

\[
 \mathscr D_{\Omega^*}(F)=\frac1\pi\int_{\Omega^*}|F'(w)|^2\,dA(w),
\]

that theorem states

\[
 \mathscr D_{\Omega^*}(F_v)\le\|v\|^2-\|Bv\|^2.
 \tag{1.2}
\]

Equality holds when the Jordan boundary has planar measure zero. The sign convention for the Grunsky matrix does not affect its squared norm. Thus, without any zero-area assumption,

\[
 \boxed{\mathscr D_{\Omega^*}(F_v)\le D=O_C(1).}
 \tag{1.3}
\]

The external input here is the established Faber identity; the bounded budget for these specific square packets follows from the project’s cross-ratio identity.

## 2. The Faber function is an explicit physical dipole

### Proposition 2.1 — logarithmic dipole formula

Let \(a=f(z_1)\), \(b=f(z_2)\). With the branch normalized to zero at infinity,

\[
 \boxed{F_v(w)=\log\frac{w-b}{w-a}.}
 \tag{2.1}
\]

Consequently the bounded energy has the completely geometric expression

\[
 \boxed{
 \frac{|a-b|^2}{\pi}\int_{\Omega^*}
 \frac{dA(w)}{|w-a|^2|w-b|^2}
 \le D=O_C(1).}
 \tag{2.2}
\]

**Proof.** After translating \(f(0)\) to zero, the Faber functions normalized at infinity have generating function

\[
 -\log(1-f(z)/w)=\sum_{n\ge1}\frac{\Phi_n(w)}n z^n.
\]

Initially this follows by Taylor expansion near \(z=0\) and large \(w\); it defines the rational Faber functions. The left side has analytic continuation in \(z\in\mathbb D\) for every \(w\in\Omega^*\), because \(w\notin f(\mathbb D)\). Since \(I_f^\infty(\bar z^n)=\Phi_n\), linearity applied to
\(h_v=\sum(z_1^n-z_2^n)\bar z^n/n\) gives (2.1). Dirichlet convergence of the series and bounded point evaluation after normalization justify the passage from polynomials. Differentiation gives
\(F_v'=1/(w-b)-1/(w-a)\), proving (2.2).
The ratio has a single-valued logarithm on the complementary domain, including infinity. ∎

In particular

\[
 \Re F_v(w)=\log\frac{|w-b|}{|w-a|}.
\]

For real-part crossings, the relevant traces are therefore explicit log-distance ratios. The missing localization can now be posed in physical coordinates.

## 3. A local energy lemma

### Lemma 3.1 — cost of a quadrilateral crossing

Let \(Q\) be conformally parametrized by a rectangle \((0,L)\times(0,H)\). Let \(F\) be holomorphic on \(Q\) with finite Dirichlet energy. Suppose that, for some real \(\beta,c\) and \(a>0\), the Sobolev boundary traces of

\[
 U=\Re(e^{-i\beta}F)
\]

satisfy

\[
 U(0,y)\le c,\qquad U(L,y)\ge c+a
\]

for almost every \(y\in(0,H)\). Then

\[
 \boxed{\mathscr D_Q(F)\ge\frac{a^2H}{\pi L}.}
 \tag{3.1}
\]

In particular the cost is at least \(a^2/(\pi M)\) if \(L/H\le M\).

**Proof.** Pull back to the rectangle. For almost every horizontal slice, the fundamental theorem for Sobolev functions and Cauchy–Schwarz give

\[
 a^2\le\left|\int_0^L U_x(x,y)\,dx\right|^2
       \le L\int_0^L|U_x(x,y)|^2\,dx.
\]

Integrate in \(y\). The Cauchy–Riemann equations give
\(|\nabla U|^2=|F'|^2\), and Dirichlet energy is conformally invariant. ∎

For a smooth quadrilateral compactly contained in the complementary domain, ordinary continuous boundary values suffice. On rough quadrilaterals the stated trace hypothesis is part of the assumption; it is not supplied by a drawing of a corridor.

## 4. A conditional way to terminate bounded 2+2

### Theorem 4.1 — many transmission crossings are impossible

Suppose a sequence of bounded 2+2 square packets satisfies the v199 hypotheses with one common pair-width bound \(C\). For the function \(F_{v_R}\) belonging to each packet, suppose there are \(N_R\) quadrilaterals in the complementary domain with pairwise disjoint interiors. On each quadrilateral assume Lemma 3.1 with common \(a>0\) and \(L/H\le M\). The constants \(c\) and phases \(\beta\) may differ between quadrilaterals.

Then

\[
 \boxed{N_R\le \frac{\pi M}{a^2}D_R=O_{C,M,a}(1).}
 \tag{4.1}
\]

Thus a construction with \(N_R\to\infty\), even slowly, excludes that collision sequence.

**Proof.** The quadrilateral interiors are disjoint, so their nonnegative Dirichlet integrals sum to at most the total integral (1.3). Apply (3.1). ∎

### The precise missing geometric statement

One promising target is:

> A bounded 2+2 square packet with \(R\) large forces its Faber function to make a fixed-size crossing in a growing number of disjoint complementary quadrilaterals with uniformly bounded aspect ratio.

The \(\Theta(\log R)\) occupied frequency octaves in v200 suggest where to look, but they do **not** prove this statement. Three issues need separate proofs:

1. Construct actual quadrilaterals in \(\Omega^*\) from the collision’s geometric arcs.
2. Prove separation of the relevant **Faber-function traces**, rather than separation of Euclidean positions alone.
3. Bound their overlap and conformal aspect ratios uniformly.

These requirements make the route falsifiable: an explicit Jordan cusp model may show that trace separation decays, the quadrilaterals become extremely long, or their overlap becomes unbounded. Any of these would identify the geometric mechanism preventing this particular exclusion theorem.

## 5. A built-in clearance barrier

The dipole formula also prevents overstating the energy route.

### Proposition 5.1 — all four vertices have interior clearance

Under \(g_1+g_3\le C\varepsilon\), every vertex of the square is at distance at least \(c_Cs\) from \(\partial\Omega\), where \(s\) is the square's side length and \(c_C>0\) depends only on \(C\).

**Proof.** Either tight pair has pseudohyperbolic separation at most

\[
 \kappa_C=\frac{C}{\sqrt{4+C^2}}<1.
\]

Center a normalized schlicht microscope at either point of that pair. The growth bound gives

\[
 |f(z_i)-f(z_j)|
 \le M_C(1-|z_i|^2)|f'(z_i)|,\qquad
 M_C=\frac{\kappa_C}{(1-\kappa_C)^2}.
\]

The left side is at least \(s\). Koebe quarter then gives

\[
 \operatorname{dist}(f(z_i),\partial\Omega)
 \ge\frac{(1-|z_i|^2)|f'(z_i)|}{4}
 \ge\frac{s}{4M_C}.
\]

Apply this at both ends of both tight pairs. ∎

For \(a,b\) in (2.2), the complementary domain therefore avoids disks of radius \(c'_C|a-b|\) about both poles. After sending \(a,b\) to \(0,1\), elementary integration gives

\[
 \frac1\pi\int_{\Omega^*}\frac{dA(w)}{|w|^2|w-1|^2}
 =O(1+|\log c'_C|).
\]

For example, inside \(|w|\le2\) use
\[
 \frac1{|w|^2|w-1|^2}\le2\left(\frac1{|w|^2}+\frac1{|w-1|^2}\right),
\]
and outside that disk use the integrable \(4/|w|^4\) bound.

Thus bounded dipole energy already has a direct explanation from the thick neighborhoods of the vertices. It cannot, by itself, exclude a long conformal passage. A proposed sequence of forced quadrilateral crossings must use additional relationships with the boundary or with other events.

Geometrically, long-pair hyperbolic distance is \(2\log R+O(1)\), while their Euclidean separation is comparable to \(s\) and their endpoint clearances are comparable from below to \(s\). The obstruction is the connecting passage. A path of length at most \(Ls\) between the two points must somewhere have boundary distance at most
\[
 \frac{2Ls}{2\log R+O(1)}.
\]
Indeed, hyperbolic density is at most \(2/\operatorname{dist}(\cdot,\partial\Omega)\); a path staying farther inside would have insufficient hyperbolic length. This pinpoints a bottleneck but does not contradict the Jordan property.

## 6. Relation to the bubbling suggestion

Claude’s proposed analogy correctly points to loss of compactness. A fixed positive cost per event yields finiteness only when the events consume a common finite budget without unbounded reuse. Existence of a density by itself supplies neither condition.

Here there is a more specific proposal: use many local costs **inside one packet**, whose total energy is already bounded by (1.3). It does not require summing energies of different \(F_{v_R}\) across all scales. Those are different functions, so such a sum would need another argument.

The distinction also explains why the older whole-curve logarithmic identity was insufficient. Formula (1.1) selects four parameters, but its localization still has to be justified through the complementary geometry. This note provides the quantitative implication once that geometry is established; it does not supply the missing geometry.

## 7. First useful model calculation

Before attempting a general theorem, use the explicit dipole in a slit or cusp calibration and track the three possible losses above. The Koebe matrix \(B=I\) makes the transmission defect zero in the degenerate slit model. Therefore no uniform crossing claim can extend indiscriminately to slit limits. Any successful Jordan argument must use the separation of the two genuine boundary sides quantitatively.

This is a model warning, not a counterexample to the square-peg conjecture. The input domain in the slit calibration is not a bounded Jordan domain.

See [references_v201.md](references_v201.md) for the classical identity and the current primitive-convergence literature.
