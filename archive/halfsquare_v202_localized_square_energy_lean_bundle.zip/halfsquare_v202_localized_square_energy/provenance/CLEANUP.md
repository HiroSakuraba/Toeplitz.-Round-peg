# Cleanup record

Source: halfsquare_v200_corrected_3plus1_and_grunsky_wavepacket_bundle.zip (1,697,249 bytes).

Source SHA-256: ea6393921be1185ee02e8f6869a1f0dd7ea3d50cf6de9b92afce38ab0a625378.

The input had 53 distinct ZIP containers, 2 repeated archive references, and 51 levels of nesting below the root.

Of 363 unique leaf contents, 277 are retained and 86 are removed. 24 additional leaf references were duplicates. No ZIP file is embedded in the new bundle.

## Retained

Proofs, failed approaches, counterexamples, audits, corrections, research handoffs, references, Python verifiers and recorded results. The complete latest endpoint TeX is retained. The invalid v199 rank claim is represented by its full audit and v200 correction.

## Removed

- 6 unique file(s): Checksum list for obsolete nested layout; replaced by v201 manifest.
- 2 unique file(s): Generated endpoint PDF; complete latest TeX and mathematical audits retained.
- 53 unique file(s): Historical navigation/summary wrapper; proofs, handoffs, audits, references, and current index retained.
- 1 unique file(s): Interpreter bytecode cache; Python source retained.
- 2 unique file(s): Layout check for a removed PDF; no mathematical content.
- 18 unique file(s): Obsolete wrapper inventory; replaced by consolidated provenance.
- 1 unique file(s): Superseded by complete v183 TeX theorem; all later audits retained.
- 1 unique file(s): Superseded by v183 TeX, including improved pi/4 constant and compactness criterion.
- 1 unique file(s): Superseded endpoint proof; v183 TeX supplies the revised proof.
- 1 unique file(s): Withdrawn rank claim; v199 referee audit, v200 correction, and full-rank counterexample retained.

## Traceability

archives.tsv records each container, parent and hash. files.tsv records every original leaf, source hash, disposition and destination. Two historical notes have a v201 scope/coordinate warning prepended; their original bodies are unchanged. All other retained source files are byte-for-byte copies.

Earlier audits sometimes contain claims later corrected. Preservation is for traceability. The current theorem ledger and corrections take precedence. This cleanup is not a fresh proof audit of every historical argument.

Final ZIP size and reduction are reported in the delivery message. The archive's own checksum cannot be embedded inside itself; its contents have a SHA256SUMS manifest.
