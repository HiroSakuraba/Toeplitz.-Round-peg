# v202 change record

Starting artifact: halfsquare_v201_finite_point_energy_lean_bundle.zip.

Its SHA256 was:

    73f30fd8960880336596b7b2c7b06fd829f2cc38742af50a52c1c265d9996f0d

This update copies the flat source tree, adds the v202 locality and charge-transport proofs, research decisions, reference list, proof audit, exact verifier, and verification record. It updates the root README, current theorem ledger, and code instructions. The former README and ledger are retained under history/v201, with their relative links adjusted for that location.

All v201 mathematical sources and historical code remain unchanged. The original 277-source cleanup mapping and its corrections remain authoritative for the v200-to-v201 curation; this file records the separate v201-to-v202 increment.

The outer ZIP is regenerated from this tree. Earlier ZIPs, bytecode, and generated output documents are excluded. SHA256SUMS.txt is regenerated for the new contents; it does not hash itself.

Exact verification: 75 new checks passed. These checks validate formulas and calibrations, not the full analytic proofs. No new interval arithmetic or floating-point certification was used.
