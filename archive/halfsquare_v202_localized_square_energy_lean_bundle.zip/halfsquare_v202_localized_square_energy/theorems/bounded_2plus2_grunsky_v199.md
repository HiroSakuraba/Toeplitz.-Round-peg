# Bounded 2+2 runaway forces asymptotic Grunsky saturation

## 1. Setup
Let `f:D->Omega` be univalent. Affine-normalize so that

`f(0)=0`, `f'(0)=1`.

For four distinct points `z0,z1,z2,z3` in the disk define

`chi(z0,z1,z2,z3) = ((z1-z0)(z3-z2))/((z2-z0)(z3-z1))`.

The square image has cross-ratio in the finite set

`{1/2,-1,2}`

for any ordering of its four vertices.

Let

`L_f(z,w)=log((f(z)-f(w))/(z-w))`,

using the analytic logarithm on `D x D`. Because `f` is univalent, the divided difference never vanishes, including on the diagonal where it equals `f'(z)`.

For the associated Grunsky coefficients `c_mn`, `m,n>=1`, one has

`L_f(z,w)=ell(z)+ell(w)-sum_{m,n>=1} c_mn z^m w^n`,

where the one-variable logarithmic terms `ell` will cancel below. Put

`B_mn = sqrt(m n) c_mn`.

The Grunsky operator `B` is a contraction on `l^2`.

## 2. Exact cross-ratio/Grunsky identity
Define

`Q_f = log( chi(f(z0),f(z1),f(z2),f(z3)) / chi(z0,z1,z2,z3) )`.

Then

`Q_f = L01+L23-L02-L13`.

The one-variable terms cancel exactly. Symmetry `c_mn=c_nm` gives

`Q_f = - sum_{m,n>=1} c_mn (z0^m-z3^m)(z1^n-z2^n)`.

Define

`u_m=(z0^m-z3^m)/sqrt(m)`,

`v_n=(z1^n-z2^n)/sqrt(n)`.

Then

`Q_f = -u^T B v`.

Consequently

`|Q_f| <= kappa(f) ||u||_2 ||v||_2 <= ||u||_2 ||v||_2`,

where `kappa(f)=||B||<=1` is the Grunsky norm.

This identity is the key v199 bridge: the v198 conformal-modulus load is exactly a Grunsky bilinear load.

## 3. Exact norms of the test vectors
For any `a,b in D`,

`sum_{n>=1} |a^n-b^n|^2/n`

is exactly

`log( |1-a conjugate(b)|^2 / ((1-|a|^2)(1-|b|^2)) )`.

Equivalently, if `rho(a,b)` is pseudohyperbolic distance,

`||u(a,b)||_2^2 = -log(1-rho(a,b)^2)`.

If `|a|=|b|=r` and their angular separation is `Delta`,

`||u(a,b)||_2^2 = log(1 + 4 r^2 sin^2(Delta/2)/(1-r^2)^2)`.

## 4. Bounded 2+2 geometry
Write the four conformal angles in cyclic order with gaps

`g1, g2, g3 >0`,

and total packet width

`delta=g1+g2+g3`.

The 2+2 stratum means the first and last gaps are tight pairs:

`g1+g3 = O(1-r)`.

Set

`eps=1-r`,

`R=delta/eps -> infinity`.

Then `g2=delta-O(eps)=delta(1+o(1))`.

For co-circular points,

`chi_in = [sin(g1/2) sin(g3/2)]/[sin((g1+g2)/2) sin((g2+g3)/2)]`.

Hence

`chi_in = (g1 g3/delta^2)(1+o(1))`.

For an exact square image, `|chi_out|` is one of `1/2,1,2`. Therefore

`Re Q_f = log |chi_out/chi_in|`

`= log(delta^2/(g1 g3)) + O(1)`.

The two Grunsky vectors use the long separations `z0-z3` and `z1-z2`, both angularly `delta(1+o(1))`. Thus

`||u||^2 = 2 log R + O(1)`,

`||v||^2 = 2 log R + O(1)`,

and

`||u|| ||v|| = 2 log R + O(1)`.

## 5. Pair-width coercion
The Grunsky inequality gives

`log(delta^2/(g1 g3))+O(1) <= 2 log R+O(1)`.

Since `delta=R eps`, this becomes

`log(eps^2/(g1 g3)) <= O(1)`.

Therefore

`g1 g3 >= c eps^2`

for some sequence-uniform `c>0` once the upper bound `g1+g3<=C eps` is fixed.

Because `g1+g3<=C eps`, each tight pair is individually comparable to the Abel depth:

`c_C eps <= g1,g3 <= C eps`.

So bounded 2+2 cannot hide a still smaller sub-subpair. Both pair scales genuinely survive in the finite inner blow-up.

## 6. Asymptotic saturation
The preceding coercion also gives

`g1 g3 asymp eps^2`.

Hence

`Re Q_f = 2 log R+O(1)`.

But

`||u|| ||v|| = 2 log R+O(1)`.

Therefore

`|u^T B v|/(||u|| ||v||) -> 1`.

This is asymptotic equality in the Grunsky inequality for an explicit sequence of test vectors.

### Corollary 6.1: Grunsky norm one
If `kappa(f)<1`, then

`|Q_f| <= kappa(f)(2 log R+O(1))`,

contradicting `Re Q_f=2 log R+O(1)` as `R->infinity`.

Thus bounded 2+2 runaway for one fixed Riemann map requires

`kappa(f)=1`.

### Corollary 6.2: approximate singular-vector relation
Normalize

`U=conjugate(u)/||u||`, `V=v/||v||`.

Choose a phase `e^{i phi_R}` matching the phase of the extremal pairing. Since `B` is a contraction and the pairing misses equality by only `O(1)` while the squared norms are `Theta(log R)`, one obtains

`||B V - e^{i phi_R} U||_2 = O((log R)^(-1/2))`.

Equivalently, in unnormalized form after the harmless norm-ratio correction,

`||B v - e^{i phi_R}(||v||/||u||) conjugate(u)||_2 = O(1)`.

Thus the Grunsky operator must transport one explicit boundary wave packet into the conjugate of the other with only bounded total `l^2` error while each packet has norm `Theta(sqrt(log R))`.

## 7. Calibration: Koebe and analytic approximants
For the Koebe function

`k(z)=z/(1-z)^2`,

one computes exactly

`(k(z)-k(w))/(z-w)=(1-zw)/((1-z)^2(1-w)^2)`.

Thus the two-variable Grunsky part is

`log(1-zw)=-sum_{n>=1}(zw)^n/n`,

so

`c_nn=1/n`, `c_mn=0` for `m!=n`,

and hence

`B=I`.

Koebe saturates the Grunsky inequality on every vector. Its image is a slit domain, not a bounded Jordan domain; it is a useful extremal calibration, not a Toeplitz counterexample.

For

`k_s(z)=z/(1-sz)^2`, `0<s<1`,

the same computation gives

`B_nn=s^(2n)`.

Therefore `||B||=s^2<1` for every fixed `s<1`, although `||B||->1` as `s->1`. This calibrates the fixed-map nature of the v199 theorem: a sequence of increasingly singular analytic Jordan maps can approximate Grunsky extremality, but one fixed map supporting arbitrarily large bounded-2+2 runaway must already sit at norm one.
