# v198 — Bounded-inner-scale 3+1: parabolic tangent-flow theorem

## 1. Setting

Let \(f:\mathbb D\to\Omega\) be a Riemann map onto a bounded Jordan domain.  Suppose exact nondegenerate squares occur on the Abel curves
\[
\Gamma_r=f(rS^1)
\]
along a collapsing runaway sequence
\[
r_n\uparrow1,
\qquad
\varepsilon_n=1-r_n,
\qquad
\delta_n\to0,
\qquad
R_n=\frac{\delta_n}{\varepsilon_n}\to\infty.
\]
Assume the normalized angular shape tends to a \(3+1\) vertex.  Thus three parameter points form a tight triple of angular diameter \(\kappa_n\), while the fourth lies at distance \(\asymp\delta_n\), and
\[
\boxed{
\Lambda_n:=\frac{\kappa_n}{\varepsilon_n}=O(1).
}
\]
The purpose of this note is to determine what this branch forces on the set of conformal blow-up tangents at the common boundary point.

## 2. A three-vertex angular floor

The v192 ultralocal argument can be strengthened in a direction tailored to \(3+1\).

### Lemma 2.1 — three square vertices cannot fit below the Abel depth

For \(r\ge1/2\), if three vertices of a Euclidean square lie on \(f(rS^1)\) and their three conformal parameters are contained in an angular interval of length \(\kappa\), then
\[
\boxed{
\kappa>\frac{1-r}{100}.
}
\]

### Proof

Write \(\varepsilon=1-r\) and
\[
h(t)=f(re^{it}).
\]
The universal pre-Schwarzian estimate used in v192 gives
\[
\left|\frac{d}{dt}\log h'(t)\right|
\le1+\frac3\varepsilon.
\]
If \(\kappa\le\varepsilon/100\), then throughout the interval
\[
\left|\frac{h'(t)}{h'(t_0)}-1\right|
\le e^{0.035}-1=:\eta<0.036.
\]
Hence all three images lie in a strip of half-width at most
\[
\eta |h'(t_0)|\kappa
\]
around one affine tangent line.  The two extreme parameter values have image separation at least
\[
(1-\eta)|h'(t_0)|\kappa.
\]
If the square side is \(s\), any pair of square vertices is at distance at most \(\sqrt2s\), so
\[
s\ge\frac{(1-\eta)|h'(t_0)|\kappa}{\sqrt2}.
\]
But any three vertices of a square form a right isosceles triangle whose minimum width over all strip directions is \(s/\sqrt2\).  The tangent strip has total width at most \(2\eta|h'(t_0)|\kappa\), so a square would require
\[
2\eta|h'(t_0)|\kappa
\ge
\frac{s}{\sqrt2}
\ge
\frac{(1-\eta)|h'(t_0)|\kappa}{2},
\]
that is \(\eta\ge1/5\), a contradiction. ∎

### Consequence

In the bounded-\(\Lambda\) branch,
\[
\boxed{
\frac1{100}<\Lambda_n\le C
}
\]
after discarding finitely many terms.

Moreover, after passing to a subsequence, neither internal gap of the tight triple can be \(o(\varepsilon_n)\).  To see this, center a canonical microscope at the triple.  The three preimages stay in a fixed compact subset of \(\mathbb D\).  If two of them collided while the third stayed separated, local uniform convergence of normalized schlicht maps would make one pair of square vertices coalesce while another pair remained separated.  This is impossible because all nonzero pairwise distances among three square vertices differ by at most a factor \(\sqrt2\).

Thus the three marked preimages have three distinct finite limits in the triple-centered microscope.

## 3. Tangent set at the common boundary point

Rotate so that the common boundary parameter is \(1\).  Define the full canonical tangent set
\[
\mathfrak T_1(f)
:=
\left\{
F:\exists a_n\to1\text{ with }\mathcal C_{a_n}f\to F
\text{ locally uniformly}
\right\}.
\]
The normalized schlicht class is compact, so \(\mathfrak T_1(f)\) is nonempty and compact.

For \(t\in\mathbb R\), define the parabolic renormalization
\[
\boxed{
\mathscr P_tF
:=
\mathscr R_{P_t}F,
}
\]
where
\[
P_t=G_0^{-1}(G_0+it),
\qquad
G_0(z)=\frac{z}{1+z}.
\]

### Theorem 3.1 — tangent-set invariance

For every \(F\in\mathfrak T_1(f)\) and every real \(t\),
\[
\boxed{
\mathscr P_tF\in\mathfrak T_1(f).
}
\]

### Proof

Represent \(F\) by centers
\[
a_n=r_ne^{i\theta_n}\to1.
\]
Put
\[
b_n=r_ne^{i(\theta_n+(1-r_n^2)t)}.
\]
Then \(b_n\to1\).  By the exact cocycle from the companion note,
\[
\mathcal C_{b_n}f
=
\mathscr R_{h_{a_n,b_n}}(\mathcal C_{a_n}f),
\]
and
\[
h_{a_n,b_n}\to P_t.
\]
Passing to the locally uniform limit gives
\[
\mathcal C_{b_n}f\to\mathscr P_tF.
\]
Hence \(\mathscr P_tF\) belongs to the same tangent set. ∎

This is the fixed-map compatibility that v197 was missing: the different local microscopes are tied together by a continuous dynamical action.

## 4. Classification of stationary tangents

### Theorem 4.1 — the only parabolically stationary normalized tangent is the regular Möbius tangent

If a normalized univalent \(F\) satisfies
\[
\mathscr P_tF=F
\qquad\text{for every }t\in\mathbb R,
\]
then
\[
\boxed{
F(z)=G_0(z)=\frac{z}{1+z}.
}
\]

### Proof

Put
\[
X=G_0(z),
\qquad
H(X)=F(G_0^{-1}(X)).
\]
Then \(H\) is univalent on
\[
\Pi=\{\operatorname{Re}X<1/2\},
\]
with
\[
H(0)=0,\qquad H'(0)=1.
\]
Since \(G_0(P_tz)=G_0(z)+it\), the stationarity equation becomes
\[
\boxed{
H(X+it)=H(it)+H'(it)H(X).
}
\]
Differentiate twice in \(X\) and set \(X=0\):
\[
H''(it)=H'(it)H''(0).
\]
The imaginary axis lies in \(\Pi\), so the identity theorem gives
\[
H''=aH'
\]
throughout \(\Pi\), where \(a=H''(0)\).

If \(a=0\), then \(H(X)=X\), hence \(F=G_0\).

If \(a\ne0\), normalization gives
\[
H(X)=\frac{e^{aX}-1}{a}.
\]
But this has the nonzero period
\[
\frac{2\pi i}{a}.
\]
A left half-plane contains two points differing by any prescribed finite complex period, so this \(H\) is not injective on \(\Pi\), contradicting univalence.  Therefore \(a=0\). ∎

### Corollary 4.2 — finite tangent sets collapse to the regular tangent

If \(\mathfrak T_1(f)\) is finite, then
\[
\boxed{
\mathfrak T_1(f)=\{G_0\}.
}
\]
Indeed, for any \(F\in\mathfrak T_1(f)\), the map
\[
t\mapsto\mathscr P_tF
\]
is continuous with image in the finite set \(\mathfrak T_1(f)\), so it is constant.  Theorem 4.1 applies.

## 5. Main 3+1 consequence

### Theorem 5.1 — bounded-inner-scale 3+1 requires a continuum of tangents

A bounded-\(\Lambda\) \(3+1\) runaway exact-square sequence cannot occur at a boundary point whose canonical tangent set is finite.  More strongly, if such a sequence occurs then
\[
\boxed{
\mathfrak T_1(f)\text{ contains an uncountable connected parabolic orbit.}
}
\]

### Proof

Center the microscope on the tight triple.  By Lemma 2.1 and the internal-gap noncollapse argument, after passing to a subsequence the three marked preimages converge to three distinct finite points on the limiting horocycle
\[
\mathcal H=\{|z+1/2|=1/2\}.
\]
Compactness gives
\[
\mathcal C_{a_n}f\to F\in\mathfrak T_1(f).
\]
The three image points converge to three distinct vertices of a Euclidean square and hence are noncollinear.

But
\[
G_0(U(s))=is,
\]
so \(G_0\) sends the entire limiting horocycle to a straight line.  Therefore
\[
F\ne G_0.
\]
By Theorem 3.1 the whole orbit
\[
\{\mathscr P_tF:t\in\mathbb R\}
\]
lies in \(\mathfrak T_1(f)\).  The orbit cannot be constant, because a constant orbit would make \(F=G_0\) by Theorem 4.1.  A nonconstant connected subset of a metric space is uncountable. ∎

This does not eliminate the general Jordan case, but it changes the bounded-\(\Lambda\) \(3+1\) branch from “an arbitrary singular tangent might do it” to the much more restrictive statement:

> the common boundary point must support a continuum of mutually re-centered conformal tangent geometries.

## 6. What happens to the v197 Möbius-circle calibration

Take
\[
M_c(z)=\frac{z}{1+cz},
\qquad 0\le c<1.
\]
Write \(a=1-c\).  In the half-plane coordinate \(X=G_0(z)\),
\[
M_c(G_0^{-1}(X))=\frac{X}{1-aX}.
\]
A direct calculation gives the exact orbit law
\[
\boxed{
\mathscr P_tM_c=M_{c_t},
\qquad
c_t=1-\frac{1-c}{1-i(1-c)t}.
}
\]
Hence
\[
\boxed{c_t\to1\quad(|t|\to\infty),}
\]
so
\[
\mathscr P_tM_c\to M_1=G_0
\]
locally uniformly.

Therefore, if a nonregular Möbius-circle tangent \(M_c\) ever arises from one fixed Jordan map at a boundary point, fixed-map compatibility forces its entire parabolic orbit to arise there as well, and the regular tangent \(G_0\) lies in the closure of that tangent set.

This is a major correction to the naive use of the v197 calibration: \(M_c\) may demonstrate abstract local feasibility, but it cannot be treated as an isolated tangent geometry of a fixed map.

## 7. A warning: one discrete recurrence is not enough

The continuous-flow hypothesis in Theorem 4.1 is essential.  There are non-Möbius normalized univalent functions fixed by one nonzero parabolic time.

Let \(T>0\) and choose \(\eta>0\) so small that
\[
\frac{2\pi\eta}{T}e^{\pi/T}<1.
\]
On \(\Pi\), define
\[
H_{T,\eta}(X)
=
\frac{X+\eta(e^{2\pi X/T}-1)}{1+2\pi\eta/T}.
\]
Then
\[
H_{T,\eta}(0)=0,
\qquad
H'_{T,\eta}(0)=1,
\]
and
\[
\operatorname{Re}H'_{T,\eta}(X)>0
\]
throughout the convex half-plane \(\Pi\), so \(H_{T,\eta}\) is univalent.  It satisfies
\[
H_{T,\eta}(X+iT)-H_{T,\eta}(iT)=H_{T,\eta}(X),
\qquad
H'_{T,\eta}(iT)=1.
\]
Thus
\[
F_{T,\eta}=H_{T,\eta}\circ G_0
\]
is normalized, non-Möbius, univalent, and
\[
\boxed{
\mathscr P_TF_{T,\eta}=F_{T,\eta}.
}
\]

So a single repeated scale or a discrete parabolic period does not imply regularity.  What forces \(G_0\) is stationarity under the full continuous re-centering flow, which follows when the tangent set is finite.
