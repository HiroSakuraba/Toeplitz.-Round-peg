# Correct compactification of bounded 3+1

## 1. Coordinates

Use

`G(z)=z/(1+z)`,

which maps the unit disk onto the half-plane

`Pi={Re X<1/2}`.

Its inverse is

`J(X)=X/(1-X)`.

The distinguished limiting horocycle is `X=is`, `s in R`. Under `J`,

`z_T=J(iT)=iT/(1-iT)`

lies on the circle

`|z+1/2|=1/2`

and tends to the tangency point `-1` as `T->infinity`.

Indeed

`z_T+1 = 1/(1-iT)`.

Thus the natural compactifying source coordinate is

`sigma=z+1`,

or, along the real one-parameter tail, any smooth real coordinate asymptotic to `1/T`. Treating `T` itself as a smooth endpoint coordinate is invalid.

## 2. Exact derivative conversion

Let `H` be univalent on `Pi` and set

`F(z)=H(G(z))`.

Then `H(X)=F(J(X))`. Since

`J'(X)=1/(1-X)^2`,

we have exactly

`H'(iT)=F'(z_T)/(1-iT)^2`.

Equivalently,

`boxed: F'(z_T)=(1-iT)^2 H'(iT)`.

This is the missing factor in v199.

The Koebe argument proving `H'(iT)->0` is compatible with a completely nonzero compactified derivative: if `F'(z_T)->d!=0`, then

`H'(iT)~ -d/T^2`.

So the quadratic decay seen in the Möbius calibration is the **critical nondegenerate case**, not evidence of rank loss.

## 3. Remote-germ trichotomy

Assume `F` has a one-sided asymptotic expansion along the horocycle approaching `-1`:

`F(-1+sigma)=L+c sigma^beta+o(|sigma|^beta)`,

with `c!=0`, `beta>0`.

Then in the natural source coordinate `sigma`:

- `beta>1`: `(F(-1+sigma)-L)/sigma ->0`; the remote first-order column vanishes if the extension is differentiable;
- `beta=1`: `(F(-1+sigma)-L)/sigma ->c`; the remote column converges to a nonzero vector;
- `0<beta<1`: the difference quotient diverges; the ordinary compactified square map is not `C^1` in this coordinate.

In terms of the old tail `A(T)=H(iT)-L`, since `sigma~i/T`, this is the same exponent trichotomy

`A(T)~c' T^{-beta}`.

The coordinate-invariant lesson is:

`boxed: rank loss requires superlinear collapse in the natural source compactification.`

The statement `H'(iT)->0` is insufficient.

## 4. What remains from the v199 Koebe lemma

The conditional lemma itself remains correct:

If one fixed univalent `H` has a finite asymptotic value `H(iT)->L`, then `H'(iT)->0`.

But its geometric meaning is now limited. It says that the **noncompact** parameter `T` slows down. It does not determine whether the compactified source arc has nonzero, zero, or infinite first derivative at its endpoint.

## 5. Consequence for the research program

The bounded-3+1 branch must now be split according to the remote germ:

`(A) regular-critical: F'(-1) exists and is nonzero;`

`(B) flat: F'(-1)=0 (or superlinear one-sided approach);`

`(C) singular: no finite first derivative in the natural compactification.`

Only branch (B) supports the v191-style rank-three/cokernel mechanism without further work. Branches (A) and (C) need different arguments.
