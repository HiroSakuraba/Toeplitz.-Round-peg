# Critical beta=1 can have a full-rank compactified 3+1 square

This file gives an explicit calibration showing that the corrected 3+1 endpoint need not be rank three.

## 1. The reference horocycle square

Let

`J(X)=X/(1-X)`.

On the imaginary axis,

`J(0)=0`,

`J(i)=(-1+i)/2`,

`J(-i)=(-1-i)/2`,

and

`J(i infinity)=-1`.

These four points are the vertices of the square

`Q_j=-1/2 + (1/2) i^j`, `j=0,1,2,3`,

with the remote vertex `Q_2=-1`.

## 2. Perturb the image while fixing the square

Define

`P(z)=(z+1/2)^4-1/16`,

`h(z)=i+(2z+1)^2`,

and, for real `e`,

`Psi_e(z)=z+e P(z)h(z)`.

Since `P(Q_j)=0`, all four square vertices are fixed exactly:

`Psi_e(Q_j)=Q_j`.

The derivative of the perturbation satisfies on `|z|<=1`

`|(P h)'| <= |P'| |h| + |P| |h'|`

`<= 13.5*10 + 5.125*12 = 196.5`.

Hence for `|e|<1/200`,

`sup_D |Psi_e'-1| <1`.

Because the disk is convex, integration along the line segment from `z` to `w` gives

`|Psi_e(z)-Psi_e(w)| >= (1-196.5|e|)|z-w|`.

Thus `Psi_e` is injective on the closed disk, and its image boundary is an analytic Jordan curve.

Set

`H_e(X)=Psi_e(J(X))`.

## 3. Critical endpoint rate

Put `q=1/T`. Then

`J(i/q)=-1+i q+q^2+O(q^3)`.

Also

`Psi_e'(-1)=1-(e/2)(1+i)`,

which is nonzero for `|e|<1/200`.

Therefore

`H_e(i/q)=-1 + i Psi_e'(-1) q + O(q^2)`.

So this compactified 3+1 endpoint has exactly

`boxed: beta=1`.

The remote first-order degree of freedom survives.

## 4. Full square-map Jacobian

Use the square-error DFT channels

`S_2=(1/4) sum_j Z_j i^(-2j)`,

`S_3=(1/4) sum_j Z_j i^(-3j)`.

Take real source variables

`(s_0,s_1,q,s_3)`

near

`(0,1,0,-1)`,

with

`Z_0=H_e(i s_0)`,

`Z_1=H_e(i s_1)`,

`Z_2=H_e(i/q)`,

`Z_3=H_e(i s_3)`.

Realify `(S_2,S_3)` as a map `R^4 -> R^4`.

Direct symbolic differentiation gives the exact determinant

`boxed: det D(S_2,S_3) = -e^2/512`.

Thus for every nonzero real `e` with `|e|<1/200`, the compactified endpoint square is **fully transverse**.

## 5. Interpretation

This calibration proves three things.

1. `beta=1` is compatible with the exact 3+1 square geometry.
2. The natural compactified remote column can be nonzero.
3. Even the entire four-variable compactified square Jacobian can have rank four.

Therefore the v199 statement that bounded 3+1 must end at rank at most three is false even in a very tame analytic tangent model.

This is not a counterexample to the square-peg theorem. It is a counterexample to the proposed **local endpoint mechanism**. To exclude bounded 3+1 one must use extra information saying that the tangent model and its endpoint germ arise from repeated blow-ups of one fixed Jordan map.
