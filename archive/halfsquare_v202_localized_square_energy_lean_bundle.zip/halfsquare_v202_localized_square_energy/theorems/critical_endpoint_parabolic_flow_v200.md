# Critical regular endpoint implies a heteroclinic parabolic orbit to the regular tangent

This is a conditional but useful refinement of the beta=1 branch.

## 1. Straightened parabolic re-centering

For a tangent map `H` on

`Pi={Re X<1/2}`,

the parabolic re-centering by `t` is, in straightened coordinates,

`H_t(X)=[H(X+i t)-H(i t)]/H'(i t)`.

This is the half-plane version of the exact disk action `mathscr P_t` from v198.

## 2. Pass to the natural disk endpoint

Write

`F(z)=H(G(z))`,

`G(z)=z/(1+z)`,

and `J=G^{-1}`.

The remote endpoint is `z=-1`. Suppose `F` extends `C^1` to a one-sided neighborhood of `-1` in the closed disk and

`F'(-1)=d != 0`.

Then for fixed compact `X`-sets and `t->+infinity`,

`J(X+i t)-J(i t)=J'(i t) X + o(|J'(i t)|)`

uniformly, while

`F(J(X+i t))-F(J(i t))`

`=d [J(X+i t)-J(i t)] + o(|J'(i t)|)`.

Also

`H'(i t)=F'(J(i t))J'(i t)=d J'(i t)(1+o(1))`.

Therefore

`boxed: H_t(X)->X`

locally uniformly on `Pi`.

Equivalently, in disk normalization,

`boxed: mathscr P_t F_tangent -> G(z)=z/(1+z)`.

## 3. Interpretation

A critical beta=1 tangent whose remote prime end is genuinely regular does not remain exotic under repeated parabolic motion toward that remote endpoint. Its re-centered tangents converge to the regular Möbius tangent.

Thus such a 3+1 branch has a **heteroclinic** tangent-flow structure:

`nonregular square-carrying tangent  --->  regular tangent`.

This is compatible with v198's conclusion that the tangent set must contain a continuum. It is not a contradiction: under this re-centering the marked square itself escapes to the opposite end of the straightened horocycle rather than remaining in a fixed compact window.

## 4. Limits of the theorem

The `C^1` endpoint hypothesis is stronger than merely knowing

`H(iT)-L ~ c/T`.

A one-dimensional critical decay law along the horocycle does not automatically control nearby complex directions. Therefore this theorem must not be applied to an arbitrary Jordan tangent without first proving the needed endpoint regularity.
