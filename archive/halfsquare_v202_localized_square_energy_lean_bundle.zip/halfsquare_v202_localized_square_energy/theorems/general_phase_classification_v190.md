> **v201 scope correction:** retain the local classification. Globalization from simple connectivity alone is false. See [the counterexample](../notes/scope_corrections_v201.md). The original body below is preserved for audit.

# General phase-lattice forcing and classification of singular square-phase foliations

## 1. Square evaluation map

Let
\[
v_0=(1,0),\quad v_1=(0,1),\quad v_2=(-1,0),\quad v_3=(0,-1).
\]
A positively oriented square is
\[
z_j=b+sR_\theta v_j,
\qquad s>0.
\]
For a scalar phase `H`, define
\[
F_H(b_x,b_y,s,\theta)=\bigl(H(z_0),H(z_1),H(z_2),H(z_3)\bigr).
\]

## 2. General phase-lattice forcing theorem

### Theorem 2.1
Let `H` be `C1` on a neighborhood of a reference square `u_*=(b_*,s_*,theta_*)`, and suppose
\[
\det D F_H(u_*)\ne0.
\]
Let
\[
\Phi_L(z)=L H(z)+e_L(z),\qquad L\to\infty,
\]
where each `e_L` is continuous on a fixed neighborhood of the four reference vertices and
\[
\eta_L:=\|e_L\|_\infty/L\to0.
\]
Then for every sufficiently large `L` there is an exact square `u_L` with all four vertices on the phase layers
\[
\Phi_L(z_j(u_L))\in\pi\mathbb Z,
\]
and
\[
|u_L-u_*|=O(\eta_L+L^{-1}).
\]

### Proof
Let `J=D F_H(u_*)`. Choose a ball on which
\[
|F_H(u)-F_H(u_*)-J(u-u_*)|\le o(|u-u_*|)
\]
uniformly, and let `m>0` be a lower singular-value bound for `J` there.

For each `L`, choose `k_L in Z^4` so that
\[
|\pi k_L-(L F_H(u_*)+E_L(u_*))|\le \pi,
\]
where
\[
E_L(u)=\bigl(e_L(z_0(u)),\ldots,e_L(z_3(u))\bigr).
\]
Take
\[
r_L=C(\eta_L+L^{-1})
\]
with `C` large compared with `m^{-1}`. On `|u-u_*|=r_L`, the linear displacement `LJ(u-u_*)` dominates both the nearest-lattice error and the total continuous perturbation
\[
|E_L(u)-E_L(u_*)|\le 4^{1/2}(2\|e_L\|_\infty)=O(\eta_L L).
\]
The nonlinear remainder is `o(L r_L)` because `r_L->0`.

Hence the map
\[
u\mapsto L F_H(u)+E_L(u)-\pi k_L
\]
is homotopic on the boundary to the invertible linear map `LJ(u-u_*)`, without crossing zero. Its Brouwer degree is therefore `sign det J`, so it has a zero inside the ball.

No derivative bound on `e_L` is used.

## 3. Similarity-generator determinant

Instead of `(b_x,b_y,s,theta)`, use the four infinitesimal generators of the direct-similarity group:

- horizontal translation `X_1=(1,0)`;
- vertical translation `X_2=(0,1)`;
- dilation `X_3(z)=z`;
- rotation `X_4(z)=Jz`.

Changing from these generators to the local square parameters is invertible, so the rank is the same. Thus the square-phase Jacobian is singular exactly when
\[
\det
\begin{pmatrix}
H_x(z_0)&H_y(z_0)&\nabla H(z_0)\cdot z_0&\nabla H(z_0)\cdot Jz_0\\
H_x(z_1)&H_y(z_1)&\nabla H(z_1)\cdot z_1&\nabla H(z_1)\cdot Jz_1\\
H_x(z_2)&H_y(z_2)&\nabla H(z_2)\cdot z_2&\nabla H(z_2)\cdot Jz_2\\
H_x(z_3)&H_y(z_3)&\nabla H(z_3)\cdot z_3&\nabla H(z_3)\cdot Jz_3
\end{pmatrix}=0.
\]
Multiplying any row by a nonzero scalar does not alter singularity. Therefore this condition depends only on the four **gradient directions**, not on `|grad H|`. It is invariant under monotone reparameterization `H -> f(H)`.

Geometrically, singularity says that there is a nonzero infinitesimal direct similarity
\[
V(z)=u+\alpha z+\beta Jz
\]
that is tangent to the level set of `H` at all four square vertices:
\[
V(z_j)\cdot\nabla H(z_j)=0,
\qquad j=0,1,2,3.
\]

## 4. Exact angle identity

Assume `grad H != 0`. On a simply connected patch choose a continuous gradient angle `phi`:
\[
\nabla H=|\nabla H|(\cos\phi,\sin\phi).
\]
For an axis-aligned square with east, north, west, south vertices `E,N,W,S`, direct calculation gives
\[
\det D F_H
=2s\prod_{P\in\{E,N,W,S\}}|\nabla H(P)|\,\mathcal D,
\]
up to the harmless nonzero parameter-change factor, where
\[
\boxed{
\mathcal D=
\sin(\phi_E-\phi_N+\phi_W-\phi_S)
+\sin(\phi_E-\phi_W)\sin(\phi_N-\phi_S).
}
\]
The same formula holds in every rotated coordinate frame because only angle differences occur.

## 5. Infinitesimal rigidity PDE

Suppose the square-phase Jacobian is singular for every sufficiently small square in a region. Expand the angle identity for a square of radius `s` in orthonormal directions `(u,v)`:
\[
\phi_{uu}-\phi_{vv}+4\phi_u\phi_v=0.
\]
Because this holds for every rotation of `(u,v)`, its `cos 2theta` and `sin 2theta` coefficients vanish separately:
\[
\boxed{
\phi_{xx}-\phi_{yy}+4\phi_x\phi_y=0,
}
\]
\[
\boxed{
\phi_{xy}=\phi_x^2-\phi_y^2.
}
\]
Set
\[
w=\phi_x+i\phi_y.
\]
Then
\[
\boxed{w_{\bar z}=i w^2},
\qquad
w_z=\frac12\Delta\phi\in\mathbb R.
\]

Let `R=w_z`. Commuting mixed derivatives gives
\[
R_{\bar z}=2iwR.
\]
If `R` were nonzero at a point, it would be nonzero on a neighborhood. There
\[
(\log|R|)_x=-4\phi_y,
\qquad
(\log|R|)_y=4\phi_x.
\]
Thus `log|R|-4 i phi` satisfies the Cauchy-Riemann equations. In particular `phi` is harmonic, so
\[
R=\frac12\Delta\phi=0,
\]
a contradiction. Hence
\[
\boxed{R\equiv0}.
\]
Therefore `w` is anti-holomorphic and obeys the scalar ODE
\[
\frac{dw}{d\bar z}=iw^2.
\]
On each connected patch the only possibilities are
\[
\boxed{w\equiv0}
\]
or
\[
\boxed{w=\frac{i}{\bar z-\bar z_0}}.
\]
Consequently
\[
\boxed{\phi\equiv\phi_0}
\]
or
\[
\boxed{\phi(z)=\arg(z-z_0)+\phi_0}.
\]

## 6. Classification theorem

### Theorem 6.1
Let `U` be a connected planar region, `H in C4(U)`, and `grad H != 0`. Suppose `det D F_H=0` for every sufficiently small square contained in `U`.

Then locally, and globally on any simply connected subregion on which the indicated angular lift is defined, exactly one of the following holds.

### Parallel family
There is a fixed nonzero vector `n` and a one-variable `C4` function `f` with `f' != 0` such that
\[
\boxed{H(z)=f(n\cdot z).}
\]
The phase foliation is invariant under translation perpendicular to `n`.

### Similarity-spiral family
There are `z_0`, real constants `(alpha,beta)!=(0,0)`, and a one-variable `C4` function `f` with `f' != 0` such that
\[
\boxed{
H(z)=f\bigl(\beta\log|z-z_0|-\alpha\arg(z-z_0)\bigr).
}
\]
This is understood locally on an angular lift. The phase foliation is invariant under the one-parameter direct-similarity flow
\[
\dot z=(\alpha+i\beta)(z-z_0).
\]
Special cases include:

- concentric circles (`alpha=0` after reparameterization);
- rays (`beta=0`);
- genuine logarithmic spirals (`alpha beta != 0`).

Conversely every phase in either family has singular four-square Jacobian at every square, because the corresponding nonzero infinitesimal similarity is tangent to all phase leaves globally.

## 7. Quadratic audit

Let
\[
H(z)=\frac12 z^TQz+\ell\cdot z+c,
\]
with `Q` symmetric.

If `Q` is nonsingular, translate to remove `ell` and rotate so
\[
Q=\operatorname{diag}(\lambda,\mu).
\]
For an axis square centered at `(x,y)` with half-side parameter `s`, the local square Jacobian is
\[
\boxed{
4\lambda\mu\,s^3xy(\lambda-\mu)^2.
}
\]
Thus it vanishes identically only when `lambda=mu`, the concentric-circle family.

If `rank Q=1`, rotate and translate along the quadratic direction to write
\[
H=\frac\lambda2x^2+Ey+c.
\]
Then
\[
\boxed{
\det D F_H=4E\lambda^3s^3x.
}
\]
Hence everywhere singularity forces `E=0`, giving the parallel/ridge family.

This exactly matches Theorem 6.1.

## 8. Consequence for the Toeplitz program

If the deep v189 nested lamination admits a coherent scalar phase description
\[
\Phi_L=L H+o(L)
\]
on a patch, there are only two possibilities:

1. `H` has one full-rank square. Then Theorem 2.1 forces an exact phase-lattice square.
2. `H` is similarity-symmetric: parallel-line or logarithmic-spiral type.

Thus the coherent scalar-phase branch has been reduced to an explicit exceptional family. The unresolved issue is now twofold:

- obtain such a scalar metric phase from the topological nested-lobe stack;
- treat the rank-three similarity-symmetric family by a mixed-scale degree argument using the subleading phase.

The second issue contains the v187 critical radial spiral as one special case, where the subleading angular term already restores the missing direction and forces squares.
