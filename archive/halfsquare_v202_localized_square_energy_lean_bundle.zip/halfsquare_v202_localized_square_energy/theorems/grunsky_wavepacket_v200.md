> **v201 coordinate note:** setting the first angle to zero rotates the map and matrix for each event unless that angle is fixed. Use [the global-coordinate theorem](../notes/finite_point_grunsky_energy.md) for one fixed operator. The original body below is preserved for audit.

# Bounded 2+2 reduces to one self-extremizing broadband Grunsky packet

## 1. Setup

Write the four conformal parameters, after rotation, as

`z0=r`,

`z1=r exp(i g1)`,

`z2=r exp(i(delta-g3))`,

`z3=r exp(i delta)`.

In bounded 2+2,

`eps=1-r`, `R=delta/eps -> infinity`,

and v199 proves

`g1 asymp eps`, `g3 asymp eps`.

Define the two long-pair Grunsky vectors

`u_n=(z0^n-z3^n)/sqrt(n)`,

`v_n=(z1^n-z2^n)/sqrt(n)`.

Let the diagonal unitary modulation be

`(D_theta x)_n=exp(i n theta)x_n`.

## 2. The two long-pair vectors are the same packet up to O(1)

Compute

`v_n-(D_g1 u)_n`

`= r^n [exp(i n(delta+g1))-exp(i n(delta-g3))]/sqrt(n)`.

This is itself a difference vector whose angular separation is `g1+g3=O(eps)`.

Using the exact norm identity from v199,

`||v-D_g1 u||^2`

`= log(1+4 r^2 sin^2((g1+g3)/2)/(1-r^2)^2)`

`=O(1)`.

But

`||u||^2=||v||^2=2 log R+O(1)`.

Hence the relative discrepancy is

`O((log R)^(-1/2))`.

Also, exactly,

`conjugate(u)=-D_{-delta}u`.

## 3. Combine with Grunsky saturation

v199 proves that there is a phase `phi_R` for which

`||Bv-exp(i phi_R) conjugate(u)||=O(1)`.

Since `B` is a contraction and `v-D_g1 u=O(1)`, we obtain

`boxed: ||D_delta B D_g1 u + exp(i phi_R) u|| = O(1)`.

Normalize

`W_R=u/||u||`.

Then

`boxed: ||(D_delta B D_g1 + exp(i phi_R) I) W_R||`

`= O((log R)^(-1/2)).`

Thus a bounded-2+2 square produces one explicit weakly-null packet `W_R` which is an approximate unimodular eigenvector of the phase-twisted Grunsky operator.

This is stronger structurally than merely knowing `||B||_ess=1`: the extremizer has a prescribed difference-vector form and a prescribed multiscale spectrum.

## 4. Every interior dyadic octave carries constant unnormalized energy

The packet has

`|u_n|^2 = 4 r^(2n) sin^2(n delta/2)/n`.

For a scale parameter `M`, define the dyadic octave

`I_M={n: M/delta <= n < 2M/delta}`.

Fix any `c<1`. For all sufficiently large absolute `M0`, uniformly for

`M0 <= M <= c R`,

and along `eps->0`, `R->infinity`, one has

`boxed: c0 <= sum_{n in I_M}|u_n|^2 <= C0`,

with constants depending only on `c` (and the harmless fixed choice of `M0`).

### Proof sketch

For `n<=2c/eps`, the radial factor `r^(2n)` is bounded above and below by positive constants.

Then use

`sin^2(n delta/2)=(1-cos(n delta))/2`.

The harmonic part over a dyadic block contributes approximately `(1/2)log 2`. The oscillatory cosine sum is `O(1/M)` by Abel summation, since partial sums of `exp(i n delta)` are `O(1/delta)` while `1/n` is of size `delta/M` on the block.

Choosing `M0` large makes the oscillatory error strictly smaller than the harmonic main term.

Therefore each octave between the low transition `1/delta` and any fixed fraction of the high transition `1/eps` carries a fixed positive amount of energy.

Since the total energy is

`2 log R+O(1)`,

a normalized packet carries

`Theta(1/log R)`

in each of `Theta(log R)` consecutive interior octaves.

## 5. Why this matters

The 2+2 branch is not asking the Grunsky operator to amplify one isolated high mode. It must coherently reproduce one packet whose energy is spread through essentially every scale in a logarithmically long corridor.

The remaining loophole is **where the operator sends each octave**. The near-extremizer relation does not yet prove octave-to-nearby-octave transport. A norm-one Grunsky operator could, in principle, use substantial off-diagonal scale mixing.

That is the clean next operator-theoretic target.
