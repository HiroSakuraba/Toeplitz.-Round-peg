# Nested lobe lamination forced by primitive concentration

## 1. Setup

Let \(\sigma:[0,1]\to\mathbb R^2\) be a simple polygonal arc with endpoints \(p,q\), diameter at most \(r\), and let \(e=[q,p]\) be its closing chord. Put
\[
\Gamma=\sigma+e,
\qquad
\alpha=\frac12(x\,dy-y\,dx),
\qquad
\mathcal A=\int_\Gamma\alpha.
\]
Assume first that the line \(\ell\) through \(p,q\) meets \(\sigma\) transversely away from the endpoints and contains no polygon edge. Nongeneric line pieces are handled by an arbitrarily small perturbation or by the component formulation used in v183--v184.

Let \(\sigma_i\) be the connected components of \(\sigma\setminus\ell\). Each \(\sigma_i\) lies in one open half-plane bounded by \(\ell\), has endpoints \(a_i,b_i\in\ell\), and closes with the chord interval \([b_i,a_i]\subset\ell\) to a simple Jordan loop
\[
L_i=\sigma_i+[b_i,a_i].
\]
Write \(D_i\) for its bounded Jordan domain and \(\epsilon_i\in\{+1,-1\}\) for its orientation sign.

Because the line pieces telescope as oriented one-chains,
\[
\boxed{\Gamma=\sum_i L_i.}
\]
Consequently
\[
\boxed{\mathcal A=\sum_i\epsilon_i |D_i|,}
\qquad
\boxed{\operatorname{wind}(\Gamma,z)=\sum_i\epsilon_i\mathbf 1_{D_i}(z).}
\]

## 2. Positive-lobe multiplicity theorem

Reverse the orientation if necessary so that \(\mathcal A>0\). Then
\[
\sum_{\epsilon_i=+1}|D_i|\ge \mathcal A.
\]
Every \(D_i\) is contained in the convex hull \(K=\operatorname{conv}(\sigma)\), and \(\operatorname{diam}K\le r\). By the planar isodiametric inequality,
\[
|K|\le \frac\pi4 r^2.
\]
Define the positive multiplicity function
\[
m_+(z)=\sum_{\epsilon_i=+1}\mathbf 1_{D_i}(z).
\]
Then
\[
\int_K m_+(z)\,dz
=\sum_{\epsilon_i=+1}|D_i|
\ge \mathcal A.
\]
Hence some \(z\in K\setminus\ell\) satisfies
\[
\boxed{
m_+(z)\ge \frac{4\mathcal A}{\pi r^2}.
}
\]
For the v184 concentration packets, \(|\mathcal A|\ge\varepsilon/2\), so
\[
\boxed{
m_+(z)\ge \frac{2\varepsilon}{\pi r^2}.
}
\]
Thus the old high-winding conclusion can be strengthened to a same-sign lobe statement: one point belongs to order \(r^{-2}\) positively oriented endpoint-line lobes.

## 3. Laminarity of simple crosscuts

The off-line pieces \(\sigma_i\) are pairwise disjoint crosscuts of one of the two half-planes bounded by \(\ell\).

Two disjoint crosscuts in the same half-plane have noninterlacing endpoint pairs on \(\ell\). Their chord intervals are therefore either disjoint or nested. The corresponding bounded caps are likewise either disjoint or nested. This is the standard noncrossing-crosscut consequence of the Jordan theorem: if nested endpoint intervals produced crossing caps, one crosscut would have to cross the other to escape the cap cut off by the outer crosscut.

All positive lobes containing the point \(z\) from Section 2 lie in the same half-plane as \(z\). Since their domains all contain \(z\), they cannot be disjoint. Therefore they form an inclusion chain
\[
\boxed{
D_1\supset D_2\supset\cdots\supset D_N\ni z,
\qquad
N\ge \frac{4\mathcal A}{\pi r^2}.
}
\]
This is the **nested lobe lamination** forced by primitive concentration.

It is stronger than merely having many endpoint-line intersections or one point of large winding: the same-sign winding is carried by a depth-\(N\) laminar family of genuine Jordan caps whose off-line boundaries are disjoint subarcs of the original simple arc.

## 4. Same-side cubic spacing

Let \(H\) be the half-plane containing \(z\), and let \(n\) be the unit normal to \(\ell\) pointing into \(H\). Consider the outward normal ray
\[
R_z=\{z+tn:t\ge0\}.
\]
It never meets the artificial chord pieces on \(\ell\). Since every selected \(D_j\) contains \(z\) and is contained in \(K\), the ray exits every \(D_j\) through the actual excursion arc \(\sigma_j\) at a distance \(t_j\le r\).

After ordering the nested domains from inner to outer, the first-exit times are strictly ordered for a generic ray,
\[
0<t_N<\cdots<t_2<t_1\le r.
\]
Therefore
\[
\boxed{
\min_j(t_j-t_{j+1})\le \frac{r}{N-1}.
}
\]
For a v184 packet,
\[
N\ge \frac{2\varepsilon}{\pi r^2},
\]
so
\[
\boxed{
\min_j(t_j-t_{j+1})
\le
\frac{\pi}{2\varepsilon}r^3(1+o(1)).
}
\]
Thus the cubic spacing law does not require the complementary arc or a polar spiral interpretation. It is already present inside the same concentration arc as a nested crosscut stack.

## 5. Critical rainbow model

The nested-lobe conclusion is scale-sharp and need not look like a spiral.

Fix \(N\), set
\[
q_j=1-\frac{j}{3N},\qquad j=0,\ldots,N,
\]
and scale the construction by \(\lambda_N=N^{-1/2}\).

For \(j=0,\ldots,N-1\):

1. traverse the upper semicircle whose diameter is
   \[
   [-q_{j+1},q_j]\times\{0\}
   \]
   from \(q_j\) to \(-q_{j+1}\);
2. if \(j<N-1\), traverse the lower semicircle of radius \(q_{j+1}\) from \(-q_{j+1}\) to \(+q_{j+1}\).

The resulting arc is simple. Its upper caps are nested, positively oriented, and all contain a fixed point \((0,c\lambda_N)\) for any sufficiently small fixed \(c>0\). Closing the final endpoint to the initial endpoint along the \(x\)-axis gives winding exactly \(N\) at that point.

After the \(N^{-1/2}\) scaling,
\[
\operatorname{diam}\sigma_N\asymp N^{-1/2},
\qquad
|\mathcal A_N|\asymp1,
\qquad
\operatorname{wind}(\Gamma_N,z_N)=N.
\]
Hence
\[
N\asymp r_N^{-2}.
\]
On the positive normal ray \(x=0\), the upper-lobe crossing heights are
\[
y_j=\lambda_N\sqrt{q_jq_{j+1}},
\]
and
\[
\boxed{
y_j-y_{j+1}=\frac13\lambda_N^3+o(\lambda_N^3).}
\]
Thus the same critical cubic spacing seen in the root spiral occurs in a completely different, chord-laminated geometry.

## 6. Why topology does not imply the v188 radial phase law

The nested-lobe structure is topological. Let \(F\) be any orientation-preserving homeomorphism of the packet disk that fixes the endpoint line setwise. Applying \(F\) preserves:

- simplicity;
- the lobe incidence tree;
- nesting depth;
- winding multiplicity;
- the existence of the common point contained in the selected lobes.

But it can alter Euclidean layer geometry by order the packet diameter. Even the fixed affine deformation
\[
F(x,y)=(x,2y)
\]
turns a circular rainbow into an elliptic one whose deviation from every concentric circular foliation is order \(r\), not \(o(r)\).

Therefore **planarity and Jordan simplicity alone cannot supply the coherent radial phase law required by v188**. What topology forces is a deep lamination, not a Euclidean radial coordinate on that lamination.

This corrects the proposed v189 route: the missing ingredient is metric rather than purely topological.

## 7. Revised frontier

The forced terminal structure can now be stated without assuming a spiral:
\[
\boxed{
\text{primitive spike}
\Longrightarrow
\text{depth-}r^{-2}\text{ nested same-sign Jordan lobe stack}
\Longrightarrow
\text{actual-arc gaps of order }r^3.
}
\]

The natural next step is to generalize v188 from radial phase laws to an arbitrary scalar phase function \(H(x,y)\). For a square
\[
z_j=c+sR_\theta v_j,
\]
one should study the four-phase map
\[
(c_x,c_y,s,\theta)
\longmapsto
(H(z_0),H(z_1),H(z_2),H(z_3)).
\]
If its \(4\times4\) Jacobian is nonzero at one square, the same large-phase lattice degree argument should force exact squares for every sufficiently large phase multiplier. This would absorb elliptic, sheared, and many nonradial coherent laminations at once.

The genuinely exceptional case would then be a scalar phase function whose square-phase map is rank-deficient for every square. Classifying that PDE/geometric degeneracy is the recommended v190 target.
