# Half-square / Toeplitz research — v203

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Starting point:** v202 localized square energy lean bundle

This continuation sharpens the energy route in two directions. It isolates the universal Abel-boundary insertion singularity of a square, and it gives an exact decomposition of charged rectangle transport into Schwartz's area-controlled shape term plus a conformal screening term. An analytic fourfold-symmetric calibration proves that the area invariant alone cannot control square transport. The full Toeplitz conjecture remains open.

## Start here

1. [Boundary-renormalized square energy](notes/boundary_insertion_energy_v203.md).
2. [Rectangle area versus screening response](notes/rectangle_area_energy_bridge_v203.md).
3. [Research decisions and v204 targets](notes/research_decisions_v203.md).
4. [Current theorem ledger](THEOREM_LEDGER.md).
5. [v203 proof audit](notes/proof_audit_v203.md) and [references](notes/references_v203.md).

## New mathematical results

For fixed physical charges on the Abel curve \(f(rS^1)\), the energy in the shrinking domain \(f(t\mathbb D)\) has a universal logarithmic insertion divergence. After subtracting it, the exact finite part is
\[
\mathcal B_r(\lambda)
=
-\sum_j\lambda_j^2\log(r|f'(z_j)|)
-\sum_{j\ne k}\lambda_j\lambda_k\log|f(z_j)-f(z_k)|.
\]

For alternating square charges,
\[
\mathcal B_r^\square
=
4\log s-\log4-\sum_j\log(r|f'(z_j)|).
\]
In bounded \(2+2\),
\[
\mathcal B_r^\square=4\log(1-r)+O(1).
\]

A square deep inside a Jordan domain also has a sharp quartic upper bound:
\[
q_\Omega^\square
\le
4\log\frac{1+(A/D)^4}{1-(A/D)^4},
\]
where \(A\) is the circumradius and \(D\) is the distance from the square center to the boundary.

For a rectangle with aspect angle \(\phi\), the scale-normalized whole-plane alternating-charge energy is
\[
C_\eta(\phi)=4\log\frac{\sin2\phi}{2\eta}.
\]
Schwartz's rectangle-area differential gives
\[
dC_\eta
=
-\frac{8\cot2\phi}{X^2+Y^2}\,d\mathcal A.
\]

The v202 projection identity then yields the exact decomposition
\[
\boxed{
dq_\Omega
=
-\frac{8\cot2\phi}{X^2+Y^2}\,d\mathcal A
-d\mathscr S_\Omega,
}
\]
where \(\mathscr S_\Omega\) is the induced screening energy.

On the square locus the first term vanishes:
\[
dq_\Omega^\square=-d\mathscr S_\Omega^\square.
\]
Thus exact-square transport is a screening-response problem, not a first-order aspect-ratio problem.

Finally, the analytic family
\[
f_a(z)=z+az^5,\qquad |a|<1/5,
\]
has fourfold-symmetric Abel curves carrying a smooth one-parameter family of exact squares. Schwartz's \(\mathcal A\) is constant along that family, while the outer-domain finite-point energy is
\[
q_{\Omega_a}(\theta)
=
4\log\frac{1+r^4}{1-r^4}
+
4\log\left|
\frac{1+ar^4e^{4i\theta}}
{1+5ar^4e^{4i\theta}}
\right|,
\]
which is nonconstant when \(a\ne0\).

Therefore a direct bound of charged square transport by variation of Schwartz's area invariant is false even for analytic Jordan geometry.

## What changed in strategy

The v202 suggestion “use rectangle area to pay moving-charge work” is now too coarse. The area invariant exactly controls only the universal rectangle-shape term. The unresolved quantity is the nearby-domain screening response.

The strongest v204 target is therefore to derive a marked local formula for \(d\mathscr S_\Omega\) under square motion and determine whether bounded-\(2+2\) chamber geometry forces one-sidedness, recurrence, or a local concentration alternative.

The independent primitive/lobe route remains open and should not be merged into the screening argument without a proved bridge.

## Verification

Run:

    python3 code/verify_v203.py

The v203 verifier passes **36 exact SymPy checks** with no floating-point or interval arithmetic. The checks cover the insertion normalization, square and rectangle constants, the quartic disk formula, the Schwartz differential relation, the fourfold analytic calibration, the nonconstant energy harmonic, and the quarter-moment congruence.

The analytic and topological proofs are in the notes. Historical verification records remain historical records and are not silently counted as new checks.

The archive remains flat: no nested ZIPs, generated PDFs, or bytecode are included. SHA256SUMS.txt covers the extracted source tree.
