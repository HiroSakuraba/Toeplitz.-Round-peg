# Current theorem ledger

**Author:** Benjamin John Schulz  
**Version:** v202, 10 September 2026

“Project proof” means that a written argument is present and supported by the indicated internal audits. It does not mean external acceptance or a priority determination. A necessary collision condition is not a sufficient condition for squares.

## Results that directly force rectangles or squares

| Result | Hypotheses and conclusion | Current source and scope |
|---|---|---|
| Finite-\(2\)-variation rectangle theorem | A Jordan parametrization of finite \(2\)-variation inscribes every prescribed rectangle class. The proof uses a simple-arc area bound and primitive compactness. | [Complete v183 TeX](theorems/finite_2variation_endpoint_v183.tex); [third audit](history/v183/third_audit_v183.md). Central project theorem. |
| Local quadratic-tightness criterion | Simple Jordan polygons converge uniformly and have uniformly tight local quadratic variation; the limit has all prescribed rectangles. | Proposition in the same v183 source. Sufficient approximation criterion. |
| Full-rank phase-lattice forcing | A coherent phase \(LH+o(L)\), with a nonsingular four-square phase map, forces exact phase-lattice squares. | [v190 theorem](theorems/general_phase_classification_v190.md). Connecting the phase layers to the actual curve remains an explicit hypothesis. |
| Lobe-entropy criterion | A simple polygonal approximation with uniform unsigned lobe \(L\log L\) bounds on short arcs has primitive compactness and all prescribed rectangles. | [v201 proof](notes/lobe_entropy_compactness.md). No universal approximation construction is claimed. |

The external primitive-convergence input is Asano–Ike. Li–Pan's current theorem covers \(p<2\); the endpoint proof here replaces Young integration with the simple-arc estimate. See [references](notes/references_v201.md).

## Structural theorems and corrected collision consequences

| Result | What is established | Limitation / source |
|---|---|---|
| Nested same-sign lobes | A fixed primitive concentration in diameter \(r\) forces a deep nested lobe stack and cubic-scale gaps. | [v189](theorems/nested_lobe_lamination_v189.md). Does not supply a smooth metric phase. |
| Local phase rigidity | A \(C^4\) noncritical scalar phase with every local square Jacobian singular has local parallel or similarity-foliation form. | [v190](theorems/general_phase_classification_v190.md), with [v201 globalization correction](notes/scope_corrections_v201.md). |
| Conformal collision hierarchy | The conformal microscopes and spectral reductions distinguish several runaway scales and collision strata. | [v197 hierarchy](history/v197/collision_spectral_hierarchy.md); earlier dependencies through [history](history/INDEX.md). These are conditional reductions, not a closure of all cases. |
| Bounded 3+1 tangent flow | A tight triple surviving at bounded inner scale forces a nonconstant parabolic tangent orbit and an uncountable tangent set. | [v198](theorems/bounded_3plus1_tangent_flow_v198.md), [cocycle](history/v198/renormalization_cocycle.md). An uncountable tangent set is not a contradiction. |
| Bounded 2+2 saturation | Both short gaps are comparable to Abel depth; a fixed Grunsky operator is asymptotically saturated and has essential norm one. | [v199 proof](theorems/bounded_2plus2_grunsky_v199.md), [essential-norm note](history/v199/logarithmic_spectral_corridor.md), [referee audit](history/v199/REFEREE_PROOF_AUDIT_v199.md). |
| Broadband packet | Every interior octave of the specified corridor carries comparable unnormalized packet mass. | [v200](theorems/grunsky_wavepacket_v200.md), with fixed-coordinate clarification in v201. Does not imply diagonal frequency transport. |
| Critical endpoint can have full rank | An analytic calibration has compactified square Jacobian determinant \(-e^2/512\). | [v200 calibration](theorems/critical_beta1_full_rank_v200.md). Refutes universal rank loss; is not a square-free Jordan counterexample. |
| Regular endpoint flow | Under a genuine endpoint \(C^1\) hypothesis with nonzero derivative, parabolic recentering tends to the regular tangent. | [v200](theorems/critical_endpoint_parabolic_flow_v200.md). Marks escape; the full problem does not close. |

## New v201 deductions and sufficient tests

| Result | Exact conclusion | What would make it decisive |
|---|---|---|
| Positive four-point deficit | \(D=\|v\|^2-\|Bv\|^2+\|Bv+\bar u\|^2\ge0\); \(D=O(1)\) in bounded 2+2. | Supplies a selected-configuration budget. |
| Explicit pair-width floor | \(\liminf g_1g_3/(4|\chi_{\rm out}|\varepsilon^2)\ge1\). | A quantitative refinement, without a sharpness claim. |
| One fixed positive form | \(q_f(u)=\|u\|^2+\Re(u^TBu)=O(1)\); normalized packets approach the negative edge of one real self-adjoint operator. | Joint information about actual events, rather than arbitrary rotating operators. |
| Finite-point compatibility matrix | Polarized energies form a real positive semidefinite matrix with explicit geometric and pseudohyperbolic cross ratios. | Force a negative principal determinant from a selected lineage. This has not been done. |
| Explicit Faber dipole | \(F_v(w)=\log((w-f(z_2))/(w-f(z_1)))\); its complementary Dirichlet energy is bounded by \(D\). | Makes the local density geometrically explicit. |
| Transmission crossing criterion | \(N\) disjoint, bounded-aspect regions with fixed dipole-trace separation cost at least a constant times \(N\). | Derive a growing family of such regions from actual boundary geometry. |
| Interior-clearance barrier | All four bounded-2+2 vertices have interior clearance comparable from below to the square side. | Shows why the simple dipole bound alone cannot rule out the long passage. |
| Lobe entropy spike bound | A fixed chord-closed area in diameter \(r\) forces entropy at least \(a\log(1+4a/(\pi r^2))\). | Construct an approximation that avoids this concentration, as required by the sufficient criterion. |

Proofs are in the [Grunsky](notes/finite_point_grunsky_energy.md), [transmission](notes/transmission_energy_target.md), and [lobe-entropy](notes/lobe_entropy_compactness.md) notes.

## Retractions and barriers that must remain visible

- **Withdrawn:** universal compactified rank at most three in bounded 3+1.
- **Invalid without more hypotheses:** passing from compact convergence to moving remote evaluations.
- **Invalid:** treating the v193 normalized strain as a globally summable area charge; see the retained v194 correction.
- **Invalid:** adding separate octave energies from positivity alone.
- **Invalid:** obtaining a global scalar normal form from simple connectivity alone.
- **Open:** deriving smooth phase coherence, bounded entropy approximations, or an incompatible finite-point matrix from every hypothetical square-free Jordan curve.

The strongest current targets are compared in [research_decisions_v202.md](notes/research_decisions_v202.md). There is still no full Toeplitz proof in this bundle.

## New v202 locality and transport results

| Result | Exact conclusion | Scope |
|---|---|---|
| Whole-plane energy identity | The finite-point form equals \((2\pi)^{-1}\int|\nabla H|^2\), where \(H\) is harmonic inside and equals the physical charge potential outside. | Bounded Jordan domains; includes any boundary-area contribution. |
| Square quadrupole tail | Outside radius \(R>A\), the analytic energy divided by \(\pi\) is \(4\log((1+(A/R)^4)/(1-(A/R)^4))\). | Exact formula for alternating physical square charges. |
| Grounded-potential decay | Beyond a nearby complement point, \(E_v(R)\le(R_0/R)E_v(R_0)\). | Uses connected complement and no boundary smoothness in the final statement. |
| Full-density localization | The full boundary-charge energy outside radius \(R\) is bounded by the explicit quartic tail plus \(2(R_0/R)C_\square\). | Includes the interior harmonic correction. |
| Remote-domain locality | Domains agreeing inside radius \(R\) have charge energies differing by at most \(68(R_0/R)E(P)/(2\pi)\). | Same fixed physical charges and clearance disks; nearby complement point. |
| Bounded-2+2 applicability | Existing clearance and a long-pair distance greater than \(4/5\) give the square locality hypotheses with \(R_0=2A\). | Localizes each actual event's energy; does not sum different events. |
| Fixed-charge exhaustion flow | \(q_t'=-2\sum |M_n|^2/t^{2n+1}\le0\). | Charges fixed in physical coordinates and strictly interior to each domain. |
| Moving-charge balance | \(q_t'=-\mathcal D_t+\mathcal W_t\), with an explicit transport term. | Differentiable moving charges with an interior margin. No sign bound on work. |
| Exact cancellation calibration | Homothetic squares in disks have constant \(q_t\) and equal nonzero dissipation and transport at every logarithmic scale. | Refutes a budget inference from bounded moving energy alone; not a counterexample to Toeplitz. |

Proofs are in [localized_square_energy_v202.md](notes/localized_square_energy_v202.md) and [charge_transport_v202.md](notes/charge_transport_v202.md). These are project deductions supported by an internal audit, not claims of external acceptance or priority.


## New v203 boundary-renormalization and screening results

| Result | Exact conclusion | Scope |
|---|---|---|
| Abel-boundary insertion finite part | For fixed physical charges on \(f(rS^1)\), subtracting \(S_2\log(1-r^2/t^2)\) from the \(f(t\mathbb D)\) insertion singularity leaves an explicit finite limit. | Equal-radius distinct conformal points; neutral real charges. |
| Square insertion formula | \(\mathcal B_r^\square=4\log s-\log4-\sum_j\log(r|f'(z_j)|)\). | Alternating physical square charges; conformal order arbitrary. |
| Bounded-\(2+2\) insertion asymptotic | \(\mathcal B_r^\square=4\log(1-r)+O(1)\); hence \(\mathcal B_r^\square-4\log(1-r)\) is bounded. | Uses the retained bounded-\(2+2\) short-gap comparability. |
| Quartic deep-interior bound | If the square circumradius is \(A\) and center clearance is \(D>A\), then \(q_\Omega^\square\le4\log((1+(A/D)^4)/(1-(A/D)^4))\). | Exact disk comparison plus domain monotonicity. |
| Rectangle shape-energy identity | For scale-adapted regularization, \(dC_\eta=-8\cot(2\phi)(X^2+Y^2)^{-1}d\mathcal A\). | Uses Schwartz's rectangle-area differential. |
| Area/screening decomposition | \(q_\Omega=C_\eta-\mathscr S_\Omega\), so \(dq_\Omega=-8\cot(2\phi)(X^2+Y^2)^{-1}d\mathcal A-d\mathscr S_\Omega\). | Fixed domain and differentiable rectangle path with admissible regularization disks. |
| Square transport reduction | On exact squares, \(dq_\Omega^\square=-d\mathscr S_\Omega^\square\). | Identifies the missing first-order transport variable; supplies no sign bound. |
| Fourfold analytic no-go calibration | \(f_a(z)=z+az^5\) has Abel curves with exact square families for which \(\mathcal A\) is constant but \(q_{\Omega_a}\) is nonconstant. | Refutes transport bounds depending only on Schwartz-area variation; not a Toeplitz counterexample. |

Proofs are in [boundary_insertion_energy_v203.md](notes/boundary_insertion_energy_v203.md) and [rectangle_area_energy_bridge_v203.md](notes/rectangle_area_energy_bridge_v203.md). The [v203 audit](notes/proof_audit_v203.md) records the sign, scaling, and scope checks.

### v203 route correction

The proposal
\[
\text{Schwartz-area variation alone pays charged square transport}
\]
is now **withdrawn**. The exact decomposition shows that the area form controls the universal aspect-ratio term, while exact-square motion is carried entirely by the screening-response term. Any future energy proof must control that screening response through collision/chamber geometry, recurrence, or a new compactness principle.
