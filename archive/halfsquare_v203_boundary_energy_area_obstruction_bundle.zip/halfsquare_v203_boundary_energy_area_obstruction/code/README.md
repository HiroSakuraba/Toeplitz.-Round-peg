# Verification code

The current v203 verifier runs with:

    python3 code/verify_v203.py

It passes 36 exact SymPy checks covering the new Abel-boundary insertion normalization, square and rectangle interaction constants, the quartic deep-interior disk formula, the Schwartz area/shape-energy relation, fourfold equivariance, the exact nonconstant square-family energy, \(c_{22}=-a\), and the quarter-moment congruence. See [recorded output](../results/verify_v203_output.txt) and the [v203 proof audit](../notes/proof_audit_v203.md).

The current v202 verifier remains available as:

    python3 code/verify_v202.py

It passed 75 exact checks of the localized energy, annular constants, and fixed/moving-charge formulas. The retained v201 verifier passed 187 exact checks of the finite-point positive form and related calibrations.

The written proofs establish the analytic, functional-analytic, and topological claims. Exact symbolic checks do not certify those arguments by sampling.

Scripts under `history/` are retained from earlier versions. Some historical scripts use floating-point diagnostics; their saved outputs remain dated historical records rather than part of the v203 check count.

No interval arithmetic is used in v201--v203. Any future interval certification should use SageMath, in accordance with the project convention.
