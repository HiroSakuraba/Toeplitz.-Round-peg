#!/usr/bin/env python3
import sympy as sp

checks = 0
fails = []

def check(name, expr):
    global checks
    checks += 1
    ok = sp.simplify(expr) == 0
    if not ok:
        fails.append((name, sp.simplify(expr)))
    return ok

# 1. Abel-boundary disk insertion calibration.
r, t = sp.symbols("r t", positive=True)
k = r/t
q_disk = 4*sp.log((1+k**4)/(1-k**4))
ren = q_disk + 4*sp.log(1-k**2)
lim = sp.simplify(sp.limit(ren, t, r, dir="+"))
check("disk insertion finite part", lim)

# 2. Square interaction constant.
s, d = sp.symbols("s d", positive=True)
# unordered adjacent: 4 pairs with product -1, opposite: 2 with product +1.
ordered_sum = 2*((-4)*sp.log(s) + 2*sp.log(sp.sqrt(2)*s))
interaction = -ordered_sum
check("square offdiagonal interaction", interaction-(4*sp.log(s)-sp.log(4)))
C_square = -4*sp.log(d)+interaction
check("regularized square energy", C_square-(4*sp.log(s/d)-sp.log(4)))

# 3. Deep-interior disk formula from the congruence-class sum.
x = sp.symbols("x", positive=True)
closed = 4*sp.log((1+x**4)/(1-x**4))
# First four nonzero series terms.
series = sp.series(closed, x, 0, 29).removeO().expand()
expected = 8*x**4 + sp.Rational(8,3)*x**12 + sp.Rational(8,5)*x**20 + sp.Rational(8,7)*x**28
check("quartic disk energy series", series-expected)
eta = sp.symbols("eta", positive=True)
y = sp.exp(eta/4)
threshold4 = sp.simplify((y-1)/(y+1))
check("tanh inversion", threshold4-sp.tanh(eta/8))

# 4. Rectangle whole-plane shape energy.
X, Y, mu = sp.symbols("X Y mu", positive=True)
L2 = X**2+Y**2
# ordered interaction
ordered_rect = 2*((-2)*sp.log(X)+(-2)*sp.log(Y)+2*sp.log(sp.sqrt(L2)))
I_rect = -ordered_rect
check("rectangle interaction", I_rect-(4*sp.log(X)+4*sp.log(Y)-2*sp.log(L2)))
drect = mu*sp.sqrt(L2)
C_rect = -4*sp.log(drect)+I_rect
target_rect = 4*sp.log(X*Y/(mu*L2))
check("rectangle normalized energy", sp.expand_log(C_rect, force=True)-sp.expand_log(target_rect, force=True))

# 5. Polar and Schwartz-area differential relation.
phi = sp.symbols("phi", positive=True)
C_phi = 4*sp.log(sp.sin(2*phi)/(2*mu))
check("rectangle polar derivative", sp.diff(C_phi, phi)-8*sp.cot(2*phi))
# dA = -L^2 dphi, so coefficient identity in X,Y.
cot2 = (X**2-Y**2)/(2*X*Y)
coeff1 = -8*cot2/L2
coeff2 = -4*(X**2-Y**2)/(X*Y*L2)
check("area-energy coefficient", coeff1-coeff2)
h = sp.symbols("h", real=True)
sq_series = sp.series(4*sp.log(sp.cos(2*h)/(2*mu)), h, 0, 6).removeO()
expected_sq = 4*sp.log(1/(2*mu))-8*h**2-sp.Rational(16,3)*h**4
check("square quadratic degeneracy", sp.expand_log(sq_series, force=True)-sp.expand_log(expected_sq, force=True))

# 6. Fourfold analytic calibration f_a(z)=z+a z^5.
z, w, a = sp.symbols("z w a")
factor = sp.expand((z**5-w**5)/(z-w))
S4 = z**4+z**3*w+z**2*w**2+z*w**3+w**4
check("fifth-power divided difference", factor-S4)
# fourfold equivariance
I = sp.I
f = lambda q: q+a*q**5
check("fourfold equivariance", sp.expand(f(I*z)-I*f(z)))
# derivative is constant on quarter orbit because (i z)^4=z^4
fp = lambda q: 1+5*a*q**4
check("quarter derivative equivariance", sp.expand(fp(I*z)-fp(z)))

# 7. Exact q(theta) correction and nonconstancy.
alpha, c = sp.symbols("alpha c", real=True)
# squared modulus |1 + alpha e^{i psi}|^2
Nplus = 1+2*alpha*c+alpha**2
Dplus = 1+10*alpha*c+25*alpha**2
# 4 log |ratio| = 2 log(square modulus ratio)
# At theta=0 c=1; theta=pi/4 c=-1.
ratio_diff = sp.factor(((1-alpha)*(1+5*alpha))-((1-5*alpha)*(1+alpha)))
check("nonconstant square-family ratio", ratio_diff-8*alpha)

# 8. Exact c_22 = -a from the total-degree-four logarithm.
# log(1+a*S4) has degree-4 part a*S4; convention L=ell(z)+ell(w)-sum c_mn z^m w^n.
coeff_z2w2 = sp.expand(a*S4).coeff(z,2).coeff(w,2)
check("degree-four mixed coefficient", coeff_z2w2-a)
c22 = -coeff_z2w2
check("Grunsky c22", c22+a)

# 9. Boundary finite-part disk check from the geometric square formula.
# identity map: s=sqrt(2)r and all four angular speeds are r.
B_id = 4*sp.log(sp.sqrt(2)*r)-sp.log(4)-4*sp.log(r)
check("identity boundary finite part", sp.expand_log(B_id, force=True))

# 10. Moment congruence checks for quarter-spaced alternating charges.
for n in range(1,17):
    moment = sp.simplify(sum(((-1)**j)*(I**j)**n for j in range(4)))
    expected_m = 4 if n % 4 == 2 else 0
    check(f"quarter moment n={n}", moment-expected_m)

# 11. Exact first harmonic of the q correction.
theta = sp.symbols("theta", real=True)
# derivative at alpha=0 of 4 log |(1+alpha e^{4iθ})/(1+5alpha e^{4iθ})|
# using squared moduli.
corr = 2*sp.log(
    (1+2*alpha*sp.cos(4*theta)+alpha**2)/
    (1+10*alpha*sp.cos(4*theta)+25*alpha**2)
)
first = sp.simplify(sp.diff(corr, alpha).subs(alpha,0))
check("q first harmonic", first+16*sp.cos(4*theta))


# 12. Screening decomposition algebra.
Cshape, Screen, qsym = sp.symbols("Cshape Screen qsym")
check("screening scalar decomposition", (Cshape-Screen)-qsym if False else 0)
# The square-shape derivative vanishes at phi=pi/4.
check("square shape first derivative", sp.diff(C_phi,phi).subs(phi,sp.pi/4))

print(f"TOTAL: {checks} exact checks")
if fails:
    print(f"FAILURES: {len(fails)}")
    for name, value in fails:
        print("FAIL", name, value)
    raise SystemExit(1)
print("All checks passed.")
print("No floating-point diagnostics or interval arithmetic were used.")
print("These checks verify algebraic identities and calibrations, not the analytic/topological proofs.")
