# Retained research history

These are dated records, not a list of independently accepted theorems. Read the current theorem ledger and scope corrections first. Earlier handoffs sometimes retain an older version in their filename; the grouping records the source bundle.

Every substantive source is stored once. Python verifiers are together in code/history/ so their one local import remains usable. Recorded outputs are in results/history/. Historical prose may mention original paths or ZIPs; use this index or provenance/files.tsv to resolve them.

- v148–v179: profile extraction, logarithmic exceptions, degree, folding, and routing.
- v180–v190: primitives, finite-2-variation, nested lobes, and phase rigidity.
- v191–v200: conformal microscopes, spectral hierarchies, collisions, and Grunsky packets.

## Source v148

- [explore_inversion_pairing.py](../code/history/explore_inversion_pairing.py)
- [verify_backtracking_degree.py](../code/history/verify_backtracking_degree.py)
- [verify_profile_classification.py](../code/history/verify_profile_classification.py)
- [verify_slope_reversals.py](../code/history/verify_slope_reversals.py)
- [continuation_centered_spin.md](../history/v148/continuation_centered_spin.md)
- [research_note.md](../history/v148/research_note.md)
- [backtracking_verification_output.txt](../results/history/v148_backtracking_verification_output.txt)
- [profile_classification_verification_output.txt](../results/history/v148_profile_classification_verification_output.txt)
- [slope_reversals_verification_output.txt](../results/history/v148_slope_reversals_verification_output.txt)
- [verification_output.txt](../results/history/v148_verification_output.txt)

## Source v149

- [verify_v149.py](../code/history/verify_v149.py)
- [continuation_logarithmic_slope.md](../history/v149/continuation_logarithmic_slope.md)
- [continuation_profile_classification.md](../history/v149/continuation_profile_classification.md)
- [continuation_slope_reversals.md](../history/v149/continuation_slope_reversals.md)
- [v149_verifier_output.txt](../results/history/v149_v149_verifier_output.txt)

## Source v150

- [verify_v150.py](../code/history/verify_v150.py)
- [v150_verifier_output.txt](../results/history/v150_v150_verifier_output.txt)

## Source v151

- [verify_v151.py](../code/history/verify_v151.py)
- [handoff_v149_shrinking_window_profile_extraction.md](../history/v151/handoff_v149_shrinking_window_profile_extraction.md)
- [handoff_v150_exceptional_profile_second_scale.md](../history/v151/handoff_v150_exceptional_profile_second_scale.md)
- [v151_verifier_output.txt](../results/history/v151_v151_verifier_output.txt)

## Source v152

- [verify_v152.py](../code/history/verify_v152.py)
- [handoff_v151_third_scale_cubic_resonance.md](../history/v152/handoff_v151_third_scale_cubic_resonance.md)
- [v152_verifier_output.txt](../results/history/v152_v152_verifier_output.txt)

## Source v153

- [verify_v153.py](../code/history/verify_v153.py)
- [handoff_v152_moving_log_resummation.md](../history/v153/handoff_v152_moving_log_resummation.md)
- [v153_verifier_output.txt](../results/history/v153_v153_verifier_output.txt)

## Source v154

- [verify_v154.py](../code/history/verify_v154.py)
- [handoff_v153_nested_log_coherence.md](../history/v154/handoff_v153_nested_log_coherence.md)
- [v154_verifier_output.txt](../results/history/v154_v154_verifier_output.txt)

## Source v155

- [verify_v155.py](../code/history/verify_v155.py)
- [handoff_v154_visible_mass_compactness.md](../history/v155/handoff_v154_visible_mass_compactness.md)
- [v155_verifier_output.txt](../results/history/v155_v155_verifier_output.txt)

## Source v156

- [verify_v156.py](../code/history/verify_v156.py)
- [handoff_v155_critical_resolution_collapse.md](../history/v156/handoff_v155_critical_resolution_collapse.md)
- [v156_verifier_output.txt](../results/history/v156_v156_verifier_output.txt)

## Source v157

- [verify_v157.py](../code/history/verify_v157.py)
- [handoff_v156_phase_root_rigidity.md](../history/v157/handoff_v156_phase_root_rigidity.md)
- [v157_verifier_output.txt](../results/history/v157_v157_verifier_output.txt)

## Source v158

- [verify_v158.py](../code/history/verify_v158.py)
- [handoff_v157_plateau_and_return_arch.md](../history/v158/handoff_v157_plateau_and_return_arch.md)
- [v158_theorem_audit.txt](../history/v158/v158_theorem_audit.txt)
- [v158_verifier_output.txt](../results/history/v158_v158_verifier_output.txt)

## Source v159

- [verify_v159.py](../code/history/verify_v159.py)
- [handoff_v158_two_channel_sumset.md](../history/v159/handoff_v158_two_channel_sumset.md)
- [v159_theorem_audit.txt](../history/v159/v159_theorem_audit.txt)
- [v159_verifier_output.txt](../results/history/v159_v159_verifier_output.txt)

## Source v160

- [verify_v160.py](../code/history/verify_v160.py)
- [handoff_v159_multivalued_degree.md](../history/v160/handoff_v159_multivalued_degree.md)
- [v160_theorem_audit.txt](../history/v160/v160_theorem_audit.txt)
- [v160_verifier_output.txt](../results/history/v160_v160_verifier_output.txt)

## Source v161

- [verify_v161.py](../code/history/verify_v161.py)
- [handoff_v160_critical_set_and_defect_roughness.md](../history/v161/handoff_v160_critical_set_and_defect_roughness.md)
- [v161_theorem_audit.txt](../history/v161/v161_theorem_audit.txt)
- [v161_verifier_output.txt](../results/history/v161_v161_verifier_output.txt)

## Source v162

- [verify_v162.py](../code/history/verify_v162.py)
- [handoff_v161_record_envelope_stieltjes.md](../history/v162/handoff_v161_record_envelope_stieltjes.md)
- [v162_counterexample_table.csv](../history/v162/v162_counterexample_table.csv)
- [v162_theorem_audit.txt](../history/v162/v162_theorem_audit.txt)
- [v162_verifier_output.txt](../results/history/v162_v162_verifier_output.txt)

## Source v163

- [verify_v163.py](../code/history/verify_v163.py)
- [handoff_v162_persistence_critical_image.md](../history/v163/handoff_v162_persistence_critical_image.md)
- [v163_theorem_audit.txt](../history/v163/v163_theorem_audit.txt)
- [v163_verifier_output.txt](../results/history/v163_v163_verifier_output.txt)

## Source v164

- [verify_v164.py](../code/history/verify_v164.py)
- [external_sources_v164.md](../history/v164/external_sources_v164.md)
- [handoff_v163_critical_image_entropy.md](../history/v164/handoff_v163_critical_image_entropy.md)
- [handoff_v164_pressure_tangent.md](../history/v164/handoff_v164_pressure_tangent.md)
- [v164_theorem_audit.txt](../history/v164/v164_theorem_audit.txt)
- [v164_verifier_output.txt](../results/history/v164_v164_verifier_output.txt)

## Source v165

- [verify_v165.py](../code/history/verify_v165.py)
- [external_sources_v165.md](../history/v165/external_sources_v165.md)
- [handoff_v165_fiber_entropy_budget.md](../history/v165/handoff_v165_fiber_entropy_budget.md)
- [v165_theorem_audit.txt](../history/v165/v165_theorem_audit.txt)
- [v165_verifier_output.txt](../results/history/v165_v165_verifier_output.txt)

## Source v166

- [verify_v166.py](../code/history/verify_v166.py)
- [external_sources_v166.md](../history/v166/external_sources_v166.md)
- [handoff_v166_carrier_measure_upgrade.md](../history/v166/handoff_v166_carrier_measure_upgrade.md)
- [v166_theorem_audit.txt](../history/v166/v166_theorem_audit.txt)
- [v166_verifier_output.txt](../results/history/v166_v166_verifier_output.txt)

## Source v167

- [verify_v167.py](../code/history/verify_v167.py)
- [external_sources_v167.md](../history/v167/external_sources_v167.md)
- [handoff_v167_critical_fiber_saturation.md](../history/v167/handoff_v167_critical_fiber_saturation.md)
- [v167_theorem_audit.txt](../history/v167/v167_theorem_audit.txt)
- [v167_verifier_output.txt](../results/history/v167_v167_verifier_output.txt)

## Source v168

- [verify_v168.py](../code/history/verify_v168.py)
- [handoff_v168_phase_shear_visibility.md](../history/v168/handoff_v168_phase_shear_visibility.md)
- [v168_theorem_audit.txt](../history/v168/v168_theorem_audit.txt)
- [v168_verifier_output.txt](../results/history/v168_v168_verifier_output.txt)

## Source v169

- [verify_v169.py](../code/history/verify_v169.py)
- [handoff_v169_lattice_snapping.md](../history/v169/handoff_v169_lattice_snapping.md)
- [v169_theorem_audit.txt](../history/v169/v169_theorem_audit.txt)
- [v169_verifier_output.txt](../results/history/v169_v169_verifier_output.txt)

## Source v170

- [verify_v170.py](../code/history/verify_v170.py)
- [handoff_v170_residue_reentry.md](../history/v170/handoff_v170_residue_reentry.md)
- [v170_theorem_audit.txt](../history/v170/v170_theorem_audit.txt)
- [v170_verifier_output.txt](../results/history/v170_v170_verifier_output.txt)

## Source v171

- [verify_v171.py](../code/history/verify_v171.py)
- [handoff_v171_lattice_resonance_audit.md](../history/v171/handoff_v171_lattice_resonance_audit.md)
- [v171_theorem_audit.txt](../history/v171/v171_theorem_audit.txt)
- [v171_verifier_output.txt](../results/history/v171_v171_verifier_output.txt)

## Source v172

- [verify_v172.py](../code/history/verify_v172.py)
- [handoff_v172_mixed_difference_residue_drift.md](../history/v172/handoff_v172_mixed_difference_residue_drift.md)
- [v172_theorem_audit.txt](../history/v172/v172_theorem_audit.txt)
- [v172_verifier_output.txt](../results/history/v172_v172_verifier_output.txt)

## Source v173

- [verify_v173.py](../code/history/verify_v173.py)
- [handoff_v173_clearance_collapse_resonant_tangent.md](../history/v173/handoff_v173_clearance_collapse_resonant_tangent.md)
- [v173_theorem_audit.txt](../history/v173/v173_theorem_audit.txt)
- [v173_verifier_output.txt](../results/history/v173_v173_verifier_output.txt)

## Source v174

- [handoff_v174_record_envelope_excursion_sync.md](../history/v174/handoff_v174_record_envelope_excursion_sync.md)
- [v174_theorem_audit.txt](../history/v174/v174_theorem_audit.txt)
- [v174_verifier_output.txt](../results/history/v174_v174_verifier_output.txt)

## Source v175

- [verify_v174.py](../code/history/verify_v174.py)
- [verify_v175.py](../code/history/verify_v175.py)
- [handoff_v175_post_bottom_relocation.md](../history/v175/handoff_v175_post_bottom_relocation.md)
- [v175_theorem_audit.txt](../history/v175/v175_theorem_audit.txt)
- [v175_verifier_output.txt](../results/history/v175_v175_verifier_output.txt)

## Source v176

- [verify_v176.py](../code/history/verify_v176.py)
- [handoff_v176_clearance_tangent_degree.md](../history/v176/handoff_v176_clearance_tangent_degree.md)
- [verify_v176_output.txt](../results/history/v176_verify_v176_output.txt)

## Source v177

- [verify_v177.py](../code/history/verify_v177.py)
- [handoff_v177_fold_renormalization.md](../history/v177/handoff_v177_fold_renormalization.md)
- [verify_v177_output.txt](../results/history/v177_verify_v177_output.txt)

## Source v178

- [verify_v178.py](../code/history/verify_v178.py)
- [handoff_v178_fold_event_capture.md](../history/v178/handoff_v178_fold_event_capture.md)
- [verify_v178_output.txt](../results/history/v178_verify_v178_output.txt)

## Source v179

- [verify_v179.py](../code/history/verify_v179.py)
- [handoff_v179_selected_branch_routing.md](../history/v179/handoff_v179_selected_branch_routing.md)
- [verify_v179_output.txt](../results/history/v179_verify_v179_output.txt)

## Source v180

- [verify_v180.py](../code/history/verify_v180.py)
- [audit_v149_v179.csv](../history/v180/audit_v149_v179.csv)
- [handoff_v180_global_audit.md](../history/v180/handoff_v180_global_audit.md)
- [obstruction_tree_v180.md](../history/v180/obstruction_tree_v180.md)
- [theorem_audit_v180.md](../history/v180/theorem_audit_v180.md)
- [verify_v180_output.txt](../results/history/v180_verify_v180_output.txt)

## Source v181

- [verify_v181.py](../code/history/verify_v181.py)
- [handoff_v181_endpoint_referee_audit.md](../history/v181/handoff_v181_endpoint_referee_audit.md)
- [literature_snapshot_v181.md](../history/v181/literature_snapshot_v181.md)
- [referee_audit_v181.md](../history/v181/referee_audit_v181.md)
- [theorem_status_v181.md](../history/v181/theorem_status_v181.md)
- [verify_v181_output.txt](../results/history/v181_verify_v181_output.txt)

## Source v182

- [verify_v182.py](../code/history/verify_v182.py)
- [handoff_v182_endpoint_second_audit.md](../history/v182/handoff_v182_endpoint_second_audit.md)
- [independent_audit_v182.md](../history/v182/independent_audit_v182.md)
- [proof_dependency_map.md](../history/v182/proof_dependency_map.md)
- [verify_v182_output.txt](../results/history/v182_verify_v182_output.txt)

## Source v183

- [verify_v183.py](../code/history/verify_v183.py)
- [handoff_v183_endpoint_third_audit.md](../history/v183/handoff_v183_endpoint_third_audit.md)
- [third_audit_v183.md](../history/v183/third_audit_v183.md)
- [verify_v183_output.txt](../results/history/v183_verify_v183_output.txt)
- [endpoint_p2_standalone_v183.tex](../theorems/finite_2variation_endpoint_v183.tex)

## Source v184

- [verify_v184.py](../code/history/verify_v184.py)
- [handoff_v184_quadratic_concentration.md](../history/v184/handoff_v184_quadratic_concentration.md)
- [quadratic_concentration_theorem.md](../history/v184/quadratic_concentration_theorem.md)
- [theorem_status_v184.txt](../history/v184/theorem_status_v184.txt)
- [verify_v184_output.txt](../results/history/v184_verify_v184_output.txt)

## Source v185

- [verify_v185.py](../code/history/verify_v185.py)
- [handoff_v185_two_sided_threading.md](../history/v185/handoff_v185_two_sided_threading.md)
- [theorem_status_v185.txt](../history/v185/theorem_status_v185.txt)
- [two_sided_threading_theorem.md](../history/v185/two_sided_threading_theorem.md)
- [verify_v185_output.txt](../results/history/v185_verify_v185_output.txt)

## Source v186

- [verify_v186.py](../code/history/verify_v186.py)
- [cubic_corridor_obstruction.md](../history/v186/cubic_corridor_obstruction.md)
- [handoff_v186_cubic_corridor_obstruction.md](../history/v186/handoff_v186_cubic_corridor_obstruction.md)
- [theorem_status_v186.txt](../history/v186/theorem_status_v186.txt)
- [verify_v186_output.txt](../results/history/v186_verify_v186_output.txt)

## Source v187

- [verify_v187.py](../code/history/verify_v187.py)
- [handoff_v187_nonlocal_spiral_lattice.md](../history/v187/handoff_v187_nonlocal_spiral_lattice.md)
- [nonlocal_spiral_lattice_theorem.md](../history/v187/nonlocal_spiral_lattice_theorem.md)
- [verify_v187_output.txt](../results/history/v187_verify_v187_output.txt)

## Source v188

- [verify_v188.py](../code/history/verify_v188.py)
- [handoff_v188_phase_lattice_stability.md](../history/v188/handoff_v188_phase_lattice_stability.md)
- [phase_lattice_stability_theorem.md](../history/v188/phase_lattice_stability_theorem.md)
- [status_corrections_v188.md](../history/v188/status_corrections_v188.md)
- [verify_v188_output.txt](../results/history/v188_verify_v188_output.txt)

## Source v189

- [verify_v189.py](../code/history/verify_v189.py)
- [handoff_v189_nested_lobe_lamination.md](../history/v189/handoff_v189_nested_lobe_lamination.md)
- [status_corrections_v189.md](../history/v189/status_corrections_v189.md)
- [verify_v189_output.txt](../results/history/v189_verify_v189_output.txt)
- [nested_lobe_lamination_theorem.md](../theorems/nested_lobe_lamination_v189.md)

## Source v190

- [verify_v190.py](../code/history/verify_v190.py)
- [handoff_v190_general_phase_classification.md](../history/v190/handoff_v190_general_phase_classification.md)
- [proof_audit_v190.md](../history/v190/proof_audit_v190.md)
- [status_corrections_v190.md](../history/v190/status_corrections_v190.md)
- [verify_v190_output.txt](../results/history/v190_verify_v190_output.txt)
- [general_phase_classification_theorem.md](../theorems/general_phase_classification_v190.md)

## Source v191

- [verify_v191.py](../code/history/verify_v191.py)
- [conformal_fourier_square_transform.md](../history/v191/conformal_fourier_square_transform.md)
- [handoff_v191.md](../history/v191/handoff_v191.md)
- [mixed_scale_rank3_theorem.md](../history/v191/mixed_scale_rank3_theorem.md)
- [status_corrections_v191.md](../history/v191/status_corrections_v191.md)
- [verify_v191_output.txt](../results/history/v191_verify_v191_output.txt)

## Source v192

- [verify_v192.py](../code/history/verify_v192.py)
- [compactification_and_next_targets.md](../history/v192/compactification_and_next_targets.md)
- [handoff_v192.md](../history/v192/handoff_v192.md)
- [local_spectral_invariants.md](../history/v192/local_spectral_invariants.md)
- [mobius_fourier_escape_theorem.md](../history/v192/mobius_fourier_escape_theorem.md)
- [status_corrections_v192.md](../history/v192/status_corrections_v192.md)
- [verify_v192_output.txt](../results/history/v192_verify_v192_output.txt)

## Source v193

- [verify_v193.py](../code/history/verify_v193.py)
- [handoff_v193.md](../history/v193/handoff_v193.md)
- [modulus_bridge_audit.md](../history/v193/modulus_bridge_audit.md)
- [next_targets_v194.md](../history/v193/next_targets_v194.md)
- [proof_audit_v193.md](../history/v193/proof_audit_v193.md)
- [runaway_spectral_cascade_theorem.md](../history/v193/runaway_spectral_cascade_theorem.md)
- [status_corrections_v193.md](../history/v193/status_corrections_v193.md)
- [verify_v193_output.txt](../results/history/v193_verify_v193_output.txt)

## Source v194

- [verify_v194.py](../code/history/verify_v194.py)
- [handoff_v194.md](../history/v194/handoff_v194.md)
- [next_targets_v195.md](../history/v194/next_targets_v195.md)
- [packing_obstruction_and_cusp_model.md](../history/v194/packing_obstruction_and_cusp_model.md)
- [proof_audit_v194.md](../history/v194/proof_audit_v194.md)
- [runaway_parabolic_packing_theorem.md](../history/v194/runaway_parabolic_packing_theorem.md)
- [status_corrections_v194.md](../history/v194/status_corrections_v194.md)
- [v189_harmonic_measure_bridge_audit.md](../history/v194/v189_harmonic_measure_bridge_audit.md)
- [verify_v194_output.txt](../results/history/v194_verify_v194_output.txt)

## Source v195

- [verify_v195.py](../code/history/verify_v195.py)
- [gap_centered_spectral_theorem.md](../history/v195/gap_centered_spectral_theorem.md)
- [handoff_v195.md](../history/v195/handoff_v195.md)
- [next_targets_v196.md](../history/v195/next_targets_v196.md)
- [power_tangent_exclusion.md](../history/v195/power_tangent_exclusion.md)
- [proof_audit_v195.md](../history/v195/proof_audit_v195.md)
- [status_corrections_v195.md](../history/v195/status_corrections_v195.md)
- [transport_rich_audit.md](../history/v195/transport_rich_audit.md)
- [verification_results.txt](../results/history/v195_verification_results.txt)

## Source v196

- [verify_v196.py](../code/history/verify_v196.py)
- [collision_strata.md](../history/v196/collision_strata.md)
- [handoff_v196.md](../history/v196/handoff_v196.md)
- [next_targets_v197.md](../history/v196/next_targets_v197.md)
- [off_center_power_tangent_exclusion.md](../history/v196/off_center_power_tangent_exclusion.md)
- [projected_second_order_spectral_theorem.md](../history/v196/projected_second_order_spectral_theorem.md)
- [proof_audit_v196.md](../history/v196/proof_audit_v196.md)
- [status_corrections_v196.md](../history/v196/status_corrections_v196.md)
- [transversality_resultants.txt](../history/v196/transversality_resultants.txt)
- [verification_results.txt](../results/history/v196_verification_results.txt)

## Source v197

- [verify_v197.py](../code/history/verify_v197.py)
- [collision_spectral_hierarchy.md](../history/v197/collision_spectral_hierarchy.md)
- [handoff_v197.md](../history/v197/handoff_v197.md)
- [next_targets_v198.md](../history/v197/next_targets_v198.md)
- [pair_centroid_decomposition.md](../history/v197/pair_centroid_decomposition.md)
- [proof_audit_v197.md](../history/v197/proof_audit_v197.md)
- [status_corrections_v197.md](../history/v197/status_corrections_v197.md)
- [symbolic_vertex_table.txt](../history/v197/symbolic_vertex_table.txt)
- [verification_results.txt](../results/history/v197_verification_results.txt)

## Source v198

- [verify_v198.py](../code/history/verify_v198.py)
- [bounded_2plus2_crossratio.md](../history/v198/bounded_2plus2_crossratio.md)
- [handoff_v198.md](../history/v198/handoff_v198.md)
- [next_targets_v199.md](../history/v198/next_targets_v199.md)
- [proof_audit_v198.md](../history/v198/proof_audit_v198.md)
- [renormalization_cocycle.md](../history/v198/renormalization_cocycle.md)
- [status_corrections_v198.md](../history/v198/status_corrections_v198.md)
- [verification_results.txt](../results/history/v198_verification_results.txt)
- [bounded_3plus1_tangent_flow.md](../theorems/bounded_3plus1_tangent_flow_v198.md)

## Source v199

- [audit_countercheck.py](../code/history/audit_countercheck.py)
- [verifier_v199.py](../code/history/verifier_v199.py)
- [CORRECTED_STATUS_v199.md](../history/v199/CORRECTED_STATUS_v199.md)
- [REFEREE_PROOF_AUDIT_v199.md](../history/v199/REFEREE_PROOF_AUDIT_v199.md)
- [handoff_v199.md](../history/v199/handoff_v199.md)
- [logarithmic_spectral_corridor.md](../history/v199/logarithmic_spectral_corridor.md)
- [next_targets_v200.md](../history/v199/next_targets_v200.md)
- [proof_audit_v199.md](../history/v199/proof_audit_v199.md)
- [references_v199.md](../history/v199/references_v199.md)
- [status_corrections_v199.md](../history/v199/status_corrections_v199.md)
- [audit_countercheck_results.txt](../results/history/v199_audit_countercheck_results.txt)
- [verifier_results.txt](../results/history/v199_verifier_results.txt)
- [grunsky_2plus2_saturation.md](../theorems/bounded_2plus2_grunsky_v199.md)

## Source v200

- [verify_v200.py](../code/history/verify_v200.py)
- [handoff_v200.md](../history/v200/handoff_v200.md)
- [next_targets_v201.md](../history/v200/next_targets_v201.md)
- [proof_audit_v200.md](../history/v200/proof_audit_v200.md)
- [references_v200.md](../history/v200/references_v200.md)
- [status_corrections_v200.md](../history/v200/status_corrections_v200.md)
- [verify_v200_output.txt](../results/history/v200_verify_v200_output.txt)
- [corrected_3plus1_compactification.md](../theorems/corrected_3plus1_compactification_v200.md)
- [critical_beta1_full_rank_calibration.md](../theorems/critical_beta1_full_rank_v200.md)
- [critical_endpoint_parabolic_flow.md](../theorems/critical_endpoint_parabolic_flow_v200.md)
- [grunsky_self_extremizing_wavepacket.md](../theorems/grunsky_wavepacket_v200.md)


## Source v201

- [README_v201.md](v201/README_v201.md)
- [THEOREM_LEDGER_v201.md](v201/THEOREM_LEDGER_v201.md)

## Source v202

- [README_v202.md](v202/README_v202.md)
- [THEOREM_LEDGER_v202.md](v202/THEOREM_LEDGER_v202.md)

