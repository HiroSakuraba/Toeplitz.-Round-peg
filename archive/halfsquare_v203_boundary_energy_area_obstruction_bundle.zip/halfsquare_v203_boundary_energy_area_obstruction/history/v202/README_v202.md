# Half-square / Toeplitz research — v202

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Starting point:** v201 finite-point energy lean bundle

This version proves quantitative locality for the full energy attached to a cleared square, and derives the extra work term caused by moving its vertices. It does not solve the full Toeplitz conjecture.

## Start here

1. [Locality theorem and complete proofs](../../notes/localized_square_energy_v202.md).
2. [Fixed-charge monotonicity and moving-charge work](../../notes/charge_transport_v202.md).
3. [Worked research directions and the remaining bridges](../../notes/research_decisions_v202.md).
4. [Current theorem ledger](../../THEOREM_LEDGER.md).
5. [Proof audit](../../notes/proof_audit_v202.md) and [primary references](../../notes/references_v202.md).

## The new mathematical result

The finite-point Grunsky energy equals the whole-plane Dirichlet energy of a harmonic boundary-charge potential. A square's alternating charges cancel its dipole moment, yielding an exact quartic tail for the explicit physical potential.

The harmonic correction also has a uniform tail bound. If the square has side \(s\), interior clearance comparable to \(s\), and a boundary point nearby, changing the domain only beyond radius \(R\) changes its full energy by \(O(s/R)\). The existing bounded-2+2 estimates supply these geometric hypotheses.

This addresses remote absorption for fixed four-point configurations. A separate exact calculation shows why a bounded energy at each scale still does not bound the total dissipation: moving vertices supply transport work. In the disk calibration those two terms cancel at every scale.

## Existing results remain available

The current [finite-2-variation rectangle theorem](../../theorems/finite_2variation_endpoint_v183.tex), the [lobe-entropy criterion](../../notes/lobe_entropy_compactness.md), the [finite-point matrix](../../notes/finite_point_grunsky_energy.md), and the corrected collision theorems remain in the flat archive.

The ledger distinguishes results that force rectangles, necessary collision conditions, countermodels, and unresolved hypotheses. Earlier claims remain subject to the [v201 scope corrections](../../notes/scope_corrections_v201.md).

## Verification and archive size

Run from this directory:

    python3 code/verify_v202.py

The new verifier passed **75 exact SymPy checks**, with no floating point or interval arithmetic. The [saved output](../../results/verify_v202_output.txt) records their scope; the analytic proofs are in the notes.

This version adds a small set of text proofs and one verifier to the cleaned v201 tree. It contains no nested ZIPs, generated PDFs, or bytecode. Useful historical arguments, counterexamples, audits, and verification records remain indexed in [history/INDEX.md](../../history/INDEX.md).

The original cleanup mapping remains in [provenance/CLEANUP.md](../../provenance/CLEANUP.md). The [v202 change record](../../provenance/v202_changes.md) documents this update. SHA256SUMS.txt covers the extracted contents.

For the next version, update this tree and rebuild its one outer ZIP. Do not include this ZIP or old bundles inside it.
