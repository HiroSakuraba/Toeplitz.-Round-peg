# Boundary-renormalized square energy

**Author:** Benjamin John Schulz  
**Version:** v203, 10 September 2026  
**Status:** project deductions with a separate internal audit. They do not prove the square-peg conjecture.

## 1. Why renormalize at the Abel boundary

The v202 moving-charge formula is finite only while the marked points stay strictly inside the comparison domain. If a square lies on an analytic Abel curve
\[
\Gamma_r=f(rS^1),
\qquad 0<r<1,
\]
and one shrinks the containing Abel domain \(f(t\mathbb D)\) down to \(t=r\), the finite-point energy diverges because the four charges are being inserted into the boundary.

That divergence is universal. Removing it leaves an exact finite boundary quantity. In the bounded-\(2+2\) collision regime this quantity has a universal \(4\log(1-r)\) leading term.

Throughout, \(f:\mathbb D\to\Omega\) is univalent, \(z_j=re^{i\theta_j}\) are distinct, \(x_j=f(z_j)\), and the real charges satisfy
\[
\sum_j\lambda_j=0.
\]
Let
\[
S_2=\sum_j\lambda_j^2.
\]
For \(t>r\), let \(q_t\) denote the v202 finite-point energy of the **fixed physical points** \(x_j\) in the domain
\[
\Omega_t=f(t\mathbb D).
\]

## 2. Exact insertion renormalization

### Theorem 2.1 — Abel-boundary finite part

The limit
\[
\boxed{
\mathcal B_r(\lambda)
=
\lim_{t\downarrow r}
\left[
q_t+S_2\log\!\left(1-\frac{r^2}{t^2}\right)
\right]
}
\tag{2.1}
\]
exists and equals
\[
\boxed{
\mathcal B_r(\lambda)
=
-\sum_j\lambda_j^2\log\!\bigl(r|f'(z_j)|\bigr)
-\sum_{j\ne k}\lambda_j\lambda_k\log|x_j-x_k|.
}
\tag{2.2}
\]

Equivalently,
\[
q_t
=
-S_2\log\!\left(1-\frac{r^2}{t^2}\right)
+\mathcal B_r(\lambda)+o(1)
\qquad (t\downarrow r).
\tag{2.3}
\]

**Proof.** For the domain \(f(t\mathbb D)\), the conformal radius at \(x_j=f(z_j)\) is
\[
r_{\Omega_t}(x_j)
=
t\left(1-\frac{r^2}{t^2}\right)|f'(z_j)|.
\]
Hence the diagonal kernel is
\[
K_{\Omega_t}(x_j,x_j)
=
-\log t
-\log\!\left(1-\frac{r^2}{t^2}\right)
-\log|f'(z_j)|.
\]
After adding the renormalizing logarithm and sending \(t\downarrow r\), this tends to
\[
-\log(r|f'(z_j)|).
\]

For \(j\ne k\),
\[
K_{\Omega_t}(x_j,x_k)
=
-\log|x_j-x_k|
+
\log\rho\!\left(\frac{z_j}{t},\frac{z_k}{t}\right).
\]
The two normalized points approach distinct boundary points of the unit disk, so their pseudohyperbolic distance tends to \(1\). Thus the second term tends to zero. Summing the diagonal and off-diagonal terms proves (2.2). ∎

The quantity \(r|f'(re^{i\theta})|\) is exactly the speed of the Abel boundary under angular parametrization:
\[
r|f'(re^{i\theta})|
=
\left|\frac{\partial}{\partial\theta}f(re^{i\theta})\right|.
\]
Thus \(\mathcal B_r\) is a finite boundary insertion energy expressed entirely through the marked chord geometry and the four local Abel speeds.

## 3. Exact formula for a square

Let the physical points be the vertices of a square of side \(s\), and assign alternating charges \(+1,-1,+1,-1\) in physical cyclic order. The conformal order may be any of the square orderings.

The ordered off-diagonal interaction is
\[
-\sum_{j\ne k}\lambda_j\lambda_k\log|x_j-x_k|
=
4\log s-\log4.
\]
Therefore

### Corollary 3.1 — square boundary finite part
\[
\boxed{
\mathcal B_r^\square
=
4\log s-\log4
-\sum_{j=0}^3\log\!\bigl(r|f'(z_j)|\bigr).
}
\tag{3.1}
\]

Equivalently,
\[
\boxed{
\mathcal B_r^\square
=
\log
\frac{s^4}
{4\prod_{j=0}^3|\partial_\theta f(re^{i\theta_j})|}.
}
\tag{3.2}
\]

For the identity map and the quarter-spaced square \(z_j=ri^j\), (3.1) gives \(0\), agreeing with the exact disk insertion limit.

## 4. Bounded \(2+2\) has a universal logarithmic finite part

Use the bounded-\(2+2\) hypotheses from v199--v202. Put
\[
\varepsilon=1-r,
\]
and let \(g_1,g_3\) be the two short conformal gaps. The pair-width theorem and the bounded inner-scale assumption give, for all sufficiently late events,
\[
c\,\varepsilon\le g_1,g_3\le C\,\varepsilon
\tag{4.1}
\]
with constants \(c,C>0\).

For two equal-radius points separated by \(g\),
\[
\rho_r(g)
=
\frac{2r\sin(g/2)}
{\sqrt{(1-r^2)^2+4r^2\sin^2(g/2)}}.
\tag{4.2}
\]
Consequently (4.1) places the pseudohyperbolic separations of both short pairs in one compact subinterval
\[
0<\rho_- \le \rho_r(g_j)\le \rho_+<1.
\tag{4.3}
\]

Normalize a schlicht microscope at one endpoint \(z\) of a short pair. The growth theorem gives, with \(\rho=\rho(z,w)\),
\[
\frac{\rho}{(1+\rho)^2}
\le
\frac{|f(z)-f(w)|}
{(1-|z|^2)|f'(z)|}
\le
\frac{\rho}{(1-\rho)^2}.
\tag{4.4}
\]
The physical distance between two distinct square vertices is either \(s\) or \(s\sqrt2\). Since the two short pairs cover all four vertices, (4.3)--(4.4) imply
\[
\boxed{
(1-r^2)|f'(z_j)|\asymp_C s
\qquad (j=0,1,2,3).
}
\tag{4.5}
\]
As \(1-r^2\asymp\varepsilon\) and \(r\to1\),
\[
r|f'(z_j)|\asymp_C \frac{s}{\varepsilon}.
\tag{4.6}
\]

Substituting into (3.1) proves:

### Theorem 4.1 — bounded-\(2+2\) insertion asymptotic
\[
\boxed{
\mathcal B_r^\square
=
4\log(1-r)+O_C(1).
}
\tag{4.7}
\]

Thus the once-renormalized boundary finite part still tends to \(-\infty\). The further normalized quantity
\[
\boxed{
\mathcal I_r^\square
=
\mathcal B_r^\square-4\log(1-r)
}
\tag{4.8}
\]
remains bounded in every bounded-\(2+2\) collision family with a common tight-pair constant.

This is not a monotonicity theorem. It identifies the universal insertion scale that any future common-budget argument must subtract before comparing different Abel levels.

## 5. A quartic deep-interior bound

The v202 locality theorem controls changes far away from a square. There is also a simple complementary estimate in the opposite direction.

Let a square of circumradius \(A=s/\sqrt2\) be centered at \(c\), and let
\[
D=\operatorname{dist}(c,\partial\Omega).
\]
Assume \(D>A\). Since \(B(c,D)\subset\Omega\), domain monotonicity of the positive finite-point energy gives
\[
q_\Omega^\square
\le
q_{B(c,D)}^\square.
\]
After scaling the disk to the unit disk, the four charge points are \(ti^j\) with \(t=A/D\). Their moments vanish except for \(n\equiv2\pmod4\), and direct summation gives
\[
\boxed{
q_{B(c,D)}^\square
=
4\log\frac{1+t^4}{1-t^4},
\qquad t=\frac AD.
}
\tag{5.1}
\]

Hence:

### Theorem 5.1 — quartic interior screening
\[
\boxed{
0\le q_\Omega^\square
\le
4\log
\frac{1+(A/D)^4}{1-(A/D)^4}.
}
\tag{5.2}
\]
In particular,
\[
q_\Omega^\square
=
O\!\left((A/D)^4\right)
\qquad (A/D\to0).
\tag{5.3}
\]

Conversely, if \(q_\Omega^\square\ge\eta>0\), then
\[
\boxed{
\frac DA
\le
\left[\tanh\!\left(\frac{\eta}{8}\right)\right]^{-1/4}.
}
\tag{5.4}
\]

**Proof.** Only the disk calculation remains. In the unit disk
\[
M_n=\sum_{j=0}^3(-1)^j(ti^j)^n
=
\begin{cases}
4t^n,&n\equiv2\pmod4,\\
0,&\text{otherwise}.
\end{cases}
\]
The disk has zero Grunsky matrix, so
\[
q^\square
=
16\sum_{k\ge0}\frac{t^{8k+4}}{4k+2}
=
8\sum_{k\ge0}\frac{t^{8k+4}}{2k+1}
=
4\log\frac{1+t^4}{1-t^4}.
\]
Solving (5.2) for \(D/A\) gives (5.4). ∎

The fourth power is the physical quadrupole cancellation. A localized square-energy event therefore cannot remain uniformly positive while the square becomes deep relative to its own size.

## 6. What this contributes

The insertion finite part and the quartic interior estimate do not create a finite budget across a moving square lineage. They do sharpen the alternatives:

- bounded \(2+2\) has a universal boundary insertion scale \(4\log(1-r)\);
- a positive square energy forces boundary geometry at the square scale;
- deep-interior geometry is too regular, in the energetic sense, to carry a fixed event cost.

The next note tests whether Schwartz's actual rectangle-area invariant can control the remaining moving-charge transport. It can control the universal free-space **shape** term, but not the full domain-response term.
