# v203 proof audit

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Scope:** internal referee-style audit of the new v203 deductions. This is not independent expert review.

## 1. Boundary-insertion finite part

The conformal radius in \(\Omega_t=f(t\mathbb D)\) at the fixed physical point \(f(z_j)\), \(|z_j|=r<t\), is
\[
t\left(1-\frac{r^2}{t^2}\right)|f'(z_j)|.
\]
Therefore the diagonal divergence is exactly
\[
-\lambda_j^2\log\left(1-\frac{r^2}{t^2}\right).
\]
For distinct equal-radius points, their coordinates \(z_j/t,z_k/t\) approach distinct unit-circle points, so their pseudohyperbolic distance tends to one. No off-diagonal logarithmic divergence remains. This verifies the sign and normalization in Theorem 2.1.

The identity-disk quarter-square calibration gives finite part zero:
\[
4\log\frac{1+(r/t)^4}{1-(r/t)^4}
+
4\log\left(1-\frac{r^2}{t^2}\right)
\longrightarrow0.
\]

## 2. Square interaction constant

For alternating cyclic charges, the four adjacent unordered pairs have charge product \(-1\) and distance \(s\); the two opposite pairs have product \(+1\) and distance \(s\sqrt2\). Remembering that the kernel sum is ordered gives
\[
-\sum_{j\ne k}\lambda_j\lambda_k\log|x_j-x_k|
=
4\log s-\log4.
\]
This matches the v202 whole-plane regularized square constant after adding the four self terms.

## 3. Bounded-\(2+2\) asymptotic

The v201 pair-width floor plus \(g_1+g_3=O(1-r)\) yields two-sided bounds
\[
g_1,g_3\asymp1-r.
\]
Their pseudohyperbolic separations are therefore bounded away from both zero and one. The standard schlicht growth theorem, applied after centering at either endpoint, makes the physical short-pair distance comparable to
\[
(1-r^2)|f'(z_j)|.
\]
Every vertex belongs to one of the two tight pairs, and every distance between distinct square vertices is either \(s\) or \(s\sqrt2\). Hence
\[
(1-r^2)|f'(z_j)|\asymp s
\]
at all four vertices. Substitution gives
\[
\mathcal B_r^\square=4\log(1-r)+O(1).
\]

No lower regularity of the limiting Jordan boundary is used. The result is only for the bounded-\(2+2\) branch with the retained pair-width hypotheses.

## 4. Deep-interior monotonicity direction

If \(D=\operatorname{dist}(c,\partial\Omega)>A\), then \(B(c,D)\subset\Omega\). The v202 projection monotonicity is
\[
D_0\subset\Omega
\quad\Longrightarrow\quad
q_\Omega\le q_{D_0}.
\]
Thus the disk gives an **upper**, not lower, bound. The disk moment calculation yields
\[
4\log\frac{1+(A/D)^4}{1-(A/D)^4}.
\]
The inversion
\[
(A/D)^4\ge\tanh(\eta/8)
\]
when \(q_\Omega\ge\eta\) has been checked algebraically.

## 5. Rectangle shape energy and Schwartz sign

With \(L^2=X^2+Y^2\) and regularization \(d=\eta L\),
\[
C_\eta=4\log\frac{XY}{\eta L^2}.
\]
Writing \(X=L\cos\phi,Y=L\sin\phi\) gives
\[
C_\eta=4\log\frac{\sin2\phi}{2\eta}.
\]
Schwartz's convention is
\[
d\mathcal A=Y\,dX-X\,dY=-L^2d\phi.
\]
Therefore
\[
dC_\eta=-\frac{8\cot2\phi}{L^2}d\mathcal A.
\]
The sign agrees with the source convention. At \(\phi=\pi/4\), the coefficient vanishes; the Taylor expansion begins with \(-8h^2\).

## 6. Screening decomposition

The v202 orthogonal-projection identity says
\[
\frac1{2\pi}\|\nabla P_R\|_2^2
=
q_\Omega(R)
+
\frac1{2\pi}\|\nabla v_{\Omega,R}\|_2^2.
\]
For the scale-adapted rectangle regularization, the first term on the left is \(C_\eta(\phi)\). Hence
\[
q_\Omega=C_\eta-\mathscr S_\Omega.
\]
Differentiating the scalar identity gives the area/screening formula wherever the rectangle family and \(q_\Omega\) are differentiable. One does not need to differentiate a moving projection space to justify the fixed-domain formula.

On a square family the shape term is constant to first order, so
\[
dq_\Omega^\square=-d\mathscr S_\Omega^\square.
\]
This identifies, but does not bound, the missing transport term.

## 7. Analytic fourfold calibration

For
\[
f_a(z)=z+az^5,\qquad |a|<1/5,
\]
the estimate
\[
|z^5-w^5|\le5|z-w|
\]
on the closed unit disk proves injectivity directly. Thus no univalence criterion is being used beyond this elementary bound.

The equivariance
\[
f_a(iz)=if_a(z)
\]
makes the quarter-spaced Abel points exact squares. The outer finite-point energy is
\[
q_{\Omega_a}(\theta)
=
4\log\frac{1+r^4}{1-r^4}
+
4\log\left|
\frac{1+ar^4e^{4i\theta}}
{1+5ar^4e^{4i\theta}}
\right|.
\]
An independent derivation comes from the Green-kernel formula: relative to the identity disk, the square interaction contributes \(4\log|1+ar^4e^{4i\theta}|\), while the four diagonal conformal-radius terms contribute \(-4\log|1+5ar^4e^{4i\theta}|\).

The difference between \(\theta=0\) and \(\theta=\pi/4\) is nonzero for \(a\ne0\), because the relevant numerator-minus-denominator reduces to \(8ar^4\). The exact Grunsky coefficient \(c_{22}=-a\) supplies the same nonconstant \(4\theta\) harmonic.

## 8. Scope of the no-go theorem

Schwartz's area invariant is applied to the fixed analytic Abel curve \(\Gamma_r=f_a(rS^1)\). The charged energy is evaluated in the naturally associated fixed outer domain \(\Omega_a=f_a(\mathbb D)\), exactly the architecture contemplated in the v202 bridge. Along the square family,
\[
d\mathcal A=0
\]
but \(dq_{\Omega_a}\) is not identically zero.

This refutes:
- a pointwise estimate \(|dq|\le C|d\mathcal A|\);
- a total-positive-variation bound depending only on \(\operatorname{Var}\mathcal A\);
- a claim that the full charged square energy is determined by the area invariant and square shape alone.

It does **not** refute a more elaborate invariant using \(\mathcal A\) together with the screening response, marked conformal data, or chamber information.

## 9. Computational verification

The v203 script performs exact SymPy checks of:
- the disk insertion finite part;
- square and rectangle interaction constants;
- the quartic disk-energy expansion and threshold inversion;
- the area-energy differential and square Taylor degeneracy;
- fourfold equivariance;
- the exact nonconstant \(4\theta\) mode;
- \(c_{22}=-a\);
- and the alternating quarter-moment congruence.

No floating-point or interval arithmetic is used. These algebra checks do not replace the analytic arguments above.

## 10. What remains open

v203 does not supply:
- a finite common budget across moving square events;
- a sign or bounded-variation theorem for the screening response;
- a forced incompatible finite-point matrix;
- a proof that primitive concentration forces a noncollapsing square;
- or a proof of the full Toeplitz conjecture.

The immediate useful reduction is:
\[
\boxed{
\text{square transport}
=
\text{screening-response transport},
}
\]
after the universal shape term is removed.
