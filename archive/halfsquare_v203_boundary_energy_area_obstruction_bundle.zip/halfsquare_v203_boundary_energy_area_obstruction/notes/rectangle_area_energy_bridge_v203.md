# Rectangle area versus charged transport

**Author:** Benjamin John Schulz  
**Version:** v203, 10 September 2026  
**Status:** exact comparison for the universal rectangle-shape energy, plus an analytic calibration showing that Schwartz's area invariant alone cannot bound the full charged transport.

## 1. The tempting bridge

For a piecewise smooth path of rectangles inscribed in one fixed piecewise smooth Jordan loop, Schwartz's area quantity satisfies
\[
d\mathcal A=Y\,dX-X\,dY,
\tag{1.1}
\]
where \(X,Y\) are the two side lengths.

The v202 moving-charge identity has the form
\[
dq=-\mathcal D\,dt+\mathcal W\,dt.
\tag{1.2}
\]
It is natural to ask whether \(\mathcal A\), which is attached to the **actual four-point rectangle family**, can control the transport work \(\mathcal W\).

There is an exact relation for the free-space shape part. Unfortunately it becomes degenerate precisely at squares, and the full domain-response energy can vary while \(\mathcal A\) is constant.

## 2. Universal alternating-charge energy of a rectangle

Take a Euclidean rectangle with side lengths \(X,Y>0\), and put charges
\[
+1,-1,+1,-1
\]
cyclically around its vertices. Let
\[
L=\sqrt{X^2+Y^2}
\]
be the diagonal length. Regularize every charge in a disk of radius
\[
d=\eta L,
\]
where \(\eta>0\) is small enough that the four disks are disjoint on the aspect-ratio range under consideration.

The whole-plane regularized energy from v202 is
\[
C_\eta
=
-4\log d
-\sum_{j\ne k}\lambda_j\lambda_k\log|x_j-x_k|.
\]
There are two adjacent pairs of length \(X\), two of length \(Y\), and two opposite pairs of length \(L\). Therefore

### Proposition 2.1 — exact rectangle shape energy
\[
\boxed{
C_\eta(X,Y)
=
4\log\frac{XY}{\eta(X^2+Y^2)}.
}
\tag{2.1}
\]

Write
\[
X=L\cos\phi,\qquad
Y=L\sin\phi,\qquad
0<\phi<\frac{\pi}{2}.
\]
Then
\[
\boxed{
C_\eta(\phi)
=
4\log\frac{\sin2\phi}{2\eta}.
}
\tag{2.2}
\]

The overall rectangle scale has disappeared. This is exactly the scale-invariant free-space shape term.

## 3. Exact comparison with Schwartz's differential

From
\[
d\phi=\frac{X\,dY-Y\,dX}{X^2+Y^2}
\]
and (1.1),
\[
d\mathcal A
=
-(X^2+Y^2)d\phi
=
-L^2d\phi.
\tag{3.1}
\]
Differentiating (2.2) gives
\[
dC_\eta
=
8\cot(2\phi)\,d\phi.
\]
Hence:

### Theorem 3.1 — free-space area-energy identity
\[
\boxed{
dC_\eta
=
-\frac{8\cot(2\phi)}{L^2}\,d\mathcal A.
}
\tag{3.2}
\]

Equivalently,
\[
\boxed{
dC_\eta
=
-\frac{4(X^2-Y^2)}
{XY(X^2+Y^2)}
\,d\mathcal A.
}
\tag{3.3}
\]

Thus Schwartz's area form does control the scale-normalized **universal free-space shape energy** exactly.

But at a square,
\[
X=Y,\qquad \phi=\frac{\pi}{4},
\]
so
\[
\boxed{dC_\eta=0}
\tag{3.4}
\]
independently of the motion.

More quantitatively, if \(\phi=\pi/4+h\),
\[
\boxed{
C_\eta(\phi)
=
4\log\frac1{2\eta}
-8h^2-\frac{16}{3}h^4+O(h^6).
}
\tag{3.5}
\]

The free-space shape energy has a quadratic maximum at the square. The area differential is first order in \(d\phi\), while the energy sensitivity to aspect-ratio displacement vanishes to first order.

This is already a warning against using the area invariant as a positive first-order event cost at a square crossing.


## 4. Exact decomposition: area-controlled shape term plus screening

The v202 projection identity makes the missing term explicit. For each rectangle choose the four regularization disks with radius \(d=\eta L\) as above, let \(P_R\) be the corresponding whole-plane alternating-charge potential, and let \(v_{\Omega,R}\) be its orthogonal projection to \(H^1_0(\Omega)\). Define the screening energy
\[
\boxed{
\mathscr S_\Omega(R)
=
\frac1{2\pi}\int_{\mathbb R^2}
|\nabla v_{\Omega,R}|^2\,dA.
}
\tag{4.1}
\]

The Pythagorean identity from v202 gives
\[
\frac1{2\pi}\int|\nabla P_R|^2
=
q_\Omega(R)+\mathscr S_\Omega(R).
\]
The left side is exactly \(C_\eta(\phi)\). Hence:

### Theorem 4.1 — rectangle area/screening decomposition
\[
\boxed{
q_\Omega(R)
=
C_\eta(\phi)-\mathscr S_\Omega(R).
}
\tag{4.2}
\]

Along any differentiable rectangle family for which the regularization disks remain admissible,
\[
\boxed{
dq_\Omega
=
-\frac{8\cot(2\phi)}{L^2}\,d\mathcal A
-d\mathscr S_\Omega.
}
\tag{4.3}
\]

This is the exact version of the proposed area-energy bridge. It separates the transport into:

1. a universal aspect-ratio term controlled by Schwartz's area form;
2. a domain-screening term carrying all dependence on the surrounding conformal geometry.

On the square locus,
\[
\phi=\frac{\pi}{4},
\]
so
\[
\boxed{
dq_\Omega^\square=-d\mathscr S_\Omega^\square.
}
\tag{4.4}
\]

If the square regularization radius is written \(d=\eta s\) instead, then the whole-plane square energy is the constant
\[
4\log(1/\eta)-\log4,
\]
and the same conclusion follows directly.

Thus the exact-square transport problem is not an aspect-ratio problem at first order. It is a **screening-response problem**.

## 5. The full finite-point energy is not determined by \(\mathcal A\)

The stronger obstruction is exact and occurs in an analytic Jordan example.

Fix real
\[
0<|a|<\frac15
\]
and define
\[
\boxed{
f_a(z)=z+az^5.
}
\tag{5.1}
\]
For \(z,w\in\overline{\mathbb D}\),
\[
|z^5-w^5|\le5|z-w|,
\]
so
\[
|f_a(z)-f_a(w)|
\ge(1-5|a|)|z-w|.
\tag{5.2}
\]
Hence \(f_a\) is injective on the closed disk; its image boundary is an analytic Jordan curve.

Moreover,
\[
f_a(iz)=if_a(z).
\tag{5.3}
\]
For any fixed \(0<r<1\), the Abel curve
\[
\Gamma_r=f_a(rS^1)
\]
is fourfold symmetric. Therefore, for every \(\theta\),
\[
x_j(\theta)
=
f_a\!\left(re^{i(\theta+j\pi/2)}\right)
=
i^j f_a(re^{i\theta})
\tag{5.4}
\]
are the four vertices of an exact square centered at the origin.

Let
\[
\Omega_a=f_a(\mathbb D),
\]
and assign alternating charges to these four vertices.

### Proposition 5.1 — exact charged energy on the square family

Put
\[
\alpha=ar^4.
\]
Then
\[
\boxed{
q_{\Omega_a}(\theta)
=
4\log\frac{1+r^4}{1-r^4}
+
4\log\left|
\frac{1+\alpha e^{4i\theta}}
{1+5\alpha e^{4i\theta}}
\right|.
}
\tag{5.5}
\]

**Proof.** For the identity disk, the quarter-spaced alternating charge vector has moments only in the congruence class \(n\equiv2\pmod4\), giving
\[
q_{\mathbb D}(r)
=
4\log\frac{1+r^4}{1-r^4}.
\tag{5.6}
\]

For \(f_a\),
\[
f_a(re^{i\theta})
=
re^{i\theta}
\left(1+ar^4e^{4i\theta}\right),
\tag{5.7}
\]
and
\[
f_a'(re^{i\theta})
=
1+5ar^4e^{4i\theta}.
\tag{5.8}
\]
All four derivatives in the square have the same modulus, and the physical square side is
\[
s(\theta)=\sqrt2\,r\,
\left|1+\alpha e^{4i\theta}\right|.
\]
Substituting these data in the finite-point Green-kernel formula, with the pseudohyperbolic terms equal to the identity-disk baseline, gives (5.5). ∎

For \(a\ne0\), this function is nonconstant. For example,
\[
q_{\Omega_a}(\pi/4)-q_{\Omega_a}(0)
=
4\log
\left|
\frac{(1-\alpha)(1+5\alpha)}
{(1-5\alpha)(1+\alpha)}
\right|,
\tag{5.9}
\]
which is nonzero for \(0<|\alpha|<1/5\).

The same conclusion is visible directly in the Grunsky series: the exact coefficient
\[
c_{22}=-a
\]
produces a nonzero \(4\theta\) Fourier mode.

## 6. Yet Schwartz's area invariant is constant on this family

The family (4.4) consists entirely of squares. Thus its two side lengths satisfy
\[
X(\theta)=Y(\theta)=s(\theta).
\]
Schwartz's differential gives
\[
\frac{d\mathcal A}{d\theta}
=
Y\frac{dX}{d\theta}
-
X\frac{dY}{d\theta}
=0.
\tag{6.1}
\]

Therefore \(\mathcal A\) is constant along the whole square family, while (4.5) shows that the full finite-point energy in the naturally associated fixed outer domain \(\Omega_a\) varies.

### Theorem 6.1 — no direct area budget for charged square transport

There is no universal estimate of the form
\[
|dq_\Omega|
\le C\,|d\mathcal A|
\tag{6.2}
\]
along Abel square families, even for analytic Jordan domains and exact smoothly varying squares.

More generally, the positive variation of \(q_\Omega\) cannot be bounded by a function of the total variation of \(\mathcal A\) alone: in the family above,
\[
\operatorname{Var}(\mathcal A)=0,
\qquad
\operatorname{Var}(q_{\Omega_a})>0.
\tag{6.3}
\]

The same example rules out any claim that the full charged energy is a function only of Schwartz's alternating area invariant and the square shape. All rectangles here have exactly the same shape: a square.

## 7. What survives from the proposed bridge

The failure is informative rather than total.

Equation (3.2) identifies the piece that Schwartz's invariant controls:
\[
\text{rectangle aspect-ratio work}.
\]
The uncontrolled piece is the response of the surrounding conformal domain. On the square locus the universal shape term is stationary, so **all first-order charged transport is domain-response transport**.

This fits v202's locality theorem: far-away domain changes have small effect for one cleared square, but nearby boundary geometry can still change the local response as the square moves.

A successful use of Schwartz's rectangle family must therefore add information beyond \(\mathcal A\), for example:

1. a second marked-domain quantity controlling the nearby harmonic response;
2. a recurrence theorem forcing the same local domain geometry at two rectangle states with different \(q\);
3. or a compactness argument converting the failure of such control into a primitive/lobe concentration that can be attacked by the other branch of the project.

The simple proposal
\[
\text{area variation pays transport work}
\]
is now ruled out.
