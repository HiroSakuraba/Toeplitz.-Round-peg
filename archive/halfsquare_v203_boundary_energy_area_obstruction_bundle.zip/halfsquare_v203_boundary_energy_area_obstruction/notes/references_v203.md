# References checked for v203

Checked 10 September 2026.

1. **Richard Evan Schwartz**, *Inscribed Rectangle Coincidences*, manuscript dated 16 November 2019.  
   https://www.math.brown.edu/reschwar/Papers/coincidence.pdf  
   Section 2, Lemma 2.1 gives
   \[
   d\mathcal A=Y\,dX-X\,dY
   \]
   for a piecewise smooth path of rectangles inscribed in a fixed piecewise smooth Jordan loop. The integral version follows immediately afterward. v203 uses this sign convention in the rectangle area/screening decomposition.

2. **Eric Schippers and Wolfgang Staubach**, *Analysis on quasidisks: A unified approach through transmission and jump problems*, EMS Surveys in Mathematical Sciences, DOI 10.4171/EMSS/53.  
   https://ems.press/content/serial-article-files/37030  
   Background for the fixed finite-point/Grunsky energy and Faber-Dirichlet interpretation retained from v201. No new external theorem from this source is needed for the elementary v203 insertion and disk calculations.

The v202 references remain applicable to the localization and moving-charge identities used as inputs. The new formulas in v203 are proved in the accompanying notes; no priority claim is made.
