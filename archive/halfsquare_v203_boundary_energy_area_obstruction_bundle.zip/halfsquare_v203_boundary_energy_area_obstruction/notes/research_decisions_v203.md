# Research decisions after v203

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

v203 tested the most immediate bridge proposed in v202: use Schwartz's rectangle-area invariant to control the charged transport of the selected four points. The result is now exact enough to separate what works from what does not.

## 1. What was gained

For a rectangle with aspect angle \(\phi\), the scale-normalized whole-plane alternating-charge energy is
\[
C_\eta(\phi)=4\log\frac{\sin2\phi}{2\eta}.
\]
Schwartz's differential satisfies
\[
d\mathcal A=-(X^2+Y^2)d\phi,
\]
so
\[
dC_\eta
=
-\frac{8\cot2\phi}{X^2+Y^2}\,d\mathcal A.
\]

The full finite-point energy is
\[
q_\Omega=C_\eta-\mathscr S_\Omega,
\]
where \(\mathscr S_\Omega\) is the projection/screening energy. Hence
\[
dq_\Omega
=
-\frac{8\cot2\phi}{X^2+Y^2}\,d\mathcal A
-d\mathscr S_\Omega.
\]

This is the correct decomposition. The rectangle-area invariant controls the universal aspect-ratio term exactly. It does not control the nearby-domain screening response.

On squares,
\[
\cot2\phi=0,
\]
so the entire first-order transport is
\[
dq_\Omega^\square=-d\mathscr S_\Omega^\square.
\]

## 2. Why the direct area-budget route should be demoted

The analytic family
\[
f_a(z)=z+az^5,\qquad |a|<1/5,
\]
gives a fixed outer Jordan domain and a fixed Abel curve containing a smooth one-parameter family of exact squares. Schwartz's \(\mathcal A\) is constant along that family, but the charged energy varies explicitly.

Therefore no proof should now try to establish a bound of the form
\[
\text{transport work}\lesssim \text{variation of }\mathcal A
\]
without an additional term. That architecture is false even for analytic Jordan geometry.

The area invariant remains useful away from the square locus, where it controls aspect-ratio motion. It may still help organize a rectangle path, but it cannot be the budget that pays square transport.

## 3. The better energy variable is screening

The projection identity isolates
\[
\mathscr S_\Omega
=
\frac1{2\pi}\int|\nabla v_\Omega|^2.
\]

Three possible next theorems would make this useful.

### A. One-sided screening along a selected collision chamber

If the topology of the selected square/rectangle lineage forces \(\mathscr S_\Omega\) to change monotonically, or to cross separated levels only finitely often, then its bounded range could become a genuine event budget.

The fourfold calibration shows this cannot be true for arbitrary square families. Any such theorem must use the specific chamber or collision ordering.

### B. A screening recurrence contradiction

v202 locality says the full energy of one cleared square is determined up to \(O(s/R)\) by geometry within \(R\) of it. If a selected lineage revisits approximately the same marked local geometry while the finite-point compatibility matrix requires a different energy, that would be a contradiction.

This is more plausible than a global monotonicity theorem because it uses recurrence rather than total variation.

### C. Convert rapid screening oscillation into primitive concentration

If neither monotonicity nor recurrence holds, repeated \(O(1)\) screening changes at shrinking scales should require the nearby boundary to reorganize at every scale. A quantitative theorem converting that reorganization into unsigned lobe entropy or primitive concentration would reconnect the energy route to the v183/v189 endpoint program.

The analytic calibration is again a warning: ordinary smooth fourfold modulation produces screening oscillation without pathological concentration. The theorem would need an amplitude that remains nonvanishing under collapse or the bounded-\(2+2\) collision geometry.

## 4. Boundary insertion gives a second useful normalization

For a square on \(f(rS^1)\), the finite part after removing the charge-insertion divergence is
\[
\mathcal B_r^\square
=
4\log s-\log4
-\sum_j\log(r|f'(z_j)|).
\]

In bounded \(2+2\),
\[
\mathcal B_r^\square
=
4\log(1-r)+O(1).
\]

Therefore
\[
\mathcal I_r^\square
=
\mathcal B_r^\square-4\log(1-r)
\]
is bounded.

This quantity is worth tracking along a selected bounded-\(2+2\) lineage. Unlike the raw insertion energy, its dominant boundary singularity has already been removed. The open question is whether collision topology constrains its oscillation or forces a recurrent subsequence.

## 5. Deep-interior events are energetically negligible

If a square has circumradius \(A\) and center-to-boundary distance \(D>A\),
\[
q_\Omega^\square
\le
4\log\frac{1+(A/D)^4}{1-(A/D)^4}.
\]

Thus a uniformly positive event energy forces boundary geometry within \(O(A)\) of the square. This makes the energy route genuinely local: an event cannot be paid by smooth far-field geometry.

The estimate does not supply a positive lower bound for the events. It says where such a lower bound would have to live if one is proved.

## 6. Recommended v204 order

The best next work is now:

1. **Screening-response formula in marked local coordinates.** Differentiate \(\mathscr S_\Omega\) under a rigidly moving square and express it as a boundary or stress-energy pairing. Use the quadrupole cancellation to identify which local boundary modes can contribute at first order.
2. **Bounded-\(2+2\) recurrence test.** Combine the normalized insertion quantity \(\mathcal I_r^\square\), the finite-point positive matrix, and locality. Look for a two-event incompatibility before attempting a many-event theorem.
3. **Primitive-spike fallback.** In parallel, work on the scale-aware arc-area statement from v202: a fixed primitive spike should force a square above a controlled relative scale, or else force a metric lobe model already excluded by the phase machinery.

The first item is narrower and now has exact variables. The second can fail cleanly on an explicit model. The third remains the most direct route to the finite-\(2\)-variation endpoint if a new geometric idea appears.
