# v203 change record

Starting artifact: `halfsquare_v202_localized_square_energy_lean_bundle.zip`.

This update preserves the flat v202 source tree and adds:

- `notes/boundary_insertion_energy_v203.md`
- `notes/rectangle_area_energy_bridge_v203.md`
- `notes/research_decisions_v203.md`
- `notes/proof_audit_v203.md`
- `notes/references_v203.md`
- `code/verify_v203.py`
- `results/verify_v203_output.txt`
- v202 README/ledger snapshots under `history/v202/`

It updates the root README, theorem ledger, code instructions, manifest, and validation metadata.

The main mathematical changes are:
1. exact Abel-boundary insertion renormalization;
2. the bounded-\(2+2\) \(4\log(1-r)+O(1)\) finite-part asymptotic;
3. a quartic deep-interior square-energy bound;
4. an exact decomposition of rectangle transport into Schwartz-area shape work and conformal screening response;
5. an analytic fourfold calibration proving that Schwartz-area variation alone cannot bound charged square transport.

No old ZIP is nested in the new archive. Historical sources remain dated; the current ledger and v203 audit take precedence over superseded research suggestions.

Exact verification: 36 new SymPy checks, zero failures, no floating-point or interval certification.
