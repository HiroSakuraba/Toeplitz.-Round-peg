# Prior status carried from v203

The v204 bundle is intentionally lean. The complete v203 bundle remains a separate artifact.

Banked inputs used here:

- finite-point energy projection identity from v202;
- moving-charge decomposition from v202;
- boundary insertion finite part from v203;
- bounded-2+2 insertion asymptotic \(\mathcal B_r^\square=4\log(1-r)+O(1)\);
- quartic deep-interior bound;
- rectangle decomposition \(q=C_\eta-\mathscr S\);
- exact fact that the Schwartz-area term vanishes to first order on the square locus;
- analytic fourfold calibration showing that area variation alone cannot control square screening transport.

v204 does not alter those statements. It replaces the previously opaque differential \(d\mathscr S\) by exact stress-flux and Fourier-resonance formulas.
