# Half-square / Toeplitz research — v204

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Starting point:** v203 boundary-energy / area-obstruction bundle

This continuation attacks the screening-response term isolated in v203. The main new result is an exact stress-energy localization theorem for infinitesimal similarity motion of a neutral four-charge packet. For an alternating square, the local harmonic screening field obeys exact mod-4 mode-selection rules, and in any cleared centered disk the square-root finite-point energy has a quantitative Lipschitz bound in similarity-group path length. A simple star-shaped corollary gives a genuine one-sided screening theorem under an explicit geometric hypothesis.

The full Toeplitz conjecture remains open.

## Start here

1. [Similarity stress localization](notes/screening_stress_localization_v204.md).
2. [Square mode selection and cleared-disk bound](notes/square_mode_selection_v204.md).
3. [Conformal stress Fourier transform](notes/conformal_stress_fourier_transform_v204.md).
4. [Geometric consequences and v205 targets](notes/research_decisions_v204.md).
5. [Proof audit](notes/proof_audit_v204.md).
6. [References](notes/references_v204.md).

## New results

Let
\[
q_\Omega(\lambda)=\sum_{j,k}\lambda_j\lambda_k K_\Omega(x_j,x_k)
\]
be the finite-point energy of a neutral charge packet in a smooth simply connected domain, and let
\[
U=\sum_j\lambda_j g_\Omega(\cdot,x_j)
\]
be its Green potential. If the marked packet moves infinitesimally by the similarity vector field
\[
V(z)=a+b(z-c),\qquad a,b\in\mathbb C,
\]
then
\[
\boxed{
\dot q_\Omega
=\frac1{2\pi}\int_{\partial\Omega}(\partial_nU)^2 V\!\cdot n\,ds.
}
\]
Because the two-dimensional Dirichlet stress tensor
\[
T[U]=\nabla U\otimes\nabla U-\tfrac12|\nabla U|^2I
\]
is divergence-free away from the charges and traceless, the same response can be evaluated on **any** smooth contour \(\Gamma\Subset\Omega\) enclosing the packet:
\[
\boxed{
\dot q_\Omega
=\frac1\pi\int_\Gamma T[U]n_\Gamma\!\cdot V\,ds.
}
\]
Thus similarity transport is exactly localizable.

For an arbitrary Jordan Riemann map \(f:\mathbb D\to\Omega\), the localized flux can also be written on any analytic Abel contour. If
\[
W_V(z)=\frac{V(f(z))}{f'(z)},\qquad
\mathcal F_\lambda(z)=-\sum_{n\ge1}(M_nz^{-n-1}+\overline{M_n}z^{n-1}),
\]
then
\[
\boxed{
\dot q_\Omega=\Re[z^{-1}]\bigl(W_V\mathcal F_\lambda^2\bigr).
}
\]
This is an exact square-adapted conformal Fourier transform: the charge spectrum is universal, while all Jordan-domain geometry enters through \(V(f)/f'\).

Writing
\[
U(z)=-\sum_j\lambda_j\log|z-x_j|+h(z),
\]
with \(h\) harmonic through the charge points, gives the equivalent marked force formula
\[
\boxed{
\dot q_\Omega=-2\Re\sum_j\lambda_jV(x_j)H'(x_j),
}
\]
where \(h=\Re H\).

For an alternating square
\[
x_j=c+A e^{i\theta}i^j,\qquad \lambda_j=(-1)^j,
\]
and a cleared disk \(B(c,R)\Subset\Omega\), expand
\[
H'(c+z)=\sum_{m\ge0}c_mz^m.
\]
Then exactly
\[
\boxed{
\dot q_\Omega=-8\Re\left[
 a\sum_{k\ge0}c_{4k+2}A^{4k+2}e^{i(4k+2)\theta}
 +b\sum_{k\ge0}c_{4k+1}A^{4k+2}e^{i(4k+2)\theta}
\right].
}
\]
Hence translation sees only the \(2\pmod4\) screening-gradient modes, while rotation and dilation see only the \(1\pmod4\) modes.

Put \(t=A/R<1\). Since the local harmonic correction is a piece of the v202 finite-point energy field,
\[
\frac1\pi\int_{B(c,R)}|\nabla h|^2\le2q_\Omega.
\]
Cauchy–Schwarz and the exact mod-4 sums yield
\[
\boxed{
\begin{aligned}
\left|\frac{d}{d\tau}\sqrt{q_\Omega}\right|
&\le
4\sqrt2\,|a|\frac{A^2}{R^3}
\frac{\sqrt{3+t^8}}{1-t^8}\\
&\quad+
8|b|\frac{A^2}{R^2}
\frac{\sqrt{1+t^8}}{1-t^8}.
\end{aligned}
}
\]
For a square family, \(a=\dot c\) and \(b=\dot A/A+i\dot\theta\). Thus a uniformly cleared square cannot undergo order-one screening-energy oscillation without paying order-one normalized similarity path length.

Finally, the boundary formula gives a genuine sign result: if the normalized domain is star-shaped about the square center, then outward dilation satisfies
\[
\dot q_\Omega\ge0,
\qquad
\dot{\mathscr S}_\Omega\le0.
\]
This is not universal; it identifies a concrete geometric condition under which the screening term becomes one-sided.

## Strategic consequence

v203 asked whether the screening response could be localized. v204 answers **yes, exactly**, for similarity motion. But the response is still carried by the harmonic field induced by the surrounding domain. The useful dichotomy is now:

- if the square sits inside a centered cleared disk, only two mod-4 screening channels matter and \(\sqrt q\) has a quantitative path-length bound;
- if no such cleared disk exists at comparable scale, the boundary already threads the square-scale neighborhood and the problem becomes geometric/topological rather than a remote-energy problem.

The strongest v205 target is to combine this threading alternative with the bounded-\(2+2\) fjord/cross-ratio geometry from v198–v203, rather than search for a universal screening monotonicity theorem.

## Verification

Run

    python3 code/verify_v204.py

The verifier uses exact SymPy algebra for the square multipole selector, the two mod-4 Cauchy–Schwarz series, the disk calibration, and the stress/Hadamard normalization. Numerical checks are not used to establish the analytic theorems.
