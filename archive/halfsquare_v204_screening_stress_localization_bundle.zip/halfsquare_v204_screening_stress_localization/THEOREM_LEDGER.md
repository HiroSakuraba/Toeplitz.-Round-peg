# Theorem ledger — v204

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

## Banked in v204

### S204.1 — Boundary screening-stress formula
For a smooth simply connected domain and a neutral packet moved infinitesimally by a Euclidean similarity field \(V\),
\[
\dot q=(2\pi)^{-1}\int_{\partial\Omega}(\partial_nU)^2V\cdot n\,ds.
\]

### S204.2 — Exact contour localization
For any smooth contour enclosing the packet,
\[
\dot q=\pi^{-1}\int_\Gamma T[U]n\cdot V\,ds.
\]
The flux is contour-independent because the 2D stress tensor is divergence-free and traceless and \(V\) is a conformal affine field.

### S204.3 — Marked local force formula
If \(U=p+h\) and \(h=\Re H\) is the regular harmonic screening correction, then
\[
\dot q=-2\Re\sum_j\lambda_jV(x_j)H'(x_j).
\]

### S204.4 — Abel conformal stress transform
For any Jordan Riemann map and any analytic Abel contour enclosing the charges,
\[
\dot q=\Re[z^{-1}]\bigl((V(f)/f')\,\mathcal F_\lambda^2\bigr).
\]

### S204.5 — Alternating-square mod-4 selector
In a centered cleared disk, translation sees only \(H'\)-coefficients \(c_{4k+2}\), while rotation/dilation see only \(c_{4k+1}\).

### S204.6 — Cleared-disk square-root energy bound
The explicit inequality (4.5) of `square_mode_selection_v204.md` controls \(|d\sqrt q|\) by normalized similarity motion whenever \(A/R<1\).

### S204.7 — Star-shaped dilation monotonicity
If the domain is star-shaped about the square center, outward dilation gives \(\dot q\ge0\) and \(\dot{\mathscr S}\le0\).

## Retained from v203

- Boundary-insertion finite part \(\mathcal B_r\).
- Bounded-2+2 asymptotic \(\mathcal B_r^\square=4\log(1-r)+O(1)\).
- Quartic deep-interior square-energy bound.
- Exact rectangle shape/screening decomposition.
- Area-only transport budget refuted by the analytic fourfold calibration.

## Open

- Marked crosscut/fjord theorem for bounded 2+2.
- Screening-channel crossing cost through that crosscut.
- Common budget across multiple collision events.
- Bridge to v189 lobe lamination / primitive concentration.
- Full Toeplitz conjecture.
