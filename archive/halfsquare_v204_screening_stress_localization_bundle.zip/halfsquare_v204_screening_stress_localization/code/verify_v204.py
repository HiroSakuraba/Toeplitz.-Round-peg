import sympy as sp

checks = []
def check(name, expr):
    ok = sp.simplify(expr) == 0
    checks.append((name, ok, sp.simplify(expr)))
    if not ok:
        raise AssertionError(f"{name}: {sp.simplify(expr)}")

# 1. Root-of-unity square selector for several periods.
i = sp.I
for n in range(0, 20):
    s = sp.simplify(sum(((-1)**j) * i**(j*n) for j in range(4)))
    target = 4 if n % 4 == 2 else 0
    check(f"moment_selector_n{n}", s-target)

# 2. Exact weighted mod-4 sums.
t = sp.symbols('t', positive=True)
x = sp.symbols('x')
k = sp.symbols('k', integer=True, nonnegative=True)
# derive using elementary geometric sums, with x=t^8
Strans_x = 4*x/(1-x)**2 + 3/(1-x)
Strans = sp.factor(t**4 * Strans_x.subs(x,t**8))
check("translation_series", Strans - t**4*(3+t**8)/(1-t**8)**2)
Ssim_x = 4*x/(1-x)**2 + 2/(1-x)
Ssim = sp.factor(t**4 * Ssim_x.subs(x,t**8))
check("similarity_series", Ssim - 2*t**4*(1+t**8)/(1-t**8)**2)

# 3. Unit disk centered-square calibration.
A = sp.symbols('A', positive=True)
q = 4*sp.log((1+A**4)/(1-A**4))
dlogq = sp.simplify(A*sp.diff(q,A))
check("disk_dlog_energy", dlogq - 32*A**4/(1-A**8))

# Disk local screening-gradient selector: c_{4k+1}=-4 A^{4k+2}.
geom = -4*A**4/(1-A**8)
mode_dilation = -8*geom
check("disk_mode_dilation", mode_dilation - 32*A**4/(1-A**8))

# 4. Boundary-stress Parseval calibration.
# 2 sum |M_n|^2, M_{4k+2}=4 A^{4k+2}
parseval = 32*A**4/(1-A**8)
check("disk_boundary_stress", parseval-dlogq)

# 5. Neutral dilation free-space residue cancellation for a symbolic charge set
# Use algebraic identity: sum_{j<k} lambda_j lambda_k = -1/2 sum lambda_j^2 when sum lambda=0.
l0,l1,l2 = sp.symbols('l0 l1 l2')
l3 = -(l0+l1+l2)
ls=[l0,l1,l2,l3]
pairs=sum(ls[j]*ls[m] for j in range(4) for m in range(j+1,4))
squares=sum(v*v for v in ls)
check("neutral_pair_identity", 2*pairs+squares)

# 6. Similarity invariance additive kernel shift.
s = sp.symbols('s', positive=True)
charge_sum = sum(ls)
check("neutral_similarity_shift", -sp.log(s)*charge_sum**2)

# 7. Square free-space moments: monopole/dipole zero, quadrupole 4 A^2 zeta^2.
zeta = sp.symbols('zeta')
pts=[A*zeta*i**j for j in range(4)]
lams=[1,-1,1,-1]
M0=sp.simplify(sum(lams[j] for j in range(4)))
M1=sp.simplify(sum(lams[j]*pts[j] for j in range(4)))
M2=sp.simplify(sum(lams[j]*pts[j]**2 for j in range(4)))
check("square_monopole",M0)
check("square_dipole",M1)
check("square_quadrupole",M2-4*A**2*zeta**2)

print(f"PASS: {sum(ok for _,ok,_ in checks)}/{len(checks)} exact checks")
for name,ok,res in checks:
    print(f"{'PASS' if ok else 'FAIL'}  {name}")
