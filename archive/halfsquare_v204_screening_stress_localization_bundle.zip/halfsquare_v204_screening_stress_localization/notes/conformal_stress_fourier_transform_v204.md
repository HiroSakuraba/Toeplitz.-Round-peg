# Conformal stress transform for arbitrary Jordan domains

**Author:** Benjamin John Schulz  
**Version:** v204, 10 September 2026

## 1. Why this transform is useful

The physical stress-localization formula is exact, but a local Euclidean disk centered on a square need not lie inside a wild Jordan domain. The Riemann map supplies a replacement that always exists on every Abel level.

Let
\[
f:\mathbb D\to\Omega
\]
be the Riemann map of an arbitrary bounded Jordan domain. Put physical charges at
\[
x_j=f(z_j),
\qquad
\sum_j\lambda_j=0,
\]
and choose any
\[
\max_j|z_j|<t<1.
\]
The physical Abel contour
\[
\Gamma_t=f(tS^1)
\]
is analytic and encloses all the charges.

## 2. Universal disk Green field

Green functions are conformally invariant:
\[
g_\Omega(f(z),f(a))=g_{\mathbb D}(z,a).
\]
Hence the pulled-back packet potential is
\[
\widetilde U(z)=\sum_j\lambda_jg_{\mathbb D}(z,z_j).
\]
Its complex gradient on the annulus \(\max|z_j|<|z|<1\) is
\[
\boxed{
\mathcal F_\lambda(z)
=-\sum_j\lambda_j\left(
\frac1{z-z_j}+\frac{\overline{z_j}}{1-z\overline{z_j}}
\right).
}
\tag{2.1}
\]
If
\[
M_n=\sum_j\lambda_jz_j^n,
\]
neutrality gives the two-sided Laurent expansion
\[
\boxed{
\mathcal F_\lambda(z)
=-\sum_{n\ge1}
\left(M_nz^{-n-1}+\overline{M_n}z^{n-1}\right).
}
\tag{2.2}
\]
Thus the charge side of the transform is completely explicit.

## 3. Pullback of a physical similarity field

Let the physical square/packet move with the infinitesimal similarity field
\[
V(w)=a+b(w-c).
\]
Under \(w=f(z)\), the corresponding holomorphic vector field in conformal coordinates is
\[
\boxed{
W_V(z)=\frac{V(f(z))}{f'(z)}.
}
\tag{3.1}
\]
The complex stress one-form is conformally invariant in the required sense:
\[
V(w)(U_x-iU_y)^2\,dw
=
W_V(z)\mathcal F_\lambda(z)^2\,dz.
\tag{3.2}
\]
All dependence on the Jordan domain is therefore carried by the single holomorphic function \(W_V\).

## 4. Exact transform

Applying the contour-localization theorem on \(\Gamma_t\) and pulling back to \(|z|=t\) gives:

### Theorem 4.1 — Abel conformal stress transform

For every \(t\) with \(\max|z_j|<t<1\),
\[
\boxed{
\dot q_\Omega
=
\frac1\pi\Re\left[
-\frac i2
\oint_{|z|=t}
W_V(z)\mathcal F_\lambda(z)^2\,dz
\right].
}
\tag{4.1}
\]
Equivalently,
\[
\boxed{
\dot q_\Omega
=
\Re\operatorname{Res}
\left(W_V\mathcal F_\lambda^2\right)
=
\Re[z^{-1}]
\left(W_V(z)\mathcal F_\lambda(z)^2\right).
}
\tag{4.2}
\]
The value is independent of \(t\). For scale-adapted square regularization,
\[
\dot{\mathscr S}_\Omega=-\dot q_\Omega.
\]

This is an exact Fourier/Laurent transform of the marked Jordan geometry.

## 5. Interpretation

The factors have distinct roles:

- \(\mathcal F_\lambda\) is determined solely by the conformal locations and charges;
- squaring \(\mathcal F_\lambda\) forms the stress spectrum of the packet;
- \(W_V=V(f)/f'\) is the response of the particular Jordan geometry to the physical similarity motion;
- the coefficient extraction \([z^{-1}]\) selects exactly the resonant interaction between those two spectra.

Unlike a Fourier transform of an arbitrary boundary parametrization, this construction is tied to the Riemann map and is therefore insensitive to arbitrary reparametrization of the Jordan curve.

It also does not require the limiting boundary to have a tangent, finite length, or a classical normal: the contour \(f(tS^1)\) is analytic for every \(t<1\).

## 6. Connection with the local mod-4 selector

If a physical cleared disk is available and the square is used as the local center, the Laurent stress transform can be pushed onto a Euclidean circle and evaluated by residues at the square. The resulting residue classes are exactly the \(4k+2\) translation and \(4k+1\) rotation/dilation channels derived in `square_mode_selection_v204.md`.

So the local selector is not a separate construction. It is the physical-coordinate normal form of the general conformal stress transform.

## 7. Best next use

For bounded \(2+2\), the conformal points already have a highly constrained two-scale pattern and the Grunsky operator is asymptotically extremized by their long-pair wave packet. The natural next question is whether that same packet forces concentration in the coefficients of
\[
\frac1{f'(z)}
\quad\text{or}\quad
\frac{f(z)-c}{f'(z)},
\]
which are precisely the translation and dilation/rotation parts of \(W_V\).

A theorem linking Grunsky extremality to a forced large resonant coefficient in (4.2) would connect the v199--v203 spectral branch directly to the new screening-stress formula.
