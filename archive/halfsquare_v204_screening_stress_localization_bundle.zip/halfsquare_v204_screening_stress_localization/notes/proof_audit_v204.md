# v204 proof audit

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Scope:** internal referee-style audit of the new v204 deductions.

## 1. Hadamard sign and normalization

The classical Hadamard formula is usually written for \(-\Delta G=\delta\). The project Green function is \(g=2\pi G\), so
\[
\dot g(a,b)=\frac1{2\pi}\int_{\partial\Omega}\partial_ng(\xi,a)\partial_ng(\xi,b)V_n\,ds.
\]
Under inverse pullback of a moving charge packet, the domain boundary velocity is \(-V\cdot n\). Since \(q\) contains \(-g\), the two minus signs cancel and give
\[
\dot q=\frac1{2\pi}\int(\partial_nU)^2V\cdot n\,ds.
\]
The unit-disk dilation calibration independently reproduces the same factor and sign.

## 2. Similarity invariance

Under a common similarity of scale \(s\), \(K\) changes by \(-\log s\) in every entry, including the diagonal. The total change is
\[
-\log s\,(\sum\lambda_j)^2=0.
\]
Neutrality is essential.

## 3. Stress conservation

For
\[
T=\nabla U\otimes\nabla U-\tfrac12|\nabla U|^2I,
\]
\(\operatorname{div}T=(\Delta U)\nabla U\), so it vanishes off the charges. For a similarity field,
\[
\nabla V=\alpha I+\omega J.
\]
In two dimensions \(\operatorname{tr}T=0\), while symmetry of \(T\) kills the antisymmetric part. Hence \(T:\nabla V=0\). This is exactly why translations, rotations, and dilations localize, while a general affine shear would leave a bulk term.

The annular divergence theorem fixes the contour orientation and gives the same sign as the outer-boundary formula.

## 4. Complex contour constant

For a counterclockwise contour, \(n\,ds=(dy,-dx)\). Direct component calculation gives
\[
(R_x-iR_y)
=\int(Tn)_x-i(Tn)_y\,ds
=-\frac i2\oint (U_x-iU_y)^2dz.
\]
Pairing with the complex similarity field yields (4.1) of the localization note.

## 5. Pure free-space term

The free field is
\[
F_p=-\sum_j\lambda_j/(z-x_j).
\]
For translation, the residue of \(F_p^2\) sums to the total pair force and vanishes. For rotation, the real part of the corresponding virial is zero. For dilation, the double-pole term contributes \(\sum\lambda_j^2\), while the simple-pole pair term contributes its negative because
\[
2\sum_{j<k}\lambda_j\lambda_k=-\sum_j\lambda_j^2
\]
under neutrality. Hence the pure whole-plane packet carries no net similarity stress, as required by similarity invariance of its scale-adapted regularized energy.

## 6. Marked-force formula

Only \(2F_pH'\) survives the contour integral. The residue at \(x_j\) is \(-\lambda_jV(x_j)H'(x_j)\). Multiplying by the contour prefactor gives
\[
\dot q=-2\Re\sum_j\lambda_jV(x_j)H'(x_j).
\]
The sign agrees with the direct derivative of the regular-part kernel in the unit disk.

## 7. Mod-4 selector

The root-of-unity sum
\[
\sum_{j=0}^3(-1)^ji^{jn}
\]
is \(4\) for \(n\equiv2\pmod4\) and zero otherwise. Substituting the Taylor series of \(H'\) gives the two residue classes in Theorem 2.1 exactly. No truncation or small-square assumption is involved; only the existence of a centered cleared disk containing the square.

## 8. Local energy domination

The harmonic correction \(h\) equals minus the v202 whole-plane harmonic finite-point field inside \(\Omega\). Therefore its Dirichlet energy on a subdisk is bounded by the total whole-plane field energy:
\[
\frac1\pi\int_{B_R}|\nabla h|^2\le2q.
\]
The factor two follows from v202's normalization \(q=(2\pi)^{-1}\int|\nabla H_\Omega|^2\).

## 9. Cauchy–Schwarz series

The exact sums are
\[
\sum_{k\ge0}(4k+3)t^{8k+4}
=\frac{t^4(3+t^8)}{(1-t^8)^2},
\]
\[
\sum_{k\ge0}(4k+2)t^{8k+4}
=\frac{2t^4(1+t^8)}{(1-t^8)^2}.
\]
These give the stated powers \(A^2/R^3\) for translation and \(A^2/R^2\) for rotation/dilation. Dimensional analysis agrees: translation velocity has units of length/time; \(b\) has units of inverse time.

## 10. Star-shaped monotonicity

For a smooth domain star-shaped with respect to \(c\), the outward normal satisfies \((z-c)\cdot n\ge0\) almost everywhere. The boundary density \((\partial_nU)^2\) is nonnegative, so outward dilation gives \(\dot q\ge0\). This is conditional on star-shapedness and is not asserted for bounded-2+2 geometry.

## 11. Remaining limitations

v204 does not prove:
- existence of a centered cleared disk for a bad collision packet;
- a uniform sign for translation or rotation screening work;
- a common finite budget across many square events;
- a marked boundary crosscut in bounded 2+2;
- a bridge from the stress channels to the v189 lobe stack;
- the Toeplitz conjecture.

The key new fact is exact **localization of the first variation**, not locality of the screening field itself.

## 12. Conformal stress transform

If \(w=f(z)\), the complex gradient transforms as
\[
\mathcal F_z=(U_x-iU_y)_w\,f'(z).
\]
Therefore
\[
V(w)(U_x-iU_y)_w^2\,dw
=\frac{V(f(z))}{f'(z)}\mathcal F_z^2\,dz.
\]
The disk Green derivative is exactly
\[
-\frac1{z-a}-\frac{\bar a}{1-z\bar a},
\]
which yields the two-sided Laurent series in terms of \(M_n\). Applying the complex stress formula on \(f(tS^1)\) gives (4.1) of the transform note. Since
\[
-\frac i2(2\pi i)=\pi,
\]
the prefactor \(1/\pi\) converts the contour integral exactly to the real part of the residue. No limiting boundary regularity is needed because \(t<1\).
