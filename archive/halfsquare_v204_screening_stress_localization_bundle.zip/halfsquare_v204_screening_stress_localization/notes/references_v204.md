# References for v204

1. Björn Gustafsson and Ahmed Sebbar, **“Hadamard’s variational formula in terms of stress and strain tensors,”** *Analysis and Mathematical Physics* **12**, 29 (2022), DOI: 10.1007/s13324-021-00632-y. In particular, §2 states the classical boundary Hadamard formula and the paper develops the stress-tensor formulation used here. Their Green function normalization is \(-\Delta G=\delta\); v204 rescales it to the project convention \(-\Delta g=2\pi\delta\).

2. Takashi Suzuki and Takuya Tsuchiya, **“First and second Hadamard variational formulae of the Green function for general domain perturbations,”** *Journal of the Mathematical Society of Japan* **68** (2016), 1389–1419, DOI: 10.2969/jmsj/06841389. Used as a modern reference for Hadamard variation under general domain perturbations.

3. v202 project notes, `localized_square_energy_v202.md` and `charge_transport_v202.md`, for the finite-point projection identity and the normalization
\[
q=(2\pi)^{-1}\int_{\mathbb R^2}|\nabla H_\Omega|^2.
\]

4. v203 project notes, `rectangle_area_energy_bridge_v203.md`, for
\[
q=C_\eta-\mathscr S_\Omega
\]
and the fact that the scale-adapted whole-plane energy is constant to first order on the square locus.
