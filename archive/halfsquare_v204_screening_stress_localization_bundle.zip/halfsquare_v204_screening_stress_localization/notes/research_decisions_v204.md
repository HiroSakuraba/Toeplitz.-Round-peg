# Research decisions after v204

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

## 1. What v204 resolves

v203 reduced exact-square transport to the screening response. v204 gives an exact first-variation representation:
\[
\dot q
=\frac1{2\pi}\int_{\partial\Omega}(\partial_nU)^2V\cdot n\,ds
=\frac1\pi\int_\Gamma T[U]n\cdot V\,ds.
\]
For similarity vector fields the flux can be moved through every charge-free annulus because the two-dimensional stress tensor is divergence-free, symmetric, and traceless.

Therefore remote geometry is no longer an opaque term in the first variation. Its effect reaches the packet only through the harmonic screening field on a local enclosing contour.

## 2. The exact square selects only two local mode families

In a centered cleared disk, the alternating square couples only to
\[
c_{4k+2}\quad\text{under translation},
\]
and
\[
c_{4k+1}\quad\text{under dilation/rotation}.
\]
This should replace vague language about a "quadrupole-like" response. The selection rule is exact.

The local energy estimate also identifies \(\sqrt q\) as the right transport variable:
\[
|d\sqrt q|\lesssim_\kappa
\frac{|dc|}{A}+|d\log A|+|d\theta|
\]
on every branch with a uniformly cleared centered disk.

## 3. Universal one-sided screening is still impossible

The boundary formula has a positive density but an indefinite geometric factor \(V\cdot n\). Translation and rotation therefore have no universal sign. v203's analytic fourfold example already realizes sign-changing rotational screening work.

A real sign theorem does hold for outward dilation in a star-shaped domain. This suggests that any useful monotonicity theorem must be obtained by proving a **geometric sign condition for the selected chamber**, not by manipulating the energy alone.

## 4. The new dichotomy

For a square of circumradius \(A\) and center \(c\), either:

1. there is a centered disk \(B(c,R)\Subset\Omega\) with \(A/R\le\kappa<1\), in which case the mod-4 selector and path-length bound control screening transport; or
2. such clearance fails, so the boundary enters an \(O(A)\) neighborhood of the square center, or the center itself lies outside the domain. Then the packet is **threaded at its own scale**.

The second alternative is not a nuisance. Bounded \(2+2\) already requires a long conformal fjord and Grunsky extremality. The threading geometry may be the physical manifestation of that conformal obstruction.

## 5. Best v205 target

Do not spend the next version searching for a global stress-energy budget. The exact contour conservation shows why that is unlikely to add information: the same flux can be read on many contours.

Instead:

### A. Threading theorem for bounded 2+2

Use the two tight pairs, their vertex-clearance lower bounds, and the large cross-ratio/modulus distortion to prove that any bounded-2+2 packet must contain a boundary crosscut or fjord separating the two tight pairs at a controlled relative scale.

The desired output is a **marked geometric crosscut**, not merely a statement that the conformal modulus is large.

### B. Feed the marked crosscut into stress localization

Choose the local contour on the packet side of the crosscut. Determine whether the selected mod-4 stress channel must cross that neck. A quadrilateral crossing estimate for the relevant harmonic field could then charge the same bounded finite-point energy used in v201.

### C. Reconnect to v189 only after a marked crosscut is obtained

A sequence of controlled nested crosscuts is the kind of object that can plausibly be compared with the v189 lobe lamination. Without the marked separation theorem, merely juxtaposing "large modulus" and "many lobes" repeats the failed v194 modulus-counting idea.

## 6. Status

v204 is a structural advance, not a Toeplitz proof. It removes one analytical ambiguity—the moving screening projection—and replaces it with exact local stress data. The main remaining difficulty is now geometric: force the bad collision chamber to create a marked boundary neck that the selected square's screening field must actually use.
