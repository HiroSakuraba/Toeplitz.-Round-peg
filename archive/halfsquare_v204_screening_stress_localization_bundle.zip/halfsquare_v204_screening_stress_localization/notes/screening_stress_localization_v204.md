# Similarity stress localization for the screening response

**Author:** Benjamin John Schulz  
**Version:** v204, 10 September 2026  
**Status:** proved for smooth bounded simply connected domains; applicable to analytic Abel exhaustions. Jordan-domain use is by exhaustion away from the outer boundary.

## 1. Setup and normalization

Let \(\Omega\subset\mathbb C\) be a smooth bounded simply connected domain. Let \(x_1,\dots,x_N\in\Omega\) be distinct and let real charges \(\lambda_j\) satisfy
\[
\sum_j\lambda_j=0.
\]
Use the project normalization
\[
-\Delta g_\Omega(\cdot,a)=2\pi\delta_a,
\qquad
g_\Omega=0\text{ on }\partial\Omega.
\]
Put
\[
U(z)=\sum_j\lambda_j g_\Omega(z,x_j).
\]
The finite-point kernel is
\[
K_\Omega(x,y)=-\log|x-y|-g_\Omega(x,y)
\]
off the diagonal, with the conformal-radius value on the diagonal, and
\[
q_\Omega=\sum_{j,k}\lambda_j\lambda_kK_\Omega(x_j,x_k).
\]

Consider an infinitesimal orientation-preserving similarity about a marked center \(c\):
\[
S_\tau(z)=z+\tau V(z)+O(\tau^2),
\qquad
V(z)=a+b(z-c),
\]
where \(a\in\mathbb C\) is translation and \(b=\alpha+i\omega\) combines logarithmic dilation \(\alpha\) and rotation \(\omega\).

## 2. Hadamard pullback formula

Neutral finite-point energy is invariant under a common Euclidean similarity of the domain and charges. Indeed, under a similarity of scale \(s>0\), every entry of \(K\) acquires the same additive term \(-\log s\), whose total contribution is
\[
-\log s\left(\sum_j\lambda_j\right)^2=0.
\]
Therefore
\[
q_\Omega(S_\tau x_1,\dots,S_\tau x_N)
=q_{S_\tau^{-1}\Omega}(x_1,\dots,x_N).
\]
The pulled-back boundary velocity is \(-V\cdot n\). Hadamard's formula, in the normalization \(-\Delta g=2\pi\delta\), is
\[
\dot g_\Omega(a,b)
=\frac1{2\pi}\int_{\partial\Omega}
\partial_ng_\Omega(\xi,a)\,
\partial_ng_\Omega(\xi,b)\,
V_n(\xi)\,ds(\xi).
\]
Since the domain dependence of \(q\) enters with the minus sign in \(K=-\log|x-y|-g\), the inverse-domain velocity yields:

### Theorem 2.1 — boundary screening-stress formula

For infinitesimal similarity motion of the marked neutral packet in a fixed domain,
\[
\boxed{
\dot q_\Omega
=\frac1{2\pi}\int_{\partial\Omega}
(\partial_nU)^2\,V\cdot n\,ds.
}
\tag{2.1}
\]
For a square with scale-adapted core regularization, the whole-plane shape energy is similarity invariant, so the v203 screening energy satisfies
\[
\boxed{
\dot{\mathscr S}_\Omega=-\dot q_\Omega.
}
\tag{2.2}
\]

This formula already shows why no universal sign exists for arbitrary translations or rotations: \((\partial_nU)^2\ge0\), but \(V\cdot n\) generally changes sign around a closed boundary.

## 3. Exact contour localization

Define the two-dimensional Dirichlet stress tensor
\[
T[U]
=\nabla U\otimes\nabla U
-\frac12|\nabla U|^2I.
\tag{3.1}
\]
Away from the charge points, \(U\) is harmonic and
\[
\operatorname{div}T[U]=0.
\]
For an affine similarity field \(V(z)=a+b(z-c)\),
\[
\nabla V=\alpha I+\omega J.
\]
The tensor \(T\) is symmetric, so \(T:J=0\), and in two dimensions it is traceless, so \(T:I=0\). Hence
\[
\operatorname{div}(T[U]V)=T[U]:\nabla V=0
\tag{3.2}
\]
wherever \(U\) is harmonic.

Let \(\Gamma\Subset\Omega\) be any smooth Jordan contour enclosing all charge points and no other singularity, oriented counterclockwise with outward normal from its bounded interior. Apply the divergence theorem to the annulus between \(\Gamma\) and \(\partial\Omega\). On \(\partial\Omega\), \(U=0\), hence \(\nabla U=(\partial_nU)n\) and
\[
Tn\cdot V=\frac12(\partial_nU)^2V\cdot n.
\]
Therefore:

### Theorem 3.1 — exact similarity-stress localization

\[
\boxed{
\dot q_\Omega
=\frac1\pi\int_\Gamma T[U]n_\Gamma\cdot V\,ds.
}
\tag{3.3}
\]
The right side is independent of which enclosing contour \(\Gamma\) is chosen.

This is stronger than the v202 remote-domain locality estimate for the **first variation under similarities**: the flux itself is conserved through every charge-free annulus. Global geometry enters only through the harmonic field carried into the chosen local contour.

## 4. Complex contour form

For a real harmonic function \(U\), put
\[
F(z)=U_x-iU_y.
\]
In a charge-free region \(F\) is holomorphic. If \(v(z)=V_x+iV_y\) is the complex form of the similarity field, direct substitution into the stress tensor gives
\[
\boxed{
\int_\Gamma Tn\cdot V\,ds
=\Re\left[-\frac i2\oint_\Gamma v(z)F(z)^2\,dz\right].
}
\tag{4.1}
\]
Thus
\[
\boxed{
\dot q_\Omega
=\frac1\pi\Re\left[-\frac i2\oint_\Gamma vF^2\,dz\right].
}
\tag{4.2}
\]

## 5. Local marked-force formula

Write the Green potential near the packet as
\[
U(z)=p(z)+h(z),
\qquad
p(z)=-\sum_j\lambda_j\log|z-x_j|,
\tag{5.1}
\]
where \(h\) is harmonic through all charge points. Let
\[
h=\Re H,
\qquad H' = h_x-i h_y.
\]
Then
\[
F_p(z)=-\sum_j\frac{\lambda_j}{z-x_j}.
\]
In (4.2), the \(H'^2\) term has no poles. The pure free-space term \(F_p^2\) has zero total similarity flux for every neutral packet. For translation and rotation this is the usual vanishing total force and torque. For dilation, the double-pole and pair-interaction residues cancel by neutrality:
\[
\sum_{j<k}\lambda_j\lambda_k
=-\frac12\sum_j\lambda_j^2.
\]
Only the cross term survives. Taking residues gives:

### Theorem 5.1 — marked local response

\[
\boxed{
\dot q_\Omega
=-2\Re\sum_j\lambda_jV(x_j)H'(x_j).
}
\tag{5.2}
\]
Equivalently,
\[
\boxed{
\dot{\mathscr S}_\Omega
=2\Re\sum_j\lambda_jV(x_j)H'(x_j)
}
\tag{5.3}
\]
for scale-adapted square regularization.

The formula makes the role of the surrounding domain precise: it acts only through the **regular harmonic screening field** \(h\) evaluated at the marked points.

## 6. A genuine one-sided corollary

Take pure outward dilation about \(c\):
\[
V(z)=z-c.
\]
If \(\Omega\) is star-shaped with respect to \(c\), then for a smooth boundary
\[
(z-c)\cdot n\ge0
\quad\text{on }\partial\Omega.
\]
Equation (2.1) immediately gives:

### Corollary 6.1 — star-shaped dilation monotonicity

\[
\boxed{
\dot q_\Omega\ge0,
\qquad
\dot{\mathscr S}_\Omega\le0.
}
\tag{6.1}
\]
This is a real screening monotonicity theorem, but it depends on an explicit geometric sign condition. v203's fourfold calibration shows that no analogous sign theorem can hold for arbitrary square motion in arbitrary analytic Jordan domains.

## 7. Scope

The stress localization theorem is a first-variation theorem. It does not make the screening field itself local: changing remote boundary geometry can change \(h\) on the local contour. Its value is that any proposed transport budget can now be tested against a local flux or against the finitely marked force formula (5.2), instead of an opaque moving projection.
