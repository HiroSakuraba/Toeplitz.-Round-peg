# Alternating-square mode selection and cleared-disk response bound

**Author:** Benjamin John Schulz  
**Version:** v204, 10 September 2026

## 1. Exact square multipoles

Center the square at the origin and write
\[
x_j=A\zeta i^j,
\qquad
\zeta=e^{i\theta},
\qquad
\lambda_j=(-1)^j.
\]
Its complex moments are
\[
M_n=\sum_{j=0}^3\lambda_jx_j^n.
\]
The four-point root-of-unity sum gives
\[
\boxed{
M_n=
\begin{cases}
4A^n\zeta^n,&n\equiv2\pmod4,\\
0,&\text{otherwise}.
\end{cases}
}
\tag{1.1}
\]
The monopole and dipole vanish. The first surviving physical multipole is the quadrupole \(M_2=4A^2e^{2i\theta}\).

## 2. Screening-gradient selection rules

Assume a centered cleared disk
\[
\overline{B(0,R)}\subset\Omega,
\qquad A<R.
\]
Let the harmonic screening correction from v204 be
\[
h=\Re H,
\qquad
H'(z)=\sum_{m\ge0}c_mz^m
\quad(|z|<R).
\]
An infinitesimal square-preserving motion is
\[
V(z)=a+bz,
\]
where \(a\) is translation and \(b=\dot A/A+i\dot\theta\) is logarithmic scale plus rotation.

From the marked-force formula,
\[
\dot q=-2\Re\sum_j\lambda_j(a+bx_j)H'(x_j).
\]
Using (1.1),
\[
\sum_j\lambda_jH'(x_j)
=4\sum_{k\ge0}c_{4k+2}A^{4k+2}\zeta^{4k+2},
\]
while
\[
\sum_j\lambda_jx_jH'(x_j)
=4\sum_{k\ge0}c_{4k+1}A^{4k+2}\zeta^{4k+2}.
\]
Hence:

### Theorem 2.1 — exact mod-4 screening selector

\[
\boxed{
\dot q=-8\Re\left[
 a\sum_{k\ge0}c_{4k+2}A^{4k+2}e^{i(4k+2)\theta}
 +b\sum_{k\ge0}c_{4k+1}A^{4k+2}e^{i(4k+2)\theta}
\right].
}
\tag{2.1}
\]
Thus:

- translation couples only to gradient modes \(m\equiv2\pmod4\);
- dilation and rotation couple only to gradient modes \(m\equiv1\pmod4\);
- all other local harmonic screening modes are invisible to first-order similarity transport of the square.

This is the precise quadrupole/multipole cancellation requested after v203.

## 3. Local screening-field energy

Define
\[
E_R(h)=\frac1\pi\int_{B(0,R)}|\nabla h|^2\,dA.
\]
Because \(|\nabla h|=|H'|\), orthogonality of monomials gives
\[
\boxed{
E_R(h)=\sum_{m\ge0}\frac{|c_m|^2R^{2m+2}}{m+1}.
}
\tag{3.1}
\]
Inside \(\Omega\), the v202 harmonic finite-point field \(H_\Omega=P-v_\Omega\) equals \(-h\), including across the regularization disks by harmonic continuation. Therefore
\[
\boxed{E_R(h)\le2q_\Omega.}
\tag{3.2}
\]

## 4. Exact Cauchy–Schwarz sums

Put
\[
t=A/R<1.
\]
For the translation channel,
\[
\left|\sum_{k\ge0}c_{4k+2}A^{4k+2}\zeta^{4k+2}\right|
\le
\sqrt{E_R(h)}\,
\frac{A^2}{R^3}
\frac{\sqrt{3+t^8}}{1-t^8}.
\tag{4.1}
\]
Indeed,
\[
\sum_{k\ge0}(4k+3)t^{8k+4}
=
\boxed{
\frac{t^4(3+t^8)}{(1-t^8)^2}.
}
\tag{4.2}
\]

For the dilation/rotation channel,
\[
\left|\sum_{k\ge0}c_{4k+1}A^{4k+2}\zeta^{4k+2}\right|
\le
\sqrt{E_R(h)}\,
\sqrt2\frac{A^2}{R^2}
\frac{\sqrt{1+t^8}}{1-t^8},
\tag{4.3}
\]
using
\[
\sum_{k\ge0}(4k+2)t^{8k+4}
=
\boxed{
\frac{2t^4(1+t^8)}{(1-t^8)^2}.
}
\tag{4.4}
\]

Combining (2.1), (3.2), (4.1), and (4.3) proves:

### Theorem 4.1 — cleared-disk square-root energy bound

Where \(q_\Omega>0\),
\[
\boxed{
\begin{aligned}
\left|\frac d{d\tau}\sqrt{q_\Omega}\right|
&\le
4\sqrt2\,|a|\frac{A^2}{R^3}
\frac{\sqrt{3+t^8}}{1-t^8}\\
&\quad+
8|b|\frac{A^2}{R^2}
\frac{\sqrt{1+t^8}}{1-t^8}.
\end{aligned}
}
\tag{4.5}
\]
The integrated inequality extends through zeros of \(q\) by regularizing \(\sqrt q\) as \(\sqrt{q+\epsilon}\) and letting \(\epsilon\downarrow0\).

If \(t\le\kappa<1\), then
\[
\boxed{
\left|d\sqrt q\right|
\le C_T(\kappa)\frac{|dc|}{A}
+C_S(\kappa)\left(|d\log A|+|d\theta|\right),
}
\tag{4.6}
\]
with explicit choices
\[
C_T(\kappa)=
4\sqrt2\,\kappa^3
\frac{\sqrt{3+\kappa^8}}{1-\kappa^8},
\]
\[
C_S(\kappa)=
8\kappa^2
\frac{\sqrt{1+\kappa^8}}{1-\kappa^8}.
\]
Thus \(\sqrt q\), rather than \(q\), is naturally Lipschitz in the normalized similarity metric on a uniformly cleared branch.

## 5. Disk calibration

Take \(\Omega=\mathbb D\), square center \(0\), orientation \(0\), and circumradius \(A<1\). The exact energy is
\[
q(A)=4\log\frac{1+A^4}{1-A^4}.
\]
Hence
\[
\frac{dq}{d\log A}
=
\boxed{
\frac{32A^4}{1-A^8}.
}
\tag{5.1}
\]
For the disk, the regular harmonic Green correction has gradient coefficients
\[
c_m=-\overline{M_{m+1}}.
\]
Only \(m\equiv1\pmod4\) occur. Equation (2.1) with \(b=1\) gives
\[
-8\left(-4\sum_{k\ge0}A^{8k+4}\right)
=
\frac{32A^4}{1-A^8},
\]
exactly matching (5.1). Translation and rotation vanish by symmetry.

The boundary stress formula gives the same number because
\[
\frac1{2\pi}\int_0^{2\pi}(\partial_nU)^2\,d\phi
=2\sum_{n\ge1}|M_n|^2
=\frac{32A^4}{1-A^8}.
\]
This independently fixes the factor \(1/(2\pi)\) in the Hadamard normalization used by the project.

## 6. Geometric reading

The leading factor in both channels is \(A^2\), the square's quadrupole scale. A remote smooth screening field cannot couple to the square through monopole or dipole data because those moments vanish exactly.

The bound becomes weak as \(A/R\uparrow1\). That is not an artifact: it marks the regime in which the surrounding boundary penetrates the square's own scale. This is exactly the branch that must be handled by the bounded-\(2+2\) fjord/threading geometry rather than by a cleared-disk harmonic expansion.
