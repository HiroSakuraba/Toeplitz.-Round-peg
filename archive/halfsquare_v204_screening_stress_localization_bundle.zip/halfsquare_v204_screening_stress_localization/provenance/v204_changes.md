# v204 changes

- Took v203's screening-response term as the primary target.
- Derived the fixed-domain moving-square Hadamard formula by inverse similarity pullback.
- Converted the boundary formula to a contour-invariant 2D stress flux.
- Derived the equivalent local residue/force formula.
- Specialized to alternating square charges and obtained exact mod-4 mode selection.
- Derived explicit Cauchy–Schwarz response bounds and the square-root energy path-length inequality.
- Added the star-shaped dilation sign theorem.
- Demoted universal screening monotonicity; promoted a bounded-2+2 threading/crosscut theorem as the next geometric target.
- Pulled the conserved stress flux through the Riemann map to obtain an Abel-contour conformal stress transform valid for arbitrary Jordan domains; the response is the real part of one Laurent coefficient of `(V(f)/f') * F_lambda^2`.
