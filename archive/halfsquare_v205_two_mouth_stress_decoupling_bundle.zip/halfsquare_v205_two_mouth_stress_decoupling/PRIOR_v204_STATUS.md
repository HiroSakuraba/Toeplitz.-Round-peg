# Prior v204 status retained

v204 proved exact stress-energy localization for similarity motion of the alternating square, the local marked-force formula, exact mod-4 screening-mode selection, a cleared-disk Lipschitz estimate for \(\sqrt q\), and conditional star-shaped dilation monotonicity. It also introduced the conformal stress transform
\[
\dot q=\Re[z^{-1}](W_V\mathcal F_\lambda^2).
\]

v205 uses those results as banked inputs and does not alter their stated scope.
