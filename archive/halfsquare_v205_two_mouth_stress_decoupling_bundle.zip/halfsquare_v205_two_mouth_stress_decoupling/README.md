# Half-square / Toeplitz research — v205

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026  
**Starting point:** v204 screening-stress localization

This continuation attacks the bounded-\(2+2\) “marked fjord” target from v204. The main outcome is both positive and corrective.

First, bounded \(2+2\) does force two **controlled square-scale interior mouths**: fixed-pseudohyperbolic neighborhoods of the two tight source pairs map to disjoint analytic loops of physical diameter \(\asymp s\), while the extremal length between those loops grows at least like \(c\log R\). This gives a concrete fjord/corridor object without assuming quantitative boundary regularity.

Second, the direct first-order screening interaction across that long corridor is not order one. Using the exact v204 stress transform, the response splits into two local mouth functionals with a remote-pair error only \(O(R^{-2})\), improved to \(O(R^{-3})\) when the remote tight pair is neutral. Thus the next proof cannot rely on a universal positive “stress transmitted through the neck” cost.

The full Toeplitz conjecture remains open.

## Start here

1. [Two-mouth contour / fjord theorem](notes/two_mouth_contours_v205.md).
2. [Exact stress splitting and remote-pair decoupling](notes/two_mouth_stress_decoupling_v205.md).
3. [Exact two-germ square lock](notes/two_germ_square_lock_v205.md).
4. [Proof audit](notes/proof_audit_v205.md).
5. [v206 targets](notes/next_targets_v206.md).
6. [References](notes/references_v205.md).

## New theorem A — two square-scale mouths

In bounded \(2+2\), write
\[
\varepsilon=1-r,\qquad R=\delta/\varepsilon\to\infty,
\qquad g_1+g_3\le L\varepsilon.
\]
The banked v201 Grunsky deficit gives
\[
g_1,g_3\asymp_L\varepsilon.
\]
Choose one fixed pseudohyperbolic radius \(q<1\) large enough to contain either tight pair. For large \(R\), the two resulting pair disks are disjoint. Their image boundaries \(\Gamma_0,\Gamma_1\subset\Omega\) satisfy
\[
\boxed{s\le\operatorname{diam}\Gamma_i\le C_Ls}
\]
and lie at bounded physical relative distance. Nevertheless the extremal length of curves in \(\Omega\) joining them obeys
\[
\boxed{
\operatorname{EL}_\Omega(\Gamma_0,\Gamma_1)
\ge \frac1{2\pi}\log R-O_L(1).
}
\]
Thus two physically neighboring square-scale neighborhoods are separated by an intrinsically longer and longer passage.

This deliberately uses **interior** loops. A tiny source boundary crosscut can have a huge image on an arbitrary Jordan boundary, so v205 does not bank a quantitative true-boundary-crosscut theorem.

## New theorem B — exact two-mouth stress localization

Let
\[
\mathcal F=\mathcal F_0+\mathcal F_1
\]
be the disk Green-gradient split into the two tight source pairs, and
\[
W_V=V(f)/f'
\]
for a physical similarity field \(V(w)=a+b(w-c)\). Stress conservation through the charge-free region outside the two pair disks gives the exact disconnected-contour identity
\[
\boxed{
\dot q
=
\frac1\pi\Re\left[-\frac i2
\sum_{m=0}^1\oint_{\partial\Delta_m}
W_V\mathcal F^2\,dz\right].
}
\]
Define \(\mathcal J_m\) by replacing \(\mathcal F^2\) with the local-pair field \(\mathcal F_m^2\). With
\[
\nu(V)=|a|/s+|b|,
\]
one obtains
\[
\boxed{
\dot q=\mathcal J_0(V)+\mathcal J_1(V)
+O_L\!\left(\nu(V)R^{-2}\right).
}
\]
If the two tight clusters are neutral, the remote-pair cancellation improves this to
\[
\boxed{
\dot q=\mathcal J_0(V)+\mathcal J_1(V)
+O_L\!\left(\nu(V)R^{-3}\right).
}
\]
The estimate comes from the exact disk Green-gradient formula
\[
\mathcal G_a(z)
=-\frac{1-|a|^2}{(z-a)(1-z\bar a)}.
\]
At one mouth, a remote charge contributes only
\[
O\!\left(\frac1{R^2\varepsilon}\right)
\]
to the field, versus \(O(1/\varepsilon)\) for the local pair.

## Strategic consequence

v204 suggested that the long bounded-\(2+2\) neck might be forced to carry a selected order-one square-stress channel. v205 shows that this is not the right first-order picture. The long corridor is almost decoupled in the marked Green field; first-order response is asymptotically the sum of two local mouth functionals.

The exact pair-vector algebra also gives a first compatibility theorem. If \(F_0,F_1\) are the two normalized local schlicht microscopes, \(\xi_0,\xi_1\) their tight-partner coordinates, and \(r_m=(1-|a_m|^2)f'(a_m)\), then
\[
\boxed{
\frac{r_1}{r_0}=\omega_p\frac{F_0(\xi_0)}{F_1(\xi_1)}
}
\]
for a square-symmetry factor \(\omega_p\). Hence the two mouths are hyperbolically \(2\log R+O(1)\) apart while their normalized conformal derivative scales remain in a fixed nonzero ratio.

The next load-bearing problem is therefore **compatibility**, not transmission:
\[
\boxed{
\text{How can two local schlicht mouth germs belong to one fixed global map,}
\atop
\text{form one exact Euclidean square, and simultaneously generate the v199--v201 Grunsky extremizer?}
}
\]
The best v206 targets are a joint local/global compatibility inequality, the v201 finite-point PSD matrix across a selected lineage, and a possible second-variation calculation. A useful geometric alternative is to prove that the same connected Jordan-boundary subarc causes both of the previously banked \(O(s/\log R)\) long-chord bottlenecks.

## Verification

Run

    python3 code/verify_v205.py

The verifier checks exact Green-gradient identities, pseudohyperbolic formulas, the remote-field asymptotic scaling on rational model sequences, and the mod-4 charge-order bookkeeping. It does not replace the analytic proofs above.
