# v205 theorem ledger

| Item | Status | Meaning |
|---|---|---|
| v201 tight-pair floor \(g_1,g_3\asymp_L1-r\) | **BANKED PRIOR** | Both pair microscopes live at nondegenerate hyperbolic scale. |
| Two controlled interior pair loops | **PROVED v205** | Each loop encloses one tight pair and has physical diameter \(\asymp_L s\). |
| Logarithmic two-mouth extremal distance | **PROVED v205** | \(\operatorname{EL}\ge(2\pi)^{-1}\log R-O_L(1)\). |
| Square-scale true boundary crosscut | **NOT PROVED / DEMOTED** | Tiny source boundary caps can have large images for wild Jordan boundaries. |
| Disconnected two-mouth stress identity | **PROVED v205** | Full first variation equals sum of fluxes on the two pair contours. |
| Remote charge field at opposite mouth | **PROVED v205** | \(O((R^2\varepsilon)^{-1})\). |
| Neutral remote-pair improvement | **PROVED v205** | Opposite signs improve remote field to \(O((R^3\varepsilon)^{-1})\). |
| Two-mouth first-order decoupling | **PROVED v205** | \(\dot q=J_0+J_1+O(R^{-2})\), or \(O(R^{-3})\) in neutral-cluster order. |
| Two-germ compactification | **PROVED v205** | Along subsequences, leading first-order response depends on two local schlicht germs. |
| Exact two-germ square lock | **PROVED v205** | \(r_1/r_0=\omega_pF_0(\xi_0)/F_1(\xi_1)\); endpoint hyperbolic derivative scales remain comparable across distance \(2\log R+O(1)\). |
| Positive stress cost through the long neck | **REFUTED AS A GENERAL FIRST-ORDER TARGET** | Direct remote-pair transmission vanishes polynomially. |
| Compatibility contradiction between two germs | **OPEN** | Main v206 target. |
| Toeplitz conjecture | **OPEN** | No full proof claimed. |
