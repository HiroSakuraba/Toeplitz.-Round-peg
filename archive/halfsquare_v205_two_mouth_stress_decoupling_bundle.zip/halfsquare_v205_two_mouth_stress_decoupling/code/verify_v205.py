import sympy as sp

checks = []

def check(name, expr):
    ok = sp.simplify(expr) == 0
    checks.append((name, ok, sp.simplify(expr)))

# 1. Exact disk Green complex-gradient identity.
z, a, ab = sp.symbols('z a ab', nonzero=True)
expr = -1/(z-a) - ab/(1-z*ab) + (1-a*ab)/((z-a)*(1-z*ab))
check('green_gradient_factorization', expr)

# 2. Exact denominator comparison identity |1-a_bar z|^2-|z-a|^2.
# Treat zbar, abar as independent algebraic symbols.
zb = sp.symbols('zb')
lhs = (1-ab*z)*(1-a*zb) - (z-a)*(zb-ab)
rhs = (1-a*ab)*(1-z*zb)
check('disk_denominator_identity', lhs-rhs)

# 3. Equal-radius pseudohyperbolic formula.
r, g = sp.symbols('r g', positive=True, real=True)
# Using |e^{ig}-1|^2 = 4 sin^2(g/2)
num = 4*r**2*sp.sin(g/2)**2
den = (1-r**2)**2 + num
# Direct denominator |1-r^2 e^{ig}|^2.
direct_den = 1 + r**4 - 2*r**2*sp.cos(g)
check('pseudohyperbolic_denominator', direct_den-den)

# 4. Hyperbolic identity: if rho = X/sqrt(1+X^2), 2 atanh rho = 2 asinh X.
X = sp.symbols('X', positive=True, real=True)
# verify via tanh(asinh X)=X/sqrt(1+X^2)
check('tanh_asinh_identity', sp.tanh(sp.asinh(X)) - X/sp.sqrt(1+X**2))

# 5. Similarity-speed dimensional scaling algebra.
eps, R, nu = sp.symbols('eps R nu', positive=True)
W = eps*nu
Floc = 1/eps
Frem = 1/(R**2*eps)
length = eps
check('mixed_stress_scaling_R2', W*Floc*Frem*length - nu/R**2)
check('remote_square_scaling_R4', W*Frem**2*length - nu/R**4)
Frem_neutral = 1/(R**3*eps)
check('mixed_stress_scaling_R3_neutral', W*Floc*Frem_neutral*length - nu/R**3)

# 6. Charge-order bookkeeping.
charges = {0:1, 1:-1, 2:1, 3:-1}
orders = {
    'p0': (0,1,2,3),
    'p1': (0,1,3,2),
    'p2': (0,2,1,3),
}
expected = {
    'p0': (0,0),
    'p1': (0,0),
    'p2': (2,-2),
}
for name,p in orders.items():
    nets = (charges[p[0]]+charges[p[1]], charges[p[2]]+charges[p[3]])
    checks.append((f'cluster_charge_{name}', nets == expected[name], nets))

# 7. Neutral-pair first-difference scaling in a rational toy kernel K(theta)=eps/(delta+theta)^2.
# K(0)-K(g) has exact leading g*eps/delta^3 behavior.
delta, h = sp.symbols('delta h', positive=True)
K0 = eps/delta**2
Kh = eps/(delta+h)**2
ratio = sp.simplify((K0-Kh) / (eps*h/delta**3))
# Limit h/delta -> 0 equals 2.
t = sp.symbols('t', positive=True)
ratio_t = sp.simplify(ratio.subs(h, t*delta))
check('neutral_difference_limit', sp.limit(ratio_t, t, 0) - 2)

# 8. Radial admissible metric area over full annulus.
rin, rout = sp.symbols('rin rout', positive=True)
L = sp.log(rout/rin)
# 2pi integral_{rin}^{rout} (1/(rL))^2 r dr = 2pi/L
area = sp.simplify(2*sp.pi*sp.integrate(1/(sp.Symbol('rr')*L**2), (sp.Symbol('rr'), rin, rout)))
check('annulus_metric_area', area - 2*sp.pi/L)

# 9. Root-of-unity charge sums for three source orders, useful sanity check.
i = sp.I
for name,p in orders.items():
    lambdas = [charges[pj] for pj in p]
    checks.append((f'neutral_total_{name}', sum(lambdas)==0, sum(lambdas)))
    # actual physical charge values remain two + and two - under permutation
    checks.append((f'charge_square_sum_{name}', sum(x*x for x in lambdas)==4, sum(x*x for x in lambdas)))


# 10. Exact square pair-vector and centroid locks for the three source-order representatives.
Q = [sp.Integer(1), sp.I, sp.Integer(-1), -sp.I]
omega_expected = {'p0': -1, 'p1': 1, 'p2': sp.I}
eta_expected = {'p0': sp.I, 'p1': sp.I, 'p2': 0}
for name,pord in orders.items():
    P0 = sp.simplify(Q[pord[1]]-Q[pord[0]])
    P1 = sp.simplify(Q[pord[3]]-Q[pord[2]])
    C0 = sp.simplify((Q[pord[0]]+Q[pord[1]])/2)
    C1 = sp.simplify((Q[pord[2]]+Q[pord[3]])/2)
    check(f'pair_vector_lock_{name}', sp.simplify(P1-omega_expected[name]*P0))
    check(f'centroid_lock_{name}', sp.simplify((C1-C0)-eta_expected[name]*P0))

failed = [c for c in checks if not c[1]]
print(f'v205 exact/symbolic checks: {len(checks)-len(failed)}/{len(checks)} PASS')
for name,ok,val in checks:
    print(f'{"PASS" if ok else "FAIL"}  {name}' + ('' if ok else f' :: {val}'))
if failed:
    raise SystemExit(1)
