# v206 targets after two-mouth decoupling

## 1. Do not chase a scalar neck-flux lower bound

v205 shows that the direct remote-pair contribution to first-order similarity stress is only \(O(R^{-2})\), or \(O(R^{-3})\) for neutral pair clusters. The long conformal corridor is therefore almost decoupled at first order.

A universal statement of the form
\[
\text{long fjord}\Rightarrow\text{fixed positive cross-neck screening work}
\]
is incompatible with the actual Green-field scaling.

## 2. Best target: two-germ compatibility

Let \(F_0,F_1\) be subsequential normalized schlicht limits at the two tight pairs. Their partner parameters \(\eta_0,\eta_1\) stay in a compact annulus. The exact square equations impose:

- prescribed lengths of the two local pair image vectors;
- either equal-and-opposite adjacent-side vectors or common-midpoint diagonal relations, depending on square order;
- a prescribed relation between the two local normalization scales and phases.

Derive these relations explicitly in local microscope coordinates and ask whether an arbitrary pair \((F_0,F_1)\) can satisfy them while the global Grunsky packet simultaneously approaches the \(-1\) spectral edge.

The desired theorem is a **joint local/global compatibility inequality**, not another one-point distortion estimate.

## 3. Finite-point matrix route

The v201 kernel
\[
\mathcal E_{jk}
=(u(a_j,b_j),E u(a_k,b_k))_{\mathbb R}
\]
is positive semidefinite for any collection of long pairs. Use the two tight-pair microscopes to compute asymptotic off-diagonal entries between the two long-pair dipoles of a single \(2+2\) event, and then between nearby events on a selected lineage.

If local germ convergence fixes these entries while Grunsky extremality forces a different limit, a principal minor could provide a genuine contradiction.

## 4. Second variation is now more plausible than first variation

First-order cross-mouth coupling dies. The next term may retain information about how the two local germs are glued through the long corridor. Compute the Hessian of the finite-point energy under the four-dimensional square similarity/shape coordinates. In disk coordinates the second variation differentiates both \(W_V\) and the marked Green field and may expose an \(R^{-2}\) coefficient with a fixed sign or a summable square.

Do not assume this; calibrate first on the disk, the fourfold family \(z+az^5\), and the power/cusp models.

## 5. Boundary-threading refinement

The old long-chord estimate already gives boundary approach \(O(s/\log R)\). A worthwhile geometric strengthening would identify whether the *same connected boundary subarc* is responsible for the two marked long-chord bottlenecks. If one subarc threads both prescribed chords, the square is trapped by one physical fjord finger and a local topological classification may become possible.

This is much sharper than merely proving that some boundary point lies near each chord.

## 6. Relation to v189

Only after a common threading subarc or a joint-germ constraint is obtained should the result be compared with the v189 nested-lobe stack. Two independent local mouths with no compatibility theorem do not yet interact with the \(r^{-2}\) lobe count strongly enough to close the program.
