# v205 proof audit

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

## 1. What is genuinely new

The new banked statements are:

1. two disjoint fixed-pseudohyperbolic pair neighborhoods whose physical boundary loops have diameter comparable to the square side;
2. a logarithmically divergent extremal distance between those two physical loops;
3. exact stress-flux decomposition onto the disconnected union of the two loops;
4. \(O(R^{-2})\) remote-pair suppression in the local stress integral, improved to \(O(R^{-3})\) for a neutral remote tight pair;
5. the resulting two-germ compactification of first-order similarity screening response;
6. the exact complex square lock between the two local conformal-radius scales and partner values.

The older \(O(s/\log R)\) long-chord boundary-threading estimate is not claimed as new; it already appears in the v201/v202 transmission note.

## 2. Why boundary crosscuts were demoted

A source crosscut of Euclidean diameter \(O(1-r)\) with endpoints on \(S^1\) is not contained in a compact hyperbolic neighborhood of the charge points: its endpoints have pseudohyperbolic distance one. Koebe interior distortion therefore gives no uniform diameter bound for its image. An arbitrary Jordan Riemann map may send a tiny source boundary arc to a large physical excursion.

For this reason v205 does **not** assert a square-scale true boundary crosscut. The controlled replacement uses interior pseudohyperbolic circles.

## 3. Pair-width input

The proof uses the v201 positive Grunsky deficit to obtain a lower as well as upper bound on each tight source gap:
\[
g_1,g_3\asymp_L\varepsilon.
\]
The upper bound alone would not suffice: without the lower bound the pair image could fail to control the local conformal-radius scale from above.

## 4. Physical diameter control

The pair pseudohyperbolic separation stays in a compact subinterval of \((0,1)\). The normalized schlicht growth theorem therefore gives
\[
(1-r^2)|f'(z_i)|\asymp_Ls
\]
at either pair center. Fixed pseudohyperbolic disks then map into \(O_L(s)\) physical neighborhoods.

The lower bound on the loop diameter uses only that the bounded component contains two square vertices separated by at least \(s\). For any bounded domain, the diameter of its closure is attained on the boundary; hence the loop diameter is at least the distance of those two interior points.

## 5. Extremal-length direction

The radial test metric gives an **upper** bound on the conformal modulus of the connecting family and therefore a **lower** bound on its extremal length. The note consistently uses
\[
\operatorname{EL}(\Gamma)=1/\operatorname{Mod}(\Gamma).
\]
The constant \(1/(2\pi)\) is deliberately non-sharp because the proof integrates over a full Euclidean annulus even though the relevant region lies near the disk boundary.

## 6. Disconnected stress contour

The v204 conservation law was stated for one enclosing contour, but the divergence theorem applies equally to a domain with two inner boundary components. The outer flux equals the sum of the two positively oriented inner fluxes because \(\operatorname{div}T=0\) away from charges and \(T:\nabla V=0\) for similarities. There is no missing corridor term.

## 7. Remote Green-gradient estimate

For one disk charge,
\[
\mathcal G_a(z)
=-\frac{1-|a|^2}{(z-a)(1-z\bar a)}.
\]
On the opposite pair contour,
\[
|z-a|\gtrsim_L\delta,
\qquad
|1-z\bar a|\ge|z-a|,
\qquad
1-|a|^2\asymp\varepsilon.
\]
Thus
\[
|\mathcal G_a(z)|\lesssim_L\varepsilon/\delta^2
=1/(R^2\varepsilon).
\]
For an opposite-sign remote pair, differentiating with respect to its angular parameter gives one additional inverse power of \(\delta\); multiplication by its gap \(O(\varepsilon)\) yields \(1/(R^3\varepsilon)\).

No cancellation beyond this first difference is claimed.

## 8. Stress-error scaling

On a local pair contour:
\[
|W_V|\lesssim\varepsilon\nu,
\quad
|\mathcal F_{\rm local}|\lesssim1/\varepsilon,
\quad
|\mathcal F_{\rm remote}|\lesssim1/(R^2\varepsilon),
\quad
|dz|_{\rm total}\lesssim\varepsilon.
\]
Therefore the mixed term has size
\[
(\varepsilon\nu)(1/\varepsilon)(1/(R^2\varepsilon))(\varepsilon)
=O(\nu/R^2),
\]
and the remote-square term is smaller. This dimensional cancellation is an important sanity check.

## 9. What v205 does not prove

v205 does not prove:

- a true boundary crosscut of diameter \(O(s)\) separating the two tight pairs;
- a sign for either local mouth functional \(\mathcal J_m\);
- that \(\mathcal J_0+\mathcal J_1\) cannot cancel;
- that the two local schlicht germs are independent (they are not; both come from one fixed map);
- a finite common budget across different square events;
- a contradiction for bounded \(2+2\);
- the Toeplitz conjecture.

The key negative strategic conclusion is also rigorous: the direct remote-pair contribution to the first-order stress is asymptotically small, so a proof cannot simply assign an order-one first-variation cost to transmission across the growing corridor.


## 10. Two-germ square lock

The identity \(P_m=r_mF_m(\xi_m)\) is exact from the local normalization. The three source-order representatives give \(P_1/P_0=-1,1,i\). Since \(|\xi_m|\) stays in a compact subinterval of \((0,1)\), schlicht growth bounds keep \(|F_m(\xi_m)|\) bounded above and below. Thus the ratio of the complex hyperbolic derivative scales \(r_1/r_0\) remains in a compact annulus. No claim is made about the total variation of this quantity along the long corridor.
