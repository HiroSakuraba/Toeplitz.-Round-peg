# References used in v205

1. P. L. Duren, *Univalent Functions*, Springer, 1983. Standard growth and distortion theorems for normalized schlicht functions.
2. L. V. Ahlfors, *Conformal Invariants: Topics in Geometric Function Theory*, McGraw-Hill, 1973. Extremal length and conformal modulus.
3. F. W. Gehring and B. G. Osgood, classical comparison of hyperbolic and quasihyperbolic metrics in simply connected plane domains; the Koebe-quarter comparison is the only ingredient used in the previously banked long-chord bottleneck estimate.
4. B. Gustafsson and A. Sebbar, work on Hadamard variation and stress tensors for Green functions, cited in v204 for the stress-energy normalization.
5. Project-local inputs: v201 positive Grunsky deficit/pair-width floor; v204 similarity stress localization and conformal stress transform.
