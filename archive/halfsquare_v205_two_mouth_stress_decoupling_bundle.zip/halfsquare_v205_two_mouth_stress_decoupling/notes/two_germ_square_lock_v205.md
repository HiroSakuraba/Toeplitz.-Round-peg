# v205 — Exact square lock between the two local mouth germs

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

The two-mouth stress theorem says that first-order screening becomes local at the two tight-pair neighborhoods. Those two local germs are nevertheless not independent: the exact Euclidean square imposes a simple complex lock between them.

## 1. Pair vectors for the three source-order types

Write a standard cyclic square as
\[
Q_k=c+A\zeta i^k,
\qquad k=0,1,2,3,
\]
with \(|\zeta|=1\). Modulo dihedral symmetry, the three possible source orders are
\[
p_0=(0,1,2,3),\qquad
p_1=(0,1,3,2),\qquad
p_2=(0,2,1,3).
\]
For a source order \(p\), define the two tight-pair vectors
\[
P_0=Q_{p(1)}-Q_{p(0)},
\qquad
P_1=Q_{p(3)}-Q_{p(2)},
\]
and pair centroids
\[
C_0=\frac{Q_{p(0)}+Q_{p(1)}}2,
\qquad
C_1=\frac{Q_{p(2)}+Q_{p(3)}}2.
\]
A direct calculation gives
\[
\boxed{P_1=\omega_pP_0}
\tag{1.1}
\]
with
\[
\omega_{p_0}=-1,
\qquad
\omega_{p_1}=1,
\qquad
\omega_{p_2}=i,
\tag{1.2}
\]
for the displayed representatives. Dihedral relabeling only multiplies these constants by harmless square symmetries.

The centroid relation is
\[
\boxed{C_1-C_0=\eta_pP_0}
\tag{1.3}
\]
with
\[
\eta_{p_0}=i,
\qquad
\eta_{p_1}=i,
\qquad
\eta_{p_2}=0.
\tag{1.4}
\]
Thus the opposite-pair order \(p_2\) is exactly the common-midpoint case from v197.

## 2. Local schlicht microscopes

Let the first points of the two source tight pairs be
\[
a_0=z_0,\qquad a_1=z_2,
\]
with partners
\[
b_0=z_1,\qquad b_1=z_3.
\]
Use the disk automorphism
\[
\phi_a(u)=\frac{a+u}{1+\bar a u},
\qquad
\phi_a(0)=a,
\qquad
\phi_a'(0)=1-|a|^2,
\]
and define the normalized local maps
\[
F_m(u)=
\frac{f(\phi_{a_m}(u))-f(a_m)}{r_m},
\qquad
r_m=(1-|a_m|^2)f'(a_m).
\tag{2.1}
\]
Then
\[
F_m(0)=0,\qquad F_m'(0)=1.
\]
Let
\[
\xi_m=\phi_{a_m}^{-1}(b_m).
\]
The bounded-\(2+2\) pair-width theorem gives
\[
0<\rho_-\le|\xi_m|\le\rho_+<1.
\tag{2.2}
\]
The physical tight-pair vector is exactly
\[
\boxed{P_m=r_mF_m(\xi_m).}
\tag{2.3}
\]

## 3. Exact hyperbolic-scale/phase lock

Combining (1.1) and (2.3) gives
\[
\boxed{
\frac{r_1}{r_0}
=\omega_p\,
\frac{F_0(\xi_0)}{F_1(\xi_1)}.
}
\tag{3.1}
\]
Because normalized schlicht growth bounds keep \(|F_m(\xi_m)|\) uniformly above and below on the compact annulus (2.2),
\[
\boxed{
0<c_L\le
\left|\frac{(1-|a_1|^2)f'(a_1)}{(1-|a_0|^2)f'(a_0)}\right|
\le C_L<\infty.
}
\tag{3.2}
\]
This is stronger than the separate statement that each conformal-radius scale is comparable to \(s\): it records an exact complex relation between the two hyperbolically remote mouths.

At the same time,
\[
d_{\mathbb D}(a_0,a_1)=2\log R+O_L(1).
\tag{3.3}
\]
Thus bounded \(2+2\) combines
\[
\boxed{
\text{hyperbolic separation }\to\infty
\quad\text{with}\quad
\text{bounded nonzero endpoint hyperbolic derivative ratio}.}
\tag{3.4}
\]

This is the simplest exact local/global compatibility constraint produced by the two-germ viewpoint.

## 4. What it does and does not imply

Equation (3.2) rules out any proposed terminal corridor model in which the hyperbolically normalized derivative is forced to decay or blow up monotonically by an unbounded factor from one mouth to the other. It does not rule out a long corridor whose scale contracts and later re-expands, nor a highly oscillatory or folded geometry.

The next useful quantity is therefore not the endpoint ratio itself but the *variation* of
\[
\log\bigl((1-|z|^2)f'(z)\bigr)
\]
along a distinguished geodesic or crosscut chain joining the two mouths. If the large Grunsky wave packet can force large unsigned variation while (3.1) fixes the signed endpoint difference, one obtains a natural oscillation budget to compare with the v189 lamination.
