# v205 — Two square-scale mouths for bounded-2+2 collision

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

## 1. Setting

Let \(f:\mathbb D\to\Omega\) be conformal, with \(\Omega\) a bounded Jordan domain. Consider an exact square on the Abel curve \(f(rS^1)\), with source points
\[
z_0=re^{i\theta_0},\quad z_1=re^{i\theta_1},\quad
z_2=re^{i\theta_2},\quad z_3=re^{i\theta_3},
\]
in source order and internal angular gaps
\[
g_1=\theta_1-\theta_0,\qquad
g_2=\theta_2-\theta_1,\qquad
g_3=\theta_3-\theta_2.
\]
Put
\[
\varepsilon=1-r,\qquad \delta=g_1+g_2+g_3,\qquad R=\delta/\varepsilon.
\]
Assume the bounded-inner-scale \(2+2\) regime
\[
R\to\infty,\qquad g_1+g_3\le L\varepsilon.
\]
The v201 Grunsky deficit theorem implies, after discarding finitely many events,
\[
\boxed{\mu_L\varepsilon\le g_1,g_3\le L\varepsilon}
\tag{1.1}
\]
for some \(\mu_L>0\). The four image points are distinct square vertices, so every tight-pair image distance is either the square side \(s\) or its diagonal \(\sqrt2s\).

The goal here is to construct controlled *interior* contours around the two tight pairs. This avoids a false step: a small source crosscut with endpoints on \(\partial\mathbb D\) need not have small image diameter under an arbitrary Jordan Riemann map. Boundary distortion can be arbitrarily large. The controlled objects must stay a fixed hyperbolic distance inside the disk.

## 2. Tight pairs live at fixed pseudohyperbolic scale

For equal-radius points separated by angle \(g\),
\[
\rho_{\mathbb D}^2(re^{i\alpha},re^{i(\alpha+g)})
=
\frac{4r^2\sin^2(g/2)}{(1-r^2)^2+4r^2\sin^2(g/2)}.
\tag{2.1}
\]
By (1.1), there are constants
\[
0<\rho_-<\rho_+<1
\]
depending only on \(L\) such that eventually
\[
\boxed{\rho_-\le \rho(z_0,z_1),\rho(z_2,z_3)\le\rho_+.}
\tag{2.2}
\]
Choose once and for all
\[
\rho_+<q<1.
\]
Let \(\Delta_0\) be the pseudohyperbolic disk of radius \(q\) centered at \(z_0\), and \(\Delta_1\) the corresponding disk centered at \(z_2\). Then
\[
z_0,z_1\in\Delta_0,\qquad z_2,z_3\in\Delta_1.
\]
The long-pair hyperbolic distance is
\[
d_{\mathbb D}(z_0,z_2)
=2\operatorname{arsinh}
\frac{2r\sin((\theta_2-\theta_0)/2)}{1-r^2}
=2\log R+O_L(1),
\tag{2.3}
\]
and similarly for \((z_1,z_3)\). Hence the fixed-radius hyperbolic disks \(\Delta_0,\Delta_1\) are disjoint for all sufficiently large \(R\).

Put
\[
D_i=f(\Delta_i),\qquad \Gamma_i=\partial D_i=f(\partial\Delta_i).
\]
Each \(\Gamma_i\) is an analytic Jordan curve strictly inside \(\Omega\).

## 3. The two mouths have physical size comparable to the square

Write the conformal-radius scale
\[
r_f(z)=(1-|z|^2)|f'(z)|.
\]
Normalize at \(z_0\) by a disk automorphism and divide by \(r_f(z_0)\). The schlicht growth theorem gives
\[
\frac{\rho}{(1+\rho)^2}
\le
\frac{|f(w)-f(z_0)|}{r_f(z_0)}
\le
\frac{\rho}{(1-\rho)^2}
\tag{3.1}
\]
when \(\rho=\rho(z_0,w)\). Apply the lower bound to \(w=z_1\) and use (2.2). Since \(|f(z_1)-f(z_0)|\le\sqrt2s\),
\[
r_f(z_0)\le C_Ls.
\tag{3.2}
\]
The upper growth bound on the fixed disk \(\rho\le q\) then gives
\[
\operatorname{diam}D_0\le C_Ls.
\tag{3.3}
\]
The same holds for \(D_1\).

Conversely, each \(D_i\) contains two square vertices at mutual distance at least \(s\). The diameter of a bounded Jordan domain equals the diameter of its boundary, hence
\[
\operatorname{diam}\Gamma_i\ge s.
\]
Therefore
\[
\boxed{s\le\operatorname{diam}\Gamma_i\le C_Ls.}
\tag{3.4}
\]
The same growth estimate shows that both loops lie in a ball of radius \(C_Ls\) about the geometric square, and hence
\[
\operatorname{dist}(\Gamma_0,\Gamma_1)\le C_Ls.
\tag{3.5}
\]
Thus the two continua are at bounded Euclidean relative distance, even though their intrinsic conformal separation diverges.

## 4. A logarithmically long intrinsic corridor

Let \(\mathcal G_R\) be the family of curves in
\[
\Omega\setminus(\overline{D_0}\cup\overline{D_1})
\]
joining \(\Gamma_0\) to \(\Gamma_1\). By conformal invariance this is the same curve family in
\[
\mathbb D\setminus(\overline{\Delta_0}\cup\overline{\Delta_1}).
\]
A fixed pseudohyperbolic disk about \(z_0\) has Euclidean diameter \(O_L(\varepsilon)\). The second disk lies at Euclidean distance \(\asymp_L\delta\) from \(z_0\). Consequently every joining curve must cross a Euclidean annulus
\[
A(z_0;C_L\varepsilon,c_L\delta).
\]
Use the radial metric
\[
\varrho(z)=
\frac{1}{|z-z_0|\log(c_L\delta/(C_L\varepsilon))}
\]
on this annulus and zero outside. It is admissible for every curve in \(\mathcal G_R\), while
\[
\int\varrho^2\,dA
\le
\frac{2\pi}{\log(c_L\delta/(C_L\varepsilon))}.
\]
Therefore the extremal length of the joining family satisfies
\[
\boxed{
\operatorname{EL}(\mathcal G_R)
\ge
\frac1{2\pi}\log R-O_L(1).
}
\tag{4.1}
\]
No optimal constant is asserted. The important point is divergence.

### Theorem 4.1 — two-mouth fjord certificate

Every bounded-\(2+2\) exact-square sequence admits two disjoint analytic interior loops \(\Gamma_0,\Gamma_1\) such that
\[
\operatorname{diam}\Gamma_i\asymp_Ls,
\qquad
\operatorname{dist}(\Gamma_0,\Gamma_1)\lesssim_Ls,
\]
but
\[
\operatorname{EL}_\Omega(\Gamma_0,\Gamma_1)
\ge
\frac1{2\pi}\log R-O_L(1)\to\infty.
\]
Thus the physical obstruction is not merely a large four-boundary-point modulus. Two square-scale interior neighborhoods, physically close to one another, are separated by a conformally longer and longer passage in the fixed Jordan domain.

This is the controlled replacement for the over-strong proposed statement that a square-scale *boundary* crosscut must exist. A small source boundary cap can map to a large Jordan-boundary excursion; the theorem does not assume otherwise.

## 5. Relation to the earlier chord-threading estimate

The v201 transmission note already proves that the two long source pairs have hyperbolic distance \(2\log R+O(1)\) while their Euclidean image distance is \(s\) or \(\sqrt2s\). Therefore any physical path of length \(O(s)\) joining a long pair must approach \(\partial\Omega\) within \(O(s/\log R)\). In particular the straight long chord either exits \(\Omega\), or comes within \(O(s/\log R)\) of the true boundary.

The present theorem adds a different piece of structure: the two *tight-pair neighborhoods themselves* can be enclosed by controlled square-scale contours, and the entire conformal corridor between those contours has logarithmically divergent extremal length.
