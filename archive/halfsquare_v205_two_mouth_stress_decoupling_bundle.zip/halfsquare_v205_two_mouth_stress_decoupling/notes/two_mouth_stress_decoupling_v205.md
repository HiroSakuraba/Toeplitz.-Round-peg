# v205 — Exact two-mouth stress localization and remote-pair decoupling

**Author:** Benjamin John Schulz  
**Date:** 10 September 2026

## 1. Disk-coordinate Green field

Keep the bounded-\(2+2\) setup and the two pseudohyperbolic pair disks \(\Delta_0,\Delta_1\) from the companion note. Let the alternating square charges be \(\lambda_j\in\{+1,-1\}\), with total charge zero.

The Green potential in physical coordinates is
\[
U(w)=\sum_{j=0}^3\lambda_jg_\Omega(w,f(z_j)).
\]
Under \(w=f(z)\), conformal invariance gives the universal disk potential
\[
U(f(z))=\sum_j\lambda_jg_{\mathbb D}(z,z_j).
\]
Its complex gradient is
\[
\mathcal F(z)=\sum_j\lambda_j\mathcal G_{z_j}(z),
\]
where
\[
\boxed{
\mathcal G_a(z)
=-\frac1{z-a}-\frac{\overline a}{1-z\overline a}
=-\frac{1-|a|^2}{(z-a)(1-z\overline a)}.
}
\tag{1.1}
\]
Split
\[
\mathcal F=\mathcal F_0+\mathcal F_1
\]
according to the two tight source pairs \(\{z_0,z_1\}\) and \(\{z_2,z_3\}\).

For a physical similarity field
\[
V(w)=a+b(w-c)
\]
about the square center \(c\), define
\[
W_V(z)=\frac{V(f(z))}{f'(z)}.
\]
The v204 conformal stress formula is
\[
\dot q
=\frac1\pi\Re\left[-\frac i2\oint W_V\mathcal F^2\,dz\right]
\tag{1.2}
\]
on any contour enclosing all four charges.

## 2. The disconnected contour identity

The two pair disks are disjoint. Choose an Abel circle \(tS^1\), \(t<1\), enclosing both of them. The region between \(tS^1\) and
\[
\partial\Delta_0\cup\partial\Delta_1
\]
contains no charges. The stress tensor is divergence-free there and satisfies \(T:\nabla V=0\) for every similarity field. Therefore the outer stress flux equals the sum of the two inner fluxes.

Equivalently,
\[
\boxed{
\dot q
=
\frac1\pi\Re\left[-\frac i2
\sum_{m=0}^1
\oint_{\partial\Delta_m}W_V(z)\mathcal F(z)^2\,dz
\right].
}
\tag{2.1}
\]
The contours are positively oriented as boundaries of the pair disks.

This is exact. The long corridor itself carries no independent bookkeeping term; its effect is already encoded in the traces reaching the two mouths.

## 3. Uniform local estimates

Define the dimensionless similarity speed
\[
\nu(V)=\frac{|a|}{s}+|b|.
\tag{3.1}
\]
Because the tight-pair pseudohyperbolic separation stays in a compact subinterval of \((0,1)\), the schlicht growth and distortion theorems give, uniformly on either fixed pair contour,
\[
(1-|z|^2)|f'(z)|\asymp_L s,
\qquad
|f(z)-c|\lesssim_Ls.
\]
Moreover \(1-|z|\asymp_L\varepsilon\) on these contours. Hence
\[
\boxed{|W_V(z)|\le C_L\varepsilon\,\nu(V).}
\tag{3.2}
\]
The Euclidean length of each source contour is \(O_L(\varepsilon)\).

The contour stays a fixed hyperbolic distance from both charges in its own tight pair, so
\[
\boxed{|\mathcal F_m(z)|\le C_L/\varepsilon
\quad(z\in\partial\Delta_m).}
\tag{3.3}
\]

For a remote charge \(a\) from the other pair, \(|z-a|\gtrsim_L\delta\) on \(\partial\Delta_m\). Since
\[
|1-\overline a z|^2-|z-a|^2=(1-|a|^2)(1-|z|^2)\ge0,
\]
(1.1) gives
\[
\boxed{|\mathcal G_a(z)|\le C_L\frac{\varepsilon}{\delta^2}
=\frac{C_L}{R^2\varepsilon}.}
\tag{3.4}
\]
Thus, without using the signs inside the remote pair,
\[
\boxed{|\mathcal F_{1-m}(z)|\le\frac{C_L}{R^2\varepsilon}.}
\tag{3.5}
\]

If the remote tight pair is neutral, its two charges have opposite signs and angular separation \(O_L(\varepsilon)\). Differentiating (1.1) with respect to the remote angular parameter and applying the mean-value theorem improves (3.5) to
\[
\boxed{|\mathcal F_{1-m}(z)|\le\frac{C_L}{R^3\varepsilon}.}
\tag{3.6}
\]
The gain is the extra factor \(g/\delta=O(1/R)\).

## 4. Two-mouth decoupling theorem

Define the local-pair flux functional
\[
\boxed{
\mathcal J_m(V)
=
\frac1\pi\Re\left[-\frac i2
\oint_{\partial\Delta_m}
W_V(z)\mathcal F_m(z)^2\,dz
\right].
}
\tag{4.1}
\]
Expand
\[
\mathcal F^2
=\mathcal F_m^2+2\mathcal F_m\mathcal F_{1-m}+\mathcal F_{1-m}^2
\]
on each mouth. Combining (3.2)--(3.5) with the \(O(\varepsilon)\) contour length gives
\[
\left|
\frac1\pi\Re\left[-\frac i2\oint_{\partial\Delta_m}
W_V(2\mathcal F_m\mathcal F_{1-m}+\mathcal F_{1-m}^2)\,dz
\right]
\right|
\le
C_L\frac{\nu(V)}{R^2}.
\]
Summing the mouths yields:

### Theorem 4.1 — asymptotic two-mouth stress splitting

For every bounded-\(2+2\) exact square,
\[
\boxed{
\dot q
=\mathcal J_0(V)+\mathcal J_1(V)
+O_L\!\left(\frac{\nu(V)}{R^2}\right).
}
\tag{4.2}
\]
If both tight pairs are neutral, then
\[
\boxed{
\dot q
=\mathcal J_0(V)+\mathcal J_1(V)
+O_L\!\left(\frac{\nu(V)}{R^3}\right).
}
\tag{4.3}
\]
The improved case occurs when the two tight source pairs correspond to adjacent square vertices. If a tight pair consists of opposite square vertices, it carries two equal signs and only the \(R^{-2}\) estimate is available from this argument.

The constants depend only on the bounded-inner-scale constant \(L\) and the fixed choice of pair contour radius \(q\).

## 5. Interpretation

The conformal corridor between the pair neighborhoods has extremal length \(\gtrsim\log R\), yet the *charge-field coupling from one mouth to the other* contributes only \(O(R^{-2})\) to first-order similarity stress, or \(O(R^{-3})\) when the remote pair is neutral.

Therefore the v204 proposal that a uniformly positive first-order screening channel must be transmitted through the entire long neck is not correct in that form. At leading order the response splits into two local mouth functionals.

This is not a contradiction to the Grunsky result. The global Jordan geometry still enters each \(\mathcal J_m\) through
\[
W_V=V(f)/f'.
\]
What disappears is the direct *remote charge field* across the growing conformal separation.

## 6. Two-germ compactification

Normalize \(f\) separately at the two pair centers:
\[
F_m(u)
=
\frac{f(\phi_{z_m}(u))-f(z_m)}{(1-|z_m|^2)f'(z_m)},
\qquad m=0,1,
\]
with the appropriate pair-center indices. The tight partner has pseudohyperbolic coordinate in a fixed compact annulus
\[
0<\rho_-\le|u_m|\le\rho_+<1.
\]
The family of normalized schlicht maps is compact on every smaller disk. After subsequence extraction, each mouth therefore has a local schlicht limit, and \(\mathcal J_m\) is a continuous functional of that local germ, the limiting partner coordinate, and the normalized similarity field.

Hence bounded \(2+2\) first-order screening transport has an asymptotic **two-germ compactification**:
\[
\boxed{
\dot q
\longrightarrow
\mathcal J(F_0,\eta_0;V_0)
+
\mathcal J(F_1,\eta_1;V_1)
}
\]
whenever the normalized local data converge.

The logarithmically long middle corridor is still essential to the existence of the collision, but it does not automatically create a growing first-order screening cost.

## 7. Strategic consequence

This rules out a tempting v205 shortcut:

> large bounded-\(2+2\) modulus \(\Rightarrow\) order-one stress must repeatedly cross the neck.

The direct cross-neck contribution actually vanishes polynomially in \(R\). A successful continuation must instead exploit a **compatibility condition between the two local mouth germs** imposed by their belonging to one fixed global Riemann map and by their four images forming one exact Euclidean square.

That is closer in spirit to the v201 finite-point compatibility matrix than to a scalar neck-energy budget.
