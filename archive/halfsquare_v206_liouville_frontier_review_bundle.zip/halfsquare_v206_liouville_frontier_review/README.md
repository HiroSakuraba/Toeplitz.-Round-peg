# Toeplitz research — v206 critique and proof skeleton

**Author:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** research correction and targeted deductions; the full conjecture remains unproved.

This is a small review supplement to the existing archive. It responds to Claude's critique of v204 after reading the full original Asano–Ike paper and recovering v203–v205. It does not replace the complete historical archive.

The central decision is to stop treating a local response bound as a proposed global energy budget. The square-free contradiction must specify an irreversible event cost or a direct route from primitive concentration to an actual square.

Read:

1. [Assessment and scope corrections](notes/critique_assessment.md).
2. [Global contradiction skeleton](notes/contradiction_skeleton.md).
3. [Critical double-spiral renormalization test](notes/spiral_test.md).
4. [Exact radial-action criterion on Abel curves](notes/abel_action_criterion.md).
5. [Sources and verification scope](notes/sources_and_audit.md).

The canonical critical double spiral was already addressed by the project's [v187 lattice-square argument](retained/nonlocal_spiral_lattice_theorem_v187.md). That source is retained verbatim so the proposed new test case can be compared with the actual earlier proof.

Run the elementary exact verifier with:

    python3 code/verify_v206.py

It passed 71 exact checks using the Python standard library and rational arithmetic. Its checks establish specified algebraic identities and example constants, not the analytic or topological assertions.

This supplement contains no nested archives and no copy of the downloaded external paper.
