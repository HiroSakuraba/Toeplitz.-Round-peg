#!/usr/bin/env python3
"""Exact elementary calibrations for v206; standard library only."""
from fractions import Fraction as Q

checks = {}


def check(group, assertion):
    if not assertion:
        raise AssertionError(group)
    checks[group] = checks.get(group, 0) + 1


def add(x, y):
    return (x[0]+y[0], x[1]+y[1])


def scale(a, x):
    return (a*x[0], a*x[1])


def mul(x, y):
    return (x[0]*y[0]-x[1]*y[1], x[0]*y[1]+x[1]*y[0])


def conj(x):
    return (x[0], -x[1])


def norm2(x):
    return x[0]*x[0]+x[1]*x[1]


def div(x, y):
    return scale(1/norm2(y), mul(x, conj(y)))


zero, one = (Q(0), Q(0)), (Q(1), Q(0))
units = [one, (Q(0), Q(1)), (-Q(1), Q(0)), (Q(0), -Q(1))]
c, radius, a = Q(9, 35), Q(16, 35), Q(1, 3)
xs = [add((c, Q(0)), scale(radius, u)) for u in units]
zs = [div(add(w, (-a, Q(0))), add(one, scale(-a, w))) for w in xs]
expected = [(Q(1, 2), Q(0)), (-Q(6, 37), Q(35, 74)),
            (-Q(1, 2), Q(0)), (-Q(6, 37), -Q(35, 74))]
for z, w, target in zip(zs, xs, expected):
    check("Abel square preimages", z == target)
    check("Abel square preimages", norm2(z) == Q(1, 4))
    check("Abel square preimages",
          div(add(z, (a, Q(0))), add(one, scale(a, z))) == w)
physical = zero
source = zero
for j in range(4):
    physical = add(physical, scale((-1)**j, xs[j]))
    source = add(source, scale((-1)**j, zs[j]))
check("physical versus conformal moments", physical == zero)
check("physical versus conformal moments", source == (Q(12, 37), Q(0)))

# Rational parts of q and its derivatives; limits follow by evaluating the
# continuous renormalized rational expression at A=1.
for A in [Q(1, 3), Q(1, 2), Q(9, 10), Q(9999, 10000)]:
    N, D = 1+A**4, 1+A+A*A+A**3
    check("disk finite part", N/(1-A**4)*(1-A) == N/D)
    raw_rate = 4*A*(4*A**3/(1+A**4)+4*A**3/(1-A**4))
    check("disk finite part", raw_rate == 32*A**4/(1-A**8))
    finite_rate = 4*A*(4*A**3/N-(1+2*A+3*A*A)/D)
    check("disk finite part", raw_rate-4*A/(1-A) == finite_rate)
A = Q(1)
N, D = 1+A**4, 1+A+A*A+A**3
check("disk finite-part limits", N/D == Q(1, 2))
check("disk finite-part limits",
      4*A*(4*A**3/N-(1+2*A+3*A*A)/D) == 2)

# Infinite intersections: take psi=0 and write u=U*pi, v=V*pi.
for K1, K2 in [(Q(2), Q(1)), (Q(1), Q(2)), (Q(3), Q(2))]:
    sign = 1 if K1 > K2 else -1
    for k in [sign, 2*sign, 17*sign]:
        V = K2*K2*2*k/(K1*K1-K2*K2)
        U = V+2*k
        check("unequal critical arms", U > 0 and V > 0)
        check("unequal critical arms", K1*K1/U == K2*K2/V)
        check("unequal critical arms", U-V == 2*k)

# Critical interlacing inequalities after cancelling K^2; shift is positive.
for T, shift in [(Q(1), Q(2)), (Q(7), Q(3)), (Q(100), Q(1))]:
    check("critical interlacing", 0 < T/(T+shift) < 1)
    check("critical interlacing", 0 < 1/T-1/(T+shift) <= shift/T**2)

# Stokes sign for f(z)=b+a*z at rational direction phases.
# The theta-dependent area terms agree independently; these are the endpoint
# terms in the angular primitive and the difference of radial actions.
for b, aa in [((Q(2), Q(3)), (Q(1), Q(0))),
              ((Q(1, 3), -Q(2, 5)), (Q(3, 5), Q(4, 5)))]:
    r, s = Q(1, 3), Q(4, 5)
    for phase in units:
        endpoint = (s-r)*mul(conj(b), mul(aa, add(phase, (-Q(1), Q(0)))))[1]/2
        radial_theta = (s-r)*mul(conj(b), mul(aa, phase))[1]/2
        radial_zero = (s-r)*mul(conj(b), aa)[1]/2
        check("annular Stokes orientation", endpoint == radial_theta-radial_zero)

# Telescoping budget with summable positive recovery.
E0, eps = Q(3), Q(1, 2)
recovery = sum((Q(1, 2**(n+1)) for n in range(12)), Q(0))
check("budget contradiction", recovery < 1)
check("budget contradiction", E0-12*eps+recovery < 0)

for group, count in checks.items():
    print(f"PASS {group}: {count} exact checks")
print(f"TOTAL: {sum(checks.values())} exact checks, zero failures")
print("Standard-library rational arithmetic; no floating point or intervals.")
print("The checks do not replace the written analytic proofs.")
