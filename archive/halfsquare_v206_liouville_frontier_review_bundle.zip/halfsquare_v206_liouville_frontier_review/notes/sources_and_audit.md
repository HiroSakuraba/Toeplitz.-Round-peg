# Sources, scope, and verification

**Author:** Benjamin John Schulz  
**Date:** 23 September 2026

## Primary literature

Tomohiro Asano and Yuichi Ike, *Liouville regular Jordan curves*, arXiv:2609.11598v1, submitted 10 September 2026.

- Abstract and metadata: https://arxiv.org/abs/2609.11598
- Full original text read: https://arxiv.org/html/2609.11598v1
- Relevant locations: Definitions 1.2 and 1.5; Theorems 1.6 and 1.7; Remark 1.3; Theorem 4.1; Lemma 6.2 and Theorem 6.3; Section 6.2.

Tomohiro Asano and Yuichi Ike, *The rectifiable rectangular peg problem*, arXiv:2412.21057.

- https://arxiv.org/abs/2412.21057
- Its rectangle-existence theorem is restated as Theorem 1.1 in the September paper. This review uses that restatement and the prior project reference record; it does not claim to have re-audited the microlocal proof.

The September item is a recent preprint. Reading and using its statements is not an independent certification of every proof in it.

## Project sources actually inspected

- v203: boundary_insertion_energy_v203.md.
- v204: square_mode_selection_v204.md, conformal_stress_fourier_transform_v204.md, and screening_stress_localization_v204.md.
- v205: README.md, including its stated decoupling theorem and revised next target.
- v187: nonlocal_spiral_lattice_theorem.md, recovered from the complete v203 archive and retained here verbatim.

The latest recovered project bundle was v205. This v206 supplement is a response to the critique, not a claim that the v203–v205 files were absent or that the v204 formulas had not been qualified.

## Deductions checked in this review

1. The Möbius calibration has four equal-modulus preimages on one Abel contour, an exact physical square, and a nonzero first alternating source moment. This settles the coordinate issue with an exact example.
2. In the disk, logarithmic self-energy subtraction has limit \(-4\log2\) and logarithmic-radius derivative limit \(2\). The rational derivative formulas are checked without floating point.
3. Critical spiral subtraction removes the divergence only by changing the primitive's differential. No extension of the external existence theorem is asserted.
4. Unequal leading constants for the two specified exact critical arms produce infinitely many intersections, by the explicit parameter solution.
5. The interlaced-tail cancellation follows from a telescoping nonnegative integral. The proof remains valid when the separate integrals diverge.
6. The Abel criterion is the uniform Cauchy criterion rewritten by Stokes' theorem. The signs are checked against the positive orientation of an annular sector and an affine conformal calibration.
7. The global budget skeleton requires a fixed cost with summable recovery. Its final telescoping contradiction is elementary; event selection and the budget construction remain open.

The verifier uses exact fractions and integer pairs for complex numbers. Its output is in results/verify_v206_output.txt. It checks algebraic calibrations, not the continuum proofs. No interval arithmetic, floating-point certification, full historical test rerun, or solution of Toeplitz is claimed.
