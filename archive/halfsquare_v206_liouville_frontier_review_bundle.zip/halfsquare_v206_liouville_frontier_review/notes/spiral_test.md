# Testing logarithmic subtraction on the critical double spiral

**Author:** Benjamin John Schulz  
**Date:** 23 September 2026

## 1. The logarithmic divergence is real

For the critical arm

\[
\gamma(\theta)=K\theta^{-1/2}e^{i\theta},
\]

the symmetric area primitive satisfies

\[
\gamma^*\alpha=\frac{K^2}{2\theta}\,d\theta,\qquad
S(\theta)=\frac{K^2}{2}\log(\theta/\theta_0).
\]

Since \(|\gamma|=K/\sqrt\theta\), the singular part is
\(-K^2\log|\gamma|\). It tends to positive infinity as the arm reaches the origin.

Put \(G(w)=-K^2\log|w|\) on the punctured plane. Then \(S-G\circ\gamma\) is constant on this exact arm. However,

\[
d(S-G\circ\gamma)=\gamma^*(\alpha-dG),
\]

not \(\gamma^*\alpha\). The function \(G\) has no continuous extension to the origin. This is a singular change of the primitive, not a valid application of the original continuous-lift theorem.

A new renormalized existence theorem would have to show how the geometric square invariant survives this singular change and how the two arm limits are matched. Finite subtraction alone proves neither statement.

## 2. Unequal leading coefficients are not an arbitrary option

Consider two exact critical arms

\[
\gamma_1(u)=K_1u^{-1/2}e^{iu},
\qquad
\gamma_2(v)=K_2v^{-1/2}e^{i(v+\psi)}.
\]

Equality of arguments allows \(u=v+\psi+2\pi k\). Equality of radii then requires

\[
v=\frac{K_2^2(\psi+2\pi k)}{K_1^2-K_2^2},
\qquad
u=\frac{K_1^2}{K_2^2}v.
\tag{1}
\]

If \(K_1\ne K_2\), choose integers \(k\) tending to the appropriate positive or negative infinity. Both parameters tend to positive infinity, giving infinitely many intersections. Thus two such unequal-amplitude exact arms cannot be the disjoint arms of a Jordan double spiral.

This conclusion is restricted to the specified monotone power-law arms. It does not classify arbitrary winding arcs.

## 3. Interlacing already produces paired action cancellation

More generally, let \(r(\theta)>0\) decrease to zero, and suppose a second arm lies between neighboring turns:

\[
r(\theta+2\pi)\le \widetilde r(\theta)\le r(\theta).
\]

Traverse one inward and the other outward. Their paired tail action has absolute value at most

\[
\begin{aligned}
\frac12\int_T^\infty\bigl(r(\theta)^2-\widetilde r(\theta)^2\bigr)\,d\theta
&\le\frac12\int_T^\infty
\bigl(r(\theta)^2-r(\theta+2\pi)^2\bigr)\,d\theta\\
&=\frac12\int_T^{T+2\pi}r(\theta)^2\,d\theta\\
&\le\pi r(T)^2\longrightarrow0.
\end{aligned}
\tag{2}
\]

For a finite upper limit the telescoping integral has the additional subtracted tail over \([U,U+2\pi]\), which vanishes as \(U\to\infty\). This justifies the identity even when each arm's individual area integral diverges.

For \(r(\theta)=K/\sqrt\theta\), interlacing forces

\[
\sqrt{\frac{\theta}{\theta+2\pi}}
\le\frac{\widetilde r(\theta)}{r(\theta)}\le1.
\]

The two leading logarithmic coefficients therefore match. Matching singular coefficients and cancellation of paired tails are compatible with failure of continuity of the running primitive at the central point. They are not, on their own, an obstruction to square-free behavior.

## 4. The symmetric model is already square-rich in the project

The retained v187 note treats

\[
\Sigma_K=\{z\ne0:K^2/|z|^2-\arg z\in\pi\mathbb Z\}.
\]

Near the origin this is exactly the union of the critical arm and its half-turn rotation. The note constructs noncentered squares at every sufficiently small physical scale by matching three relative phases and then rotating to match the fourth.

I re-read that argument: its explicit three-variable Jacobian is nonsingular at the stated reference square, and the bounded lattice discrepancy is corrected by the inverse-function theorem. This remains an internal project proof, not an independent publication or a new result of this review.

Consequently, merely establishing a square for the symmetric \(K/\sqrt\theta\) test object would repeat an existing project result. The valuable extension would handle noncanonical winding packets or finite-coil accumulations without assuming the exact phase law.

## 5. Disk energy subtraction is a useful calibration, but a different object

For a square of circumradius \(A<1\) in the unit disk,

\[
q(A)=4\log\frac{1+A^4}{1-A^4}.
\]

Its renormalized value is

\[
q(A)+4\log(1-A)
=4\log\frac{1+A^4}{1+A+A^2+A^3}.
\]

It tends to \(-4\log2\), and its derivative with respect to \(\log A\) tends to \(2\). These are correct finite-part calculations.

The parameter-dependent charge energy here is not the running area primitive on a Jordan arc. A logarithm in each expression does not establish a theorem transferring a renormalization of one to the other.
