# v207 — Actual squares in the finite-coil model

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** A quantitative application of the existing phase method; the general Toeplitz conjecture remains open.

For an integer \(N\ge32768\), the single inward spiral arm
\[
\kappa(\theta)=R\left(\frac12-\frac{\theta}{8\pi N}\right)
 e^{i(\theta+\pi)},\qquad 0\le\theta\le2\pi N,
\]
contains a Euclidean square with side greater than \(R/8\).
All four vertices lie away from the arm's endpoints.
The result also tolerates continuous radial phase perturbations bounded by
\(N/131072\); no derivative bound on those perturbations is needed.

This applies to the explicit finite-coil construction in Asano–Ike §6.2
when endpoint smoothing preserves the central inward arm. With their
\(R_n=2^{-3n}\) and \(N_n=n2^{6n}\), every coil with \(n\ge3\) has such a
square. Thus this concrete non-Liouville-regular test construction is
already square-bearing. This does not cover every arc satisfying the
action inequalities in their abstract coil lemma.

## What this continuation adds

The underlying radial phase method was already present in v188.
Here it is specialized to a finite arm, with an explicit invertible
Jacobian, a quantified fixed-point argument, verification that the
vertices lie on the actual arm, and an application to the recent
nonregular example. No priority claim is made.

## Contents

- [Complete theorem and stability proof](notes/finite_coil_square_theorem.md).
- [Application and remaining geometric gap](notes/application_and_proof_map.md).
- [Audit and limits](notes/proof_audit.md).
- [Earlier v188 phase theorem](retained/phase_lattice_stability_theorem_v188.md), retained for historical context; the present proof is self-contained.
- [v206 contradiction skeleton](retained/contradiction_skeleton_v206.md) and [Abel criterion](retained/abel_action_criterion.md), locating the missing global implication.

Run Python 3 on code/verify_v207.py. It uses only the standard library
and exact rational arithmetic. Its recorded output is in
results/verify_v207_output.txt. These checks audit arithmetic;
they are not a formal verification of the analytic proof.

This is a small standalone continuation. It contains no nested archives,
duplicated old bundles, downloaded paper, or unrelated experiments.
