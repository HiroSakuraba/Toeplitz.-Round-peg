#!/usr/bin/env python3
"""Exact arithmetic audit of v207. Not a formal proof or root certificate."""
from fractions import Fraction as F
from itertools import permutations
from math import prod

checks = 0


def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def det(matrix):
    total = F(0)
    for p in permutations(range(len(matrix))):
        inversions = sum(p[i] > p[j] for i in range(len(p))
                         for j in range(i + 1, len(p)))
        total += (-1) ** inversions * prod(matrix[i][p[i]]
                                         for i in range(len(p)))
    return total


def multiply(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


x, y, s = F(3, 8), F(0), F(7, 64)
unit = [(1, 0), (0, 1), (-1, 0), (0, -1)]
vertices = [(x + s * a, y + s * b) for a, b in unit]
radii = [F(k, 64) for k in (31, 25, 17, 25)]
gradients = []
for j, ((vx, vy), r, (a, b)) in enumerate(zip(vertices, radii, unit)):
    check(f"radius {j}", vx * vx + vy * vy == r * r)
    check(f"reference annulus {j}", F(1, 4) < r < F(1, 2))
    gradients.append([vx / r, vy / r, (vx * a + vy * b) / r])

J = [[gradients[j][k] - gradients[0][k] for k in range(3)]
     for j in range(1, 4)]
expected = [[F(-1, 25), F(7, 25), F(-18, 25)],
            [F(0), F(0), F(-2)],
            [F(-1, 25), F(-7, 25), F(-18, 25)]]
check("derived Jacobian", J == expected)
check("Jacobian determinant", det(J) == F(28, 625))
inverse = [[F(-25, 2), F(9), F(-25, 2)],
           [F(25, 14), F(0), F(-25, 14)],
           [F(0), F(-1, 2), F(0)]]
identity = [[F(i == j) for j in range(3)] for i in range(3)]
check("left inverse", multiply(inverse, J) == identity)
check("right inverse", multiply(J, inverse) == identity)
norm = max(sum(abs(z) for z in row) for row in inverse)
check("inverse infinity norm", norm == 34)

# Independently evaluate the earlier general radial-Jacobian identity
# with h(q)=sqrt(q), hence h'(q_j)=1/(2*r_j).
a0, a1, a2, a3 = [1 / (2 * r) for r in radii]
general_det = 16 * s * (x*x + y*y - s*s) * (
    a0*a1*a2 - a0*a1*a3 + a0*a2*a3 - a1*a2*a3)
check("v188 identity specialization", general_det == det(J))

delta, N0 = F(1, 4096), 32768
margin = F(1, 64) - 3 * delta
check("radial margin value", margin == F(61, 4096))
for j, r in enumerate(radii):
    check(f"cube lower radius {j}", r - 3 * delta >= F(1, 4) + margin)
    check(f"cube upper radius {j}", r + 3 * delta <= F(1, 2) - margin)
    check(f"argument branch {j}", vertices[j][0] - 2 * delta > 0)
check("positive shape parameter", s - delta > 0)
check("side lower bound", 2 * (s - delta)**2 > F(1, 64))
check("circumradius value", s - delta == F(447, 4096))
check("endpoint angular margin", 8 * margin > F(1, 16))

# Analytic inputs 1/r <= 4 and coordinate-column lengths <= 1 yield:
hessian_relative = 2 * 4
remainder_coefficient = F(1, 2) * hessian_relative * 3**2
derivative_change_coefficient = hessian_relative * 3**2
arg_derivative_norm = 2 * 4 * 3
check("Taylor coefficient", remainder_coefficient == 36)
check("derivative change coefficient", derivative_change_coefficient == 72)
check("argument derivative norm", arg_derivative_norm == 24)
check("mapping quadratic coefficient", norm * remainder_coefficient == 1224)
check("contraction coefficient", norm * derivative_change_coefficient == 2448)
check("lattice rounding coefficient", F(norm, 8) == F(17, 4))
check("argument correction coefficient",
      F(norm * arg_derivative_norm, 24) == 34)


def bounds(N):
    mapping = 1224 * delta**2 + 34 * delta / N + F(17, 4*N)
    contraction = 2448 * delta + F(34, N)
    return mapping, contraction


mapping, contraction = bounds(N0)
check("exact mapping ratio", mapping / delta == F(13617, 16384))
check("mapping into cube", mapping < delta)
check("exact contraction", contraction == F(9809, 16384))
check("contraction below 3/5", contraction < F(3, 5))
check("shape correction coefficient", F(17, 4) / (1 - F(3, 5)) == F(85, 8))
error_extra = F(17, 6 * 131072)
check("continuous perturbation ratio",
      (mapping + error_extra) / delta == F(45203, 49152))
check("perturbed cube invariance", mapping + error_extra < delta)
check("phase error displacement coefficient", F(2 * norm, 24) == F(17, 6))

# Sampling larger integers does not prove monotonicity; the formulas
# are decreasing because their variable terms are positive constants / N.
for N in (32769, 65536, 786432, 10**9):
    bm, bc = bounds(N)
    check(f"bound consistency N={N}", bm <= mapping and bc <= contraction)

# Finite-arm identity: use t=theta/(2*pi*N), so r=1/2-t/4.
# Coefficients in units of pi: theta/pi=2*N*t,
# L*r/pi=8*N*r; their sum is the integer 4*N.
for t in (F(0), F(1, 32), F(1, 4), F(1, 2), F(31, 32), F(1)):
    r = F(1, 2) - t / 4
    check(f"finite parameter t={t}", F(1, 4) <= r <= F(1, 2))
    check(f"phase congruence t={t}", 2 * N0 * t + 8 * N0 * r == 4 * N0)
check("phase coefficient identity constant", 8 * F(1, 2) == 4)
check("phase coefficient identity linear", 2 - 8 * F(1, 4) == 0)

# Integral of (1/2-t/4)^2 dt over [0,1].
poly = [F(1, 4), F(-1, 4), F(1, 16)]
mean_r_squared = sum(c / (degree + 1) for degree, c in enumerate(poly))
check("arm action coefficient", mean_r_squared == F(7, 48))
check("N=2 coil below sufficient threshold", 2 * 2**12 < N0)
for n in range(3, 9):
    N, R = n * 2**(6*n), F(1, 2**(3*n))
    check(f"example threshold n={n}", N >= N0)
    check(f"example action growth n={n}", N * R**2 == n)
    check(f"example side expression n={n}", R / 8 == F(1, 2**(3*n+3)))
    check(f"turn counts increase n={n}", (n + 1) * 2**(6*(n+1)) > N)
check("n=3 side bound", F(1, 2**9) / 8 == F(1, 4096))

print("v207 exact rational arithmetic audit")
print(f"PASS: {checks} checks")
print("det(J) = 28/625; ||J^-1||_infinity = 34")
print("Mapping bound / delta = 13617/16384 < 1")
print("Contraction bound = 9809/16384 < 3/5")
print("Perturbed mapping bound / delta = 45203/49152 < 1")
print("Square side > R/8; endpoint radial margin >= 61R/4096")
print("Finite-coil model N_n=n*2^(6n) meets threshold for every n>=3")
print("Scope: arithmetic audit only; written proof supplies analytic reasoning.")
