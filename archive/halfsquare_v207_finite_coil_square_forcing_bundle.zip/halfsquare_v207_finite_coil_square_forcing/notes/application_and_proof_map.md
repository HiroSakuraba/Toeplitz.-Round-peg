# Finite coils and the remaining implication

## 1. The external test construction

Asano and Ike's [Liouville regular Jordan curves, arXiv:2609.11598v1](https://arxiv.org/html/2609.11598v1),
§6.2, Lemma 6.5 and Proposition 6.6, construct an arc with finite coils
at successively smaller scales. Each coil has large partial signed
action while its total action stays of order its containing disk's area.
The accumulating arc is differentiable at the accumulation point but
is not Liouville regular.

Their explicit inward arm is exactly equation (1) of the v207 theorem.
The return arm has radius smaller by \(R/(16N)\), traversed in the
opposite direction. Connectors join the arms and exterior endpoints;
corners are smoothed locally.

Our application uses this explicit construction with smoothing
confined near junctions, preserving the central inward arm.
The vertex parameter interval in v207 is a compact subinterval of
the arm's interior. For each fixed coil, smoothing neighborhoods
can be chosen disjoint from it. The vertices then lie directly on
the unmodified part of the curve.

## 2. Consequence for the accumulating example

The parameters in Proposition 6.6 are
\[
a_n=2^{-n},\qquad R_n=2^{-3n},\qquad N_n=n2^{6n}.
\]
For every \(n\ge3\), \(N_n\ge32768\). The explicit coil
centered at \((a_n,0)\) therefore contains a square of side
\[
>R_n/8=2^{-3n-3}.
\]
In particular the \(n=3\) coil supplies a square of side greater
than \(1/4096\). Fix this coil; no limit of shrinking squares is needed.
Every Jordan curve containing this unchanged coil arm consequently
has an inscribed square.

This conclusion is not derived solely from the two action
inequalities in the abstract statement of Lemma 6.5. Different
arcs satisfying those inequalities are not covered automatically.
Nor does it cover arbitrary smoothing or replacement of the spiral.

## 3. An action spike can coexist with actual squares

For the centered inward arm, put
\(\alpha=\tfrac12(x\,dy-y\,dx)\). Direct integration gives
\[
\int_\kappa\alpha
=\frac12\int_0^{2\pi N}r(\theta)^2\,d\theta
=\frac{7\pi}{48}NR^2.
\]
The paper uses \(\lambda=y\,dx=\tfrac12d(xy)-\alpha\).
Its endpoint term vanishes for this arm, so its integral has the
opposite sign. The return arm cancels the leading \(NR^2\) contribution
in the total coil, but the individual arm already supplies squares.

Nonregularity describes failure of a continuous primitive; it does
not obstruct four-point configurations. The explicit finite-coil
example joins the canonical critical spiral among nonregular test
geometries handled by the existing phase method.

## 4. Updated contradiction skeleton

The v206 route under a hypothetical square-free Jordan boundary is:

1. Squares exist on analytic interior approximations.
2. Their maximal side tends to zero, by compactness.
3. The boundary is not Liouville regular, by the external existence theorem.
4. The Abel primitives fail the uniform Cauchy condition.
5. Relative radial actions therefore have nonvanishing tail oscillation.
6. **Missing:** turn that oscillation into a square on the boundary.

The present theorem supplies step 6 under a concrete extra hypothesis:
the boundary contains a translated and rotated copy of the finite
radial-phase arm, or an allowed continuous radial perturbation.
It does not prove arbitrary radial-action packets have this form.

An action integral's sign and size do not supply the three independent
phase equations used here. Large winding alone likewise does not
provide quantitative radial geometry. Earlier v189 separates
nested-lobe topology from Euclidean radial coherence: an anisotropic
deformation can preserve topology while changing normalized radial
geometry by order one.

## 5. Next targets and their required conclusions

**Direct four-point degree on a packet.** Seek a configuration-space
degree for four boundary points, rather than extracting a spiral.
The square residual comprises two complex equations:
\[
z_0+z_2-z_1-z_3=0,\qquad
z_1-z_3-i(z_0-z_2)=0.
\]
Together they give a square of one orientation, provided \(z_0\ne z_2\).
A useful theorem must control the boundary of its four-parameter
configuration domain and exclude the full diagonal.
Signed action has not been shown to give either control.

**Coherent subpacket extraction.** To use the present method, prove
that some physical subarc has a radial phase law with a nondegenerate
square-shape Jacobian and sufficiently small uniform phase error.
The estimate must hold in physical Euclidean coordinates.
Homeomorphic straightening is insufficient: it generally changes
squares. A proposed extraction based only on topology or winding,
without a metric estimate, does not establish this hypothesis.

**An irreversible budget.** The sufficient inequality remains
\[
E_{m+1}\le E_m-\varepsilon+e_m,\quad E_m\ge0,\quad
\varepsilon>0,\quad\sum_m e_m<\infty.
\]
It must hold for one selected infinite sequence. An upper bound on
local energy change, or a separate bounded energy at each scale,
does not supply it.

The first target directly addresses the missing implication.
The second has a working theorem once its substantial geometric
hypothesis is established. None is presented as solved in v207.
