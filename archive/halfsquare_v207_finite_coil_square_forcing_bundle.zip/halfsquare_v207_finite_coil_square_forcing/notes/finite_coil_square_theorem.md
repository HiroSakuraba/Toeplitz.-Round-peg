# Quantitative squares on one finite spiral arm

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026

## 1. Statement

Let \(R>0\) and let \(N\ge32768\) be an integer. The embedded arc
\[
\kappa_{R,N}(\theta)
=R\left(\frac12-\frac{\theta}{8\pi N}\right)e^{i(\theta+\pi)},
\qquad 0\le\theta\le2\pi N,
\tag{1}
\]
contains the four vertices of a Euclidean square of side \(>R/8\).
Each vertex has a parameter in
\[
[\pi N/16,\ 2\pi N-\pi N/16].
\tag{2}
\]
Translations and rotations of this arc have the same property.

More generally, set \(L=8\pi N\), and let \(e:[1/4,1/2]\to\mathbb R\)
be continuous with
\[
\|e\|_\infty\le N/131072.
\tag{3}
\]
Then the arc
\[
\mathcal C_{R,N,e}
=\{Rr\exp(i(\pi-Lr-e(r))):1/4\le r\le1/2\}
\tag{4}
\]
contains a square of side \(>R/8\). All its vertices have normalized
radii at least \(61/4096\) away from both endpoints of the radial
interval. Radius is an injective parameter for (4), even when \(e\)
is only continuous. The conclusion therefore also holds for families
with \(\|e_N\|_\infty=o(N)\) for all sufficiently large integer \(N\).

This is a quantified specialization of the v188 radial phase method
to \(h(q)=\sqrt q\). The numerical threshold is sufficient, not sharp.

## 2. The phase equation describes exactly the finite arm

Work first with \(R=1\). For (1), the radius determines
\[
\theta=4\pi N-Lr.
\]
Because \(N\) is an integer, (1) has precisely the image
\[
\{re^{i\varphi}:1/4\le r\le1/2,\
Lr+\varphi\equiv\pi\pmod{2\pi}\}.
\tag{5}
\]
Every point in this set belongs to the finite arm: substituting its
radius into the displayed formula gives a parameter in \([0,2\pi N]\)
and the correct angle. This checks membership in the finite arm,
rather than merely in an infinite extension.

For (4), the corresponding equation is
\[
Lr+\varphi+e(r)\equiv\pi\pmod{2\pi}.
\tag{6}
\]

## 3. A nondegenerate square shape

Write candidate vertices as
\[
w_j=x+iy+s i^j,\quad j=0,1,2,3,\qquad u=(x,y,s).
\]
They form a square whenever \(s>0\), with side \(\sqrt2s\).
Take
\[
u_*=(3/8,0,7/64).
\]
Its radii \(r_j=|w_j|\) are
\[
(r_0,r_1,r_2,r_3)=(31,25,17,25)/64.
\]
Define \(G(u)=(r_1-r_0,r_2-r_0,r_3-r_0)\).
Direct differentiation at \(u_*\) gives
\[
J=DG(u_*)=
\begin{pmatrix}
-1/25&7/25&-18/25\\
0&0&-2\\
-1/25&-7/25&-18/25
\end{pmatrix},\qquad \det J=28/625.
\tag{7}
\]
For a vector \((a,b,c)\),
\[
J^{-1}(a,b,c)=
\left(-\frac{25}{2}(a+c)+9b,\ \frac{25}{14}(a-c),\ -\frac b2\right).
\tag{8}
\]
The induced infinity norm is \(\|J^{-1}\|_\infty=34\).

Set \(\delta=1/4096\) and
\[
K=\{u:\|u-u_*\|_\infty\le\delta\}.
\]
Each vertex moves by at most \(3\delta\) on this cube. Every radius
therefore remains strictly between \(1/4\) and \(1/2\), every vertex
has positive real part, and \(s>0\). Every radius is at least
\[
1/64-3\delta=61/4096
\tag{9}
\]
away from either endpoint of the radial interval.

Use the continuous argument branch in the right half plane and put
\[
A(u)=(\arg w_1-\arg w_0,\arg w_2-\arg w_0,\arg w_3-\arg w_0).
\]
The relative phase map is \(D_L=LG+A\).

## 4. Uniform estimates on the cube

The coordinate derivatives of each \(w_j\) have Euclidean norm one.
The Euclidean Hessian of \(|w|\) has operator norm \(1/|w|\), so
every coordinate Hessian entry of \(r_j\) has magnitude at most \(4\)
on \(K\). Every Hessian entry of each component of \(G\) is thus
bounded by \(8\).

For \(Q(u)=G(u)-G(u_*)-J(u-u_*)\), Taylor's theorem gives
\[
\|Q(u)\|_\infty\le36\|u-u_*\|_\infty^2,\qquad
\|DQ(u)\|_\infty\le72\delta.
\tag{10}
\]
Indeed, a scalar remainder is at most
\(\frac12\cdot8(\sum_{\ell=1}^3|u_\ell-u_{*,\ell}|)^2\);
each derivative entry changes by at most \(24\delta\).
All line segments used here lie in the convex cube.

The Euclidean gradient of \(\arg w\) has norm \(1/|w|\).
Each coordinate derivative of an argument difference is therefore
bounded by \(8\). Hence
\[
\|DA(u)\|_\infty\le24,\qquad
\|A(u)-A(u_*)\|_\infty\le24\delta.
\tag{11}
\]

## 5. Hitting the three relative phases

Round each component of \(D_L(u_*)/(2\pi)\) to a nearest integer,
obtaining \(k\in\mathbb Z^3\). Then
\[
b=2\pi k-D_L(u_*),\qquad \|b\|_\infty\le\pi.
\]
Consider
\[
T(u)=u_*+J^{-1}\left[
\frac bL-\frac{A(u)-A(u_*)}{L}-Q(u)\right].
\tag{12}
\]
A fixed point is exactly a solution of \(D_L(u)=2\pi k\).
Since \(L=8\pi N>24N\), estimates (8)–(11) give
\[
\|T(u)-u_*\|_\infty
\le B_N:=1224\delta^2+\frac{34\delta}{N}+\frac{17}{4N}.
\tag{13}
\]
At \(N_0=32768\),
\[
B_{N_0}/\delta=13617/16384<1.
\tag{14}
\]
Also
\[
\operatorname{Lip}_K(T)
\le2448\delta+\frac{34}{N}
\le9809/16384<3/5.
\tag{15}
\]
These bounds improve as \(N\) increases. Thus \(T\) is a contraction
of the closed cube into itself and has a fixed point in \(K\).
For this rounded target \(k\), that fixed point is unique in \(K\);
this does not assert uniqueness among all inscribed squares.
The contraction estimate also gives
\[
\|u-u_*\|_\infty\le
\frac{\|T(u_*)-u_*\|_\infty}{1-3/5}
\le\frac{85}{8N}.
\tag{16}
\]

## 6. Recovering the fourth phase and the actual square

At the fixed point the four numbers \(Lr_j+\arg w_j\) agree modulo
\(2\pi\). Choose
\[
\beta\equiv\pi-Lr_0-\arg w_0\pmod{2\pi}.
\]
The points \(e^{i\beta}w_j\) then all satisfy (5).
Rotation preserves radii, square equations, and relative arguments
modulo \(2\pi\). Section 2 places every point on the actual finite arm.

Moreover
\[
s\ge7/64-\delta=447/4096,\qquad
2(447/4096)^2>1/64.
\]
The side thus exceeds \(1/8\).
By (9), the parameter distance from either endpoint is at least
\[
L(61/4096)=61\pi N/512>\pi N/16,
\]
proving (2). Rescaling proves the assertion for arbitrary \(R\).

## 7. Continuous radial phase errors

Let \(E=\|e\|_\infty\) and
\[
\Delta e(u)=(e(r_1)-e(r_0),e(r_2)-e(r_0),e(r_3)-e(r_0)).
\]
Use the same \(k,b\) as above and define the continuous map
\[
T_e(u)=T(u)-J^{-1}\Delta e(u)/L.
\tag{17}
\]
Its fixed points solve
\(LG(u)+A(u)+\Delta e(u)=2\pi k\).
The additional displacement is at most
\[
68E/L\le17E/(6N).
\]
Under (3), the total bound at the worst value \(N=N_0\) satisfies
\[
\frac{B_{N_0}+17/(6\cdot131072)}{\delta}
=45203/49152<1.
\tag{18}
\]
Thus \(T_e\) maps \(K\) into itself. Brouwer's fixed-point theorem
supplies a solution; no differentiability of \(e\), nor uniqueness,
is asserted.

Choose
\[
\beta\equiv\pi-Lr_0-\arg w_0-e(r_0)\pmod{2\pi}.
\]
The error is radial, hence unchanged by rotation. All four rotated
vertices satisfy (6). The same radius and side bounds apply.
This proves the perturbed theorem.

An angle-dependent error would change under the final rotation.
The present three-dimensional proof makes no such extension.
A separate four-dimensional argument would be required.
