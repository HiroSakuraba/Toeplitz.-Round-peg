# v207 audit and provenance

The self-contained proof uses elementary differentiation, the contraction
mapping theorem, and Brouwer's fixed-point theorem. It proves existence
on a specific finite spiral arc and the stated radial phase perturbations.
It does not prove the full Toeplitz conjecture.

The method is inherited from v188. This continuation adds a quantitative
specialization, actual-arm membership, and the finite-coil application.
No priority claim or independent external review is asserted.

## Critical checks

| Issue | Resolution |
|---|---|
| Three relative phases versus four points | A common physical rotation fixes the remaining phase. |
| Rotation changes the phase error | The permitted error is radial and unchanged by rotation. |
| Infinite spiral versus finite arm | Radius determines a parameter in the finite interval; congruence is sufficient. |
| Degenerate square | The circumradius parameter is at least \(447/4096\) before rescaling. |
| Endpoint smoothing | Every radius stays at least \(61/4096\) from the radial endpoints. |
| Nondifferentiable perturbation | Brouwer replaces contraction; only continuity is used. |
| Exact arithmetic versus analytic proof | The verifier checks arithmetic; the written proof supplies analytic estimates and fixed-point reasoning. |
| General nonregular curves | No inference from nonregularity alone to radial geometry is made. |
| Historical theorem scope | The broad classification and angle-dependent extension in retained v188 are not needed for this proof. |

The exact verifier derives radius gradients from the reference vertices,
reconstructs the Jacobian, checks its inverse and determinant, checks
the v188 determinant identity at this shape, and verifies rational
bounds. It checks the polynomial integral for the inward arm and
the parameter substitution for finite-arm membership.
It does not approximate a root or claim interval certification.

## Sources read

1. Asano and Ike, *Liouville regular Jordan curves*,
   [arXiv:2609.11598v1](https://arxiv.org/html/2609.11598v1),
   §6.2, particularly Lemma 6.5 and Proposition 6.6.
   The full local HTML extraction was inspected, not only the abstract.
   The paper is referenced rather than copied into this supplement.
2. v188, *Phase-lattice stability beyond the cubic scale*, from the
   recovered v203 historical archive. Retained verbatim.
3. v206, *Liouville frontier review*, especially the contradiction
   skeleton and Abel criterion. Those two notes are retained.
4. v189, nested-lobe lamination note, consulted as a warning against
   assuming topology supplies radial coherence; not needed for the proof.

Input and retained-file hashes are recorded in provenance.json.
SHA256SUMS.txt covers every other member of this continuation.
The compact package omits old nested bundles and the downloaded
external paper. Those omissions do not delete the originals.
