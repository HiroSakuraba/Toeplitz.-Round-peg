# Relative radial action: an exact Abel criterion

**Author:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** a direct deduction from Stokes' theorem. No novelty claim.

Let \(f:\mathbb D\to\Omega\) be a conformal map onto a bounded Jordan domain. Use the symmetric area form
\(\alpha=\tfrac12(x\,dy-y\,dx)\), for which \(d\alpha=dx\wedge dy\).

For \(0<r<s<1\), define

\[
F_r(\theta)=\int_{f(r e^{iu}),\,0\le u\le\theta}\alpha,
\qquad
J_{r,s}(\theta)=\int_{f(u e^{i\theta}),\,r\le u\le s}\alpha.
\]

The integrals are classical because \(r,s<1\). Write \(A_{r,s}(\theta)\) for the nonnegative area of the image of the annular sector \(r<|z|<s,\ 0<\arg z<\theta\), for \(0\le\theta\le2\pi\).

The positively oriented sector boundary consists of the outer arc, the reversed radial side at \(\theta\), the reversed inner arc, and the radial side at zero. Therefore

\[
\boxed{F_s(\theta)-F_r(\theta)
=A_{r,s}(\theta)+J_{r,s}(\theta)-J_{r,s}(0).}
\tag{1}
\]

Set

\[
\epsilon(r)=\operatorname{Area}(\Omega\setminus f(r\mathbb D))\longrightarrow0.
\]

For each \(r<s\),

\[
\left|\|F_s-F_r\|_\infty
-\|J_{r,s}(\cdot)-J_{r,s}(0)\|_\infty\right|
\le\epsilon(r).
\tag{2}
\]

This follows from (1), the triangle inequality, and \(0\le A_{r,s}\le\epsilon(r)\).

### Proposition

The Abel primitives \(F_r\) converge uniformly on one angular period as \(r\uparrow1\) if and only if

\[
\boxed{\lim_{r\uparrow1}\sup_{r<s<1}\sup_{0\le\theta\le2\pi}
|J_{r,s}(\theta)-J_{r,s}(0)|=0.}
\tag{3}
\]

**Proof.** Equation (2) identifies the two uniform Cauchy conditions up to a vanishing error. The limit of continuous \(F_r\) is continuous. Uniform continuity of \(f\) gives convergence of the curves themselves. The relation \(y\,dx=\tfrac12d(xy)-\alpha\) converts these primitives to the Liouville convention. The increment over one full period also converges, so convergence extends locally uniformly to the universal angular cover. ∎

This characterizes convergence for the Abel approximations. It is not asserted to characterize every possible Liouville-regular approximation of a curve.

The radial-tail length condition bounds each \(J\) in absolute value and hence implies (3). Condition (3) only asks that their direction-dependent differences vanish. It permits cancellation that a length estimate discards. We have not supplied a new geometric class satisfying (3) but excluded by all existing criteria.

Most usefully, if a curve is not Liouville regular, (3) must fail. There are then arbitrarily thin source annuli with a nonvanishing relative radial action. A proof that such failure forces a square would finish the contradiction skeleton. That square-forcing assertion is still unproved.
