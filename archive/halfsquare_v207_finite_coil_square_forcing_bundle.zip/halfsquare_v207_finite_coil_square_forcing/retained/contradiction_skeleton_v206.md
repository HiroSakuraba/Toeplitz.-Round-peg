# A global contradiction with every missing implication exposed

**Author:** Benjamin John Schulz  
**Date:** 23 September 2026

This is the intended proof architecture, not a completed proof.

## Fixed setup

Let \(\Gamma=\partial\Omega\) be a bounded Jordan curve, and let \(f:\mathbb D\to\Omega\) extend homeomorphically to the closures. Let \(\Gamma_r=f(rS^1)\).

Assume for contradiction that \(\Gamma\) has no nondegenerate square. Allow every physical vertex ordering; do not restrict the target to graceful squares.

| Step | Required statement | Status and direction |
|---|---|---|
| A | Every \(\Gamma_r\), \(r<1\), has a square. | Known smooth-curve result. |
| B | The largest side \(L(r)\) of a square on \(\Gamma_r\) tends to zero under the square-free assumption. | Proved by compactness below. |
| C | \(\Gamma\) is not Liouville regular. | Contrapositive of the external rectangle theorem. |
| D | Abel primitives fail to be uniformly Cauchy; therefore relative radial actions have nonvanishing tail oscillation. | Proved from C and the exact sector identity below. |
| E | That oscillation forces an actual square on \(\Gamma\), or forces a selected collapse family with an irreversible event budget. | **Unproved. This is the main missing implication.** |
| F | In the budget route, infinitely many forced events exhaust a finite nonnegative budget. | Elementary once the hypotheses below are established. |

### Proof of B

If not, take \(r_n\uparrow1\) and squares with sides at least \(\delta>0\). Their four preimages lie on \(r_nS^1\), so a subsequence of the four arguments converges. Uniform continuity of \(f\) on the closed disk implies convergence of the physical vertices to four points of \(\Gamma\). The square equations persist, and the side lower bound keeps the four vertices distinct. This contradicts square-freeness.

The maximum \(L(r)\) exists by using the compact parameter space of four points and including degenerate configurations; existence of a nondegenerate square makes the maximum positive.

### The budget inequality that would actually work

One sufficient form is to construct a selected sequence of genuine events with energies \(E_n\), and prove

\[
E_n\ge0,\qquad E_0<\infty,
\]
\[
E_{n+1}\le E_n-\varepsilon+e_n,\qquad
\varepsilon>0,\qquad\sum_{n=0}^{\infty}e_n<\infty.
\]

Then

\[
0\le E_N\le E_0-N\varepsilon+\sum_{n<N}e_n,
\]

an impossibility for large \(N\).

Each component must be established for the same selected sequence. The event selection must produce infinitely many events. Relabeling and changes of normalization must preserve the inequality or contribute a summable error. A different bounded energy for each event is not sufficient.

Equivalently, in the differentiable transport framework, one would need a finite upper bound on positive transport work and a fixed lower bound on the dissipation assigned to each disjoint event interval. Neither property has been proved for the selected Toeplitz configurations.

### A more direct target

Use the [relative radial-action criterion](abel_action_criterion.md). Square-freeness would imply a number \(\eta>0\), radii \(r_n<s_n\uparrow1\), and directions \(\theta_n\) for which

\[
|J_{r_n,s_n}(\theta_n)-J_{r_n,s_n}(0)|\ge\eta.
\]

The missing geometric lemma would turn these actual conformal radial-action packets into a square on \(\Gamma\). Merely identifying a canonical spiral, a chordal square, or a large winding count does not prove that lemma.

The canonical critical double spiral is already handled by the retained v187 argument. The finite-coil examples and noncanonical packets are therefore essential adversarial cases for any claimed transfer theorem.

## Research decision

Do not improve the cleared-disk response constant as the main route toward the contradiction. Work on E: either actual square production from primitive failure, or a recoverable-to-irreversible conversion of the selected configuration energy with the stated inequality direction.
