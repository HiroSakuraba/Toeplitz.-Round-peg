# v188 — Phase-lattice stability beyond the cubic scale

## 1. Purpose

v187 proved that the canonical critical double spiral
\[
\Sigma_a=\{z\ne0:a^2/|z|^2-\arg z\in\pi\mathbb Z\}
\]
contains exact noncentered squares at every sufficiently small scale.  The proposed next dichotomy was that `o(r^3)` perturbations should preserve those squares, whereas `O(r^3)` perturbations might form a new roughness obstruction.

That threshold is too pessimistic.  The relevant large parameter is the phase amplification
\[
L\asymp r^{-2}.
\]
The degree argument survives every **subleading phase perturbation** `E_L=o(L)`.  For the critical radial law this corresponds, under a coherent radial phase parametrization, to positional errors `o(r)`, not merely `o(r^3)`.

The same calculation also reveals the full leading-order exceptional family for a general radial phase law: the only laws whose three-dimensional square-shape phase map is everywhere rank deficient are affine and logarithmic laws in squared radius.

---

## 2. Square coordinates

Write a normalized square as
\[
 w_0=c+s,\qquad
 w_1=c+is,\qquad
 w_2=c-s,\qquad
 w_3=c-is,
 \qquad c=x+iy,
\]
and put
\[
q_j=|w_j|^2.
\]
Explicitly,
\[
\begin{aligned}
q_0&=(x+s)^2+y^2,\\
q_1&=x^2+(y+s)^2,\\
q_2&=(x-s)^2+y^2,\\
q_3&=x^2+(y-s)^2.
\end{aligned}
\]
They obey
\[
q_0+q_2=q_1+q_3=2(x^2+y^2+s^2).
\]

For a radial leading phase `h(q)`, define the three relative radial phases
\[
G_h(x,y,s)=
\begin{pmatrix}
h(q_1)-h(q_0)\\
h(q_2)-h(q_0)\\
h(q_3)-h(q_0)
\end{pmatrix}.
\]

---

## 3. Exact radial-shape Jacobian

Let
\[
a_j=h'(q_j).
\]
Direct differentiation gives
\[
\boxed{
\det DG_h
=16s(x^2+y^2-s^2)
\left(
 a_0a_1a_2-a_0a_1a_3+a_0a_2a_3-a_1a_2a_3
\right).
}
\]
If no `a_j` vanishes, this is equivalently
\[
\boxed{
\det DG_h
=16s(x^2+y^2-s^2)
\prod_{j=0}^3 a_j
\left(
\frac1{a_3}-\frac1{a_2}+\frac1{a_1}-\frac1{a_0}
\right).
}
\]

For the critical law `h(q)=1/q`, `a_j=-q_j^{-2}`.  The identity reduces exactly to the v187 factorization
\[
\det DG_h=
\frac{-128s^3(x-y)(x+y)(s^2-x^2-y^2)}
{q_0^2q_1^2q_2^2q_3^2}.
\]
Thus v187 is one member of a much larger radial phase family.

---

## 4. Classification of the radial leading-rank exceptions

Assume `h\in C^3(J)` and `h'` is nowhere zero on an interval `J`.  Put
\[
R(q)=\frac1{h'(q)}.
\]
Suppose the reciprocal-slope factor
\[
R(q_3)-R(q_2)+R(q_1)-R(q_0)
\]
vanishes for every generic square with all `q_j\in J`.

Take `y=0`.  Then
\[
q_1=q_3=m=x^2+s^2,
\qquad
q_0=m+a,
\qquad
q_2=m-a,
\qquad a=2sx.
\]
Away from the harmless geometric locus `x^2=s^2`, rank degeneracy implies
\[
R(m+a)+R(m-a)=2R(m).
\]
For every interior `m`, arbitrarily small `a` are realizable by taking `x` small and `s\approx\sqrt m`.  Dividing by `a^2` and sending `a\to0` gives
\[
R''(m)=0.
\]
Hence
\[
R(q)=\alpha+\beta q.
\]
Therefore the only radial leading laws with identically degenerate square-shape phase map are
\[
\boxed{
h(q)=Aq+B
}
\]
when `\beta=0`, and
\[
\boxed{
h(q)=A\log|\alpha+\beta q|+B
}
\]
when `\beta\ne0`, on any interval where the logarithm is defined.

This is the same reciprocal-derivative mechanism that produced the affine/shifted-log exceptional family much earlier in the program, now appearing in the squared-radius phase coordinate.

**Important:** this is a classification of failure of the *leading three-dimensional radial rank*.  It does not prove that the affine/logarithmic layer sets themselves are square-free.  Lower-order angular terms may still restore the missing direction.

---

## 5. Subleading phase stability theorem

Let `h\in C^2(J)`.  Fix a generic normalized square `u_*=(x_*,y_*,s_*)` such that all four `q_j(u_*)` lie in a compact subinterval of `J` and
\[
\det DG_h(u_*)\ne0.
\]

For `L\to\infty`, consider a coherent phase-lattice packet on the universal cover of an annulus,
\[
\Phi_L(re^{i\vartheta})
=Lh(r^2)-\vartheta+e_L(r,\vartheta),
\]
where `e_L` is continuous, `2\pi`-periodic in `\vartheta`, and
\[
E_L:=\|e_L\|_\infty=o(L).
\]
Define
\[
\Sigma_L=\{z:\Phi_L(z)\in\pi\mathbb Z\}.
\]

### Theorem
For all sufficiently large `L`, `\Sigma_L` contains an exact Euclidean square whose normalized shape tends to `u_*`.

More quantitatively, its shape correction satisfies
\[
\boxed{
|u_L-u_*|=O\!\left(\frac{E_L+1}{L}\right).
}
\]
No derivative bound on `e_L` is required.

### Proof
For `u=(x,y,s)` and common rotation `\theta`, set
\[
z_j=e^{i\theta}w_j(u).
\]
Use relative/common phase coordinates
\[
\mathcal R_L(u,\theta)=
\begin{pmatrix}
\Phi_L(z_1)-\Phi_L(z_0)\\
\Phi_L(z_2)-\Phi_L(z_0)\\
\Phi_L(z_3)-\Phi_L(z_0)
\end{pmatrix},
\qquad
\mathcal C_L(u,\theta)=\Phi_L(z_0).
\]
Then
\[
\mathcal R_L=L G_h(u)-A(u)+\Delta e_L(u,\theta),
\]
where `A` is the vector of argument differences and
\[
|\Delta e_L|\le 2E_L
\]
componentwise.

Choose `(k_L,m_L)\in\mathbb Z^3\times\mathbb Z` so that at `(u_*,0)` the four residuals from `(\pi k_L,\pi m_L)` are each at most `\pi/2`.

Put
\[
v=L(u-u_*).
\]
On the shape boundary
\[
|v|=K(E_L+1),
\]
Taylor expansion gives
\[
L(G_h(u)-G_h(u_*))=DG_h(u_*)v+o(E_L+1),
\]
uniformly because `E_L=o(L)`.  Since `DG_h(u_*)` is invertible, choose `K` large enough that this term dominates the at-most `O(E_L+1)` contribution of the lattice residual, the argument term, and `\Delta e_L`.  Thus the relative three-vector cannot vanish on the shape boundary.

For the common phase,
\[
\mathcal C_L(u,\theta)-\mathcal C_L(u_*,0)
=L[h(q_0(u))-h(q_0(u_*))]
-[\arg w_0(u)-\arg w_0(u_*)]
-\theta
+[e_L(z_0)-e_L(w_0(u_*))].
\]
The shape term is `O(E_L+1)` on the preceding shape cylinder and the error term is at most `2E_L`.  Hence, after choosing `T` large enough, the common residual has opposite signs on
\[
\theta=\pm T(E_L+1).
\]

The map
\[
(\mathcal R_L-\pi k_L,\mathcal C_L-\pi m_L)
\]
therefore has no zero on the boundary of the resulting four-dimensional cylinder.  Homotoping the bounded error and Taylor remainder to zero leaves the affine model
\[
(v,\theta)\mapsto
\bigl(DG_h(u_*)v,\ \ell\cdot v-\theta\bigr),
\]
whose determinant is `-\det DG_h(u_*)\ne0`.  Its Brouwer degree is nonzero.  The original map has the same degree and hence has a zero.

At that zero all four phases lie in `\pi\mathbb Z`, so all four square vertices lie on `\Sigma_L`.  The shape-cylinder radius gives the stated correction estimate.  `\square`

---

## 6. Consequence for the critical double spiral

Take
\[
h(q)=\frac1q,
\qquad
L=\frac{a^2}{\rho^2}.
\]
The v187 Jacobian is nonzero at any generic off-center reference shape.  Therefore any coherent packet of the form
\[
\Phi_\rho(z)
=\frac{a^2}{|z|^2}-\arg z+e_\rho(z),
\qquad
\|e_\rho\|_\infty=o(\rho^{-2}),
\]
contains an exact square at sufficiently small scale.

If an indexed radial lamination is relatively `o(1)`-close to the critical spiral law on a fixed normalized annulus, the induced phase error is `o(L)`.  In physical coordinates this corresponds to radial positional error
\[
\boxed{o(\rho),}
\]
not merely `o(\rho^3)`.

Thus the v187 proposed stability threshold was too narrow by two powers of the packet scale.

---

## 7. Cubic corrugation is not an escape

Consider, for integer `L`,
\[
\Phi_L(r,\vartheta)
=\frac{L}{r^2}-\vartheta
+\varepsilon\sin(L\vartheta),
\qquad 0<\varepsilon<1.
\]
The phase error is uniformly bounded:
\[
E_L\le\varepsilon=o(L),
\]
even though it oscillates `O(L)` times per revolution.

Solving one phase level for its radius shows that relative to the unperturbed level,
\[
\delta r=O(L^{-1})
\]
in normalized coordinates.  Under the critical physical scaling `\rho\asymp L^{-1/2}`, this becomes
\[
\boxed{
\delta r_{\rm phys}=O(\rho^3).
}
\]
So one may corrugate every layer at exactly the v185 cubic gap scale, with angular frequency `\rho^{-2}`, without leaving the v188 square-forcing class.

This also shows why `O(r^3)` phase incoherence is not automatically a new quadratic-variation budget.  `N\asymp r^{-2}` oscillations of amplitude `r^3` contribute only order
\[
N(r^3)^2\asymp r^4
\]
to a naive squared transverse-increment sum.

The correct obstruction is therefore not *cubic motion itself*.  It is loss of a coherent subleading phase coordinate, or entry into a leading-rank exceptional law.

---

## 8. Revised terminal alternatives

Combining v184--v188, a hypothetical square-free concentration packet can no longer converge to the critical double spiral plus any subleading coherent phase perturbation.

The surviving possibilities are now:

1. **leading-order phase disorder:** there is no coherent scalar phase coordinate of the form `Lh(r^2)-theta+o(L)` on the winding packet;
2. **radial exceptional law:** the leading coherent radial phase has `1/h'` affine, hence `h` is affine or logarithmic in squared radius;
3. **nonradial leading phase:** angular dependence enters at the same order as the `L`-scale radial phase and the radial reduction no longer applies;
4. **topological lamination failure:** repeated ray crossings cannot be organized into a coherent annular level stack because of branch births, backtracking, or singular accumulation.

This is substantially narrower than the v187 `o(r^3)` / `O(r^3)` split.

---

## 9. Recommended v189 target

The highest-value next question is topological rather than metric:

> From the v185 two-sided threading packet with `N\asymp r^{-2}` alternating ray crossings, can one extract a large coherent annular sublamination carrying a scalar phase coordinate?

If yes, v188 kills every nonexceptional radial leading law.  If no, the failure of annular organization itself becomes the terminal object and should be expressed as a braid/branching current rather than another scalar roughness estimate.

In parallel, the affine/logarithmic radial exceptions should be tested directly: leading rank degeneracy does not yet imply square avoidance, and lower-order angular terms may close them as well.
