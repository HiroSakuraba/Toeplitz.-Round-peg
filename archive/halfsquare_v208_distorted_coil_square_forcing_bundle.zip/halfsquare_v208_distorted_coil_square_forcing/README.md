# v208 — Squares in distorted finite coils

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** Proved conditional geometric results; the general Toeplitz problem remains open.

This continuation applies the general four-phase principle already banked
in v190 to finite coils whose circular geometry has been distorted.

For every fixed invertible real linear map \(T\), a sufficiently long
coil \(T\kappa_{R,N}\) contains an actual Euclidean square. The threshold
depends on \(T\). Here
\[
\kappa_{R,N}(\theta)=R(1/2-\theta/(8\pi N))e^{i(\theta+\pi)},
\quad 0\le\theta\le2\pi N.
\]
This assertion concerns squares on the distorted arm itself.

There is also an explicit example: for \(T(x,y)=(x/3,y/4)\),
every integer \(N\ge1024\) forces a square of side \(>R/8\).
The proof survives continuous position-dependent phase errors of size
\(\le N/2048\), with no derivative bound.

A further theorem treats accumulating coils under a fixed continuously
differentiable diffeomorphism whose derivative at the accumulation point
has unequal singular values. All sufficiently small, sufficiently
many-turn coils in that image contain squares of side comparable to
their original radii.

## Why this matters

An elliptic distortion had illustrated why nested topology does not
supply circular radial geometry. This particular loss of circularity
does not prevent square forcing: unequal stretching supplies a fourth
independent phase direction. The actual square is found afresh after
the distortion.

The missing global implication remains substantial. An arbitrary
signed-area packet need not admit a fixed differentiable deformation
model, or any controlled limiting phase function.

## Contents

- [General principle and affine-coil theorem](notes/affine_coil_theorem.md).
- [Explicit 1,024-turn theorem](notes/quantitative_elliptic_theorem.md).
- [Smooth deformation theorem and research implications](notes/smooth_deformations_and_gap.md).
- [Plain-language account and audit](notes/work_explained_and_audit.md).
- [Retained v207 proof](retained/finite_coil_square_theorem_v207.md), used for the similarity case.

Run Python 3 on code/verify_v208.py. The standard-library verifier checks
an exact polynomial determinant identity and all stated rational bounds.
The written proofs provide the analytic reasoning; the verifier is not
a formal proof assistant. Recorded output is in results/verify_v208_output.txt.

No new general phase theorem or priority claim is asserted. The contribution
is the finite-arm application, determinant evaluation, explicit constants,
and deformation consequence. This package contains no nested archives.
