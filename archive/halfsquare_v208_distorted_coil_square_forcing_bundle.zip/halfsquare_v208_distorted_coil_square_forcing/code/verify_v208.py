#!/usr/bin/env python3
"""Exact algebra/constant audit. Does not formally verify analytic proofs."""
from fractions import Fraction as F
from itertools import permutations
from math import prod

checks = 0


def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def sign(p):
    return (-1)**sum(p[i] > p[j] for i in range(len(p))
                     for j in range(i+1, len(p)))


def det(m):
    return sum(sign(p) * prod(m[i][p[i]] for i in range(len(m)))
               for p in permutations(range(len(m))))


def multiply(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


# Sparse exact polynomials in a,b. These establish an identity, not
# a finite set of numerical examples.
def add_poly(p, q):
    out = dict(p)
    for k, v in q.items():
        out[k] = out.get(k, F(0)) + v
    return {k: v for k, v in out.items() if v}


def scale_poly(p, s):
    return {k: v*s for k, v in p.items() if v*s}


def mul_poly(p, q):
    out = {}
    for (i, j), v in p.items():
        for (k, l), w in q.items():
            key = (i+k, j+l)
            out[key] = out.get(key, F(0)) + v*w
    return {k: v for k, v in out.items() if v}


def det_poly(m):
    out = {}
    for p in permutations(range(len(m))):
        term = {(0, 0): F(sign(p))}
        for i in range(len(m)):
            term = mul_poly(term, m[i][p[i]])
        out = add_poly(out, term)
    return out


a, b = {(1, 0): F(1)}, {(0, 1): F(1)}
na, nb = scale_poly(a, -1), scale_poly(b, -1)
S = [[a, b, a, b], [na, b, b, a],
     [na, nb, a, b], [a, nb, b, a]]
symbolic_determinant = det_poly(S)
check("polynomial determinant identity",
      symbolic_determinant == {(3, 1): F(8), (1, 3): F(-8)})
row_change = [[1, 0, -1, 0], [0, 1, 0, -1],
              [1, 0, 1, 0], [0, 1, 0, 1]]
check("row operation determinant", det(row_change) == 4)
# The analytic factors are (1/sqrt(a+b))^4 for the norm phase
# and (2*h*phi')^4 for phi(a*x^2+b*y^2).
check("quadratic phase prefactor", 8 * 2**4 == 128)

h = F(3, 40)
vertices = [(h, h), (-h, h), (-h, -h), (h, -h)]
columns = [
    [(1, 0), (0, 1), (1, 0), (0, 1)],
    [(1, 0), (0, 1), (0, 1), (-1, 0)],
    [(1, 0), (0, 1), (-1, 0), (0, -1)],
    [(1, 0), (0, 1), (0, -1), (1, 0)],
]
r = F(3, 8)
J = []
for j, ((vx, vy), cols) in enumerate(zip(vertices, columns)):
    check(f"reference radius {j}", 9*vx*vx + 16*vy*vy == r*r)
    for k, (cx, cy) in enumerate(cols):
        check(f"unit coordinate column {j},{k}", cx*cx+cy*cy == 1)
    J.append([(9*vx*cx+16*vy*cy)/r for cx, cy in cols])
expected = [[F(t, 5) for t in row] for row in
            [[9, 16, 9, 16], [-9, 16, 16, 9],
             [-9, -16, 9, 16], [9, -16, 16, 9]]]
check("derived Jacobian", J == expected)
check("Jacobian determinant", det(J) == F(-8064, 25))
check("elliptic determinant specialization",
      det(J) == F(8*9*16*(9-16), 9+16))

inverse = [
    [F(5, 36), F(-5, 36), F(-5, 36), F(5, 36)],
    [F(5, 64), F(5, 64), F(-5, 64), F(-5, 64)],
    [F(-9, 70), F(8, 35), F(-9, 70), F(8, 35)],
    [F(8, 35), F(-9, 70), F(8, 35), F(-9, 70)],
]
identity = [[F(i == j) for j in range(4)] for i in range(4)]
check("left inverse", multiply(inverse, J) == identity)
check("right inverse", multiply(J, inverse) == identity)
M = max(sum(map(abs, row)) for row in inverse)
check("inverse infinity norm", M == F(5, 7))

delta, N0 = F(1, 8192), 1024
check("vertex displacement conservative", 2*2**2 < 4**2)
check("elliptic displacement", 16*delta == F(1, 512))
margin = F(1, 8)-16*delta
check("annular margin", margin == F(63, 512))
check("strict interior", r-16*delta > F(1, 4)
      and r+16*delta < F(1, 2))
check("positive p and q", h-delta > 0)
check("side expression", 2*(h-delta) == F(3067, 20480))
check("side lower bound", 2*(h-delta) > F(1, 8))
check("argument neighborhoods avoid zero", 16*delta < r)

hessian = F(16)/F(1, 4)
gradient_argument = F(4)/F(1, 4)
check("Hessian bound", hessian == 64)
check("Taylor coefficient", F(1, 2)*hessian*4**2 == 512)
check("derivative-change coefficient", hessian*4**2 == 1024)
check("argument derivative row norm", 4*gradient_argument == 64)
check("using pi > 3", F(64, 24) == F(8, 3))


def bounds(N):
    B = M*(F(1, 8*N)+F(8, 3)*delta/N+512*delta**2)
    C = M*(1024*delta+F(8, 3*N))
    return B, C


B, C = bounds(N0)
check("mapping ratio", B/delta == F(2045, 2688))
check("mapping into cube", B < delta)
check("contraction bound", C == F(35, 384))
check("contraction below 1/10", C < F(1, 10))
extra = M/F(24*2048)
check("perturbed ratio", (B+extra)/delta == F(2365, 2688))
check("perturbed invariance", B+extra < delta)
for N in (1025, 2048, 8192, 10**9):
    bN, cN = bounds(N)
    check(f"decreasing bounds sample N={N}", bN < B and cN < C)
# Formula monotonicity follows because the variable terms have positive
# coefficients divided by N; samples only check implementation consistency.

low = 4 - 8*(r+16*delta)
high = 4 - 8*(r-16*delta)
check("source parameter lower", low == F(63, 64))
check("source parameter upper", high == F(65, 64))
check("central portion", F(1, 2) < low < high < F(3, 2))
for rho in (r-16*delta, r, r+16*delta):
    theta_over_pi = 4*N0-8*N0*rho
    check(f"finite-arm phase rho={rho}",
          theta_over_pi+8*N0*rho == 4*N0)
    check(f"finite-arm range rho={rho}",
          0 < theta_over_pi < 2*N0)
for n in range(2, 7):
    N = n*2**(6*n)
    R = F(1, 2**(3*n))
    check(f"coil threshold n={n}", N >= N0)
    check(f"coil side n={n}", R/8 == F(1, 2**(3*n+3)))
check("n=2 bound", F(1, 2**6)/8 == F(1, 512))

print("v208 exact algebra and rational arithmetic audit")
print(f"PASS: {checks} checks")
print("Polynomial identity: det(S) = 8*a*b*(a*a-b*b)")
print("Elliptic Jacobian determinant: -8064/25")
print("Inverse infinity norm: 5/7")
print("Mapping ratio: 2045/2688 < 1")
print("Contraction: 35/384 < 1/10")
print("Perturbed mapping ratio: 2365/2688 < 1")
print("Square side > R/8; source parameters in [63*pi*N/64,65*pi*N/64]")
print("Analytic proofs and geometric membership are supplied in the notes.")
