# Four physical phases and distorted coils

## 1. The earlier general principle, restated precisely

The following is the local forcing principle of v190, with the lattice
spacing written as \(2\pi\). Its short proof is included so this application
does not depend on v190's separate classification or globalization claims.

Write a physical square as
\[
z_0=(x+p,y+q),\quad z_1=(x-q,y+p),\quad
z_2=(x-p,y-q),\quad z_3=(x+q,y-p).
\tag{1}
\]
Let \(u=(x,y,p,q)\), with \(p^2+q^2>0\). Its side is
\(\sqrt{2(p^2+q^2)}\).

Suppose \(H\) is continuously differentiable near the four vertices of
a reference square \(u_*\), and
\[
F(u)=(H(z_0(u)),H(z_1(u)),H(z_2(u)),H(z_3(u)))
\]
has an invertible derivative \(J=DF(u_*)\).
Let \(\mathcal E_L(u)\) be any continuous four-vector on a fixed
neighborhood of \(u_*\), with
\[
E_L:=\sup\|\mathcal E_L(u)\|_\infty=o(L).
\]
Then, for every sufficiently large \(L\), there is a square \(u_L\to u_*\)
such that
\[
LF(u_L)+\mathcal E_L(u_L)\in c+2\pi\mathbb Z^4
\tag{2}
\]
for any fixed vector \(c\). Moreover,
\[
\|u_L-u_*\|_\infty=O((E_L+1)/L).
\]
No derivative bound on \(\mathcal E_L\) is assumed.

**Proof.** Put \(M=\|J^{-1}\|_\infty\).
Choose a lattice target \(t_L\) by componentwise rounding of
\(LF(u_*)+\mathcal E_L(u_*)\) to \(c+2\pi\mathbb Z^4\).
The difference \(b_L\) has norm at most \(\pi\).
Write
\[
Q(u)=F(u)-F(u_*)-J(u-u_*).
\]
Continuous differentiability gives
\(\|Q(u)\|_\infty=o(\|u-u_*\|_\infty)\).
On the cube of radius
\[
r_L=2M(\pi+2E_L)/L
\]
about \(u_*\), consider
\[
T_L(u)=u_*+J^{-1}\left[
b_L/L-(\mathcal E_L(u)-\mathcal E_L(u_*))/L-Q(u)\right].
\]
For large \(L\) this cube lies in the fixed neighborhood and
\(\|Q(u)\|_\infty\le\|u-u_*\|_\infty/(4M)\).
Thus \(\|T_L(u)-u_*\|_\infty\le r_L/2+r_L/4\).
Brouwer's fixed-point theorem gives a fixed point, which is exactly
(2). The reference is nondegenerate, so nearby solutions remain
nondegenerate squares. This proves the claim.

The lattice zero is a point of the desired curve only when the phase
description actually characterizes that curve near the four vertices.
That membership condition is checked below.

## 2. An elliptic leading phase has full rank

Let \(a,b>0\), \(a\ne b\), and
\[
H(X,Y)=\sqrt{aX^2+bY^2}.
\]
Choose \(h>0\) and \(u_*=(0,0,h,h)\). The four vertices are
\((h,h),(-h,h),(-h,-h),(h,-h)\), all with
elliptic radius \(r_*=h\sqrt{a+b}\).

Direct differentiation in the coordinates (1) gives
\[
J=\frac1{\sqrt{a+b}}
\begin{pmatrix}
a&b&a&b\\
-a&b&b&a\\
-a&-b&a&b\\
a&-b&b&a
\end{pmatrix}.
\tag{3}
\]
Let the displayed integer-pattern matrix be \(S\).
Replacing its rows by
\((R_0-R_2,R_1-R_3,R_0+R_2,R_1+R_3)\)
has determinant multiplier \(4\) and produces two diagonal blocks.
Their determinants are \(8ab\) and \(4(a^2-b^2)\).
Therefore
\[
\det S=8ab(a^2-b^2),\qquad
\boxed{\det J=\frac{8ab(a-b)}{a+b}\ne0.}
\tag{4}
\]

This calculation also handles \(H(X,Y)=\phi(aX^2+bY^2)\).
At the same square all four quadratic arguments equal
\(q_*=h^2(a+b)\), so
\[
\det DF_H(u_*)=
128h^4ab(a^2-b^2)\,[\phi'(q_*)]^4.
\tag{5}
\]
It is nonzero whenever \(\phi\) is continuously differentiable near
\(q_*\) and \(\phi'(q_*)\ne0\).
In particular, affine or logarithmic laws in the quadratic argument
are not rank exceptions after a fixed unequal elliptic stretch.
This is a rank statement for coherent phases, not a theorem that all
curves have such a phase description.

## 3. Every fixed invertible linear distortion of a long coil

**Theorem.** For every fixed invertible real linear map \(T\) there
are constants \(N_T\) and \(c_T>0\) such that, for every integer
\(N\ge N_T\) and every \(R>0\), the arm \(T\kappa_{R,N}\) contains
a Euclidean square of side at least \(c_TR\).
The vertices can be kept in the interior of the original arm.
The statement also permits an arbitrary translation of the whole arm.

**Proof for unequal singular values.** Set \(R=1\) and \(L=8\pi N\).
In physical coordinates, membership in \(T\kappa_{1,N}\) is exactly
\[
1/4\le H(z):=|T^{-1}z|\le1/2,\qquad
LH(z)+\arg(T^{-1}z)\equiv\pi\pmod{2\pi}.
\tag{6}
\]
This is the v207 finite-arm identity applied to the actual inverse
linear map. It holds for both signs of \(\det T\).

An orthogonal change of physical coordinates diagonalizes
\((T^{-1})^{\mathsf T}T^{-1}\), giving the phase of §2, with
\(a,b>0\) unequal. Orthogonal changes preserve Euclidean squares.
Choose
\[
h=\frac{3}{8\sqrt{a+b}},
\]
so all four reference radii are \(3/8\).
Each of the four inverse images is nonzero. On small neighborhoods
choose continuous branches of \(\arg(T^{-1}z)\); these branches are
bounded, and changing a branch by \(2\pi\) does not affect membership.

Use the theorem of §1 with these four bounded argument terms as
\(\mathcal E_L\), and with \(c=(\pi,\pi,\pi,\pi)\).
Equation (4) gives invertibility. The resulting physical square
converges to \(u_*\). Its elliptic radii stay in \((1/4,1/2)\);
equation (6) puts its vertices on the actual finite arm.
Its side tends to
\[
2h=\frac{3}{4\sqrt{a+b}}.
\]
For sufficiently large \(N\), one may take
\(c_T=3/(8\sqrt{a+b})\).
The source parameters tend, after division by \(N\), to \(\pi\);
they stay away from the endpoints \(0\) and \(2\pi N\).
Rescale by \(R\).

**Equal singular values.** Then \(T\) is a scalar multiple of an
orthogonal map. Apply the retained v207 theorem, which gives
\(N_T=32768\) and \(c_T=\sigma/8\), where \(\sigma\) is the common
singular value. This completes the proof.

The threshold in the unequal case is not asserted uniform as
\(a-b\to0\). Its Jacobian becomes singular there, while the separate
circular argument handles equality.

## 4. Continuous nonradial phase errors

In the unequal case, replace the phase in (6) by
\[
L|T^{-1}z|+\arg(T^{-1}z)+e_L(z),
\qquad \|e_L\|_\infty=o(L)
\]
on the four fixed vertex neighborhoods. Continuous, position-dependent
errors are allowed. Section 1 still applies, so the local phase-zero
set contains a nearby square.

To infer a square on a particular Jordan curve, that curve must contain
these local zero sets, or otherwise have the asserted equivalent
membership description. Closeness to phase zeros alone is insufficient.
Section 3 satisfies this requirement exactly. The smooth-deformation
application in the companion note also checks it.
