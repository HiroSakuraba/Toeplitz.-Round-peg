# An explicit 1,024-turn theorem

## Statement and coordinates

Let \(T(X,Y)=(X/3,Y/4)\). For every integer \(N\ge1024\) and \(R>0\),
the single arm \(T\kappa_{R,N}\) contains a square of side \(>R/8\).
For the unperturbed arm, all four source parameters belong to
\[
[63\pi N/64,\ 65\pi N/64].
\tag{1}
\]
Thus local endpoint smoothing can preserve the vertices.

Work with normalized physical coordinates \(R=1\). Put
\[
H(X,Y)=\sqrt{9X^2+16Y^2},\qquad \psi(X,Y)=\arg(3X+4iY),
\qquad L=8\pi N.
\]
The arm is exactly the set
\[
1/4\le H(z)\le1/2,\qquad LH(z)+\psi(z)\equiv\pi\pmod{2\pi}.
\tag{2}
\]
Use the square coordinates in the affine theorem, with
\[
u_*=(0,0,3/40,3/40),\qquad \delta=1/8192,\qquad
K=\{u:\|u-u_*\|_\infty\le\delta\}.
\]
Every reference elliptic radius is \(3/8\).

## Exact derivative

For \(F(u)=(H(z_j(u)))_{j=0}^3\),
\[
J=DF(u_*)=\frac15
\begin{pmatrix}
9&16&9&16\\
-9&16&16&9\\
-9&-16&9&16\\
9&-16&16&9
\end{pmatrix},
\qquad \det J=-8064/25.
\]
Its inverse is
\[
J^{-1}=
\begin{pmatrix}
5/36&-5/36&-5/36&5/36\\
5/64&5/64&-5/64&-5/64\\
-9/70&8/35&-9/70&8/35\\
8/35&-9/70&8/35&-9/70
\end{pmatrix},
\qquad M:=\|J^{-1}\|_\infty=5/7.
\tag{3}
\]

## Uniform estimates

Each vertex displacement has Euclidean norm at most \(4\delta\).
The function \(H\) is \(4\)-Lipschitz, so throughout \(K\),
\[
|H(z_j)-3/8|\le16\delta=1/512.
\tag{4}
\]
The radial margin to either endpoint of \([1/4,1/2]\) is at least
\(63/512\).

Writing \(B=\operatorname{diag}(3,4)\), the Hessian of \(H(z)=|Bz|\)
has norm at most \(\|B\|^2/H\le64\). Each coordinate column of
the linear vertex map has Euclidean norm one, so all coordinate
Hessian entries of \(F_j\) are bounded by \(64\).
For \(Q(u)=F(u)-F(u_*)-J(u-u_*)\), this gives
\[
\|Q(u)\|_\infty\le512\|u-u_*\|_\infty^2,\qquad
\|DQ(u)\|_\infty\le1024\delta.
\tag{5}
\]

Choose separate continuous branches of \(\psi\) near the four
reference vertices. Each branch has gradient norm
\(\le\|B\|/H\le16\). For
\(\Psi(u)=(\psi(z_j(u)))_{j=0}^3\), consequently
\[
\|D\Psi(u)\|_\infty\le64,\qquad
\|\Psi(u)-\Psi(u_*)\|_\infty\le64\delta.
\tag{6}
\]
Such branches exist on these small vertex neighborhoods because their
images under \(B\) stay in disks avoiding the origin.

## Fixed-point estimate

Round \(LF(u_*)+\Psi(u_*)\) to a vector \(t\in\pi+2\pi\mathbb Z^4\).
Let \(b=t-LF(u_*)-\Psi(u_*)\), so \(\|b\|_\infty\le\pi\).
Define
\[
\mathcal T(u)=u_*+J^{-1}
\left[b/L-(\Psi(u)-\Psi(u_*))/L-Q(u)\right].
\]
Its fixed points are exactly the phase equations (2) for all vertices.
Using \(L>24N\), equations (3)–(6) give
\[
\|\mathcal T(u)-u_*\|_\infty\le
B_N:=\frac57\left(\frac1{8N}+\frac{8\delta}{3N}+512\delta^2\right),
\]
\[
\operatorname{Lip}_K(\mathcal T)\le
C_N:=\frac57\left(1024\delta+\frac8{3N}\right).
\]
At \(N=1024\) these satisfy
\[
B_N/\delta=2045/2688<1,\qquad C_N=35/384<1/10.
\tag{7}
\]
Both bounds decrease with \(N\). The contraction theorem gives a
fixed point in \(K\), hence an actual square on the arm.
Its coordinates satisfy
\[
p,q\ge3/40-\delta,\qquad
\text{side}=\sqrt{2(p^2+q^2)}
\ge2(3/40-\delta)=3067/20480>1/8.
\tag{8}
\]
Formula (4), substituted in \(\theta=4\pi N-LH(z)\),
gives (1). Scaling gives the result for \(R>0\).
For the fixed rounded target the solution in \(K\) is unique;
this does not assert that the arm contains only one square.

## Continuous spatial phase perturbations

Suppose \(e_N(z)\) is continuous on the union of these fixed vertex
neighborhoods, with
\[
\|e_N\|_\infty\le N/2048.
\]
Replace the phase in (2) by \(LH+\psi+e_N\).
Set \(\mathcal E_N(u)=(e_N(z_j(u)))_j\), and replace \(\mathcal T\)
by \(\mathcal T_e=\mathcal T-J^{-1}\mathcal E_N/L\).
Its extra displacement is at most
\[
\frac{M\|e_N\|_\infty}{L}\le\frac{M}{24\cdot2048}.
\]
At the worst value \(N=1024\),
\[
\frac{B_{1024}+M/(24\cdot2048)}{\delta}
=2365/2688<1.
\tag{9}
\]
Thus \(\mathcal T_e\) maps \(K\) into itself. Brouwer supplies a
fixed point without any derivative bound on \(e_N\).
The phase-zero set contains a square with the same side and elliptic
radius bounds. No uniqueness is asserted in this continuous case.

This last assertion concerns the phase-zero set. It is a statement
about a chosen Jordan curve only if that curve has the specified
local phase membership description.
