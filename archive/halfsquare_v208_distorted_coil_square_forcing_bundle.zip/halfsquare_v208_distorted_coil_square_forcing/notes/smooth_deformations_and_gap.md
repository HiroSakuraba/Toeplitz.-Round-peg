# Smooth deformations, actual membership, and the remaining gap

## 1. A deformation theorem for accumulating coils

Let \(a_n\to0\), \(R_n\downarrow0\), and let integer \(N_n\to\infty\).
Suppose a curve contains the arms
\[
a_n+R_n\kappa_{1,N_n},
\]
or at least their central portions with source parameter
\(\theta\in[\pi N_n/2,3\pi N_n/2]\).
Here centers \(a_n\) are viewed as points of the plane.

Let \(F\) be a continuously differentiable diffeomorphism on a
neighborhood of \(0\), and assume \(T=DF(0)\) has unequal singular
values. Then, for all sufficiently large \(n\), the image under \(F\)
of each such arm contains an actual Euclidean square with side
\[
\ge c_T R_n,\qquad c_T>0.
\tag{1}
\]
One can take \(c_T=3/(8\sqrt{a+b})\), where \(a,b\) are the
eigenvalues of \((T^{-1})^{\mathsf T}T^{-1}\).
There is no assertion of a universal threshold independent of \(F\).

## 2. Proof

Normalize around the image of each center:
\[
G_n(w)=\frac{F(a_n+R_n w)-F(a_n)}{R_n}.
\]
Continuous differentiability, with \(a_n\to0\) and \(R_n\to0\),
gives \(G_n(w)\to Tw\) uniformly on every fixed bounded source set.
The corresponding inverse functions satisfy
\[
W_n(z):=\frac{F^{-1}(F(a_n)+R_nz)-a_n}{R_n}
\longrightarrow T^{-1}z
\tag{2}
\]
uniformly on fixed compact target sets. These facts follow directly
from the first-order integral expansions of \(F\) and \(F^{-1}\);
their derivatives converge uniformly near the accumulation point.

Work near the four reference vertices in the affine-coil proof,
each with \(|T^{-1}z_j|=3/8\). Choose fixed small neighborhoods.
For large \(n\), (2) ensures that all \(|W_n(z)|\) in those neighborhoods
lie strictly between \(1/4\) and \(1/2\).
The exact image-arm membership condition is
\[
L_n|W_n(z)|+\arg W_n(z)\equiv\pi\pmod{2\pi},
\qquad L_n=8\pi N_n.
\tag{3}
\]

Choose continuous, bounded argument branches on these neighborhoods.
They exist uniformly for large \(n\), since \(W_n\to T^{-1}\)
there and each limiting inverse image stays away from zero.
Rewrite (3) as
\[
L_nH(z)+e_n(z)\equiv\pi\pmod{2\pi},
\qquad H(z)=|T^{-1}z|,
\]
where
\[
e_n(z)=L_n\bigl(|W_n(z)|-|T^{-1}z|\bigr)+\arg W_n(z).
\]
Equation (2) and boundedness of the arguments give
\(\|e_n\|_\infty/L_n\to0\).
The four-phase theorem therefore produces a physical square converging
in normalized coordinates to the affine reference square.

At these vertices, (3) and the radial interval check establish
membership in the actual image arm. The corresponding source
parameters obey \(\theta_j/N_n\to\pi\); consequently the central
portion specified in §1 suffices. The normalized side tends to
\(3/(4\sqrt{a+b})\). Rescaling proves (1).

The proof permits very large phase errors in absolute size, provided
they are subleading compared with \(N_n\). It needs no relation such
as \(N_nR_n\to0\). The uniform normalized inverse convergence in (2)
is the relevant estimate.

## 3. Application to the explicit finite-coil construction

The sequence used in the previous continuation has
\[
a_n=2^{-n},\quad R_n=2^{-3n},\quad N_n=n2^{6n}.
\]
It satisfies the hypotheses. Thus a fixed continuously differentiable
deformation with anisotropic derivative at the accumulation point
cannot remove all the squares from its central coil arms.
At least one sufficiently late coil already contains a positive-size
square; taking a limit of these squares is unnecessary.

For the fixed linear compression \(T(x,y)=(x/3,y/4)\), the explicit
theorem applies already at \(n=2\), since \(N_2=8192\).
Its square has side \(>R_2/8=1/512\), when that arm is preserved.

No claim is made here that an arbitrary diffeomorphism preserves
Liouville regularity or nonregularity. The conclusion concerns the
actual square configurations of these specified geometric models.

## 4. What this does and does not settle

The earlier warning remains valid: nested-lobe topology does not
imply circular radial geometry. This continuation handles one
substantial family of the resulting noncircular geometries directly.
It also handles small-scale nonlinear deformations when they have
a fixed anisotropic linear limit.

It supplies no comparable conclusion for deformations that change
uncontrollably with scale, maps without a suitable derivative,
or arbitrary area packets lacking a coherent phase coordinate.
Nor has non-Liouville regularity been shown to produce such a model.

The global contradiction is still missing
\[
\text{nonvanishing relative radial action}
\ \Longrightarrow\
\text{a square on the actual boundary}.
\]
The current results establish the right side for explicit families,
not this implication in general.

## 5. Best next question

Study normalized packets that have no stable scalar phase description.
A meaningful result would either:

- construct a four-point degree directly on such packets, with
  controlled boundary behavior and exclusion of coincident vertices; or
- prove compactness/extraction into a phase model with a nonsingular
  four-point derivative, with every extracted zero belonging to the
  physical boundary.

The second statement must include the metric estimate that makes
phase error subleading. A topological conjugacy alone does not.
The first must handle diagonal collapse; writing the square equations
does not by itself supply the required degree.

Improving the numerical turn threshold is lower priority than either
of these missing geometric statements.
