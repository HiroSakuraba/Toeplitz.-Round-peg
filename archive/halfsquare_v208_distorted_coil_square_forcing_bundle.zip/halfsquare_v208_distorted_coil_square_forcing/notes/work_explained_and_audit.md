# What we worked on

## Plain-language explanation

The previous result found squares on tightly wound circular coils.
But a real difficult curve might resemble a stretched or bent coil.
Stretching an existing square usually turns it into a rectangle,
so simply carrying the old square through the deformation would
not answer the problem.

We instead solve for four new points after the deformation.
The four points have four freedoms: two for the center and two
for size and orientation. On an elliptic coil, moving those freedoms
changes the four winding phases independently. An explicit determinant
proves that independence.

When there are many turns, a small adjustment of the square changes
its phases enough to land all four points on actual turns of the coil.
A fixed-point theorem makes this exact. It also tolerates small
continuous errors without requiring those errors to be smooth.

The new quantitative example compresses the coil differently in
the horizontal and vertical directions. With 1,024 turns, it
guarantees a square larger than one-eighth of the original coil
radius. A further argument shows that sufficiently small coils
also survive a fixed smooth deformation with an unequal local stretch.

This removes circular symmetry as a necessary hypothesis for these
examples. It still does not show that every difficult Jordan curve
contains an appropriate coil or phase pattern. That remains a
central obstacle to solving Toeplitz.

## Audit and scope

| Claim | Evidence and boundary |
|---|---|
| General four-phase forcing | Already banked in v190; a self-contained local proof is supplied here. |
| Elliptic phase full rank | Symbolic polynomial determinant identity plus direct differentiation. |
| Every fixed invertible linear image of a long coil | Elliptic argument for unequal singular values; retained v207 for similarities. |
| Explicit 1,024-turn case | Exact inverse, norm, cube invariance, contraction, side, and finite-arm checks. |
| Continuous nonradial error | Brouwer's fixed-point theorem; requires actual local phase membership to infer a curve square. |
| Smooth deformation | Uniform convergence of normalized inverses; anisotropic derivative assumed. |
| General area-to-square implication | Still unproved. |

The verification script checks algebra and rational constants.
It does not formally verify the analytic estimates or fixed-point theorems.
No interval arithmetic certification or external peer review is claimed.
The illustrative constants are conservative and not optimized.

## Historical sources and attribution

- v189, nested-lobe lamination note, identified the elliptic obstruction
  to assuming circular radial geometry.
- v190, general phase-lattice forcing, Theorem 2.1, supplies the
  existing general principle. Its separate classification is not used.
  The v201 correction to that classification's globalization is
  consequently irrelevant to the present proof.
- v207, finite-coil square theorem, is retained verbatim for the
  circular/similarity case and comparison.
- The finite-coil test family originates in Asano and Ike,
  [Liouville regular Jordan curves, arXiv:2609.11598v1](https://arxiv.org/html/2609.11598v1),
  §6.2. v208's affine and deformation assertions are deductions in this
  research continuation, not claims attributed to that paper.

Source hashes are recorded in provenance.json. No claim of priority
is made for these deductions. The bundle is a research continuation,
not a completed proof of the square-peg conjecture.
