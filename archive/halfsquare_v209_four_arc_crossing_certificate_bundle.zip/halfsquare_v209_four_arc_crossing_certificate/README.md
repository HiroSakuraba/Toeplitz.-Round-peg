# v209 — A square from four actual crossing arcs

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** A local sufficient criterion, with a proved failure example for a weaker criterion. Toeplitz remains open.

This continuation removes the scalar phase assumption from a local
square-forcing argument. Four actual curve pieces, crossing four
appropriately oriented thin rectangles, must contain the vertices
of a square. The pieces may backtrack and need only be continuous.

The criterion is finite and explicit: construct two real matrices
\(A,B\) from the rectangle directions, require \(A\) invertible, and check
\[
\sum_j |(A^{-1}B)_{ij}|\varepsilon_j<T_i
\quad\text{for every }i.
\]
Here \(T_i\) is a rectangle's longitudinal coordinate half-length and
\(\varepsilon_j\) its transverse coordinate half-width.
The proof is a direct application of the multidimensional intermediate
value theorem to the linear square equations.

An explicit configuration centered at \((1,1),(-1,1),(-1,-1),(1,-1)\)
has a positive margin \(3/200\) and forces a square of side at least
\(29/20\). An exact rational example uses four backtracking polygonal
arcs, with an actual square found and checked on their segments.

We also prove that four arbitrarily thin, smooth crossing arcs near
the corners of a square need not supply one vertex each to a square.
Thus closeness, flatness, and crossing alone are insufficient; the
compatibility of the four directions matters.

## What remains missing

No theorem here extracts the required four rectangles from an arbitrary
signed-area concentration packet. This is a concrete local condition
to aim for, not a solution of that global extraction problem.
No claim of a new general topological principle or mathematical priority
is made.

## Read and run

- [Four-arc theorem and explicit constants](notes/four_arc_theorem.md).
- [Failure of the weaker closeness criterion](notes/radial_failure_example.md).
- [Research interpretation and next target](notes/research_status.md).
- [Illustration of the exact witness](results/four_arc_witness.svg).
- Run Python 3 on code/verify_v209.py. It uses exact rational arithmetic
  and the standard library, checks the matrix and sign estimates, and
  locates a square on the supplied polygonal paths.
- results/verification.txt records the checks; results/witness.json
  records the exact vertex coordinates and segment parameters.

The checker verifies the supplied polygonal paths in full, not merely
sampled points of an unknown curve. The general continuous-arc theorem
is a written proof, not a claim of formal proof-assistant verification.
This small standalone bundle has no nested archives.
