#!/usr/bin/env python3
"""Exact audit and rational polygonal witness; no numerical root tolerance."""
from fractions import Fraction as F
from itertools import permutations, product
from math import prod
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
checks = 0


def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def det(a):
    n = len(a)
    return sum((-1)**sum(p[i] > p[j] for i in range(n)
                         for j in range(i+1, n))
               * prod(a[i][p[i]] for i in range(n))
               for p in permutations(range(n)))


def inverse(a):
    n = len(a)
    m = [[F(v) for v in row] + [F(i == j) for j in range(n)]
         for i, row in enumerate(a)]
    for j in range(n):
        pivot = next((i for i in range(j, n) if m[i][j]), None)
        if pivot is None:
            return None
        m[j], m[pivot] = m[pivot], m[j]
        d = m[j][j]
        m[j] = [v/d for v in m[j]]
        for i in range(n):
            if i != j:
                d = m[i][j]
                m[i] = [x-d*y for x, y in zip(m[i], m[j])]
    return [row[n:] for row in m]


def multiply(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def mv(a, v):
    return [sum(x*y for x, y in zip(row, v)) for row in a]


def add(a, b):
    return [x+y for x, y in zip(a, b)]


def sub(a, b):
    return [x-y for x, y in zip(a, b)]


def scale(s, a):
    return [s*x for x in a]


def norm2(a):
    return sum(x*x for x in a)


def dot(a, b):
    return sum(x*y for x, y in zip(a, b))


K = [
    [[1, 0], [0, 1], [0, 1], [-1, 0]],
    [[-1, 0], [0, -1], [1, 0], [0, 1]],
    [[1, 0], [0, 1], [0, -1], [1, 0]],
    [[-1, 0], [0, -1], [-1, 0], [0, -1]],
]


def residual(vertices):
    return [sum(mv(K[j], vertices[j])[i] for j in range(4))
            for i in range(4)]


def direction_matrix(directions):
    cols = [mv(K[j], directions[j]) for j in range(4)]
    return [[cols[j][i] for j in range(4)] for i in range(4)]


def rational_pair(values):
    return [F(v) for v in values]


case = json.loads((ROOT/'data/crossing_example.json').read_text())
q = [rational_pair(p) for p in case['reference_vertices']]
v = [rational_pair(p) for p in case['longitudinal_vectors']]
n = [rational_pair(p) for p in case['transverse_vectors']]
T, eps = F(case['T']), F(case['epsilon'])
local = [[rational_pair(p) for p in path] for path in case['local_paths']]
A, B = direction_matrix(v), direction_matrix(n)
invA = inverse(A)
check('invertible longitudinal matrix', invA is not None)
check('determinant', det(A) == -672)
check('reference square residual', residual(q) == [0]*4)
check('matrix inverse', multiply(invA, A) ==
      [[F(i == j) for j in range(4)] for i in range(4)])
C = multiply(invA, B)
expectedC = [[F(x, 336) for x in row] for row in [
    [-527, 425, -625, 775], [-425, 527, -775, 625],
    [-625, 775, -527, 425], [-775, 625, -425, 527]]]
check('preconditioned error matrix', C == expectedC)
for i in range(4):
    check(f'row norm {i}', sum(map(abs, C[i])) == 7)
    margin = T-sum(abs(c)*eps for c in C[i])
    check(f'positive margin {i}', margin == F(3, 200) and margin > 0)
    check(f'orthogonality {i}', dot(v[i], n[i]) == 0)
    check(f'basis lengths {i}', norm2(v[i]) == norm2(n[i]) == 25)

D = 5*(T+eps)
check('displacement bound', D == F(11, 40))
check('side bound', 2-2*D == F(29, 20))
for i, j in ((i, j) for i in range(4) for j in range(i+1, 4)):
    check(f'pairwise separation {i},{j}', norm2(sub(q[i], q[j])) > (2*D)**2)

# All vertices in each convex rectangle imply all full segments are inside.
paths = []
for j in range(4):
    path = local[j]
    check(f'negative end cap {j}', path[0][0] == -T)
    check(f'positive end cap {j}', path[-1][0] == T)
    for k, (a, b) in enumerate(path):
        check(f'longitudinal containment {j},{k}', -T <= a <= T)
        check(f'transverse containment {j},{k}', -eps <= b <= eps)
    check(f'backtracking {j}', any(path[k+1][0] < path[k][0]
                                  for k in range(len(path)-1)))
    check(f'simple path via transverse monotonicity {j}',
          all(path[k+1][1] > path[k][1] for k in range(len(path)-1)))
    paths.append([add(q[j], add(scale(a, v[j]), scale(b, n[j])))
                  for a, b in path])

# Constructive exact witness on actual line segments.
witness = None
tried = 0
for indices in product(*(range(len(path)-1) for path in paths)):
    tried += 1
    starts = [paths[j][indices[j]] for j in range(4)]
    directions = [sub(paths[j][indices[j]+1], starts[j]) for j in range(4)]
    m = direction_matrix(directions)
    inv = inverse(m)
    if inv is None:
        continue
    t = mv(inv, scale(-1, residual(starts)))
    if all(0 <= s <= 1 for s in t):
        vertices = [add(starts[j], scale(t[j], directions[j])) for j in range(4)]
        witness = (indices, t, vertices)
        break
check('actual segment square found', witness is not None)
indices, parameters, square = witness
check('exact square residual', residual(square) == [0]*4)
sides2 = [norm2(sub(square[(j+1)%4], square[j])) for j in range(4)]
check('equal positive sides', all(s == sides2[0] and s > 0 for s in sides2))
check('perpendicular adjacent sides',
      dot(sub(square[1], square[0]), sub(square[2], square[1])) == 0)
check('witness side meets theorem bound', sides2[0] >= F(29, 20)**2)
for j in range(4):
    check(f'exact segment parameter {j}', 0 <= parameters[j] <= 1)
    p = add(paths[j][indices[j]],
            scale(parameters[j], sub(paths[j][indices[j]+1], paths[j][indices[j]])))
    check(f'exact segment membership {j}', p == square[j])
check('squared-radius parallelogram identity',
      norm2(square[0])+norm2(square[2]) ==
      norm2(square[1])+norm2(square[3]))

# Counterexample: rational circle identity, not a floating-point approximation.
def poly_mul(p, q):
    out = [F(0)]*(len(p)+len(q)-1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i+j] += a*b
    return out

left = poly_mul([F(1), F(0), F(-1)], [F(1), F(0), F(-1)])
left[2] += 4
right = poly_mul([F(1), F(0), F(1)], [F(1), F(0), F(1)])
check('rational circle polynomial identity', left == right)
eta = F(1, 100)
delta = eta**2
normal_width = delta+2*(1+delta)*eta**2
minimum_half_length = 2*eta/(1+eta**2)
rho = delta+2*(1+delta)*eta
check('counterexample positive defect',
      2*(1+delta)**2-2 == 4*delta+2*delta**2 > 0)
check('thinness formula',
      normal_width/minimum_half_length ==
      eta*(3+2*eta**2)*(1+eta**2)/2)
check('thinness numerical rational bound',
      normal_width/minimum_half_length < F(1, 50))
check('small vertex neighborhoods', rho < F(1, 10))
check('convex ordering protected', 8*rho+4*rho**2 < 1)
radial_q = [[F(1), F(0)], [F(0), F(1)],
            [F(-1), F(0)], [F(0), F(-1)]]
radial_v = [[-p[1], p[0]] for p in radial_q]
radialA = direction_matrix(radial_v)
check('radial contact matrix singular', det(radialA) == 0)
check('common rotation is kernel', mv(radialA, [F(1)]*4) == [0]*4)

output = '\n'.join([
    'v209 exact four-arc audit and polygonal square witness',
    f'PASS: {checks} exact checks',
    'det(A) = -672; ||A^-1 B||_infinity = 7',
    'All four face margins = 3/200 > 0',
    'Guaranteed square side >= 29/20',
    'All polygonal segments stay in their rectangles; all four paths backtrack',
    f'Actual square found after {tried} segment combinations',
    'Exact square equations, segment membership and side bound: PASS',
    'Thin radial counterexample: exact positive squared-radius defect',
    'Scope: written proof supplies the continuous-path topological argument.',
])+'\n'
print(output, end='')


def serialize_pairs(points):
    return [[str(x) for x in p] for p in points]


data = {
    'segment_indices_zero_based': list(indices),
    'segment_parameters': [str(t) for t in parameters],
    'square_vertices': serialize_pairs(square),
    'squared_side': str(sides2[0]),
    'guaranteed_side_lower_bound': '29/20',
    'all_residuals_exactly_zero': True,
    'checks': checks,
    'segment_combinations_tried': tried,
}


def make_svg():
    # Scientific illustration of the exact rational witness.
    # Conversion to floats is only for display, never for verification.
    pieces = ['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="680" viewBox="0 0 1100 680">',
              '<rect width="1100" height="680" fill="#fbfcfe"/>',
              '<g font-family="Arial,sans-serif" fill="#15263d">',
              '<text x="35" y="38" font-size="24">Four crossing arcs force an actual square</text>',
              '<text x="35" y="65" font-size="14">Blue: actual paths · coral: exact rational square · shaded: permitted rectangles</text>']
    def pt(p):
        return 315+195*float(p[0]), 352-195*float(p[1])
    def points(ps, mapper=pt):
        return ' '.join(f'{mapper(p)[0]:.3f},{mapper(p)[1]:.3f}' for p in ps)
    for j in range(4):
        corners = [add(q[j], add(scale(a, v[j]), scale(b, n[j])))
                   for a, b in [(-T, -eps), (T, -eps), (T, eps), (-T, eps)]]
        pieces.append(f'<polygon points="{points(corners)}" fill="#dce8f2" stroke="#839aaf" stroke-width="1.3"/>')
        pieces.append(f'<polyline points="{points(paths[j])}" fill="none" stroke="#1864a2" stroke-width="2.2"/>')
        x, y = pt(q[j])
        pieces.append(f'<text x="{x+14:.2f}" y="{y-14:.2f}" font-size="16">{j}</text>')
    pieces.append(f'<polygon points="{points(square)}" fill="none" stroke="#cf6249" stroke-width="2.5"/>')
    for p in square:
        x, y = pt(p)
        pieces.append(f'<circle cx="{x:.3f}" cy="{y:.3f}" r="4.5" fill="#cf6249"/>')
    pieces.append('<text x="40" y="641" font-size="15">The reference square has side 2. The theorem guarantees side ≥ 1.45.</text>')
    for j in range(4):
        col, row = j % 2, j // 2
        ox, oy = 715+225*col, 230+235*row
        def localpt(p):
            return ox+88*float(p[0]/T), oy-68*float(p[1]/eps)
        pieces.append(f'<rect x="{ox-88}" y="{oy-68}" width="176" height="136" fill="#eaf1f7" stroke="#839aaf"/>')
        pieces.append(f'<line x1="{ox-88}" y1="{oy}" x2="{ox+88}" y2="{oy}" stroke="#a9b8c7" stroke-dasharray="4 4"/>')
        pieces.append(f'<text x="{ox-88}" y="{oy-85}" font-size="16">Arc {j}: local coordinates</text>')
        pieces.append(f'<polyline points="{points(local[j],localpt)}" fill="none" stroke="#1864a2" stroke-width="2.3"/>')
        pair = add(local[j][indices[j]], scale(parameters[j],
                   sub(local[j][indices[j]+1], local[j][indices[j]])))
        x, y = localpt(pair)
        pieces.append(f'<circle cx="{x:.3f}" cy="{y:.3f}" r="4.8" fill="#cf6249"/>')
        pieces.append(f'<text x="{ox-88}" y="{oy+91}" font-size="12">Horizontal scale: T · vertical scale: ε</text>')
    pieces.append('</g></svg>')
    return '\n'.join(pieces)+'\n'


if '--write-results' in sys.argv:
    target = ROOT/'results'
    target.mkdir(exist_ok=True)
    (target/'verification.txt').write_text(output)
    (target/'witness.json').write_text(json.dumps(data, indent=2)+'\n')
    (target/'four_arc_witness.svg').write_text(make_svg())
