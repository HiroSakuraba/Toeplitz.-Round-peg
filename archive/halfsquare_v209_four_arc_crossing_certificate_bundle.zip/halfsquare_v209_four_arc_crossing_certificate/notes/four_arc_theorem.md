# Four actual arcs force a square

## 1. The geometric data

Let \(q_0,q_1,q_2,q_3\in\mathbb C\) be the vertices of a reference
square in counterclockwise order. For each \(j\), choose linearly
independent vectors \(v_j,n_j\in\mathbb R^2\), and positive numbers
\(T_j,\varepsilon_j\). They determine a parallelogram
\[
\mathcal R_j=\{q_j+v_ja+n_jb:|a|\le T_j,\ |b|\le\varepsilon_j\}.
\]
It is a rectangle when \(v_j\perp n_j\), as in the explicit example.
The vectors need not be unit vectors.

Suppose an actual continuous path \(\gamma_j:[-1,1]\to\mathcal R_j\)
joins the two longitudinal end caps. Orient its parameter so that,
in the unique coordinates
\[
\gamma_j(t)=q_j+v_j a_j(t)+n_j b_j(t),
\]
we have
\[
a_j(-1)=-T_j,\qquad a_j(1)=T_j,\qquad
|a_j(t)|\le T_j,\quad |b_j(t)|\le\varepsilon_j.
\tag{1}
\]
No monotonicity of \(a_j\), differentiability, finite length, or graph
representation is assumed. The theorem even permits noninjective
paths. For a Jordan-curve application, the \(\gamma_j\) are subarcs
of that curve.

## 2. The linear square equations

For four complex points define the two complex residuals
\[
S_1=z_0-z_1+z_2-z_3,\qquad
S_2=-iz_0+z_1+iz_2-z_3.
\tag{2}
\]
Let \(\mathcal S\in\mathbb R^4\) be their real and imaginary parts,
in the order \((\Re S_1,\Im S_1,\Re S_2,\Im S_2)\).
This is a real linear map of the eight vertex coordinates.

Both residuals vanish precisely when
\[
(z_0,z_1,z_2,z_3)=(c+w,c+iw,c-w,c-iw)
\tag{3}
\]
for some \(c,w\in\mathbb C\). If \(w\ne0\), these are the vertices
of a Euclidean square. The case \(w=0\) has all vertices coincident.

Let \(K_j:\mathbb R^2\to\mathbb R^4\) be the contribution of the
\(j\)-th vertex to \(\mathcal S\). Construct the matrices
\[
A=(K_0v_0,\ K_1v_1,\ K_2v_2,\ K_3v_3),\qquad
B=(K_0n_0,\ K_1n_1,\ K_2n_2,\ K_3n_3).
\tag{4}
\]
Since the reference square has zero residual, the residual evaluated
on one point from each path is exactly
\[
\mathcal S(\gamma_0(t_0),\ldots,\gamma_3(t_3))
=Aa(t)+Bb(t).
\tag{5}
\]
There is no linearization error in this identity.

## 3. Crossing theorem

**Theorem.** Assume \(A\) is invertible, put \(C=A^{-1}B\), and suppose
\[
m_i:=T_i-\sum_{j=0}^3|C_{ij}|\varepsilon_j>0
\quad(i=0,1,2,3).
\tag{6}
\]
Then there is a choice of one point on each of the four actual paths
for which (2) vanishes.
If the paths cannot all share one point, this choice is a nondegenerate
square. In particular, pairwise disjoint rectangles ensure this.

**Proof.** On the parameter cube \([-1,1]^4\), define
\[
G(t)=A^{-1}\mathcal S(\gamma_0(t_0),\ldots,\gamma_3(t_3))
=a(t)+Cb(t).
\]
On the face \(t_i=-1\), equation (1) gives \(G_i(t)\le-m_i<0\).
On the opposite face \(t_i=1\), it gives \(G_i(t)\ge m_i>0\).
The Poincaré–Miranda theorem, the multidimensional intermediate
value theorem, supplies a zero of the continuous map \(G\).
Equations (2) and (3) give a square or a coincident configuration.
The latter is excluded by the stated geometric separation. \(\square\)

For completeness, the needed version of Poincaré–Miranda follows
from Brouwer: apply Brouwer to the cube map
\(t\mapsto\operatorname{clamp}(t-\lambda G(t))\), coordinatewise,
for any \(\lambda>0\). A fixed point cannot lie on a face with
the strict signs above, and an interior fixed point has \(G(t)=0\).

Let \(s_*\) be the reference side and
\[
D_j=\|v_j\|T_j+\|n_j\|\varepsilon_j.
\]
At the constructed square, each point is within \(D_j\) of \(q_j\).
Consequently its side is at least
\[
\min_j(s_*-D_j-D_{j+1}),\quad j\pmod4,
\tag{7}
\]
whenever this lower bound is positive.

The curve order of the four subarcs is unrestricted. The labels here
describe their geometric square order; no graceful-order assumption
is made.

## 4. An explicit rational configuration

Take
\[
(q_0,q_1,q_2,q_3)=((1,1),(-1,1),(-1,-1),(1,-1)),
\]
\[
(v_0,v_1,v_2,v_3)=((-4,3),(-4,-3),(4,-3),(4,3)),
\]
\[
(n_0,n_1,n_2,n_3)=((3,4),(-3,4),(-3,-4),(3,-4)).
\]
Each pair \(v_j,n_j\) is perpendicular and both vectors have length \(5\).
Direct construction of (4) gives
\[
A=
\begin{pmatrix}
-4&4&4&-4\\
3&3&-3&-3\\
3&-4&3&-4\\
4&-3&4&-3
\end{pmatrix},\quad
B=
\begin{pmatrix}
3&3&-3&-3\\
4&-4&-4&4\\
4&-3&4&-3\\
-3&4&-3&4
\end{pmatrix}.
\]
Their relevant exact values are
\[
\det A=-672,\qquad
C=A^{-1}B=\frac1{336}
\begin{pmatrix}
-527&425&-625&775\\
-425&527&-775&625\\
-625&775&-527&425\\
-775&625&-425&527
\end{pmatrix},
\qquad \|C\|_\infty=7.
\tag{8}
\]
Choose all \(T_j=1/20\) and all \(\varepsilon_j=1/200\).
Then every face margin in (6) is
\[
1/20-7/200=3/200>0.
\]
Also \(D_j\le5(1/20+1/200)=11/40\).
The rectangle neighborhoods are disjoint, since the reference vertices
are at least distance \(2\) apart and \(2D_j<2\).
Equation (7) gives a side of at least
\[
2-2(11/40)=29/20.
\tag{9}
\]

Thus any four continuous paths crossing these four rectangles as
specified contain one vertex each of an actual square with this
positive side bound.

Similarities of the entire construction preserve the conclusion:
translation and rotation move the configuration; a positive scale
factor multiplies every physical length, including (9).

## 5. Exact executable example

The supplied example uses seven vertices on each path. In the local
rectangle coordinates its longitudinal coordinates, divided by \(T\), are
\[
(-1,-1/2,-3/4,0,1/2,1/4,1).
\]
They deliberately backtrack. At vertex \(k=0,\ldots,6\), the transverse
coordinate on path \(j\), divided by \(\varepsilon\), is
\[
-1+2(k/6)^{j+1}.
\]
These transverse coordinates strictly increase, so each polygonal path
is injective despite its longitudinal backtracking.

The exact checker verifies the rectangle and endpoint conditions.
Because each rectangle is convex, checking the polygonal vertices
proves containment of the full segments.
It then enumerates segment choices, solves the four linear residual
equations over rational numbers, and verifies an actual square with
one point on each selected segment. The exact result is stored in
results/witness.json. The figure is an illustration of that checked
rational witness, not evidence replacing the proof.
