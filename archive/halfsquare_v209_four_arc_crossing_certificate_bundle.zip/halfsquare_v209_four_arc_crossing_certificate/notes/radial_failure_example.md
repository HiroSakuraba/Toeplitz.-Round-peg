# Four thin crossing arcs alone do not force a square

The invertibility and sign margins in the crossing theorem cannot be
replaced by the assertion that four thin arcs lie near a reference
square. Here is an explicit obstruction to that weaker statement.

Let \(0<\eta\le1/100\), set \(\delta=\eta^2\), and define four smooth arcs
\[
\gamma_j(t)=r_j i^j
\left(\frac{1-t^2}{1+t^2}
i\frac{2t}{1+t^2}\right),\quad -\eta\le t\le\eta,
\]
where
\[
r_0=r_2=1+\delta,\qquad r_1=r_3=1.
\]
They lie near the east, north, west, and south vertices \(i^j\)
of a square. The rational parametrization has modulus one, so
the squared radius of every point on arc \(j\) is exactly \(r_j^2\).

## 1. They are arbitrarily thin rectangle crossings

Use the tangent direction \(v_j=i^{j+1}\) and the normal direction
\(n_j=i^j\), with reference vertex \(q_j=i^j\).
The local coordinates are
\[
a_j(t)=r_j\frac{2t}{1+t^2},\qquad
b_j(t)=r_j\frac{1-t^2}{1+t^2}-1.
\]
For \(|t|\le\eta<1\), \(a_j\) is strictly increasing and takes endpoint
values \(\pm T_j\), where
\[
T_j=\frac{2r_j\eta}{1+\eta^2}.
\]
Moreover
\[
|b_j(t)|\le\varepsilon
:=\delta+2(1+\delta)\eta^2.
\]
Thus each is a genuine smooth crossing of its corresponding thin
tangential rectangle. As \(\eta\downarrow0\),
\[
\frac{\varepsilon}{\min_j T_j}
\le\frac{\eta(3+2\eta^2)(1+\eta^2)}2\longrightarrow0.
\tag{1}
\]
The rectangles become arbitrarily small and arbitrarily thin.

## 2. Yet there is no square taking one point from each

For the vertices of any square in cyclic order, the parallelogram
identity gives
\[
|z_0|^2+|z_2|^2=|z_1|^2+|z_3|^2.
\tag{2}
\]
For points on these four arcs, the difference between the two sides is
\[
2(1+\delta)^2-2=4\delta+2\delta^2>0.
\tag{3}
\]
Hence no such cyclically labeled square exists.

Nor can relabeling produce a square with one point on each arc.
Each point is within
\[
\rho:=\delta+2(1+\delta)\eta<1/10
\]
of its reference point \(i^j\), since the distance of the rational
unit-circle parametrization from \(1\) is at most \(2|t|\).
Every triple of cyclically ordered reference vertices has oriented
area determinant \(2\). Perturbing each point by at most \(\rho\)
changes this determinant by at most \(8\rho+4\rho^2<1\).
All triples keep positive orientation; consequently the four selected
points remain in strictly convex position in the order \(0,1,2,3\).
Their only possible square order has the same opposite pairs.
Equation (3) excludes it.

The longitudinal matrix \(A\) in the crossing theorem is singular for
these tangent directions. Moving all four reference points by an
infinitesimal common rotation keeps a square and is tangent at every
vertex. That gives a nonzero kernel vector. The failed hypothesis
therefore identifies exactly the weakness of this example.

## 3. Scope

This is not a square-free Jordan curve. It only excludes squares that
select one vertex from each of the four specified short arcs.
Joining the arcs elsewhere can create squares elsewhere, or with
different choices of subarcs.

The lesson for the program is precise: four near-corner crossings,
even smooth and extremely flat ones, do not establish the needed
four-point intersection. A compatible crossing pattern or another
degree argument is still required.
