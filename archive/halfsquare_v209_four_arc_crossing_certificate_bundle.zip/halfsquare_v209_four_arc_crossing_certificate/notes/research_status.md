# What v209 changes in the proof strategy

## 1. From a global phase model to four actual subarcs

The preceding continuations forced squares on circular and distorted
coils by describing the winding geometry with a phase function.
That model is powerful, but it can fail when geometry changes
uncontrollably across scales.

This continuation uses no phase function. It asks for four pieces
of the actual curve that cross four physical rectangles in compatible
directions. Their shapes inside the rectangles may be arbitrarily
irregular. The proof uses their endpoint crossings and transverse
width bounds, followed by the multidimensional intermediate value
theorem.

The square equations are linear in the four points. This makes the
local existence calculation exact, without a Taylor remainder and
without differentiating the curve. The final vertices belong to
the actual selected paths, not to chords or to an approximate model.

## 2. What has been proved

- A sufficient four-arc criterion with explicitly computable margins.
- One rational configuration forcing side length at least \(29/20\)
  before rescaling.
- An exact square witness on four specified backtracking polygonal
  paths, with no numerical root tolerance used.
- A smooth counterexample to the weaker claim that four very thin,
  near-corner crossing arcs always supply a square.

The counterexample matters as much as the sufficient criterion:
it prevents us from silently replacing the directional compatibility
condition by visual closeness or dense crossings.

## 3. What has not been proved

We have not shown that a general nonvanishing relative radial-action
packet contains a compatible four-arc configuration.
Nested lobes, large winding, or many crossings do not by themselves
establish the matrix condition and the four simultaneous width margins.

Thus the global implication remains open:
\[
\text{nonvanishing relative radial action}
\ \Longrightarrow\
\text{a nondegenerate square on the boundary}.
\]
The local criterion is a finite target for an extraction proof.
It is not that extraction proof in different notation.

## 4. The next useful test

Try to extract the four actual subarcs from the nested-lobe packet,
and record the four direction vectors, widths, and endpoint crossings.
The decisive quantity is
\[
\min_i\left(T_i-\sum_j |(A^{-1}B)_{ij}|\varepsilon_j\right).
\]
The task is to prove it positive somewhere while retaining geometric
separation. Merely establishing many crossings does not suffice.

If every natural extraction has a singular or badly conditioned
longitudinal matrix, investigate whether the nesting forces a
rotational or other collective motion that supplies a different
degree. Circular configurations show that failure of this particular
criterion is not evidence of square-freeness.

No new global geometric class has been established in this continuation.
Further local tools should be judged by whether they help prove the
specific extraction or collective-motion statement above.

## 5. Literature and audit boundaries

This is an elementary local application of a standard topological
existence theorem; no priority claim is made.
Gregory R. Chambers's primary-source abstract for
[On the square peg problem, arXiv:2203.02613](https://arxiv.org/abs/2203.02613)
already states a different square-existence theorem for Jordan curves
sufficiently close, with an appropriate winding condition, to a
smooth closed curve. That source was checked to avoid presenting
continuous stability around regular geometry as a new general idea.
Its theorem is not used in the present proof.

The v190 and v191 phase arguments were reviewed before choosing this
route. v208 supplied the motivation to handle geometry without
a stable limiting phase. None of their classification results is
needed for the v209 proof.

The supplied verifier checks exact matrix identities, strict face
margins, full polygonal containment, segment membership of the
constructed square, and the algebra of the counterexample.
The continuous-path theorem and the separation reasoning remain
written mathematical proofs, not formally machine-checked proofs.
