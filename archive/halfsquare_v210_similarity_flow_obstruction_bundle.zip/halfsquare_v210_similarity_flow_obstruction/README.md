# v210 — A proved obstruction to the proposed extraction

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** Negative result about a proof route; Toeplitz remains open.

The proposed implication

> large signed area + deep nested lobes + cubic gaps
> imply a strict four-arc crossing certificate from v209

is false without an additional hypothesis.

This continuation constructs a single simple analytic spiral packet
with all three concentration features, at arbitrarily small scales,
and proves that no four subarcs of that packet can satisfy the
nondegenerate, strict v209 criterion.

The obstruction is an exact rotating-and-scaling symmetry. If the
packet contains a square, that square moves along the spiral until
one vertex reaches the end of a selected subarc. A strict v209
certificate forbids such a boundary solution. The two requirements
cannot coexist.

This does **not** prove that the packet has no squares, and does not
produce a square-free Jordan curve. It rules out a specific universal
extraction claim that was suggested as the next step in v209.
The v209 sufficient theorem itself remains valid.

## Results

- [Similarity-flow obstruction](notes/flow_obstruction.md): no strict
  isolating crossing certificate on four finite orbit segments.
- [Exact critical concentration model](notes/logarithmic_packet.md):
  shrinking diameter, constant signed area, depth \(N\), and gaps
  comparable to the cube of the packet scale.
- [Endpoint transport](notes/endpoint_transfer.md): an existing square
  can be moved to an endpoint while retaining at least half its side.
- [Revised research direction and audit](notes/research_reset.md).

Run Python 3 on code/verify_v210.py for the exact algebra and rational
checks. The analytic arguments are supplied in the notes; the script
does not formally verify the proofs or perform interval certification.

This is a small standalone continuation with no nested archives.
Earlier bundles are preserved. No claim of mathematical priority is made.
