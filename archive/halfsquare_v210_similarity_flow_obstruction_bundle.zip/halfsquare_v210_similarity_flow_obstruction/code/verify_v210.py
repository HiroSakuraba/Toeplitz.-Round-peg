#!/usr/bin/env python3
"""Exact algebra audit. No square-existence/nonexistence search is performed."""
from fractions import Fraction as F
from itertools import permutations
from math import prod
from pathlib import Path
import sys

checks = 0


def check(label, condition):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def matmul(a, b):
    return [[sum(a[i][k]*b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def matvec(a, b):
    return [sum(x*y for x, y in zip(row, b)) for row in a]


def rank(a):
    m = [[F(x) for x in row] for row in a]
    r = 0
    for j in range(len(m[0])):
        p = next((i for i in range(r, len(m)) if m[i][j]), None)
        if p is None:
            continue
        m[r], m[p] = m[p], m[r]
        d = m[r][j]
        m[r] = [x/d for x in m[r]]
        for i in range(len(m)):
            if i != r:
                d = m[i][j]
                m[i] = [x-d*y for x, y in zip(m[i], m[r])]
        r += 1
        if r == len(m):
            break
    return r


def det(a):
    n = len(a)
    return sum((-1)**sum(p[i] > p[j] for i in range(n)
                         for j in range(i+1, n))
               * prod(a[i][p[i]] for i in range(n))
               for p in permutations(range(n)))


K = [
    [[1, 0], [0, 1], [0, 1], [-1, 0]],
    [[-1, 0], [0, -1], [1, 0], [0, 1]],
    [[1, 0], [0, 1], [0, -1], [1, 0]],
    [[-1, 0], [0, -1], [-1, 0], [0, -1]],
]
J2 = [[0, -1], [1, 0]]
J4 = [[0, -1, 0, 0], [1, 0, 0, 0],
      [0, 0, 0, -1], [0, 0, 1, 0]]
for j in range(4):
    # Together with real linearity, this proves covariance for every
    # complex multiplier, not just a finite list of rotations.
    check(f'complex covariance at vertex {j}', matmul(K[j], J2) == matmul(J4, K[j]))
check('translation cancellation',
      [[sum(K[j][i][k] for j in range(4)) for k in range(2)]
       for i in range(4)] == [[0, 0] for _ in range(4)])

fullK = [[K[j][i][k] for j in range(4) for k in range(2)] for i in range(4)]
Q = [
    [1, 0, 1, 0], [0, 1, 0, 1],
    [1, 0, 0, -1], [0, 1, 1, 0],
    [1, 0, -1, 0], [0, 1, 0, -1],
    [1, 0, 0, 1], [0, 1, -1, 0],
]
check('all square parameters give zero residual', matmul(fullK, Q) == [[0]*4 for _ in range(4)])
check('residual rank', rank(fullK) == 4)
check('square parametrization rank', rank(Q) == 4)

# One rational illustration of the infinitesimal symmetry kernel.
params = [F(1, 3), F(2, 5), F(4, 7), F(3, 8)]
flat = matvec(Q, params)
vertices = [flat[2*j:2*j+2] for j in range(4)]
center = [F(-1, 5), F(1, 7)]
generator = [[F(-1, 9), F(-1)], [F(1), F(-1, 9)]]
velocities = [matvec(generator, [p[k]-center[k] for k in range(2)]) for p in vertices]
columns = [matvec(K[j], velocities[j]) for j in range(4)]
orbit_jacobian = [[columns[j][i] for j in range(4)] for i in range(4)]
check('common orbit-time kernel', matvec(orbit_jacobian, [1]*4) == [0]*4)
check('orbit Jacobian singular', det(orbit_jacobian) == 0)

# Formal Laurent monomials: coefficient, exponents of
# (pi, log(2), N, rho_squared). No floating approximations.
def mono(coefficient, exponents):
    return F(coefficient), tuple(exponents)


def mul(a, b):
    return a[0]*b[0], tuple(x+y for x, y in zip(a[1], b[1]))


def reciprocal(a):
    return 1/a[0], tuple(-x for x in a[1])


lam = mono(F(1, 2), (-1, 1, -1, 0))
duration = mono(2, (1, 0, 1, 0))
rho2 = mono(1, (0, 0, 0, 1))
check('lambda times duration', mul(lam, duration) == mono(1, (0, 1, 0, 0)))
check('squared-radius terminal exponent',
      mul(mono(2, (0, 0, 0, 0)), mul(lam, duration)) == mono(2, (0, 1, 0, 0)))
check('terminal squared radius factor', F(1, 2)**2 == F(1, 4))
check('integral coefficient', (1-F(1, 4))/4 == F(3, 16))
area = mul(mono(F(3, 16), (0, 0, 0, 0)), mul(rho2, reciprocal(lam)))
check('unnormalized action monomial', area == mono(F(3, 8), (1, -1, 1, 1)))
# rho_squared=N^-1.
coefficient, (pi_power, log_power, n_power, rho_power) = area
normalized = mono(coefficient, (pi_power, log_power, n_power-rho_power, 0))
check('constant normalized action', normalized == mono(F(3, 8), (1, -1, 0, 0)))
check('action/diameter squared coefficient', F(3, 8)/4 == F(3, 32))
check('diameter lower bound comparison', F(1, 2)**2 < F(1, 2))

# Symbolic power counting with N: rho=N^(-1/2).
check('rho/N is rho cubed', F(-1, 2)-1 == 3*F(-1, 2))
check('gap lower coefficient', F(1, 2)*F(1, 2) == F(1, 4))
# The inequality 1-exp(-x) >= x/(1+x) >= x/2 is justified in
# the written proof by exp(x)>=1+x and 0<x<1.
for x in (F(1, 100), F(1, 3), F(1, 2), F(9, 10)):
    check(f'rational part of gap bound x={x}', x/(1+x) >= x/2)

for N in (1, 2, 3, 5, 17):
    heights = [F(4*j+1, 4*N) for j in range(N)]
    check(f'cap count N={N}', len(heights) == N)
    for j, u in enumerate(heights):
        check(f'axis exponent interior N={N},j={j}', 0 < u < 1)
        if j+1 < N:
            check(f'exponent spacing N={N},j={j}', heights[j+1]-u == F(1, N))
    for j in range(N):
        start, stop = F(j, N), F(2*j+1, 2*N)
        check(f'upper excursion bounds N={N},j={j}', 0 <= start < stop <= 1)

# Exit-time arithmetic only: these sample parameters are not claimed
# to be the vertices of a square on a logarithmic spiral.
times = [F(1, 7), F(2, 5), F(3, 4), F(4, 5)]
forward, backward = 1-max(times), -min(times)
check('forward exit time', forward == F(1, 5))
check('backward exit time', backward == F(-1, 7))
for t in times:
    check(f'forward parameter remains in arm t={t}', 0 <= t+forward <= 1)
    check(f'backward parameter remains in arm t={t}', 0 <= t+backward <= 1)
check('forward endpoint attained', max(t+forward for t in times) == 1)
check('backward endpoint attained', min(t+backward for t in times) == 0)
check('forward exponent implies factor >=1/2', 0 <= forward <= 1)
check('backward exponent implies factor <=2', -1 <= backward <= 0)
check('repeated factor losses can vanish', F(1, 2)**10 == F(1, 1024))

output = '\n'.join([
    'v210 exact algebra and rational audit',
    f'PASS: {checks} checks',
    'Square residual: translation invariant and complex-linear covariant',
    'Common orbit-time motion lies in the square-residual kernel',
    'Formal action normalization: 3*pi/(8*log(2)), independent of N',
    'Nested-cap radial exponents and cubic gap scaling: PASS',
    'Endpoint-transfer exponent bounds: PASS',
    'No square search, square-free-arc claim, or interval certification.',
    'The flow first-exit argument and analytic inequalities are proved in the notes.',
])+'\n'
print(output, end='')
if '--write-results' in sys.argv:
    root = Path(__file__).resolve().parents[1]
    (root/'results/verification.txt').write_text(output)
