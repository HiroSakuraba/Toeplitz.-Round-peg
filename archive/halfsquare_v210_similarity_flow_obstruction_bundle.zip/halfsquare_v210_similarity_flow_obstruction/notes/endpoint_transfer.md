# An existing square can reach an endpoint without collapsing

Use the packet \(\sigma_N\) from the companion note.
Suppose four parameters \(\theta_j\in[0,2\pi N]\) give a square
of side \(s>0\). Its curve order is unrestricted.

Set
\[
t_+=2\pi N-\max_j\theta_j,\qquad
t_-=-\min_j\theta_j.
\]
Simultaneously shifting all four parameters by \(t\) preserves
the square for every \(t\in[t_-,t_+]\).
The side becomes
\[
s(t)=e^{-\lambda_Nt}s.
\tag{1}
\]

At \(t=t_+\), at least one vertex reaches the inner endpoint
\(\sigma_N(2\pi N)\). Since \(0\le t_+\le2\pi N\),
\[
\boxed{s/2\le s(t_+)\le s.}
\tag{2}
\]
At \(t=t_-\), at least one vertex reaches the outer endpoint
\(\sigma_N(0)\), and
\[
\boxed{s\le s(t_-)\le2s.}
\tag{3}
\]
All four vertices remain on the same actual arm throughout.
This is a positive conditional transport statement with a uniform
factor independent of the number of turns.

It does not produce the initial square.
It also does not remove the need to control repeated transfers:
after \(m\) steps each losing up to a factor \(1/2\), the lower
bound is only \(2^{-m}s\), which can tend to zero.

The useful conclusion is narrower. A square family on an exact
similarity packet need not terminate inside that packet; it can
carry a nonzero-size configuration to its endpoint. A global method
must keep track of what happens there rather than assume local
isolation. We have not constructed a continuation through arbitrary
packet junctions or established a bound on the accumulated size loss.
