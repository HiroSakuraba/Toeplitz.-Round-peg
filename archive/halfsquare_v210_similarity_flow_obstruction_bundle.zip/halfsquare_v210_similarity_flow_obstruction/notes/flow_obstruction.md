# Common similarity motion obstructs strict local crossing certificates

## 1. Setup

Let
\[
g_s(z)=z_*+e^{cs}(z-z_*),\qquad c\in\mathbb C,\quad c\ne0.
\tag{1}
\]
For every finite real \(s\), this is an orientation-preserving Euclidean
similarity with positive scale factor \(e^{(\Re c)s}\).

For \(j=0,1,2,3\), let a selected actual arc be the image of a finite
interval \([\alpha_j,\beta_j]\), \(\alpha_j<\beta_j\), under
\[
\gamma_j(t)=g_t(p_j).
\tag{2}
\]
Assume this parametrization is injective and nonconstant on the
interval. Logarithmic-spiral segments with \(\Re c\ne0\) satisfy this
automatically if \(p_j\ne z_*\).
Different arcs may lie on different orbits of the same flow.

Let the square residual be
\[
S_1=z_0-z_1+z_2-z_3,\qquad
S_2=-iz_0+z_1+iz_2-z_3.
\tag{3}
\]
Its real and imaginary parts form a continuous map
\(\mathcal S:\mathbb C^4\to\mathbb R^4\).
Residual zero is equivalent to
\((z_0,z_1,z_2,z_3)=(a+w,a+iw,a-w,a-iw)\).
The square is nondegenerate if \(w\ne0\).

## 2. Every interior square reaches a parameter boundary

**Theorem.** If \(t_j\in(\alpha_j,\beta_j)\) describe a nondegenerate
square on the four selected arcs, then the closed product
\(\prod_j[\alpha_j,\beta_j]\) contains a nondegenerate square on its
boundary.

**Proof.** Set
\[
s_+=\min_j(\beta_j-t_j)>0.
\]
For \(0\le s\le s_+\), all \(t_j+s\) remain in their intervals, and
\[
\gamma_j(t_j+s)=g_s(\gamma_j(t_j)).
\]
The four points thus remain a square, with side multiplied by
\(e^{(\Re c)s}>0\). At \(s=s_+\), at least one coordinate equals
its endpoint \(\beta_j\). The square is still nondegenerate and
lies on the product boundary. \(\square\)

The same proof applies to any bounded open parameter region \(U\)
whose closure is contained in the orbit-coordinate domain. Starting
from a square in \(U\), follow \(t+s(1,1,1,1)\) to its first exit.
Boundedness makes the exit time finite, and continuity gives a square
on \(\partial U\).

Consequently a bounded such region whose boundary has no square
cannot have an interior square. In particular, an ordinary nonzero
Brouwer degree on an isolating local region cannot be obtained here.
This assertion does not exclude methods that identify boundaries,
quotient a symmetry, or use relative or equivariant constructions.

## 3. Consequence for v209

The v209 criterion uses four reference-square rectangles and writes
the actual paths as
\[
\eta_j(u)=q_j+v_j a_j(u)+n_j b_j(u),\quad -1\le u\le1,
\]
with \(a_j(-1)=-T_j,\ a_j(1)=T_j\), and
\(|b_j|\le\varepsilon_j\).
The real square residual is exactly
\[
\mathcal S=Aa+Bb.
\]
If \(A\) is invertible, its preconditioned residual is
\[
G=a+Cb,\qquad C=A^{-1}B.
\]
The strict conditions
\[
T_i-\sum_j|C_{ij}|\varepsilon_j>0
\tag{4}
\]
give opposite strict signs for \(G_i\) on the two corresponding
parameter faces. They both exclude zeros on the entire boundary
and, by the multidimensional intermediate value theorem, force
an interior zero.

**Corollary.** Four finite orbit segments of (1) cannot satisfy the
v209 hypotheses together with geometric separation excluding a
coincident four-point configuration.

Indeed, v209 would supply an interior nondegenerate square and
exclude all boundary squares, contradicting §2.
Changing the orientation or speed of an injective arc parametrization
does not help: it preserves endpoints and the product boundary.

This statement holds for every choice of rectangle axes and widths.
It does not merely say that the most obvious tangent directions
give a singular matrix. If another choice makes \(A\) invertible,
at least one strict margin in (4), or another v209 hypothesis,
must fail.

## 4. Differential check

At a square on these smooth arcs, the simultaneous tangent motion
\[
(V(z_0),V(z_1),V(z_2),V(z_3)),\qquad
V(z)=c(z-z_*),
\]
lies in the kernel of the derivative of (3). In orbit-time coordinates,
the derivative annihilates \((1,1,1,1)\).
This recovers the rank loss expected from symmetry.

The finite endpoint argument is stronger than this derivative test:
it excludes the strict continuous crossing certificate even when
the rectangle axes do not match the tangents.

## 5. Scope

No existence or nonexistence of a square on a particular logarithmic
spiral is inferred. The result says that any square present belongs
to a movable family, so it cannot be isolated by the strict v209
face conditions on finite subarcs.

The original v209 theorem is unchanged. What fails is the proposal
to obtain one of its strict certificates from every concentration
packet using only winding, nesting, and gap size.

## 6. Consequence for approximating polygonal arcs

Suppose four paths \(\eta_{j,m}\) converge uniformly, with their
specified parametrizations, to four separated finite orbit segments
\(\eta_j\). Suppose they carry v209 certificates whose data converge:
\[
q_{j,m}\to q_j,\quad v_{j,m}\to v_j,\quad n_{j,m}\to n_j,\quad
T_{j,m}\to T_j>0,\quad\varepsilon_{j,m}\to\varepsilon_j.
\]
Assume the limiting local bases are independent, the limiting
longitudinal matrix \(A\) is invertible, and all margins are bounded
below by a common \(m_0>0\).
These assumptions are incompatible.

Indeed, inverse local coordinate matrices converge, so the path
coordinate functions \(a_{j,m},b_{j,m}\) converge uniformly.
Endpoint equalities, containment bounds, and the reference square
equations pass to the limit. Matrix inversion is continuous at the
invertible \(A\), so the limiting margins remain at least \(m_0\).
The separated limit arcs would thus have a strict v209 certificate,
contrary to §3.

This does not rule out certificates on individual polygonal
approximations. It says they cannot retain all the stated compactness,
conditioning, separation, and positive-margin properties in this
limit. Loss of a certificate is also not, by itself, loss of every
actual square.
