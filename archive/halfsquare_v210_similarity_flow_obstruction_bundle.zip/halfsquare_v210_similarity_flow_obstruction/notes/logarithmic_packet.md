# An exact concentration packet defeating strict extraction

## 1. The family

For an integer \(N\ge1\), define
\[
\rho_N=N^{-1/2},\qquad
\lambda_N=\frac{\log2}{2\pi N},\qquad
\sigma_N(\theta)=\rho_N e^{(-\lambda_N+i)\theta},
\quad 0\le\theta\le2\pi N.
\tag{1}
\]
It is a simple real-analytic arc: its radius decreases strictly
from \(\rho_N\) to \(\rho_N/2\), while its angle makes \(N\) turns.
Both endpoints lie on the positive real axis.

Its diameter \(d_N\) satisfies
\[
\frac32\rho_N\le d_N\le2\rho_N.
\tag{2}
\]
The upper bound follows from containment in the disk of radius
\(\rho_N\). For the lower bound, compare \(\theta=0\) and \(\theta=\pi\):
their distance is
\(\rho_N(1+2^{-1/(2N)})>\tfrac32\rho_N\).

Thus the packets shrink to a point. Formula (1) is an exact
similarity orbit for each fixed \(N\), even though its pitch
\(\lambda_N\) changes between packets.

## 2. A fixed amount of signed area

Close the arc by the real chord from \(\rho_N/2\) to \(\rho_N\),
and write \(\alpha=\tfrac12(x\,dy-y\,dx)\).
The chord contributes zero to the integral. Polar coordinates give
\[
\begin{aligned}
\mathcal A_N
&=\frac12\int_0^{2\pi N}\rho_N^2e^{-2\lambda_N\theta}\,d\theta\\
&=\frac{\rho_N^2(1-e^{-4\pi N\lambda_N})}{4\lambda_N}\\
&=\frac{3\pi N\rho_N^2}{8\log2}
=\boxed{\frac{3\pi}{8\log2}}.
\end{aligned}
\tag{3}
\]
This is the signed area of the closed chain, counting winding
multiplicity. The chain need not be a Jordan loop.
In particular
\[
\mathcal A_N/d_N^2\ge\frac{3\pi}{32\log2}\,N\longrightarrow\infty.
\tag{4}
\]

## 3. Depth \(N\) of actual same-sign lobes

Use the real axis as endpoint line.
For \(j=0,\ldots,N-1\), the upper excursion is
\(\theta\in[2\pi j,(2j+1)\pi]\).
Its domain after closing by the endpoint-line interval is
\[
D_j=
\{re^{i\phi}:0<\phi<\pi,\
0<r<\rho_Ne^{-\lambda_N(2\pi j+\phi)}\}.
\tag{5}
\]
Each excursion with its closing interval is a positively oriented
Jordan cap. The off-axis excursion arcs are disjoint actual
subarcs of \(\sigma_N\).

Equation (5) gives strict nesting
\[
D_0\supset D_1\supset\cdots\supset D_{N-1}.
\]
Every cap contains \(z_N=i\rho_N/4\), since its upper-axis radius
exceeds \(\rho_N/2\).
The lower excursions lie in the other half-plane and do not contain
\(z_N\). Decomposing the closed chain into its excursion caps shows
that its winding number at \(z_N\) is exactly \(N\).

These are the actual same-sign nested-lobe features used by the
v189 concentration argument; no homeomorphic approximation is used.

## 4. Two-sided cubic gap estimates

The positive imaginary-axis intersection of the \(j\)-th upper arc has
height
\[
y_j=\rho_N\,2^{-(j+1/4)/N},\quad j=0,\ldots,N-1.
\]
For adjacent upper arcs,
\[
y_j-y_{j+1}
=\rho_N2^{-(j+1/4)/N}(1-2^{-1/N}).
\tag{6}
\]
Let \(x=(\log2)/N\), so \(0<x<1\).
The elementary bounds
\[
x/2\le1-e^{-x}\le x
\]
follow, for example, from \(e^x\ge1+x\) and integration.
Also \(1/2<2^{-(j+1/4)/N}\le1\).
Using \(\rho_N/N=\rho_N^3\) in (6) gives, for \(N\ge2\),
\[
\boxed{\frac{\log2}{4}\rho_N^3
\le y_j-y_{j+1}\le(\log2)\rho_N^3.}
\tag{7}
\]
Because \(d_N\) and \(\rho_N\) are comparable, these are also
cubic-scale gaps in terms of the actual packet diameter.

## 5. Why the proposed extraction fails

For each \(N\), all subarcs of \(\sigma_N\) are finite segments of
the same flow
\[
g_s(z)=e^{(-\lambda_N+i)s}z.
\]
The obstruction theorem therefore prohibits a nondegenerate
strict v209 certificate on any four of its subarcs.

Equations (2), (3), (5), and (7) hold simultaneously. Hence the
following universal statement is false:

> Every sufficiently concentrated simple analytic packet with deep
> same-sign nested lobes and cubic actual-arc gaps contains four
> subarcs meeting the strict v209 crossing conditions.

This is stronger than the v209 example of four unrelated short arcs:
here the obstruction occurs on one connected high-winding packet
with the desired concentration estimates.

The model does not establish that it is realized as a radial-action
packet of a hypothetical square-free Jordan curve. Extra global
information from such a curve could still rule it out.
Nor does the model assert that its own arc contains no square.
The falsified conclusion is the strict local certificate.

The v189 note initially formulates its calculation for polygonal
arcs. The present analytic arcs satisfy the same smooth cap
decomposition and geometric conclusions. They are not literal
counterexamples to a statement restricted to polygons. For polygonal
approximations, §6 of the obstruction note instead proves the
precise failure of a uniformly persistent certificate.

## 6. Relation to finite-action logarithmic spirals

There is no conflict with the finite swept area of an infinite
logarithmic spiral of fixed pitch. Here the pitch is
\(\lambda_N\asymp1/N\), and tends to zero while the physical scale
shrinks. The fixed-pitch area constant grows like \(1/\lambda_N\);
that growth compensates for \(\rho_N^2\).
