# What should change after this obstruction

## 1. The result in plain language

We tried to get the four crossing pieces required by v209 from the
strong concentration properties already available in the program.
That attempted implication fails on a very regular example.

A logarithmic spiral repeats its shape when rotated and rescaled.
Consequently, any square sitting on it can slide along it while
remaining a square. On four finite selected pieces, that motion
eventually pushes a vertex to an endpoint.

The strict v209 test works by forbidding square solutions at all
such endpoints while forcing one in the interior. It therefore
cannot apply to these spiral pieces. Increasing the turn count,
action, nesting depth, or closeness of adjacent turns does not
repair the incompatibility.

This is not a counterexample to Toeplitz, or a disproof of v209's
sufficient theorem. It rules out the proposed universal way of
obtaining v209's hypotheses.

## 2. What remains useful

- v207 and v208 still force squares on their stated coil families.
- v209 remains a valid sufficient test when its actual crossing
  conditions can be established.
- v189's nesting conclusion is unaffected; the present model
  explicitly exhibits the nesting.
- The new endpoint-transfer lemma describes one way a square
  family can leave a packet while retaining positive size.
- For polygonal approximations, the compactness corollary specifies
  which simultaneous certificate controls cannot survive a limit
  to these orbit segments. It does not claim that polygons
  themselves lack certificates or squares.

The phase-rank exceptions recognized in v190 have reappeared in
a formulation that uses no phase function. Dropping phase notation
does not eliminate the underlying rotating-and-scaling symmetry.

## 3. A more appropriate next objective

Do not demand a strictly isolated square configuration in every local
packet. A method must also handle families that pass through packet
boundaries. Two possibilities deserve investigation:

1. Use both the interior and exterior of the same Jordan curve to
   obstruct such family motion.
2. Continue the family through adjacent pieces while retaining
   enough control to prevent all configurations from collapsing.

Neither objective is completed here. In the second, endpoint
existence and a per-step factor are insufficient: the accumulated
loss over infinitely many steps still needs a bound.
Any bookkeeping of boundary contributions must be defined and
proved compatible under changes of local coordinates and vertex order.

## 4. Existing global structure to retain

Hugelmeyer's 2023 preprint proves that a hypothetical square-free Jordan
curve has a square envelope: a moving square with two adjacent
vertices outside and two inside, with shrinking ends and a winding
condition. Its separate Spiral Conjecture is an assumption, not a
proved general reduction to logarithmic spirals.

This input was already used in v148; it is not a new discovery in v210.
It is relevant because it involves four simultaneous points and the
same Jordan domain. The present concentration model supplies neither
those global inside/outside constraints nor their winding condition.
Linking them to the packet geometry remains unproved.

Primary source checked: Cole Hugelmeyer,
[Inscribed Squares and Relation Avoiding Paths](https://arxiv.org/pdf/2301.01340),
Definition 1 and Theorem 1; distinguish its conjectural later steps.
No result from that paper is required for the obstruction proof.

## 5. Audit boundaries

The new proofs are self-contained apart from the standard
multidimensional intermediate value theorem used to restate v209.
The verifier checks square-residual covariance, the symmetry kernel,
exact formal coefficients in the area calculation, ordering of
radial exponents, and the algebra behind endpoint transfer.
The analytic inequalities and first-exit argument are proved in text.
No numerical search establishes square-freeness, and no such
square-freeness claim is made.

No new general class of Jordan curves is solved in this version.
The advance is a decisive test of a proposed proof route, replacing
an unsupported extraction hope with a precise obstruction.
