# v211 — Shape sphere and tangent escape

**Research program:** Benjamin John Schulz  
**Date:** 23 September 2026  
**Status:** Proved elementary geometric estimates and a proof-route audit. No solution of the general Toeplitz conjecture, and no claim of priority for configuration-space methods.

This continuation investigates the sphere idea while retaining physical size. Centered, normalized four-point configurations lie on S^5. All labeled square shapes form six circles there. The sphere separates shape from size; it does not prevent size from becoming zero.

The main useful estimate is the following. Let a square have center c and size rho, where rho is twice its circumradius. Suppose each vertex is within epsilon of a compact planar set Gamma. Fix p in Gamma and a line L through p, put

    R = |c-p| + rho/2 + epsilon,
    eta_p(R) = sup{dist(w,L): w in Gamma, |w-p| <= R}/R.

Then

    rho <= 2 sqrt(2) [eta_p(R) R + epsilon].

At a tangent point, eta_p(R) tends to zero. If approximation error is negligible compared with square size, collapsing squares must have |c-p|/rho tending to infinity. A tangent at the limiting point alone does not prevent collapse. An explicit Jordan graph in this bundle demonstrates that escape.

## Read in this order

1. [Physical coordinates and all square orders](notes/shape_sphere.md).
2. [Quantitative collapse theorem](notes/tangent_escape.md).
3. [Explicit tangent-point example](notes/tangent_graph_example.md).
4. [Approximation and the actual remaining proof target](notes/approximation_and_next_target.md).
5. [Audit, sources, and relation to previous versions](notes/provenance_and_limits.md).

Run `python3 code/verify_v211.py` from this directory. The standard-library verifier checks exact finite algebra, sharpness witnesses, and the graph construction. Analytic arguments are proved in the notes, not certified by the script.

The [two-scale graph illustration](figures/tangent_graph.svg) shows the explicit example. Its optional generator, code/draw_graph.py, requires matplotlib; the exact verifier does not.

This is a lean standalone continuation: no nested ZIPs, downloaded papers, superseded experiments, or duplicated historical bundles. Earlier valid results are summarized with their scope in the provenance note; their full proofs remain in the earlier bundles.
