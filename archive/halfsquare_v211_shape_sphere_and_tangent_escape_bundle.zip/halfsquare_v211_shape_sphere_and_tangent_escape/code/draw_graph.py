#!/usr/bin/env python3
"""Optional illustration generator; requires matplotlib, unlike the verifier."""
from pathlib import Path
import argparse
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()
parser.add_argument("--preview", help="Optional PNG output path")
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
(root / "figures").mkdir(exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "svg.fonttype": "none"})
fig, axs = plt.subplots(1, 2, figsize=(11, 4.6), gridspec_kw={"width_ratios": [1.25, 1]})
xy = [(-.025, 0), (0, 0)]
for n in range(9, 0, -1):
    a, r = 2**(-n), 2**(-3*n)
    xy.extend([(a-r, 0), (a-.8*r, .6*r), (a-.6*r, -.8*r),
               (a+.6*r, .8*r), (a+.8*r, -.6*r), (a+r, 0)])
xy.append((.68, 0))
axs[0].plot(*zip(*xy), color="#223344", lw=1.7)
axs[0].scatter([0], [0], c="#1a7c7d", s=35, zorder=4)
axs[0].annotate("Tangent point p", xy=(0, 0), xytext=(.035, -.105),
                arrowprops={"arrowstyle": "->", "color": "#1a7c7d"}, color="#1a7c7d")
a = 2**(-3)
axs[0].scatter([a], [0], facecolors="none", edgecolors="#8b3f9d", s=75, lw=1.3, zorder=5)
axs[0].annotate("Third square: center a₃", xy=(a, 0), xytext=(.055, .095),
                arrowprops={"arrowstyle": "->", "color": "#8b3f9d"}, color="#8b3f9d")
axs[0].set(xlim=(-.04, .69), ylim=(-.135, .135), xlabel="x", ylabel="y",
           title="The graph near the origin")
axs[0].set_aspect("equal", adjustable="box")
points = [(-1, 0), (-.8, .6), (-.6, -.8), (.6, .8), (.8, -.6), (1, 0)]
square = [(.6, .8), (-.8, .6), (-.6, -.8), (.8, -.6), (.6, .8)]
axs[1].plot(*zip(*points), color="#223344", lw=1.7, label="Curve")
axs[1].plot(*zip(*square), color="#8b3f9d", lw=1.5, ls="--", label="Square edges")
axs[1].scatter(*zip(*square[:-1]), color="#8b3f9d", s=25, zorder=5)
axs[1].set_aspect("equal")
axs[1].set(xlim=(-1.16, 1.16), ylim=(-1.08, 1.05), xlabel="(x − a₃) / r₃",
           ylabel="y / r₃", title="The same square, enlarged")
axs[1].legend(loc="lower center", ncol=2, fontsize=8, framealpha=.95, borderpad=.25)
for ax in axs:
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(alpha=.16)
fig.suptitle("A tangent point can have squares at much smaller nearby scales", fontsize=13, y=.98)
fig.text(.5, .035, "Here aₙ = 2⁻ⁿ, rₙ = 2⁻³ⁿ and ρₙ = 2rₙ.  The ratio |cₙ − p| / ρₙ = 2²ⁿ⁻¹ diverges.",
         ha="center", fontsize=10)
fig.subplots_adjust(bottom=.19, top=.84, wspace=.30)
fig.savefig(root / "figures" / "tangent_graph.svg", metadata={"Date": None})
if args.preview:
    fig.savefig(args.preview, dpi=140)
