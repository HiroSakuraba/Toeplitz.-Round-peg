#!/usr/bin/env python3
"""Finite exact checks for v211. Analytic proofs are in the notes."""
from fractions import Fraction as F
from itertools import permutations, combinations

count = 0
groups = []


def check(statement):
    global count
    if not statement:
        raise AssertionError(f"Check {count + 1} failed")
    count += 1


def group(name, start):
    groups.append((name, count - start))


def g(a=0, b=0):
    return (F(a), F(b))


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def neg(a):
    return (-a[0], -a[1])


def sub(a, b):
    return add(a, neg(b))


def mul(a, b):
    return (a[0]*b[0] - a[1]*b[1], a[0]*b[1] + a[1]*b[0])


def conj(a):
    return (a[0], -a[1])


def scale(a, s):
    return (a[0]*s, a[1]*s)


def total(a):
    out = g()
    for x in a:
        out = add(out, x)
    return out


def norm2(a):
    return a[0]*a[0] + a[1]*a[1]


def inner(a, b):
    return total(mul(x, conj(y)) for x, y in zip(a, b))


def vnorm2(a):
    return sum(map(norm2, a), F(0))


def centered(z):
    c = scale(total(z), F(1, 4))
    return c, tuple(sub(x, c) for x in z)


def residual(z):
    return (
        total(mul(a, b) for a, b in zip(z, (g(1), g(-1), g(1), g(-1)))),
        total(mul(a, b) for a, b in zip(z, (g(0, -1), g(1), g(0, 1), g(-1))))
    )


start = count
roots = (g(1), g(0, 1), g(-1), g(0, -1))
reps = []
for w in permutations(roots):
    if not any(all(w[j] == mul(a, r[j]) for j in range(4))
               for r in reps for a in roots):
        reps.append(w)
check(len(reps) == 6)
vectors = [tuple(scale(z, F(1, 2)) for z in w) for w in reps]
for v in vectors:
    check(total(v) == g() and vnorm2(v) == 1)
    check(sum(1 for w in permutations(roots)
              if any(all(w[j] == mul(a, scale(v[j], 2)) for j in range(4))
                     for a in roots)) == 4)
overlaps = []
for i, j in combinations(range(6), 2):
    d = norm2(inner(vectors[i], vectors[j]))
    check(d in (F(0), F(1, 4)))
    overlaps.append(d)
check(overlaps.count(F(0)) == 3 and overlaps.count(F(1, 4)) == 12)
group("six square circles and their separation", start)

start = count
v = vectors[0]
check(residual(v) == (g(), g()))
# Under centering and the first residual equation, q2=-q0,q3=-q1.
# The remaining residual is 2(q1-i*q0): verify this linear identity
# on a complex basis for the two free variables.
for a, b in ((g(1), g()), (g(0, 1), g()),
             (g(), g(1)), (g(), g(0, 1))):
    z = (a, b, neg(a), neg(b))
    check(residual(z) == (g(), scale(sub(b, mul(g(0, 1), a)), 2)))
# Off-line projection agrees with the residual after removing a*v.
samples = [
    (g(1, 2), g(-2, 1), g(3, -4), g(-2, 1)),
    (g(1), g(0, 1), g(-1), g(0, -1)),
    (g(1), g(1), g(-1), g(-1))
]
for z in samples:
    _, q = centered(z)
    a = inner(q, v)
    b = tuple(sub(qj, mul(a, vj)) for qj, vj in zip(q, v))
    check(inner(b, v) == g())
    check(vnorm2(q) == norm2(a) + vnorm2(b))
    check(residual(q) == residual(b))
group("linear residual and orthogonal splitting", start)

start = count
for v in vectors:
    for i, j in combinations(range(4), 2):
        # Use unnormalized n=e_i-e_j; n has squared norm 2.
        n = tuple(g(int(k == i) - int(k == j)) for k in range(4))
        coefficient = scale(inner(v, n), F(1, 2))
        p = tuple(sub(vk, mul(coefficient, nk)) for vk, nk in zip(v, n))
        gap = norm2(sub(v[i], v[j])) / 2
        check(p[i] == p[j] and total(p) == g())
        check(vnorm2(p) == 1-gap and gap in (F(1, 4), F(1, 2)))
        # p/||p|| attains the projection bound, without irrational arithmetic.
        check(norm2(inner(p, v)) / vnorm2(p) == 1-gap)
group("sharp repeated-point projection gaps", start)

start = count
for v in vectors:
    real = [x[0] for x in v]
    imag = [x[1] for x in v]
    check(sum(x*x for x in real) == F(1, 2))
    check(sum(x*x for x in imag) == F(1, 2))
    check(sum(x*y for x, y in zip(real, imag)) == 0)
    check(sum(real) == sum(imag) == 0)
    check(total(mul(x, x) for x in v) == g())
    p = tuple(g(x) for x in real)
    check(norm2(inner(p, v))/vnorm2(p) == F(1, 2))
group("collinearity and second-moment identities", start)

start = count
base = (g(1, 1), g(-1, 1), g(-1, -1), g(1, -1))
for a in (g(F(3, 5), F(4, 5)), g(0, 2), g(F(7, 3), F(-2, 3))):
    c = g(F(2, 7), F(-3, 11))
    z = tuple(add(c, mul(a, x)) for x in base)
    found_c, zz = centered(z)
    check(found_c == c and residual(z) == (g(), g()))
    check(vnorm2(zz) == 8*norm2(a))
    check(vnorm2(zz) ==
          sum(norm2(sub(z[i], z[j])) for i, j in combinations(range(4), 2))/4)
    check(norm2(sub(z[0], z[1])) == vnorm2(zz)/2)
# Sharp strip/error witness: physical corners (+/-1,+/-1), height=1.
c, zz = centered(base)
rho2 = vnorm2(zz)
check(rho2 == 8)
check(max(abs(z[1]) for z in base) == 1)
projected = tuple(g(z[0]) for z in base)
_, ww = centered(projected)
check(vnorm2(tuple(sub(w, z) for w, z in zip(ww, zz))) == 4)
check(projected[0] == projected[3] and projected[1] == projected[2])
check(F(1)/rho2 == F(1, 8))  # (epsilon/rho)^2 = 1/8.
group("physical scaling, strip sharpness and error scale", start)

start = count
for n in (1, 2, 3, 8, 20):
    a, r = F(1, 2**n), F(1, 2**(3*n))
    next_a, next_r = a/2, r/8
    check(r + next_r < a - next_a)
    check(0 < a-r < a+r < 1)
    ordered = [
        g(a-r, 0), g(a-4*r/5, 3*r/5), g(a-3*r/5, -4*r/5),
        g(a+3*r/5, 4*r/5), g(a+4*r/5, -3*r/5), g(a+r, 0)
    ]
    check(all(x[0] < y[0] for x, y in zip(ordered, ordered[1:])))
    check(max(abs(x[1]) for x in ordered) == 4*r/5)
    # Cyclic square order differs from increasing graph-x order.
    square = (ordered[3], ordered[1], ordered[2], ordered[4])
    c, z = centered(square)
    check(c == g(a) and residual(square) == (g(), g()))
    check(all(norm2(x) == r*r for x in z))
    check(vnorm2(z) == 4*r*r)
    check(all(norm2(sub(square[(j+1) % 4], square[j])) == 2*r*r
              for j in range(4)))
    check(a/(2*r) == F(2**(2*n), 2))
    check(4*r/(5*(a-r)) == F(4, 5*(2**(2*n)-1)))
group("explicit Jordan-graph squares and drift formulas", start)

print("v211 exact arithmetic verification")
for name, subtotal in groups:
    print(f"PASS {name}: {subtotal} checks")
print(f"PASS total: {count} checks")
print("Analytic proofs, compactness and limiting arguments are in notes/.")
print("These checks do not constitute a proof of general Toeplitz.")
