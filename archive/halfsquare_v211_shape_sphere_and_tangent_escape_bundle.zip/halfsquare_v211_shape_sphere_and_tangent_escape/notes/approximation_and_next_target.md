# Approximation, scale, and the next proof target

## 1. A quantitative transfer lemma

Let z_j be square vertices with size rho>0, and let w_j be any four points satisfying |w_j-z_j|<=epsilon. Write Z and W for their centered four-vectors and sigma=||W||. Orthogonal centering in C^4 gives
\[
\|W-Z\|\le2\epsilon,\qquad |\sigma-\rho|\le2\epsilon. \tag{1}
\]
If epsilon<rho/2, then sigma>0, and their normalized shapes satisfy
\[
\left\|\frac W\sigma-\frac Z\rho\right\|
\le\frac{4\epsilon}{\rho}. \tag{2}
\]
For (2), add and subtract W/rho, use (1), and bound
||W|| |1/sigma-1/rho|=|rho-sigma|/rho.

Choose the square labeling v so Z belongs to Cv. Orthogonal projection off this line yields the sharper residual estimate
\[
D_v(W/\sigma)\le
\left(\frac{2\epsilon}{\rho-2\epsilon}\right)^2. \tag{3}
\]
Indeed, the off-line part of W equals that of W-Z, and sigma>=rho-2epsilon.

If epsilon<rho/(2sqrt(2)), the w_j are distinct: the smallest separation of square vertices is rho/sqrt(2), and each pairwise separation changes by at most 2epsilon.

These estimates require no regularity of the set containing the w_j.

## 2. Which blow-up does an approximating square reach?

Let Gamma_n converge uniformly to a Jordan curve Gamma via parametrizations, with errors epsilon_n tending to zero. Let z_{n,j} be square vertices on Gamma_n and choose matching points w_{n,j} on Gamma. The error estimate holds automatically for such matched points.

If rho_n has a positive lower bound along a subsequence, compactness supplies an actual positive-size square on Gamma. This is the familiar noncollapse criterion.

Suppose instead rho_n->0.

* If epsilon_n/rho_n->0, (1)--(3) show that the actual Gamma-tuples have normalized shapes approaching the square target. After taking a subsequence of centers and shapes, the physical blow-up of Gamma itself contains a square shape at rho=0.
* If epsilon_n/rho_n is not small, uniform convergence alone makes no such deduction. One gets a square-shaped boundary point of the approximating family, but it has not been identified as a boundary point of the actual Gamma configuration set.

This distinction is essential. For example, the square with corners (+/-h,+/-h) is at distance h from a line, and projects to a collinear tuple with two repeated pairs. As h->0 the absolute approximation error vanishes, but its ratio to rho is the constant 1/(2sqrt(2)). Its normalized shape remains square while the projected tuple remains collinear. This is a local comparison example, not an assertion that a line is a Jordan curve or that these tuples are Abel approximants.

Uniform convergence of sets does not in general commute with normalization at a vanishing scale.

## 3. An explicit conditional contradiction

Take a Jordan domain and its Abel curves Gamma_r=f(rS^1), with
\[
\epsilon(r)=\sup_\theta|f(re^{i\theta})-f(e^{i\theta})|\to0.
\]
Use a square on each smooth Gamma_r, and denote its size and center by rho(r), c(r). One may choose a largest square, but that choice alone proves none of the estimates below.

Assume the boundary Gamma has no square. Then every such rho(r) tends to zero as r->1, by the compactness argument in section 2. After selecting a sequence, c(r_n)->p in Gamma.

The new local theorem would give a contradiction if one could establish, for that same sequence,
\[
\text{(i) }\eta_p(R)\to0,\qquad
\text{(ii) }\epsilon(r_n)/\rho(r_n)\to0,\qquad
\text{(iii) }\sup_n |c(r_n)-p|/\rho(r_n)<\infty.
\]
This is a conditional lemma, not a proof of any of (i)--(iii).

| Required fact | What is actually available here |
|---|---|
| Existence of squares on the smooth approximants | Known smooth square-peg theorem; already used in v206. |
| Their physical size tends to zero under square-freeness | Elementary compactness. |
| Their approximation error is negligible at that size | Not proved. Absolute error tending to zero is insufficient. |
| Their centers stay within a bounded multiple of their size from a limiting point | Not proved; the graph example rules out a purely pointwise-tangent justification. |
| A tangent or corresponding flatness at a selected limiting point | Not available for arbitrary Jordan curves. |
| A contradiction without the last three conditions | The unresolved general task. |

The six square circles, the complement retraction, and the collision gaps do not supply these missing facts.

## 4. Best next route after this audit

The sphere is useful as a fixed shape coordinate system. A proof still needs global information tying moving centers and scales to the same Jordan domain.

The most relevant retained global input is Hugelmeyer's square-envelope theorem: a hypothetical square-free Jordan curve admits an envelope of squares with prescribed adjacent inside/outside vertices, shrinking ends, and a winding condition. The theorem and its separate conjectural steps must be kept distinct. This was already part of v148 and the v210 research reset.

A concrete next investigation is to take such an envelope, express it as (c(t),rho(t),q(t)), and determine whether the inside/outside data force a nontrivial boundary contribution that survives both:

1. center drift |c-p|/rho -> infinity;
2. changes of scale whose accumulated loss is unbounded.

The envelope vertices are not all on Gamma. They cannot be inserted into the present epsilon estimate with epsilon=0. Any such application must first prove actual proximity of the relevant vertices to Gamma, at the scale of the square.

There is a sharp local obstruction to obtaining that improvement from the inside/outside labels alone. Let Gamma be the boundary of the rectangle [-1,1] times [-1,0], with p=(0,0). For 0<h<1/4 take the square with corners (+/-h,+/-h). Its upper two adjacent vertices are outside the rectangle, its lower two are inside, and its center is p. Every vertex is at distance exactly h from Gamma, while rho=2sqrt(2)h. Thus
\[
\epsilon/\rho=1/(2\sqrt2),\qquad |c-p|/\rho=0.
\]
All relevant boundary points lie on a straight segment, so eta_p(R)=0, and the tangent estimate is saturated. Such locally labeled squares can shrink indefinitely.

This example is not a counterexample to the square-envelope theorem: the rectangle has squares, and no global winding condition has been imposed on this local family. It shows exactly why the global winding or continuation information is indispensable.

This is a research target, not a claimed relative-degree theorem. The current work does not construct a conserved boundary charge or exclude envelope escape.

For the alternate energy route, the v206 requirement remains:
\[
E_n\ge0,\quad E_0<\infty,\quad
E_{n+1}\le E_n-\delta+e_n,\quad
\delta>0,\quad \sum_ne_n<\infty.
\]
A shape-only function is constant along any family c_n+rho_n v with fixed v. It cannot by itself control rho_n. Nor does a bound on rate of energy change give the stated irreversible decrement.

The v210 common-similarity-flow obstruction also remains relevant: one cannot universally demand isolated local square configurations with square-free parameter boundaries. The global method must allow square families and account for their exits.
