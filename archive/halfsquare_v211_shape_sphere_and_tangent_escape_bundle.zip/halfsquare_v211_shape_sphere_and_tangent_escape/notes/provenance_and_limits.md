# Provenance, checks, and limitations

**Research program:** Benjamin John Schulz.  
**Continuation:** v211, 23 September 2026.

## What this version establishes

The notes give direct proofs of the following elementary statements:

1. Physical center, size, and normalized shape coordinates; six square circles for all labelings.
2. An explicit deformation retraction onto S^3 for the complement of one square circle.
3. Exact repeated-point and collinearity defect gaps.
4. A sharp strip estimate and its tangent-collapse consequences.
5. Quantitative transfer of square shape under vertex perturbation.
6. A fully specified Jordan graph differentiable at the origin, with squares at successively smaller nearby scales and unbounded center-to-size ratio.

These are additions to the program's explicit toolbox and audit. They are not asserted to be new to the mathematical literature. The strip and projection arguments are elementary. No general new class of Jordan curves is proved square-bearing by this version.

## Relation to retained work

| Earlier work | What remains useful |
|---|---|
| v192, physical collisions before Möbius normalization | Exact square collapse first reaches the physical total diagonal. Here that statement is quantified using rho and shape defects. |
| v206, Liouville-frontier review | Global contradiction skeleton and the missing action-to-square or irreversible-budget implication. |
| v207, finite-coil square forcing | Actual squares on the specified linear-radius spiral arms, including the preserved-arm finite-coil construction. |
| v208, distorted coils | Stated fixed-linear and local C^1 perturbation results with their hypotheses. |
| v209, four-arc certificate | A valid sufficient theorem when its strict crossing hypotheses hold. |
| v210, common similarity flow | Obstruction to universally extracting that strict certificate from concentration packets; conditional endpoint transfer does not prevent infinite scale loss. |
| v148 and v210, square envelopes | A global inside/outside structure worth retaining; the later spiral claims are not supplied as theorems. |

This ZIP does not reproduce those full proofs. It is a standalone continuation for its own results, not a replacement archive for every earlier valid theorem.

## Primary literature checked

* Jason Cantarella, Elizabeth Denne, John McCleary, *Configuration Spaces, Multijet Transversality, and the Square-Peg Problem*, Illinois J. Math. 66(3), 385--420 (2022), [arXiv:2103.07506v2](https://arxiv.org/abs/2103.07506v2).
  The abstract explicitly requires boundary-disjointness in its compactified-configuration transversality result. This establishes that configuration compactification is an existing method, not a new solution supplied by placing shapes on a sphere. The local proofs here do not invoke that transversality theorem.
* Cole Hugelmeyer, *Inscribed Squares and Relation Avoiding Paths*, [arXiv:2301.01340](https://arxiv.org/pdf/2301.01340), Definition 1 and Theorem 1.
  The square-envelope input and its distinction from the separate Spiral Conjecture were checked in v210. No claim from that paper is required to prove the v211 geometric estimates.

The earlier Asano--Ike analysis is inherited from v206--v208; no new inference about Liouville regularity is needed here. In particular, the explicit graph example is not advertised as outside the already solved classes.

## What the verifier does

The standard-library Python script uses rational complex arithmetic. It checks the six-circle enumeration and pairwise inner products; the linear square residual kernel; exact projection witnesses for repeated-point gaps; real/imaginary orthogonality for the collinearity gap; representative scale/rotation identities; the sharp strip and error-scale examples; and the graph's square identities and interval estimates.

The script does not prove Cauchy--Schwarz, deformation-retraction continuity, limiting implications, compactness, or the Jordan property. Those arguments are in the text. Finite checks of the graph formulas supplement the all-n proofs; they do not substitute for them.

## Explicitly unproved

* A positive physical size bound for squares on arbitrary Abel approximants.
* Negligible approximation error relative to selected square size.
* Control of moving centers from a tangent at a single limiting point.
* General boundary-disjointness for wild Jordan curves.
* A global envelope charge, an irreversible collision budget, or a theorem transferring arbitrary Liouville-action failure into an actual square.
* The general Toeplitz square-peg conjecture.

No numerical absence-of-squares claim is made. The exact graph example contains squares and serves only to falsify an overly strong local compactness claim.
