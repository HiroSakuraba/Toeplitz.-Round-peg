# Physical shape coordinates and the square target

All points below are in the Euclidean plane identified with C. The construction is a change of coordinates for configurations, not a stereographic change of the physical plane.

## 1. Retain center and size

For a labeled tuple z=(z_0,z_1,z_2,z_3) which is not totally coincident, define
\[
c=\frac14\sum_jz_j,\qquad
\rho^2=\sum_j|z_j-c|^2,\qquad q_j=(z_j-c)/\rho.
\]
Then
\[
q\in S(V),\quad V=\{q\in\mathbb C^4:\sum_jq_j=0\},\quad
S(V)\cong S^5.
\]
Conversely z_j=c+rho q_j. This is an exact bijective coordinate change for rho>0. Translation and positive scaling disappear from q; physical rotation acts by multiplying all q_j by the same complex unit.

For a square, rho is twice the circumradius and its side is rho/sqrt(2).
The identity
\[
\rho^2=\frac14\sum_{i<j}|z_i-z_j|^2
\]
also shows that rho can tend to zero only when all physical vertices coalesce. Partial collisions can occur at positive rho, but cannot themselves be square configurations.

## 2. Six circles, not one

Put v=(1,i,-1,-i)/2. For this particular labeling, the normalized square shapes are
\[
\Sigma_v=\{e^{i\theta}v:\theta\in\mathbb R\}.
\]
Allowing every vertex order gives six distinct complex lines and hence six disjoint circles on S^5. Representatives, before division by 2, are
\[
\begin{array}{llll}
(1,i,-1,-i), &(1,i,-i,-1), &(1,-1,i,-i),\\
(1,-1,-i,i), &(1,-i,i,-1), &(1,-i,-1,i).
\end{array}
\]
Indeed, there are 24 permutations and exactly four in each phase orbit. Representatives are unique after fixing their first entry to 1. A non-root-of-unity phase cannot identify two permutations, as is already seen from their first entries.

Use the Hermitian product <q,v>=sum q_j conjugate(v_j). Define
\[
D_v(q)=1-|\langle q,v\rangle|^2,\qquad
D(q)=\min_{v\text{ among the six}}D_v(q).
\]
Equality in Cauchy--Schwarz gives D_v=0 precisely on Sigma_v. Thus D=0 is the square condition for every physical ordering. The order in which four points occur along a Jordan curve need not be their cyclic order around the square.

For distinct representatives, squared inner products are 0 or 1/4. The minimum Euclidean distance between their circles is respectively sqrt(2) or 1, since
\[
\min_{\alpha,\beta}|e^{i\alpha}v-e^{i\beta}w|^2
 =2-2|\langle v,w\rangle|.
\]
The all-order target is therefore a separated six-component set.

## 3. The complement for one labeling is the familiar S^3 target

Write q=a v+b with b orthogonal to v. Outside Sigma_v, b is nonzero, and
\[
H_t(q)=
\frac{(1-t)a v+b}
{\sqrt{(1-t)^2|a|^2+\|b\|^2}},\qquad 0\le t\le1,
\]
is a strong deformation retraction of S^5 minus Sigma_v onto the unit S^3 in the complex two-dimensional space v-perp intersect V.

This is the normalized square residual in orthogonal coordinates. For example, on V the complex linear map
\[
K(q)=\big(q_0-q_1+q_2-q_3,\;-iq_0+q_1+iq_2-q_3\big)
\]
has kernel Cv. Its restriction to v-perp intersect V is an invertible map to C^2. Composing this linear identification with normalization identifies the two S^3-valued tests.

The statement concerns the complement of one circle. We do not claim that the complement of all six circles retracts onto one S^3. Nor does this retraction provide a new degree or a boundary-disjointness theorem for a wild curve.

## 4. Exact gaps from partial collision and collinearity

**Repeated-point gap.** If q_i=q_j and ||q||=1, then
\[
D_v(q)\ge\frac{|v_i-v_j|^2}{2}.
\]
To prove this, put n=(e_i-e_j)/sqrt(2), so q is orthogonal to n. The squared norm of the orthogonal projection of v onto n-perp is 1-|<v,n>|^2. Apply Cauchy--Schwarz in that hyperplane. The projection is in V, so the bound is attained by its normalization.

For adjacent vertices in the labeling of v, the gap is 1/4; for opposite vertices it is 1/2. Consequently any tuple with a repeated point satisfies D(q)>=1/4, even when every square order is allowed.

**Collinearity gap.** If the centered normalized tuple is collinear, write q=e^{i phi}x, where x is real, sum x_j=0 and ||x||=1. The real and imaginary parts of every v above are orthogonal real vectors, each of squared norm 1/2. Therefore
\[
|\langle q,v\rangle|^2\le1/2,\qquad D(q)\ge1/2.
\]
This is sharp: normalize the real part of v. The distance between a square circle and the collinear locus in S^5 is sqrt(2-sqrt(2)).

An equivalent measure of deviation from collinearity is
\[
M(q)=\sum_jq_j^2,\qquad
\min_\phi\sum_j\big(\operatorname{Im}(e^{-i\phi}q_j)\big)^2
=\frac{1-|M(q)|}{2}.
\]
This follows by expanding each imaginary part squared. Collinear tuples have |M|=1, while squares have M=0. The converse "M=0 implies square" is false: for example, a centered equilateral triangle together with its center also has M=0 after normalization.

## 5. What compactification retains

For a compact curve Gamma, take the closure of the image of Gamma^4 minus the total diagonal under z -> (c,rho,q). This closure is compact: c is in the compact convex hull, rho is bounded by 2 diam(Gamma), and q is in S^5.

The added points with rho=0 have c in Gamma and record normalized directions of actual four-point collapse. They need not be collinear at a merely pointwise differentiable limiting point: the example in this bundle proves this explicitly.

This is a blow-up of the physical total diagonal, retaining only the common shape at that scale. It is not a full compactification resolving every nested partial collision. Such a resolution may require further coordinates.

No square at rho=0 is a positive-size inscribed square. For instance, c=p, rho_n->0 and q=v is a convergent ambient configuration sequence. Its constant shape supplies no lower bound on rho. Those ambient tuples are not asserted to lie on any specified curve.
