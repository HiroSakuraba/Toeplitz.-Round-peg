# A quantitative theorem for collapsing squares

## 1. Hypotheses and sharp inequality

Let Gamma be a nonempty compact subset of the plane, p in Gamma, and L an affine line through p. For R>0 define the one-sided flatness at p by
\[
\eta_p(R)=\frac1R\sup_{w\in\Gamma\cap\overline B(p,R)}
\operatorname{dist}(w,L).
\]
Let z_0,...,z_3 be an exact nondegenerate Euclidean square with center c and size rho=(sum |z_j-c|^2)^(1/2). Suppose dist(z_j,Gamma)<=epsilon for all j. Set
\[
R=|c-p|+\rho/2+\epsilon.
\]
Then
\[
\boxed{\rho\le2\sqrt2\,\big(\eta_p(R)R+\epsilon\big).} \tag{1}
\]

**Proof.** Compactness supplies w_j in Gamma with |z_j-w_j|<=epsilon. Each w_j is within R of p, because |z_j-c|=rho/2. Hence every z_j is at distance at most h=eta_p(R)R+epsilon from L.

Write a square of side s as c+(s/2)(+/-u +/-v), with u,v orthonormal. Its width in a unit normal direction n is
\[
s\big(|\langle u,n\rangle|+|\langle v,n\rangle|\big)\ge s.
\]
The strip of points within h of L has width 2h. Thus s<=2h; substituting s=rho/sqrt(2) proves (1).

The strip constant is sharp. A square with corners (+/-h,+/-h) and L the horizontal axis has rho=2sqrt(2)h. This verifies sharpness of the geometric estimate; it is not a construction of Abel approximants.

## 2. Why a nonzero tangent gives eta_p(R)->0

Suppose Gamma is a Jordan curve with a local parametrization gamma(t_0)=p differentiable at t_0 and gamma'(t_0)=u nonzero. Take L=p+Ru.

For t near t_0,
\[
\gamma(t)-p=(t-t_0)u+o(|t-t_0|).
\]
Consequently dist(gamma(t),L)/|gamma(t)-p| tends to zero. The inverse homeomorphism on the compact Jordan curve ensures that points of Gamma sufficiently near p have parameter near t_0. Taking a supremum over the ball proves eta_p(R)->0.

Only differentiability at t_0 is needed for this conclusion. Continuity of derivatives on a neighborhood is a stronger condition and is not silently assumed.

## 3. Two ways a square can collapse near a tangent point

Suppose c_n->p, rho_n->0 and epsilon_n->0, with the hypotheses of (1), and suppose eta_p(R)->0. Put
\[
\alpha_n=\epsilon_n/\rho_n,\qquad
\beta_n=|c_n-p|/\rho_n,\qquad
R_n=\rho_n(\beta_n+1/2+\alpha_n).
\]
Then
\[
1\le2\sqrt2\big[\eta_p(R_n)(\beta_n+1/2+\alpha_n)+\alpha_n\big]. \tag{2}
\]

**Corollary A: negligible approximation error forces center drift.**
If alpha_n->0, then beta_n->infinity.

Indeed, a bounded subsequence of beta_n would make the right-hand side of (2) tend to zero on that subsequence, a contradiction.

**Corollary B: bounded center drift forces a definite error ratio.**
If beta_n is bounded, then
\[
\liminf_n\alpha_n\ge\frac1{2\sqrt2}. \tag{3}
\]
If the liminf were smaller, take a subsequence on which alpha_n tends to a finite value smaller than the displayed constant, and pass to the limit in (2).

These statements are not an exhaustive alternative for arbitrary oscillating sequences without subsequence selection. Equation (2) is the general quantitative assertion.

For an actual square on Gamma, epsilon=0. If eta_p(R)>0, (2) gives
\[
\frac{|c-p|}{\rho}\ge\frac1{2\sqrt2\,\eta_p(R)}-\frac12. \tag{4}
\]
If eta_p(R)=0, no positive square satisfying the hypotheses exists.

More generally, for alpha<=a<1/(2sqrt(2)), a positive eta gives the useful lower bound
\[
\beta\ge
\frac{1-2\sqrt2\,a}{2\sqrt2\,\eta_p(R)}-\frac12-a. \tag{5}
\]

## 4. Moving centers are the real local obstruction

Define a flatness number centered at the actual square center, allowing the approximating line to move:
\[
b_\Gamma(c,r)=\frac1r\inf_{\text{affine lines }L}
\sup_{w\in\Gamma\cap\overline B(c,r)}\operatorname{dist}(w,L).
\]
For r=rho/2+epsilon the same strip proof gives
\[
b_\Gamma(c,r)\ge
\frac{\rho/(2\sqrt2)-\epsilon}{\rho/2+\epsilon}. \tag{6}
\]
The bound may be negative for large epsilon and then says nothing.
If epsilon/rho->0 along a square sequence, its moving-center flatness has liminf at least 1/sqrt(2).

This is compatible with eta_p(R)->0 at a fixed limiting point: the moving radii can be much smaller than |c-p|. A tangent controls the view from p, not every finer view around nearby centers.

Uniform flatness tending to zero over those moving centers and radii would contradict (6). No such uniform flatness is established here for arbitrary Jordan curves, and imposing it would restrict the curve class.
