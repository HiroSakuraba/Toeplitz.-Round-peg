# A tangent point with squares in every neighborhood

This elementary example is independent of the earlier spiral theorems. It prevents the incorrect inference that a tangent at a collapse point forces all normalized four-point limits to be collinear.

## Construction

For n>=1 set
\[
a_n=2^{-n},\qquad r_n=2^{-3n},\qquad I_n=[a_n-r_n,a_n+r_n].
\]
These closed intervals are disjoint and lie inside (0,1). In fact
\[
r_n+r_{n+1}=(9/8)2^{-3n}
 <2^{-n-1}=a_n-a_{n+1}.
\]
On each I_n define a continuous piecewise linear function g whose graph, in increasing x order, passes through the six points
\[
\begin{array}{ll}
(a_n-r_n,0),&
(a_n-4r_n/5,\phantom{-}3r_n/5),\\
(a_n-3r_n/5,-4r_n/5),&
(a_n+3r_n/5,\phantom{-}4r_n/5),\\
(a_n+4r_n/5,-3r_n/5),&
(a_n+r_n,0).
\end{array}
\]
Set g=0 on the rest of [-1,1].

Because the heights tend to zero at the only accumulating intervals, g is continuous everywhere. On I_n,
\[
|g(x)|\le4r_n/5,\qquad
\left|\frac{g(x)}x\right|
\le\frac{4r_n}{5(a_n-r_n)}\longrightarrow0.
\]
Outside those intervals the ratio is zero. Thus g is differentiable at 0 and g'(0)=0.

Close the graph from (-1,0) to (1,0) by the three segments
\[
(1,0)\longrightarrow(1,-1)\longrightarrow(-1,-1)
\longrightarrow(-1,0).
\]
Since |g|<=1/10, this gives a Jordan curve Gamma, and p=(0,0) is an interior point of its graph arc with horizontal nonzero tangent. The corners elsewhere cause no problem; no global C^1 assertion is made.

## Actual squares and their scales

Four of the listed graph points have offsets from (a_n,0)
\[
\frac{r_n}{5}(3,4),\quad
\frac{r_n}{5}(-4,3),\quad
\frac{r_n}{5}(-3,-4),\quad
\frac{r_n}{5}(4,-3).
\]
Successive offsets are related by a quarter-turn, so these are actual Euclidean square vertices on Gamma. Their circumradius is r_n, their side is sqrt(2)r_n, and their configuration size is rho_n=2r_n.

Consequently
\[
c_n=(a_n,0)\to p,\qquad \rho_n\to0,\qquad
\frac{|c_n-p|}{\rho_n}=2^{2n-1}\longrightarrow\infty.
\]
Their normalized shapes are constant, up to the chosen fixed labeling, and lie on a square circle in S^5. Thus the actual configuration blow-up over a point with a nonzero tangent can contain square shapes.

There is no approximation error: epsilon_n=0. This is exactly the escape allowed by the quantitative theorem. It disproves a proposed local exclusion principle, not the Toeplitz conjecture; the curve already has many squares.

The order of these four points along the graph is different from their cyclic square order. This also illustrates why retaining all six labeled square circles matters.

## Relation to the earlier coils

The finite-coil scales in v207 have the same location/size disparity, a_n=2^-n and r_n=2^-3n. Its coil square theorem therefore fits the same mechanism. That older result remains stronger in its own direction: it produces squares on long spiral arms and applies to the stated non-Liouville-regular construction. The present graph example needs none of that analytic machinery and makes no claim about failure of Liouville regularity.
