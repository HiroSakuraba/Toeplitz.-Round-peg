# Extremal Geometry Lab handoff

Current baseline: v2.0c

Implemented in this step:
- replaced trim-region diversified beam grouping with a support-signature geometric diversity key
- the new key is built from centered support samples plus coarse scale and shape-ratio buckets
- diversified beam search now separates rounded non-polygon descendants from purely polygonal cut families using geometry-facing data rather than move labels
- added a demo sweep under `results/certificates/v2_0c_demo_lebesgue_support_signature_beam_sweep/`

Most important consequence:
- Lebesgue beam diversity is now based on coarse support geometry rather than trim-parameter regions

Recommended next step:
1. extend export bundles into fully self-verifying certificates for rounded candidates
2. prototype exact small-LP Helly-style infeasibility pruning in rigid-box refinement
3. compress local LP certificates down to minimal active-contact data
