# Extremal Geometry Lab handoff

Current baseline: v2.0c

Implemented in this step:
- certified width prescreen for Lebesgue candidates
- optional robust-interval LP branch for rotation refinement (`lp_mode="robust-interval"`)
- default sampled/HiGHS path remains the baseline
- width prescreen now exercised through the family-screen API and exported as a small demo certificate bundle
- robust-interval mode now has a non-optional fallback validation path through the default LP backend
- Lebesgue proposal generation can now use the width prescreen directly during bounded search

Notes:
- the robust-interval LP path is opt-in and dependency-optional
- CVXPY/Clarabel are not required for the default stack

# Handoff: Extremal Geometry Lab v2.0a

This repository is a proof-oriented scaffold for three extremal-geometry programs:
- Lebesgue universal covering
- Moser's worm
- restricted Hadwiger / illumination in 3D

## What the repository now does well
The core is now genuinely support-native rather than only polygon-sampled.
It includes:
- shared geometric types,
- 2D polygon Minkowski sums,
- support-function-native 2D/3D bodies,
- support-fit LP placement,
- rigidity checks via thickening,
- sampled and interval-certified containment checks,
- interval rigid-motion refinement in 2D,
- exportable joint coexistence certificates for witness families.

## What changed through v1.5

### v0.7
- Added interval-valued rigid-motion certificates in 2D support fitting.
- Certified feasible rotation intervals now export derived translation boxes.

### v0.8
- Added `mpmath.iv`-backed interval support-gap certification for polygon-backed 2D bodies.
- Kept Lipschitz support-gap certification as the generic fallback when no polygon proxy exists.
- Support-fit LP solves now expose whether the result came from `scipy-highs` or vertex enumeration.
- Revised the 3D roadmap: centrally symmetric bodies are the computational first lane; constant-width bodies are the theorem-strong lane.

### v0.9
- Added a first native interval branch-and-bound in rigid-motion space `(theta, t_x, t_y)` via `refine_body_in_body_support_rigid_2d`.
- A rigid-motion box can now be certified feasible directly, rather than only by deriving a translation box from a center pose.
- Added midpoint-drift infeasibility pruning for rigid-motion boxes.
- Added a constant-support fallback in the box certifier, which materially improves disk/ball-style witnesses.

### v1.0
- Added stable certificate export for native rigid-motion refinement.
- Export bundles now include a machine-readable JSON schema, a human-readable markdown summary, and per-cell support-bound audits for an exported feasible box.
- Added a deterministic demo exporter under `scripts/export_demo_rigid_motion_certificate.py`.
- Materialized a first sample bundle under `results/certificates/v1_0_demo_rigid_motion_bundle.{json,md}`.

### v1.1
- Added an interval-support cache to reduce repeated enclosure work in joint rigid-motion refinement.
- The cache reports hit/miss statistics in the refinement `best_pose.details["support_cache"]`.
- Added a witness-family bundle exporter that writes per-witness rigid-motion bundles plus a top-level summary.
- Added `scripts/export_demo_witness_family_bundle.py` and a sample artifact under `results/certificates/v1_1_demo_witness_family_bundle/`.

### v1.2
- Upgraded witness-family export into an actual joint coexistence certificate.
- The exporter now writes `coexistence.{json,md}` containing a product-space feasibility region built from one certified feasible rigid-motion box per witness.
- Canonical per-witness box selection is deterministic: smaller certified upper violation first, then smaller widths.
- The top-level certificate is honest about scope: it certifies independent witness pose feasibility in one common container, not non-overlap among witnesses.

## What is certified now
There are now three distinct 2D certificate types.

1. **Rotation-first certificate**
   - classify a rotation interval,
   - optionally derive a translation box from the center-pose residual margin.

2. **Native rigid-motion box certificate**
   - directly classify a box in `(theta, t_x, t_y)`,
   - certify that **every** pose in that box is feasible when marked feasible.

3. **Witness-family coexistence certificate**
   - choose one certified feasible rigid-motion box for each witness,
   - certify the Cartesian product of those boxes in the independent witness pose variables.

The third object is now the correct proof-facing replacement for the earlier witness-family scaffold.

## Current limitations
- The joint rigid-motion refinement is still conservative.
- The feasible-box proof path is strongest for polygon-backed bodies and constant-support bodies.
- Non-polygon, non-constant-support witnesses still rely on Lipschitz fallback bounds inside the box certifier.
- Witness-family coexistence is certified in the product of independent pose spaces, but not yet with witness--witness non-overlap constraints.
- No 3D analogue of the native rigid-motion box certifier exists yet.

## Recommended development order from here
1. Tighten non-polygon support-interval bounds so the joint box certifier is less dependent on Lipschitz fallback.
2. Build actual Pál-descended and hard-worm witness sets on top of the new coexistence export layer.
3. Add witness--witness non-overlap constraints only where the domain truly needs simultaneous packing rather than independent cover feasibility.
4. In 3D, implement centrally symmetric support families first, then add constant-width constraints `h(u)+h(-u)=w`.

### v1.3
- Added a certified width prescreen for Lebesgue candidates.
- Added an optional robust-interval LP branch for rotation refinement.
- Kept the sampled/HiGHS path as the default baseline.

### v1.4
- Exercised the width prescreen through the family-screen API and exported a demo certificate bundle.
- Added non-optional fallback-path validation for robust-interval LP mode using the default LP backend.

### v1.5
- Added proposal-search screening hooks so bounded search can prune candidates before scoring and expansion.
- Added `domains.lebesgue.search_with_width_prescreen(...)` as the first domain-level use of those hooks.
- Added `scripts/export_demo_lebesgue_prescreened_search.py` and a sample artifact under `results/certificates/v1_5_demo_lebesgue_prescreened_search/`.

### v1.6
- Proposal search now uses screen slack as the first ordering key, followed by proxy score.
- In the Lebesgue lane, accepted descendants are therefore ranked by certified width slack rather than only area proxy.
- Added `scripts/export_demo_lebesgue_ranked_sweep.py` and a sample artifact under `results/certificates/v1_6_demo_lebesgue_ranked_sweep/`.


### v1.7
- Added an optional `beam_width` cap to bounded search.
- Slack-aware ordering now affects which branches survive frontier truncation, not just display order.
- Added `domains.lebesgue.search_with_width_prescreen(..., beam_width=...)` and `scripts/export_demo_lebesgue_beam_sweep.py`.


### v1.8
- Added a diversified beam policy to bounded search.
- The beam can now reserve slots for geometrically distinct trim-parameter regions instead of collapsing entirely onto the single highest-slack trim family.
- Added `domains.lebesgue.search_with_width_prescreen(..., beam_policy="diversified", beam_diversity_reserve=...)`.
- Added `scripts/export_demo_lebesgue_diversified_beam_sweep.py` and a sample artifact under `results/certificates/v1_8_demo_lebesgue_diversified_beam_sweep/`.


## v2.0 implementation started

Implemented first roadmap slice:
- analytic interval-support hooks for non-polygon 2D bodies
- exact interval support for disks, segments, ellipses, and capsule-style arc/segment bodies
- cache/certifier now use support hooks before Lipschitz fallback
- export bundles now include a self-verifying rigid-motion certificate recipe

Still not done:
- arc-replaced Pál candidates are not yet wired into the Lebesgue move family
- Helly-style pruning and geometric support-signature diversity remain future steps


## v2.0b rounded arc/segment Lebesgue candidates
- The Lebesgue family no longer records arc replacements as stubs only.
- Search now generates rounded candidates built from a polygon cut plus a disk Minkowski summand, with analytic interval-support bounds composed through the sum.
- Prescreening uses the body-level support hook for these states, while scoring and canonicalization use a reconstructed polygon surrogate.
- This is the first point where the v2.0 analytic interval machinery is exercised by the actual Lebesgue search lane.

### v2.0c
- Replaced trim-region diversified beam grouping with a support-signature geometric diversity key.
- The diversity key is built from centered support samples together with coarse scale and shape-ratio buckets, so it distinguishes rounded non-polygon descendants from purely scaled polygon cuts.
- Added `scripts/export_demo_lebesgue_support_signature_beam_sweep.py` and a sample artifact under `results/certificates/v2_0c_demo_lebesgue_support_signature_beam_sweep/`.


### v2.0d
- added self-verifying rounded-candidate certificate bundles for the Lebesgue lane
- rounded candidate exports now include base-polygon vertices, rounding radius, and a replay recipe for the width prescreen


## v2.0d self-verifying rounded-candidate bundles
- Added certificate exports for rounded Lebesgue candidates that are self-verifying at the width-prescreen level.
- Export payloads now carry the base cut-polygon vertices, rounding radius, rounded-candidate construction metadata, polygon surrogate vertices, and a replay recipe.
- Demo bundles live under `results/certificates/v2_0d_demo_lebesgue_rounded_self_verify/`.
- This closes the portability gap for rounded-candidate prescreen claims, but does not yet make the full rigid-motion theorem layer self-contained.
