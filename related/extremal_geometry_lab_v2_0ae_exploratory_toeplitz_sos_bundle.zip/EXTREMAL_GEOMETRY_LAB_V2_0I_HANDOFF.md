# Extremal Geometry Lab v2.0i handoff

## Main upgrade

v2.0i strengthens the **contact-side structure signal** used by the Lebesgue search lane.

Previous status (v2.0h):
- the contact signal was built from a **single unit-segment probe**
- the hybrid diversified beam could combine support-signature geometry with that contact signal
- but the contact side remained coarse at shallow depth

New status (v2.0i):
- the default contact signal now uses a **small probe library**
- default probes:
  - `segment`
  - `orbiform-stub`
  - `disk-half`
- `structure_signal="contact"` and `structure_signal="hybrid"` now annotate each screened proposal with a **combined probe-library contact signature**

## What changed in code

### Witness layer
- `domains/lebesgue/witnesses.py`
  - added `probe_witness_library()`
  - `reduced_witness_family()` now delegates to the same probe set

### Contact metrics
- `domains/lebesgue/family.py`
  - added `DEFAULT_CONTACT_PROBE_NAMES`
  - generalized `contact_signature_metrics(...)` to support any probe in the library
  - added `contact_probe_library_metrics(...)`
  - added `contact_probe_library_key(...)`

### Search annotations and priorities
- `make_contact_structure_annotator(...)`
  - now computes:
    - a primary single-probe signature (still segment-based for readability)
    - a combined probe-library signature for search behavior
  - new annotation fields include:
    - `contact_probe_library`
    - `contact_probe_signature`
    - `contact_probe_key_count`
    - `contact_total_cardinality`
    - `contact_algebraic_probe_count`
- `proposal_contact_priority_key(...)`
  - now rewards contact structure across the full probe library, not only one witness
- `proposal_hybrid_priority_key(...)`
  - updated similarly
- `proposal_contact_diversity_key(...)`
  - now defaults to the combined probe-library key when annotations are absent
- `search_with_width_prescreen(...)`
  - added `contact_probe_names=...`
  - default is the full probe library

## What this achieves

With the old segment-only contact signal, the depth-1 diversified contact beam can collapse to a single contact key even when multiple descendants survive.

With the new probe-library signal, the same sweep preserves **more contact-key variety** without changing the accepted move set.

## Demo artifact

See:
- `results/certificates/v2_0i_demo_lebesgue_probe_library_contact_sweep/`

The comparison currently shows:
- segment-only unique contact keys: `1`
- probe-library unique contact keys: `2`

So the contact side is now strictly more discriminating, even though this small sweep still keeps the same three accepted depth-1 descendants.

## Validation performed here

Focused validation completed on the impacted slice:
- new contact-probe-library metric test
- new annotation metadata test
- new segment-only vs probe-library comparison test
- existing Lebesgue contact/hybrid search tests
- demo export replay for the new probe-library comparison bundle

## What this does **not** claim

- This is **not** a theorem-grade contact classification.
- The probe library is still a heuristic structure signal for beam priority/diversity.
- It does not replace the support-signature side of the hybrid beam.
- It does not yet use a full witness family or an epsilon-net witness reduction.

## Recommended next step

Now that the contact signal has a small probe library, the next clean move is:

> use the **witness-net scaffold** as a search/exact-screen bridge,
> so candidate covers can be checked against a finite normalized witness set,
> with exported pass/fail ledgers and coexistence summaries.

That is the next place where the current search/proof bridge can become more theorem-facing without pretending to have a full finite-witness reduction yet.
