# Extremal Geometry Lab v2.0j handoff

## Main upgrade

v2.0j turns the **witness-net scaffold** into a real **search / exact-screen bridge** for the Lebesgue lane.

Previous status (v2.0i):
- the witness-net scaffold existed only as a standalone finite normalized family export
- it was not yet wired into candidate screening or bundled exact-style checks

New status (v2.0j):
- candidate covers can now be screened against a finite normalized witness set
- the bridge exports:
  - a top-level **pass/fail witness ledger**
  - a nested **witness-family coexistence bundle**
  - explicit witness-net metadata (resolution note, incomplete-family status)

## What changed in code

### Witness-net bridge layer
- `domains/lebesgue/witness_net.py`
  - added `WitnessNetScreenResult`
  - added `witness_bodies_from_net(...)`
  - added `screen_candidate_state_against_witness_net(...)`
  - added `predicate_from_witness_net_scaffold(...)`
  - added `export_candidate_witness_net_bundle(...)`
  - added refine-kwarg normalization so older `initial_intervals` callers still work

### Domain exports
- `domains/lebesgue/__init__.py`
  - re-exported the new witness-net bridge helpers

### Demo artifact
- added `scripts/export_demo_lebesgue_witness_net_bridge.py`
- generated:
  - `results/certificates/v2_0j_demo_lebesgue_witness_net_bridge/`

## What the bridge means

Given a candidate cover state `state`, the bridge:
1. builds (or accepts) a finite normalized witness net
2. converts each witness polygon into a support-native body
3. runs rigid-motion refinement witness-by-witness inside the candidate cover
4. records:
   - whether each witness has a certified feasible box
   - whether each witness refinement classified all boxes
5. exports the joint product-space coexistence summary across the finite witness family

So this is now a real **finite-family exact-screen bridge**, not just a witness list.

## What the top-level summary exports

The top-level `summary.json` now includes:
- `schema_version = lebesgue-witness-net-bridge.v1`
- `state_name`
- `container_name`
- `witness_count`
- `joint_certified`
- `passed_witness_count`
- `failed_witness_count`
- `coverage_certificate`
- `hausdorff_resolution`
- `joint_coexistence_path = witness_family/coexistence.json`
- per-witness ledger entries

## Demo artifact

See:
- `results/certificates/v2_0j_demo_lebesgue_witness_net_bridge/`

In the current demo configuration:
- witness count: `4`
- coverage status: `incomplete-family`
- joint certified: `False`

That is the **correct** result for the current shallow demo refinement settings. The value of the bridge is the exported ledger/coexistence structure, not that the shallow demo already passes.

## What this does **not** claim

- This is **not** a full epsilon-net theorem certificate.
- The witness family remains an explicit scaffold with an incomplete-family warning.
- Passing the bridge would only certify the current finite normalized family, not the full class of diameter-1 convex bodies.
- The bridge does not yet feed back into beam priority or proposal expansion directly.

## Recommended next step

Now that the witness-net scaffold is a real search / exact-screen bridge, the next clean move is:

> use the bridge results as a **structure-aware screening signal** inside search,
> for example by ranking candidates by finite witness pass count / certified coexistence status,
> rather than using the bridge only as a post-search bundle export.

That would be the first time the finite-family bridge directly shapes the proposal frontier.
