# Extremal Geometry Lab v2.0k handoff

## Main upgrade

v2.0k feeds the **finite witness-net bridge back into search** as an actual structure-aware signal.

Previous status (v2.0j):
- the witness-net scaffold had become a real finite-family screen / export bridge
- but it only existed as a **post-search** bundle export
- search itself did not use finite witness pass/fail information when ranking or diversifying proposals

New status (v2.0k):
- Lebesgue search now supports:
  - `structure_signal="witness-net"`
  - `structure_signal="hybrid-witness-net"`
- these signals annotate screened proposals with a **quick-fit finite witness-net summary**
- beam priority / diversification can now depend on finite-family behavior, not only width slack, support-signature geometry, or contact structure

## Important semantic distinction

v2.0k intentionally separates two layers:

### 1. Rigorous finite-family bridge (unchanged from v2.0j)
Implemented in `domains/lebesgue/witness_net.py`:
- per-witness rigid-motion refinement
- exported pass/fail ledgers
- exported product-space coexistence summary
- explicit `incomplete-family` warning

This remains the theorem-facing finite-family scaffold.

### 2. Search-time witness-net signal (new in v2.0k)
Implemented in `domains/lebesgue/family.py`:
- a **quick-fit** finite witness-net heuristic used only for proposal annotation / ranking
- this avoids making search pay the full cost of rigid witness-net refinement for every live proposal

So the new search signal is **derived from the same finite witness family idea**, but it is not pretending to be the full rigorous bridge.

## What changed in code

### Lebesgue family / search signal
- `domains/lebesgue/family.py`
  - added `quick_witness_net_metrics(...)`
  - added `quick_witness_net_key(...)`
  - added `proposal_witness_net_diversity_key(...)`
  - added `proposal_witness_net_priority_key(...)`
  - added `proposal_hybrid_witness_net_diversity_key(...)`
  - added `proposal_hybrid_witness_net_priority_key(...)`
  - added `make_witness_net_structure_annotator(...)`
  - extended `search_with_width_prescreen(...)` with:
    - `structure_signal="witness-net"`
    - `structure_signal="hybrid-witness-net"`
    - `witness_net_max_vertices`
    - `witness_net_include_reduced_family`
    - `witness_net_refine_kwargs` (used here as lightweight fit kwargs)

### Domain exports
- `domains/lebesgue/__init__.py`
  - re-exported the new witness-net search-signal helpers

### Demo artifact
- added `scripts/export_demo_lebesgue_witness_net_search_signal.py`
- generated:
  - `results/certificates/v2_0k_demo_lebesgue_witness_net_search_signal/`

## Search-time annotation payload

For proposals using the new signal, annotations now include:
- `witness_net_key`
- `witness_net_signal_mode = quick-fit`
- `witness_net_witness_count`
- `witness_net_passed_witness_count`
- `witness_net_failed_witness_count`
- `witness_net_all_passed`
- `witness_net_failed_labels`
- `witness_net_passed_labels`
- `witness_net_margin_signature`
- `witness_net_min_margin_bucket`
- `witness_net_coverage_status`
- `witness_net_hausdorff_resolution`

These are used as beam signals only.

## Demo behavior

See:
- `results/certificates/v2_0k_demo_lebesgue_witness_net_search_signal/`

On the small demo sweep:
- **support-signature diversified beam** keeps descendants centered around the previous geometric signal
- **witness-net diversified beam** shifts the frontier toward branches with better quick finite-family witness behavior
- **hybrid-witness-net beam** blends both, keeping support-signature variety while also respecting the finite-family quick signal

In the current demo comparison:
- support descendants include `small-arc-rounding`
- witness-net descendants promote `small-corner-cut` and `heavy-arc-rounding`
- hybrid witness-net keeps a mixed frontier combining support and finite-family quick structure

## What this does **not** claim

- The new search signal is **not** a theorem certificate.
- It does not replace the full witness-net bridge from v2.0j.
- `witness_net_all_passed=True` in a search annotation means only:
  > all quick-fit witnesses in the current finite scaffold passed the lightweight search-time check.
- The rigorous finite-family bundle export is still the correct artifact to cite for theorem-facing finite-family results.

## Recommended next step

Now that finite witness-net behavior influences search, the next clean move is:

> let the rigorous witness-net bridge and the quick witness-net signal communicate more directly,
> e.g. promote selected search winners into exported finite-family bridge bundles automatically,
> or use failed-witness identity to suggest targeted cover moves.

That would close more of the loop between search heuristics and theorem-facing exported evidence.
