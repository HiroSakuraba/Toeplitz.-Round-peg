# Extremal Geometry Lab v2.0n handoff

## What changed

v2.0n reduces the amount of hand-written witness-targeting logic in the Lebesgue lane.

The search system already had:
- quick witness-net annotations,
- cluster summaries,
- contact summaries,
- targeted follow-up moves.

In v2.0m those targeted moves were still driven primarily by a small set of hand-written
cluster/contact rules.

In v2.0n the move policy is upgraded to use a **finite witness ledger summary** directly.

## Main upgrade

The witness-net annotator now exports ledger-derived guidance fields:
- `witness_net_cluster_stats`
- `witness_net_driver_clusters`
- `witness_target_move_specs`
- `witness_target_move_source = "witness-ledger"`

The new `witness_target_move_specs` are derived from the finite witness ledger itself.
Each spec is a small machine-readable move recipe containing:
- target class (`triangle`, `square`, `net-heavy`)
- source cluster (`needle`, `pointy`, `broad`, `round`)
- severity (`safe`, `mild`, `moderate`, `severe`)
- cut amount
- rounding radius when applicable

`witness_targeted_moves(...)` now prefers those ledger-derived move specs.
Older cluster/contact fallback behavior is still supported so earlier annotations do not break.

## Why this matters

This is a cleaner search--proof bridge.

Instead of saying:
> if failed witness labels look triangle-like, inject triangle-targeted moves

v2.0n says:
> summarize the finite witness ledger into cluster pressure and severity,
> derive move specs from that ledger,
> then replay those move specs inside the proposal-aware move generator.

So the guidance is still heuristic, but it is now **ledger-derived** rather than mostly label-driven.

## New demo artifact

The bundle includes:
- `results/certificates/v2_0n_demo_lebesgue_ledger_targeted_moves/`

This compares witness-net search with:
- targeted follow-up moves disabled
- ledger-derived targeted follow-up moves enabled

The exported summaries show:
- the accepted descendants,
- the ledger-derived move specs attached to each accepted proposal,
- which targeted descendants are introduced by the guided policy.

## Validation performed here

Focused validation target set:
- `tests/test_lebesgue_search_prescreen.py`
- `tests/test_domains.py`
- `tests/test_witness_net_scaffold.py`
- `tests/test_smoke.py`

Collected tests in that set: `32`.

Additional direct checks performed:
- demo export generation for `v2_0n_demo_lebesgue_ledger_targeted_moves`
- inspection that accepted guided descendants include `targeted-*` moves introduced by the ledger-derived policy

## Current scope

This is still a **search heuristic** upgrade.
It does **not** change the theorem-level status of the finite witness-net scaffold.

The witness-net bridge remains:
- useful as a finite normalized witness-family screen,
- exportable as a pass/fail ledger and coexistence summary,
- explicitly marked as `incomplete-family`, not a full epsilon-net theorem certificate.

## Next clean move

Use the ledger-derived witness results to build a **small reusable move-policy table** keyed by
cluster severity and contact summary, then score those suggested moves against the existing beam
rather than always appending them directly.
