# Extremal Geometry Lab v2.0x handoff

## Main upgrade

v2.0x turns the recent bridge fixes into a single **cascaded rigid refinement** architecture.

The key principle is now explicit:

> inherit certified coarse feasible structure and refine only inside it,
> rather than restarting the rigid search globally at each higher-resolution rung.

This generalizes the earlier bridge fixes:
- v2.0t translation-box warm start,
- v2.0v localized deepening near seeded feasible regions,
- v2.0w rotation-interval seeding.

## What changed in code

### Core rigid refinement
- `packages/extremal_geometry_lab/core/rigid_fit.py`
  - added `cascaded_rigid_refinement(...)`
  - added explicit seed-propagation helpers for:
    - translation bounds from prior certified boxes,
    - theta seed boxes from rotation refinement / prior rigid boxes,
    - incomplete-region concentration tests,
    - stage provenance payloads
  - upgraded `refine_body_in_body_support_rigid_2d(...)` with:
    - `initial_theta_boxes`
    - `anisotropic_seed_spans`
  - added anisotropic split priority based on seeded feasible-box geometry

### Bridge policy
- `packages/extremal_geometry_lab/certificates/bridge_policy.py`
  - added `BRIDGE_CASCADE_LEVELS`
  - added `bridge_cascade(...)`
  - added `sticky_locked_priority_score(...)`

### Certificate payloads
- `packages/extremal_geometry_lab/certificates/formats.py`
  - rigid refinement bundles now export cascade-stage provenance when present:
    - `cascaded_refinement`
    - `cascade_stage_count`
    - `cascade_stage_records`
    - `cascade_priority_hypothesis`
    - `cascade_witness_priority_score`
  - witness-family export can now use `cascade_stages` instead of a single rigid stage

### Scripts
- `scripts/export_tier_b2_real_bridge.py`
  - updated to pass cascade stages via `bridge_cascade(...)`
- `scripts/export_tier_b2a_seed_bridge_calibration.py`
  - updated to use `cascaded_rigid_refinement(...)`

## New search / bridge-side logic

### 1. Cascaded refinement
A bridge/export run may now use an explicit stage sequence such as:
- `light`
- `light -> real`
- `light -> real -> confirm`

Each later stage inherits only the geometrically relevant region from the previous stage.

### 2. Per-stage provenance
Every cascaded rigid refinement now records, per stage:
- stage name
- stage parameters
- seed source
- input seed-box count
- input theta-seed count
- output box counts
- promotion decision and reason

### 3. Anisotropic splitting
Rigid-box splitting no longer uses only the raw largest-width axis.
If seeded feasible-box spans are available, split priority is normalized by those spans so the refiner spends more effort along the relatively unresolved direction.

### 4. Local escalation rule
Promotion to the next stage now occurs only when at least one of the following is true:
- the current stage found certified feasible boxes, or
- the unresolved region is concentrated enough to justify local refinement, or
- the optional sticky/locked-contact priority heuristic says the witness deserves fine confirmation.

### 5. Sticky = locked contact remains heuristic only
The new witness-priority score is **search-side only**. It does not alter any proof predicate.
Its role is only to decide which witnesses deserve finer cascade stages when the rigid search is still locally ambiguous.

## Demo / verification snapshot

A focused demo bundle was exported at:
- `results/certificates/v2_0x_demo_cascade_segment/`

This verifies that the rigid-refinement certificate payload now carries the cascade provenance fields.

## Honest scope

This upgrade changes only:
- search ordering,
- seed propagation between stages,
- stage escalation policy,
- per-stage provenance export.

It does **not** change:
- interval support-gap predicates,
- rigid-box feasible / infeasible classification rules,
- witness-fit truth conditions,
- certificate meaning.

## Recommended next step

The next clean move is a **small bridge batch under the new cascade policy** that measures:
- which witnesses terminate at `light`,
- which need `real`,
- which, if any, need `confirm`,
- and whether anisotropic splitting materially reduces explored-box counts on the hard witnesses.
