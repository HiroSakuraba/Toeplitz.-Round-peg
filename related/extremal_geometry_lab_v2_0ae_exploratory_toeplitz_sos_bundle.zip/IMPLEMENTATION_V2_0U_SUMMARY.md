# Extremal Geometry Lab v2.0u — formalized rigid seed derivation and bridge ladder

## What changed

This revision implements Step 1 and Step 2 of the v2.0t-next plan.

### 1. Formalized rigid seed derivation
The rigid bridge/export lane now centralizes rotation-stage seed consumption through:
- `derive_rigid_seed_from_rotation_fit(...)`

Current precedence when explicit `translation_bounds` are not supplied:
1. padded certified translation box from the rotation stage,
2. otherwise a padded best-pose neighborhood when sampled margin is positive,
3. otherwise global auto-bounds.

### 2. Standardized bridge ladder levels
Added:
- `packages/extremal_geometry_lab/certificates/bridge_policy.py`

with explicit levels:
- `light`
- `real`
- `confirm`

and helpers:
- `bridge_refine_kwargs(...)`
- `bridge_ladder_sequence(...)`

### 3. Script updates
The following bridge/export scripts now use explicit ladder levels rather than ad hoc tuples:
- `scripts/export_tier_b2_real_bridge.py`
- `scripts/export_tier_b2a_seed_bridge_calibration.py`
- `scripts/export_demo_lebesgue_witness_net_bridge.py`

### 4. Metadata expansion
The rigid refiner now records seed-selection metadata including:
- `rotation_seed_available`
- `rotation_seed_kind`
- `rotation_seed_center`
- `rotation_seed_radius_x`
- `rotation_seed_radius_y`
- `rotation_seed_margin`
- `rotation_seed_box_count`

## Correctness boundary
This revision does **not** change:
- interval predicates,
- rigid-box feasible / infeasible classification,
- witness-fit truth conditions,
- certificate semantics.

It changes only:
- rigid seed selection,
- exported seed metadata,
- bridge/export script configuration.

## Verification
Focused checks completed:
- new seed-derivation helper tests,
- explicit bridge ladder tests,
- existing warm-start and explicit-bounds rigid-refinement tests,
- Python compile checks for the updated modules/scripts.

Passing focused tests:
- `tests/test_bridge_policy.py`
- `tests/test_joint_interval_rigid_refinement.py::test_derive_rigid_seed_from_rotation_fit_uses_best_pose_neighborhood_when_box_missing`
- `tests/test_joint_interval_rigid_refinement.py::test_derive_rigid_seed_from_rotation_fit_can_disable_rotation_seed_consumption`
- `tests/test_joint_interval_rigid_refinement.py::test_joint_interval_refinement_warm_starts_from_rotation_seed_box_for_seed_triangle`
- `tests/test_joint_interval_rigid_refinement.py::test_joint_interval_refinement_preserves_explicit_translation_bounds_source`

The updated witness-net bridge demo script also ran and wrote:
- `results/certificates/v2_0t_demo_lebesgue_witness_net_bridge/`

## Next recommended move
The next clean move is Step 3 from the plan:
- localized deepening near seeded feasible regions,
- with lower priority or a shallower depth cap for rigid boxes that are far from the inherited seed.
