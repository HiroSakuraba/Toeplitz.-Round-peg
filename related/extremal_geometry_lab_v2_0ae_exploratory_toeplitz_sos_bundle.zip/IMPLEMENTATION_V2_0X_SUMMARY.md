# Extremal Geometry Lab v2.0x implementation summary

Implemented:
- cascaded rigid refinement as an explicit wrapper over the existing rigid refiner
- stage provenance export in rigid certificate payloads
- anisotropic split priority from seeded feasible-box geometry
- local escalation based on certified-feasible boxes or concentrated incomplete regions
- a search-side sticky/locked-contact witness-priority heuristic for fine-stage escalation
- bridge-policy cascade helpers and script wiring

Focused verification:
- selected bridge-policy / cascaded-refinement / rigid-refinement tests completed without reported failures in this environment
- exported demo bundle: `results/certificates/v2_0x_demo_cascade_segment/bundle.json`
- the demo bundle contains the new cascade provenance fields
- segment light spot-check: `64 feasible / 0 infeasible / 0 unresolved`, cascade stage count `1`
- regular-3-gon light spot-check: `0 feasible / 60 infeasible / 12 unresolved`, cascade stage count `1`

Correctness boundary unchanged:
- interval predicates
- rigid-box feasible/infeasible classification
- witness-fit truth conditions
- certificate semantics
