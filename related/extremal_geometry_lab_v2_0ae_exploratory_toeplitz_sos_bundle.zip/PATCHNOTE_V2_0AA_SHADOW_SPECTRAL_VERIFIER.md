# Patch note — v2.0aa shadow spectral verifier

## Main addition

This revision adds a **shadow spectral verifier** as a dual-path cross-check for sampled fixed-`theta` structures coming out of the repaired cascade lane.

It does **not** replace the current proof layer.

## New code

- `packages/extremal_geometry_lab/core/spectral_shadow.py`
  - sampled Fourier support extraction
  - sampled fixed-`theta` support-gap Fourier models
  - LP-based translation fit at fixed `theta`
  - shadow margin report `truncated_gap_margin - tail_sup_proxy`
  - cascade-to-spectral cross-check helper

- `tests/test_spectral_shadow.py`
  - disk Fourier sanity check
  - nested-disk shadow verifier check
  - rigid-refinement cross-check plumbing check

- `scripts/export_demo_shadow_spectral_verifier.py`
  - focused demo on the Pál seed with `orbiform-stub` and `disk-half`

## New docs

- `docs/SHADOW_SPECTRAL_VERIFIER.md`
- `docs/HANDOFF.md` updated with a new v2.0aa section
- `paper/extremal_geometry_lab_design.tex` updated with a new v2.0aa section
- `README.md`, `docs/API_MAP.md`, `docs/PACKAGE_MAP.md`, and `docs/NEXT_STEPS.md` updated

## Focused demo result

The new focused demo artifact lives under:
- `results/certificates/v2_0aa_demo_shadow_spectral_verifier/`

Current focused outcome:
- `orbiform-stub`: Lane A `certified_feasible`, Lane B `shadow-supportive`
- `disk-half`: Lane A `certified_feasible`, Lane B `shadow-supportive`

## Important boundary

The current shadow verifier is exploratory:
- sampled tail proxies are not yet rigorous truncation bounds,
- there is no PSD/SOS certificate yet,
- and the angle variable is still owned by the interval/cascade lane.

So this patch adds a **cross-check and debugging lane**, not a new proof backend.
