# Patch note — v2.0ab shadow batch and maturity ladder

## What changed

This patch extends the shadow spectral lane from a focused two-witness demo into a batch disagreement detector.

### Code
- strengthened `packages/extremal_geometry_lab/core/spectral_shadow.py`
- added contact-direction comparison utilities
- added disagreement-taxonomy summarization
- expanded pose reports to include:
  - width prescreen status
  - Helly/LP status
  - sampled-gap margin at explicit pose
  - sampled-gap margin at LP translation
  - LP translation shift norm
  - contact-direction overlap diagnostics

### Tests
- updated `tests/test_spectral_shadow.py`
- verified the strengthened shadow lane and taxonomy logic

### Docs
- updated `docs/SHADOW_SPECTRAL_VERIFIER.md`
- updated `docs/NEXT_STEPS.md`
- updated `docs/HANDOFF.md`
- updated `paper/extremal_geometry_lab_design.tex`
- updated `README.md`

## New batch artifact

- `results/certificates/v2_0ab_shadow_disagreement_batch/summary.md`
- `results/certificates/v2_0ab_shadow_disagreement_batch/summary.json`

Batch scope:
- states: `pal-seed`, `small-cut`, `moderate-cut`, `small-arc-rounding`
- witnesses: `orbiform-stub`, `disk-half`, `segment`, `regular-3-gon`, `regular-4-gon`

## Current batch result

In the current witness-state matrix:
- Lane A is `certified_feasible` in all 20 checked cases
- Lane B is `shadow-supportive` in all 20 checked cases
- disagreement ledger count: `0`
- disagreement histogram: `{'agreement-feasible': 20}`

This does **not** promote Lane B to proof-facing status.
It means the current shadow lane is now acting as a stable cross-check over the repaired cascade outputs for this first batch.

## Maturity ladder

The docs now make the shadow-lane maturity explicit:
- `S0`: sampled support-gap only
- `S1`: width + Helly/LP + sampled-gap comparison
- `S2`: sampled Fourier shadow check with disagreement batch
- `S3`: exploratory fixed-theta PSD/SOS backend
- `S4`: certified PSD/residual verification with rigorous truncation control

Current status: between `S1` and `S2`.

## Interpretation

The dual pipeline is now in the right shape:
- Lane A continues to own certified motion-space claims.
- Lane B is now strong enough to serve as a structured disagreement detector.
- The next mathematically meaningful step is still rigorous truncation control for round / arc-based witness classes, not a premature proof replacement claim.
