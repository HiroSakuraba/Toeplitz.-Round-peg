# Patch note — v2.0ac shadow tension batch and first real truncation module

This patch pushes the dual pipeline past the easy-feasible batch and into a boundary-stress regime.

## What changed

### 1. First real truncation module in the shadow spectral lane

The old sampled tail proxy in `core/spectral_shadow.py` has been replaced, for shadow-lane purposes, by a real truncation object that combines:
- observed grid tail,
- observed coefficient tail beyond the retained Fourier order,
- a simple extrapolated tail term.

Current modes:
- `empirical-k2-tail-envelope` for round / regular witness classes,
- `observed-tail-plus-grid` for the sharper segment lane.

This is still exploratory rather than theorem-grade rigorous, but it is a genuine truncation module rather than a single sampled remainder number.

### 2. Translation-tension stress construction

Added tension-pose construction in `core/spectral_shadow.py`.

For a fixed certified seed pose, the exporter now builds:
- `certified-seed-pose`
- `near-boundary-feasible`
- `negative-control`

The derived poses are created by shifting translation along the sampled minimum-gap direction. This gives a controlled way to stress the dual pipeline near the feasible / infeasible boundary.

### 3. Tension batch exporter

Added:
- `scripts/export_shadow_tension_batch.py`

Result bundle:
- `results/certificates/v2_0ac_shadow_tension_batch/summary.md`
- `results/certificates/v2_0ac_shadow_tension_batch/summary.json`

## Batch scope

States:
- `pal-seed`
- `small-cut`
- `moderate-cut`
- `small-arc-rounding`

Witnesses:
- `orbiform-stub`
- `disk-half`
- `segment`
- `regular-3-gon`
- `regular-4-gon`

Each state / witness pair contributes:
- the repaired-cascade seed pose,
- one near-boundary feasible pose,
- one explicit negative control.

## Result summary

Base repaired-cascade cases:
- `20 / 20` Lane A feasible and Lane B shadow-supportive.

Tension poses:
- `60` total.

By class:
- `certified-seed-pose`: `20 / 20` `shadow-truncation-positive`
- `negative-control`: `20 / 20` `shadow-inconclusive`
- `near-boundary-feasible`:
  - `12 / 20` `shadow-truncation-positive`
  - `8 / 20` `sampled-feasible-with-helly`

Truncation-module usage:
- `empirical-k2-tail-envelope`: `48`
- `observed-tail-plus-grid`: `12`

The informative holdouts are the near-boundary `orbiform-stub` and `regular-3-gon` cases. Those are exactly the kinds of cases where truncation still needs tightening before any stronger spectral claim would be credible.

## Interpretation

This patch establishes that the dual pipeline is now genuinely useful as a cross-check:
- it stays positive on easy feasible seed poses,
- it rejects explicit negative controls,
- and it exposes a small, interpretable truncation-limited frontier instead of simply agreeing everywhere.

That is the correct outcome for a shadow lane at this stage.
