# Patch note — v2.0ad high-k tail-fit truncation fix

## What changed

This patch replaces the round/regular shadow-lane truncation estimator

- from: all-`k` `k^{-2}` envelope (`empirical-k2-tail-envelope`)
- to: high-`k` tail-fit envelope with a conservative monotone cap (`high-k-k2-tail-envelope-monotone-cap`)

The batch harness itself was left unchanged. The same `60` tension poses were rerun so the delta is attributable to the truncation estimator alone.

## Decision tree result

Fix 1 was sufficient.

- previous unresolved near-boundary holdouts: `8`
- unresolved near-boundary holdouts after Fix 1: `0`

Because Fix 1 cleared the holdouts, the fallback `N_ext = 128` rerun was **not required**.

## Batch result

- seed poses: `20 / 20` `shadow-truncation-positive`
- near-boundary poses: `20 / 20` `shadow-truncation-positive`
- negative controls: `20 / 20` `shadow-inconclusive`

Module usage:
- `high-k-k2-tail-envelope-monotone-cap`: `48`
- `observed-tail-plus-grid`: `12`

Mean tail change versus `v2.0ac`:
- `-0.012238`

## Former holdouts resolved

- `pal-seed` / `orbiform-stub`: prior tail `0.063009` -> new tail `0.047511`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.009306`
- `pal-seed` / `regular-3-gon`: prior tail `0.070163` -> new tail `0.039121`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.008914`
- `small-cut` / `orbiform-stub`: prior tail `0.062093` -> new tail `0.046594`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.008073`
- `small-cut` / `regular-3-gon`: prior tail `0.069230` -> new tail `0.038801`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.006838`
- `moderate-cut` / `orbiform-stub`: prior tail `0.059345` -> new tail `0.043843`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.004373`
- `moderate-cut` / `regular-3-gon`: prior tail `0.066432` -> new tail `0.037842`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.000611`
- `small-arc-rounding` / `orbiform-stub`: prior tail `0.062093` -> new tail `0.046594`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.009073`
- `small-arc-rounding` / `regular-3-gon`: prior tail `0.069230` -> new tail `0.038801`, status `sampled-feasible-with-helly` -> `shadow-truncation-positive`, shadow lower margin `0.007863`

## Interpretation

The `v2.0ac` holdouts were an **envelope-quality problem**, not a cascade-architecture problem.

More specifically:
- Lane A remained stable,
- negative controls remained safe,
- and the only change needed to clear the near-boundary round/regular cases was tightening the asymptotic tail estimate by fitting it from the extreme high-frequency window instead of allowing retained or mid-frequency structural harmonics to dominate the unknown tail.

This batch should now be treated as the standing regression harness for future truncation work.
