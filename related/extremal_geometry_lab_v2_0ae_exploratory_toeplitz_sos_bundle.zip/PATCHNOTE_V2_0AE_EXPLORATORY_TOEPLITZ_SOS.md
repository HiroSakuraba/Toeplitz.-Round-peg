# Patch note — v2.0ae exploratory fixed-theta Toeplitz SOS lane

This patch adds a small exploratory S3a shadow lane for fixed-`theta` trigonometric nonnegativity.

## What was added

- `packages/extremal_geometry_lab/core/spectral_sos.py`
  - `ToeplitzGramCertificate2D`
  - `trig_series_exponential_coeffs`
  - `canonical_toeplitz_gram_from_series`
  - `toeplitz_gram_certificate_from_series`
  - `fixed_theta_toeplitz_gram_certificate_2d`
- `scripts/export_exploratory_fixed_theta_toeplitz_sos.py`
- `tests/test_spectral_sos.py`

## Mathematical scope

This is **not** a full SDP solve. It uses the canonical Hermitian Toeplitz Gram candidate `M` whose diagonal sums reproduce the truncated trigonometric gap polynomial. If `M` is PSD, then the truncated polynomial is nonnegative on `S^1`. If `M` is indefinite, that only means the restricted Toeplitz ansatz failed; it does not rule out existence of a more general Fejer/Riesz Gram certificate.

## Focused batch

The exploratory batch targets the exact witness/state pairs that were formerly truncation-limited before the high-`k` tail-fit fix:

- witnesses: `orbiform-stub`, `regular-3-gon`
- states: `pal-seed`, `small-cut`, `moderate-cut`, `small-arc-rounding`
- pose labels: `near-boundary-feasible`, `negative-control`

## Result

- near-boundary feasible cases: `8 / 8` `toeplitz-gram-psd-shadow-positive`
- matched negative controls: `8 / 8` `toeplitz-gram-indefinite`

This is a meaningful shadow-side separation result. It does not upgrade Lane B to a proof backend, but it strengthens the fixed-`theta` cross-check beyond the earlier sampled/LP/truncation-only regime.
