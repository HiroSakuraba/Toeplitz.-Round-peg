# Extremal Geometry Lab v2.0z — cascade seed-coupling fix

## What was wrong

The compact cascade path was rebuilding the first rigid stage from decoupled rotation and translation seeds, and later stages only propagated theta boxes plus aggregated translation bounds. That destroys the pairing between a rotation interval and its matching translation seed region.

A second issue showed up during debugging: the rotation refinement exported `certified_feasible_motion_boxes`, but those boxes were created by expanding a certified center translation point into a translation neighborhood without re-certifying the enlarged rigid-motion box. They were therefore too aggressive to use as coupled rigid seeds.

## What changed

### 1. Coupled motion-box propagation in the cascade

`cascaded_rigid_refinement()` now carries forward coupled rigid-motion seeds instead of only:

- `translation_bounds`
- `initial_theta_boxes`

The stage payload now records `input_motion_seed_count`, and the cascade details mark that motion-box coupling is preserved.

### 2. New first-stage seed construction from rotation intervals

The first rigid stage now uses **local motion seeds** built from each certified rotation interval together with the interval center translation point:

- same theta interval as the certified rotation interval
- point translation box at the LP/certified center translation

This preserves the rotation/translation correspondence without importing an over-expanded translation neighborhood.

### 3. Explicit motion-box initialization in rigid refinement

`refine_body_in_body_support_rigid_2d()` now accepts `initial_motion_boxes` and can seed its pending queue directly from coupled rigid-motion boxes.

## Focused regression result

Re-running the compact cascade batch on the Pál seed after the patch restores the previously implausible failures:

- `orbiform-stub`: `certified_feasible`
- `disk-half`: `certified_feasible`
- `regular-3-gon`: `certified_feasible`
- `segment`: `certified_feasible`
- `regular-4-gon`: `certified_feasible`
- `pal-seed`: `certified_feasible`

In the updated compact batch, these seed witnesses now certify at the light stage with 4 explored boxes rather than being wiped out by a 64-box Cartesian reconstruction.

## Files changed

- `packages/extremal_geometry_lab/core/rigid_fit.py`
- `results/certificates/v2_0y_compact_cascade_batch/summary.json`
- `results/certificates/v2_0y_compact_cascade_batch/summary.md`

## Validation performed

- `pytest -q tests/test_cascaded_rigid_refinement.py tests/test_joint_interval_rigid_refinement.py`
- focused Pál-seed regression checks for `orbiform-stub`, `disk-half`, `regular-3-gon`, `segment`, `regular-4-gon`, `pal-seed`
- regenerated `scripts/export_compact_cascade_batch.py`
