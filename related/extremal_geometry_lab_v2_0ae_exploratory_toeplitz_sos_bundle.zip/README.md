# Extremal Geometry Lab v2.0c

A GitHub-ready scaffold for a computer-assisted extremal geometry program focused on:

1. Lebesgue's universal covering problem
2. Moser's worm problem
3. Hadwiger covering / illumination in structured 3D classes

This repository is designed around a strict split between:

- **search**: heuristic proposal generation, symmetry reduction, proxy scoring, active witness discovery
- **proof**: interval-certified covering checks, exact combinatorial reductions, certificate export

## Core design principles

- support-function-native geometry engine
- rigid-motion witness fitting
- Minkowski-sum-based witness generation
- global rigidity testing for active witness sets
- family-aware exact screening
- human-readable symbolic reductions alongside machine certificates

## Package map

- `packages/extremal_geometry_lab/core/`: geometric primitives and proof-oriented engines
- `packages/extremal_geometry_lab/search/`: bounded move-sequence proposal search and exact-family screening
- `packages/extremal_geometry_lab/domains/lebesgue/`: problem-specific witnesses and candidate families
- `packages/extremal_geometry_lab/domains/moser/`: hard worm generation and convex cover ansatz families
- `packages/extremal_geometry_lab/domains/hadwiger3d/`: support-function-native 3D structured-class experiments
- `packages/extremal_geometry_lab/certificates/`: export formats for machine and human proof artifacts
- `docs/HANDOFF.md`: project handoff for future AI agents and collaborators
- `paper/extremal_geometry_lab_design.tex`: long-form LaTeX design memo

## Initial milestone sequence

1. Build shared support-function, witness-fitting, Minkowski, and rigidity modules.
2. Reproduce a trustworthy Lebesgue baseline inside a Pál-descended family.
3. Stress-test the same machinery on Moser's worm.
4. Attempt a support-function-native 3D class for restricted Hadwiger.

## Status

This is still a scaffold rather than a theorem repository, but the proof layer now includes exportable rigid-motion certificate bundles and per-cell support-bound audits for 2D joint interval refinement. It is no longer purely placeholder.
The 2D engine now has both:
- derived interval rigid-motion certificates from rotation refinement, and
- native rigid-motion box refinement in `(theta, t_x, t_y)`.

## Current proof-layer baseline

- added `refine_body_in_body_support_rigid_2d`, a first native interval branch-and-bound in rigid-motion space
- feasible boxes are now certified directly in `(theta, t_x, t_y)` rather than only via a center-pose residual box
- midpoint-drift infeasibility pruning added for rigid-motion boxes
- constant-support fallback added to the box certifier, which helps disks and similar witnesses
- test suite now covers the new joint interval refinement path

## New in v1.0

- stable rigid-motion refinement bundle export under `packages/extremal_geometry_lab/certificates/`
- deterministic demo exporter in `scripts/export_demo_rigid_motion_certificate.py`
- sample box-level proof artifact in `results/certificates/v1_0_demo_rigid_motion_bundle.{json,md}`

## New in v1.1

- added interval-support caching (support + trig) for joint rigid-motion refinement
- added witness-family bundle exporter `export_witness_family_bundle`
- added demo family bundle in `results/certificates/v1_1_demo_witness_family_bundle/`

## New in v1.2

- upgraded witness-family export into an actual product-space coexistence certificate
- exporter now writes `coexistence.{json,md}` alongside `summary.{json,md}` and per-witness bundles
- canonical certified-feasible box selection added for deterministic joint certificates
- added demo coexistence bundle in `results/certificates/v1_2_demo_witness_family_bundle/`


### v1.3 additions
- certified width prescreen for Lebesgue candidates
- optional robust-interval LP branch (`lp_mode="robust-interval"`) for one-translation-per-angle-interval fitting
- default path remains sampled/HiGHS-based


### v1.4 additions
- width prescreen now exercised through the family-screen API and demo bundle export
- robust-interval LP mode now has a non-optional fallback validation path via the default LP backend


### v1.5 additions
- Lebesgue proposal generation can now run with the width prescreen active during bounded search
- added a domain-level `search_with_width_prescreen(...)` helper and demo export


### v1.6 additions
- bounded search now orders proposals by screen slack first, then proxy score
- Lebesgue width-prescreened search produces a more meaningful ranked sweep over accepted descendants
- added `scripts/export_demo_lebesgue_ranked_sweep.py` and a sample artifact under `results/certificates/v1_6_demo_lebesgue_ranked_sweep/`


### v1.7 additions
- bounded search now supports beam-style frontier truncation
- width slack now affects not just proposal order but branch survival under truncation
- added `scripts/export_demo_lebesgue_beam_sweep.py` and a sample artifact under `results/certificates/v1_7_demo_lebesgue_beam_sweep/`


### v1.8 additions
- added a diversified beam policy for bounded search
- Lebesgue width-prescreened search can now reserve beam slots for geometrically distinct trim-parameter regions
- added `scripts/export_demo_lebesgue_diversified_beam_sweep.py` and a sample artifact under `results/certificates/v1_8_demo_lebesgue_diversified_beam_sweep/`


## New in v2.0a

- added analytic interval-support hooks for non-polygon 2D bodies
- exact interval support now exists for disks, segments, ellipses, and capsule-style arc/segment bodies
- interval cache and interval support-gap certificates now use body hooks before the Lipschitz fallback
- rigid-motion export bundles now include a self-verifying certificate recipe for independent replay

This is the first implemented slice of the v2.0 roadmap, not the full roadmap completion.


## v2.0b slice

- Lebesgue search now generates actual rounded arc/segment candidates via corner-cut polygon + disk Minkowski sums
- the analytic interval-support machinery is therefore exercised by real search states rather than only core/demo bodies


## v2.0c slice

- replaced trim-region diversified beam grouping with a support-signature geometric diversity key
- the new key uses centered support samples plus coarse scale and shape-ratio buckets
- added a demo comparison under `results/certificates/v2_0c_demo_lebesgue_support_signature_beam_sweep/`

- Lebesgue search now includes actual rounded arc/segment candidates backed by analytic interval-support hooks.
- Width prescreen and search can therefore exercise non-polygon bodies through the real family lane, not only demos.


### v2.0d
- added self-verifying rounded-candidate certificate bundles for the Lebesgue lane
- rounded candidate exports now include base-polygon vertices, rounding radius, and a replay recipe for the width prescreen


## v2.0f
- added minimal active-contact certificate exports for local support-fit LP placements


## v2.0h highlights
- hybrid diversified beam for the Lebesgue lane using support-signature and contact-structure together
- finite witness-net scaffold export for the Lebesgue theorem lane


## v2.0i probe-library contact signal

- strengthened the contact-side search signal from a single segment probe to a small probe library
- default contact/hybrid annotations now use `segment`, `orbiform-stub`, and `disk-half` witnesses
- diversified beam can now distinguish multiple contact keys even when the segment-only signature collapses


## v2.0aa shadow spectral verifier

- added a fixed-`theta` shadow spectral verifier under `core/spectral_shadow.py`
- the new lane extracts sampled Fourier support-gap models, LP-fitted translations, and sampled tail proxies
- it is wired as a dual-path cross-check against the repaired cascade lane rather than a proof replacement
- added a focused demo under `results/certificates/v2_0aa_demo_shadow_spectral_verifier/` for `orbiform-stub` and `disk-half` on the Pál seed


## v2.0ab shadow disagreement batch

- extended the shadow spectral lane into a batch disagreement detector over repaired cascade outputs
- added disagreement taxonomy, Helly/LP status, and contact-direction overlap diagnostics
- batch states: `pal-seed`, `small-cut`, `moderate-cut`, `small-arc-rounding`
- batch witnesses: `orbiform-stub`, `disk-half`, `segment`, `regular-3-gon`, `regular-4-gon`
- kept Lane B explicitly shadow-only and added an S0--S4 maturity ladder in the docs


## v2.0ac shadow tension batch

- added a near-boundary / negative-control tension batch under `results/certificates/v2_0ac_shadow_tension_batch/`
- added a first real shadow-lane truncation module in `core/spectral_shadow.py`
- round / regular witnesses now use `empirical-k2-tail-envelope`
- sharp witnesses currently use `observed-tail-plus-grid`
- batch result:
  - seed poses: `20 / 20` `shadow-truncation-positive`
  - negative controls: `20 / 20` `shadow-inconclusive`
  - near-boundary feasible poses: `12 / 20` truncation-positive, `8 / 20` still truncation-limited

## v2.0ae — exploratory fixed-theta Toeplitz SOS lane

A restricted S3a shadow lane is now present for a small hard subset: the formerly truncation-limited near-boundary cases for `orbiform-stub` and `regular-3-gon`, with matched negative controls across the same four container states. Instead of a full SDP solve, the lane builds the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of that matrix is a sufficient certificate for nonnegativity of the truncated polynomial; failure only rejects this restricted ansatz, not the full SDP/SOS problem.

Current exploratory result:
- near-boundary former holdouts: `8 / 8` `toeplitz-gram-psd-shadow-positive`
- matched negative controls: `8 / 8` `toeplitz-gram-indefinite`

Interpretation: after the high-`k` truncation fix, the shadow lane now separates these hard positives from matched negatives even under a restricted Gram ansatz. The next promotion step is still a genuine SDP-capable backend, but the Toeplitz subset already provides a meaningful S3a cross-check.
