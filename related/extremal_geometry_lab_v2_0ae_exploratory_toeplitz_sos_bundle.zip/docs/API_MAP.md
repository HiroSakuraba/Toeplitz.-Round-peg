
# API Map for Extremal Geometry Lab v0.2

## Core modules

- `core/geometry_types.py`
  - shared dataclasses for polygons, polylines, support functions, interval boxes, and spherical direction sets
- `core/minkowski.py`
  - convex hull
  - 2D convex polygon Minkowski sum
  - support-function sum in 2D and 3D
  - difference body
  - buffer/offset via sampled disks
  - polyline tube construction
- `core/support.py`
  - support from polygon
  - width / constant-width residuals
- `core/rigid_fit.py`
  - sample-based polygon/polyline placement
  - best contact pose search
- `core/rigidity.py`
  - rigidity matrix
  - thickened rigidity check
- `core/certify.py`
  - certified area
  - polygon/polyline containment
  - witness-family screen
- `core/canonicalize.py`
  - canonical polygon signatures
- `core/symbolic_export.py`
  - markdown/json symbolic reductions
- `core/spectral_shadow.py`
  - sampled Fourier support extraction
  - fixed-theta shadow support-gap verification
  - dual-path cross-checks from rigid refinement

## Search modules
- `search/proposal_search.py`
- `search/exact_screen.py`
- `search/proxy_score.py`

## Domain modules
- `domains/lebesgue/`
- `domains/moser/`
- `domains/hadwiger3d/`

## Certificate layer
- `certificates/formats.py`


core.prescreen
- WidthCertificate2D
- certified_min_width_2d(body, ...)
- certified_width_prescreen_2d(body, ...)

domains.lebesgue.prescreen
- prescreen_candidate_state(state, ...)
- LebesguePrescreenResult

core.support_lp
- SupportLPResult2D


domains.lebesgue.family
- proxy_score_state(state)
- width_prescreen(...)
- search_with_width_prescreen(...)

search.proposal_search
- bounded_search(..., screen=None, include_rejected=False)

certificates.formats
- rounded_candidate_self_verify_payload(...)
- export_rounded_candidate_bundle(...)


core.spectral_shadow
- SupportFourierSeries2D
- ShadowSpectralPoseReport2D
- ShadowSpectralCrosscheck2D
- sampled_support_fourier_2d(body, ...)
- sampled_gap_fourier_series_2d(container, witness, ...)
- fixed_theta_sampled_lp_translation(container, witness, ...)
- shadow_spectral_verify_pose_2d(container, witness, ...)
- shadow_spectral_crosscheck_from_refinement_2d(container, witness, refinement, ...)
