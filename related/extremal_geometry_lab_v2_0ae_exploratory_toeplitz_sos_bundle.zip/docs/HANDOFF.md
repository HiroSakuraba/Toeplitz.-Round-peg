# Extremal Geometry Lab v2.0q handoff

## Main state

The current search stack has three important search-side upgrades and one low-risk performance cleanup layer:

- **v2.0m:** witness-targeted follow-up moves became less label-driven and more geometric.
- **v2.0o:** ledger-derived targeted moves became scored and capped.
- **v2.0p:** witness-target scores began feeding back into beam priority and diversity.
- **v2.0q:** low-risk performance cleanup removed redundant search work without changing certificate semantics.

The key boundary remains unchanged:

> The witness/target summaries, suggestion scores, and beam-side score signals are all **search heuristics**. The rigorous proof side still lives in the interval-certified predicates, witness-fit pass/fail semantics, and certificate/export layers.

---

## v2.0m: cluster- and contact-guided witness targeting

### Previous status (v2.0l)
- witness-net search annotations could trigger targeted follow-up moves,
- but the guidance was still keyed mainly off raw failed/weakest witness labels.

### New status
The witness-net quick annotation now exposes:
- **low-margin witness clusters**,
- **failed witness clusters**,
- **weakest witness clusters**,
- and a small cached **contact summary**.

Targeted follow-up moves are now driven primarily by those coarse geometric summaries, with raw witness labels only as a fallback.

### Search-side summaries
Current witness clusters are intentionally coarse:
- `needle`
- `pointy`
- `broad`
- `round`

Current contact summaries are likewise coarse:
- `sparse`
- `simple`
- `mixed`
- `locked`

These are search heuristics, not theorem objects.

### Move-policy effect
The targeted move generator now uses:
1. low-margin / failed / weakest witness clusters,
2. contact summary,
3. raw witness labels only as fallback.

At the current search level:
- `needle` / `pointy` pressure or `sparse` contact summary suggests:
  - `targeted-triangle-rounding`
  - `targeted-triangle-cut`
- `broad` / `round` pressure or `mixed` / `locked` contact summary suggests:
  - `targeted-square-rounding`
- mixed low-margin pressure across clusters suggests:
  - `targeted-net-heavy-rounding`

### Demo artifact
- `results/certificates/v2_0m_demo_lebesgue_cluster_targeted_moves/`

---

## v2.0o: scored witness-ledger suggestion sets

Ledger-derived follow-up moves are no longer appended wholesale. Each suggestion now carries a numeric `score` built from:
- witness-cluster pressure from the quick witness ledger,
- severity bucket,
- move kind / target bonus,
- and a small geometric-scale term from cut amount and rounding radius.

The proposal-aware move generator now:
1. builds the baseline family,
2. sorts ledger-derived move specs by descending score,
3. keeps only the top `witness_target_move_limit` suggestions,
4. emits those targeted descendants.

### Current default
- `targeted_move_limit = 2`

This reduces frontier flooding without changing the proof layer.

### Demo artifact
- `results/certificates/v2_0o_demo_lebesgue_scored_targeted_moves/`

---

## v2.0p: beam-side witness-target score signal

The witness-ledger targeting lane now feeds back into the **beam policy** itself.

### New exported summary fields
The witness-net annotator exports:
- `witness_target_max_score`
- `witness_target_total_score`
- `witness_target_score_bucket`
- `witness_target_score_signature`
- `witness_target_suggested_targets`
- `witness_target_suggested_labels`

### Search-side effect
The search policy now uses these in two places:
1. **priority** for `structure_signal="witness-net"` and `structure_signal="hybrid-witness-net"`
2. **diversified beam novelty** via a witness-target diversity key

So the same witness-ledger pressure signal now influences both:
- which targeted moves are proposed,
- and which proposals the beam prefers to keep.

### Demo artifact
- `results/certificates/v2_0p_demo_lebesgue_target_score_beam_signal/`

---

## v2.0q: low-risk performance cleanup

### Why this was added
A small staged stress check showed that the stacked heavy lane is genuinely expensive when several costs are combined:
- deeper Lebesgue beam search,
- witness-net search annotations,
- targeted move generation,
- and bridge/export work.

The observed issue was runtime/scaling growth, not an immediate correctness failure.

### What changed in code
The low-risk cleanup deliberately touched only **redundant search work**, not any proof predicate.

#### Search-level dedup before expensive screening
- added a `deduplicate_before_screen` hook to `bounded_search(...)`
- enabled it in `search_with_width_prescreen(...)`

This removes obviously duplicate descendants before they pay for more expensive search-side analysis.

#### Contact-metric reuse inside the annotator
- `make_contact_structure_annotator(...)` now reuses already-computed contact metrics rather than recomputing them only to build annotation keys

This is a pure reuse/cache cleanup inside the same semantics.

#### Geometric dedup inside targeted move generation
- `witness_targeted_moves(...)` now deduplicates geometrically identical targeted descendants before they move deeper into the search stack

This cuts redundant targeted branches without changing any downstream pass/fail rule.

### Files changed
- `packages/extremal_geometry_lab/domains/lebesgue/family.py`
- `packages/extremal_geometry_lab/search/proposal_search.py`
- `tests/test_lebesgue_search_prescreen.py`

### What was intentionally not changed
The following were treated as correctness-critical and left alone:
- interval-certified predicates,
- support-gap / width-screen semantics,
- witness-fit pass/fail semantics,
- rigid box / rigid refinement classification rules,
- certificate/export truth conditions.

### Verification
Focused verification passed on the patched bundle, including tests for:
- pre-screen dedup,
- contact-metric reuse,
- targeted-move geometric dedup,
- bridge/export,
- certificate export.

### Benchmark snapshot
On the small staged benchmark, the speedups are modest but the accepted descendants remained unchanged.

#### contact
- baseline: `3.555 s`
- patched: `3.502 s`
- delta: `-0.053 s` (`-1.5%`)
- accepted descendants unchanged: `True`

#### witness
- baseline: `6.296 s`
- patched: `6.322 s`
- delta: `+0.026 s` (`+0.4%`)
- accepted descendants unchanged: `True`

#### hybrid_witness
- baseline: `3.053 s`
- patched: `3.028 s`
- delta: `-0.025 s` (`-0.8%`)
- accepted descendants unchanged: `True`

### Interpretation
The main value of v2.0q is not a dramatic micro-benchmark gain. The value is that the search stack now does less redundant work in the heaviest witness-targeted lanes, while leaving the certificate semantics intact.

### Preexisting issue noted during verification
The original unmodified bundle already fails:
- `tests/test_lebesgue_search_prescreen.py::test_witness_targeted_moves_introduce_targeted_descendants`

in this environment. That issue was present upstream and was not counted as a regression from the low-risk cleanup.

---

## v2.0s: heuristic transparency and adaptive quick witness fitting

### Why this was added
A follow-up review identified four search-side issues worth fixing without touching the proof layer:
- the coarse witness-cluster boundaries were implicit in code rather than documented,
- the targeted move cut/radius choices were magic numbers,
- the legacy cluster/contact fallback path was still silent,
- and the quick witness fit used a uniformly coarse `angle_steps=12` even near tight margins.

The resulting cleanup stays entirely on the heuristic side. It does **not** alter interval predicates, witness-fit truth conditions, or certificate/export semantics.

### What changed in code

#### Exposed cluster boundaries and targeted-move defaults
- `packages/extremal_geometry_lab/domains/lebesgue/family.py`
  - surfaced the current witness-cluster thresholds as named constants:
    - `needle`: at most 4 vertices and `area / diameter^2 < 0.14`
    - `pointy`: at most 4 vertices and `area / diameter^2 < 0.20`
    - `round`: at least 8 vertices or `area / diameter^2 >= 0.26`
    - otherwise `broad`
  - surfaced the current targeted move cut/radius defaults as named empirical constants
  - exported those thresholds and defaults into witness-net annotations so demo artifacts and handoffs can report the exact heuristic values in use

These are still tuned search heuristics, not theorem quantities.

#### Deprecated fallback path is now explicit
- `witness_targeted_moves(...)` still supports older cluster/contact-only annotations for backward compatibility
- but the fallback path is now tagged explicitly as:
  - `deprecated-cluster-contact-fallback`
- targeted descendants built from that path now carry:
  - `target_source`
  - `target_annotation_path`

This makes it visible when a run used legacy fallback logic rather than ledger-derived move specs.

#### Adaptive quick witness fitting near the margin
- `quick_witness_net_metrics(...)` now starts at the configured base resolution (still `angle_steps=12` by default)
- then selectively re-fits only witnesses whose first-pass margin is near the decision boundary
- current adaptive defaults:
  - base angle steps: `12`
  - adaptive angle steps: `24`
  - adaptive trigger threshold: sampled margin `<= 0.12`

The annotation now exports:
- `witness_net_base_angle_steps`
- `witness_net_adaptive_angle_steps`
- `witness_net_adaptive_margin_threshold`
- `witness_net_adaptive_refit_count`
- `witness_net_max_angle_steps_used`

So the quick-fit path remains cheap on easy states, but the tight-margin cases that drive severity buckets and targeted moves get a second pass.

#### Nontrivial witness-nerve demo
- `scripts/export_demo_lebesgue_witness_cofailure_nerve.py` now uses a small family of **deliberately undersized stress states** instead of only easy Pál descendants
- the updated demo writes:
  - `results/certificates/v2_0s_demo_lebesgue_witness_cofailure_nerve/`

This gives a sampled co-failure nerve with actual nonempty failure samples instead of a trivial all-pass output.

### Verification
Focused verification covered:
- annotation metadata for thresholds / parameter policy,
- explicit deprecated fallback tagging,
- adaptive quick-fit escalation from `12` to `24` angle steps near the margin,
- targeted descendants surviving again under the diversified witness-net beam,
- and the nontrivial witness-nerve demo export.

Representative checks passed:
- `tests/test_lebesgue_search_prescreen.py::test_witness_targeted_moves_introduce_targeted_descendants`
- `tests/test_lebesgue_search_prescreen.py::test_quick_witness_net_metrics_adapts_angle_steps_near_margin`
- `tests/test_topology_diagnostics.py::test_nerve_complex_from_failure_sets_detects_cycle_without_triangle_fill`
- `tests/test_topology_diagnostics.py::test_nerve_complex_triangle_fill_kills_cycle`

### Updated demo snapshot
For the updated witness-cofailure demo:
- vertices: `10`
- edges: `28`
- triangles: `56`
- `betti_0 = 3`
- `betti_1 = 0`
- nonempty failure samples: `3`

That is still only a **sampled diagnostic**, not a finite-witness completeness proof, but it is now nontrivial enough to be informative.

---

## Current recommended next step

The next clean move is still on the **search side**, but should keep the same correctness boundary:

> let quick witness-ledger outcomes update move suggestion scores online, while preserving the current proof-layer predicates and certificate/export truth conditions.

Concretely, the safe next lane is:
- keep interval-certified and witness-fit semantics fixed,
- keep search/export separation explicit,
- add online score adaptation only as a beam / proposal heuristic,
- and continue measuring accepted-descendant stability alongside runtime.

---

## Batch 1 reporting correction

The original Tier B1 Batch 1 summary reported `19` passed proposals in each pass. That was a **summary-accounting issue**, not a search change: the count included the seed. The corrected passed-proposal count is `18` for both runs under the rule `screen_passed == True and len(move_history) > 0` (seed excluded).


## v2.0u: formalized rigid seed derivation and explicit bridge ladder

The next bridge/export cleanup is now implemented at the initialization-policy layer rather than as another ad hoc script-level warm-start.

### What changed

#### Single seed-derivation helper
The rigid layer now centralizes rotation-stage seed consumption through:
- `derive_rigid_seed_from_rotation_fit(...)`

This helper chooses rigid translation bounds using the following precedence when the caller does not supply explicit `translation_bounds`:
1. a padded certified translation box from the rotation stage,
2. otherwise a padded best-pose neighborhood when the sampled margin is positive,
3. otherwise the old global auto-bounds.

The rigid refiner records the chosen policy explicitly in metadata rather than only exposing a raw bounds source string.

#### Standardized seed metadata
The rigid refiner now exports additional seed metadata fields, including:
- `rotation_seed_available`
- `rotation_seed_kind`
- `rotation_seed_center`
- `rotation_seed_radius_x`
- `rotation_seed_radius_y`
- `rotation_seed_margin`
- `rotation_seed_box_count`

These fields keep the earlier rotation-stage evidence visible to the exporter without conflating it with rigid-box certification.

#### Explicit bridge ladder levels
Bridge/export scripts now use named ladder levels rather than hard-coded tuples:
- `light`
- `real`
- `confirm`

The current defaults are centralized in:
- `packages/extremal_geometry_lab/certificates/bridge_policy.py`

This does not change any proof-facing predicate. It only standardizes how bridge/export scripts request rigid refinement strength.

### Scope boundary
This revision does **not** change:
- interval predicates,
- rigid-box feasible / infeasible classification,
- witness-fit truth conditions,
- certificate semantics.

It changes only:
- seed selection,
- exported seed metadata,
- and script-side bridge ladder configuration.

### Verification
Focused verification covered:
- best-pose-neighborhood seed derivation when no certified translation box exists,
- disabling rotation-seed consumption cleanly,
- preserving explicit translation bounds when supplied by the caller,
- explicit bridge ladder mappings,
- and the witness-net bridge demo script under the new ladder helper.

Representative checks passed:
- `tests/test_joint_interval_rigid_refinement.py`
- `tests/test_bridge_policy.py`

The updated witness-net bridge demo script also ran and wrote:
- `results/certificates/v2_0t_demo_lebesgue_witness_net_bridge/`

### Recommended next step
The next clean move is still the first deferred piece from the v2.0t-next plan:
> localized deepening near seeded feasible regions, with far-away rigid boxes receiving lower priority or a shallower depth cap.

That would continue the seeded-bridge lane without touching any correctness-facing predicate.


## v2.0v: localized rigid deepening near seeded feasible regions

The rigid bridge lane now uses the inherited rotation-fit seed more aggressively in the **branch ordering and depth budget**, not just in the initial translation bounds.

### What changed

The rigid-motion refiner now constructs a small seed-focus translation box from the inherited rotation-fit seed metadata:
- seed center from `rotation_seed_center`
- radii from `rotation_seed_radius_x / rotation_seed_radius_y` when available
- fallback half-extent from the best-pose neighborhood minimum
- small configurable padding `localized_deepening_pad`

Each rigid box is then tagged as either:
- `localized_near_seed`, if its translation box intersects the seed-focus box
- or far from the seed, with a positive `localized_seed_distance`

The search uses this in two search-side ways only:
1. near-seed boxes are popped first from the pending queue,
2. far-away boxes receive a smaller effective depth cap:
   \[
   d_{\mathrm{eff}} = \max(0, d_{\max} - \Delta d_{\mathrm{far}})
   \]
   with `localized_far_box_depth_penalty = 1` in the current bridge ladder defaults.

### What this is

This is still a **search-ordering / budget-allocation** change. It does not alter:
- interval predicates,
- rigid-box feasible/infeasible criteria,
- witness-fit truth conditions,
- certificate semantics.

### New metadata

Rigid-box details now record:
- `localized_near_seed`
- `localized_seed_distance`
- `localized_effective_max_depth`

The rigid best-pose details now record:
- `localized_deepening`
- `localized_deepening_pad`
- `localized_far_box_depth_penalty`
- `seed_focus_box`

### Current defaults

The explicit bridge ladder now includes localized deepening by default at all levels:
- `light`
- `real`
- `confirm`

with:
- `localized_deepening = True`
- `localized_deepening_pad = 0.05`
- `localized_far_box_depth_penalty = 1`

### Focused verification

- bridge-policy tests passed with the new ladder defaults,
- localized-deepening metadata tests passed on explicit wide-bounds seed-triangle runs,
- the warm-started seed triangle still certifies at the light bridge level,
- the rigid layer preserves explicit translation bounds when supplied.

### Recommended next step

Now that the rigid bridge lane has:
1. seeded translation bounds, and
2. localized deepening near the inherited seed,

the next clean move is a **seed-only bridge ladder rerun** to measure how many witnesses certify at `light / real / confirm` under the new queueing/depth-budget policy before restoring the full Batch 2 export pass.

## v2.0aa: shadow spectral verifier as a dual-path cross-check

The next lane after the cascade seed-coupling repair is now implemented as a **shadow spectral verifier**, not as a replacement proof backend.

### Why this lane exists

The repaired cascade path recovered the previously lost `orbiform-stub` and `disk-half` Pál-seed certifications. The immediate follow-up need was not another independent global search tree. The need was a second, differently structured explanation of the same sample structures so that future regressions can be caught earlier.

That led to the following split:

- **Lane A:** the existing interval/cascade rigid-motion certifier in `(theta, t_x, t_y)`
- **Lane B:** a fixed-`theta` shadow spectral verifier attached to Lane A's sampled poses and feasible motion boxes

### What Lane B currently does

For a sampled pose, the shadow verifier now:

1. solves a fixed-`theta` sampled support LP for translation,
2. samples the support-gap profile,
3. extracts a truncated Fourier representation of that sampled gap,
4. computes a sampled tail proxy,
5. reports a shadow lower margin `truncated_gap_margin - tail_sup_proxy`,
6. attaches width-style prescreen data for the same witness/container pair.

This is intentionally narrower than the full spectral proposal. There is **no** PSD/SOS proof object yet, and the tail proxy is not yet rigorous.

### Correctness boundary

This lane does **not** change:

- interval predicates,
- rigid-box feasible / infeasible / unresolved semantics,
- witness-fit truth conditions,
- certificate export truth conditions.

It is a **cross-check/debugging lane** only.

### Implemented entry points

Added core module:
- `packages/extremal_geometry_lab/core/spectral_shadow.py`

Main functions:
- `sampled_support_fourier_2d(...)`
- `sampled_gap_fourier_series_2d(...)`
- `fixed_theta_sampled_lp_translation(...)`
- `shadow_spectral_verify_pose_2d(...)`
- `shadow_spectral_crosscheck_from_refinement_2d(...)`

### Focused demo

A focused demo now exists under:
- `results/certificates/v2_0aa_demo_shadow_spectral_verifier/`

Current demo scope:
- container: Pál seed,
- witnesses: `orbiform-stub`, `disk-half`,
- Lane A source: repaired cascade lane,
- Lane B output: shadow-supportive fixed-`theta` reports on the best pose and feasible-box centers.

In the current focused demo, both witnesses are:
- Lane A: `certified_feasible`
- Lane B: `shadow-supportive`

This is the right first checkpoint: the new lane agrees with the repaired cascade on the exact sample structures that were previously wiped out by the seed-transfer regression.

### Recommended next step

Keep the spectral lane in **shadow-only mode** and harden it in the following order:

1. rigorous coefficient extraction for the round / arc-based witness classes,
2. rigorous truncation bounds replacing sampled tail proxies,
3. stable disagreement reporting between Lane A and Lane B,
4. only then a real fixed-`theta` PSD/SOS backend.

Do **not** promote the spectral lane to a proof replacement until it has rigorous truncation control and a verified post-check path.

## v2.0ab: shadow disagreement batch and maturity ladder

The shadow spectral lane has now been promoted from a focused two-witness demo into a **batch disagreement detector**.

### Why this was the next move

After v2.0aa, the main open question was no longer whether the plumbing worked for a single repaired example. The right next question was whether Lane B could cross-check the repaired cascade lane across a small witness-state matrix and tell us **why** the two lanes agreed or disagreed.

That led to four concrete upgrades:

1. batch cross-check over repaired cascade outputs,
2. a disagreement ledger with named taxa,
3. stronger Lane B signals beyond a single sampled/Fourier margin,
4. a formal maturity ladder so the spectral lane's current evidentiary level is explicit.

### What the batch covers

Current batch states:
- `pal-seed`
- `small-cut`
- `moderate-cut`
- `small-arc-rounding`

Current batch witnesses:
- `orbiform-stub`
- `disk-half`
- `segment`
- `regular-3-gon`
- `regular-4-gon`

All cases are run with the repaired cascade lane first. Lane B is then attached to the best pose and feasible-box centers from the resulting refinement.

### Stronger Lane B record

Lane B now records, per sampled pose:

1. width-prescreen result,
2. fixed-`theta` Helly/LP translation margin,
3. sampled support-gap margin at the explicit Lane A pose,
4. sampled support-gap margin at the LP translation,
5. sampled Fourier truncation proxy data,
6. contact-direction overlap between Lane A and LP-induced near-contact sets.

This makes Lane B a more useful debugging surface without changing any proof-facing semantics.

### Disagreement taxonomy

The current batch exports one of the following labels per case:

- `agreement-feasible`
- `agreement-infeasible`
- `truncation-too-loose`
- `motion-box-issue`
- `symmetry-transport-or-motion-box-issue`
- `fourier-extraction-or-width-prescreen-mismatch`
- `conditioning-or-fourier-extraction`
- `true-unresolved-case`

These labels are intentionally operational. They are meant to direct the next debugging step, not to encode a theorem.

### Maturity ladder for the spectral lane

The shadow lane now has an explicit maturity ladder:

- `S0`: sampled support-gap shadow check only
- `S1`: width + Helly/LP prescreens + sampled-gap comparison
- `S2`: sampled Fourier truncation shadow check with batch disagreement reporting
- `S3`: exploratory fixed-`theta` PSD/SOS backend
- `S4`: certified PSD/residual verification with rigorous truncation control

Current status: **between S1 and S2**.

That means:
- the dual pipeline is real,
- disagreement reports are now exported,
- but the spectral lane is still **shadow-only** because the truncation object is still sampled rather than rigorous.

### Files changed

Core code:
- `packages/extremal_geometry_lab/core/spectral_shadow.py`

Updated tests:
- `tests/test_spectral_shadow.py`

Updated docs:
- `docs/SHADOW_SPECTRAL_VERIFIER.md`
- `docs/NEXT_STEPS.md`
- `docs/HANDOFF.md`
- `paper/extremal_geometry_lab_design.tex`
- `README.md`

### Current interpretation

This is the right shape of dual pipeline:

- Lane A continues to own certified motion-space statements.
- Lane B now has enough internal structure to be a useful disagreement detector over the repaired cascade outputs.
- The spectral route still should **not** be promoted to theorem-facing status until the sampled tail proxy is replaced by a rigorous truncation bound and a certified PSD/residual post-check exists.

### Recommended next step

Keep working in this order:

1. expand the disagreement matrix to more nearby candidate states,
2. harden the truncation module first for round / arc-based witness classes,
3. only then add an exploratory fixed-`theta` PSD/SOS backend,
4. only after that decide whether any shadow result can become proof-facing.


## Shadow spectral verifier status through v2.0ac

The repaired cascade lane is now backed by three shadow-lane phases:
- focused verifier demo (v2.0aa)
- disagreement batch over repaired cascade outputs (v2.0ab)
- tension batch with first real truncation module (v2.0ac)

Current shadow-lane picture:
- base repaired-cascade sample structures agree `20 / 20`
- explicit negative controls are rejected by Lane B `20 / 20`
- near-boundary feasible stress poses split into:
  - `12 / 20` full truncation-positive
  - `8 / 20` sampled-feasible-with-Helly but truncation-limited

Interpretation:
- the dual pipeline is now genuinely discriminating near the boundary,
- but the round / regular truncation layer is still too loose to promote Lane B beyond shadow-only status,
- the most valuable next target is the small set of truncation-limited near-boundary cases (`orbiform-stub`, `regular-3-gon`) rather than broadening the easy-feasible batch further.

## v2.0ae — exploratory fixed-theta Toeplitz SOS lane

A restricted S3a shadow lane is now present for a small hard subset: the formerly truncation-limited near-boundary cases for `orbiform-stub` and `regular-3-gon`, with matched negative controls across the same four container states. Instead of a full SDP solve, the lane builds the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of that matrix is a sufficient certificate for nonnegativity of the truncated polynomial; failure only rejects this restricted ansatz, not the full SDP/SOS problem.

Current exploratory result:
- near-boundary former holdouts: `8 / 8` `toeplitz-gram-psd-shadow-positive`
- matched negative controls: `8 / 8` `toeplitz-gram-indefinite`

Interpretation: after the high-`k` truncation fix, the shadow lane now separates these hard positives from matched negatives even under a restricted Gram ansatz. The next promotion step is still a genuine SDP-capable backend, but the Toeplitz subset already provides a meaningful S3a cross-check.
