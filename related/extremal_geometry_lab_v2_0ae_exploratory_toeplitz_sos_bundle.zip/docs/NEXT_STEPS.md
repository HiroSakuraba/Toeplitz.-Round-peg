# Next Steps After v1.7

## Immediate engineering targets
1. Improve non-polygon support intervals beyond the current Lipschitz fallback.
2. Add a priority policy for box splitting based on actual certificate slack rather than only width scale.
3. Add explicit lower-bound obstruction bundles alongside containment bundles.
4. Add witness--witness non-overlap constraints when a domain actually needs simultaneous packing rather than independent coexistence.

## Lebesgue targets
1. Encode a real Pál-descended family with trim parameters and symmetry normalization.
2. Use the new product-space witness coexistence certificates to test finite forcing sets.
3. Export symbolic contact reductions for boxes that survive exact screening.

## Moser targets
1. Build a proper hard-worm generator using polyline + arc primitives.
2. Use joint rigid-motion boxes to separate forcing worms from non-forcing worms.
3. Split the pipeline cleanly into upper-bound cover certificates and lower-bound obstruction certificates.

## Hadwiger 3D targets
1. Implement centrally symmetric support-function families first.
2. Add constant-width constraints `h(u)+h(-u)=w` as the stronger theorem-facing subclass.
3. Add spherical cap coverage certificates with interval margins.

## The next clean theorem-facing move
The immediate theorem-facing goal is now to use the new witness-family coexistence certificate as a proof primitive inside actual candidate-family scans, rather than treating it only as a post hoc export layer.

Completed in v1.7:
- bounded search now supports beam-style frontier truncation
- width slack now affects not just proposal order but branch survival under truncation
- added a beam-sweep demo certificate bundle for the Lebesgue lane


Completed in v1.3:
- width prescreen for Lebesgue candidates

Still open:
- upgrade robust interval LP from opt-in branch to default only after timing and stability checks
- add existential contractor branch (`pyibex` or equivalent) without replacing universal box semantics


Completed in v1.4:
- width prescreen exercised through exact-family screening and demo export
- robust-interval LP path validated in fallback mode without optional solver dependencies


Completed in v1.5:
- width prescreen now wired into actual Lebesgue bounded proposal search
- added a demo prescreened-search certificate bundle


Completed in v1.8:
- bounded search now supports a diversified beam policy in addition to greedy truncation
- Lebesgue search can reserve beam slots for distinct root-branch families under the width prescreen
- added a diversified-beam comparison demo bundle for the Lebesgue lane


Completed in v2.0b:
- rounded arc/segment Lebesgue candidates wired into search and prescreen

Next:
- replace trim-region beam diversity with support-signature geometric diversity
- add self-verifying certificate bundles for the new arc candidates
- prototype exact small-LP Helly-style infeasibility pruning


Current completed v2.0 slices: analytic interval hooks (v2.0a), rounded candidate search integration (v2.0b), support-signature beam diversity (v2.0c), self-verifying rounded-candidate bundles (v2.0d).


## Shadow spectral verifier follow-up

Completed in v2.0ab:
- batch cross-check over repaired cascade outputs for `pal-seed`, `small-cut`, `moderate-cut`, and `small-arc-rounding`
- disagreement ledger with explicit taxon labels
- stronger Lane B signal set: width, Helly/LP, sampled-gap, truncation-proxy, and contact-direction overlap
- formal shadow-lane maturity ladder (S0 through S4)

Completed in v2.0ac:
- built a near-boundary / negative-control tension batch for the five current witnesses across the four repaired-cascade states
- replaced the old sampled tail proxy by a first real shadow-lane truncation module:
  - `empirical-k2-tail-envelope` for round / regular witness classes
  - `observed-tail-plus-grid` for the sharper segment lane
- confirmed that all `20 / 20` negative controls go `shadow-inconclusive`
- confirmed that all `20 / 20` seed poses remain `shadow-truncation-positive`
- exposed an informative near-boundary split:
  - `12 / 20` full truncation-positive
  - `8 / 20` sampled-feasible-with-Helly but truncation-limited

Completed in v2.0ad:
- replaced the all-`k` round/regular tail envelope by a **high-`k` tail-fit envelope with a conservative monotone cap**
- reran the exact same `60`-pose tension batch unchanged except for that truncation estimator
- resolved all `8 / 8` previous near-boundary holdouts without weakening the negative-control safety behavior
- result:
  - `20 / 20` seed poses remain `shadow-truncation-positive`
  - `20 / 20` near-boundary poses now go `shadow-truncation-positive`
  - `20 / 20` negative controls remain `shadow-inconclusive`
- because Fix 1 cleared the holdouts, the brute-force `N_ext = 128` confirmation pass was **not needed**

Next:
- keep the batch harness fixed and use it as a regression test whenever the truncation model changes
- start a small fixed-`theta` exploratory SOS/PSD lane on the formerly truncation-limited `orbiform-stub` and `regular-3-gon` cases
- add a sharper shadow-negative path for explicit bad poses so Lane B can sometimes return more than `shadow-inconclusive` on negative controls
- keep Lane B shadow-only until it reaches S4 with certified PSD/residual verification and rigorous truncation control

## v2.0ae — exploratory fixed-theta Toeplitz SOS lane

A restricted S3a shadow lane is now present for a small hard subset: the formerly truncation-limited near-boundary cases for `orbiform-stub` and `regular-3-gon`, with matched negative controls across the same four container states. Instead of a full SDP solve, the lane builds the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of that matrix is a sufficient certificate for nonnegativity of the truncated polynomial; failure only rejects this restricted ansatz, not the full SDP/SOS problem.

Current exploratory result:
- near-boundary former holdouts: `8 / 8` `toeplitz-gram-psd-shadow-positive`
- matched negative controls: `8 / 8` `toeplitz-gram-indefinite`

Interpretation: after the high-`k` truncation fix, the shadow lane now separates these hard positives from matched negatives even under a restricted Gram ansatz. The next promotion step is still a genuine SDP-capable backend, but the Toeplitz subset already provides a meaningful S3a cross-check.
