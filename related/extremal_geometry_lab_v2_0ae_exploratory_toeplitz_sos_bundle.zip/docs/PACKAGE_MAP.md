# Package Map

## Core
- `support.py`: convex-body and support-function representations
- `rigid_fit.py`: rigid-motion witness placement and active-contact detection
- `minkowski.py`: Minkowski sum / difference and witness constructors
- `rigidity.py`: local and global rigidity tests for witness configurations
- `certify.py`: interval-certified covering / containment / margin checks
- `canonicalize.py`: symmetry reduction and canonical representatives
- `symbolic_export.py`: human-readable proof reduction summaries
- `spectral_shadow.py`: fixed-theta sampled Fourier shadow verifier and cascade cross-check lane

## Search
- `proposal_search.py`: bounded move-sequence candidate generator
- `exact_screen.py`: family-aware exact screening and survivor ledgers
- `proxy_score.py`: search-only scoring layer

## Domains
- `lebesgue/`: Pál-descended family, orbiform witnesses, universal-cover certificates
- `moser/`: hard worm generation, convex cover families, coexistence tests
- `hadwiger3d/`: spherical normal coverage, structured 3D class experiments
