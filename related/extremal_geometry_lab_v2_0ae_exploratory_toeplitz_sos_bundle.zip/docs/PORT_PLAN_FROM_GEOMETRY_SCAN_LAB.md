# Port Plan from geometry_scan_lab_v0.8.0

This repo does **not** import the old scan-lab project wholesale. Instead it ports the reusable ideas.

## Reused concepts
- bounded move-sequence proposal search
- canonicalization / deduplication
- family-aware exact screening
- 3D sphere-environment ideas
- certificate-pattern philosophy from the ODE core

## Not reused verbatim
- toric-specific task generators
- toric exact-family code paths
- Whitney / stratification audits as theorem dependencies

## New modules required here
- support-function engine
- witness-placement engine
- Minkowski-sum engine
- global rigidity tester
- interval-certified geometric inequality checker
- human-readable symbolic reduction exporter
