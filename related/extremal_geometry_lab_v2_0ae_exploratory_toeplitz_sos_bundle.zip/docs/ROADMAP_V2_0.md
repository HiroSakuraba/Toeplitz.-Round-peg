# Roadmap v2.0

1. Piecewise analytic arc/segment support enclosures
2. Geometric beam diversity via support signatures
3. Self-verifying certificate exports
4. Helly-style exact early infeasibility pruning
5. Minimal active-contact LP exports

## Implementation status

Started: roadmap item 1 is now partially implemented in core form. The proof layer supports analytic interval bounds for several non-polygon families, but the Lebesgue search family still needs a real arc-replacement geometry lane to exploit them fully.


## Progress note: v2.0b
The first roadmap follow-up after v2.0a is complete: actual rounded arc/segment candidates are now generated in the Lebesgue family and pass through width prescreening using analytic interval-support hooks. This closes the previous gap where the roadmap machinery existed only at the core/demo layer.


## Progress note: v2.0c
Roadmap item 2 is now partially implemented: diversified beam search in the Lebesgue lane uses a support-signature geometric diversity key rather than trim-parameter regions. The key is coarse and heuristic, but it is now geometry-facing and distinguishes rounded descendants by support signature, scale bucket, and shape-ratio bucket.


## Implemented: v2.0g contact-structure search signal
- Added proposal annotation hooks to bounded search.
- Added a Lebesgue contact-structure annotator based on the minimal active-contact certificate of a canonical segment probe.
- Added `structure_signal="contact"` to the Lebesgue search wrapper.
- Contact structure now acts as a real search signal in diversified beam selection, not only as export metadata.


## v2.0h hybrid beam + witness-net scaffold
- Added `structure_signal="hybrid"` to the Lebesgue search wrapper.
- Diversified beam can now reserve novelty across **both** support-signature geometry and contact-structure keys at once.
- Added a finite witness-net scaffold builder for the Lebesgue lane: `build_polygon_witness_net_scaffold(...)`.
- The witness-net scaffold is exported honestly as an **incomplete-family scaffold**, not a theorem certificate.


## v2.0i probe-library contact signal
- Replaced the single segment contact probe with a small default probe library: `segment`, `orbiform-stub`, and `disk-half`.
- `structure_signal="contact"` and `structure_signal="hybrid"` now annotate proposals with a combined probe-library contact signature.
- This strengthens the contact side of the hybrid beam without pretending to have theorem-grade contact classes yet.
