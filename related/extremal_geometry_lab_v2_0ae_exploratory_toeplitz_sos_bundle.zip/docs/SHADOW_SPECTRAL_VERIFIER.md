# v2.0ab shadow spectral verifier and disagreement batch

This lane remains a **dual-path cross-check**. It is deliberately narrower than a theorem-facing spectral backend.

## Purpose

The current rigid/cascade lane remains the only proof-facing global certifier for motion-space statements.

- **Lane A:** interval/cascade rigid certification in `(theta, t_x, t_y)`
- **Lane B:** fixed-`theta` shadow spectral verification attached to Lane A poses and feasible motion-box centers

The point of Lane B is not to replace Lane A. The point is to attach an independent analytic explanation to the same sample structures and to surface disagreements early.

## Current strengthened shadow check

For a sampled pose, Lane B now records four distinct signals:

1. **width prescreen**
   - compares a sampled witness diameter against a certified lower width bound for the container.
2. **Helly/LP prescreen**
   - solves a fixed-`theta` sampled support LP for translation.
3. **sampled support-gap check**
   - evaluates
     \[
     \Delta_g(\alpha)=h_C(\alpha)-h_W(\alpha-\theta)-t_x\cos\alpha-t_y\sin\alpha
     \]
     on a dense angular grid.
4. **sampled Fourier shadow check**
   - builds a truncated Fourier model,
   - measures a sampled tail proxy,
   - reports the shadow lower margin
     \[
     m_{\mathrm{shadow}}=\min \Delta_g^{(N)}-\varepsilon_{N,\mathrm{sample}}.
     \]

Lane B also compares **contact-direction structure** between:
- the Lane A pose translation,
- the fixed-`theta` LP translation.

This is recorded as an overlap score between near-contact angle sets.

## Output objects

The core module is still:
- `packages/extremal_geometry_lab/core/spectral_shadow.py`

It now exports:
- `compare_contact_directions_2d(...)`
- `summarize_shadow_disagreement_2d(...)`
- richer `ShadowSpectralPoseReport2D`
- richer `ShadowSpectralCrosscheck2D`

Each pose report now carries:
- width-pass data,
- LP margin and LP status,
- sampled-gap margin at the explicit pose,
- sampled-gap margin at the LP translation,
- Fourier/truncation proxy data,
- contact-direction overlap diagnostics.

## Batch disagreement detector

The first batch disagreement run now lives under:
- `results/certificates/v2_0ab_shadow_disagreement_batch/`

Current batch scope:
- states:
  - `pal-seed`
  - `small-cut`
  - `moderate-cut`
  - `small-arc-rounding`
- witnesses:
  - `orbiform-stub`
  - `disk-half`
  - `segment`
  - `regular-3-gon`
  - `regular-4-gon`

For each state/witness pair the batch records:
- Lane A status,
- Lane B status,
- disagreement taxon,
- best-pose margin,
- shadow lower margin,
- sampled-gap margin,
- LP margin,
- contact-direction overlap.

## Disagreement taxonomy

The current taxonomy is intentionally simple and operational:

- `agreement-feasible`
- `agreement-infeasible`
- `truncation-too-loose`
- `motion-box-issue`
- `symmetry-transport-or-motion-box-issue`
- `fourier-extraction-or-width-prescreen-mismatch`
- `conditioning-or-fourier-extraction`
- `true-unresolved-case`

This is a debugging ledger, not a theorem.

## Maturity ladder

The shadow lane now has an explicit maturity ladder.

- **S0**: sampled support-gap shadow check only
- **S1**: width + Helly/LP prescreens + sampled-gap comparison
- **S2**: sampled Fourier truncation shadow check with disagreement batch
- **S3**: exploratory fixed-`theta` PSD/SOS backend
- **S4**: certified PSD/residual verification with rigorous truncation control

Current status is **between S1 and S2**:
- the batch disagreement framework exists,
- the truncation object is still sampled rather than rigorous,
- therefore the lane remains shadow-only.

## Correctness boundary

This lane does **not** change:
- interval predicates,
- rigid-box feasible/infeasible/unresolved semantics,
- witness-fit truth conditions,
- certificate export truth conditions.

Lane A still owns proof-facing motion-space claims.
Lane B currently owns only shadow diagnostics on fixed-`theta` sample structures.

## Recommended next move

The next clean step is to keep expanding the disagreement matrix before promoting the spectral lane:

1. stabilize disagreement counts across more candidate states,
2. replace sampled tail proxies by rigorous truncation bounds for round/arc families first,
3. add a true fixed-`theta` PSD/SOS backend only after that,
4. then decide whether any part of Lane B can move from shadow to proof-facing status.


## v2.0ac tension batch and first real truncation module

The next shadow-lane step is now implemented under:
- `results/certificates/v2_0ac_shadow_tension_batch/`

### What changed

The old sampled tail proxy has been replaced, for shadow-lane purposes, by a first real truncation module:
- round / regular witnesses use an `empirical-k2-tail-envelope` bound,
- sharp witnesses currently stay on an `observed-tail-plus-grid` bound.

This is still **not theorem-grade rigorous truncation**, but it is no longer just a single sampled remainder number. The module now combines:
1. an observed grid tail,
2. an observed coefficient tail beyond the retained order,
3. a simple extrapolated tail term.

### Tension-batch construction

For each repaired-cascade best pose, the exporter now constructs three explicit fixed-`theta` poses:
- `certified-seed-pose`
- `near-boundary-feasible`
- `negative-control`

The two derived poses are built by shifting translation along the sampled minimum-gap direction. This gives a controlled way to stress Lane B near the feasible/infeasible boundary without changing Lane A's proof-facing ownership of the original certified pose.

### Current batch result

Across 4 states and 5 witnesses:
- base repaired-cascade agreements: `20 / 20`
- tension poses: `60`
- truncation-module usage:
  - `empirical-k2-tail-envelope`: `48`
  - `observed-tail-plus-grid`: `12`

By tension class:
- `certified-seed-pose`: `20 / 20` `shadow-truncation-positive`
- `negative-control`: `20 / 20` `shadow-inconclusive`
- `near-boundary-feasible`:
  - `12 / 20` `shadow-truncation-positive`
  - `8 / 20` `sampled-feasible-with-helly`

The informative split is that the 8 truncation-limited near-boundary cases are exactly the more curved / round-adjacent witnesses that the revised spectral proposal warned would need truncation discipline before any stronger claims. In the current batch, those are the `orbiform-stub` and `regular-3-gon` cases.

### Updated maturity reading

This moves Lane B solidly into **S2 exploratory truncation**:
- there is now a real truncation module,
- it discriminates between easy feasible, near-boundary feasible, and negative-control poses,
- but the 8 near-boundary holdouts show that the truncation layer is still too loose for proof-facing use.

So the lane remains shadow-only, but it is now informative in exactly the way we wanted from a tension batch.


## v2.0ad high-k tail-fit envelope (Fix 1)

The v2.0ac tension batch showed that the only remaining near-boundary holdouts were:
- `orbiform-stub`
- `regular-3-gon`

across all four tested container states. The failure mode was cleanly truncation-limited rather than geometric.

### What changed

For the round / regular shadow lane, the all-`k` `k^{-2}` tail envelope was replaced by a **high-`k` tail-fit envelope with a conservative monotone cap**:
- the fit is taken only from the extreme high-frequency window near `N_ext`,
- a monotone suffix cap is applied on that fit window,
- the resulting scale is used only for the unknown tail beyond `N_ext`.

This keeps the retained and observed mid-frequency harmonics in the known part of the truncation budget instead of letting them inflate the asymptotic tail estimate.

### Batch result

The exact same `60`-pose tension batch was rerun with no other changes.

Result:
- `20 / 20` seed poses: `shadow-truncation-positive`
- `20 / 20` near-boundary poses: `shadow-truncation-positive`
- `20 / 20` negative controls: `shadow-inconclusive`

So the decision tree closed at **Fix 1**:
- Fix 1 cleared the holdouts,
- therefore the fallback `N_ext = 128` confirmation pass was not required.

### Interpretation

This strongly suggests that the v2.0ac holdouts were caused by **envelope quality**, not by insufficient extended order and not by a deeper architectural problem.

The tension batch should now be treated as a standing regression harness for any future truncation changes.

## v2.0ae — exploratory fixed-theta Toeplitz SOS lane

A restricted S3a shadow lane is now present for a small hard subset: the formerly truncation-limited near-boundary cases for `orbiform-stub` and `regular-3-gon`, with matched negative controls across the same four container states. Instead of a full SDP solve, the lane builds the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of that matrix is a sufficient certificate for nonnegativity of the truncated polynomial; failure only rejects this restricted ansatz, not the full SDP/SOS problem.

Current exploratory result:
- near-boundary former holdouts: `8 / 8` `toeplitz-gram-psd-shadow-positive`
- matched negative controls: `8 / 8` `toeplitz-gram-indefinite`

Interpretation: after the high-`k` truncation fix, the shadow lane now separates these hard positives from matched negatives even under a restricted Gram ansatz. The next promotion step is still a genuine SDP-capable backend, but the Toeplitz subset already provides a meaningful S3a cross-check.
