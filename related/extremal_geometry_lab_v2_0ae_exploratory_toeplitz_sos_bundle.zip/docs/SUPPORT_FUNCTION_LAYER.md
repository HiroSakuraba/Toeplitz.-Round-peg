# Support-function / convex-body representation layer

This layer is the shared abstraction layer for the extremal geometry lab.

It now exposes:
- `ConvexBody2D` and `ConvexBody3D`
- support sampling profiles in 2D and 3D
- support-gap profiles for containment and support-distance checks
- piecewise support families in 2D
- sampled support families in 3D
- polygon-backed bodies and pure support-backed bodies
- translation / scaling / reflection / rotation in 2D
- translation / scaling / reflection in 3D
- Minkowski addition at the body level
- difference-body support construction
- approximate polygon reconstruction from support data via support-line intersections
- constant-width and origin-symmetry residuals
- sampled support-based containment checks
- zonotope / ellipse / regular-polygon constructors

## Design principle

A `ConvexBody2D` or `ConvexBody3D` is the proof-facing object.
A polygon or polytope is a useful proxy when available, but support-function algebra is the primary shared language.

## Why this matters

- Lebesgue: candidate covers and witnesses should eventually be support-function-native.
- Moser: many hard worms need convex surrogates, buffers, support distances, and support-based cover models.
- Hadwiger: the 3D lane is most coherent when built directly on support functions and spherical normal data.

## New capabilities in v0.4 direction

1. **Body-to-body support containment**
   The layer can now compare bodies directly by sampled support inequalities, independent of polygon proxies.

2. **Symmetry / width diagnostics**
   Constant-width residuals and origin-symmetry residuals are now first-class utilities.

3. **Richer canonical families**
   Ellipses, regular polygons, and 2D zonotopes can be represented natively through support functions.

4. **Support-line reconstruction**
   Reconstructed polygons now come from support-line intersections rather than a derivative-only formula, which is more stable for nonsmooth bodies.

## Immediate next steps

1. Add interval support envelopes and certified support-gap bounds.
2. Add exact support-family serializers for certificate bundles.
3. Add support-based witness fitting directly in the rigid-motion layer.
4. Add 3D support-family normal-fan refinement for the Hadwiger lane.
