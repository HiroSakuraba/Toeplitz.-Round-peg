# v0.4 support-layer upgrade

This revision strengthens the support-function / convex-body representation so the rest of the lab can become support-native instead of polygon-only.

## Main upgrades

- Added support-gap profiles in 2D and 3D for containment and support-distance checks.
- Added richer body constructors:
  - ellipses,
  - regular polygons,
  - 2D zonotopes.
- Added body-level diagnostics:
  - sampled support containment,
  - support distance,
  - origin-symmetry residuals in 2D/3D,
  - constant-width residual in 3D.
- Replaced derivative-only polygon reconstruction with support-line intersection reconstruction.
- Added provenance metadata on transformed bodies.
- Expanded tests from 17 to 23 passing tests.

## Why this matters

The lab can now express more of the Lebesgue / Moser / Hadwiger geometry directly at the support-function level:

- **Lebesgue:** support-gap and containment checks can drive witness verification without relying on polygon proxies.
- **Moser:** zonotope / ellipse / disk surrogates give a cleaner convex-body vocabulary for hard-worm families and buffers.
- **Hadwiger:** the 3D lane now has support-based width and symmetry diagnostics that match the constant-width plan.

## Immediate next steps

1. Support-based rigid-motion witness fitting.
2. Interval-certified support-gap bounds.
3. Support-native family screens for the Lebesgue lane.
4. Better 3D normal-fan refinement tied to sampled support families.
