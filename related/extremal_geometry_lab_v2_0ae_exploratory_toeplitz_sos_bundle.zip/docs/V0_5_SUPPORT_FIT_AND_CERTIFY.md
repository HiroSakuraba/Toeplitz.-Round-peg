# v0.5 Support-based witness fitting and certified support-gap bounds

This revision adds the first proof-facing bridge from the support-function layer to actual containment logic.

## New capabilities

### 1. Support-based rigid-motion witness fitting in 2D
The fitter samples witness rotations and, for each sampled rotation, solves the finite LP

\[
\max m \quad \text{s.t.}\quad \langle t,u_i\rangle + m \le h_C(u_i)-h_{R\cdot W}(u_i)
\]

by triple-active vertex enumeration in the variables \((t_x,t_y,m)\).

This gives a sampled best translation for a support-defined witness body inside a support-defined container body.

Primary API:
- `fit_body_in_body_support_2d`
- `SupportRigidPlacement2D`

### 2. Interval-style certified support-gap bounds
For planar convex bodies, the support function is Lipschitz on \(S^1\) with constant at most the circumradius upper bound. Therefore the support gap

\[
g(\theta)=h_{\text{target}}(\theta)-h_{\text{container}}(\theta)
\]

is Lipschitz with constant at most

\[
L \le R_{\text{target}} + R_{\text{container}} + \|t\|.
\]

If the gap is sampled on an angular grid of spacing \(\Delta\theta\), then

\[
\sup g \le \max g_{\text{sampled}} + \frac{L\Delta\theta}{2}.
\]

Thus containment is certified whenever the right-hand side is nonpositive.

Primary API:
- `certified_support_gap_bound_2d`
- `certified_support_gap_bound_3d`
- `circumradius_upper_bound_2d`
- `circumradius_upper_bound_3d`
- `support_gap_lipschitz_bound_2d`
- `support_gap_lipschitz_bound_3d`

## Why this matters
This is the first place where the support-function layer becomes part of the proof machinery rather than just a representation layer.

It gives the lab a clean path for:
- support-native containment in the Lebesgue lane,
- support-native witness fitting for convex surrogates in the Moser lane,
- spherical support-gap certification in the Hadwiger lane.

## Current limitations
- the support fitter is still rotation-sampled rather than branch-and-bound certified;
- the 3D certificate needs a user-supplied spherical covering radius;
- the certification is Lipschitz-based rather than interval-subdivision-based.

## Immediate next step
Replace the sampled rotation search with interval-certified rotation refinement in the Lebesgue lane.
