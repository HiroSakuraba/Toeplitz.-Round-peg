# v0.6 interval-certified rotation refinement

## Main change
Version 0.6 replaces the old coarse sampled-angle search in the 2D support fitter with a branch-and-bound **interval-certified rotation refinement** layer.

## New APIs
- `RotationInterval2D`
- `SupportRotationRefinement2D`
- `refine_body_in_body_support_rotation_2d`
- updated `fit_body_in_body_support_2d`

## Logic
For an angle interval centered at `theta_0` with half-width `w`, the engine computes:

1. the best sampled translation at `theta_0` by the support LP,
2. a **feasibility certificate**: if the support-gap certificate at the center pose plus rotational drift is still nonpositive, then the same translation works throughout the interval,
3. an **impossibility certificate**: if the sampled LP optimum at the center plus rotational drift is still negative, then no rotation in the interval can fit.

Intervals that are neither certified feasible nor certified infeasible are subdivided.

## Current status
- The fitter now returns the best center pose discovered during refinement.
- When the best pose lies in a certified feasible interval, the returned pose carries a certified upper-violation bound.
- The implementation is still 2D only.

## Important limitation
The refinement is only interval-certified in **rotation**. Translation is still solved at interval centers, and the existence certificate is based on reusing the center translation across the whole interval. This is strong enough for proof-facing progress in the Lebesgue lane, but not yet the final form of a full rigid-motion certificate.

## Tests
The suite now has 31 passing tests, including:
- full-angle feasible classification for nested disks,
- full-angle infeasible classification for too-large disks,
- interval-refinement metadata on polygon-in-disk fits,
- unresolved-interval behavior under zero refinement depth.
