# v0.7 interval rigid-motion certificates

This revision upgrades the 2D support-native fitter from angle-only interval refinement to a genuine rigid-motion certificate.

## Main idea

For each angle interval $I=[	heta_- , 	heta_+]$, we solve the support LP at the center angle $	heta_c$ and obtain a center translation $t_c$ and sampled margin $m_c$.

Using the support-gap certificate at the center pose and a rotation Lipschitz bound $L_{rot}$ for the witness, we obtain a certified upper violation

$$
V_I \le V_{center} + L_{rot}\,|I|/2.
$$

If $V_I < 0$, then the center pose works for the whole angle interval.

To certify a **translation interval box**, we observe that perturbing translation by $\delta t$ changes every support constraint by at most $\|\delta t\|_2$. Therefore any axis-aligned box around $t_c$ with Euclidean radius at most $-V_I$ is certified feasible over the full angle interval.

The code exports such a box as `TranslationIntervalBox2D`, and each certified feasible rotation interval now yields a `RigidMotionBox2D`.

## Limitation

This still uses a center translation and proves that a whole translation box around that center works. It does not yet optimize translation interval boxes directly.
