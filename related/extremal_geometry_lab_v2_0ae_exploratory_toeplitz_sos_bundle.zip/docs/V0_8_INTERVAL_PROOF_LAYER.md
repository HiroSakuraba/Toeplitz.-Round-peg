# v0.8 interval proof-layer upgrade

Version 0.8 adds a genuine interval-certified support-gap checker for polygon-backed 2D bodies.

## What changed

The older proof layer certified containment by combining sampled support gaps with a global Lipschitz drift term. That route remains available, but it can be loose.

The new checker partitions the circle into angular cells and, on each cell, encloses

- the container support function from below,
- the target support function from above,

using `mpmath.iv` interval trigonometry applied directly to the polygon vertices.

For a polygon body with vertices `v`, the support on an angular cell `I` is enclosed by

`h_K(I) = max_v <v, (cos I, sin I)>`.

This yields a cellwise upper bound on support violation

`sup_{theta in I} (h_target(theta) - h_container(theta)) <= h_target(I)^+ - h_container(I)^-`.

Taking the maximum over all cells gives a proof-facing upper bound for the whole circle.

## Scope

This is currently implemented only when both bodies have polygon proxies. If either body lacks a polygon proxy, the checker falls back to the older Lipschitz certificate.

## Why this is the right next move

It upgrades the proof layer materially without forcing a rewrite around a heavy external interval branch-and-bound library. It is also directly compatible with the future joint `(theta, t_x, t_y)` interval search.

## 3D lane revision

The roadmap is now split in two:

- computational first lane: centrally symmetric bodies
- theorem-strong lane: constant-width bodies

That keeps the first 3D implementation structurally simple while preserving the stronger theorem-facing target.
