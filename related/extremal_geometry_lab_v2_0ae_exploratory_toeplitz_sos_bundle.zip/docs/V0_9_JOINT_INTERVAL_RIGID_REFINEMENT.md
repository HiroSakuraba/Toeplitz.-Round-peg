# v0.9 native joint interval rigid-motion refinement

Version 0.9 adds the first native interval branch-and-bound in rigid-motion space:

- rotation interval `[theta_lo, theta_hi]`
- translation interval `[tx_lo, tx_hi]`
- translation interval `[ty_lo, ty_hi]`

implemented by `refine_body_in_body_support_rigid_2d`.

## What is new mathematically

The v0.7 certificate proved:

- one center translation works for all rotations in an angle interval,
- then converted leftover robust margin into a derived translation box.

The v0.9 certificate instead works directly on a rigid-motion box.

For a direction cell `alpha in I` and a rotation interval `theta in J`, the rotated witness support is evaluated on the shifted angle interval

`alpha - theta in I - J`.

So the cellwise worst-case support violation is bounded by

`h_W(I-J)^+ + sup_{t in T} <t, u(I)> - h_C(I)^-`.

Taking the maximum over all angular cells gives an upper bound on the worst support violation over the entire rigid-motion box.

If that upper bound is nonpositive, the whole box is certified feasible.

## Infeasibility pruning

A box is certified infeasible when a sampled violation at the box midpoint dominates the full pose drift across the box:

- rotational drift bounded by `R_W * delta_theta`,
- translational drift bounded by the box translation radius.

This is still conservative, but it is enough to prune obviously impossible regions.

## Why this matters

This is the first point where the proof layer is no longer only proving statements about a sampled pose plus a derived buffer. It is proving a statement about a region of rigid-motion space directly.

## Current weak point

The box certifier is strongest when support intervals are exact or nearly exact:
- polygon-backed bodies,
- constant-support bodies such as disks.

General smooth support functions still fall back to Lipschitz intervals, which can be loose.
