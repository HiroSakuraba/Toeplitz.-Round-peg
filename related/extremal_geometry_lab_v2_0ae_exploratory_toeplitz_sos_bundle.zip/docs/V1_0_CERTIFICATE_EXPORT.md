# v1.0 certificate export

Version 1.0 closes the most immediate proof-interface gap from v0.9: native rigid-motion refinement results can now be exported as stable artifacts under `results/certificates/`.

## What is exported

For a call to `export_rigid_motion_refinement_bundle`, the exporter writes:

1. a machine-readable JSON bundle with schema `rigid-motion-refinement.v1`,
2. a human-readable markdown summary of the classified boxes,
3. a per-cell support audit for one exported feasible box with schema `support-cell-bounds.v1`.

## Why this matters

The rigid-motion refiner no longer terminates in opaque Python objects only. A certified feasible box can now be handed to another model or a human reviewer together with:

- the exact translation box and rotation interval being certified,
- the midpoint pose and drift bounds used in pruning,
- the support certification method used on the box,
- the cellwise support upper-violation data that explains the final certificate.

## Current limitations

- export is box-level, not yet witness-family-level,
- support-cell audits still recompute interval enclosures instead of using a cache,
- non-polygon bodies still fall back to coarse Lipschitz support bounds,
- the demo artifact is deliberately small and not a theorem-strength Lebesgue or Moser result.
