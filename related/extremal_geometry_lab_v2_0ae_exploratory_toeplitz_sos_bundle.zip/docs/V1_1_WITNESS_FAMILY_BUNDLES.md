# v1.2 witness-family coexistence certificates

Version 1.2 keeps the v1.1 interval-support cache and upgrades the witness-family exporter from a directory of independent per-witness bundles into a product-space coexistence certificate.

## Export layout

Calling `export_witness_family_bundle(base_dir, container=..., witnesses=[...])` now writes:

- `base_dir/summary.{json,md}`: top-level index artifact,
- `base_dir/coexistence.{json,md}`: the actual joint product-space certificate,
- `base_dir/NN_<witness-name>/bundle.{json,md}`: per-witness rigid-motion certificate bundles.

## Canonical box selection

For each witness, the exporter chooses a canonical certified-feasible box by preferring:

1. smaller certified upper violation,
2. smaller angular width,
3. smaller translation widths.

This makes the top-level joint certificate deterministic rather than traversal-order dependent.

## Current limitations

- the coexistence certificate lives in the product of independent witness pose spaces,
- it is not yet a non-overlap or packing certificate,
- smooth non-polygon witnesses still rely on fallback bounds when no sharper support interval is available.
