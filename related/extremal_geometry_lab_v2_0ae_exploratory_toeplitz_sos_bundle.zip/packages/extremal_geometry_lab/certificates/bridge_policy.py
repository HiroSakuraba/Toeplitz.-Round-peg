from __future__ import annotations

BRIDGE_LADDER_LEVELS: dict[str, dict] = {
    "light": {
        "angle_steps": 24,
        "cert_n": 48,
        "initial_theta_intervals": 4,
        "initial_translation_intervals": 4,
        "max_depth": 1,
        "use_rotation_seed_translation_bounds": True,
        "rotation_seed_translation_pad": 0.1,
        "best_pose_neighborhood_min_half_extent": 0.05,
        "best_pose_neighborhood_margin_scale": 1.0,
        "localized_deepening": True,
        "localized_deepening_pad": 0.05,
        "localized_far_box_depth_penalty": 1,
        "anisotropic_policy": "off",
    },
    "real": {
        "angle_steps": 48,
        "cert_n": 96,
        "initial_theta_intervals": 4,
        "initial_translation_intervals": 4,
        "max_depth": 2,
        "use_rotation_seed_translation_bounds": True,
        "rotation_seed_translation_pad": 0.1,
        "best_pose_neighborhood_min_half_extent": 0.05,
        "best_pose_neighborhood_margin_scale": 1.0,
        "localized_deepening": True,
        "localized_deepening_pad": 0.05,
        "localized_far_box_depth_penalty": 1,
        "anisotropic_policy": "off",
    },
    "confirm": {
        "angle_steps": 64,
        "cert_n": 128,
        "initial_theta_intervals": 4,
        "initial_translation_intervals": 4,
        "max_depth": 4,
        "use_rotation_seed_translation_bounds": True,
        "rotation_seed_translation_pad": 0.1,
        "best_pose_neighborhood_min_half_extent": 0.05,
        "best_pose_neighborhood_margin_scale": 1.0,
        "localized_deepening": True,
        "localized_deepening_pad": 0.05,
        "localized_far_box_depth_penalty": 1,
        "anisotropic_policy": "off",
    },
}


def bridge_refine_kwargs(level: str, /, **overrides) -> dict:
    key = str(level).strip().lower()
    if key not in BRIDGE_LADDER_LEVELS:
        raise KeyError(f"unknown bridge ladder level: {level}")
    out = dict(BRIDGE_LADDER_LEVELS[key])
    out.update(overrides)
    return out


def bridge_ladder_sequence(levels: tuple[str, ...] | list[str] | None = None) -> list[dict]:
    if levels is None:
        levels = ["light", "real", "confirm"]
    seq: list[dict] = []
    for level in levels:
        rec = {"name": str(level)}
        rec.update(bridge_refine_kwargs(str(level)))
        seq.append(rec)
    return seq


BRIDGE_CASCADE_LEVELS: dict[str, list[dict]] = {
    "light": [
        {"name": "light", **BRIDGE_LADDER_LEVELS["light"]},
    ],
    "real": [
        {"name": "light", **BRIDGE_LADDER_LEVELS["light"]},
        {"name": "real", **BRIDGE_LADDER_LEVELS["real"]},
    ],
    "confirm": [
        {"name": "light", **BRIDGE_LADDER_LEVELS["light"]},
        {"name": "real", **BRIDGE_LADDER_LEVELS["real"]},
        {"name": "confirm", **BRIDGE_LADDER_LEVELS["confirm"]},
    ],
}


def bridge_cascade(level: str, /, **overrides) -> list[dict]:
    key = str(level).strip().lower()
    if key not in BRIDGE_CASCADE_LEVELS:
        raise KeyError(f"unknown bridge cascade level: {level}")
    seq: list[dict] = []
    for stage in BRIDGE_CASCADE_LEVELS[key]:
        rec = dict(stage)
        rec.update(overrides)
        seq.append(rec)
    return seq


def sticky_locked_priority_score(*, witness_name: str, width_spread: float | None = None, thin_direction_count: int | None = None) -> float:
    """Heuristic-only priority score for witnesses likely to need fine confirmation.

    This intentionally stays on the search side. It does *not* alter any proof
    predicate or certificate semantics; it only helps decide whether a witness
    should be escalated to finer cascade stages.
    """
    name = str(witness_name).strip().lower()
    score = 0.0
    if 'regular-3-gon' in name or 'triangle' in name:
        score += 3.0
    elif 'regular-4-gon' in name or 'square' in name:
        score += 2.0
    elif 'orbiform' in name or 'pal-seed' in name:
        score += 2.0
    elif 'segment' in name or 'disk-half' in name:
        score += 1.0
    if width_spread is not None:
        if float(width_spread) <= 0.02:
            score += 1.5
        elif float(width_spread) <= 0.08:
            score += 0.75
    if thin_direction_count is not None and int(thin_direction_count) >= 4:
        score += 0.5
    return float(score)
