"""Certificate file formats and bundle exporters."""
from __future__ import annotations

from dataclasses import asdict, is_dataclass
import itertools
import json
import math
import numpy as np
from pathlib import Path
from typing import Any


def _sanitize(obj: Any) -> Any:
    """Recursively convert objects into stable JSON-friendly structures."""
    if is_dataclass(obj):
        obj = asdict(obj)
    if isinstance(obj, dict):
        return {str(k): _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize(v) for v in obj]
    if isinstance(obj, float):
        if math.isnan(obj):
            return "nan"
        if math.isinf(obj):
            return "inf" if obj > 0 else "-inf"
        return float(obj)
    if isinstance(obj, (int, str, bool)) or obj is None:
        return obj
    return str(obj)


def write_certificate(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_sanitize(payload), indent=2), encoding="utf-8")



def write_certificate_bundle(base: Path, *, machine: dict, human_markdown: str) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    base.with_suffix(".json").write_text(json.dumps(_sanitize(machine), indent=2), encoding="utf-8")
    base.with_suffix(".md").write_text(human_markdown, encoding="utf-8")



# --- Width prescreen certificate helpers ---


def width_prescreen_payload(*, family: str, state_name: str, result) -> dict:
    cert = result.width_certificate
    return {
        "schema_version": "width-prescreen.v1",
        "family": str(family),
        "state_name": str(state_name),
        "passed": bool(result.passed),
        "reason": str(result.reason),
        "required_width": float(cert.required_width),
        "certified_lower_width": float(cert.certified_lower_width),
        "details": _sanitize(cert.details),
    }


def width_prescreen_markdown(payload: dict) -> str:
    lines = [
        f"# Width prescreen certificate: {payload['state_name']}",
        "",
        f"- schema: `{payload['schema_version']}`",
        f"- family: `{payload['family']}`",
        f"- passed: `{payload['passed']}`",
        f"- reason: `{payload['reason']}`",
        f"- required width: `{payload['required_width']}`",
        f"- certified lower width: `{payload['certified_lower_width']}`",
        "",
        "## Details",
        f"- worst cell: `{payload['details'].get('worst_cell')}`",
        f"- cell width: `{payload['details'].get('cell_width')}`",
        f"- support methods: `{payload['details'].get('methods')}`",
        "",
    ]
    return "\n".join(lines)


def export_width_prescreen_bundle(base, *, family: str, state_name: str, result) -> dict:
    payload = width_prescreen_payload(family=family, state_name=state_name, result=result)
    write_certificate_bundle(base, machine=payload, human_markdown=width_prescreen_markdown(payload))
    return payload



def rounded_candidate_self_verify_payload(*, family: str, state_name: str, state: dict, result) -> dict:
    construction = _sanitize(dict(state.get("construction") or {}))
    proxy = state.get("polygon")
    body = state.get("body")
    meta = _sanitize(getattr(body, "metadata", {}) or {})
    arc_replacements = _sanitize(list(state.get("arc_replacements", [])))
    cert = result.width_certificate
    payload = {
        "schema_version": "rounded-candidate-self-verify.v1",
        "family": str(family),
        "state_name": str(state_name),
        "claim": "width-prescreen-pass" if bool(result.passed) else "width-prescreen-fail",
        "required_width": float(cert.required_width),
        "certified_lower_width": float(cert.certified_lower_width),
        "support_methods": _sanitize(cert.details.get("methods", [])),
        "construction": construction,
        "arc_replacements": arc_replacements,
        "body_metadata": meta,
        "verification_algorithm": (
            "Replay the rounded candidate as a Minkowski sum of the stored base polygon and a disk of the stored rounding radius. "
            "For each angular cell [theta_j, theta_{j+1}], lower-bound the width by combining a lower bound for the base polygon support on that cell and on the antipodal cell, then add 2*r for the disk summand. "
            "The minimum over cells is the certified lower width. If it is at least the required width, the candidate passes the width prescreen."
        ),
        "theorems_used": [
            "Support-sum rule: h_{A+B}(u) = h_A(u) + h_B(u)",
            "Width identity: w_K(theta) = h_K(theta) + h_K(theta+pi)",
            "For a disk of radius r, h(theta) = r in every direction, so w(theta) = 2r",
        ],
    }
    if proxy is not None:
        payload["polygon_proxy_vertices"] = proxy.vertices.tolist()
    base_vertices = construction.get("base_polygon_vertices") if isinstance(construction, dict) else None
    if base_vertices:
        payload["base_polygon_vertices"] = base_vertices
    return payload



def rounded_candidate_markdown(payload: dict) -> str:
    construction = payload.get("construction", {}) or {}
    lines = [
        f"# Rounded candidate certificate: {payload['state_name']}",
        "",
        f"- schema: `{payload['schema_version']}`",
        f"- family: `{payload['family']}`",
        f"- claim: `{payload['claim']}`",
        f"- required width: `{payload['required_width']}`",
        f"- certified lower width: `{payload['certified_lower_width']}`",
        f"- support methods: `{payload.get('support_methods')}`",
        "",
        "## Construction",
        f"- kind: `{construction.get('kind', 'unknown')}`",
        f"- base polygon: `{construction.get('base_polygon')}`",
        f"- rounded radius: `{construction.get('rounded_radius')}`",
        f"- arc replacements: `{payload.get('arc_replacements')}`",
        "",
        "## Independent verification",
        payload.get('verification_algorithm', ''),
        "",
    ]
    return "\n".join(lines)


def export_rounded_candidate_bundle(base, *, family: str, state_name: str, state: dict, result) -> dict:
    payload = rounded_candidate_self_verify_payload(family=family, state_name=state_name, state=state, result=result)
    write_certificate_bundle(base, machine=payload, human_markdown=rounded_candidate_markdown(payload))
    return payload

# --- Stable rigid-motion certificate schema helpers ---


def _box_theta_interval_for_audit(box) -> tuple[float, float]:
    details = getattr(box, "details", {}) or {}
    if "theta_center" in details and "theta_width" in details:
        center = float(details["theta_center"])
        width = abs(float(details["theta_width"]))
        return (center - 0.5 * width, center + 0.5 * width)
    return (float(box.rotation_lo), float(box.rotation_hi))



def rigid_motion_box_payload(box, *, index: int | None = None) -> dict:
    theta_audit_lo, theta_audit_hi = _box_theta_interval_for_audit(box)
    payload = {
        "rotation_interval": {
            "theta_lo": float(box.rotation_lo),
            "theta_hi": float(box.rotation_hi),
            "theta_lo_audit": float(theta_audit_lo),
            "theta_hi_audit": float(theta_audit_hi),
            "theta_center": float(getattr(box, "details", {}).get("theta_center", 0.5 * (theta_audit_lo + theta_audit_hi))),
            "theta_width": float(getattr(box, "details", {}).get("theta_width", theta_audit_hi - theta_audit_lo)),
        },
        "translation_box": {
            "tx_lo": float(box.translation_box.tx_lo),
            "tx_hi": float(box.translation_box.tx_hi),
            "ty_lo": float(box.translation_box.ty_lo),
            "ty_hi": float(box.translation_box.ty_hi),
            "l2_radius": float(box.translation_box.l2_radius),
        },
        "certified_feasible": bool(box.certified_feasible),
        "certified_infeasible": bool(box.certified_infeasible),
        "details": _sanitize(box.details),
    }
    if index is not None:
        payload["box_index"] = int(index)
    return payload



def refinement_summary_payload(refinement, *, container_name: str, witness_name: str) -> dict:
    best = refinement.best_pose
    return {
        "schema_version": "rigid-motion-refinement.v1",
        "container": str(container_name),
        "witness": str(witness_name),
        "best_pose": {
            "rotation": float(best.rotation),
            "translation": [float(best.translation[0]), float(best.translation[1])],
            "sampled_margin": float(best.sampled_margin),
            "sampled_max_violation": float(best.sampled_max_violation),
            "certified_upper_violation": None if best.certified_upper_violation is None else float(best.certified_upper_violation),
            "details": _sanitize(best.details or {}),
        },
        "counts": {
            "certified_feasible_boxes": len(refinement.certified_feasible_boxes),
            "certified_infeasible_boxes": len(refinement.certified_infeasible_boxes),
            "unresolved_boxes": len(refinement.unresolved_boxes),
            "explored_boxes": len(refinement.explored_boxes),
        },
        "classification_complete": bool(refinement.all_boxes_classified),
        "has_certified_feasible_box": bool(refinement.has_certified_feasible_box),
    }



def support_cell_bounds_payload(container, witness, *, box, n: int = 128, dps: int = 60) -> dict:
    """Return per-cell support bounds for a rigid-motion box certificate.

    The payload is deliberately verbose so a human or another AI can audit the
    upper-violation estimate cell by cell without reopening internal classes.
    """
    from extremal_geometry_lab.core.rigid_fit import _support_interval_with_fallback, _translation_term_upper
    from extremal_geometry_lab.core.interval_cache import IntervalSupportCache2D

    cache = IntervalSupportCache2D()
    delta = 2.0 * math.pi / max(1, int(n))
    theta_lo_audit, theta_hi_audit = _box_theta_interval_for_audit(box)
    cells: list[dict] = []
    max_upper = -float("inf")
    for j in range(int(n)):
        alpha_lo = j * delta
        alpha_hi = (j + 1) * delta
        (c_lo, c_hi), c_method = _support_interval_with_fallback(container, alpha_lo, alpha_hi, dps=dps, cache=cache)
        beta_lo = alpha_lo - theta_hi_audit
        beta_hi = alpha_hi - theta_lo_audit
        (w_lo, w_hi), w_method = _support_interval_with_fallback(witness, beta_lo, beta_hi, dps=dps, cache=cache)
        trans_hi = _translation_term_upper(box.translation_box, alpha_lo, alpha_hi, dps=dps, cache=cache)
        upper = float(w_hi + trans_hi - c_lo)
        max_upper = max(max_upper, upper)
        cells.append({
            "cell_index": int(j),
            "direction_interval": {"alpha_lo": float(alpha_lo), "alpha_hi": float(alpha_hi)},
            "container_support": {"lo": float(c_lo), "hi": float(c_hi), "method": c_method},
            "witness_support": {"lo": float(w_lo), "hi": float(w_hi), "method": w_method},
            "translation_term_upper": float(trans_hi),
            "cell_upper_violation": float(upper),
        })
    cells_sorted = sorted(cells, key=lambda rec: rec["cell_upper_violation"], reverse=True)
    return {
        "schema_version": "support-cell-bounds.v1",
        "support_cell_count": int(n),
        "cell_width": float(delta),
        "dps": int(dps),
        "max_cell_upper_violation": float(max_upper if max_upper != -float("inf") else 0.0),
        "worst_cells": cells_sorted[: min(10, len(cells_sorted))],
        "cells": cells,
        "cache": {
            "support_hits": cache.support_hits,
            "support_misses": cache.support_misses,
            "trig_hits": cache.trig_hits,
            "trig_misses": cache.trig_misses,
        },
    }



def _contact_system_for_pose(container, witness, *, rotation: float, translation: tuple[float, float], sample_count: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, float]:
    sample_count = max(8, int(sample_count))
    angles = np.linspace(0.0, 2.0 * math.pi, sample_count, endpoint=False)
    dirs = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    wrot = witness.rotate(float(rotation), name=f"rot({getattr(witness, 'name', 'witness')})")
    rhs = np.array([float(container.support_value(u) - wrot.support_value(u)) for u in dirs], dtype=float)
    t = np.array([float(translation[0]), float(translation[1])], dtype=float)
    slacks = rhs - (dirs @ t)
    margin = float(np.min(slacks)) if len(slacks) else 0.0
    return angles, dirs, rhs, margin


def minimal_contact_certificate_payload(container, witness, placement, *, sample_count: int | None = None, tol: float = 1e-7) -> dict:
    """Compress a local support-LP placement into a small active-contact certificate.

    The exported contact set is capped at three directions, matching the ambient
    LP dimension ``(t_x, t_y, m)``. When three independent contacts are found,
    the payload also includes the solved pose recovered from those contacts.
    """
    details = getattr(placement, "details", {}) or {}
    n = int(sample_count if sample_count is not None else details.get("sample_count", 180))
    rotation = float(getattr(placement, "rotation"))
    translation = tuple(float(x) for x in getattr(placement, "translation"))
    angles, dirs, rhs, margin = _contact_system_for_pose(
        container, witness, rotation=rotation, translation=translation, sample_count=n
    )
    t = np.array(translation, dtype=float)
    eq_resid = np.abs(dirs @ t + margin - rhs)
    global_violation = float(np.max(dirs @ t + margin - rhs)) if len(rhs) else 0.0

    candidate_pool = [int(i) for i in (getattr(placement, "active_indices", ()) or ())]
    near_active = [int(i) for i in np.where(eq_resid <= max(float(tol), 1e-6))[0].tolist()]
    for idx in near_active:
        if idx not in candidate_pool:
            candidate_pool.append(idx)
    if not candidate_pool:
        candidate_pool = list(np.argsort(eq_resid)[: min(8, len(eq_resid))])
    pool = candidate_pool[: min(8, len(candidate_pool))]
    if not pool:
        pool = [int(np.argmin(eq_resid))] if len(eq_resid) else []

    full_A = np.column_stack([dirs[:, 0], dirs[:, 1], np.ones(len(dirs), dtype=float)]) if len(dirs) else np.zeros((0, 3), dtype=float)
    chosen = None
    best_key = None
    for k in range(min(3, len(pool)), 0, -1):
        for subset in itertools.combinations(pool, k):
            A = np.column_stack([dirs[list(subset), 0], dirs[list(subset), 1], np.ones(k, dtype=float)])
            b = rhs[list(subset)]
            rank = int(np.linalg.matrix_rank(A, tol=max(float(tol), 1e-10)))
            if k == 3 and rank == 3:
                try:
                    x = np.linalg.solve(A, b)
                except np.linalg.LinAlgError:
                    continue
                sub_resid = float(np.max(np.abs(A @ x - b)))
                feas_violation = float(np.max(full_A @ x - rhs)) if len(rhs) else 0.0
                key = (0, sub_resid, feas_violation, float(np.linalg.cond(A)))
                if best_key is None or key < best_key:
                    best_key = key
                    chosen = {
                        "indices": tuple(int(i) for i in subset),
                        "rank": rank,
                        "solve_translation": (float(x[0]), float(x[1])),
                        "solve_margin": float(x[2]),
                        "max_equality_residual": sub_resid,
                        "max_global_violation": feas_violation,
                        "verification_method": "algebraic-solve",
                    }
            else:
                sub_resid = float(np.max(eq_resid[list(subset)])) if subset else 0.0
                key = (1, -k, sub_resid)
                if best_key is None or key < best_key:
                    best_key = key
                    chosen = {
                        "indices": tuple(int(i) for i in subset),
                        "rank": rank,
                        "solve_translation": translation,
                        "solve_margin": float(margin),
                        "max_equality_residual": sub_resid,
                        "max_global_violation": global_violation,
                        "verification_method": "pose-replay",
                    }
        if chosen is not None and (chosen["verification_method"] == "algebraic-solve" or len(chosen["indices"]) == k):
            break

    subset = tuple(chosen["indices"]) if chosen is not None else tuple()
    active_directions = [float(angles[i]) for i in subset]
    active_rhs = [float(rhs[i]) for i in subset]
    return {
        "schema_version": "minimal-contact-certificate.v1",
        "rotation": rotation,
        "translation": [float(translation[0]), float(translation[1])],
        "margin": float(margin),
        "sample_count": int(n),
        "active_indices": [int(i) for i in subset],
        "active_directions": active_directions,
        "active_rhs": active_rhs,
        "candidate_pool_size": int(len(pool)),
        "verification_method": chosen.get("verification_method", "pose-replay") if chosen else "pose-replay",
        "rank": int(chosen.get("rank", 0)) if chosen else 0,
        "solved_from_contacts": {
            "translation": [float(chosen["solve_translation"][0]), float(chosen["solve_translation"][1])] if chosen else [float(translation[0]), float(translation[1])],
            "margin": float(chosen.get("solve_margin", margin)) if chosen else float(margin),
        },
        "max_active_equality_residual": float(chosen.get("max_equality_residual", 0.0)) if chosen else 0.0,
        "max_global_violation": float(chosen.get("max_global_violation", global_violation)) if chosen else float(global_violation),
        "contact_cardinality": int(len(subset)),
        "caratheodory_bound": 3,
        "verification_algorithm": (
            "Given the exported active directions alpha_i and right-hand sides rhs_i, form the linear equalities cos(alpha_i) tx + sin(alpha_i) ty + m = rhs_i. "
            "If three independent contacts are present, solve this 3x3 system for (tx, ty, m). Then verify the global inequalities cos(alpha_j) tx + sin(alpha_j) ty + m <= rhs_j across the sampled support directions used by the local LP. "
            "If fewer than three contacts are exported, replay verification at the exported pose and margin instead of solving a square system."
        ),
    }


def self_verifying_box_payload(container, witness, *, box, n: int = 128, dps: int = 60) -> dict:
    """Return a portable verification recipe for a rigid-motion box certificate."""
    payload = {
        "schema_version": "rigid-motion-self-verify.v1",
        "claim": "feasible" if bool(getattr(box, "certified_feasible", False)) else ("infeasible" if bool(getattr(box, "certified_infeasible", False)) else "unresolved"),
        "verification_cells": int(n),
        "dps": int(dps),
        "rigid_motion_box": rigid_motion_box_payload(box),
        "theorems_used": [
            "Support containment: K subset L iff h_K(u) <= h_L(u) for all directions u",
            "Rigid motion support rule: h_{R W + t}(u) = h_W(R^T u) + <t,u>",
            "Interval enclosure on angular cells bounds the worst support violation on each cell",
        ],
        "verification_algorithm": (
            "Partition [0, 2pi) into N angular cells. For each cell, enclose the container support below, the witness support above after inverse-rotating by the box rotation interval, and the translation term above over the box translation interval. The cell upper violation is witness_upper + translation_upper - container_lower. If the maximum cell upper violation is <= 0, the rigid-motion box is certified feasible."
        ),
    }
    cpoly = getattr(container, "polygon_proxy", None)
    wpoly = getattr(witness, "polygon_proxy", None)
    if cpoly is not None and wpoly is not None:
        payload["container_vertices"] = cpoly.vertices.tolist()
        payload["witness_vertices"] = wpoly.vertices.tolist()
    else:
        payload["geometry_note"] = "raw vertices unavailable; replay requires body-specific support routines"
    return payload


def refinement_bundle_payload(
    refinement,
    *,
    container_name: str,
    witness_name: str,
    include_explored: bool = False,
    container=None,
    witness=None,
) -> dict:
    payload = refinement_summary_payload(refinement, container_name=container_name, witness_name=witness_name)
    payload["certified_feasible_boxes"] = [
        rigid_motion_box_payload(box, index=i) for i, box in enumerate(refinement.certified_feasible_boxes)
    ]
    payload["certified_infeasible_boxes"] = [
        rigid_motion_box_payload(box, index=i) for i, box in enumerate(refinement.certified_infeasible_boxes)
    ]
    payload["unresolved_boxes"] = [
        rigid_motion_box_payload(box, index=i) for i, box in enumerate(refinement.unresolved_boxes)
    ]
    if include_explored:
        payload["explored_boxes"] = [
            rigid_motion_box_payload(box, index=i) for i, box in enumerate(refinement.explored_boxes)
        ]
    if container is not None and witness is not None and getattr(refinement, 'best_pose', None) is not None:
        payload["best_pose_minimal_contact_certificate"] = minimal_contact_certificate_payload(container, witness, refinement.best_pose)
    details = dict((getattr(getattr(refinement, 'best_pose', None), 'details', {}) or {}))
    if details.get('cascaded_refinement'):
        payload['cascaded_refinement'] = True
        payload['cascade_stage_count'] = int(details.get('cascade_stage_count', 0))
        payload['cascade_stage_records'] = list(details.get('cascade_stage_records', []))
        payload['cascade_priority_hypothesis'] = details.get('cascade_priority_hypothesis')
        payload['cascade_witness_priority_score'] = details.get('cascade_witness_priority_score')
    return payload



def refinement_bundle_markdown(
    refinement,
    *,
    container_name: str,
    witness_name: str,
    support_cell_payload: dict | None = None,
) -> str:
    summary = refinement_summary_payload(refinement, container_name=container_name, witness_name=witness_name)
    best = summary["best_pose"]
    lines = [
        f"# Rigid-motion certificate bundle: {witness_name} in {container_name}",
        "",
        "## Summary",
        f"- schema: `{summary['schema_version']}`",
        f"- classification complete: `{summary['classification_complete']}`",
        f"- certified feasible boxes: `{summary['counts']['certified_feasible_boxes']}`",
        f"- certified infeasible boxes: `{summary['counts']['certified_infeasible_boxes']}`",
        f"- unresolved boxes: `{summary['counts']['unresolved_boxes']}`",
        f"- explored boxes: `{summary['counts']['explored_boxes']}`",
        "",
        "## Best midpoint pose found during refinement",
        f"- rotation: `{best['rotation']}`",
        f"- translation: `{tuple(best['translation'])}`",
        f"- sampled margin: `{best['sampled_margin']}`",
        f"- sampled max violation: `{best['sampled_max_violation']}`",
        f"- certified upper violation: `{best['certified_upper_violation']}`",
        "",
    ]

    def _box_lines(title: str, boxes: list) -> None:
        lines.extend([f"## {title}", ""])
        if not boxes:
            lines.append("- none")
            lines.append("")
            return
        for i, box in enumerate(boxes):
            details = box.details
            lines.extend([
                f"### Box {i}",
                f"- theta interval: `[{box.rotation_lo}, {box.rotation_hi}]`",
                f"- translation box: `[{box.translation_box.tx_lo}, {box.translation_box.tx_hi}] x [{box.translation_box.ty_lo}, {box.translation_box.ty_hi}]`",
                f"- l2 translation radius: `{box.translation_box.l2_radius}`",
                f"- certified upper violation: `{details.get('certified_upper_violation')}`",
                f"- midpoint sampled margin: `{details.get('center_sampled_margin')}`",
                f"- midpoint sampled max violation: `{details.get('center_sampled_max_violation')}`",
                f"- pose drift bound: `{details.get('pose_drift_bound')}`",
                f"- certification method: `{details.get('cert_method')}`",
                f"- depth: `{details.get('depth')}`",
                "",
            ])

    details = dict((getattr(getattr(refinement, 'best_pose', None), 'details', {}) or {}))
    if details.get('cascaded_refinement'):
        lines.extend([
            '## Cascade provenance',
            '',
            f"- stage count: `{details.get('cascade_stage_count', 0)}`",
            f"- priority hypothesis: `{details.get('cascade_priority_hypothesis')}`",
            f"- witness priority score: `{details.get('cascade_witness_priority_score')}`",
            '',
        ])
        for rec in details.get('cascade_stage_records', []):
            lines.extend([
                f"### Stage {rec.get('stage_index')} — {rec.get('stage_name')}",
                f"- seed source: `{rec.get('seed_source')}`",
                f"- input seed boxes: `{rec.get('input_seed_box_count')}`",
                f"- input theta seeds: `{rec.get('input_theta_seed_count')}`",
                f"- output counts: `{rec.get('output_counts')}`",
                f"- promoted: `{rec.get('promoted')}` ({rec.get('promote_reason')})",
                '',
            ])
    _box_lines("Certified feasible boxes", list(refinement.certified_feasible_boxes))
    _box_lines("Certified infeasible boxes", list(refinement.certified_infeasible_boxes))
    _box_lines("Unresolved boxes", list(refinement.unresolved_boxes))

    if hasattr(refinement, 'best_pose'):
        try:
            bp = getattr(refinement, 'best_pose')
            if getattr(bp, 'details', None) and 'minimal_contact_certificate' in bp.details:
                mc = bp.details['minimal_contact_certificate']
                lines.extend([
                    '## Minimal active-contact certificate for best pose',
                    '',
                    f"- contact cardinality: `{mc.get('contact_cardinality')}`",
                    f"- active indices: `{mc.get('active_indices')}`",
                    f"- verification method: `{mc.get('verification_method')}`",
                    f"- max active equality residual: `{mc.get('max_active_equality_residual')}`",
                    f"- max global violation: `{mc.get('max_global_violation')}`",
                    '',
                ])
        except Exception:
            pass

    if support_cell_payload is not None:
        lines.extend([
            "## Support-cell audit for exported box",
            f"- schema: `{support_cell_payload['schema_version']}`",
            f"- support cells: `{support_cell_payload['support_cell_count']}`",
            f"- cell width: `{support_cell_payload['cell_width']}`",
            f"- max cell upper violation: `{support_cell_payload['max_cell_upper_violation']}`",
            "",
            "### Worst cells",
            "",
        ])
        for rec in support_cell_payload.get("worst_cells", []):
            lines.extend([
                f"- cell {rec['cell_index']}: upper violation `{rec['cell_upper_violation']}`, direction interval `[{rec['direction_interval']['alpha_lo']}, {rec['direction_interval']['alpha_hi']}]`, container method `{rec['container_support']['method']}`, witness method `{rec['witness_support']['method']}`",
            ])
        lines.extend([
            "",
            "## Independent verification",
            "- the machine payload includes `self_verifying_certificate` with the exact box, geometry payload when available, and a replay algorithm summary.",
            "",
        ])
    return "\n".join(lines)



def export_rigid_motion_refinement_bundle(
    base: Path,
    *,
    container,
    witness,
    refinement,
    support_box_index: int | None = 0,
    support_cell_count: int | None = None,
    dps: int = 60,
    include_explored: bool = False,
) -> dict:
    machine = refinement_bundle_payload(
        refinement,
        container_name=getattr(container, "name", "container"),
        witness_name=getattr(witness, "name", "witness"),
        include_explored=include_explored,
        container=container,
        witness=witness,
    )
    if getattr(refinement, "best_pose", None) is not None:
        try:
            refinement.best_pose.details = {**(getattr(refinement.best_pose, "details", {}) or {}), "minimal_contact_certificate": machine.get("best_pose_minimal_contact_certificate")}
        except Exception:
            pass
    support_payload = None
    if support_box_index is not None and refinement.certified_feasible_boxes:
        idx = max(0, min(int(support_box_index), len(refinement.certified_feasible_boxes) - 1))
        audit_box = refinement.certified_feasible_boxes[idx]
        audit_n = int(support_cell_count if support_cell_count is not None else (getattr(audit_box, "details", {}) or {}).get("cert_n", 128))
        audit_dps = int(dps if dps is not None else (getattr(audit_box, "details", {}) or {}).get("dps", 60))
        support_payload = support_cell_bounds_payload(
            container,
            witness,
            box=audit_box,
            n=audit_n,
            dps=audit_dps,
        )
        machine["exported_support_box_index"] = int(idx)
        machine["support_cell_bounds"] = support_payload
        machine["self_verifying_certificate"] = self_verifying_box_payload(container, witness, box=audit_box, n=audit_n, dps=audit_dps)
    human = refinement_bundle_markdown(
        refinement,
        container_name=getattr(container, "name", "container"),
        witness_name=getattr(witness, "name", "witness"),
        support_cell_payload=support_payload,
    )
    write_certificate_bundle(base, machine=machine, human_markdown=human)
    return machine


# --- Witness-family aggregation and joint coexistence certificates ---


def _slug(name: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(name).strip())
    while "__" in safe:
        safe = safe.replace("__", "_")
    return safe.strip("_") or "witness"



def _box_selection_key(box) -> tuple[float, float, float, float]:
    details = getattr(box, "details", {}) or {}
    upper = float(details.get("certified_upper_violation", 0.0))
    theta_width = abs(float(details.get("theta_width", 0.0)))
    tx_width = float(box.translation_box.tx_hi - box.translation_box.tx_lo)
    ty_width = float(box.translation_box.ty_hi - box.translation_box.ty_lo)
    return (upper, theta_width, tx_width + ty_width, box.translation_box.l2_radius)



def select_joint_feasible_box(refinement) -> tuple[int | None, object | None]:
    """Choose a canonical certified-feasible box for joint coexistence export.

    The policy is deterministic and prefers more robust boxes first:
    lower certified upper violation, then smaller widths.
    """
    boxes = list(getattr(refinement, "certified_feasible_boxes", ()) or ())
    if not boxes:
        return None, None
    indexed = list(enumerate(boxes))
    idx, box = min(indexed, key=lambda rec: _box_selection_key(rec[1]))
    return int(idx), box



def coexistence_product_payload(
    *,
    container_name: str,
    witness_entries: list[dict],
) -> dict:
    selected = [w for w in witness_entries if w.get("selected_box") is not None]
    missing = [
        {
            "index": int(w["index"]),
            "name": str(w["name"]),
            "reason": "no certified feasible rigid-motion box exported",
        }
        for w in witness_entries
        if w.get("selected_box") is None
    ]
    joint_certified = len(missing) == 0 and len(selected) == len(witness_entries)
    return {
        "schema_version": "witness-family-coexistence.v1",
        "container": str(container_name),
        "certificate_kind": "product-space-feasibility-region",
        "joint_certified": bool(joint_certified),
        "witness_count": int(len(witness_entries)),
        "joint_pose_dimension": int(3 * len(witness_entries)),
        "all_refinements_classified": bool(all(bool(w.get("classification_complete")) for w in witness_entries)),
        "selected_product_region": [
            {
                "index": int(w["index"]),
                "name": str(w["name"]),
                "bundle_path": str(w["bundle_path"]),
                "selected_box_index": int(w["selected_box_index"]),
                "selected_box": _sanitize(w["selected_box"]),
            }
            for w in selected
        ],
        "missing_witnesses": missing,
        "interpretation": {
            "semantics": "Every tuple of poses chosen independently from the selected per-witness rigid-motion boxes is certified feasible for the corresponding witness in the common container.",
            "not_certified": "This does not certify disjointness or non-overlap among witnesses, and it does not force a single shared pose variable across different witnesses.",
        },
    }



def coexistence_product_markdown(coexistence: dict) -> str:
    lines = [
        f"# Witness-family coexistence certificate: {coexistence['container']}",
        "",
        f"- schema: `{coexistence['schema_version']}`",
        f"- certificate kind: `{coexistence['certificate_kind']}`",
        f"- joint certified: `{coexistence['joint_certified']}`",
        f"- witness count: `{coexistence['witness_count']}`",
        f"- joint pose dimension: `{coexistence['joint_pose_dimension']}`",
        f"- all refinements classified: `{coexistence['all_refinements_classified']}`",
        "",
        "## Interpretation",
        f"- {coexistence['interpretation']['semantics']}",
        f"- {coexistence['interpretation']['not_certified']}",
        "",
        "## Selected product region",
        "",
    ]
    if not coexistence["selected_product_region"]:
        lines.extend(["- none", ""])
    else:
        for rec in coexistence["selected_product_region"]:
            box = rec["selected_box"]
            theta = box["rotation_interval"]
            tbox = box["translation_box"]
            lines.extend([
                f"### {rec['index']:02d} `{rec['name']}`",
                f"- bundle: `{rec['bundle_path']}`",
                f"- selected box index: `{rec['selected_box_index']}`",
                f"- theta audit interval: `[{theta['theta_lo_audit']}, {theta['theta_hi_audit']}]`",
                f"- translation box: `[{tbox['tx_lo']}, {tbox['tx_hi']}] x [{tbox['ty_lo']}, {tbox['ty_hi']}]`",
                f"- certified upper violation: `{box['details'].get('certified_upper_violation')}`",
                "",
            ])
    lines.extend(["## Missing witnesses", ""])
    if not coexistence["missing_witnesses"]:
        lines.extend(["- none", ""])
    else:
        for rec in coexistence["missing_witnesses"]:
            lines.append(f"- {rec['index']:02d} `{rec['name']}`: {rec['reason']}")
        lines.append("")
    return "\n".join(lines)



def export_witness_family_bundle(
    base_dir: Path,
    *,
    container,
    witnesses: list,
    refine_kwargs: dict | None = None,
    per_witness_support_audit: bool = True,
) -> dict:
    """Export a witness-family certificate bundle directory.

    This version upgrades the earlier scaffold into an actual joint
    coexistence certificate by selecting one certified feasible rigid-motion box
    for each witness and exporting the resulting Cartesian product in the
    independent witness pose variables.
    """
    from extremal_geometry_lab.core.rigid_fit import refine_body_in_body_support_rigid_2d, cascaded_rigid_refinement

    refine_kwargs = dict(refine_kwargs or {})
    cascade_stages = refine_kwargs.pop('cascade_stages', None)
    cascade_pad = float(refine_kwargs.pop('cascade_pad', 0.05))
    sticky_locked_priority = bool(refine_kwargs.pop('sticky_locked_priority', True))
    escalation_incomplete_volume_ratio = float(refine_kwargs.pop('escalation_incomplete_volume_ratio', 0.35))
    escalation_max_unresolved_boxes = int(refine_kwargs.pop('escalation_max_unresolved_boxes', 96))
    base_dir.mkdir(parents=True, exist_ok=True)

    witness_entries: list[dict] = []
    for idx, witness in enumerate(witnesses):
        if cascade_stages:
            refinement = cascaded_rigid_refinement(
                container,
                witness,
                stages=cascade_stages,
                pad=cascade_pad,
                escalation_incomplete_volume_ratio=escalation_incomplete_volume_ratio,
                escalation_max_unresolved_boxes=escalation_max_unresolved_boxes,
                sticky_locked_priority=sticky_locked_priority,
            )
        else:
            refinement = refine_body_in_body_support_rigid_2d(container, witness, **refine_kwargs)
        witness_slug = f"{idx:02d}_{_slug(getattr(witness, 'name', f'witness_{idx}'))}"
        out_base = base_dir / witness_slug / "bundle"
        out_base.parent.mkdir(parents=True, exist_ok=True)
        selected_box_index, selected_box = select_joint_feasible_box(refinement)
        export_rigid_motion_refinement_bundle(
            out_base,
            container=container,
            witness=witness,
            refinement=refinement,
            support_box_index=selected_box_index if (per_witness_support_audit and selected_box is not None) else None,
            support_cell_count=None,
            dps=refine_kwargs.get("dps", 60),
            include_explored=False,
        )
        witness_entries.append({
            "index": idx,
            "name": getattr(witness, "name", f"witness_{idx}"),
            "has_certified_feasible_box": bool(refinement.has_certified_feasible_box),
            "classification_complete": bool(refinement.all_boxes_classified),
            "counts": {
                "certified_feasible_boxes": len(refinement.certified_feasible_boxes),
                "certified_infeasible_boxes": len(refinement.certified_infeasible_boxes),
                "unresolved_boxes": len(refinement.unresolved_boxes),
                "explored_boxes": len(refinement.explored_boxes),
            },
            "bundle_path": str(out_base.with_suffix(".json").relative_to(base_dir)),
            "selected_box_index": selected_box_index,
            "selected_box": None if selected_box is None else rigid_motion_box_payload(selected_box, index=selected_box_index),
        })

    coexistence = coexistence_product_payload(
        container_name=getattr(container, "name", "container"),
        witness_entries=witness_entries,
    )
    write_certificate_bundle(
        base_dir / "coexistence",
        machine=coexistence,
        human_markdown=coexistence_product_markdown(coexistence),
    )

    summary = {
        "schema_version": "witness-family-bundle.v2",
        "container": getattr(container, "name", "container"),
        "witness_count": len(witnesses),
        "joint_coexistence_path": "coexistence.json",
        "joint_certified": bool(coexistence["joint_certified"]),
        "witnesses": [
            {
                "index": int(w["index"]),
                "name": str(w["name"]),
                "has_certified_feasible_box": bool(w["has_certified_feasible_box"]),
                "classification_complete": bool(w["classification_complete"]),
                "counts": _sanitize(w["counts"]),
                "bundle_path": str(w["bundle_path"]),
                "selected_box_index": None if w["selected_box_index"] is None else int(w["selected_box_index"]),
            }
            for w in witness_entries
        ],
    }

    human_lines = [
        f"# Witness-family bundle: {summary['container']}",
        "",
        f"- schema: `{summary['schema_version']}`",
        f"- witness count: `{summary['witness_count']}`",
        f"- joint coexistence path: `{summary['joint_coexistence_path']}`",
        f"- joint certified: `{summary['joint_certified']}`",
        "",
        "## Witness status",
        "",
    ]
    for w in summary["witnesses"]:
        human_lines.append(
            f"- {w['index']:02d} `{w['name']}`: feasible `{w['has_certified_feasible_box']}`, complete `{w['classification_complete']}`, selected box `{w['selected_box_index']}`, bundle `{w['bundle_path']}`"
        )
    write_certificate_bundle(base_dir / "summary", machine=summary, human_markdown="\n".join(human_lines))
    return summary
