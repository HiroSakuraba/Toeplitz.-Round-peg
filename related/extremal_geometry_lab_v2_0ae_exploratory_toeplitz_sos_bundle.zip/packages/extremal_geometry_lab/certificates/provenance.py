from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class CertificateChainLink:
    claim: str
    method: str
    inputs: tuple[str, ...]
    output: str
    bound: float
    depth: int
    metadata: dict = field(default_factory=dict)


@dataclass(slots=True)
class CertificateChain:
    links: tuple[CertificateChainLink, ...]

    def verify_composition(self, *, initial_available: tuple[str, ...] = ()) -> bool:
        available = set(str(x) for x in initial_available)
        for link in self.links:
            if not all(inp in available for inp in link.inputs):
                return False
            available.add(link.output)
        return True

    def weakest_link(self) -> CertificateChainLink | None:
        if not self.links:
            return None
        return max(self.links, key=lambda link: float(link.bound))

    def to_payload(self) -> dict:
        return {
            "links": [
                {
                    "claim": str(link.claim),
                    "method": str(link.method),
                    "inputs": [str(x) for x in link.inputs],
                    "output": str(link.output),
                    "bound": float(link.bound),
                    "depth": int(link.depth),
                    "metadata": dict(link.metadata),
                }
                for link in self.links
            ],
            "compositional": bool(self.verify_composition()),
            "weakest_link": None if self.weakest_link() is None else str(self.weakest_link().output),
        }


__all__ = ["CertificateChainLink", "CertificateChain"]
