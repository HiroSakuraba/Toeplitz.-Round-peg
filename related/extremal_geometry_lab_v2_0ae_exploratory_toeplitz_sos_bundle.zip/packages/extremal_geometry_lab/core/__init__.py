from .geometry_types import ConvexPolygon2D, Polyline2D, SupportFunction2D, SupportFunction3D, Interval, IntervalBox, SphericalDirectionSet
from .minkowski import (
    minkowski_sum_dispatch,
    minkowski_sum_polygons,
    difference_body_polygon,
    sampled_disk,
    buffer_polygon,
    polyline_tube,
)
from .interval_cache import IntervalSupportCache2D
from .support import (
    ConvexBody2D,
    ConvexBody3D,
    SupportProfile2D,
    SupportProfile3D,
    SupportGapProfile2D,
    SupportGapProfile3D,
    PiecewiseSupportFamily2D,
    SampledSupportFamily3D,
    body_from_polygon,
    body_from_support_function,
    body3d_from_support_function,
    polygon_support,
    disk_body,
    ball_body_3d,
    segment_body,
    ellipse_body,
    capsule_body,
    regular_ngon_body,
    zonotope_body_2d,
    minkowski_sum_bodies_2d,
    minkowski_sum_bodies_3d,
    difference_body_support_2d,
    reconstruct_polygon_from_support,
    support_distance_2d,
    sampled_contains_body_2d,
    sampled_contains_body_3d,
    constant_width_residual,
    constant_width_residual_3d,
    origin_symmetry_residual_2d,
    origin_symmetry_residual_3d,
)
from .rigid_fit import fit_polygon_in_polygon, fit_polyline_in_polygon, best_contact_pose, SupportRigidPlacement2D, RigidSeedSelection2D, TranslationIntervalBox2D, RigidMotionBox2D, RotationInterval2D, SupportRotationRefinement2D, SupportRigidMotionRefinement2D, refine_body_in_body_support_rotation_2d, refine_body_in_body_support_rigid_2d, fit_body_in_body_support_2d, derive_rigid_seed_from_rotation_fit, cascaded_rigid_refinement
from .rigidity import RigidityReport, assess_rigidity, thickened_rigidity_check
from .certify import Certificate, SupportGapCertificate2D, IntervalSupportGapCertificate2D, SupportGapCertificate3D, certified_area_polygon, certified_contains_polygon, certified_contains_polyline, certified_universal_cover, certified_support_gap_bound_2d, certified_support_gap_bound_2d_interval, certified_support_gap_bound_3d, interval_support_bounds_2d, circumradius_upper_bound_2d, circumradius_upper_bound_3d, support_gap_lipschitz_bound_2d, support_gap_lipschitz_bound_3d

from .prescreen import WidthCertificate2D, certified_min_width_2d, certified_width_prescreen_2d
from .support_lp import SupportLPResult2D

from .topology import BnBTopologySummary, boxes_share_face, analyze_rigid_motion_refinement_topology

from .spectral_shadow import (
    SupportFourierSeries2D,
    TruncationBound2D,
    TranslationTensionPose2D,
    ContactDirectionComparison2D,
    ShadowSpectralPoseReport2D,
    ShadowSpectralCrosscheck2D,
    ShadowDisagreementSummary2D,
    sampled_support_fourier_2d,
    sampled_gap_fourier_series_2d,
    fixed_theta_sampled_lp_translation,
    sampled_body_diameter_2d,
    empirical_gap_truncation_bound_2d,
    sampled_min_gap_direction_2d,
    build_translation_tension_poses_2d,
    compare_contact_directions_2d,
    shadow_spectral_verify_pose_2d,
    summarize_shadow_disagreement_2d,
    shadow_spectral_crosscheck_from_refinement_2d,
)

from .spectral_sos import (
    ToeplitzGramCertificate2D,
    trig_series_exponential_coeffs,
    canonical_toeplitz_gram_from_series,
    toeplitz_gram_certificate_from_series,
    fixed_theta_toeplitz_gram_certificate_2d,
)
