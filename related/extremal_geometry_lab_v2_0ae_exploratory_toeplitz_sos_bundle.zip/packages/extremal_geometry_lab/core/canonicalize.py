
"""Canonicalization and symmetry reduction."""
from __future__ import annotations
from typing import Iterable, Hashable
import numpy as np

from .geometry_types import ConvexPolygon2D


def canonical_tuple(values: Iterable[Hashable]) -> tuple[Hashable, ...]:
    return tuple(sorted(values))


def dihedral_min_rep(sequence: tuple) -> tuple:
    n = len(sequence)
    rots = [sequence[i:] + sequence[:i] for i in range(n)]
    rev = sequence[::-1]
    rev_rots = [rev[i:] + rev[:i] for i in range(n)]
    return min(rots + rev_rots)


def canonical_polygon_signature(poly: ConvexPolygon2D, decimals: int = 8) -> tuple:
    verts = np.asarray(poly.vertices, dtype=float)
    centered = verts - verts.mean(axis=0)
    rounded = [tuple(np.round(v, decimals)) for v in centered]
    return dihedral_min_rep(tuple(rounded))
