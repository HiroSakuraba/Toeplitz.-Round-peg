"""Certification helpers for covering and containment inequalities.

This module now includes support-function-native, interval-style containment
certificates. The key idea is simple:

- sample the support gap on a uniform angular grid,
- bound the unsampled variation by a Lipschitz constant,
- certify containment if the resulting upper bound is nonpositive.

For a convex body K in the plane, h_K is Lipschitz on S^1 with constant at most
R_K, any circumradius upper bound of K. Therefore the support gap
h_target - h_container is Lipschitz with constant at most R_target + R_container.
A translated witness adds |t| to the bound.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import numpy as np

try:
    from mpmath import iv, mp
except Exception:  # pragma: no cover - optional interval backend
    iv = None
    mp = None

from .geometry_types import ConvexPolygon2D, Polyline2D, SphericalDirectionSet
from .halfspace import polygon_halfspace_slack
from .support import ConvexBody2D, ConvexBody3D


@dataclass(slots=True)
class Certificate:
    statement: str
    lower_margin: float
    passed: bool
    details: dict


@dataclass(slots=True)
class SupportGapCertificate2D:
    statement: str
    sampled_upper_violation: float
    certified_upper_violation: float
    sampled_min_margin: float
    lipschitz_bound: float
    angular_step: float
    passed: bool
    details: dict


@dataclass(slots=True)
class IntervalSupportGapCertificate2D:
    statement: str
    sampled_upper_violation: float
    certified_upper_violation: float
    passed: bool
    details: dict


@dataclass(slots=True)
class SupportGapCertificate3D:
    statement: str
    sampled_upper_violation: float
    certified_upper_violation: float
    lipschitz_bound: float
    covering_radius: float
    passed: bool
    details: dict


def certify_sample_margin(statement: str, margins: np.ndarray, tol: float = 1e-9) -> Certificate:
    m = float(np.min(np.asarray(margins, dtype=float)))
    return Certificate(statement=statement, lower_margin=m, passed=(m >= -tol), details={"sample_count": int(np.asarray(margins).size), "tolerance": tol})


def area_polygon(vertices: np.ndarray) -> float:
    verts = np.asarray(vertices, dtype=float)
    x = verts[:, 0]
    y = verts[:, 1]
    return 0.5 * abs(float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1))))


def certified_area_polygon(poly: ConvexPolygon2D) -> Certificate:
    area = area_polygon(poly.vertices)
    return Certificate(statement=f"area({poly.name})", lower_margin=float(area), passed=True, details={"area": float(area)})


def certified_contains_polygon(container: ConvexPolygon2D, witness: ConvexPolygon2D, tol: float = 1e-9) -> Certificate:
    slacks = polygon_halfspace_slack(container, witness.vertices)
    return certify_sample_margin(f"{container.name} contains {witness.name}", slacks, tol=tol)


def certified_contains_polyline(container: ConvexPolygon2D, witness: Polyline2D, tol: float = 1e-9) -> Certificate:
    slacks = polygon_halfspace_slack(container, witness.points)
    return certify_sample_margin(f"{container.name} contains {witness.name}", slacks, tol=tol)


def certified_universal_cover(container: ConvexPolygon2D, witness_family: list[tuple[str, ConvexPolygon2D | Polyline2D]], tol: float = 1e-9) -> Certificate:
    margins = []
    details = {"family": []}
    for name, witness in witness_family:
        if hasattr(witness, 'vertices'):
            cert = certified_contains_polygon(container, witness, tol=tol)
        else:
            cert = certified_contains_polyline(container, witness, tol=tol)
        margins.append(cert.lower_margin)
        details["family"].append({"name": name, "margin": cert.lower_margin, "passed": cert.passed})
    return certify_sample_margin(f"universal-cover screen for {container.name}", np.array(margins), tol=tol)


def volume_proxy_from_support(samples: np.ndarray) -> float:
    vals = np.asarray(samples, dtype=float)
    return float(vals.mean())


# --- Support-gap certification helpers ---

def circumradius_upper_bound_2d(body: ConvexBody2D, n: int = 720) -> float:
    if getattr(body, "polygon_proxy", None) is not None:
        return float(np.max(np.linalg.norm(body.polygon_proxy.vertices, axis=1)))
    prof = body.sample_support(n=n)
    return float(np.max(prof.values)) if len(prof.values) else 0.0


def circumradius_upper_bound_3d(body: ConvexBody3D, directions: np.ndarray | SphericalDirectionSet) -> float:
    prof = body.sample_support(directions)
    return float(np.max(prof.values)) if len(prof.values) else 0.0


def support_gap_lipschitz_bound_2d(container: ConvexBody2D, target: ConvexBody2D, *, translation_norm: float = 0.0, radius_samples: int = 720) -> float:
    rc = circumradius_upper_bound_2d(container, n=radius_samples)
    rt = circumradius_upper_bound_2d(target, n=radius_samples)
    return float(rc + rt + abs(float(translation_norm)))


def support_gap_lipschitz_bound_3d(container: ConvexBody3D, target: ConvexBody3D, directions: np.ndarray | SphericalDirectionSet, *, translation_norm: float = 0.0) -> float:
    rc = circumradius_upper_bound_3d(container, directions)
    rt = circumradius_upper_bound_3d(target, directions)
    return float(rc + rt + abs(float(translation_norm)))


def certified_support_gap_bound_2d(
    container: ConvexBody2D,
    target: ConvexBody2D,
    *,
    n: int = 720,
    translation_norm: float = 0.0,
    tol: float = 0.0,
) -> SupportGapCertificate2D:
    gap = container.sample_gap(target, n=n)
    sampled_sup_gap = float(np.max(-gap.gaps)) if len(gap.gaps) else 0.0
    sampled_min_margin = float(np.min(gap.gaps)) if len(gap.gaps) else 0.0
    L = support_gap_lipschitz_bound_2d(container, target, translation_norm=translation_norm, radius_samples=max(720, n))
    delta = 2.0 * math.pi / max(1, int(n))
    cert_sup = sampled_sup_gap + 0.5 * L * delta
    return SupportGapCertificate2D(
        statement=f"support containment of {target.name} in {container.name}",
        sampled_upper_violation=sampled_sup_gap,
        certified_upper_violation=float(cert_sup),
        sampled_min_margin=sampled_min_margin,
        lipschitz_bound=L,
        angular_step=delta,
        passed=bool(cert_sup <= tol),
        details={"sample_count": int(n), "tolerance": float(tol)},
    )


def _as_interval_scalar(value: object) -> tuple[float, float]:
    if hasattr(value, "a") and hasattr(value, "b"):
        return (float(value.a), float(value.b))
    return (float(value), float(value))


def _interval_cos_sin(theta_lo: float, theta_hi: float) -> tuple[tuple[float, float], tuple[float, float]]:
    if iv is None:
        raise RuntimeError("mpmath.iv is unavailable")
    theta_iv = iv.mpf([float(theta_lo), float(theta_hi)])
    c_iv = iv.cos(theta_iv)
    s_iv = iv.sin(theta_iv)
    return _as_interval_scalar(c_iv), _as_interval_scalar(s_iv)


def _polygon_support_interval_from_vertices(vertices: np.ndarray, theta_lo: float, theta_hi: float) -> tuple[float, float]:
    if iv is None:
        raise RuntimeError("mpmath.iv is unavailable")
    verts = np.asarray(vertices, dtype=float)
    (c_lo, c_hi), (s_lo, s_hi) = _interval_cos_sin(theta_lo, theta_hi)
    lo = -float("inf")
    hi = -float("inf")
    for x, y in verts:
        term_lo = min(x * c_lo, x * c_hi) + min(y * s_lo, y * s_hi)
        term_hi = max(x * c_lo, x * c_hi) + max(y * s_lo, y * s_hi)
        lo = max(lo, float(term_lo))
        hi = max(hi, float(term_hi))
    return lo, hi


def interval_support_bounds_2d(
    body: ConvexBody2D,
    theta_lo: float,
    theta_hi: float,
    *,
    dps: int = 50,
) -> tuple[float, float] | None:
    """Return rigorous support bounds on an angular arc when an interval hook exists.

    The preferred path is a body-supplied ``support_interval`` hook, which can
    provide analytic interval bounds for non-polygon bodies (for example disks,
    segments, ellipses, or future arc/segment constructions). If that is absent,
    the function falls back to exact interval support for polygon proxies using
    ``mpmath.iv``. If neither is available, return ``None`` so callers can use a
    coarser certification fallback.
    """
    hook = getattr(body, "support_interval", None)
    if hook is not None:
        bounds = hook(theta_lo, theta_hi)
        if bounds is not None:
            return (float(bounds[0]), float(bounds[1]))
    poly = getattr(body, "polygon_proxy", None)
    if poly is None or iv is None:
        return None
    if mp is not None:
        mp.dps = max(int(dps), 30)
    return _polygon_support_interval_from_vertices(poly.vertices, theta_lo, theta_hi)


def certified_support_gap_bound_2d_interval(
    container: ConvexBody2D,
    target: ConvexBody2D,
    *,
    n: int = 360,
    tol: float = 0.0,
    dps: int = 50,
) -> IntervalSupportGapCertificate2D:
    """Interval-certified 2D support-gap bound for polygon-backed bodies.

    The circle is partitioned into ``n`` angular cells. On each cell we enclose
    both support functions using interval trigonometry applied to the polygon
    vertices, and certify the worst-case support violation on that entire cell.

    If either body lacks a polygon proxy, this function falls back to the older
    Lipschitz-based certificate and records that choice in ``details``.
    """
    c0 = interval_support_bounds_2d(container, 0.0, 2.0 * math.pi / max(1, int(n)), dps=dps)
    t0 = interval_support_bounds_2d(target, 0.0, 2.0 * math.pi / max(1, int(n)), dps=dps)
    if c0 is None or t0 is None:
        fallback = certified_support_gap_bound_2d(container, target, n=n, tol=tol)
        return IntervalSupportGapCertificate2D(
            statement=fallback.statement,
            sampled_upper_violation=float(fallback.sampled_upper_violation),
            certified_upper_violation=float(fallback.certified_upper_violation),
            passed=bool(fallback.passed),
            details={**fallback.details, "method": "lipschitz-fallback", "interval_backend": bool(iv is not None)},
        )

    delta = 2.0 * math.pi / max(1, int(n))
    sampled_gap = container.sample_gap(target, n=n)
    sampled_sup_gap = float(np.max(-sampled_gap.gaps)) if len(sampled_gap.gaps) else 0.0
    cell_upper_violations: list[float] = []
    for j in range(int(n)):
        theta_lo = j * delta
        theta_hi = (j + 1) * delta
        c_lo, c_hi = interval_support_bounds_2d(container, theta_lo, theta_hi, dps=dps)
        t_lo, t_hi = interval_support_bounds_2d(target, theta_lo, theta_hi, dps=dps)
        cell_upper_violations.append(float(t_hi - c_lo))
    cert_sup = float(max(cell_upper_violations) if cell_upper_violations else 0.0)
    container_method = "support-hook" if getattr(container, "support_interval", None) is not None else "polygon-proxy"
    target_method = "support-hook" if getattr(target, "support_interval", None) is not None else "polygon-proxy"
    overall_method = "interval-polygon-support" if container_method == "polygon-proxy" and target_method == "polygon-proxy" else "interval-support-hook"
    return IntervalSupportGapCertificate2D(
        statement=f"interval support containment of {target.name} in {container.name}",
        sampled_upper_violation=sampled_sup_gap,
        certified_upper_violation=cert_sup,
        passed=bool(cert_sup <= tol),
        details={
            "sample_count": int(n),
            "cell_width": float(delta),
            "tolerance": float(tol),
            "method": overall_method,
            "interval_backend": bool(iv is not None),
            "body_methods": {"container": container_method, "target": target_method},
            "dps": int(max(int(dps), 30)),
            "max_cell_upper_violation": cert_sup,
            "cell_upper_violations": cell_upper_violations,
        },
    )


def certified_support_gap_bound_3d(
    container: ConvexBody3D,
    target: ConvexBody3D,
    directions: np.ndarray | SphericalDirectionSet,
    *,
    covering_radius: float,
    translation_norm: float = 0.0,
    tol: float = 0.0,
) -> SupportGapCertificate3D:
    gap = container.sample_gap(target, directions=directions)
    sampled_sup_gap = float(np.max(-gap.gaps)) if len(gap.gaps) else 0.0
    L = support_gap_lipschitz_bound_3d(container, target, directions, translation_norm=translation_norm)
    cert_sup = sampled_sup_gap + L * float(covering_radius)
    count = len(directions.directions) if isinstance(directions, SphericalDirectionSet) else len(np.asarray(directions))
    return SupportGapCertificate3D(
        statement=f"support containment of {target.name} in {container.name}",
        sampled_upper_violation=sampled_sup_gap,
        certified_upper_violation=float(cert_sup),
        lipschitz_bound=L,
        covering_radius=float(covering_radius),
        passed=bool(cert_sup <= tol),
        details={"sample_count": int(count), "tolerance": float(tol)},
    )
