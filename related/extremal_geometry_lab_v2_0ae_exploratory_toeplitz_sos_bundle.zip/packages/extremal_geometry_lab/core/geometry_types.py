
"""Shared geometric types for the extremal geometry lab.

These types are intentionally lightweight. They are designed to support both
search-stage floating point experiments and proof-stage exact/interval hooks.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Iterable
import math
import numpy as np

Array = np.ndarray

@dataclass(slots=True)
class Interval:
    low: float
    high: float

    def width(self) -> float:
        return float(self.high - self.low)

    def contains(self, value: float) -> bool:
        return self.low <= value <= self.high

@dataclass(slots=True)
class IntervalBox:
    intervals: tuple[Interval, ...]

    def inflate(self, eps: float) -> "IntervalBox":
        return IntervalBox(tuple(Interval(iv.low - eps, iv.high + eps) for iv in self.intervals))

@dataclass(slots=True)
class ConvexPolygon2D:
    vertices: Array
    name: str = "polygon"
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        verts = np.asarray(self.vertices, dtype=float)
        if verts.ndim != 2 or verts.shape[1] != 2:
            raise ValueError("vertices must have shape (n,2)")
        self.vertices = verts

    @property
    def n(self) -> int:
        return int(self.vertices.shape[0])

    def centroid(self) -> Array:
        return self.vertices.mean(axis=0)

    def translated(self, shift: Array) -> "ConvexPolygon2D":
        shift = np.asarray(shift, dtype=float)
        return ConvexPolygon2D(self.vertices + shift, name=self.name, metadata=dict(self.metadata))

    def rotated(self, theta: float) -> "ConvexPolygon2D":
        c, s = math.cos(theta), math.sin(theta)
        R = np.array([[c, -s], [s, c]], dtype=float)
        return ConvexPolygon2D(self.vertices @ R.T, name=self.name, metadata=dict(self.metadata))

@dataclass(slots=True)
class Polyline2D:
    points: Array
    name: str = "polyline"
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        pts = np.asarray(self.points, dtype=float)
        if pts.ndim != 2 or pts.shape[1] != 2:
            raise ValueError("points must have shape (n,2)")
        self.points = pts

@dataclass(slots=True)
class SupportFunction2D:
    evaluator: Callable[[Array], float]
    name: str = "support2d"
    metadata: dict = field(default_factory=dict)

    def value(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        return float(self.evaluator(u))

    def value_angle(self, theta: float) -> float:
        return self.value(np.array([math.cos(theta), math.sin(theta)], dtype=float))

@dataclass(slots=True)
class SupportFunction3D:
    evaluator: Callable[[Array], float]
    name: str = "support3d"
    metadata: dict = field(default_factory=dict)

    def value(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        return float(self.evaluator(u))

@dataclass(slots=True)
class SphericalDirectionSet:
    directions: Array
    name: str = "sphere-dirs"

    def normalized(self) -> "SphericalDirectionSet":
        dirs = np.asarray(self.directions, dtype=float)
        norms = np.linalg.norm(dirs, axis=1, keepdims=True)
        norms[norms == 0.0] = 1.0
        return SphericalDirectionSet(dirs / norms, self.name)
