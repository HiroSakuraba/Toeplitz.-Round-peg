"""Halfspace slack utilities shared by fitting and certification."""

from __future__ import annotations

import numpy as np

from .geometry_types import ConvexPolygon2D, Array


def polygon_halfspace_slack(poly: ConvexPolygon2D, points: Array) -> Array:
    """Minimum signed halfspace slack for each point (positive means inside)."""
    verts = poly.vertices
    slacks = []
    for i in range(len(verts)):
        a = verts[i]
        b = verts[(i + 1) % len(verts)]
        edge = b - a
        normal = np.array([edge[1], -edge[0]], dtype=float)
        normal /= max(np.linalg.norm(normal), 1e-15)
        centroid = verts.mean(axis=0)
        if float(np.dot(normal, centroid - a)) < 0.0:
            normal = -normal
        slacks.append((points - a) @ normal)
    return np.min(np.stack(slacks, axis=1), axis=1)
