"""Interval-bound caching utilities for proof-facing interval work."""

from __future__ import annotations

from dataclasses import dataclass, field
import math

import numpy as np

from .support import ConvexBody2D
from .certify import circumradius_upper_bound_2d, interval_support_bounds_2d


def _kfloat(x: float, *, ndigits: int = 15) -> float:
    return float(round(float(x), ndigits))


@dataclass(slots=True)
class IntervalSupportCache2D:
    """Cache interval enclosures needed by proof-layer box certification."""

    ndigits: int = 12
    support_hits: int = 0
    support_misses: int = 0
    trig_hits: int = 0
    trig_misses: int = 0

    _support: dict = field(default_factory=dict, init=False, repr=False)
    _trig: dict = field(default_factory=dict, init=False, repr=False)

    def support_bounds_with_fallback(
        self,
        body: ConvexBody2D,
        theta_lo: float,
        theta_hi: float,
        *,
        dps: int = 60,
        constant_support_samples: int = 64,
    ) -> tuple[tuple[float, float], str]:
        meta = getattr(body, "metadata", {}) or {}
        if meta.get("family") == "euclidean-ball" and "radius" in meta:
            r = float(meta["radius"])
            return ((r, r), "constant-family")

        a = float(theta_lo)
        b = float(theta_hi)
        if b < a:
            a, b = b, a
        key = (id(body), _kfloat(a, ndigits=self.ndigits), _kfloat(b, ndigits=self.ndigits), int(dps))
        if key in self._support:
            self.support_hits += 1
            return self._support[key]
        self.support_misses += 1

        bounds = interval_support_bounds_2d(body, a, b, dps=int(dps))
        if bounds is not None:
            method = "analytic-interval" if getattr(body, "support_interval", None) is not None else "interval"
            out = ((float(bounds[0]), float(bounds[1])), method)
            self._support[key] = out
            return out

        prof = body.sample_support(n=int(constant_support_samples))
        if len(prof.values) and float(np.max(prof.values) - np.min(prof.values)) <= 1e-10:
            value = float(prof.values[0])
            out = ((value, value), "constant-support")
            self._support[key] = out
            return out

        center = 0.5 * (a + b)
        half = 0.5 * abs(b - a)
        rc = float(circumradius_upper_bound_2d(body, n=720))
        value = float(body.h(center))
        out = ((value - rc * half, value + rc * half), "lipschitz")
        self._support[key] = out
        return out

    def cos_sin_bounds(
        self,
        theta_lo: float,
        theta_hi: float,
        *,
        dps: int = 60,
    ) -> tuple[tuple[float, float], tuple[float, float]]:
        a = float(theta_lo)
        b = float(theta_hi)
        if b < a:
            a, b = b, a
        key = (_kfloat(a, ndigits=self.ndigits), _kfloat(b, ndigits=self.ndigits), int(dps))
        if key in self._trig:
            self.trig_hits += 1
            return self._trig[key]
        self.trig_misses += 1
        try:
            from . import certify as _cert
            (c_lo, c_hi), (s_lo, s_hi) = _cert._interval_cos_sin(a, b)
            out = ((float(c_lo), float(c_hi)), (float(s_lo), float(s_hi)))
        except Exception:
            # conservative endpoint/extrema sampling fallback
            pts = [a, b]
            # cos extrema at 0, pi modulo 2pi
            for base in (0.0, math.pi):
                k0 = math.floor((a - base) / (2 * math.pi))
                k1 = math.ceil((b - base) / (2 * math.pi))
                for k in range(int(k0) - 1, int(k1) + 2):
                    t = base + 2 * math.pi * k
                    if a <= t <= b:
                        pts.append(t)
            cvals = [math.cos(t) for t in pts]
            pts2 = [a, b]
            for base in (math.pi / 2, 3 * math.pi / 2):
                k0 = math.floor((a - base) / (2 * math.pi))
                k1 = math.ceil((b - base) / (2 * math.pi))
                for k in range(int(k0) - 1, int(k1) + 2):
                    t = base + 2 * math.pi * k
                    if a <= t <= b:
                        pts2.append(t)
            svals = [math.sin(t) for t in pts2]
            out = ((min(cvals), max(cvals)), (min(svals), max(svals)))
        self._trig[key] = out
        return out