
"""Minkowski operations and witness-generation primitives.

The implementation is deliberately modest but the API is broad enough to serve as
an upgrade path toward exact and interval-certified geometry.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
import math
import numpy as np

from .geometry_types import ConvexPolygon2D, Polyline2D, SupportFunction2D, SupportFunction3D

Array = np.ndarray


def _cross(o: Array, a: Array, b: Array) -> float:
    return float((a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]))


def convex_hull(points: Array) -> Array:
    pts = np.asarray(points, dtype=float)
    if len(pts) <= 1:
        return pts.copy()
    pts = pts[np.lexsort((pts[:, 1], pts[:, 0]))]
    lower: list[Array] = []
    for p in pts:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper: list[Array] = []
    for p in pts[::-1]:
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    hull = np.array(lower[:-1] + upper[:-1], dtype=float)
    return hull


def minkowski_sum_points(points_a: Array, points_b: Array) -> Array:
    a = np.asarray(points_a, dtype=float)
    b = np.asarray(points_b, dtype=float)
    return np.array([x + y for x in a for y in b], dtype=float)


def minkowski_sum_polygons(poly_a: ConvexPolygon2D, poly_b: ConvexPolygon2D) -> ConvexPolygon2D:
    summed = minkowski_sum_points(poly_a.vertices, poly_b.vertices)
    hull = convex_hull(summed)
    return ConvexPolygon2D(hull, name=f"{poly_a.name}+{poly_b.name}", metadata={"parents": [poly_a.name, poly_b.name]})


def support_sum_2d(h_a: SupportFunction2D, h_b: SupportFunction2D, *, name: str | None = None) -> SupportFunction2D:
    return SupportFunction2D(lambda u: h_a.value(u) + h_b.value(u), name=name or f"{h_a.name}+{h_b.name}", metadata={"parents": [h_a.name, h_b.name]})


def support_sum_3d(h_a: SupportFunction3D, h_b: SupportFunction3D, *, name: str | None = None) -> SupportFunction3D:
    return SupportFunction3D(lambda u: h_a.value(u) + h_b.value(u), name=name or f"{h_a.name}+{h_b.name}", metadata={"parents": [h_a.name, h_b.name]})


def reflect_polygon(poly: ConvexPolygon2D) -> ConvexPolygon2D:
    return ConvexPolygon2D(-poly.vertices, name=f"-{poly.name}", metadata={"reflected": poly.name})


def difference_body_polygon(poly: ConvexPolygon2D) -> ConvexPolygon2D:
    return minkowski_sum_polygons(poly, reflect_polygon(poly))


def centered_segment(length: float = 1.0, n: int = 2) -> Array:
    xs = np.linspace(-length / 2.0, length / 2.0, n)
    return np.stack([xs, np.zeros_like(xs)], axis=1)


def segment_polygon(length: float = 1.0) -> ConvexPolygon2D:
    pts = centered_segment(length, 2)
    eps = 1e-9
    hull = np.array([[pts[0,0], -eps], [pts[1,0], -eps], [pts[1,0], eps], [pts[0,0], eps]], dtype=float)
    return ConvexPolygon2D(hull, name=f"segment({length})")


def sampled_disk(radius: float = 1.0, n: int = 64) -> ConvexPolygon2D:
    theta = np.linspace(0.0, 2.0 * math.pi, n, endpoint=False)
    pts = np.stack([radius * np.cos(theta), radius * np.sin(theta)], axis=1)
    return ConvexPolygon2D(pts, name=f"disk({radius})")


def buffer_polygon(poly: ConvexPolygon2D, radius: float, *, n_disk: int = 64) -> ConvexPolygon2D:
    return minkowski_sum_polygons(poly, sampled_disk(radius, n_disk))


def polyline(points: list[tuple[float, float]]) -> Polyline2D:
    return Polyline2D(np.asarray(points, dtype=float), name="polyline")


def polyline_tube(worm: Polyline2D, radius: float, *, n_disk: int = 48) -> ConvexPolygon2D:
    disk = sampled_disk(radius, n_disk)
    cloud = []
    for p in worm.points:
        cloud.append(disk.vertices + p)
    return ConvexPolygon2D(convex_hull(np.vstack(cloud)), name=f"tube({worm.name},{radius})")


def minkowski_sum_dispatch(a, b):
    if isinstance(a, ConvexPolygon2D) and isinstance(b, ConvexPolygon2D):
        return minkowski_sum_polygons(a, b)
    if isinstance(a, SupportFunction2D) and isinstance(b, SupportFunction2D):
        return support_sum_2d(a, b)
    if isinstance(a, SupportFunction3D) and isinstance(b, SupportFunction3D):
        return support_sum_3d(a, b)
    raise TypeError(f"unsupported Minkowski-sum pair: {type(a)} and {type(b)}")
