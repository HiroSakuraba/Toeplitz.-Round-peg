from __future__ import annotations

from dataclasses import dataclass, field
import math

from .support import ConvexBody2D
from .interval_cache import IntervalSupportCache2D


@dataclass(slots=True)
class WidthCertificate2D:
    statement: str
    required_width: float
    certified_lower_width: float
    passed: bool
    details: dict = field(default_factory=dict)


def certified_min_width_2d(
    body: ConvexBody2D,
    *,
    n: int = 256,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
) -> tuple[float, dict]:
    if cache is None:
        cache = IntervalSupportCache2D()

    delta = math.pi / max(1, int(n))
    min_width_lb = float("inf")
    worst_cell = None
    methods: set[str] = set()

    for j in range(int(n)):
        a_lo = j * delta
        a_hi = (j + 1) * delta
        (h1_lo, _h1_hi), m1 = cache.support_bounds_with_fallback(body, a_lo, a_hi, dps=int(dps))
        (h2_lo, _h2_hi), m2 = cache.support_bounds_with_fallback(body, a_lo + math.pi, a_hi + math.pi, dps=int(dps))
        cell_lb = float(h1_lo + h2_lo)
        if cell_lb < min_width_lb:
            min_width_lb = cell_lb
            worst_cell = (float(a_lo), float(a_hi))
        methods.add(m1)
        methods.add(m2)

    return float(min_width_lb), {
        "sample_count": int(n),
        "cell_width": float(delta),
        "worst_cell": worst_cell,
        "methods": sorted(methods),
    }


def certified_width_prescreen_2d(
    body: ConvexBody2D,
    *,
    width_lb: float = 1.0,
    n: int = 256,
    tol: float = 1e-9,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
) -> WidthCertificate2D:
    min_width, details = certified_min_width_2d(body, n=n, dps=dps, cache=cache)
    return WidthCertificate2D(
        statement=f"width prescreen for {body.name}",
        required_width=float(width_lb),
        certified_lower_width=float(min_width),
        passed=bool(min_width >= width_lb - tol),
        details={**details, "tolerance": float(tol)},
    )
