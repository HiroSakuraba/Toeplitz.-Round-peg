"""Rigid-motion witness placement and active-contact extraction.

This module now supports three complementary fitting modes:

1. point-sample fitting against polygon halfspace slack,
2. support-function-native fitting for convex body containment,
3. native interval branch-and-bound in rigid-motion boxes ``(theta, t_x, t_y)``.

The native box refinement is the first proof-facing refinement stage that works
in *rigid-motion space itself* rather than deriving a translation box from a
single center pose. A feasible rigid-motion box certifies that **every** pose in
that box is feasible.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Sequence
import heapq
import math
import numpy as np

try:
    from scipy.optimize import linprog
except Exception:  # pragma: no cover - optional in some environments
    linprog = None

from .geometry_types import ConvexPolygon2D, Polyline2D, Array
from .halfspace import polygon_halfspace_slack
from .support import ConvexBody2D
from .interval_cache import IntervalSupportCache2D
from .support_lp import (
    SupportLPResult2D,
    RobustIntervalLPSolver2D,
    solve_support_lp_2d,
    robust_interval_rhs_2d,
)


@dataclass(slots=True)
class TranslationIntervalBox2D:
    tx_lo: float
    tx_hi: float
    ty_lo: float
    ty_hi: float

    @property
    def center(self) -> tuple[float, float]:
        return (0.5 * (self.tx_lo + self.tx_hi), 0.5 * (self.ty_lo + self.ty_hi))

    @property
    def half_widths(self) -> tuple[float, float]:
        return (0.5 * (self.tx_hi - self.tx_lo), 0.5 * (self.ty_hi - self.ty_lo))

    @property
    def l2_radius(self) -> float:
        hx, hy = self.half_widths
        return float(math.hypot(hx, hy))


@dataclass(slots=True)
class RigidMotionBox2D:
    rotation_lo: float
    rotation_hi: float
    translation_box: TranslationIntervalBox2D
    certified_feasible: bool
    certified_infeasible: bool
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class RotationInterval2D:
    theta_lo: float
    theta_hi: float
    center: float
    half_width: float
    center_fit: "SupportRigidPlacement2D"
    sampled_center_upper_margin: float
    interval_upper_margin: float
    certified_feasible: bool
    certified_infeasible: bool
    feasible_upper_violation: float | None = None
    certified_translation_box: TranslationIntervalBox2D | None = None
    notes: dict = field(default_factory=dict)


@dataclass(slots=True)
class SupportRotationRefinement2D:
    best_pose: "SupportRigidPlacement2D"
    certified_feasible_intervals: tuple[RotationInterval2D, ...] = ()
    certified_feasible_motion_boxes: tuple[RigidMotionBox2D, ...] = ()
    certified_infeasible_intervals: tuple[RotationInterval2D, ...] = ()
    unresolved_intervals: tuple[RotationInterval2D, ...] = ()
    explored_intervals: tuple[RotationInterval2D, ...] = ()

    @property
    def has_certified_feasible_interval(self) -> bool:
        return any(iv.certified_feasible for iv in self.certified_feasible_intervals)

    @property
    def all_intervals_classified(self) -> bool:
        return len(self.unresolved_intervals) == 0


@dataclass(slots=True)
class SupportRigidMotionRefinement2D:
    best_pose: "SupportRigidPlacement2D"
    certified_feasible_boxes: tuple[RigidMotionBox2D, ...] = ()
    certified_infeasible_boxes: tuple[RigidMotionBox2D, ...] = ()
    unresolved_boxes: tuple[RigidMotionBox2D, ...] = ()
    explored_boxes: tuple[RigidMotionBox2D, ...] = ()

    @property
    def has_certified_feasible_box(self) -> bool:
        return any(box.certified_feasible for box in self.certified_feasible_boxes)

    @property
    def all_boxes_classified(self) -> bool:
        return len(self.unresolved_boxes) == 0


@dataclass(slots=True)
class RigidPlacement2D:
    rotation: float
    translation: tuple[float, float]
    margin: float
    active_indices: tuple[int, ...] = ()
    details: dict | None = None


@dataclass(slots=True)
class SupportRigidPlacement2D:
    rotation: float
    translation: tuple[float, float]
    sampled_margin: float
    sampled_max_violation: float
    certified_upper_violation: float | None = None
    certified_translation_box: TranslationIntervalBox2D | None = None
    active_indices: tuple[int, ...] = ()
    details: dict | None = None

    @property
    def certified_contains(self) -> bool:
        return self.certified_upper_violation is not None and self.certified_upper_violation <= 0.0


@dataclass(slots=True)
class RigidSeedSelection2D:
    translation_bounds: tuple[tuple[float, float], tuple[float, float]]
    translation_bounds_source: str
    rotation_seed_available: bool
    rotation_seed_kind: str
    rotation_seed_center: tuple[float, float] | None
    rotation_seed_radius_x: float | None
    rotation_seed_radius_y: float | None
    rotation_seed_margin: float | None
    rotation_seed_box_count: int

    def metadata_payload(self) -> dict:
        center = None
        if self.rotation_seed_center is not None:
            center = [float(self.rotation_seed_center[0]), float(self.rotation_seed_center[1])]
        return {
            "translation_bounds_source": str(self.translation_bounds_source),
            "rotation_seed_available": bool(self.rotation_seed_available),
            "rotation_seed_kind": str(self.rotation_seed_kind),
            "rotation_seed_center": center,
            "rotation_seed_radius_x": None if self.rotation_seed_radius_x is None else float(self.rotation_seed_radius_x),
            "rotation_seed_radius_y": None if self.rotation_seed_radius_y is None else float(self.rotation_seed_radius_y),
            "rotation_seed_margin": None if self.rotation_seed_margin is None else float(self.rotation_seed_margin),
            "rotation_seed_box_count": int(self.rotation_seed_box_count),
        }


def rotate(points: Array, theta: float) -> Array:
    c, s = math.cos(theta), math.sin(theta)
    R = np.array([[c, -s], [s, c]], dtype=float)
    return points @ R.T



def fit_witness_sample(candidate_slack: Callable[[Array], Array], witness_points: Array, angle_grid: Sequence[float], translation_grid: Sequence[tuple[float, float]]) -> RigidPlacement2D:
    best = None
    for th in angle_grid:
        pts = rotate(witness_points, th)
        for tx, ty in translation_grid:
            shifted = pts + np.array([tx, ty], dtype=float)
            slacks = np.asarray(candidate_slack(shifted), dtype=float)
            margin = float(slacks.min())
            active = tuple(np.where(np.isclose(slacks, margin, atol=1e-9))[0].tolist())
            record = RigidPlacement2D(rotation=float(th), translation=(float(tx), float(ty)), margin=margin, active_indices=active, details={"sample_count": len(witness_points)})
            if best is None or record.margin > best.margin:
                best = record
    if best is None:
        raise ValueError("empty search grids")
    return best


def fit_polygon_in_polygon(container: ConvexPolygon2D, witness: ConvexPolygon2D, *, angle_grid: Sequence[float], translation_grid: Sequence[tuple[float, float]]) -> RigidPlacement2D:
    return fit_witness_sample(lambda pts: polygon_halfspace_slack(container, pts), witness.vertices, angle_grid, translation_grid)


def fit_polyline_in_polygon(container: ConvexPolygon2D, worm: Polyline2D, *, angle_grid: Sequence[float], translation_grid: Sequence[tuple[float, float]]) -> RigidPlacement2D:
    return fit_witness_sample(lambda pts: polygon_halfspace_slack(container, pts), worm.points, angle_grid, translation_grid)


def best_contact_pose(container: ConvexPolygon2D, witness_points: Array, *, angle_steps: int = 36, tx_range: tuple[float, float] = (-1.0, 1.0), ty_range: tuple[float, float] = (-1.0, 1.0), t_steps: int = 21) -> RigidPlacement2D:
    angle_grid = np.linspace(0.0, 2.0 * math.pi, angle_steps, endpoint=False)
    txs = np.linspace(tx_range[0], tx_range[1], t_steps)
    tys = np.linspace(ty_range[0], ty_range[1], t_steps)
    tgrid = [(float(tx), float(ty)) for tx in txs for ty in tys]
    return fit_witness_sample(lambda pts: polygon_halfspace_slack(container, pts), witness_points, angle_grid, tgrid)


def _unit(theta: float) -> np.ndarray:
    return np.array([math.cos(theta), math.sin(theta)], dtype=float)


def _support_delta(container: ConvexBody2D, witness_rot: ConvexBody2D, angles: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    dirs = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    delta = np.array([container.support_value(u) - witness_rot.support_value(u) for u in dirs], dtype=float)
    return dirs, delta


def _wrap_angle(theta: float) -> float:
    two_pi = 2.0 * math.pi
    return float(theta % two_pi)


def _rotation_support_lipschitz_2d(body: ConvexBody2D, n: int = 720) -> float:
    prof = body.sample_support(n=n)
    if len(prof.values) == 0:
        return 0.0
    if float(np.max(prof.values) - np.min(prof.values)) <= 1e-10:
        return 0.0
    from .certify import circumradius_upper_bound_2d
    return float(circumradius_upper_bound_2d(body, n=max(720, n)))


def _make_interval(center: float, half_width: float) -> tuple[float, float]:
    return (_wrap_angle(center - half_width), _wrap_angle(center + half_width))


def _translation_box_from_margin(translation: np.ndarray, certified_upper_violation: float, tol: float = 0.0) -> TranslationIntervalBox2D | None:
    robust_margin = max(0.0, -(float(certified_upper_violation) + float(tol)))
    if robust_margin <= 0.0:
        return None
    half = robust_margin / math.sqrt(2.0)
    tx, ty = float(translation[0]), float(translation[1])
    return TranslationIntervalBox2D(tx_lo=tx - half, tx_hi=tx + half, ty_lo=ty - half, ty_hi=ty + half)


def _evaluate_rotation_interval(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    center: float,
    half_width: float,
    angle_steps: int,
    cert_n: int,
    tol: float = 0.0,
    dps: int = 60,
    lp_mode: str = "sampled",
    lp_solver: str = "auto",
    lp_warm_start: bool = True,
    cache: IntervalSupportCache2D | None = None,
    robust_lp_solver: RobustIntervalLPSolver2D | None = None,
) -> RotationInterval2D:
    if cache is None:
        cache = IntervalSupportCache2D()
    sample_angles = np.linspace(0.0, 2.0 * math.pi, int(angle_steps), endpoint=False)
    wrot = witness.rotate(float(center), name=f"rot({witness.name})")
    dirs, delta = _support_delta(container, wrot, sample_angles)
    center_lp = solve_support_lp_2d(dirs, delta, prefer="highs")
    t_center = np.array(center_lp.translation, dtype=float)
    m_opt = float(center_lp.margin)
    active = center_lp.active_indices
    lp_method_center = center_lp.method

    translated = wrot.translate(t_center, name=f"fit({witness.name})")
    sampled_gaps = container.sample_gap(translated, n=angle_steps).gaps
    sampled_margin = float(np.min(sampled_gaps)) if len(sampled_gaps) else 0.0
    sampled_max_violation = float(np.max(-sampled_gaps)) if len(sampled_gaps) else 0.0
    center_fit = SupportRigidPlacement2D(
        rotation=float(center),
        translation=(float(t_center[0]), float(t_center[1])),
        sampled_margin=sampled_margin,
        sampled_max_violation=sampled_max_violation,
        certified_upper_violation=None,
        active_indices=active,
        details={"sample_count": int(angle_steps), "lp_method": lp_method_center},
    )
    from .certify import certified_support_gap_bound_2d, certified_support_gap_bound_2d_interval
    r_w = _rotation_support_lipschitz_2d(witness, n=max(720, angle_steps))
    cert = certified_support_gap_bound_2d_interval(container, translated, n=cert_n, tol=tol)
    if cert.details.get("method") == "lipschitz-fallback":
        cert = certified_support_gap_bound_2d(container, translated, n=cert_n, translation_norm=0.0, tol=tol)
        cert_method = "lipschitz"
    else:
        cert_method = cert.details.get("method", "interval")
    center_feasible_upper = float(cert.certified_upper_violation + r_w * abs(float(half_width)))
    center_fit.certified_upper_violation = center_feasible_upper
    center_fit.certified_translation_box = _translation_box_from_margin(t_center, center_feasible_upper, tol=tol)
    interval_upper_margin = float(m_opt + r_w * abs(float(half_width)))
    certified_infeasible = interval_upper_margin < -tol

    theta_lo_mono = float(center - half_width)
    theta_hi_mono = float(center + half_width)
    if lp_mode == "robust-interval":
        rhs, rhs_details = robust_interval_rhs_2d(
            container, witness, dirs, theta_lo=theta_lo_mono, theta_hi=theta_hi_mono, dps=dps, cache=cache
        )
        if robust_lp_solver is None:
            robust_lp_solver = RobustIntervalLPSolver2D(dirs, backend=lp_solver)
        robust_lp = robust_lp_solver.solve(rhs, warm_start=lp_warm_start)
        t_cert = np.array(robust_lp.translation, dtype=float)
        lp_method_cert = robust_lp.method
    else:
        rhs_details = {"rhs_method": "center-angle"}
        t_cert = t_center.copy()
        lp_method_cert = lp_method_center

    cert_translation_box = TranslationIntervalBox2D(
        float(t_cert[0]), float(t_cert[0]),
        float(t_cert[1]), float(t_cert[1]),
    )
    feasible_upper, box_cert_method = _rigid_motion_box_feasible_upper_violation(
        container, witness, theta_lo=theta_lo_mono, theta_hi=theta_hi_mono, translation_box=cert_translation_box,
        n=cert_n, dps=dps, cache=cache,
    )
    certified_translation_box = _translation_box_from_margin(t_cert, feasible_upper, tol=tol)
    certified_feasible = certified_translation_box is not None
    theta_lo, theta_hi = _make_interval(center, half_width)
    return RotationInterval2D(
        theta_lo=theta_lo,
        theta_hi=theta_hi,
        center=float(center),
        half_width=float(half_width),
        center_fit=center_fit,
        sampled_center_upper_margin=float(m_opt),
        interval_upper_margin=interval_upper_margin,
        certified_feasible=certified_feasible,
        certified_infeasible=certified_infeasible,
        feasible_upper_violation=float(feasible_upper),
        certified_translation_box=certified_translation_box,
        notes={
            "rotation_lipschitz": float(r_w),
            "cert_n": int(cert_n),
            "angle_steps": int(angle_steps),
            "cert_method": cert_method,
            "box_cert_method": box_cert_method,
            "lp_mode": lp_mode,
            "lp_method_center": lp_method_center,
            "lp_method_cert": lp_method_cert,
            "rhs_method": rhs_details.get("rhs_method"),
            "lp_solver": lp_solver,
        },
    )

def refine_body_in_body_support_rotation_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    angle_steps: int = 180,
    cert_n: int = 720,
    initial_intervals: int = 16,
    max_depth: int = 6,
    tol: float = 0.0,
    dps: int = 60,
    lp_mode: str = "sampled",
    lp_solver: str = "auto",
    lp_warm_start: bool = True,
) -> SupportRotationRefinement2D:
    cache = IntervalSupportCache2D()
    sample_angles = np.linspace(0.0, 2.0 * math.pi, int(angle_steps), endpoint=False)
    dirs = np.stack([np.cos(sample_angles), np.sin(sample_angles)], axis=1)
    robust_lp_solver = None
    if lp_mode == "robust-interval":
        robust_lp_solver = RobustIntervalLPSolver2D(dirs, backend=lp_solver)
    initial_centers = np.linspace(0.0, 2.0 * math.pi, int(initial_intervals), endpoint=False)
    initial_half = math.pi / max(1, int(initial_intervals))
    pending = [(float(c), float(initial_half), 0) for c in initial_centers]
    explored: list[RotationInterval2D] = []
    feasible: list[RotationInterval2D] = []
    feasible_motion_boxes: list[RigidMotionBox2D] = []
    infeasible: list[RotationInterval2D] = []
    unresolved: list[RotationInterval2D] = []
    best_pose: SupportRigidPlacement2D | None = None
    while pending:
        center, half_width, depth = pending.pop()
        iv = _evaluate_rotation_interval(
            container, witness, center=center, half_width=half_width, angle_steps=angle_steps, cert_n=cert_n, tol=tol,
            dps=dps, lp_mode=lp_mode, lp_solver=lp_solver, lp_warm_start=lp_warm_start, cache=cache, robust_lp_solver=robust_lp_solver,
        )
        explored.append(iv)
        pose = iv.center_fit
        if best_pose is None or pose.sampled_margin > best_pose.sampled_margin:
            best_pose = pose
        if iv.certified_feasible:
            feasible.append(iv)
            if iv.certified_translation_box is not None:
                feasible_motion_boxes.append(RigidMotionBox2D(
                    rotation_lo=iv.theta_lo, rotation_hi=iv.theta_hi, translation_box=iv.certified_translation_box,
                    certified_feasible=True, certified_infeasible=False,
                    details={"center": iv.center, "half_width": iv.half_width, "feasible_upper_violation": iv.feasible_upper_violation}
                ))
            continue
        if iv.certified_infeasible:
            infeasible.append(iv)
            continue
        if depth >= max_depth:
            unresolved.append(iv)
            continue
        child_half = half_width / 2.0
        pending.append((_wrap_angle(center - child_half), child_half, depth + 1))
        pending.append((_wrap_angle(center + child_half), child_half, depth + 1))
    if best_pose is None:
        raise ValueError("empty rotation refinement")
    return SupportRotationRefinement2D(
        best_pose=best_pose,
        certified_feasible_intervals=tuple(feasible),
        certified_feasible_motion_boxes=tuple(feasible_motion_boxes),
        certified_infeasible_intervals=tuple(infeasible),
        unresolved_intervals=tuple(unresolved),
        explored_intervals=tuple(explored),
    )


# --- Native joint interval branch-and-bound in (theta, tx, ty) ---

def _interval_product_sup(a_lo: float, a_hi: float, b_lo: float, b_hi: float) -> float:
    vals = [a_lo * b_lo, a_lo * b_hi, a_hi * b_lo, a_hi * b_hi]
    return float(max(vals))


def _support_interval_with_fallback(
    body: ConvexBody2D,
    theta_lo: float,
    theta_hi: float,
    *,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
) -> tuple[tuple[float, float], str]:
    """Return support bounds on an interval, with caching.

    This wrapper exists to keep the rest of the proof layer decoupled from the
    cache implementation.
    """
    if cache is None:
        cache = IntervalSupportCache2D()
    return cache.support_bounds_with_fallback(body, theta_lo, theta_hi, dps=int(dps))

def _translation_term_upper(
    box: TranslationIntervalBox2D,
    alpha_lo: float,
    alpha_hi: float,
    *,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
) -> float:
    """Upper bound for sup_{t in box} <t, u(alpha)> over an angular cell."""
    if cache is None:
        cache = IntervalSupportCache2D()
    (c_lo, c_hi), (s_lo, s_hi) = cache.cos_sin_bounds(alpha_lo, alpha_hi, dps=int(dps))
    sup_x = _interval_product_sup(box.tx_lo, box.tx_hi, c_lo, c_hi)
    sup_y = _interval_product_sup(box.ty_lo, box.ty_hi, s_lo, s_hi)
    return float(sup_x + sup_y)

def _rigid_motion_box_feasible_upper_violation(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta_lo: float,
    theta_hi: float,
    translation_box: TranslationIntervalBox2D,
    n: int,
    dps: int,
    cache: IntervalSupportCache2D | None = None,
) -> tuple[float, str]:
    """Upper bound on worst support violation over a rigid-motion box."""
    if cache is None:
        cache = IntervalSupportCache2D()
    delta = 2.0 * math.pi / max(1, int(n))
    upper = -float("inf")
    methods: set[str] = set()
    for j in range(int(n)):
        alpha_lo = j * delta
        alpha_hi = (j + 1) * delta
        (c_lo, _c_hi), c_method = _support_interval_with_fallback(container, alpha_lo, alpha_hi, dps=dps, cache=cache)
        beta_lo = alpha_lo - float(theta_hi)
        beta_hi = alpha_hi - float(theta_lo)
        (_w_lo, w_hi), w_method = _support_interval_with_fallback(witness, beta_lo, beta_hi, dps=dps, cache=cache)
        trans_hi = _translation_term_upper(translation_box, alpha_lo, alpha_hi, dps=dps, cache=cache)
        upper = max(upper, float(w_hi + trans_hi - c_lo))
        methods.add(c_method)
        methods.add(w_method)
    method = "interval" if methods == {"interval"} else "mixed"
    return float(upper if upper != -float("inf") else 0.0), method

def _box_midpoint_pose(container: ConvexBody2D, witness: ConvexBody2D, *, theta_center: float, translation_box: TranslationIntervalBox2D, angle_steps: int) -> SupportRigidPlacement2D:
    tx_c, ty_c = translation_box.center
    pose_body = witness.rotate(theta_center, name=f"rot({witness.name})").translate(np.array([tx_c, ty_c], dtype=float), name=f"mid({witness.name})")
    sampled_gaps = container.sample_gap(pose_body, n=angle_steps).gaps
    sampled_margin = float(np.min(sampled_gaps)) if len(sampled_gaps) else 0.0
    sampled_max_violation = float(np.max(-sampled_gaps)) if len(sampled_gaps) else 0.0
    return SupportRigidPlacement2D(
        rotation=float(theta_center),
        translation=(float(tx_c), float(ty_c)),
        sampled_margin=sampled_margin,
        sampled_max_violation=sampled_max_violation,
        certified_upper_violation=None,
        certified_translation_box=None,
        active_indices=(),
        details={"joint_interval_refinement": True, "sample_count": int(angle_steps)},
    )


def _auto_translation_bounds(container: ConvexBody2D, witness: ConvexBody2D) -> tuple[tuple[float, float], tuple[float, float]]:
    from .certify import circumradius_upper_bound_2d
    rc = float(circumradius_upper_bound_2d(container, n=720))
    rw = float(circumradius_upper_bound_2d(witness, n=720))
    bound = max(1.0, rc + rw)
    return ((-bound, bound), (-bound, bound))


def _intersect_translation_bounds(
    a: tuple[tuple[float, float], tuple[float, float]],
    b: tuple[tuple[float, float], tuple[float, float]],
) -> tuple[tuple[float, float], tuple[float, float]] | None:
    tx_lo = max(float(a[0][0]), float(b[0][0]))
    tx_hi = min(float(a[0][1]), float(b[0][1]))
    ty_lo = max(float(a[1][0]), float(b[1][0]))
    ty_hi = min(float(a[1][1]), float(b[1][1]))
    if tx_lo >= tx_hi or ty_lo >= ty_hi:
        return None
    return ((tx_lo, tx_hi), (ty_lo, ty_hi))


def _translation_bounds_from_seed_box(
    seed_box: TranslationIntervalBox2D,
    *,
    pad: float,
    fallback_bounds: tuple[tuple[float, float], tuple[float, float]] | None = None,
) -> tuple[tuple[float, float], tuple[float, float]]:
    expanded = (
        (float(seed_box.tx_lo) - float(pad), float(seed_box.tx_hi) + float(pad)),
        (float(seed_box.ty_lo) - float(pad), float(seed_box.ty_hi) + float(pad)),
    )
    if fallback_bounds is None:
        return expanded
    clipped = _intersect_translation_bounds(expanded, fallback_bounds)
    return expanded if clipped is None else clipped


def _translation_bounds_from_best_pose_neighborhood(
    pose: SupportRigidPlacement2D,
    *,
    pad: float,
    fallback_bounds: tuple[tuple[float, float], tuple[float, float]],
    min_half_extent: float = 0.05,
    margin_scale: float = 1.0,
) -> tuple[tuple[float, float], tuple[float, float]]:
    tx, ty = float(pose.translation[0]), float(pose.translation[1])
    base = max(float(min_half_extent), float(pad) + max(0.0, float(pose.sampled_margin)) * float(margin_scale))
    half_tx = min(base, 0.5 * (float(fallback_bounds[0][1]) - float(fallback_bounds[0][0])))
    half_ty = min(base, 0.5 * (float(fallback_bounds[1][1]) - float(fallback_bounds[1][0])))
    return _translation_bounds_from_seed_box(
        TranslationIntervalBox2D(tx - half_tx, tx + half_tx, ty - half_ty, ty + half_ty),
        pad=0.0,
        fallback_bounds=fallback_bounds,
    )


def _seed_neighborhood_box(
    seed: RigidSeedSelection2D,
    *,
    fallback_half_extent: float,
    pad: float,
) -> TranslationIntervalBox2D | None:
    if seed.rotation_seed_center is None:
        return None
    cx, cy = float(seed.rotation_seed_center[0]), float(seed.rotation_seed_center[1])
    rx = float(seed.rotation_seed_radius_x) if seed.rotation_seed_radius_x is not None else float(fallback_half_extent)
    ry = float(seed.rotation_seed_radius_y) if seed.rotation_seed_radius_y is not None else float(fallback_half_extent)
    rx = max(float(fallback_half_extent), rx) + float(pad)
    ry = max(float(fallback_half_extent), ry) + float(pad)
    return TranslationIntervalBox2D(cx - rx, cx + rx, cy - ry, cy + ry)


def _translation_box_intersects(a: TranslationIntervalBox2D, b: TranslationIntervalBox2D) -> bool:
    return not (
        float(a.tx_hi) <= float(b.tx_lo)
        or float(b.tx_hi) <= float(a.tx_lo)
        or float(a.ty_hi) <= float(b.ty_lo)
        or float(b.ty_hi) <= float(a.ty_lo)
    )


def _translation_box_seed_distance(box: TranslationIntervalBox2D, seed_box: TranslationIntervalBox2D | None) -> float:
    if seed_box is None:
        return 0.0
    dx = max(0.0, float(seed_box.tx_lo) - float(box.tx_hi), float(box.tx_lo) - float(seed_box.tx_hi))
    dy = max(0.0, float(seed_box.ty_lo) - float(box.ty_hi), float(box.ty_lo) - float(seed_box.ty_hi))
    return float(math.hypot(dx, dy))


def _box_localized_deepening_metadata(
    box: TranslationIntervalBox2D,
    *,
    seed_box: TranslationIntervalBox2D | None,
    far_box_depth_penalty: int,
    max_depth: int,
) -> tuple[bool, float, int]:
    distance = _translation_box_seed_distance(box, seed_box)
    near_seed = bool(seed_box is not None and _translation_box_intersects(box, seed_box))
    effective_max_depth = int(max_depth if near_seed or seed_box is None else max(0, int(max_depth) - int(far_box_depth_penalty)))
    return near_seed, float(distance), effective_max_depth


def derive_rigid_seed_from_rotation_fit(
    rotation_seed_pose: SupportRigidPlacement2D,
    *,
    auto_translation_bounds: tuple[tuple[float, float], tuple[float, float]],
    use_rotation_seed_translation_bounds: bool = True,
    rotation_seed_translation_pad: float = 0.1,
    best_pose_neighborhood_min_half_extent: float = 0.05,
    best_pose_neighborhood_margin_scale: float = 1.0,
) -> RigidSeedSelection2D:
    details = dict(rotation_seed_pose.details or {})
    box_count = int(details.get("feasible_motion_box_count", 0) or 0)
    auto_bounds = (
        (float(auto_translation_bounds[0][0]), float(auto_translation_bounds[0][1])),
        (float(auto_translation_bounds[1][0]), float(auto_translation_bounds[1][1])),
    )
    if not use_rotation_seed_translation_bounds:
        return RigidSeedSelection2D(
            translation_bounds=auto_bounds,
            translation_bounds_source="auto",
            rotation_seed_available=False,
            rotation_seed_kind="global-auto-bounds",
            rotation_seed_center=None,
            rotation_seed_radius_x=None,
            rotation_seed_radius_y=None,
            rotation_seed_margin=float(rotation_seed_pose.sampled_margin),
            rotation_seed_box_count=box_count,
        )
    seed_box = rotation_seed_pose.certified_translation_box
    if seed_box is not None:
        bounds = _translation_bounds_from_seed_box(seed_box, pad=float(rotation_seed_translation_pad), fallback_bounds=auto_bounds)
        cx = 0.5 * (float(bounds[0][0]) + float(bounds[0][1]))
        cy = 0.5 * (float(bounds[1][0]) + float(bounds[1][1]))
        return RigidSeedSelection2D(
            translation_bounds=bounds,
            translation_bounds_source="rotation-fit-seed-box",
            rotation_seed_available=True,
            rotation_seed_kind="certified-translation-box",
            rotation_seed_center=(cx, cy),
            rotation_seed_radius_x=0.5 * (float(bounds[0][1]) - float(bounds[0][0])),
            rotation_seed_radius_y=0.5 * (float(bounds[1][1]) - float(bounds[1][0])),
            rotation_seed_margin=float(rotation_seed_pose.sampled_margin),
            rotation_seed_box_count=box_count,
        )
    if float(rotation_seed_pose.sampled_margin) > 0.0:
        bounds = _translation_bounds_from_best_pose_neighborhood(
            rotation_seed_pose,
            pad=float(rotation_seed_translation_pad),
            fallback_bounds=auto_bounds,
            min_half_extent=float(best_pose_neighborhood_min_half_extent),
            margin_scale=float(best_pose_neighborhood_margin_scale),
        )
        cx = 0.5 * (float(bounds[0][0]) + float(bounds[0][1]))
        cy = 0.5 * (float(bounds[1][0]) + float(bounds[1][1]))
        return RigidSeedSelection2D(
            translation_bounds=bounds,
            translation_bounds_source="rotation-fit-best-pose-neighborhood",
            rotation_seed_available=True,
            rotation_seed_kind="best-pose-neighborhood",
            rotation_seed_center=(cx, cy),
            rotation_seed_radius_x=0.5 * (float(bounds[0][1]) - float(bounds[0][0])),
            rotation_seed_radius_y=0.5 * (float(bounds[1][1]) - float(bounds[1][0])),
            rotation_seed_margin=float(rotation_seed_pose.sampled_margin),
            rotation_seed_box_count=box_count,
        )
    return RigidSeedSelection2D(
        translation_bounds=auto_bounds,
        translation_bounds_source="auto",
        rotation_seed_available=False,
        rotation_seed_kind="global-auto-bounds",
        rotation_seed_center=None,
        rotation_seed_radius_x=None,
        rotation_seed_radius_y=None,
        rotation_seed_margin=float(rotation_seed_pose.sampled_margin),
        rotation_seed_box_count=box_count,
    )


def _split_translation_box(box: TranslationIntervalBox2D, *, axis: str) -> tuple[TranslationIntervalBox2D, TranslationIntervalBox2D]:
    if axis == "tx":
        mid = 0.5 * (box.tx_lo + box.tx_hi)
        return (
            TranslationIntervalBox2D(box.tx_lo, mid, box.ty_lo, box.ty_hi),
            TranslationIntervalBox2D(mid, box.tx_hi, box.ty_lo, box.ty_hi),
        )
    if axis == "ty":
        mid = 0.5 * (box.ty_lo + box.ty_hi)
        return (
            TranslationIntervalBox2D(box.tx_lo, box.tx_hi, box.ty_lo, mid),
            TranslationIntervalBox2D(box.tx_lo, box.tx_hi, mid, box.ty_hi),
        )
    raise ValueError(f"unknown split axis: {axis}")


def _make_rigid_motion_box(theta_lo: float, theta_hi: float, translation_box: TranslationIntervalBox2D, *, certified_feasible: bool, certified_infeasible: bool, details: dict | None = None) -> RigidMotionBox2D:
    return RigidMotionBox2D(
        rotation_lo=_wrap_angle(theta_lo),
        rotation_hi=_wrap_angle(theta_hi),
        translation_box=translation_box,
        certified_feasible=bool(certified_feasible),
        certified_infeasible=bool(certified_infeasible),
        details=dict(details or {}),
    )


def _halfspace_constraints_for_translation_box(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta_lo: float,
    theta_hi: float,
    n: int,
    dps: int,
    cache: IntervalSupportCache2D | None = None,
) -> list[tuple[float, float, float]]:
    """Conservative translation halfspaces for a rigid-motion box.

    Each angular cell yields a halfspace
        <u_mid, t> <= h_C^- - h_W^+
    that is necessary for every feasible translation in the box.
    These are intentionally conservative; they are used only for early
    infeasibility detection.
    """
    if cache is None:
        cache = IntervalSupportCache2D()
    delta = 2.0 * math.pi / max(1, int(n))
    constraints: list[tuple[float, float, float]] = []
    for j in range(int(n)):
        alpha_lo = j * delta
        alpha_hi = (j + 1) * delta
        alpha_mid = 0.5 * (alpha_lo + alpha_hi)
        (c_lo, _c_hi), _ = _support_interval_with_fallback(container, alpha_lo, alpha_hi, dps=dps, cache=cache)
        beta_lo = alpha_lo - float(theta_hi)
        beta_hi = alpha_hi - float(theta_lo)
        (_w_lo, w_hi), _ = _support_interval_with_fallback(witness, beta_lo, beta_hi, dps=dps, cache=cache)
        rhs = float(c_lo - w_hi)
        constraints.append((float(math.cos(alpha_mid)), float(math.sin(alpha_mid)), rhs))
    return constraints


def _translation_box_halfspaces(box: TranslationIntervalBox2D) -> list[tuple[float, float, float]]:
    return [
        (1.0, 0.0, float(box.tx_hi)),
        (-1.0, 0.0, float(-box.tx_lo)),
        (0.0, 1.0, float(box.ty_hi)),
        (0.0, -1.0, float(-box.ty_lo)),
    ]


def _halfspace_system_feasible_2d(constraints: list[tuple[float, float, float]], *, tol: float = 1e-9) -> bool:
    if not constraints:
        return True
    A = np.array([[a, b] for a, b, _rhs in constraints], dtype=float)
    b = np.array([rhs for _a, _b, rhs in constraints], dtype=float)
    if linprog is not None:
        res = linprog(np.zeros(2, dtype=float), A_ub=A, b_ub=b + float(tol), bounds=[(None, None), (None, None)], method='highs')
        return bool(res.success)
    # Fallback: sample candidate vertices from line intersections plus origin.
    pts: list[np.ndarray] = [np.zeros(2, dtype=float)]
    m = len(constraints)
    for i in range(m):
        a1, b1, r1 = constraints[i]
        for j in range(i + 1, m):
            a2, b2, r2 = constraints[j]
            M = np.array([[a1, b1], [a2, b2]], dtype=float)
            det = float(np.linalg.det(M))
            if abs(det) <= 1e-12:
                continue
            pts.append(np.linalg.solve(M, np.array([r1, r2], dtype=float)))
    for p in pts:
        if np.all(A @ p <= b + float(tol)):
            return True
    return False


def _helly_infeasibility_check(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta_lo: float,
    theta_hi: float,
    translation_box: TranslationIntervalBox2D,
    n: int = 32,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
    top_k: int = 6,
    tol: float = 1e-9,
) -> bool:
    """Early infeasibility detection via small halfspace subsystems.

    In the translation plane, each angular cell induces a necessary halfspace
    constraint. If a small subsystem of these halfspaces is already infeasible
    together with the translation box bounds, the whole rigid-motion box is
    infeasible. This is a Helly-style pruning step rather than a full proof
    replacement.
    """
    if cache is None:
        cache = IntervalSupportCache2D()
    directional = _halfspace_constraints_for_translation_box(
        container, witness, theta_lo=theta_lo, theta_hi=theta_hi, n=max(8, int(n)), dps=dps, cache=cache
    )
    directional = sorted(directional, key=lambda c: c[2])
    directional = directional[:min(int(top_k), len(directional))]
    box_constraints = _translation_box_halfspaces(translation_box)
    from itertools import combinations
    # Helly in R^2 says infeasibility is witnessed by at most 3 convex sets.
    all_constraints = directional + box_constraints
    for triple in combinations(range(len(all_constraints)), 3):
        subset = [all_constraints[i] for i in triple]
        if not _halfspace_system_feasible_2d(subset, tol=tol):
            return True
    return False


def _sample_width_hardness_metrics(body: ConvexBody2D, *, n: int = 180) -> dict:
    angles = np.linspace(0.0, math.pi, max(16, int(n)), endpoint=False)
    widths = np.array([float(body.width(float(theta))) for theta in angles], dtype=float)
    if widths.size == 0:
        return {"width_spread": 0.0, "thin_direction_count": 0}
    min_width = float(np.min(widths))
    max_width = float(np.max(widths))
    tol = max(1.0e-9, 0.05 * max(max_width - min_width, 1.0e-9))
    thin_count = int(sum(1 for value in widths if value <= min_width + tol))
    return {"width_spread": float(max_width - min_width), "thin_direction_count": thin_count}


def _sticky_locked_priority_score_for_body(body: ConvexBody2D) -> float:
    name = str(getattr(body, "name", "witness")).strip().lower()
    metrics = _sample_width_hardness_metrics(body)
    score = 0.0
    if 'regular-3-gon' in name or 'triangle' in name:
        score += 3.0
    elif 'regular-4-gon' in name or 'square' in name:
        score += 2.0
    elif 'orbiform' in name or 'pal-seed' in name:
        score += 2.0
    elif 'segment' in name or 'disk-half' in name:
        score += 1.0
    width_spread = float(metrics['width_spread'])
    thin_direction_count = int(metrics['thin_direction_count'])
    if width_spread <= 0.02:
        score += 1.5
    elif width_spread <= 0.08:
        score += 0.75
    if thin_direction_count >= 4:
        score += 0.5
    return float(score)


def _rotation_seed_theta_boxes_from_refinement(rotation_refinement: SupportRotationRefinement2D) -> list[tuple[float, float]]:
    out: list[tuple[float, float]] = []
    for iv in rotation_refinement.certified_feasible_intervals:
        out.append((float(iv.center - iv.half_width), float(iv.center + iv.half_width)))
    return out


def _rotation_local_motion_seed_boxes_from_refinement(rotation_refinement: SupportRotationRefinement2D) -> list[RigidMotionBox2D]:
    out: list[RigidMotionBox2D] = []
    for iv in rotation_refinement.certified_feasible_intervals:
        tx, ty = iv.center_fit.translation
        out.append(_make_rigid_motion_box(
            float(iv.theta_lo),
            float(iv.theta_hi),
            TranslationIntervalBox2D(float(tx), float(tx), float(ty), float(ty)),
            certified_feasible=False,
            certified_infeasible=False,
            details={
                'center': float(iv.center),
                'half_width': float(iv.half_width),
                'seed_kind': 'rotation-center-point',
                'rotation_feasible_upper_violation': None if iv.feasible_upper_violation is None else float(iv.feasible_upper_violation),
            },
        ))
    return out


def _theta_interval_from_rigid_box(box: RigidMotionBox2D) -> tuple[float, float]:
    details = dict(getattr(box, 'details', {}) or {})
    center = details.get('theta_center')
    width = details.get('theta_width')
    if center is None or width is None:
        center = details.get('center')
        half_width = details.get('half_width')
        if center is not None and half_width is not None:
            width = 2.0 * float(half_width)
        else:
            lo = float(box.rotation_lo)
            hi = float(box.rotation_hi)
            width = hi - lo
            center = 0.5 * (lo + hi)
            if width < 0.0:
                width += 2.0 * math.pi
    return (float(center) - 0.5 * float(width), float(center) + 0.5 * float(width))


def _theta_boxes_from_rigid_boxes(boxes: Sequence[RigidMotionBox2D]) -> list[tuple[float, float]]:
    out: list[tuple[float, float]] = []
    for box in boxes:
        out.append(_theta_interval_from_rigid_box(box))
    return out


def _translation_bounds_from_rigid_boxes(
    boxes: Sequence[RigidMotionBox2D],
    *,
    pad: float,
    fallback_bounds: tuple[tuple[float, float], tuple[float, float]],
) -> tuple[tuple[float, float], tuple[float, float]]:
    if not boxes:
        return fallback_bounds
    tx_lo = min(float(box.translation_box.tx_lo) for box in boxes) - float(pad)
    tx_hi = max(float(box.translation_box.tx_hi) for box in boxes) + float(pad)
    ty_lo = min(float(box.translation_box.ty_lo) for box in boxes) - float(pad)
    ty_hi = max(float(box.translation_box.ty_hi) for box in boxes) + float(pad)
    return (
        (max(float(fallback_bounds[0][0]), tx_lo), min(float(fallback_bounds[0][1]), tx_hi)),
        (max(float(fallback_bounds[1][0]), ty_lo), min(float(fallback_bounds[1][1]), ty_hi)),
    )


def _seed_spans_from_rigid_boxes(boxes: Sequence[RigidMotionBox2D]) -> tuple[float, float, float] | None:
    if not boxes:
        return None
    theta_boxes = _theta_boxes_from_rigid_boxes(boxes)
    theta_lo = min(float(lo) for lo, _hi in theta_boxes)
    theta_hi = max(float(hi) for _lo, hi in theta_boxes)
    tx_lo = min(float(box.translation_box.tx_lo) for box in boxes)
    tx_hi = max(float(box.translation_box.tx_hi) for box in boxes)
    ty_lo = min(float(box.translation_box.ty_lo) for box in boxes)
    ty_hi = max(float(box.translation_box.ty_hi) for box in boxes)
    return (float(theta_hi - theta_lo), float(tx_hi - tx_lo), float(ty_hi - ty_lo))


def _region_volume(
    translation_bounds: tuple[tuple[float, float], tuple[float, float]],
    theta_boxes: Sequence[tuple[float, float]] | None,
) -> float:
    tx_width = max(0.0, float(translation_bounds[0][1]) - float(translation_bounds[0][0]))
    ty_width = max(0.0, float(translation_bounds[1][1]) - float(translation_bounds[1][0]))
    if theta_boxes:
        theta_width = sum(max(0.0, float(hi) - float(lo)) for lo, hi in theta_boxes)
    else:
        theta_width = 2.0 * math.pi
    return float(theta_width * tx_width * ty_width)


def _concentrated_incomplete_region(
    boxes: Sequence[RigidMotionBox2D],
    *,
    reference_volume: float,
    volume_ratio_threshold: float = 0.35,
    max_unresolved_boxes: int = 96,
) -> tuple[bool, dict]:
    if not boxes:
        return False, {"reason": "none", "box_count": 0, "volume_ratio": 0.0}
    theta_boxes = _theta_boxes_from_rigid_boxes(boxes)
    theta_lo = min(float(lo) for lo, _ in theta_boxes)
    theta_hi = max(float(hi) for _, hi in theta_boxes)
    tx_lo = min(float(box.translation_box.tx_lo) for box in boxes)
    tx_hi = max(float(box.translation_box.tx_hi) for box in boxes)
    ty_lo = min(float(box.translation_box.ty_lo) for box in boxes)
    ty_hi = max(float(box.translation_box.ty_hi) for box in boxes)
    bbox_volume = max(0.0, theta_hi - theta_lo) * max(0.0, tx_hi - tx_lo) * max(0.0, ty_hi - ty_lo)
    ratio = float(bbox_volume / max(reference_volume, 1.0e-12))
    concentrated = bool(ratio <= float(volume_ratio_threshold) and len(boxes) <= int(max_unresolved_boxes))
    return concentrated, {
        "reason": "bbox-volume-ratio" if concentrated else "dispersed",
        "box_count": int(len(boxes)),
        "volume_ratio": float(ratio),
        "bbox_volume": float(bbox_volume),
    }


def _cascade_stage_payload(
    *,
    stage_index: int,
    stage_name: str,
    stage_params: dict,
    seed_source: str,
    input_seed_box_count: int,
    input_theta_seed_count: int,
    input_motion_seed_count: int,
    refinement: SupportRigidMotionRefinement2D,
    promoted: bool,
    promote_reason: str,
    promote_details: dict | None = None,
    anisotropic_policy: str = "off",
    anisotropic_enabled: bool = False,
) -> dict:
    return {
        "stage_index": int(stage_index),
        "stage_name": str(stage_name),
        "stage_params": {k: v for k, v in dict(stage_params).items() if k != 'name'},
        "seed_source": str(seed_source),
        "input_seed_box_count": int(input_seed_box_count),
        "input_theta_seed_count": int(input_theta_seed_count),
        "input_motion_seed_count": int(input_motion_seed_count),
        "output_counts": {
            "certified_feasible_boxes": int(len(refinement.certified_feasible_boxes)),
            "certified_infeasible_boxes": int(len(refinement.certified_infeasible_boxes)),
            "unresolved_boxes": int(len(refinement.unresolved_boxes)),
            "explored_boxes": int(len(refinement.explored_boxes)),
        },
        "promoted": bool(promoted),
        "promote_reason": str(promote_reason),
        "promote_details": dict(promote_details or {}),
        "anisotropic_policy": str(anisotropic_policy),
        "anisotropic_enabled": bool(anisotropic_enabled),
    }


def _cascade_anisotropic_enabled(policy: str, *, witness_priority_score: float, seed_source: str) -> bool:
    key = str(policy).strip().lower()
    if key in {"on", "true", "always", "explicit"}:
        return True
    if key in {"priority", "witness-conditional", "conditional"}:
        return bool(witness_priority_score >= 2.5 or "concentrated-incomplete" in str(seed_source))
    return False


def cascaded_rigid_refinement(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    stages: Sequence[dict],
    pad: float = 0.05,
    escalation_incomplete_volume_ratio: float = 0.35,
    escalation_max_unresolved_boxes: int = 96,
    sticky_locked_priority: bool = True,
) -> SupportRigidMotionRefinement2D:
    """Multi-stage rigid refinement with seed propagation between stages.

    This changes only search ordering and stage initialization. Every stage uses
    the same rigid-box predicates as :func:`refine_body_in_body_support_rigid_2d`.
    """
    if not stages:
        raise ValueError('cascaded_rigid_refinement requires at least one stage')
    stage_list = [dict(stage) for stage in stages]
    first = stage_list[0]
    rotation_refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=int(first.get('angle_steps', 24)),
        cert_n=max(int(first.get('cert_n', 48)), int(first.get('angle_steps', 24))),
        initial_intervals=max(4, int(first.get('initial_theta_intervals', 4))),
        max_depth=max(1, int(first.get('max_depth', 1))),
        tol=float(first.get('tol', 0.0)),
        dps=int(first.get('dps', 60)),
    )
    auto_translation_bounds = _auto_translation_bounds(container, witness)
    seed_selection = derive_rigid_seed_from_rotation_fit(
        rotation_refinement.best_pose,
        auto_translation_bounds=auto_translation_bounds,
        use_rotation_seed_translation_bounds=bool(first.get('use_rotation_seed_translation_bounds', True)),
        rotation_seed_translation_pad=float(first.get('rotation_seed_translation_pad', 0.1)),
        best_pose_neighborhood_min_half_extent=float(first.get('best_pose_neighborhood_min_half_extent', 0.05)),
        best_pose_neighborhood_margin_scale=float(first.get('best_pose_neighborhood_margin_scale', 1.0)),
    )
    current_translation_bounds = seed_selection.translation_bounds
    current_motion_seed_boxes = tuple(_rotation_local_motion_seed_boxes_from_refinement(rotation_refinement))
    current_theta_boxes = _theta_boxes_from_rigid_boxes(current_motion_seed_boxes) if current_motion_seed_boxes else _rotation_seed_theta_boxes_from_refinement(rotation_refinement)
    current_seed_source = 'rotation-refinement-local-motion-seeds' if current_motion_seed_boxes else 'rotation-refinement'
    current_seed_box_count = int(len(current_motion_seed_boxes))
    current_anisotropic_spans = _seed_spans_from_rigid_boxes(current_motion_seed_boxes)
    stage_records: list[dict] = []
    witness_priority_score = _sticky_locked_priority_score_for_body(witness) if sticky_locked_priority else 0.0
    last_refinement: SupportRigidMotionRefinement2D | None = None
    for idx, stage in enumerate(stage_list):
        stage_name = str(stage.get('name', f'stage-{idx+1}'))
        stage_kwargs = dict(stage)
        stage_kwargs.pop('name', None)
        anisotropic_policy = str(stage_kwargs.pop('anisotropic_policy', 'off'))
        anisotropic_enabled = _cascade_anisotropic_enabled(
            anisotropic_policy,
            witness_priority_score=float(witness_priority_score),
            seed_source=current_seed_source,
        )
        stage_kwargs['translation_bounds'] = current_translation_bounds
        stage_kwargs['use_anisotropic_splitting'] = bool(anisotropic_enabled)
        if current_motion_seed_boxes:
            stage_kwargs['initial_motion_boxes'] = list(current_motion_seed_boxes)
        elif current_theta_boxes:
            stage_kwargs['initial_theta_boxes'] = list(current_theta_boxes)
        if anisotropic_enabled and current_anisotropic_spans is not None:
            stage_kwargs['anisotropic_seed_spans'] = tuple(float(x) for x in current_anisotropic_spans)
        refinement = refine_body_in_body_support_rigid_2d(container, witness, **stage_kwargs)
        last_refinement = refinement
        if idx == len(stage_list) - 1:
            promote = False
            promote_reason = 'final-stage'
            promote_details = {}
        else:
            reference_volume = _region_volume(current_translation_bounds, current_theta_boxes)
            concentrated, conc_details = _concentrated_incomplete_region(
                refinement.unresolved_boxes,
                reference_volume=reference_volume,
                volume_ratio_threshold=float(escalation_incomplete_volume_ratio),
                max_unresolved_boxes=int(escalation_max_unresolved_boxes),
            )
            if refinement.has_certified_feasible_box:
                promote = True
                promote_reason = 'certified-feasible-boxes'
                promote_details = {"feasible_box_count": int(len(refinement.certified_feasible_boxes))}
            elif concentrated:
                promote = True
                promote_reason = 'concentrated-incomplete-region'
                promote_details = conc_details
            elif sticky_locked_priority and witness_priority_score >= 2.5 and len(refinement.unresolved_boxes) > 0:
                promote = True
                promote_reason = 'sticky-locked-priority'
                promote_details = {"priority_score": float(witness_priority_score), **conc_details}
            else:
                promote = False
                promote_reason = 'no-local-escalation-signal'
                promote_details = conc_details
        stage_records.append(_cascade_stage_payload(
            stage_index=idx,
            stage_name=stage_name,
            stage_params=stage,
            seed_source=current_seed_source,
            input_seed_box_count=current_seed_box_count,
            input_theta_seed_count=int(len(current_theta_boxes)),
            input_motion_seed_count=int(len(current_motion_seed_boxes)),
            refinement=refinement,
            promoted=promote,
            promote_reason=promote_reason,
            promote_details=promote_details,
            anisotropic_policy=anisotropic_policy,
            anisotropic_enabled=anisotropic_enabled,
        ))
        if not promote:
            break
        if refinement.has_certified_feasible_box:
            current_motion_seed_boxes = tuple(refinement.certified_feasible_boxes)
            current_translation_bounds = _translation_bounds_from_rigid_boxes(
                current_motion_seed_boxes,
                pad=float(pad),
                fallback_bounds=current_translation_bounds,
            )
            current_theta_boxes = _theta_boxes_from_rigid_boxes(current_motion_seed_boxes)
            current_seed_source = 'previous-stage-feasible-motion-boxes'
            current_seed_box_count = int(len(current_motion_seed_boxes))
            current_anisotropic_spans = _seed_spans_from_rigid_boxes(current_motion_seed_boxes)
        else:
            current_motion_seed_boxes = tuple(refinement.unresolved_boxes)
            current_translation_bounds = _translation_bounds_from_rigid_boxes(
                current_motion_seed_boxes,
                pad=float(pad),
                fallback_bounds=current_translation_bounds,
            )
            current_theta_boxes = _theta_boxes_from_rigid_boxes(current_motion_seed_boxes)
            current_seed_source = 'previous-stage-concentrated-incomplete-motion-boxes'
            current_seed_box_count = int(len(current_motion_seed_boxes))
            current_anisotropic_spans = _seed_spans_from_rigid_boxes(current_motion_seed_boxes)
    if last_refinement is None:
        raise RuntimeError('cascade produced no refinement stage')
    if last_refinement.best_pose.details is None:
        last_refinement.best_pose.details = {}
    last_refinement.best_pose.details.update({
        'cascaded_refinement': True,
        'cascade_stage_count': int(len(stage_records)),
        'cascade_stage_records': stage_records,
        'cascade_seed_rotation_interval_count': int(len(_rotation_seed_theta_boxes_from_refinement(rotation_refinement))),
        'cascade_rotation_feasible_motion_box_count': int(len(rotation_refinement.certified_feasible_motion_boxes)),
        'cascade_seed_motion_box_coupling_preserved': True,
        'cascade_witness_priority_score': float(witness_priority_score),
        'cascade_priority_hypothesis': 'sticky=locked-contact-search-side' if sticky_locked_priority else 'disabled',
    })
    return last_refinement


def refine_body_in_body_support_rigid_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    angle_steps: int = 180,
    cert_n: int = 256,
    translation_bounds: tuple[tuple[float, float], tuple[float, float]] | None = None,
    initial_theta_intervals: int = 4,
    initial_theta_boxes: Sequence[tuple[float, float]] | None = None,
    initial_motion_boxes: Sequence[RigidMotionBox2D] | None = None,
    initial_translation_intervals: int = 2,
    max_depth: int = 6,
    tol: float = 0.0,
    dps: int = 60,
    use_rotation_seed_translation_bounds: bool = True,
    rotation_seed_translation_pad: float = 0.1,
    best_pose_neighborhood_min_half_extent: float = 0.05,
    best_pose_neighborhood_margin_scale: float = 1.0,
    localized_deepening: bool = True,
    localized_deepening_pad: float = 0.05,
    localized_far_box_depth_penalty: int = 1,
    anisotropic_seed_spans: tuple[float, float, float] | None = None,
    use_anisotropic_splitting: bool = True,
) -> SupportRigidMotionRefinement2D:
    """Native interval branch-and-bound in rigid-motion space.

    A rigid-motion box is certified feasible when the support inequalities hold
    uniformly for all ``theta`` and all translations in the box. A box is
    certified infeasible when a sampled violation at the box midpoint dominates
    the full pose drift across that box.
    """
    auto_translation_bounds = _auto_translation_bounds(container, witness)
    rotation_seed_pose = fit_body_in_body_support_2d(container, witness, angle_steps=angle_steps, cert_n=max(cert_n, angle_steps), use_interval_refinement=True)
    seed_details = dict(rotation_seed_pose.details or {})
    seed_certified_upper = rotation_seed_pose.certified_upper_violation
    seed_certified_box = rotation_seed_pose.certified_translation_box
    if translation_bounds is None:
        seed_selection = derive_rigid_seed_from_rotation_fit(
            rotation_seed_pose,
            auto_translation_bounds=auto_translation_bounds,
            use_rotation_seed_translation_bounds=use_rotation_seed_translation_bounds,
            rotation_seed_translation_pad=rotation_seed_translation_pad,
            best_pose_neighborhood_min_half_extent=best_pose_neighborhood_min_half_extent,
            best_pose_neighborhood_margin_scale=best_pose_neighborhood_margin_scale,
        )
        translation_bounds = seed_selection.translation_bounds
        translation_bounds_source = seed_selection.translation_bounds_source
    else:
        translation_bounds_source = "explicit"
        seed_selection = RigidSeedSelection2D(
            translation_bounds=((float(translation_bounds[0][0]), float(translation_bounds[0][1])), (float(translation_bounds[1][0]), float(translation_bounds[1][1]))),
            translation_bounds_source="explicit",
            rotation_seed_available=bool(use_rotation_seed_translation_bounds and seed_certified_box is not None),
            rotation_seed_kind="explicit-bounds",
            rotation_seed_center=(float(rotation_seed_pose.translation[0]), float(rotation_seed_pose.translation[1])),
            rotation_seed_radius_x=None,
            rotation_seed_radius_y=None,
            rotation_seed_margin=float(rotation_seed_pose.sampled_margin),
            rotation_seed_box_count=int(seed_details.get("feasible_motion_box_count", 0) or 0),
        )
    (tx_lo, tx_hi), (ty_lo, ty_hi) = translation_bounds
    tx_edges = np.linspace(float(tx_lo), float(tx_hi), int(initial_translation_intervals) + 1)
    ty_edges = np.linspace(float(ty_lo), float(ty_hi), int(initial_translation_intervals) + 1)
    motion_seed_boxes: list[RigidMotionBox2D] = []
    if initial_motion_boxes:
        motion_seed_boxes = [
            _make_rigid_motion_box(
                float(box.rotation_lo),
                float(box.rotation_hi),
                TranslationIntervalBox2D(
                    float(box.translation_box.tx_lo),
                    float(box.translation_box.tx_hi),
                    float(box.translation_box.ty_lo),
                    float(box.translation_box.ty_hi),
                ),
                certified_feasible=bool(box.certified_feasible),
                certified_infeasible=bool(box.certified_infeasible),
                details=dict(getattr(box, 'details', {}) or {}),
            )
            for box in initial_motion_boxes
        ]
        theta_seed_boxes = _theta_boxes_from_rigid_boxes(motion_seed_boxes)
        theta_seed_source = 'explicit-motion-boxes'
    elif initial_theta_boxes:
        theta_seed_boxes = [(float(lo), float(hi)) for lo, hi in initial_theta_boxes]
        theta_seed_source = 'explicit-seed-boxes'
    else:
        theta_edges = np.linspace(0.0, 2.0 * math.pi, int(initial_theta_intervals) + 1)
        theta_seed_boxes = [(float(theta_edges[i]), float(theta_edges[i + 1])) for i in range(int(initial_theta_intervals))]
        theta_seed_source = 'uniform-grid'
    seed_focus_box = _seed_neighborhood_box(
        seed_selection,
        fallback_half_extent=float(best_pose_neighborhood_min_half_extent),
        pad=float(localized_deepening_pad),
    ) if localized_deepening else None
    pending: list[tuple[float, float, int, int, float, float, TranslationIntervalBox2D]] = []
    pending_counter = 0

    def _push_pending(theta_lo_push: float, theta_hi_push: float, tbox_push: TranslationIntervalBox2D, depth_push: int) -> None:
        nonlocal pending_counter
        near_seed, seed_distance, effective_max_depth = _box_localized_deepening_metadata(
            tbox_push,
            seed_box=seed_focus_box,
            far_box_depth_penalty=int(localized_far_box_depth_penalty),
            max_depth=int(max_depth),
        )
        priority_bucket = 0 if near_seed else 1
        heapq.heappush(
            pending,
            (priority_bucket, seed_distance, int(depth_push), pending_counter, float(theta_lo_push), float(theta_hi_push), tbox_push),
        )
        pending_counter += 1

    if motion_seed_boxes:
        for seed_box in motion_seed_boxes:
            theta_lo_seed, theta_hi_seed = _theta_interval_from_rigid_box(seed_box)
            _push_pending(
                float(theta_lo_seed),
                float(theta_hi_seed),
                TranslationIntervalBox2D(
                    float(seed_box.translation_box.tx_lo),
                    float(seed_box.translation_box.tx_hi),
                    float(seed_box.translation_box.ty_lo),
                    float(seed_box.translation_box.ty_hi),
                ),
                0,
            )
    else:
        for theta_lo_seed, theta_hi_seed in theta_seed_boxes:
            for ix in range(int(initial_translation_intervals)):
                for iy in range(int(initial_translation_intervals)):
                    _push_pending(
                        float(theta_lo_seed),
                        float(theta_hi_seed),
                        TranslationIntervalBox2D(float(tx_edges[ix]), float(tx_edges[ix + 1]), float(ty_edges[iy]), float(ty_edges[iy + 1])),
                        0,
                    )
    feasible: list[RigidMotionBox2D] = []
    infeasible: list[RigidMotionBox2D] = []
    unresolved: list[RigidMotionBox2D] = []
    explored: list[RigidMotionBox2D] = []
    best_pose = SupportRigidPlacement2D(
        rotation=float(rotation_seed_pose.rotation),
        translation=(float(rotation_seed_pose.translation[0]), float(rotation_seed_pose.translation[1])),
        sampled_margin=float(rotation_seed_pose.sampled_margin),
        sampled_max_violation=float(rotation_seed_pose.sampled_max_violation),
        certified_upper_violation=None,
        certified_translation_box=None,
        active_indices=tuple(rotation_seed_pose.active_indices),
        details={
            **seed_details,
            "rigid_refinement_seeded_from_rotation_fit": True,
            "rotation_fit_seed_sampled_margin": float(rotation_seed_pose.sampled_margin),
            "rotation_fit_seed_sampled_max_violation": float(rotation_seed_pose.sampled_max_violation),
            "rotation_fit_seed_certified_upper_violation": None if seed_certified_upper is None else float(seed_certified_upper),
            "rotation_fit_seed_certified_contains": bool(seed_certified_upper is not None and seed_certified_upper <= 0.0),
            "rotation_fit_seed_certified_translation_box": None if seed_certified_box is None else {
                "tx_lo": float(seed_certified_box.tx_lo),
                "tx_hi": float(seed_certified_box.tx_hi),
                "ty_lo": float(seed_certified_box.ty_lo),
                "ty_hi": float(seed_certified_box.ty_hi),
            },
            **seed_selection.metadata_payload(),
            "translation_bounds": {
                "tx_lo": float(tx_lo),
                "tx_hi": float(tx_hi),
                "ty_lo": float(ty_lo),
                "ty_hi": float(ty_hi),
            },
            "auto_translation_bounds": {
                "tx_lo": float(auto_translation_bounds[0][0]),
                "tx_hi": float(auto_translation_bounds[0][1]),
                "ty_lo": float(auto_translation_bounds[1][0]),
                "ty_hi": float(auto_translation_bounds[1][1]),
            },
            "use_rotation_seed_translation_bounds": bool(use_rotation_seed_translation_bounds),
            "rotation_seed_translation_pad": float(rotation_seed_translation_pad),
            "best_pose_neighborhood_min_half_extent": float(best_pose_neighborhood_min_half_extent),
            "best_pose_neighborhood_margin_scale": float(best_pose_neighborhood_margin_scale),
            "theta_seed_source": str(theta_seed_source),
            "theta_seed_box_count": int(len(theta_seed_boxes)),
            "motion_seed_box_count": int(len(motion_seed_boxes)),
            "motion_seed_coupling_preserved": bool(len(motion_seed_boxes) > 0),
            "anisotropic_seed_spans": None if anisotropic_seed_spans is None else [float(x) for x in anisotropic_seed_spans],
            "use_anisotropic_splitting": bool(use_anisotropic_splitting),
            "localized_deepening": bool(localized_deepening),
            "localized_deepening_pad": float(localized_deepening_pad),
            "localized_far_box_depth_penalty": int(localized_far_box_depth_penalty),
            "seed_focus_box": None if seed_focus_box is None else {
                "tx_lo": float(seed_focus_box.tx_lo),
                "tx_hi": float(seed_focus_box.tx_hi),
                "ty_lo": float(seed_focus_box.ty_lo),
                "ty_hi": float(seed_focus_box.ty_hi),
            },
        },
    )
    best_certified_pose: SupportRigidPlacement2D | None = None
    r_w = _rotation_support_lipschitz_2d(witness, n=max(720, angle_steps))
    cache = IntervalSupportCache2D()
    while pending:
        _priority_bucket, _seed_distance_q, depth, _counter_q, theta_lo_box, theta_hi_box, tbox = heapq.heappop(pending)
        near_seed, seed_distance, effective_max_depth = _box_localized_deepening_metadata(
            tbox,
            seed_box=seed_focus_box,
            far_box_depth_penalty=int(localized_far_box_depth_penalty),
            max_depth=int(max_depth),
        )
        theta_center = 0.5 * (theta_lo_box + theta_hi_box)
        feasible_upper, cert_method = _rigid_motion_box_feasible_upper_violation(
            container,
            witness,
            theta_lo=theta_lo_box,
            theta_hi=theta_hi_box,
            translation_box=tbox,
            n=cert_n,
            dps=dps,
        )
        center_pose = _box_midpoint_pose(container, witness, theta_center=theta_center, translation_box=tbox, angle_steps=angle_steps)
        center_pose.certified_upper_violation = feasible_upper
        drift = float(r_w * 0.5 * abs(theta_hi_box - theta_lo_box) + tbox.l2_radius)
        cert_feasible = feasible_upper <= tol
        cert_infeasible = center_pose.sampled_max_violation > drift + tol
        helly_infeasible = False
        if not cert_feasible and not cert_infeasible:
            helly_infeasible = _helly_infeasibility_check(
                container, witness, theta_lo=theta_lo_box, theta_hi=theta_hi_box, translation_box=tbox,
                n=max(8, cert_n // 4), dps=dps, cache=cache, tol=tol,
            )
            if helly_infeasible:
                cert_infeasible = True
        details = {
            "theta_center": float(theta_center),
            "theta_width": float(theta_hi_box - theta_lo_box),
            "tx_center": float(center_pose.translation[0]),
            "ty_center": float(center_pose.translation[1]),
            "certified_upper_violation": float(feasible_upper),
            "center_sampled_margin": float(center_pose.sampled_margin),
            "center_sampled_max_violation": float(center_pose.sampled_max_violation),
            "pose_drift_bound": float(drift),
            "cert_method": cert_method,
            "helly_pruned": bool(helly_infeasible),
            "infeasible_reason": "helly" if helly_infeasible else ("midpoint-drift" if cert_infeasible else None),
            "cert_n": int(cert_n),
            "dps": int(dps),
            "depth": int(depth),
            "localized_near_seed": bool(near_seed),
            "localized_seed_distance": float(seed_distance),
            "localized_effective_max_depth": int(effective_max_depth),
        }
        box_rec = _make_rigid_motion_box(theta_lo_box, theta_hi_box, tbox, certified_feasible=cert_feasible, certified_infeasible=cert_infeasible, details=details)
        explored.append(box_rec)
        if center_pose.sampled_margin > best_pose.sampled_margin:
            best_pose = center_pose
        if cert_feasible:
            feasible.append(box_rec)
            if best_certified_pose is None or center_pose.sampled_margin > best_certified_pose.sampled_margin:
                best_certified_pose = center_pose
            continue
        if cert_infeasible:
            infeasible.append(box_rec)
            continue
        if depth >= effective_max_depth:
            unresolved.append(box_rec)
            continue
        theta_scale = float(r_w * abs(theta_hi_box - theta_lo_box))
        tx_scale = float(tbox.tx_hi - tbox.tx_lo)
        ty_scale = float(tbox.ty_hi - tbox.ty_lo)
        if anisotropic_seed_spans is not None and use_anisotropic_splitting:
            seed_theta, seed_tx, seed_ty = (max(1.0e-9, float(x)) for x in anisotropic_seed_spans)
            theta_priority = float(theta_scale / seed_theta)
            tx_priority = float(tx_scale / seed_tx)
            ty_priority = float(ty_scale / seed_ty)
        else:
            theta_priority, tx_priority, ty_priority = theta_scale, tx_scale, ty_scale
        if theta_priority >= tx_priority and theta_priority >= ty_priority:
            mid = 0.5 * (theta_lo_box + theta_hi_box)
            _push_pending(theta_lo_box, mid, tbox, depth + 1)
            _push_pending(mid, theta_hi_box, tbox, depth + 1)
        elif tx_priority >= ty_priority:
            left, right = _split_translation_box(tbox, axis="tx")
            _push_pending(theta_lo_box, theta_hi_box, left, depth + 1)
            _push_pending(theta_lo_box, theta_hi_box, right, depth + 1)
        else:
            bottom, top = _split_translation_box(tbox, axis="ty")
            _push_pending(theta_lo_box, theta_hi_box, bottom, depth + 1)
            _push_pending(theta_lo_box, theta_hi_box, top, depth + 1)
    if best_pose.details is None:
        best_pose.details = {}
    best_pose.details.update({
        "joint_interval_refinement": True,
        "classified": len(unresolved) == 0,
        "feasible_box_count": len(feasible),
        "infeasible_box_count": len(infeasible),
        "unresolved_box_count": len(unresolved),
        "explored_box_count": len(explored),
        "rigid_best_pose_certified": bool(best_pose.certified_contains),
        "best_certified_pose_exists": bool(best_certified_pose is not None),
    })
    if best_certified_pose is not None:
        best_pose.details["best_certified_pose"] = {
            "rotation": float(best_certified_pose.rotation),
            "translation": [float(best_certified_pose.translation[0]), float(best_certified_pose.translation[1])],
            "sampled_margin": float(best_certified_pose.sampled_margin),
            "sampled_max_violation": float(best_certified_pose.sampled_max_violation),
            "certified_upper_violation": None if best_certified_pose.certified_upper_violation is None else float(best_certified_pose.certified_upper_violation),
        }
    return SupportRigidMotionRefinement2D(
        best_pose=best_pose,
        certified_feasible_boxes=tuple(feasible),
        certified_infeasible_boxes=tuple(infeasible),
        unresolved_boxes=tuple(unresolved),
        explored_boxes=tuple(explored),
    )


def fit_body_in_body_support_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    angle_steps: int = 180,
    fit_angle_grid: Sequence[float] | None = None,
    cert_n: int = 720,
    use_interval_refinement: bool = True,
    initial_intervals: int = 16,
    max_depth: int = 6,
    tol: float = 0.0,
    dps: int = 60,
    lp_mode: str = "sampled",
    lp_solver: str = "auto",
    lp_warm_start: bool = True,
) -> SupportRigidPlacement2D:
    """Fit a convex witness body into a convex container using support data.

    By default this uses interval-certified rotation refinement. It returns the
    best center pose discovered during refinement, with the certified upper
    violation field populated whenever the best pose sits inside a certified
    feasible interval. The separate function
    :func:`refine_body_in_body_support_rigid_2d` upgrades this to native box
    refinement in ``(theta, t_x, t_y)``.
    """
    if use_interval_refinement and fit_angle_grid is None:
        refinement = refine_body_in_body_support_rotation_2d(
            container, witness, angle_steps=angle_steps, cert_n=cert_n, initial_intervals=initial_intervals, max_depth=max_depth, tol=tol,
            dps=dps, lp_mode=lp_mode, lp_solver=lp_solver, lp_warm_start=lp_warm_start,
        )
        best = refinement.best_pose
        for iv in refinement.certified_feasible_intervals:
            if abs(iv.center - best.rotation) < 1e-9:
                best.details = {**(best.details or {}), "interval_refinement": True, "classified": refinement.all_intervals_classified, "feasible_interval_count": len(refinement.certified_feasible_intervals), "feasible_motion_box_count": len(refinement.certified_feasible_motion_boxes), "infeasible_interval_count": len(refinement.certified_infeasible_intervals), "unresolved_interval_count": len(refinement.unresolved_intervals), "interval_half_width": iv.half_width}
                best.certified_upper_violation = iv.feasible_upper_violation
                best.certified_translation_box = iv.certified_translation_box
                break
        if best.details is None:
            best.details = {}
        best.details.setdefault("interval_refinement", True)
        best.details.setdefault("classified", refinement.all_intervals_classified)
        best.details.setdefault("feasible_interval_count", len(refinement.certified_feasible_intervals))
        best.details.setdefault("feasible_motion_box_count", len(refinement.certified_feasible_motion_boxes))
        best.details.setdefault("infeasible_interval_count", len(refinement.certified_infeasible_intervals))
        best.details.setdefault("unresolved_interval_count", len(refinement.unresolved_intervals))
        return best
    if fit_angle_grid is None:
        fit_angle_grid = np.linspace(0.0, 2.0 * math.pi, max(8, int(angle_steps // 4)), endpoint=False)
    sample_angles = np.linspace(0.0, 2.0 * math.pi, int(angle_steps), endpoint=False)
    best: SupportRigidPlacement2D | None = None
    for th in fit_angle_grid:
        wrot = witness.rotate(float(th), name=f"rot({witness.name})")
        dirs, delta = _support_delta(container, wrot, sample_angles)
        lp_res = solve_support_lp_2d(dirs, delta)
        t_opt = np.array(lp_res.translation, dtype=float)
        m_opt = float(lp_res.margin)
        active = lp_res.active_indices
        lp_method = lp_res.method
        translated = wrot.translate(t_opt, name=f"fit({witness.name})")
        sampled_gaps = container.sample_gap(translated, n=angle_steps).gaps
        sampled_margin = float(np.min(sampled_gaps)) if len(sampled_gaps) else 0.0
        sampled_max_violation = float(np.max(-sampled_gaps)) if len(sampled_gaps) else 0.0
        rec = SupportRigidPlacement2D(
            rotation=float(th),
            translation=(float(t_opt[0]), float(t_opt[1])),
            sampled_margin=sampled_margin,
            sampled_max_violation=sampled_max_violation,
            certified_upper_violation=None,
            active_indices=active,
            details={"sample_count": int(angle_steps), "interval_refinement": False, "lp_method": lp_method},
        )
        if best is None or rec.sampled_margin > best.sampled_margin:
            best = rec
    if best is None:
        raise ValueError("empty angle grid")
    return best