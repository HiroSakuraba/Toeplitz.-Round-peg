
"""Local and global rigidity tests for witness configurations."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from .geometry_types import ConvexPolygon2D, Polyline2D, Array
from .minkowski import polyline_tube
from .rigid_fit import fit_polyline_in_polygon


@dataclass
class RigidityReport:
    rank: int
    dof: int
    is_rigid: bool
    note: str = ""
    details: dict | None = None


def rigidity_matrix(contact_normals: Array, tangent_vectors: Array | None = None) -> Array:
    normals = np.asarray(contact_normals, dtype=float)
    if tangent_vectors is None:
        tangent_vectors = np.zeros_like(normals)
    tangents = np.asarray(tangent_vectors, dtype=float)
    return np.hstack([normals, tangents])


def assess_rigidity(contact_normals: Array, tangent_vectors: Array | None = None, ambient_dof: int = 3) -> RigidityReport:
    M = rigidity_matrix(contact_normals, tangent_vectors)
    rank = int(np.linalg.matrix_rank(M))
    dof = max(0, ambient_dof - rank)
    return RigidityReport(rank=rank, dof=dof, is_rigid=(dof == 0), note="rigid iff residual motion space is trivial", details={"matrix_shape": tuple(M.shape)})


def thickened_rigidity_check(container: ConvexPolygon2D, worm: Polyline2D, placement, eps: float = 1e-2) -> RigidityReport:
    thick = polyline_tube(worm, eps)
    placed = thick.rotated(placement.rotation).translated(np.array(placement.translation))
    from .rigid_fit import polygon_halfspace_slack
    slacks = polygon_halfspace_slack(container, placed.vertices)
    margin = float(np.min(slacks))
    rigid = margin < 0.0
    return RigidityReport(rank=3 if rigid else 2, dof=0 if rigid else 1, is_rigid=rigid, note="thickening destroys feasibility => likely rigid", details={"eps": eps, "margin_after_thickening": margin})
