from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Sequence

import numpy as np

from .support import ConvexBody2D
from .support_lp import SupportLPResult2D, solve_support_lp_2d
from .prescreen import WidthCertificate2D, certified_min_width_2d
from .rigid_fit import SupportRigidMotionRefinement2D, RigidMotionBox2D


@dataclass(slots=True)
class SupportFourierSeries2D:
    order: int
    sample_count: int
    a0: float
    cos_coeffs: tuple[float, ...]
    sin_coeffs: tuple[float, ...]
    source: str = "sampled-trapezoid"
    details: dict = field(default_factory=dict)

    def evaluate(self, angles: Sequence[float] | np.ndarray) -> np.ndarray:
        ang = np.asarray(angles, dtype=float)
        out = np.full_like(ang, float(self.a0), dtype=float)
        for k, (ak, bk) in enumerate(zip(self.cos_coeffs, self.sin_coeffs), start=1):
            out += float(ak) * np.cos(k * ang) + float(bk) * np.sin(k * ang)
        return out


@dataclass(slots=True)
class TruncationBound2D:
    order: int
    extended_order: int
    sample_count: int
    sup_bound: float
    mode: str
    observed_grid_tail: float
    observed_coeff_tail: float
    extrapolated_tail: float
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class TranslationTensionPose2D:
    label: str
    theta: float
    translation: tuple[float, float]
    min_gap_angle: float
    sampled_gap_margin: float
    imposed_shift: float
    shift_direction: tuple[float, float]
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class ContactDirectionComparison2D:
    lane_a_angles: tuple[float, ...]
    lane_b_angles: tuple[float, ...]
    overlap_count: int
    overlap_ratio: float
    angle_tolerance: float
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class ShadowSpectralPoseReport2D:
    theta: float
    translation: tuple[float, float]
    lp_margin: float
    sampled_gap_margin: float
    sampled_gap_margin_lp_translation: float
    truncated_gap_margin: float
    tail_sup_proxy: float
    shadow_lower_margin: float
    shadow_status: str
    helly_lp_status: str
    lp_translation: tuple[float, float]
    lp_translation_shift_norm: float
    support_series: SupportFourierSeries2D
    width_certificate: WidthCertificate2D | None = None
    contact_direction_comparison: ContactDirectionComparison2D | None = None
    truncation_module: str = "sampled-tail-proxy"
    truncation_details: dict = field(default_factory=dict)
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class ShadowSpectralCrosscheck2D:
    lane_a_status: str
    lane_b_status: str
    disagreement_taxon: str
    pose_reports: tuple[ShadowSpectralPoseReport2D, ...]
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class ShadowDisagreementSummary2D:
    disagreement_taxon: str
    max_shadow_lower_margin: float
    max_sampled_gap_margin: float
    min_lp_margin: float
    max_contact_overlap_ratio: float
    details: dict = field(default_factory=dict)


ROUND_WITNESS_HINTS = {"orbiform-stub", "disk-half"}
ROUND_MODE_HINTS = {"orbiform-stub", "disk-half", "regular-3-gon", "regular-4-gon", "regular-5-gon", "regular-6-gon"}


def _sample_angles(n: int) -> np.ndarray:
    return np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False, dtype=float)


def _sample_gap_values(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    sample_count: int,
) -> tuple[np.ndarray, np.ndarray]:
    angles = _sample_angles(sample_count)
    tx, ty = float(translation[0]), float(translation[1])
    container_values = np.array([float(container.h(a)) for a in angles], dtype=float)
    witness_values = np.array([float(witness.h(a - float(theta))) for a in angles], dtype=float)
    translation_values = tx * np.cos(angles) + ty * np.sin(angles)
    gaps = container_values - witness_values - translation_values
    return angles, gaps


def sampled_support_fourier_2d(
    body: ConvexBody2D,
    *,
    order: int = 32,
    sample_count: int | None = None,
) -> SupportFourierSeries2D:
    ord_n = max(0, int(order))
    n = int(sample_count) if sample_count is not None else max(256, 8 * max(1, ord_n))
    angles = _sample_angles(n)
    values = np.array([float(body.h(a)) for a in angles], dtype=float)
    a0 = float(np.mean(values))
    cos_coeffs: list[float] = []
    sin_coeffs: list[float] = []
    for k in range(1, ord_n + 1):
        cos_coeffs.append(float(2.0 * np.mean(values * np.cos(k * angles))))
        sin_coeffs.append(float(2.0 * np.mean(values * np.sin(k * angles))))
    return SupportFourierSeries2D(
        order=ord_n,
        sample_count=n,
        a0=a0,
        cos_coeffs=tuple(cos_coeffs),
        sin_coeffs=tuple(sin_coeffs),
        details={"body": str(getattr(body, 'name', 'unnamed'))},
    )


def sampled_gap_fourier_series_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    order: int = 32,
    sample_count: int | None = None,
) -> SupportFourierSeries2D:
    ord_n = max(0, int(order))
    n = int(sample_count) if sample_count is not None else max(512, 8 * max(1, ord_n))
    angles, gaps = _sample_gap_values(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        sample_count=n,
    )
    a0 = float(np.mean(gaps))
    cos_coeffs: list[float] = []
    sin_coeffs: list[float] = []
    for k in range(1, ord_n + 1):
        cos_coeffs.append(float(2.0 * np.mean(gaps * np.cos(k * angles))))
        sin_coeffs.append(float(2.0 * np.mean(gaps * np.sin(k * angles))))
    return SupportFourierSeries2D(
        order=ord_n,
        sample_count=n,
        a0=a0,
        cos_coeffs=tuple(cos_coeffs),
        sin_coeffs=tuple(sin_coeffs),
        details={
            "container": str(getattr(container, 'name', 'container')),
            "witness": str(getattr(witness, 'name', 'witness')),
            "theta": float(theta),
            "translation": [float(translation[0]), float(translation[1])],
        },
    )


def fixed_theta_sampled_lp_translation(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    direction_count: int = 128,
) -> SupportLPResult2D:
    angles = _sample_angles(max(16, int(direction_count)))
    dirs = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    rhs = np.array(
        [
            float(container.h(float(a))) - float(witness.h(float(a) - float(theta)))
            for a in angles
        ],
        dtype=float,
    )
    return solve_support_lp_2d(dirs, rhs)


def sampled_body_diameter_2d(body: ConvexBody2D, *, sample_count: int = 512) -> float:
    angles = np.linspace(0.0, math.pi, max(32, int(sample_count)), endpoint=False, dtype=float)
    widths = np.array([float(body.width(float(a))) for a in angles], dtype=float)
    if widths.size == 0:
        return 0.0
    return float(np.max(widths))


def _canonical_angle(theta: float) -> float:
    out = float(theta) % (2.0 * math.pi)
    if out < 0.0:
        out += 2.0 * math.pi
    return out


def _circular_distance(theta_a: float, theta_b: float) -> float:
    diff = abs(_canonical_angle(theta_a) - _canonical_angle(theta_b))
    return min(diff, 2.0 * math.pi - diff)


def _contact_angles_from_profile(
    angles: np.ndarray,
    gaps: np.ndarray,
    *,
    top_k: int = 3,
    margin_window: float = 1.0e-3,
) -> tuple[float, ...]:
    if len(angles) == 0 or len(gaps) == 0:
        return ()
    top_k = max(1, int(top_k))
    idx = np.argsort(gaps)
    min_gap = float(gaps[idx[0]])
    chosen: list[float] = []
    sep = 0.5 * (2.0 * math.pi / max(16, len(angles)))
    for j in idx.tolist():
        gap_j = float(gaps[j])
        if len(chosen) >= top_k and gap_j > min_gap + float(margin_window):
            break
        angle = float(angles[j])
        if any(_circular_distance(angle, prev) < sep for prev in chosen):
            continue
        chosen.append(angle)
        if len(chosen) >= top_k and gap_j > min_gap + float(margin_window):
            break
    return tuple(_canonical_angle(a) for a in chosen)


def compare_contact_directions_2d(
    lane_a_angles: Sequence[float],
    lane_b_angles: Sequence[float],
    *,
    angle_tolerance: float = 0.15,
) -> ContactDirectionComparison2D:
    left = tuple(_canonical_angle(float(a)) for a in lane_a_angles)
    right = tuple(_canonical_angle(float(a)) for a in lane_b_angles)
    used_right: set[int] = set()
    overlap = 0
    matched_pairs: list[tuple[float, float]] = []
    for a in left:
        best_idx = None
        best_dist = None
        for idx, b in enumerate(right):
            if idx in used_right:
                continue
            dist = _circular_distance(a, b)
            if dist <= float(angle_tolerance) and (best_dist is None or dist < best_dist):
                best_idx = idx
                best_dist = dist
        if best_idx is not None:
            used_right.add(best_idx)
            overlap += 1
            matched_pairs.append((a, right[best_idx]))
    denom = max(1, min(len(left), len(right)))
    return ContactDirectionComparison2D(
        lane_a_angles=left,
        lane_b_angles=right,
        overlap_count=int(overlap),
        overlap_ratio=float(overlap) / float(denom),
        angle_tolerance=float(angle_tolerance),
        details={
            "lane_a_count": int(len(left)),
            "lane_b_count": int(len(right)),
            "matched_pairs": [[float(a), float(b)] for a, b in matched_pairs],
        },
    )


def _coeff_abs_sequence(values: np.ndarray, angles: np.ndarray, order: int) -> list[float]:
    coeff_abs: list[float] = []
    for k in range(1, max(0, int(order)) + 1):
        ak = float(2.0 * np.mean(values * np.cos(k * angles)))
        bk = float(2.0 * np.mean(values * np.sin(k * angles)))
        coeff_abs.append(abs(ak) + abs(bk))
    return coeff_abs


def empirical_gap_truncation_bound_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    order: int = 32,
    sample_count: int | None = None,
    extended_order: int | None = None,
) -> TruncationBound2D:
    ord_n = max(0, int(order))
    ext_order = max(ord_n + 8, int(extended_order) if extended_order is not None else 4 * max(1, ord_n))
    n = int(sample_count) if sample_count is not None else max(4096, 16 * max(1, ext_order))
    angles, gaps = _sample_gap_values(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        sample_count=n,
    )
    truncated = sampled_gap_fourier_series_2d(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        order=ord_n,
        sample_count=n,
    ).evaluate(angles)
    grid_tail = float(np.max(np.abs(gaps - truncated))) if len(gaps) else 0.0
    coeff_abs = _coeff_abs_sequence(gaps, angles, ext_order)
    coeff_tail_known = float(sum(coeff_abs[ord_n:])) if ext_order > ord_n else 0.0

    witness_name = str(getattr(witness, 'name', 'witness'))
    fit_window = min(max(8, ext_order // 8), ext_order)
    fit_start_order = max(ord_n + 1, ext_order - fit_window + 1)
    tail_window = coeff_abs[max(0, ext_order - 8):ext_order]
    if witness_name in ROUND_MODE_HINTS:
        # Rounded / regular lane: fit the k^-2 tail only from the extreme high-k window,
        # then cap it by a monotone suffix envelope on that same window.
        # This avoids low- and mid-frequency structural harmonics inflating the asymptotic tail.
        highk_scaled: list[float] = []
        monotone_caps: list[float] = []
        running_cap = 0.0
        for k in range(ext_order, fit_start_order - 1, -1):
            scaled = float((k ** 2) * coeff_abs[k - 1])
            highk_scaled.append(scaled)
            running_cap = max(running_cap, scaled)
            monotone_caps.append(running_cap)
        highk_scaled.reverse()
        monotone_caps.reverse()
        decay_scale = float(monotone_caps[0] if monotone_caps else 0.0)
        coeff_tail_unknown = float(decay_scale / max(1, ext_order))
        mode = "high-k-k2-tail-envelope-monotone-cap"
    else:
        # Sharp witnesses are kept on a more cautious observed-tail-only lane for now.
        highk_scaled = [float(((k + 1) ** 2) * coeff_abs[k]) for k in range(max(0, ext_order - fit_window), ext_order)]
        monotone_caps = []
        coeff_tail_unknown = float(sum(tail_window))
        mode = "observed-tail-plus-grid"

    sup_bound = max(grid_tail, coeff_tail_known + coeff_tail_unknown)
    return TruncationBound2D(
        order=ord_n,
        extended_order=ext_order,
        sample_count=n,
        sup_bound=float(sup_bound),
        mode=mode,
        observed_grid_tail=float(grid_tail),
        observed_coeff_tail=float(coeff_tail_known),
        extrapolated_tail=float(coeff_tail_unknown),
        details={
            "container": str(getattr(container, 'name', 'container')),
            "witness": witness_name,
            "theta": float(theta),
            "translation": [float(translation[0]), float(translation[1])],
            "coefficient_abs_tail_window": [float(x) for x in tail_window],
            "fit_window": int(fit_window),
            "fit_start_order": int(fit_start_order),
            "highk_scaled_window": [float(x) for x in highk_scaled],
            "monotone_scaled_caps": [float(x) for x in monotone_caps],
            "fit_decay_scale": float(decay_scale if witness_name in ROUND_MODE_HINTS else 0.0),
            "legacy_allk_decay_scale": float(max([((idx + 1) ** 2) * float(val) for idx, val in enumerate(coeff_abs)], default=0.0)),
        },
    )


def sampled_min_gap_direction_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    sample_count: int = 2048,
) -> tuple[float, float]:
    angles, gaps = _sample_gap_values(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        sample_count=max(256, int(sample_count)),
    )
    if len(gaps) == 0:
        return 0.0, 0.0
    idx = int(np.argmin(gaps))
    return float(angles[idx]), float(gaps[idx])


def build_translation_tension_poses_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    sample_count: int = 2048,
    near_boundary_fraction: float = 0.9,
    negative_fraction: float = 1.1,
    absolute_buffer: float = 1.0e-3,
) -> tuple[TranslationTensionPose2D, ...]:
    alpha_star, base_margin = sampled_min_gap_direction_2d(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        sample_count=max(256, int(sample_count)),
    )
    ux = float(math.cos(alpha_star))
    uy = float(math.sin(alpha_star))
    base_tx, base_ty = float(translation[0]), float(translation[1])
    # Shifting translation in +u_alpha lowers the gap at alpha by the same amount.
    feasible_shift = max(0.0, float(near_boundary_fraction) * max(0.0, base_margin))
    infeasible_shift = max(0.0, float(negative_fraction) * max(0.0, base_margin) + float(absolute_buffer))

    cases = [
        ("certified-seed-pose", 0.0),
        ("near-boundary-feasible", feasible_shift),
        ("negative-control", infeasible_shift),
    ]
    out: list[TranslationTensionPose2D] = []
    for label, shift in cases:
        tx = base_tx + float(shift) * ux
        ty = base_ty + float(shift) * uy
        _, sampled_margin = sampled_min_gap_direction_2d(
            container,
            witness,
            theta=float(theta),
            translation=(tx, ty),
            sample_count=max(256, int(sample_count)),
        )
        out.append(
            TranslationTensionPose2D(
                label=label,
                theta=float(theta),
                translation=(float(tx), float(ty)),
                min_gap_angle=float(alpha_star),
                sampled_gap_margin=float(sampled_margin),
                imposed_shift=float(shift),
                shift_direction=(ux, uy),
                details={
                    "base_translation": [base_tx, base_ty],
                    "base_sampled_gap_margin": float(base_margin),
                    "construction_rule": "translation += shift * u(alpha_min)",
                },
            )
        )
    return tuple(out)


def shadow_spectral_verify_pose_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float] | None = None,
    spectral_order: int = 32,
    direction_count: int = 128,
    gap_sample_count: int = 1024,
    width_sample_count: int = 512,
    truncation_sample_count: int | None = None,
    truncation_extended_order: int | None = None,
    contact_top_k: int = 3,
    contact_angle_tolerance: float = 0.15,
    tol: float = 1.0e-9,
) -> ShadowSpectralPoseReport2D:
    lp_result = fixed_theta_sampled_lp_translation(
        container,
        witness,
        theta=float(theta),
        direction_count=direction_count,
    )
    lp_translation = (float(lp_result.translation[0]), float(lp_result.translation[1]))
    used_translation = (
        (float(translation[0]), float(translation[1])) if translation is not None
        else lp_translation
    )

    width_lb = sampled_body_diameter_2d(witness, sample_count=width_sample_count)
    certified_width_lb, width_details = certified_min_width_2d(container, n=max(64, int(width_sample_count // 2)))
    width_certificate = WidthCertificate2D(
        statement=f"shadow width prescreen for {getattr(container, 'name', 'container')}",
        required_width=float(width_lb),
        certified_lower_width=float(certified_width_lb),
        passed=bool(certified_width_lb + float(tol) >= width_lb),
        details={
            **width_details,
            "required_width_source": "sampled-witness-diameter",
        },
    )

    series = sampled_gap_fourier_series_2d(
        container,
        witness,
        theta=float(theta),
        translation=used_translation,
        order=max(0, int(spectral_order)),
        sample_count=max(256, int(gap_sample_count)),
    )
    angles, gaps = _sample_gap_values(
        container,
        witness,
        theta=float(theta),
        translation=used_translation,
        sample_count=max(256, int(gap_sample_count)),
    )
    truncated = series.evaluate(angles)
    truncation = empirical_gap_truncation_bound_2d(
        container,
        witness,
        theta=float(theta),
        translation=used_translation,
        order=max(0, int(spectral_order)),
        sample_count=truncation_sample_count,
        extended_order=truncation_extended_order,
    )
    tail_sup_proxy = float(truncation.sup_bound)
    sampled_gap_margin = float(np.min(gaps)) if len(gaps) else 0.0
    truncated_gap_margin = float(np.min(truncated)) if len(truncated) else 0.0
    shadow_lower_margin = float(truncated_gap_margin - tail_sup_proxy)

    angles_lp, gaps_lp = _sample_gap_values(
        container,
        witness,
        theta=float(theta),
        translation=lp_translation,
        sample_count=max(256, int(gap_sample_count)),
    )
    sampled_gap_margin_lp = float(np.min(gaps_lp)) if len(gaps_lp) else 0.0

    lane_a_contacts = _contact_angles_from_profile(angles, gaps, top_k=contact_top_k)
    lane_b_contacts = _contact_angles_from_profile(angles_lp, gaps_lp, top_k=contact_top_k)
    contact_cmp = compare_contact_directions_2d(
        lane_a_contacts,
        lane_b_contacts,
        angle_tolerance=float(contact_angle_tolerance),
    )

    tx_shift = float(lp_translation[0] - used_translation[0])
    ty_shift = float(lp_translation[1] - used_translation[1])
    lp_shift_norm = float(math.hypot(tx_shift, ty_shift))
    helly_lp_status = "lp-feasible-margin-positive" if float(lp_result.margin) >= -float(tol) else "lp-margin-negative"

    if shadow_lower_margin >= -float(tol):
        status = "shadow-truncation-positive"
    elif sampled_gap_margin >= -float(tol) and float(lp_result.margin) >= -float(tol):
        status = "sampled-feasible-with-helly"
    elif sampled_gap_margin >= -float(tol):
        status = "sampled-feasible-only"
    else:
        status = "shadow-inconclusive"

    return ShadowSpectralPoseReport2D(
        theta=float(theta),
        translation=used_translation,
        lp_margin=float(lp_result.margin),
        sampled_gap_margin=sampled_gap_margin,
        sampled_gap_margin_lp_translation=sampled_gap_margin_lp,
        truncated_gap_margin=truncated_gap_margin,
        tail_sup_proxy=tail_sup_proxy,
        shadow_lower_margin=shadow_lower_margin,
        shadow_status=status,
        helly_lp_status=helly_lp_status,
        lp_translation=lp_translation,
        lp_translation_shift_norm=lp_shift_norm,
        support_series=series,
        width_certificate=width_certificate,
        contact_direction_comparison=contact_cmp,
        truncation_module=str(truncation.mode),
        truncation_details={
            "order": int(truncation.order),
            "extended_order": int(truncation.extended_order),
            "sample_count": int(truncation.sample_count),
            "observed_grid_tail": float(truncation.observed_grid_tail),
            "observed_coeff_tail": float(truncation.observed_coeff_tail),
            "extrapolated_tail": float(truncation.extrapolated_tail),
            "details": dict(truncation.details or {}),
        },
        details={
            "lp_translation": [float(lp_result.translation[0]), float(lp_result.translation[1])],
            "lp_method": str(lp_result.method),
            "lp_active_indices": [int(i) for i in lp_result.active_indices],
            "direction_count": int(direction_count),
            "gap_sample_count": int(gap_sample_count),
            "spectral_order": int(spectral_order),
            "translation_source": "explicit-pose" if translation is not None else "fixed-theta-sampled-lp",
            "lane_a_contact_angles": [float(x) for x in lane_a_contacts],
            "lane_b_contact_angles": [float(x) for x in lane_b_contacts],
            "lp_translation_shift": [tx_shift, ty_shift],
            "width_passed": bool(width_certificate.passed),
        },
    )


def _rigid_box_center_pose(box: RigidMotionBox2D) -> tuple[float, tuple[float, float]]:
    theta = 0.5 * (float(box.rotation_lo) + float(box.rotation_hi))
    tx, ty = box.translation_box.center
    return float(theta), (float(tx), float(ty))


def summarize_shadow_disagreement_2d(
    lane_a_status: str,
    lane_b_status: str,
    pose_reports: Sequence[ShadowSpectralPoseReport2D],
    *,
    tol: float = 1.0e-9,
) -> ShadowDisagreementSummary2D:
    reports = tuple(pose_reports)
    max_shadow_lower = max((float(rep.shadow_lower_margin) for rep in reports), default=-float('inf'))
    max_sampled_gap = max((float(rep.sampled_gap_margin) for rep in reports), default=-float('inf'))
    min_lp_margin = min((float(rep.lp_margin) for rep in reports), default=float('inf'))
    max_contact_overlap = max(
        (float(rep.contact_direction_comparison.overlap_ratio) for rep in reports if rep.contact_direction_comparison is not None),
        default=0.0,
    )
    width_any_fail = any(rep.width_certificate is not None and not bool(rep.width_certificate.passed) for rep in reports)
    sampled_supportive = max_sampled_gap >= -float(tol)
    truncation_supportive = max_shadow_lower >= -float(tol)
    lane_b_supportive = lane_b_status in {"shadow-supportive", "sampled-supportive-only"}

    if lane_a_status == "incomplete":
        taxon = "true-unresolved-case"
    elif lane_a_status == "certified_feasible" and lane_b_status == "shadow-supportive":
        taxon = "agreement-feasible"
    elif lane_a_status == "certified_infeasible" and not lane_b_supportive:
        taxon = "agreement-infeasible"
    elif lane_a_status == "certified_feasible" and sampled_supportive and not truncation_supportive:
        taxon = "truncation-too-loose"
    elif lane_a_status == "certified_feasible" and min_lp_margin < -float(tol) and max_contact_overlap < 0.5:
        taxon = "motion-box-issue"
    elif lane_a_status == "certified_infeasible" and lane_b_supportive and max_contact_overlap < 0.25:
        taxon = "symmetry-transport-or-motion-box-issue"
    elif width_any_fail and lane_b_supportive:
        taxon = "fourier-extraction-or-width-prescreen-mismatch"
    else:
        taxon = "conditioning-or-fourier-extraction"

    return ShadowDisagreementSummary2D(
        disagreement_taxon=taxon,
        max_shadow_lower_margin=max_shadow_lower,
        max_sampled_gap_margin=max_sampled_gap,
        min_lp_margin=min_lp_margin,
        max_contact_overlap_ratio=max_contact_overlap,
        details={
            "lane_a_status": str(lane_a_status),
            "lane_b_status": str(lane_b_status),
            "width_any_fail": bool(width_any_fail),
            "sampled_supportive": bool(sampled_supportive),
            "truncation_supportive": bool(truncation_supportive),
            "pose_count": int(len(reports)),
        },
    )


def shadow_spectral_crosscheck_from_refinement_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    refinement: SupportRigidMotionRefinement2D,
    *,
    spectral_order: int = 32,
    direction_count: int = 128,
    gap_sample_count: int = 1024,
    truncation_sample_count: int | None = None,
    truncation_extended_order: int | None = None,
    pose_limit: int = 2,
    tol: float = 1.0e-9,
) -> ShadowSpectralCrosscheck2D:
    pose_reports: list[ShadowSpectralPoseReport2D] = []

    best = refinement.best_pose
    pose_reports.append(
        shadow_spectral_verify_pose_2d(
            container,
            witness,
            theta=float(best.rotation),
            translation=(float(best.translation[0]), float(best.translation[1])),
            spectral_order=spectral_order,
            direction_count=direction_count,
            gap_sample_count=gap_sample_count,
            truncation_sample_count=truncation_sample_count,
            truncation_extended_order=truncation_extended_order,
            tol=tol,
        )
    )

    for box in list(refinement.certified_feasible_boxes)[: max(0, int(pose_limit))]:
        theta, translation = _rigid_box_center_pose(box)
        pose_reports.append(
            shadow_spectral_verify_pose_2d(
                container,
                witness,
                theta=theta,
                translation=translation,
                spectral_order=spectral_order,
                direction_count=direction_count,
                gap_sample_count=gap_sample_count,
                truncation_sample_count=truncation_sample_count,
                truncation_extended_order=truncation_extended_order,
                tol=tol,
            )
        )

    lane_a_status = (
        "certified_feasible"
        if len(refinement.certified_feasible_boxes) > 0
        else ("certified_infeasible" if len(refinement.unresolved_boxes) == 0 else "incomplete")
    )

    supportive_reports = [rep for rep in pose_reports if rep.width_certificate is None or bool(rep.width_certificate.passed)]
    lower_margins = [float(rep.shadow_lower_margin) for rep in supportive_reports]
    if lower_margins and max(lower_margins) >= -float(tol):
        lane_b_status = "shadow-supportive"
    elif supportive_reports and max(float(rep.sampled_gap_margin) for rep in supportive_reports) >= -float(tol):
        lane_b_status = "sampled-supportive-only"
    else:
        lane_b_status = "shadow-inconclusive"

    disagreement = summarize_shadow_disagreement_2d(lane_a_status, lane_b_status, pose_reports, tol=tol)

    return ShadowSpectralCrosscheck2D(
        lane_a_status=lane_a_status,
        lane_b_status=lane_b_status,
        disagreement_taxon=disagreement.disagreement_taxon,
        pose_reports=tuple(pose_reports),
        details={
            "certified_feasible_box_count": int(len(refinement.certified_feasible_boxes)),
            "unresolved_box_count": int(len(refinement.unresolved_boxes)),
            "explored_box_count": int(len(refinement.explored_boxes)),
            "pose_report_count": int(len(pose_reports)),
            "disagreement_summary": {
                "taxon": str(disagreement.disagreement_taxon),
                "max_shadow_lower_margin": float(disagreement.max_shadow_lower_margin),
                "max_sampled_gap_margin": float(disagreement.max_sampled_gap_margin),
                "min_lp_margin": float(disagreement.min_lp_margin),
                "max_contact_overlap_ratio": float(disagreement.max_contact_overlap_ratio),
                "details": dict(disagreement.details or {}),
            },
        },
    )
