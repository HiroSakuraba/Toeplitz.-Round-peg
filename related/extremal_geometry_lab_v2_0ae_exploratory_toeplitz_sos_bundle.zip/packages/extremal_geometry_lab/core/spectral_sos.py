from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Sequence

import numpy as np

from .support import ConvexBody2D
from .spectral_shadow import sampled_gap_fourier_series_2d, empirical_gap_truncation_bound_2d, SupportFourierSeries2D


@dataclass(slots=True)
class ToeplitzGramCertificate2D:
    order: int
    theta: float
    translation: tuple[float, float]
    matrix_size: int
    min_eigenvalue: float
    max_coefficient_residual: float
    truncated_gap_margin: float
    tail_sup_proxy: float
    shadow_lower_margin: float
    status: str
    details: dict = field(default_factory=dict)


def trig_series_exponential_coeffs(series: SupportFourierSeries2D) -> dict[int, complex]:
    coeffs: dict[int, complex] = {0: complex(float(series.a0), 0.0)}
    for k, (ak, bk) in enumerate(zip(series.cos_coeffs, series.sin_coeffs), start=1):
        ck = 0.5 * complex(float(ak), -float(bk))
        coeffs[k] = ck
        coeffs[-k] = np.conjugate(ck)
    return coeffs


def canonical_toeplitz_gram_from_series(series: SupportFourierSeries2D) -> tuple[np.ndarray, dict[int, complex]]:
    n = int(series.order)
    coeffs = trig_series_exponential_coeffs(series)
    r: dict[int, complex] = {}
    for k in range(-n, n + 1):
        r[k] = coeffs.get(k, 0.0j) / float(n + 1 - abs(k))
    mat = np.empty((n + 1, n + 1), dtype=np.complex128)
    for i in range(n + 1):
        for j in range(n + 1):
            mat[i, j] = r[j - i]
    return mat, coeffs


def evaluate_trig_series(series: SupportFourierSeries2D, angles: Sequence[float] | np.ndarray) -> np.ndarray:
    return series.evaluate(np.asarray(angles, dtype=float))


def evaluate_gram_polynomial(matrix: np.ndarray, angles: Sequence[float] | np.ndarray) -> np.ndarray:
    ang = np.asarray(angles, dtype=float)
    n = matrix.shape[0] - 1
    out = np.empty_like(ang, dtype=float)
    for idx, theta in enumerate(ang):
        v = np.exp(1j * np.arange(n + 1, dtype=float) * float(theta))
        val = np.vdot(v, matrix @ v)
        out[idx] = float(np.real(val))
    return out


def toeplitz_gram_certificate_from_series(
    series: SupportFourierSeries2D,
    *,
    theta: float,
    translation: tuple[float, float],
    tail_sup_proxy: float,
    sample_count: int = 1024,
    psd_tol: float = 1.0e-9,
    coeff_tol: float = 1.0e-7,
) -> ToeplitzGramCertificate2D:
    matrix, coeffs = canonical_toeplitz_gram_from_series(series)
    eigvals = np.linalg.eigvalsh(matrix)
    min_eig = float(np.min(np.real(eigvals))) if eigvals.size else 0.0

    angles = np.linspace(0.0, 2.0 * math.pi, max(64, int(sample_count)), endpoint=False, dtype=float)
    truncated = evaluate_trig_series(series, angles)
    gram_eval = evaluate_gram_polynomial(matrix, angles)
    coeff_residual = float(np.max(np.abs(truncated - gram_eval))) if len(angles) else 0.0
    truncated_gap_margin = float(np.min(truncated)) if len(truncated) else 0.0
    shadow_lower_margin = float(truncated_gap_margin - float(tail_sup_proxy))

    if min_eig >= -float(psd_tol) and coeff_residual <= float(coeff_tol):
        if shadow_lower_margin >= -float(coeff_tol):
            status = 'toeplitz-gram-psd-shadow-positive'
        elif truncated_gap_margin >= -float(coeff_tol):
            status = 'toeplitz-gram-psd-truncated-positive-only'
        else:
            status = 'toeplitz-gram-psd-but-truncated-negative'
    elif coeff_residual > float(coeff_tol):
        status = 'toeplitz-gram-coefficient-mismatch'
    else:
        status = 'toeplitz-gram-indefinite'

    return ToeplitzGramCertificate2D(
        order=int(series.order),
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        matrix_size=int(matrix.shape[0]),
        min_eigenvalue=min_eig,
        max_coefficient_residual=coeff_residual,
        truncated_gap_margin=truncated_gap_margin,
        tail_sup_proxy=float(tail_sup_proxy),
        shadow_lower_margin=shadow_lower_margin,
        status=status,
        details={
            'psd_tol': float(psd_tol),
            'coeff_tol': float(coeff_tol),
            'eigenvalues': [float(np.real(x)) for x in eigvals.tolist()],
            'diag_real': [float(np.real(matrix[i, i])) for i in range(matrix.shape[0])],
            'max_abs_entry': float(np.max(np.abs(matrix))) if matrix.size else 0.0,
        },
    )


def fixed_theta_toeplitz_gram_certificate_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    *,
    theta: float,
    translation: tuple[float, float],
    spectral_order: int = 16,
    gap_sample_count: int = 512,
    truncation_sample_count: int = 1024,
    truncation_extended_order: int = 64,
    gram_sample_count: int = 1024,
    psd_tol: float = 1.0e-9,
    coeff_tol: float = 1.0e-7,
) -> ToeplitzGramCertificate2D:
    series = sampled_gap_fourier_series_2d(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        order=max(0, int(spectral_order)),
        sample_count=max(256, int(gap_sample_count)),
    )
    trunc = empirical_gap_truncation_bound_2d(
        container,
        witness,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        order=max(0, int(spectral_order)),
        sample_count=max(512, int(truncation_sample_count)),
        extended_order=max(int(truncation_extended_order), int(spectral_order) + 8),
    )
    cert = toeplitz_gram_certificate_from_series(
        series,
        theta=float(theta),
        translation=(float(translation[0]), float(translation[1])),
        tail_sup_proxy=float(trunc.sup_bound),
        sample_count=max(256, int(gram_sample_count)),
        psd_tol=float(psd_tol),
        coeff_tol=float(coeff_tol),
    )
    cert.details.update({
        'truncation_mode': str(trunc.mode),
        'truncation_observed_grid_tail': float(trunc.observed_grid_tail),
        'truncation_observed_coeff_tail': float(trunc.observed_coeff_tail),
        'truncation_extrapolated_tail': float(trunc.extrapolated_tail),
        'truncation_extended_order': int(trunc.extended_order),
    })
    return cert
