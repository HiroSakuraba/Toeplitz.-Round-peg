"""Support-function-native convex-body representations and utilities.

This module is the shared abstraction layer for the extremal-geometry lab.
It unifies three viewpoints on a convex body:

1. support-function / width-function data,
2. explicit polygon or polytope proxies when available,
3. sampled or interval-friendly enclosures for certification hooks.

The guiding philosophy is that the *body* is the primary proof-facing object,
while polygons and point clouds are useful proxies for search and testing.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable
import math
import numpy as np

from .geometry_types import (
    ConvexPolygon2D,
    SupportFunction2D,
    SupportFunction3D,
    SphericalDirectionSet,
    Array,
)
from .minkowski import support_sum_2d, support_sum_3d


def _unit(theta: float) -> np.ndarray:
    return np.array([math.cos(theta), math.sin(theta)], dtype=float)


def _normalize_dirs(directions: np.ndarray) -> np.ndarray:
    dirs = np.asarray(directions, dtype=float)
    if dirs.ndim == 1:
        dirs = dirs[None, :]
    norms = np.linalg.norm(dirs, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return dirs / norms


def _sample_angles(n: int) -> np.ndarray:
    return np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False, dtype=float)


def _canonical_interval(theta_lo: float, theta_hi: float) -> tuple[float, float]:
    a = float(theta_lo)
    b = float(theta_hi)
    if b < a:
        a, b = b, a
    return a, b


def _critical_points_in_interval(theta_lo: float, theta_hi: float, *, base: float, period: float) -> list[float]:
    a, b = _canonical_interval(theta_lo, theta_hi)
    if period <= 0.0:
        return []
    k0 = math.ceil((a - base) / period)
    k1 = math.floor((b - base) / period)
    pts: list[float] = []
    for k in range(int(k0), int(k1) + 1):
        t = base + period * k
        if a <= t <= b:
            pts.append(float(t))
    return pts


def _interval_bounds_from_samples(fn: Callable[[float], float], theta_lo: float, theta_hi: float, *, critical_points: list[float] | None = None) -> tuple[float, float]:
    a, b = _canonical_interval(theta_lo, theta_hi)
    pts = [a, b]
    if critical_points is not None:
        pts.extend(float(t) for t in critical_points if a <= float(t) <= b)
    vals = [float(fn(t)) for t in pts]
    return float(min(vals)), float(max(vals))


def _abs_cos_interval(theta_lo: float, theta_hi: float) -> tuple[float, float]:
    a, b = _canonical_interval(theta_lo, theta_hi)
    critical = []
    critical.extend(_critical_points_in_interval(a, b, base=0.0, period=math.pi))
    critical.extend(_critical_points_in_interval(a, b, base=0.5 * math.pi, period=math.pi))
    return _interval_bounds_from_samples(lambda t: abs(math.cos(t)), a, b, critical_points=critical)


def _ellipse_support_interval_raw(a_axis: float, b_axis: float, theta_lo: float, theta_hi: float) -> tuple[float, float]:
    aa = float(a_axis)
    bb = float(b_axis)
    critical = _critical_points_in_interval(theta_lo, theta_hi, base=0.0, period=0.5 * math.pi)
    return _interval_bounds_from_samples(
        lambda t: math.sqrt((aa * math.cos(t)) ** 2 + (bb * math.sin(t)) ** 2),
        theta_lo,
        theta_hi,
        critical_points=critical,
    )


def _direction_dot_interval(shift: Array, theta_lo: float, theta_hi: float) -> tuple[float, float]:
    sx, sy = float(np.asarray(shift, dtype=float)[0]), float(np.asarray(shift, dtype=float)[1])
    amp = math.hypot(sx, sy)
    if amp == 0.0:
        return (0.0, 0.0)
    phi = math.atan2(sy, sx)
    critical = []
    critical.extend(_critical_points_in_interval(theta_lo, theta_hi, base=phi, period=2.0 * math.pi))
    critical.extend(_critical_points_in_interval(theta_lo, theta_hi, base=phi + math.pi, period=2.0 * math.pi))
    return _interval_bounds_from_samples(lambda t: sx * math.cos(t) + sy * math.sin(t), theta_lo, theta_hi, critical_points=critical)


@dataclass(slots=True)
class SupportProfile2D:
    angles: np.ndarray
    values: np.ndarray
    source: str = "sampled"

    def max_abs(self) -> float:
        return float(np.max(np.abs(self.values))) if len(self.values) else 0.0

    def width_values(self) -> np.ndarray:
        n = len(self.values)
        if n == 0:
            return np.array([], dtype=float)
        half = n // 2
        return self.values[:half] + self.values[half:half + half]


@dataclass(slots=True)
class SupportProfile3D:
    directions: np.ndarray
    values: np.ndarray
    source: str = "sampled"

    def max_abs(self) -> float:
        return float(np.max(np.abs(self.values))) if len(self.values) else 0.0


@dataclass(slots=True)
class SupportGapProfile2D:
    angles: np.ndarray
    container_values: np.ndarray
    target_values: np.ndarray
    source: str = "gap-profile"

    @property
    def gaps(self) -> np.ndarray:
        return self.container_values - self.target_values

    def max_violation(self) -> float:
        if len(self.container_values) == 0:
            return 0.0
        return float(np.max(self.target_values - self.container_values))

    def min_margin(self) -> float:
        if len(self.container_values) == 0:
            return 0.0
        return float(np.min(self.gaps))


@dataclass(slots=True)
class SupportGapProfile3D:
    directions: np.ndarray
    container_values: np.ndarray
    target_values: np.ndarray
    source: str = "gap-profile"

    @property
    def gaps(self) -> np.ndarray:
        return self.container_values - self.target_values

    def max_violation(self) -> float:
        if len(self.container_values) == 0:
            return 0.0
        return float(np.max(self.target_values - self.container_values))

    def min_margin(self) -> float:
        if len(self.container_values) == 0:
            return 0.0
        return float(np.min(self.gaps))


@dataclass(slots=True)
class ConvexBody2D:
    support: Callable[[Array], float]
    name: str = "unnamed"
    metadata: dict = field(default_factory=dict)
    polygon_proxy: ConvexPolygon2D | None = None
    support_interval: Callable[[float, float], tuple[float, float] | None] | None = None

    def h(self, theta: float) -> float:
        return self.support_value(_unit(theta))

    def support_value(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        n = np.linalg.norm(u)
        if n == 0.0:
            raise ValueError("support direction must be nonzero")
        return float(self.support(u / n))

    def width(self, theta: float) -> float:
        return self.h(theta) + self.h(theta + math.pi)

    def width_value(self, u: Array) -> float:
        return self.support_value(u) + self.support_value(-np.asarray(u, dtype=float))

    def sample_support(self, n: int = 128) -> SupportProfile2D:
        angles = _sample_angles(n)
        values = np.array([self.h(t) for t in angles], dtype=float)
        return SupportProfile2D(angles=angles, values=values, source=self.name)

    def sample_width(self, n: int = 128) -> tuple[np.ndarray, np.ndarray]:
        angles = np.linspace(0.0, math.pi, int(n), endpoint=False, dtype=float)
        values = np.array([self.width(t) for t in angles], dtype=float)
        return angles, values

    def sample_gap(self, other: "ConvexBody2D", n: int = 256) -> SupportGapProfile2D:
        angles = _sample_angles(n)
        cv = np.array([self.h(t) for t in angles], dtype=float)
        tv = np.array([other.h(t) for t in angles], dtype=float)
        return SupportGapProfile2D(angles=angles, container_values=cv, target_values=tv, source=f"{self.name}-vs-{other.name}")

    def as_support_function(self) -> SupportFunction2D:
        return SupportFunction2D(self.support_value, name=f"h[{self.name}]", metadata=dict(self.metadata))

    def translate(self, shift: Array, *, name: str | None = None) -> "ConvexBody2D":
        shift = np.asarray(shift, dtype=float)
        new_meta = {**self.metadata, "translated": shift.tolist(), "parent": self.name}
        interval = None
        if self.support_interval is not None:
            def _interval(theta_lo: float, theta_hi: float, *, _f=self.support_interval, _s=shift):
                base = _f(theta_lo, theta_hi)
                if base is None:
                    return None
                d_lo, d_hi = _direction_dot_interval(_s, theta_lo, theta_hi)
                return (float(base[0] + d_lo), float(base[1] + d_hi))
            interval = _interval
        return ConvexBody2D(
            support=lambda u, _f=self.support, _s=shift: float(_f(u) + np.dot(_s, np.asarray(u, dtype=float))),
            name=name or f"{self.name}+t",
            metadata=new_meta,
            polygon_proxy=self.polygon_proxy.translated(shift) if self.polygon_proxy is not None else None,
            support_interval=interval,
        )

    def scale(self, lam: float, *, name: str | None = None) -> "ConvexBody2D":
        new_meta = {**self.metadata, "scaled": float(lam), "parent": self.name}
        proxy = None
        if self.polygon_proxy is not None:
            proxy = ConvexPolygon2D(self.polygon_proxy.vertices * lam, name=self.polygon_proxy.name, metadata=dict(self.polygon_proxy.metadata))
        interval = None
        if self.support_interval is not None:
            def _interval(theta_lo: float, theta_hi: float, *, _f=self.support_interval, _lam=float(lam)):
                base = _f(theta_lo, theta_hi)
                if base is None:
                    return None
                return (float(_lam * base[0]), float(_lam * base[1]))
            interval = _interval
        return ConvexBody2D(
            support=lambda u, _f=self.support, _lam=float(lam): _lam * float(_f(u)),
            name=name or f"{lam}*{self.name}",
            metadata=new_meta,
            polygon_proxy=proxy,
            support_interval=interval,
        )

    def reflect(self, *, name: str | None = None) -> "ConvexBody2D":
        new_meta = {**self.metadata, "reflected": True, "parent": self.name}
        interval = None
        if self.support_interval is not None:
            def _interval(theta_lo: float, theta_hi: float, *, _f=self.support_interval):
                return _f(theta_lo + math.pi, theta_hi + math.pi)
            interval = _interval
        return ConvexBody2D(
            support=lambda u, _f=self.support: float(_f(-np.asarray(u, dtype=float))),
            name=name or f"-{self.name}",
            metadata=new_meta,
            polygon_proxy=ConvexPolygon2D(-self.polygon_proxy.vertices, name=f"-{self.polygon_proxy.name}", metadata=dict(self.polygon_proxy.metadata)) if self.polygon_proxy is not None else None,
            support_interval=interval,
        )

    def rotate(self, theta: float, *, name: str | None = None) -> "ConvexBody2D":
        c, s = math.cos(theta), math.sin(theta)
        R = np.array([[c, -s], [s, c]], dtype=float)
        new_meta = {**self.metadata, "rotation": float(theta), "parent": self.name}
        interval = None
        if self.support_interval is not None:
            def _interval(theta_lo: float, theta_hi: float, *, _f=self.support_interval, _theta=float(theta)):
                return _f(theta_lo - _theta, theta_hi - _theta)
            interval = _interval
        return ConvexBody2D(
            support=lambda u, _f=self.support, _R=R: float(_f(_R.T @ np.asarray(u, dtype=float))),
            name=name or f"rot({self.name})",
            metadata=new_meta,
            polygon_proxy=self.polygon_proxy.rotated(theta) if self.polygon_proxy is not None else None,
            support_interval=interval,
        )


@dataclass(slots=True)
class ConvexBody3D:
    support: Callable[[Array], float]
    name: str = "unnamed3d"
    metadata: dict = field(default_factory=dict)

    def support_value(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        n = np.linalg.norm(u)
        if n == 0.0:
            raise ValueError("support direction must be nonzero")
        return float(self.support(u / n))

    def width_value(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        return self.support_value(u) + self.support_value(-u)

    def sample_support(self, directions: np.ndarray | SphericalDirectionSet) -> SupportProfile3D:
        dirs = directions.directions if isinstance(directions, SphericalDirectionSet) else directions
        dirs = _normalize_dirs(np.asarray(dirs, dtype=float))
        values = np.array([self.support_value(u) for u in dirs], dtype=float)
        return SupportProfile3D(directions=dirs, values=values, source=self.name)

    def sample_gap(self, other: "ConvexBody3D", directions: np.ndarray | SphericalDirectionSet) -> SupportGapProfile3D:
        dirs = directions.directions if isinstance(directions, SphericalDirectionSet) else directions
        dirs = _normalize_dirs(np.asarray(dirs, dtype=float))
        cv = np.array([self.support_value(u) for u in dirs], dtype=float)
        tv = np.array([other.support_value(u) for u in dirs], dtype=float)
        return SupportGapProfile3D(directions=dirs, container_values=cv, target_values=tv, source=f"{self.name}-vs-{other.name}")

    def as_support_function(self) -> SupportFunction3D:
        return SupportFunction3D(self.support_value, name=f"h[{self.name}]", metadata=dict(self.metadata))

    def translate(self, shift: Array, *, name: str | None = None) -> "ConvexBody3D":
        shift = np.asarray(shift, dtype=float)
        return ConvexBody3D(
            support=lambda u, _f=self.support, _s=shift: float(_f(u) + np.dot(_s, np.asarray(u, dtype=float))),
            name=name or f"{self.name}+t",
            metadata={**self.metadata, "translated": shift.tolist(), "parent": self.name},
        )

    def scale(self, lam: float, *, name: str | None = None) -> "ConvexBody3D":
        return ConvexBody3D(
            support=lambda u, _f=self.support, _lam=float(lam): _lam * float(_f(u)),
            name=name or f"{lam}*{self.name}",
            metadata={**self.metadata, "scaled": float(lam), "parent": self.name},
        )

    def reflect(self, *, name: str | None = None) -> "ConvexBody3D":
        return ConvexBody3D(
            support=lambda u, _f=self.support: float(_f(-np.asarray(u, dtype=float))),
            name=name or f"-{self.name}",
            metadata={**self.metadata, "reflected": True, "parent": self.name},
        )


@dataclass(slots=True)
class PiecewiseSupportFamily2D:
    angles: np.ndarray
    values: np.ndarray
    metadata: dict = field(default_factory=dict)
    interpolation: str = "linear"

    def __post_init__(self) -> None:
        angles = np.asarray(self.angles, dtype=float)
        values = np.asarray(self.values, dtype=float)
        if angles.ndim != 1 or values.ndim != 1 or len(angles) != len(values):
            raise ValueError("angles and values must be 1D arrays of equal length")
        order = np.argsort(angles)
        self.angles = angles[order]
        self.values = values[order]

    def support_value_angle(self, theta: float) -> float:
        ang = float(theta) % (2.0 * math.pi)
        idx = np.searchsorted(self.angles, ang, side="right")
        i0 = (idx - 1) % len(self.angles)
        i1 = idx % len(self.angles)
        a0 = self.angles[i0]
        a1 = self.angles[i1]
        v0 = self.values[i0]
        v1 = self.values[i1]
        if i1 == 0:
            a1 += 2.0 * math.pi
        if ang < a0:
            ang += 2.0 * math.pi
        if self.interpolation == "nearest" or abs(a1 - a0) < 1e-15:
            return float(v0)
        t = (ang - a0) / (a1 - a0)
        return float((1.0 - t) * v0 + t * v1)

    def to_body(self, *, name: str | None = None) -> ConvexBody2D:
        nm = name or self.metadata.get("name", "piecewise-support")
        return ConvexBody2D(support=lambda u, _self=self: _self.support_value_angle(math.atan2(float(u[1]), float(u[0]))), name=nm, metadata=dict(self.metadata), support_interval=lambda theta_lo, theta_hi, _self=self: _interval_bounds_from_samples(_self.support_value_angle, theta_lo, theta_hi))

    def convexity_residual(self) -> float:
        body = self.to_body()
        prof = body.sample_support(max(64, len(self.angles) * 4))
        vals = prof.values
        step = 2.0 * math.pi / len(vals)
        second = (np.roll(vals, -1) - 2.0 * vals + np.roll(vals, 1)) / (step * step)
        residual = vals + second
        return float(np.min(residual))


@dataclass(slots=True)
class SampledSupportFamily3D:
    directions: np.ndarray
    values: np.ndarray
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        dirs = np.asarray(self.directions, dtype=float)
        vals = np.asarray(self.values, dtype=float)
        if dirs.ndim != 2 or dirs.shape[1] != 3 or vals.ndim != 1 or len(dirs) != len(vals):
            raise ValueError("directions must be (n,3) and values must be (n,)")
        self.directions = _normalize_dirs(dirs)
        self.values = vals

    def nearest_support(self, u: Array) -> float:
        u = np.asarray(u, dtype=float)
        u = u / max(np.linalg.norm(u), 1e-15)
        idx = int(np.argmax(self.directions @ u))
        return float(self.values[idx])

    def to_body(self, *, name: str | None = None) -> ConvexBody3D:
        nm = name or self.metadata.get("name", "sampled-support-3d")
        return ConvexBody3D(support=lambda u, _self=self: _self.nearest_support(u), name=nm, metadata=dict(self.metadata))


# Constructors

def polygon_support(poly: ConvexPolygon2D) -> SupportFunction2D:
    verts = np.asarray(poly.vertices, dtype=float)
    return SupportFunction2D(lambda u: float(np.max(verts @ np.asarray(u, dtype=float))), name=f"h[{poly.name}]", metadata={"from": poly.name})


def body_from_polygon(poly: ConvexPolygon2D) -> ConvexBody2D:
    h = polygon_support(poly)
    return ConvexBody2D(support=h.value, name=poly.name, metadata={"from_polygon": poly.name}, polygon_proxy=poly)


def body_from_support_function(
    sf: SupportFunction2D,
    *,
    polygon_proxy: ConvexPolygon2D | None = None,
    support_interval: Callable[[float, float], tuple[float, float] | None] | None = None,
) -> ConvexBody2D:
    return ConvexBody2D(support=sf.value, name=sf.name, metadata=dict(sf.metadata), polygon_proxy=polygon_proxy, support_interval=support_interval)


def body3d_from_support_function(sf: SupportFunction3D) -> ConvexBody3D:
    return ConvexBody3D(support=sf.value, name=sf.name, metadata=dict(sf.metadata))


def disk_body(radius: float = 1.0) -> ConvexBody2D:
    rr = float(radius)
    return ConvexBody2D(
        support=lambda u, _r=rr: _r * float(np.linalg.norm(u)),
        name=f"disk({radius})",
        metadata={"radius": rr, "family": "euclidean-ball"},
        support_interval=lambda theta_lo, theta_hi, _r=rr: (_r, _r),
    )


def ball_body_3d(radius: float = 1.0) -> ConvexBody3D:
    return ConvexBody3D(support=lambda u, _r=float(radius): _r * float(np.linalg.norm(u)), name=f"ball({radius})", metadata={"radius": float(radius), "family": "euclidean-ball"})


def segment_body(length: float = 1.0, theta: float = 0.0) -> ConvexBody2D:
    direction = _unit(theta)
    half = 0.5 * float(length)
    ang = float(theta)
    return ConvexBody2D(
        support=lambda u, _d=direction, _h=half: _h * abs(float(np.dot(np.asarray(u, dtype=float), _d))),
        name=f"segment({length})",
        metadata={"length": float(length), "theta": ang, "family": "segment"},
        support_interval=lambda theta_lo, theta_hi, _h=half, _ang=ang: tuple(float(_h * v) for v in _abs_cos_interval(theta_lo - _ang, theta_hi - _ang)),
    )


def ellipse_body(a: float, b: float, theta: float = 0.0) -> ConvexBody2D:
    c, s = math.cos(theta), math.sin(theta)
    e1 = np.array([c, s], dtype=float)
    e2 = np.array([-s, c], dtype=float)
    aa = float(a)
    bb = float(b)
    ang = float(theta)
    def _support(u: Array) -> float:
        u = np.asarray(u, dtype=float)
        return float(math.sqrt((aa * np.dot(u, e1)) ** 2 + (bb * np.dot(u, e2)) ** 2))
    return ConvexBody2D(
        support=_support,
        name=f"ellipse({a},{b})",
        metadata={"a": aa, "b": bb, "theta": ang, "family": "ellipse"},
        support_interval=lambda theta_lo, theta_hi, _a=aa, _b=bb, _ang=ang: _ellipse_support_interval_raw(_a, _b, theta_lo - _ang, theta_hi - _ang),
    )


def capsule_body(segment_length: float = 1.0, radius: float = 0.25, theta: float = 0.0) -> ConvexBody2D:
    seg = segment_body(length=float(segment_length), theta=float(theta))
    disk = disk_body(float(radius))
    body = minkowski_sum_bodies_2d(seg, disk, name=f"capsule({segment_length},{radius})")
    body.metadata.update({
        "family": "capsule",
        "segment_length": float(segment_length),
        "radius": float(radius),
        "theta": float(theta),
    })
    return body



def regular_ngon_body(n: int, radius: float = 1.0, theta0: float = 0.0) -> ConvexBody2D:
    angles = theta0 + np.linspace(0.0, 2.0 * math.pi, int(n), endpoint=False)
    verts = np.stack([radius * np.cos(angles), radius * np.sin(angles)], axis=1)
    return body_from_polygon(ConvexPolygon2D(verts, name=f"regular-{n}-gon", metadata={"radius": float(radius), "theta0": float(theta0)}))


def zonotope_body_2d(generators: np.ndarray, *, name: str = "zonotope2d") -> ConvexBody2D:
    gens = np.asarray(generators, dtype=float)
    if gens.ndim != 2 or gens.shape[1] != 2:
        raise ValueError("generators must have shape (m,2)")
    return ConvexBody2D(
        support=lambda u, _g=gens: float(np.sum(np.abs(_g @ np.asarray(u, dtype=float)))),
        name=name,
        metadata={"family": "zonotope", "generator_count": int(len(gens))},
    )


# Operations

def minkowski_sum_bodies_2d(a: ConvexBody2D, b: ConvexBody2D, *, name: str | None = None) -> ConvexBody2D:
    sa = a.as_support_function()
    sb = b.as_support_function()
    sf = support_sum_2d(sa, sb, name=name or f"{a.name}+{b.name}")
    proxy = None
    if a.polygon_proxy is not None and b.polygon_proxy is not None:
        from .minkowski import minkowski_sum_polygons
        proxy = minkowski_sum_polygons(a.polygon_proxy, b.polygon_proxy)

    def _interval(theta_lo: float, theta_hi: float, *, _a=a, _b=b):
        from .certify import interval_support_bounds_2d
        ba = interval_support_bounds_2d(_a, theta_lo, theta_hi)
        bb = interval_support_bounds_2d(_b, theta_lo, theta_hi)
        if ba is None or bb is None:
            return None
        return (float(ba[0] + bb[0]), float(ba[1] + bb[1]))

    interval = _interval if (a.support_interval is not None or a.polygon_proxy is not None) and (b.support_interval is not None or b.polygon_proxy is not None) else None
    return body_from_support_function(sf, polygon_proxy=proxy, support_interval=interval)


def minkowski_sum_bodies_3d(a: ConvexBody3D, b: ConvexBody3D, *, name: str | None = None) -> ConvexBody3D:
    sa = a.as_support_function()
    sb = b.as_support_function()
    sf = support_sum_3d(sa, sb, name=name or f"{a.name}+{b.name}")
    return body3d_from_support_function(sf)


def difference_body_support_2d(a: ConvexBody2D, *, name: str | None = None) -> ConvexBody2D:
    return minkowski_sum_bodies_2d(a, a.reflect(), name=name or f"{a.name}-({a.name})")


def reconstruct_polygon_from_support(body: ConvexBody2D, n: int = 128) -> ConvexPolygon2D:
    """Reconstruct a polygon by intersecting consecutive support lines.

    For equally spaced outward normals u_i with support values h_i, the polygon
    with those support lines is a robust discrete approximation to the convex
    body. This is more stable than the derivative formula for non-smooth support
    profiles and better suited to proof-oriented combinatorics.
    """
    n = int(n)
    angles = _sample_angles(n)
    normals = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    hvals = np.array([body.h(t) for t in angles], dtype=float)
    pts: list[np.ndarray] = []
    for i in range(n):
        u0 = normals[i]
        u1 = normals[(i + 1) % n]
        h0 = hvals[i]
        h1 = hvals[(i + 1) % n]
        A = np.stack([u0, u1], axis=0)
        det = float(np.linalg.det(A))
        if abs(det) < 1e-12:
            continue
        x = np.linalg.solve(A, np.array([h0, h1], dtype=float))
        pts.append(x)
    if len(pts) < 3:
        raise ValueError("support reconstruction produced fewer than 3 vertices")
    return ConvexPolygon2D(np.array(pts, dtype=float), name=f"recon[{body.name}]", metadata={"reconstructed_from": body.name, "sample_count": n})


def support_distance_2d(a: ConvexBody2D, b: ConvexBody2D, n: int = 512) -> float:
    prof = a.sample_gap(b, n=n)
    return float(np.max(np.abs(prof.gaps))) if len(prof.angles) else 0.0


def sampled_contains_body_2d(container: ConvexBody2D, target: ConvexBody2D, n: int = 512, tol: float = 1e-9) -> bool:
    return bool(container.sample_gap(target, n=n).max_violation() <= tol)


def sampled_contains_body_3d(container: ConvexBody3D, target: ConvexBody3D, directions: np.ndarray | SphericalDirectionSet, tol: float = 1e-9) -> bool:
    return bool(container.sample_gap(target, directions=directions).max_violation() <= tol)


def constant_width_residual(body: ConvexBody2D, target_width: float, n: int = 128) -> float:
    _, vals = body.sample_width(n)
    return float(np.max(np.abs(vals - target_width))) if len(vals) else 0.0


def constant_width_residual_3d(body: ConvexBody3D, target_width: float, directions: np.ndarray | SphericalDirectionSet) -> float:
    dirs = directions.directions if isinstance(directions, SphericalDirectionSet) else directions
    dirs = _normalize_dirs(np.asarray(dirs, dtype=float))
    vals = np.array([body.width_value(u) for u in dirs], dtype=float)
    return float(np.max(np.abs(vals - target_width))) if len(vals) else 0.0


def origin_symmetry_residual_2d(body: ConvexBody2D, n: int = 256) -> float:
    angles = _sample_angles(n)
    vals = np.array([body.h(t) - body.h(t + math.pi) for t in angles], dtype=float)
    return float(np.max(np.abs(vals))) if len(vals) else 0.0


def origin_symmetry_residual_3d(body: ConvexBody3D, directions: np.ndarray | SphericalDirectionSet) -> float:
    dirs = directions.directions if isinstance(directions, SphericalDirectionSet) else directions
    dirs = _normalize_dirs(np.asarray(dirs, dtype=float))
    vals = np.array([body.support_value(u) - body.support_value(-u) for u in dirs], dtype=float)
    return float(np.max(np.abs(vals))) if len(vals) else 0.0


def support_value_3d(sf: SupportFunction3D, directions: np.ndarray) -> np.ndarray:
    dirs = _normalize_dirs(np.asarray(directions, dtype=float))
    return np.array([sf.value(u) for u in dirs], dtype=float)
