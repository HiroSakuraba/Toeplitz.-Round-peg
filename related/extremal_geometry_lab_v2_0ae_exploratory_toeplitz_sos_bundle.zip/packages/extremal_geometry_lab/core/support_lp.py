from __future__ import annotations

from dataclasses import dataclass, field
import itertools
import math
import numpy as np

try:
    from scipy.optimize import linprog
except Exception:  # pragma: no cover
    linprog = None

try:
    import cvxpy as cp
except Exception:  # pragma: no cover
    cp = None

from .support import ConvexBody2D
from .interval_cache import IntervalSupportCache2D


@dataclass(slots=True)
class SupportLPResult2D:
    translation: tuple[float, float]
    margin: float
    active_indices: tuple[int, ...]
    method: str
    details: dict = field(default_factory=dict)


class RobustIntervalLPSolver2D:
    def __init__(self, directions: np.ndarray, *, backend: str = "auto"):
        self.directions = np.asarray(directions, dtype=float)
        self.backend = backend
        self._problem = None
        self._rhs = None
        self._tx = None
        self._ty = None
        self._m = None

        if backend in ("auto", "cvxpy-clarabel") and cp is not None:
            n = len(self.directions)
            self._rhs = cp.Parameter(n)
            self._tx = cp.Variable()
            self._ty = cp.Variable()
            self._m = cp.Variable()
            t = cp.vstack([self._tx, self._ty])
            constraints = [self.directions @ t + self._m <= self._rhs]
            self._problem = cp.Problem(cp.Maximize(self._m), constraints)

    def solve(self, rhs: np.ndarray, *, warm_start: bool = True) -> SupportLPResult2D:
        rhs = np.asarray(rhs, dtype=float)
        if self._problem is not None:
            self._rhs.value = rhs
            self._problem.solve(solver=cp.CLARABEL, warm_start=bool(warm_start))
            x = np.array([float(self._tx.value), float(self._ty.value), float(self._m.value)], dtype=float)
            resid = self.directions @ x[:2] + x[2] - rhs
            active = tuple(np.where(np.isclose(resid, 0.0, atol=1e-7))[0].tolist())
            return SupportLPResult2D(
                translation=(float(x[0]), float(x[1])),
                margin=float(x[2]),
                active_indices=active,
                method="cvxpy-clarabel",
                details={"warm_start": bool(warm_start)},
            )
        return solve_support_lp_2d(self.directions, rhs, prefer="highs")


def solve_support_lp_2d(
    directions: np.ndarray,
    rhs: np.ndarray,
    *,
    prefer: str = "auto",
    tol: float = 1e-9,
) -> SupportLPResult2D:
    dirs = np.asarray(directions, dtype=float)
    rhs = np.asarray(rhs, dtype=float)
    n = len(rhs)
    if n < 3:
        raise ValueError("need at least 3 sampled directions")
    A_full = np.column_stack([dirs[:, 0], dirs[:, 1], np.ones(n, dtype=float)])

    if float(np.max(rhs) - np.min(rhs)) <= 1e-10:
        j = int(np.argmin(rhs))
        return SupportLPResult2D((0.0, 0.0), float(rhs[j]), (j,), "flat-rhs")

    if prefer in ("auto", "highs") and linprog is not None:
        c = np.array([0.0, 0.0, -1.0], dtype=float)
        bounds = [(None, None), (None, None), (None, None)]
        res = linprog(c, A_ub=A_full, b_ub=rhs, bounds=bounds, method="highs")
        if res.success and res.x is not None:
            x = np.asarray(res.x, dtype=float)
            resid = A_full @ x - rhs
            active = tuple(np.where(np.isclose(resid, 0.0, atol=1e-7))[0].tolist())
            return SupportLPResult2D(
                translation=(float(x[0]), float(x[1])),
                margin=float(x[2]),
                active_indices=active,
                method="scipy-highs",
            )

    best_x = None
    best_m = -float("inf")
    best_active: tuple[int, ...] = ()
    for triple in itertools.combinations(range(n), 3):
        A = A_full[list(triple), :]
        if abs(float(np.linalg.det(A))) < 1e-10:
            continue
        x = np.linalg.solve(A, rhs[list(triple)])
        resid = A_full @ x - rhs
        if float(np.max(resid)) <= tol:
            if float(x[2]) > best_m:
                best_x = x
                best_m = float(x[2])
                best_active = tuple(np.where(np.isclose(resid, 0.0, atol=1e-7))[0].tolist())

    if best_x is None:
        j = int(np.argmin(rhs))
        return SupportLPResult2D((0.0, 0.0), float(rhs[j]), (j,), "vertex-fallback")

    return SupportLPResult2D(
        translation=(float(best_x[0]), float(best_x[1])),
        margin=float(best_x[2]),
        active_indices=best_active,
        method="vertex-enumeration",
    )


def robust_interval_rhs_2d(
    container: ConvexBody2D,
    witness: ConvexBody2D,
    directions: np.ndarray,
    *,
    theta_lo: float,
    theta_hi: float,
    dps: int = 60,
    cache: IntervalSupportCache2D | None = None,
) -> tuple[np.ndarray, dict]:
    if cache is None:
        cache = IntervalSupportCache2D()

    dirs = np.asarray(directions, dtype=float)
    rhs = np.zeros(len(dirs), dtype=float)
    methods: set[str] = set()

    for i, u in enumerate(dirs):
        alpha = float(math.atan2(float(u[1]), float(u[0])))
        beta_lo = alpha - float(theta_hi)
        beta_hi = alpha - float(theta_lo)
        (_w_lo, w_hi), method = cache.support_bounds_with_fallback(witness, beta_lo, beta_hi, dps=int(dps))
        rhs[i] = float(container.support_value(u) - w_hi)
        methods.add(method)

    return rhs, {"rhs_method": "interval-arc-upper", "support_methods": sorted(methods)}
