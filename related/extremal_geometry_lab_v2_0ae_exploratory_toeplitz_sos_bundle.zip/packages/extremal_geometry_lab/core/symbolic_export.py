
"""Human-readable symbolic reduction export and certificate bundling."""
from __future__ import annotations
from dataclasses import dataclass
import json
from pathlib import Path


@dataclass
class SymbolicReduction:
    title: str
    finite_family: list[str]
    branch_rule: str
    contradiction: str
    contact_structure: list[str] | None = None
    active_witnesses: list[str] | None = None

    def to_markdown(self) -> str:
        lines = [f"# {self.title}", "", "## Finite family"]
        lines += [f"- {x}" for x in self.finite_family]
        if self.contact_structure:
            lines += ["", "## Contact structure"]
            lines += [f"- {x}" for x in self.contact_structure]
        if self.active_witnesses:
            lines += ["", "## Active witnesses"]
            lines += [f"- {x}" for x in self.active_witnesses]
        lines += ["", "## Branch rule", self.branch_rule, "", "## Contradiction", self.contradiction, ""]
        return "\n".join(lines)

    def to_json(self) -> dict:
        return {
            "title": self.title,
            "finite_family": self.finite_family,
            "branch_rule": self.branch_rule,
            "contradiction": self.contradiction,
            "contact_structure": self.contact_structure or [],
            "active_witnesses": self.active_witnesses or [],
        }


def write_symbolic_reduction(base: Path, reduction: SymbolicReduction) -> None:
    base.parent.mkdir(parents=True, exist_ok=True)
    base.with_suffix(".md").write_text(reduction.to_markdown(), encoding="utf-8")
    base.with_suffix(".json").write_text(json.dumps(reduction.to_json(), indent=2), encoding="utf-8")
