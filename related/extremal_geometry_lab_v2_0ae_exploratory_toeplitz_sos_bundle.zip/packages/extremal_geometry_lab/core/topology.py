from __future__ import annotations

from dataclasses import dataclass, field
from collections import deque

from .rigid_fit import RigidMotionBox2D, SupportRigidMotionRefinement2D


@dataclass(slots=True)
class BnBTopologySummary:
    """Diagnostic summary for a rigid-motion branch-and-bound decomposition.

    This is intentionally conservative. It reports connectivity information for
    the certified feasible/infeasible box unions and the extent to which
    unresolved boxes still touch those unions. It does *not* claim topological
    completeness unless no unresolved boxes remain.
    """

    feasible_components: int
    infeasible_components: int
    feasible_component_sizes: tuple[int, ...]
    infeasible_component_sizes: tuple[int, ...]
    unresolved_count: int
    unresolved_fraction: float
    unresolved_touching_feasible_count: int
    unresolved_bridge_risk_count: int
    topological_completeness_proved: bool
    details: dict = field(default_factory=dict)



def _interval_overlap(a_lo: float, a_hi: float, b_lo: float, b_hi: float, *, tol: float = 1.0e-9) -> bool:
    return a_lo < b_hi + tol and b_lo < a_hi + tol



def _interval_touch(a_lo: float, a_hi: float, b_lo: float, b_hi: float, *, tol: float = 1.0e-9) -> bool:
    return abs(a_hi - b_lo) <= tol or abs(b_hi - a_lo) <= tol



def boxes_share_face(a: RigidMotionBox2D, b: RigidMotionBox2D, *, tol: float = 1.0e-9) -> bool:
    a_theta = (float(a.rotation_lo), float(a.rotation_hi))
    b_theta = (float(b.rotation_lo), float(b.rotation_hi))
    a_tx = (float(a.translation_box.tx_lo), float(a.translation_box.tx_hi))
    b_tx = (float(b.translation_box.tx_lo), float(b.translation_box.tx_hi))
    a_ty = (float(a.translation_box.ty_lo), float(a.translation_box.ty_hi))
    b_ty = (float(b.translation_box.ty_lo), float(b.translation_box.ty_hi))
    if _interval_touch(*a_theta, *b_theta, tol=tol) and _interval_overlap(*a_tx, *b_tx, tol=tol) and _interval_overlap(*a_ty, *b_ty, tol=tol):
        return True
    if _interval_touch(*a_tx, *b_tx, tol=tol) and _interval_overlap(*a_theta, *b_theta, tol=tol) and _interval_overlap(*a_ty, *b_ty, tol=tol):
        return True
    if _interval_touch(*a_ty, *b_ty, tol=tol) and _interval_overlap(*a_theta, *b_theta, tol=tol) and _interval_overlap(*a_tx, *b_tx, tol=tol):
        return True
    return False



def _box_volume(box: RigidMotionBox2D) -> float:
    return max(0.0, float(box.rotation_hi) - float(box.rotation_lo)) * max(0.0, float(box.translation_box.tx_hi) - float(box.translation_box.tx_lo)) * max(0.0, float(box.translation_box.ty_hi) - float(box.translation_box.ty_lo))



def _adjacency(boxes: tuple[RigidMotionBox2D, ...]) -> list[list[int]]:
    adj = [[] for _ in range(len(boxes))]
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if boxes_share_face(boxes[i], boxes[j]):
                adj[i].append(j)
                adj[j].append(i)
    return adj



def _component_labels(adj: list[list[int]]) -> tuple[list[int], list[int]]:
    labels = [-1] * len(adj)
    sizes: list[int] = []
    component = 0
    for start in range(len(adj)):
        if labels[start] != -1:
            continue
        queue: deque[int] = deque([start])
        labels[start] = component
        size = 0
        while queue:
            node = queue.popleft()
            size += 1
            for nbr in adj[node]:
                if labels[nbr] == -1:
                    labels[nbr] = component
                    queue.append(nbr)
        sizes.append(size)
        component += 1
    return labels, sizes



def analyze_rigid_motion_refinement_topology(refinement: SupportRigidMotionRefinement2D) -> BnBTopologySummary:
    feasible = tuple(refinement.certified_feasible_boxes)
    infeasible = tuple(refinement.certified_infeasible_boxes)
    unresolved = tuple(refinement.unresolved_boxes)

    feasible_adj = _adjacency(feasible)
    infeasible_adj = _adjacency(infeasible)
    feasible_labels, feasible_sizes = _component_labels(feasible_adj) if feasible else ([], [])
    infeasible_labels, infeasible_sizes = _component_labels(infeasible_adj) if infeasible else ([], [])

    unresolved_touching_feasible_count = 0
    unresolved_bridge_risk_count = 0
    for ubox in unresolved:
        touched_components = set()
        for idx, fbox in enumerate(feasible):
            if boxes_share_face(ubox, fbox):
                unresolved_touching_feasible_count += 1
                if feasible_labels:
                    touched_components.add(int(feasible_labels[idx]))
        if len(touched_components) > 1:
            unresolved_bridge_risk_count += 1

    total_vol = sum(_box_volume(box) for box in feasible) + sum(_box_volume(box) for box in infeasible) + sum(_box_volume(box) for box in unresolved)
    unresolved_vol = sum(_box_volume(box) for box in unresolved)
    unresolved_fraction = float(unresolved_vol / total_vol) if total_vol > 0.0 else 0.0

    return BnBTopologySummary(
        feasible_components=int(len(feasible_sizes)),
        infeasible_components=int(len(infeasible_sizes)),
        feasible_component_sizes=tuple(int(x) for x in feasible_sizes),
        infeasible_component_sizes=tuple(int(x) for x in infeasible_sizes),
        unresolved_count=int(len(unresolved)),
        unresolved_fraction=unresolved_fraction,
        unresolved_touching_feasible_count=int(unresolved_touching_feasible_count),
        unresolved_bridge_risk_count=int(unresolved_bridge_risk_count),
        topological_completeness_proved=bool(len(unresolved) == 0),
        details={
            "mode": "rigid-motion-bnb-topology-summary",
            "feasible_box_count": int(len(feasible)),
            "infeasible_box_count": int(len(infeasible)),
            "unresolved_box_count": int(len(unresolved)),
        },
    )


__all__ = [
    "BnBTopologySummary",
    "boxes_share_face",
    "analyze_rigid_motion_refinement_topology",
]
