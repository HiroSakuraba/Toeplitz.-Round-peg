
"""Spherical normal-coverage environment for structured 3D classes."""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np

from ...core.geometry_types import SphericalDirectionSet, SupportFunction3D


@dataclass
class NormalCoverageInstance:
    normals: np.ndarray
    directions: np.ndarray

    def slack_matrix(self) -> np.ndarray:
        normals = np.asarray(self.normals, dtype=float)
        directions = np.asarray(self.directions, dtype=float)
        return normals @ directions.T

    def covered_mask(self, threshold: float = 0.0) -> np.ndarray:
        return np.max(self.slack_matrix(), axis=1) > threshold


def fibonacci_sphere(n: int = 64) -> np.ndarray:
    pts = []
    golden = (1 + 5 ** 0.5) / 2
    for i in range(n):
        z = 1 - 2 * (i + 0.5) / n
        r = max(0.0, 1.0 - z * z) ** 0.5
        theta = 2 * np.pi * i / golden
        pts.append((r * np.cos(theta), r * np.sin(theta), z))
    return np.array(pts, dtype=float)


def constant_width_residual_3d(sf: SupportFunction3D, width: float, directions: np.ndarray | None = None) -> float:
    dirs = fibonacci_sphere(128) if directions is None else np.asarray(directions, dtype=float)
    vals = np.array([sf.value(u) + sf.value(-u) - width for u in dirs], dtype=float)
    return float(np.max(np.abs(vals)))


def certified_illumination_cover(normals: np.ndarray, directions: np.ndarray, threshold: float = 0.0) -> dict:
    inst = NormalCoverageInstance(normals=np.asarray(normals, dtype=float), directions=np.asarray(directions, dtype=float))
    covered = inst.covered_mask(threshold=threshold)
    return {
        "covered": bool(np.all(covered)),
        "covered_count": int(np.sum(covered)),
        "total": int(len(covered)),
        "worst_margin": float(np.max(np.min(inst.slack_matrix(), axis=1))),
    }
