"""Pál-descended candidate family stubs for Lebesgue's problem."""
from __future__ import annotations
import math
import numpy as np

from ...core.geometry_types import ConvexPolygon2D
from ...core.minkowski import convex_hull
from ...core.canonicalize import canonical_polygon_signature
from ...core.support import body_from_polygon, disk_body, minkowski_sum_bodies_2d, reconstruct_polygon_from_support
from ...core.rigid_fit import fit_body_in_body_support_2d
from ...certificates.formats import minimal_contact_certificate_payload


def regular_hexagon_circumradius(r: float = 1.0) -> ConvexPolygon2D:
    theta = np.linspace(0.0, 2.0*math.pi, 6, endpoint=False) + math.pi/6.0
    verts = np.stack([r*np.cos(theta), r*np.sin(theta)], axis=1)
    return ConvexPolygon2D(verts, name="pal-seed")


def body_from_state(state: dict):
    body = state.get("body")
    if body is not None and state.get("arc_replacements"):
        return body
    return body_from_polygon(state["polygon"])


def state_polygon_proxy(state: dict, *, n: int = 192) -> ConvexPolygon2D:
    poly = state.get("polygon")
    if poly is not None:
        return poly
    return reconstruct_polygon_from_support(body_from_state(state), n=n)




def _cyclic_lexicographic_min(seq: tuple[int, ...]) -> tuple[int, ...]:
    if not seq:
        return seq
    doubled = seq + seq
    n = len(seq)
    best = seq
    for i in range(1, n):
        cand = doubled[i:i+n]
        if cand < best:
            best = cand
    return best


def support_signature_metrics(
    state: dict,
    *,
    n_samples: int = 64,
    n_signature: int = 8,
    n_buckets: int = 12,
) -> dict:
    body = body_from_state(state)
    proxy = state_polygon_proxy(state, n=max(int(n_samples), 96))
    center = proxy.centroid()
    centered = body.translate(-center, name=f"{body.name}-centered")
    prof = centered.sample_support(n=int(n_samples))
    vals = np.asarray(prof.values, dtype=float)
    if len(vals) == 0:
        return {
            "diameter": 0.0,
            "shape_ratio": 0.0,
            "signature": tuple(),
            "scale_bucket": 0,
            "shape_bucket": 0,
        }

    n = len(vals)
    half = n // 2
    if half > 0:
        diam = max(float(vals[i] + vals[(i + half) % n]) for i in range(half))
    else:
        diam = float(np.max(np.abs(vals))) if len(vals) else 1.0
    if diam <= 1.0e-12:
        diam = 1.0
    normalized = vals / diam

    step = max(1, n // max(1, int(n_signature)))
    signature_vals = normalized[::step][: max(1, int(n_signature))]
    quantized = []
    for v in signature_vals:
        x = float(max(0.0, min(0.999999, v)))
        quantized.append(int(math.floor(x * int(n_buckets))))
    signature = _cyclic_lexicographic_min(tuple(quantized))

    area = float(area_polygon(proxy.vertices))
    shape_ratio = float(area / max(diam * diam, 1.0e-12))
    scale_bucket = int(math.floor((diam / 2.0) * 50.0))
    shape_bucket = int(math.floor(shape_ratio * 1000.0))
    return {
        "diameter": float(diam),
        "shape_ratio": shape_ratio,
        "signature": signature,
        "scale_bucket": scale_bucket,
        "shape_bucket": shape_bucket,
    }



def support_signature_key(
    state: dict,
    *,
    n_samples: int = 64,
    n_signature: int = 8,
    n_buckets: int = 12,
) -> tuple:
    metrics = support_signature_metrics(
        state,
        n_samples=n_samples,
        n_signature=n_signature,
        n_buckets=n_buckets,
    )
    return (
        "support-signature",
        int(metrics["scale_bucket"]),
        int(metrics["shape_bucket"]),
        *tuple(metrics["signature"]),
    )


def _cyclic_gap_signature(buckets: tuple[int, ...], modulus: int) -> tuple[int, ...]:
    if not buckets:
        return tuple()
    ordered = tuple(sorted(int(b) % modulus for b in buckets))
    gaps = []
    for i, b in enumerate(ordered):
        nxt = ordered[(i + 1) % len(ordered)]
        if i + 1 < len(ordered):
            gaps.append(int(nxt - b))
        else:
            gaps.append(int((nxt + modulus) - b))
    return _cyclic_lexicographic_min(tuple(gaps))


DEFAULT_CONTACT_PROBE_NAMES: tuple[str, ...] = ("segment", "orbiform-stub", "disk-half")

# Search-side heuristic boundaries for coarse witness shape clustering.
# These bins guide targeted-move suggestions only; they are not theorem-level classes.
# The thresholds are empirical and intentionally exposed here so handoffs and demos can
# report the same values the move policy is actually using.
WITNESS_CLUSTER_NEEDLE_AREA_RATIO_MAX = 0.14
WITNESS_CLUSTER_POINTY_AREA_RATIO_MAX = 0.20
WITNESS_CLUSTER_ROUND_AREA_RATIO_MIN = 0.26
WITNESS_CLUSTER_NEEDLE_MAX_VERTICES = 4
WITNESS_CLUSTER_POINTY_MAX_VERTICES = 4
WITNESS_CLUSTER_ROUND_MIN_VERTICES = 8

# Search-side targeted-move defaults. These are tuned empirical constants rather than
# geometric identities. They should be read as default proposal scales for the current
# beam search, not as certificate-side quantities.
TARGETED_MOVE_DEFAULT_CUT_BY_SEVERITY = {
    "safe": 0.02,
    "mild": 0.035,
    "moderate": 0.06,
    "severe": 0.08,
}
TARGETED_MOVE_TRIANGLE_RADIUS_BY_SEVERITY = {
    "safe": 0.014,
    "mild": 0.014,
    "moderate": 0.018,
    "severe": 0.018,
}
TARGETED_MOVE_SQUARE_RADIUS_BY_CLUSTER = {
    "broad": 0.012,
    "round": 0.016,
}
TARGETED_MOVE_NET_HEAVY_RADIUS_BY_SEVERITY = {
    "safe": 0.016,
    "mild": 0.02,
    "moderate": 0.02,
    "severe": 0.02,
}
TARGETED_MOVE_FALLBACK_SPECS = {
    "pointy_rounding": {"label": "targeted-triangle-rounding", "kind": "rounding", "target": "triangle", "cut": 0.035, "radius": 0.018},
    "pointy_cut": {"label": "targeted-triangle-cut", "kind": "cut", "target": "triangle", "cut": 0.045},
    "broad_rounding": {"label": "targeted-square-rounding", "kind": "rounding", "target": "square", "cut": 0.06, "radius": 0.012},
    "mixed_rounding": {"label": "targeted-net-heavy-rounding", "kind": "rounding", "target": "net-heavy", "cut": 0.12, "radius": 0.02},
}

# Quick witness fits start coarse, then selectively re-fit near the margin.
# This keeps the common easy case cheap while improving the only cases where the
# quick-fit margin materially affects the follow-up move policy.
QUICK_WITNESS_BASE_ANGLE_STEPS = 12
QUICK_WITNESS_ADAPTIVE_ANGLE_STEPS = 24
QUICK_WITNESS_ADAPTIVE_MARGIN_THRESHOLD = 0.12


def _contact_probe_lookup() -> dict[str, ConvexPolygon2D]:
    return {name: poly for name, poly in probe_witness_library()}


def contact_signature_metrics(
    state: dict,
    *,
    witness_name: str = "segment",
    angle_steps: int = 48,
    sample_count: int = 96,
    direction_buckets: int = 24,
) -> dict:
    body = body_from_state(state)
    witness_lookup = _contact_probe_lookup()
    if witness_name not in witness_lookup:
        raise ValueError(f"unsupported contact witness: {witness_name}")
    witness_poly = witness_lookup[witness_name]
    witness = body_from_polygon(witness_poly)
    fit = fit_body_in_body_support_2d(
        body,
        witness,
        angle_steps=int(angle_steps),
        cert_n=max(int(sample_count), int(angle_steps)),
        use_interval_refinement=False,
    )
    mc = minimal_contact_certificate_payload(body, witness, fit, sample_count=int(sample_count))
    active_dirs = tuple(float(a) for a in mc.get("active_directions", ()))
    quantized = tuple(sorted(int(math.floor((((a % (2.0 * math.pi)) / (2.0 * math.pi)) * int(direction_buckets)))) % int(direction_buckets) for a in active_dirs))
    gap_signature = _cyclic_gap_signature(quantized, int(direction_buckets))
    return {
        "witness_name": witness_name,
        "contact_cardinality": int(len(active_dirs)),
        "active_directions": active_dirs,
        "direction_buckets": quantized,
        "gap_signature": gap_signature,
        "margin": float(mc.get("margin", 0.0)),
        "verification_method": mc.get("verification_method", "pose-replay"),
        "lp_method": (fit.details or {}).get("lp_method"),
    }


def contact_probe_library_metrics(
    state: dict,
    *,
    witness_names: tuple[str, ...] = DEFAULT_CONTACT_PROBE_NAMES,
    angle_steps: int = 48,
    sample_count: int = 96,
    direction_buckets: int = 24,
) -> dict:
    per_probe = []
    total_card = 0
    algebraic_count = 0
    for name in witness_names:
        metrics = contact_signature_metrics(
            state,
            witness_name=name,
            angle_steps=angle_steps,
            sample_count=sample_count,
            direction_buckets=direction_buckets,
        )
        per_probe.append(metrics)
        total_card += int(metrics["contact_cardinality"])
        if metrics.get("verification_method") == "algebraic-solve":
            algebraic_count += 1
    compact = tuple(
        (
            m["witness_name"],
            int(m["contact_cardinality"]),
            *tuple(int(x) for x in m["gap_signature"]),
        )
        for m in per_probe
    )
    return {
        "witness_names": tuple(str(x) for x in witness_names),
        "per_probe": tuple(per_probe),
        "probe_signature": compact,
        "probe_key_count": int(len({tuple(x) for x in compact})),
        "total_contact_cardinality": int(total_card),
        "algebraic_probe_count": int(algebraic_count),
    }


def _contact_signature_key_from_metrics(metrics: dict) -> tuple:
    return (
        "contact-signature",
        str(metrics["witness_name"]),
        int(metrics["contact_cardinality"]),
        *tuple(int(x) for x in metrics["gap_signature"]),
    )


def _contact_probe_library_key_from_metrics(metrics: dict) -> tuple:
    return ("contact-probe-library", *tuple(metrics["probe_signature"]))


def contact_signature_key(
    state: dict,
    *,
    witness_name: str = "segment",
    angle_steps: int = 48,
    sample_count: int = 96,
    direction_buckets: int = 24,
) -> tuple:
    metrics = contact_signature_metrics(
        state,
        witness_name=witness_name,
        angle_steps=angle_steps,
        sample_count=sample_count,
        direction_buckets=direction_buckets,
    )
    return _contact_signature_key_from_metrics(metrics)


def contact_probe_library_key(
    state: dict,
    *,
    witness_names: tuple[str, ...] = DEFAULT_CONTACT_PROBE_NAMES,
    angle_steps: int = 48,
    sample_count: int = 96,
    direction_buckets: int = 24,
) -> tuple:
    metrics = contact_probe_library_metrics(
        state,
        witness_names=witness_names,
        angle_steps=angle_steps,
        sample_count=sample_count,
        direction_buckets=direction_buckets,
    )
    return _contact_probe_library_key_from_metrics(metrics)


def pal_seed() -> dict:
    poly = regular_hexagon_circumradius(1.0)
    return {"family": "pal-descended", "polygon": poly, "body": body_from_polygon(poly), "corner_cuts": [], "arc_replacements": []}


def apply_corner_cut(poly: ConvexPolygon2D, amount: float) -> ConvexPolygon2D:
    center = poly.centroid()
    verts = center + (poly.vertices - center) * (1.0 - amount)
    return ConvexPolygon2D(convex_hull(verts), name=f"{poly.name}-cut", metadata={"corner_cut": amount})


def apply_arc_rounding(poly: ConvexPolygon2D, *, cut_amount: float, radius: float, n_proxy: int = 192):
    cut = apply_corner_cut(poly, float(cut_amount))
    rounded = minkowski_sum_bodies_2d(
        body_from_polygon(cut),
        disk_body(float(radius)),
        name=f"{cut.name}+arc({radius})",
    )
    rounded.metadata.update({
        "family": "rounded-minkowski",
        "base_polygon_name": cut.name,
        "base_polygon_vertices": cut.vertices.tolist(),
        "rounding_radius": float(radius),
        "cut_amount": float(cut_amount),
    })
    proxy = reconstruct_polygon_from_support(rounded, n=int(n_proxy))
    return cut, rounded, proxy


def moves(state: dict):
    poly = state_polygon_proxy(state)
    tiny = apply_corner_cut(poly, 0.005)
    yield ("tiny-corner-cut", {**state, "polygon": tiny, "body": body_from_polygon(tiny), "corner_cuts": state["corner_cuts"] + [0.005]})
    cut = apply_corner_cut(poly, 0.02)
    yield ("small-corner-cut", {**state, "polygon": cut, "body": body_from_polygon(cut), "corner_cuts": state["corner_cuts"] + [0.02]})
    medium = apply_corner_cut(poly, 0.08)
    yield ("medium-corner-cut", {**state, "polygon": medium, "body": body_from_polygon(medium), "corner_cuts": state["corner_cuts"] + [0.08]})
    aggressive = apply_corner_cut(poly, 0.5)
    yield ("aggressive-corner-cut", {**state, "polygon": aggressive, "body": body_from_polygon(aggressive), "corner_cuts": state["corner_cuts"] + [0.5]})

    arc_cut, arc_body, arc_proxy = apply_arc_rounding(poly, cut_amount=0.02, radius=0.01)
    yield (
        "small-arc-rounding",
        {
            **state,
            "polygon": arc_proxy,
            "body": arc_body,
            "corner_cuts": state["corner_cuts"] + [0.02],
            "arc_replacements": state["arc_replacements"] + [{"type": "rounded-minkowski", "cut": 0.02, "radius": 0.01}],
            "construction": {
                "kind": "rounded-minkowski",
                "base_polygon": arc_cut.name,
                "base_polygon_vertices": arc_cut.vertices.tolist(),
                "rounded_radius": 0.01,
                "proxy_vertices": arc_proxy.vertices.tolist(),
            },
        },
    )

    heavy_arc_cut, heavy_arc_body, heavy_arc_proxy = apply_arc_rounding(poly, cut_amount=0.08, radius=0.015)
    yield (
        "heavy-arc-rounding",
        {
            **state,
            "polygon": heavy_arc_proxy,
            "body": heavy_arc_body,
            "corner_cuts": state["corner_cuts"] + [0.08],
            "arc_replacements": state["arc_replacements"] + [{"type": "rounded-minkowski", "cut": 0.08, "radius": 0.015}],
            "construction": {
                "kind": "rounded-minkowski",
                "base_polygon": heavy_arc_cut.name,
                "base_polygon_vertices": heavy_arc_cut.vertices.tolist(),
                "rounded_radius": 0.015,
                "proxy_vertices": heavy_arc_proxy.vertices.tolist(),
            },
        },
    )


def _yield_unique_moves(seen_labels: set[str], items):
    for label, child in items:
        if label in seen_labels:
            continue
        seen_labels.add(label)
        yield label, child


def _witness_shape_cluster(poly: ConvexPolygon2D, *, n_samples: int = 64) -> str:
    """Map a witness proxy into a coarse search-side shape bin.

    The bins are intentionally empirical and low-dimensional: they let the search
    policy react to broad geometric pressure without pretending to expose a theorem
    classification. The current boundaries are:

    - ``needle``: at most 4 vertices and normalized area ratio < 0.14
    - ``pointy``: at most 4 vertices and normalized area ratio < 0.20
    - ``round``: at least 8 vertices or normalized area ratio >= 0.26
    - otherwise ``broad``

    Here the normalized area ratio is ``area / diameter^2`` estimated from a support
    sample. These cutoffs are tuned search heuristics and are surfaced explicitly in
    the handoff so later revisions can audit or retune them.
    """
    body = body_from_polygon(poly)
    prof = body.sample_support(n=max(16, int(n_samples)))
    vals = np.asarray(prof.values, dtype=float)
    n = len(vals)
    half = n // 2
    if half > 0:
        diam = max(float(vals[i] + vals[(i + half) % n]) for i in range(half))
    else:
        diam = 1.0
    area_ratio = float(area_polygon(poly.vertices)) / max(float(diam * diam), 1.0e-12)
    verts = int(len(poly.vertices))
    if verts <= WITNESS_CLUSTER_NEEDLE_MAX_VERTICES and area_ratio < WITNESS_CLUSTER_NEEDLE_AREA_RATIO_MAX:
        return "needle"
    if verts <= WITNESS_CLUSTER_POINTY_MAX_VERTICES and area_ratio < WITNESS_CLUSTER_POINTY_AREA_RATIO_MAX:
        return "pointy"
    if verts >= WITNESS_CLUSTER_ROUND_MIN_VERTICES or area_ratio >= WITNESS_CLUSTER_ROUND_AREA_RATIO_MIN:
        return "round"
    return "broad"


def _contact_target_summary_from_metrics(metrics: dict) -> str:
    total = int(metrics.get("total_contact_cardinality", 0))
    algebraic = int(metrics.get("algebraic_probe_count", 0))
    probe_keys = int(metrics.get("probe_key_count", 0))
    if total <= 4:
        return "sparse"
    if algebraic >= 2:
        return "locked"
    if probe_keys >= 2:
        return "mixed"
    return "simple"


def _margin_severity_bucket(min_margin: float) -> str:
    value = float(min_margin)
    if value < -0.10:
        return "severe"
    if value < -0.02:
        return "moderate"
    if value < 0.08:
        return "mild"
    return "safe"


def _quick_witness_fit_policy(
    sampled_margin: float,
    *,
    base_angle_steps: int,
    cert_n: int,
    adaptive_angle_steps: int,
    adaptive_margin_threshold: float,
) -> tuple[int, int, bool]:
    """Return the follow-up quick-fit resolution for a witness.

    Quick witness fits are used only to steer search heuristics. We therefore start
    at a coarse angular grid and selectively re-fit only near the margin where a bad
    pose estimate would materially affect severity buckets or targeted-move scores.
    """
    margin = float(sampled_margin)
    if base_angle_steps >= adaptive_angle_steps or margin > float(adaptive_margin_threshold):
        return int(base_angle_steps), int(cert_n), False
    next_steps = max(int(base_angle_steps), int(adaptive_angle_steps))
    next_cert_n = max(int(cert_n), 2 * int(next_steps))
    return int(next_steps), int(next_cert_n), True


def _severity_score(severity: str) -> float:
    return {"safe": 0.0, "mild": 0.5, "moderate": 1.0, "severe": 1.5}.get(str(severity), 0.25)


def _target_kind_score(kind: str, target: str) -> float:
    if str(target) == "net-heavy":
        return 0.45
    return 0.25 if str(kind) == "rounding" else 0.15


def _score_target_spec(spec: dict, *, ann: dict | None = None, cluster_stats: tuple[dict, ...] | None = None) -> float:
    ann = ann or {}
    stats = tuple(cluster_stats or ann.get("witness_net_cluster_stats", ()))
    pressure_by_cluster = {str(s.get("cluster", "unknown")): float(s.get("pressure", 0.0)) for s in stats}
    cluster = str(spec.get("cluster", spec.get("target", "unknown")))
    pressure = float(pressure_by_cluster.get(cluster, 0.0))
    severity = _severity_score(str(spec.get("severity", "mild")))
    kind_bonus = _target_kind_score(str(spec.get("kind", "rounding")), str(spec.get("target", "generic")))
    cut = float(spec.get("cut", 0.0))
    radius = float(spec.get("radius", 0.0))
    geometric_scale = min(0.35, 2.0 * cut + 4.0 * radius)
    return float(pressure + severity + kind_bonus + geometric_scale)


def _target_score_summary_from_specs(specs: tuple[dict, ...] | list[dict]) -> dict:
    scores = [float(spec.get("score", 0.0)) for spec in specs]
    if not scores:
        return {
            "max_score": 0.0,
            "total_score": 0.0,
            "score_bucket": 0,
            "score_signature": tuple(),
            "suggested_targets": tuple(),
        }
    clipped = [max(0.0, s) for s in scores[:3]]
    signature = tuple(int(math.floor(min(9.0, s) * 10.0)) for s in clipped)
    max_score = max(scores)
    return {
        "max_score": float(max_score),
        "total_score": float(sum(scores)),
        "score_bucket": int(math.floor(min(9.0, max_score) * 10.0)),
        "score_signature": signature,
        "suggested_targets": tuple(dict.fromkeys(str(spec.get("target", "")) for spec in specs[:2])),
    }


def _ledger_cluster_stats(witness_results: tuple[dict, ...] | list[dict]) -> tuple[dict, ...]:
    by_cluster: dict[str, dict] = {}
    for rec in witness_results:
        cluster = str(rec.get("cluster", "unknown"))
        margin = float(rec.get("sampled_margin", 0.0))
        passed = bool(rec.get("passed", False))
        bucket = by_cluster.setdefault(cluster, {
            "cluster": cluster,
            "count": 0,
            "passed_count": 0,
            "failed_count": 0,
            "min_margin": float("inf"),
            "mean_margin_sum": 0.0,
            "labels": [],
        })
        bucket["count"] += 1
        bucket["passed_count"] += int(passed)
        bucket["failed_count"] += int(not passed)
        bucket["min_margin"] = min(float(bucket["min_margin"]), margin)
        bucket["mean_margin_sum"] += margin
        bucket["labels"].append(str(rec.get("label", cluster)))
    stats = []
    for cluster, bucket in by_cluster.items():
        count = max(1, int(bucket["count"]))
        mean_margin = float(bucket["mean_margin_sum"]) / float(count)
        min_margin = float(bucket["min_margin"])
        failed_fraction = float(bucket["failed_count"]) / float(count)
        pressure = float(max(0.0, 0.10 - min_margin) + 0.5 * failed_fraction)
        stats.append({
            "cluster": cluster,
            "count": int(count),
            "passed_count": int(bucket["passed_count"]),
            "failed_count": int(bucket["failed_count"]),
            "min_margin": min_margin,
            "mean_margin": mean_margin,
            "failed_fraction": failed_fraction,
            "pressure": pressure,
            "severity": _margin_severity_bucket(min_margin),
            "labels": tuple(bucket["labels"]),
        })
    stats.sort(key=lambda d: (-float(d["pressure"]), float(d["min_margin"]), str(d["cluster"])))
    return tuple(stats)


def _target_specs_from_annotation_with_metadata(ann: dict) -> tuple[tuple[dict, ...], str]:
    specs = ann.get("witness_target_move_specs")
    if specs:
        path = str(ann.get("witness_target_annotation_path", "ledger-specs"))
        out = []
        for x in specs:
            item = dict(x)
            item.setdefault("score", _score_target_spec(item, ann=ann))
            item.setdefault("annotation_path", path)
            out.append(item)
        out.sort(key=lambda d: (-float(d.get("score", 0.0)), str(d.get("label", ""))))
        return tuple(out), path

    failed = {str(x) for x in ann.get("witness_net_failed_labels", ())}
    weakest = {str(x) for x in ann.get("witness_net_weakest_labels", ())}
    failed_clusters = tuple(str(x) for x in ann.get("witness_net_failed_clusters", ()))
    low_margin_clusters = tuple(str(x) for x in ann.get("witness_net_low_margin_clusters", ()))
    weakest_clusters = tuple(str(x) for x in ann.get("witness_net_weakest_clusters", ()))
    driver_clusters = tuple(dict.fromkeys(low_margin_clusters or failed_clusters or weakest_clusters))
    driver_labels = failed if failed else weakest
    contact_summary = str(ann.get("witness_target_contact_summary", ""))
    pointy_pressure = any(c in {"needle", "pointy"} for c in driver_clusters) or any(lbl in driver_labels for lbl in {"regular-3-gon", "segment", "regular-8-gon"}) or contact_summary == "sparse"
    broad_pressure = any(c in {"broad", "round"} for c in driver_clusters) or any(lbl in driver_labels for lbl in {"regular-4-gon", "orbiform-stub", "disk-half", "regular-5-gon", "regular-6-gon"}) or contact_summary in {"mixed", "locked"}
    mixed_pressure = len(set(driver_clusters)) >= 2 or len(driver_labels) >= 2 or (pointy_pressure and broad_pressure)
    fallback = []
    if pointy_pressure:
        fallback.extend([
            dict(TARGETED_MOVE_FALLBACK_SPECS["pointy_rounding"]),
            dict(TARGETED_MOVE_FALLBACK_SPECS["pointy_cut"]),
        ])
    if broad_pressure:
        fallback.append(dict(TARGETED_MOVE_FALLBACK_SPECS["broad_rounding"]))
    if mixed_pressure or contact_summary == "mixed":
        fallback.append(dict(TARGETED_MOVE_FALLBACK_SPECS["mixed_rounding"]))
    path = "deprecated-cluster-contact-fallback"
    out = []
    for spec in fallback:
        spec2 = dict(spec)
        spec2.setdefault("source", path)
        spec2.setdefault("annotation_path", path)
        spec2.setdefault("score", _score_target_spec(spec2, ann=ann))
        out.append(spec2)
    out.sort(key=lambda d: (-float(d.get("score", 0.0)), str(d.get("label", ""))))
    return tuple(out), path


def _target_specs_from_annotation(ann: dict) -> tuple[dict, ...]:
    specs, _path = _target_specs_from_annotation_with_metadata(ann)
    return specs


def _apply_targeted_spec(state: dict, poly: ConvexPolygon2D, spec: dict) -> tuple[str, dict]:
    label = str(spec.get("label", "targeted-move"))
    kind = str(spec.get("kind", "rounding"))
    target = str(spec.get("target", "generic"))
    cut_amount = float(spec.get("cut", 0.04))
    radius = float(spec.get("radius", 0.015))
    source = str(spec.get("source", "ledger-derived"))
    severity = str(spec.get("severity", "mild"))
    cluster = str(spec.get("cluster", target))
    annotation_path = str(spec.get("annotation_path", source))
    if kind == "cut":
        med = apply_corner_cut(poly, cut_amount)
        return label, {
            **state,
            "polygon": med,
            "body": body_from_polygon(med),
            "corner_cuts": state["corner_cuts"] + [cut_amount],
            "target_hint": target,
            "target_cluster": cluster,
            "target_severity": severity,
            "target_source": source,
            "target_annotation_path": annotation_path,
        }
    cut, body, proxy = apply_arc_rounding(poly, cut_amount=cut_amount, radius=radius)
    return label, {
        **state,
        "polygon": proxy,
        "body": body,
        "corner_cuts": state["corner_cuts"] + [cut_amount],
        "arc_replacements": state["arc_replacements"] + [{"type": "rounded-minkowski", "cut": cut_amount, "radius": radius, "target": target, "source": source, "cluster": cluster, "severity": severity, "annotation_path": annotation_path}],
        "construction": {
            "kind": "targeted-rounded-minkowski",
            "target": target,
            "target_cluster": cluster,
            "target_severity": severity,
            "target_source": source,
            "target_annotation_path": annotation_path,
            "base_polygon": cut.name,
            "base_polygon_vertices": cut.vertices.tolist(),
            "rounded_radius": radius,
            "proxy_vertices": proxy.vertices.tolist(),
        },
    }


def witness_targeted_moves(proposal: Proposal):
    """Proposal-aware move generator that augments the base family with a scored witness-ledger suggestion set.

    The preferred path is to use move specs derived from the quick finite witness ledger. Older
    cluster/contact fallback fields remain supported for backward compatibility, but that path is
    deprecated and is tagged as ``deprecated-cluster-contact-fallback`` in the emitted spec metadata.
    """
    state = proposal.state
    ann = getattr(proposal, "annotations", {}) or {}
    poly = state_polygon_proxy(state)
    seen_labels: set[str] = set()
    for item in _yield_unique_moves(seen_labels, moves(state)):
        yield item

    target_specs = list(_target_specs_from_annotation(ann))
    limit = int(ann.get("witness_target_move_limit", 2))
    if limit > 0:
        target_specs = target_specs[:limit]
    targeted = []
    seen_target_states: set[object] = set()
    for spec in target_specs:
        item = _apply_targeted_spec(state, poly, spec)
        try:
            child_key = canonicalize_state(item[1])
        except Exception:
            child_key = None
        if child_key is not None and child_key in seen_target_states:
            continue
        if child_key is not None:
            seen_target_states.add(child_key)
        targeted.append(item)

    for item in _yield_unique_moves(seen_labels, targeted):
        yield item


def canonicalize_state(state: dict):
    return canonical_polygon_signature(state_polygon_proxy(state))


from ...core.certify import area_polygon
from ...search.proposal_search import bounded_search, Proposal
from .prescreen import prescreen_candidate_state
from .witnesses import segment_witness, probe_witness_library
from .witness_net import build_polygon_witness_net_scaffold


def proxy_score_state(state: dict) -> float:
    return -float(area_polygon(state_polygon_proxy(state).vertices))


def width_prescreen(width_lb: float = 1.0, n: int = 256, tol: float = 1e-9, dps: int = 60):
    def _screen(state: dict):
        return prescreen_candidate_state(state, width_lb=width_lb, n=n, tol=tol, dps=dps)
    return _screen


def structural_branch_key(state: dict) -> tuple[str, tuple[float, ...], int]:
    cuts = tuple(sorted(float(x) for x in state.get("corner_cuts", [])))
    arcs = int(len(state.get("arc_replacements", [])))
    if cuts:
        return ("cuts", cuts, arcs)
    return ("seed", tuple(), arcs)


def trim_parameter_region_key(state: dict) -> tuple[str, str, int]:
    cuts = [float(x) for x in state.get("corner_cuts", [])]
    arcs = int(len(state.get("arc_replacements", [])))
    if not cuts:
        return ("seed", "seed", arcs)

    total_cut = float(sum(cuts))
    max_cut = float(max(cuts))
    if max_cut >= 0.25 or total_cut >= 0.25:
        region = "aggressive"
    elif total_cut >= 0.06:
        region = "heavy"
    elif total_cut >= 0.02:
        region = "moderate"
    else:
        region = "light"
    return ("trim-region", region, arcs)


def proposal_diversity_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    if "support_signature_key" in ann:
        return tuple(ann["support_signature_key"])
    return support_signature_key(proposal.state)


def proposal_contact_diversity_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    if "contact_signature_key" in ann:
        return tuple(ann["contact_signature_key"])
    return contact_probe_library_key(proposal.state)


def _proposal_screen_slack(proposal: Proposal) -> float:
    details = proposal.screen_details or {}
    try:
        return float(details.get("certified_lower_width", 0.0)) - float(details.get("required_width", 0.0))
    except Exception:
        return 0.0


def proposal_contact_priority_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    card = int(ann.get("contact_cardinality", 0))
    method = str(ann.get("contact_verification_method", ""))
    probe_key_count = int(ann.get("contact_probe_key_count", 1))
    algebraic_probe_count = int(ann.get("contact_algebraic_probe_count", 0))
    contact_bonus = float(card) + 0.5 * float(probe_key_count) + 0.25 * float(algebraic_probe_count)
    if method == "algebraic-solve":
        contact_bonus += 0.25
    return (
        _proposal_screen_slack(proposal),
        contact_bonus,
        float(proposal.score),
        -float(len(proposal.move_history)),
    )


def proposal_hybrid_diversity_key(proposal: Proposal):
    return (
        "hybrid-structure",
        tuple(proposal_diversity_key(proposal)),
        tuple(proposal_contact_diversity_key(proposal)),
    )


def proposal_hybrid_priority_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    card = int(ann.get("contact_cardinality", 0))
    method = str(ann.get("contact_verification_method", ""))
    probe_key_count = int(ann.get("contact_probe_key_count", 1))
    algebraic_probe_count = int(ann.get("contact_algebraic_probe_count", 0))
    contact_bonus = float(card) + 0.5 * float(probe_key_count) + 0.25 * float(algebraic_probe_count)
    if method == "algebraic-solve":
        contact_bonus += 0.25
    support_shape = 0.0
    support_key = ann.get("support_signature_key")
    if support_key and len(support_key) >= 3:
        try:
            support_shape = 1.0e-3 * float(support_key[2])
        except Exception:
            support_shape = 0.0
    return (
        _proposal_screen_slack(proposal),
        contact_bonus,
        support_shape,
        float(proposal.score),
        -float(len(proposal.move_history)),
    )


def quick_witness_net_metrics(
    state: dict,
    *,
    net=None,
    max_vertices: int = 4,
    include_reduced_family: bool = False,
    fit_kwargs: dict | None = None,
    tol: float = 1.0e-9,
):
    if net is None:
        net = build_polygon_witness_net_scaffold(max_vertices=max_vertices, include_reduced_family=include_reduced_family)
    container = body_from_state(state)
    fit_kwargs = dict(fit_kwargs or {})
    use_interval_refinement = bool(fit_kwargs.pop("use_interval_refinement", False))
    angle_steps = int(fit_kwargs.pop("angle_steps", QUICK_WITNESS_BASE_ANGLE_STEPS))
    cert_n = int(fit_kwargs.pop("cert_n", max(24, angle_steps * 2)))
    adaptive_angle_steps = int(fit_kwargs.pop("adaptive_angle_steps", max(angle_steps, QUICK_WITNESS_ADAPTIVE_ANGLE_STEPS)))
    adaptive_margin_threshold = float(fit_kwargs.pop("adaptive_margin_threshold", QUICK_WITNESS_ADAPTIVE_MARGIN_THRESHOLD))
    passed_labels = []
    failed_labels = []
    passed_clusters = []
    failed_clusters = []
    witness_results = []
    margin_buckets = []
    adaptive_refit_count = 0
    for label, poly in net.witnesses:
        witness = body_from_polygon(poly)
        witness.name = str(label)
        fit = fit_body_in_body_support_2d(
            container,
            witness,
            angle_steps=angle_steps,
            cert_n=cert_n,
            use_interval_refinement=use_interval_refinement,
            **fit_kwargs,
        )
        used_angle_steps, used_cert_n, needs_refit = _quick_witness_fit_policy(
            fit.sampled_margin,
            base_angle_steps=angle_steps,
            cert_n=cert_n,
            adaptive_angle_steps=adaptive_angle_steps,
            adaptive_margin_threshold=adaptive_margin_threshold,
        )
        if needs_refit:
            adaptive_refit_count += 1
            fit = fit_body_in_body_support_2d(
                container,
                witness,
                angle_steps=used_angle_steps,
                cert_n=used_cert_n,
                use_interval_refinement=use_interval_refinement,
                **fit_kwargs,
            )
        passed = float(fit.sampled_margin) >= -float(tol)
        cluster = _witness_shape_cluster(poly)
        bucket = int(max(-50, min(200, round(float(fit.sampled_margin) * 20.0))))
        margin_buckets.append(bucket)
        if passed:
            passed_labels.append(str(label))
            passed_clusters.append(cluster)
        else:
            failed_labels.append(str(label))
            failed_clusters.append(cluster)
        witness_results.append({
            "label": str(label),
            "cluster": str(cluster),
            "passed": bool(passed),
            "sampled_margin": float(fit.sampled_margin),
            "rotation": float(fit.rotation),
            "angle_steps_used": int(used_angle_steps),
            "adaptive_refit": bool(needs_refit),
        })
    weakest_recs = sorted(witness_results, key=lambda r: float(r["sampled_margin"]))[:3]
    weakest = tuple(str(rec["label"]) for rec in weakest_recs)
    weakest_clusters = tuple(dict.fromkeys(str(rec["cluster"]) for rec in weakest_recs))
    low_margin_clusters = tuple(dict.fromkeys(str(rec["cluster"]) for rec in weakest_recs if float(rec["sampled_margin"]) <= 0.10)) or weakest_clusters
    cluster_stats = _ledger_cluster_stats(tuple(witness_results))
    return {
        "signal_mode": "quick-fit",
        "witness_count": int(len(net.witnesses)),
        "passed_witness_count": int(len(passed_labels)),
        "failed_witness_count": int(len(failed_labels)),
        "all_passed": bool(len(failed_labels) == 0),
        "failed_labels": tuple(failed_labels),
        "passed_labels": tuple(passed_labels),
        "failed_clusters": tuple(dict.fromkeys(failed_clusters)),
        "passed_clusters": tuple(dict.fromkeys(passed_clusters)),
        "weakest_labels": weakest,
        "weakest_clusters": weakest_clusters,
        "low_margin_clusters": low_margin_clusters,
        "cluster_stats": cluster_stats,
        "driver_clusters": tuple(stat["cluster"] for stat in cluster_stats[:2]),
        "hausdorff_resolution": float(net.hausdorff_resolution),
        "coverage_status": net.coverage_certificate.get("status"),
        "margin_signature": tuple(margin_buckets),
        "min_margin_bucket": int(min(margin_buckets) if margin_buckets else 0),
        "adaptive_refit_count": int(adaptive_refit_count),
        "base_angle_steps": int(angle_steps),
        "adaptive_angle_steps": int(adaptive_angle_steps),
        "adaptive_margin_threshold": float(adaptive_margin_threshold),
        "max_angle_steps_used": int(max((int(rec.get("angle_steps_used", angle_steps)) for rec in witness_results), default=int(angle_steps))),
        "witness_results": tuple(witness_results),
    }


def quick_witness_net_key(metrics: dict, *, max_failed_labels: int = 3, max_margin_terms: int = 3) -> tuple:
    failed = tuple(sorted(str(x) for x in metrics.get("failed_labels", ()))[: max(0, int(max_failed_labels))])
    margin_sig = tuple(int(x) for x in metrics.get("margin_signature", ())[: max(0, int(max_margin_terms))])
    return (
        "witness-net-quick",
        int(metrics.get("witness_count", 0)),
        int(metrics.get("passed_witness_count", 0)),
        int(bool(metrics.get("all_passed", False))),
        int(metrics.get("min_margin_bucket", 0)),
        *margin_sig,
        *failed,
    )


def _derive_target_move_specs_from_metrics(metrics: dict, *, contact_summary: str) -> tuple[dict, ...]:
    stats = tuple(dict(x) for x in metrics.get("cluster_stats", ()))
    if not stats:
        return tuple()
    specs = []
    for stat in stats[:2]:
        cluster = str(stat.get("cluster", "unknown"))
        severity = str(stat.get("severity", "mild"))
        min_margin = float(stat.get("min_margin", 0.0))
        cluster_pressure = float(stat.get("pressure", 0.0))
        cut = float(TARGETED_MOVE_DEFAULT_CUT_BY_SEVERITY.get(severity, TARGETED_MOVE_DEFAULT_CUT_BY_SEVERITY["mild"]))
        if cluster in {"needle", "pointy"}:
            radius = float(TARGETED_MOVE_TRIANGLE_RADIUS_BY_SEVERITY.get(severity, TARGETED_MOVE_TRIANGLE_RADIUS_BY_SEVERITY["mild"]))
            specs.append({
                "label": "targeted-triangle-rounding",
                "kind": "rounding",
                "target": "triangle",
                "cluster": cluster,
                "severity": severity,
                "cut": cut,
                "radius": radius,
                "source": "witness-ledger",
                "annotation_path": "ledger-specs",
                "parameter_policy": "empirical-defaults",
                "pressure": cluster_pressure,
            })
            if severity in {"mild", "moderate", "severe"}:
                specs.append({
                    "label": "targeted-triangle-cut",
                    "kind": "cut",
                    "target": "triangle",
                    "cluster": cluster,
                    "severity": severity,
                    "cut": max(cut, 0.045 if severity != "safe" else 0.03),
                    "source": "witness-ledger",
                    "annotation_path": "ledger-specs",
                    "parameter_policy": "empirical-defaults",
                    "pressure": cluster_pressure,
                })
        elif cluster in {"broad", "round"}:
            radius = float(TARGETED_MOVE_SQUARE_RADIUS_BY_CLUSTER.get(cluster, 0.012))
            if severity in {"moderate", "severe"}:
                radius += 0.002
            specs.append({
                "label": "targeted-square-rounding",
                "kind": "rounding",
                "target": "square",
                "cluster": cluster,
                "severity": severity,
                "cut": max(cut, 0.05),
                "radius": radius,
                "source": "witness-ledger",
                "annotation_path": "ledger-specs",
                "parameter_policy": "empirical-defaults",
                "pressure": cluster_pressure,
            })
        if min_margin < -0.05 or contact_summary in {"mixed", "locked"}:
            specs.append({
                "label": "targeted-net-heavy-rounding",
                "kind": "rounding",
                "target": "net-heavy",
                "cluster": cluster,
                "severity": severity,
                "cut": max(0.10, cut + 0.02),
                "radius": float(TARGETED_MOVE_NET_HEAVY_RADIUS_BY_SEVERITY.get(severity, TARGETED_MOVE_NET_HEAVY_RADIUS_BY_SEVERITY["mild"])),
                "source": "witness-ledger",
                "annotation_path": "ledger-specs",
                "parameter_policy": "empirical-defaults",
                "pressure": cluster_pressure,
            })
    # de-duplicate while preserving order, then attach suggestion scores
    seen = set()
    out = []
    for spec in specs:
        key = (spec.get("label"), spec.get("target"), spec.get("cluster"), round(float(spec.get("cut", 0.0)), 4), round(float(spec.get("radius", 0.0)), 4))
        if key in seen:
            continue
        seen.add(key)
        spec2 = dict(spec)
        spec2["score"] = _score_target_spec(spec2, cluster_stats=stats)
        out.append(spec2)
    out.sort(key=lambda d: (-float(d.get("score", 0.0)), str(d.get("label", ""))))
    return tuple(out)


def proposal_witness_target_diversity_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    labels = tuple(str(x) for x in ann.get("witness_target_suggested_labels", ()))
    targets = tuple(str(x) for x in ann.get("witness_target_suggested_targets", ()))
    bucket = int(ann.get("witness_target_score_bucket", 0))
    signature = tuple(int(x) for x in ann.get("witness_target_score_signature", ()))
    active_target = str(getattr(proposal, "state", {}).get("target_hint", ""))
    active_path = str(getattr(proposal, "state", {}).get("target_annotation_path", ""))
    active_label = ""
    if proposal.move_history:
        tail = str(proposal.move_history[-1])
        if tail.startswith("targeted-"):
            active_label = tail
    return (
        "witness-target-signal",
        bucket,
        *signature,
        active_target,
        active_path,
        active_label,
        *targets,
        *labels[:2],
    )


def proposal_witness_net_diversity_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    if "witness_net_key" in ann:
        return tuple(ann["witness_net_key"])
    return ("witness-net",)


def proposal_witness_net_priority_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    pass_count = int(ann.get("witness_net_passed_witness_count", 0))
    all_passed = int(bool(ann.get("witness_net_all_passed", False)))
    fail_penalty = -int(ann.get("witness_net_failed_witness_count", 0))
    min_margin_bucket = int(ann.get("witness_net_min_margin_bucket", 0))
    target_max_score = float(ann.get("witness_target_max_score", 0.0))
    target_total_score = float(ann.get("witness_target_total_score", 0.0))
    return (
        _proposal_screen_slack(proposal),
        all_passed,
        pass_count,
        min_margin_bucket,
        target_max_score,
        target_total_score,
        fail_penalty,
        float(proposal.score),
        -float(len(proposal.move_history)),
    )


def proposal_hybrid_witness_net_diversity_key(proposal: Proposal):
    return (
        "hybrid-witness-net",
        tuple(proposal_diversity_key(proposal)),
        tuple(proposal_witness_net_diversity_key(proposal)),
    )


def proposal_hybrid_witness_net_priority_key(proposal: Proposal):
    ann = getattr(proposal, "annotations", {}) or {}
    pass_count = int(ann.get("witness_net_passed_witness_count", 0))
    all_passed = int(bool(ann.get("witness_net_all_passed", False)))
    fail_penalty = -int(ann.get("witness_net_failed_witness_count", 0))
    min_margin_bucket = int(ann.get("witness_net_min_margin_bucket", 0))
    target_max_score = float(ann.get("witness_target_max_score", 0.0))
    target_total_score = float(ann.get("witness_target_total_score", 0.0))
    support_shape = 0.0
    support_key = ann.get("support_signature_key")
    if support_key and len(support_key) >= 3:
        try:
            support_shape = 1.0e-3 * float(support_key[2])
        except Exception:
            support_shape = 0.0
    return (
        _proposal_screen_slack(proposal),
        all_passed,
        pass_count,
        min_margin_bucket,
        target_max_score,
        target_total_score,
        fail_penalty,
        support_shape,
        float(proposal.score),
        -float(len(proposal.move_history)),
    )


def make_witness_net_structure_annotator(
    *,
    net=None,
    max_vertices: int = 4,
    include_reduced_family: bool = False,
    refine_kwargs: dict | None = None,
    targeted_move_limit: int = 2,
):
    cache: dict[object, dict] = {}
    if net is None:
        net = build_polygon_witness_net_scaffold(max_vertices=max_vertices, include_reduced_family=include_reduced_family)

    refine_settings = dict(refine_kwargs or {})

    def _annotate(proposal: Proposal):
        key = proposal.canonical_key if proposal.canonical_key is not None else canonicalize_state(proposal.state)
        if key in cache:
            return dict(cache[key])
        metrics = quick_witness_net_metrics(
            proposal.state,
            net=net,
            fit_kwargs=refine_settings,
        )
        witness_key = quick_witness_net_key(metrics)
        support_key = support_signature_key(proposal.state)
        contact_metrics = contact_probe_library_metrics(
            proposal.state,
            witness_names=("segment", "orbiform-stub"),
            angle_steps=24,
            sample_count=48,
            direction_buckets=12,
        )
        contact_summary = _contact_target_summary_from_metrics(contact_metrics)
        target_specs = _derive_target_move_specs_from_metrics(metrics, contact_summary=contact_summary)
        target_score_summary = _target_score_summary_from_specs(target_specs)
        ann = {
            "support_signature_key": tuple(support_key),
            "witness_net_key": tuple(witness_key),
            "witness_net_signal_mode": str(metrics.get("signal_mode", "quick-fit")),
            "witness_net_witness_count": int(metrics.get("witness_count", 0)),
            "witness_net_passed_witness_count": int(metrics.get("passed_witness_count", 0)),
            "witness_net_failed_witness_count": int(metrics.get("failed_witness_count", 0)),
            "witness_net_all_passed": bool(metrics.get("all_passed", False)),
            "witness_net_failed_labels": tuple(metrics.get("failed_labels", ())),
            "witness_net_passed_labels": tuple(metrics.get("passed_labels", ())),
            "witness_net_failed_clusters": tuple(metrics.get("failed_clusters", ())),
            "witness_net_passed_clusters": tuple(metrics.get("passed_clusters", ())),
            "witness_net_weakest_labels": tuple(metrics.get("weakest_labels", ())),
            "witness_net_weakest_clusters": tuple(metrics.get("weakest_clusters", ())),
            "witness_net_low_margin_clusters": tuple(metrics.get("low_margin_clusters", ())),
            "witness_net_cluster_stats": tuple(metrics.get("cluster_stats", ())),
            "witness_net_driver_clusters": tuple(metrics.get("driver_clusters", ())),
            "witness_net_margin_signature": tuple(metrics.get("margin_signature", ())),
            "witness_net_min_margin_bucket": int(metrics.get("min_margin_bucket", 0)),
            "witness_net_coverage_status": metrics.get("coverage_status"),
            "witness_net_hausdorff_resolution": float(metrics.get("hausdorff_resolution", 0.0)),
            "witness_target_contact_summary": contact_summary,
            "witness_target_contact_total_cardinality": int(contact_metrics.get("total_contact_cardinality", 0)),
            "witness_target_contact_probe_key_count": int(contact_metrics.get("probe_key_count", 0)),
            "witness_target_contact_algebraic_probe_count": int(contact_metrics.get("algebraic_probe_count", 0)),
            "witness_target_move_specs": tuple(target_specs),
            "witness_target_move_source": "witness-ledger",
            "witness_target_annotation_path": "ledger-specs",
            "witness_target_move_limit": int(targeted_move_limit),
            "witness_target_parameter_policy": "empirical-defaults",
            "witness_target_cluster_thresholds": {
                "needle_area_ratio_max": float(WITNESS_CLUSTER_NEEDLE_AREA_RATIO_MAX),
                "pointy_area_ratio_max": float(WITNESS_CLUSTER_POINTY_AREA_RATIO_MAX),
                "round_area_ratio_min": float(WITNESS_CLUSTER_ROUND_AREA_RATIO_MIN),
                "needle_max_vertices": int(WITNESS_CLUSTER_NEEDLE_MAX_VERTICES),
                "pointy_max_vertices": int(WITNESS_CLUSTER_POINTY_MAX_VERTICES),
                "round_min_vertices": int(WITNESS_CLUSTER_ROUND_MIN_VERTICES),
            },
            "witness_target_default_cut_by_severity": dict(TARGETED_MOVE_DEFAULT_CUT_BY_SEVERITY),
            "witness_net_base_angle_steps": int(metrics.get("base_angle_steps", QUICK_WITNESS_BASE_ANGLE_STEPS)),
            "witness_net_adaptive_angle_steps": int(metrics.get("adaptive_angle_steps", QUICK_WITNESS_ADAPTIVE_ANGLE_STEPS)),
            "witness_net_adaptive_margin_threshold": float(metrics.get("adaptive_margin_threshold", QUICK_WITNESS_ADAPTIVE_MARGIN_THRESHOLD)),
            "witness_net_adaptive_refit_count": int(metrics.get("adaptive_refit_count", 0)),
            "witness_net_max_angle_steps_used": int(metrics.get("max_angle_steps_used", QUICK_WITNESS_BASE_ANGLE_STEPS)),
            "witness_target_max_score": float(target_score_summary.get("max_score", 0.0)),
            "witness_target_total_score": float(target_score_summary.get("total_score", 0.0)),
            "witness_target_score_bucket": int(target_score_summary.get("score_bucket", 0)),
            "witness_target_score_signature": tuple(target_score_summary.get("score_signature", ())),
            "witness_target_suggested_targets": tuple(target_score_summary.get("suggested_targets", ())),
            "witness_target_suggested_labels": tuple(dict.fromkeys(str(spec.get("label", "")) for spec in target_specs[: max(0, int(targeted_move_limit))])),
        }
        cache[key] = dict(ann)
        return ann

    return _annotate


def make_contact_structure_annotator(
    *,
    witness_name: str = "segment",
    witness_names: tuple[str, ...] = DEFAULT_CONTACT_PROBE_NAMES,
    angle_steps: int = 48,
    sample_count: int = 96,
    direction_buckets: int = 24,
):
    cache: dict[object, dict] = {}

    def _annotate(proposal: Proposal):
        key = proposal.canonical_key if proposal.canonical_key is not None else canonicalize_state(proposal.state)
        if key in cache:
            return dict(cache[key])
        support_key = support_signature_key(proposal.state)
        primary = contact_signature_metrics(
            proposal.state,
            witness_name=witness_name,
            angle_steps=angle_steps,
            sample_count=sample_count,
            direction_buckets=direction_buckets,
        )
        probe_metrics = contact_probe_library_metrics(
            proposal.state,
            witness_names=witness_names,
            angle_steps=angle_steps,
            sample_count=sample_count,
            direction_buckets=direction_buckets,
        )
        ann = {
            "support_signature_key": tuple(support_key),
            "contact_signature_key": _contact_probe_library_key_from_metrics(probe_metrics),
            "contact_primary_signature_key": _contact_signature_key_from_metrics(primary),
            "contact_cardinality": int(primary["contact_cardinality"]),
            "contact_gap_signature": tuple(primary["gap_signature"]),
            "contact_direction_buckets": tuple(primary["direction_buckets"]),
            "contact_margin": float(primary["margin"]),
            "contact_witness_name": primary["witness_name"],
            "contact_verification_method": primary["verification_method"],
            "contact_lp_method": primary.get("lp_method"),
            "contact_probe_library": tuple(probe_metrics["witness_names"]),
            "contact_probe_signature": tuple(probe_metrics["probe_signature"]),
            "contact_probe_key_count": int(probe_metrics["probe_key_count"]),
            "contact_total_cardinality": int(probe_metrics["total_contact_cardinality"]),
            "contact_algebraic_probe_count": int(probe_metrics["algebraic_probe_count"]),
        }
        cache[key] = dict(ann)
        return ann

    return _annotate


def search_with_width_prescreen(
    seed_state: dict | None = None,
    *,
    depth: int = 2,
    width_lb: float = 1.0,
    n: int = 256,
    tol: float = 1e-9,
    dps: int = 60,
    include_rejected: bool = False,
    beam_width: int | None = None,
    beam_policy: str = "greedy",
    beam_diversity_reserve: int = 0,
    structure_signal: str | None = None,
    contact_probe_names: tuple[str, ...] = DEFAULT_CONTACT_PROBE_NAMES,
    witness_net_max_vertices: int = 4,
    witness_net_include_reduced_family: bool = False,
    witness_net_refine_kwargs: dict | None = None,
    enable_witness_targeted_moves: bool = True,
    targeted_move_limit: int = 2,
):
    if seed_state is None:
        seed_state = pal_seed()
    annotate = None
    priority_key = None
    beam_diversity_key = proposal_diversity_key
    beam_diversity_keys = None
    proposal_move_generator = None
    if structure_signal in {"contact", "hybrid"}:
        annotate = make_contact_structure_annotator(witness_names=contact_probe_names)
    elif structure_signal in {"witness-net", "hybrid-witness-net"}:
        annotate = make_witness_net_structure_annotator(
            max_vertices=witness_net_max_vertices,
            include_reduced_family=witness_net_include_reduced_family,
            refine_kwargs=witness_net_refine_kwargs,
            targeted_move_limit=targeted_move_limit,
        )
    if structure_signal == "contact":
        priority_key = proposal_contact_priority_key
        beam_diversity_key = proposal_contact_diversity_key if beam_policy == "diversified" else None
    elif structure_signal == "hybrid":
        priority_key = proposal_hybrid_priority_key
        beam_diversity_key = None
        beam_diversity_keys = (proposal_diversity_key, proposal_contact_diversity_key) if beam_policy == "diversified" else None
    elif structure_signal == "witness-net":
        priority_key = proposal_witness_net_priority_key
        if beam_policy == "diversified":
            beam_diversity_key = None
            beam_diversity_keys = (proposal_witness_net_diversity_key, proposal_witness_target_diversity_key)
        else:
            beam_diversity_key = None
            beam_diversity_keys = None
    elif structure_signal == "hybrid-witness-net":
        priority_key = proposal_hybrid_witness_net_priority_key
        beam_diversity_key = None
        beam_diversity_keys = (proposal_diversity_key, proposal_witness_net_diversity_key, proposal_witness_target_diversity_key) if beam_policy == "diversified" else None

    if enable_witness_targeted_moves and structure_signal in {"witness-net", "hybrid-witness-net"}:
        proposal_move_generator = witness_targeted_moves

    return bounded_search(
        seed_state,
        moves,
        proxy_score_state,
        proposal_move_generator=proposal_move_generator,
        depth=depth,
        canonicalize=canonicalize_state,
        screen=width_prescreen(width_lb=width_lb, n=n, tol=tol, dps=dps),
        include_rejected=include_rejected,
        priority_key=priority_key,
        annotate=annotate,
        beam_width=beam_width,
        beam_policy=beam_policy,
        beam_diversity_key=beam_diversity_key,
        beam_diversity_keys=beam_diversity_keys,
        beam_diversity_reserve=beam_diversity_reserve,
        deduplicate_before_screen=True,
    )
