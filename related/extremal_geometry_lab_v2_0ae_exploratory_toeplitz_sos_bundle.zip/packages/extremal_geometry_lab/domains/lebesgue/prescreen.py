from __future__ import annotations

from dataclasses import dataclass, field

from ...core.prescreen import WidthCertificate2D, certified_width_prescreen_2d


@dataclass(slots=True)
class LebesguePrescreenResult:
    passed: bool
    reason: str
    width_certificate: WidthCertificate2D
    details: dict = field(default_factory=dict)


def prescreen_candidate_state(
    state: dict,
    *,
    width_lb: float = 1.0,
    n: int = 256,
    tol: float = 1e-9,
    dps: int = 60,
) -> LebesguePrescreenResult:
    from .family import body_from_state, state_polygon_proxy

    poly = state_polygon_proxy(state)
    body = body_from_state(state)
    cert = certified_width_prescreen_2d(body, width_lb=width_lb, n=n, tol=tol, dps=dps)
    return LebesguePrescreenResult(
        passed=bool(cert.passed),
        reason="width-ok" if cert.passed else "width-violated",
        width_certificate=cert,
        details={
            "polygon_name": poly.name,
            "required_width": float(cert.required_width),
            "certified_lower_width": float(cert.certified_lower_width),
            "worst_cell": cert.details.get("worst_cell"),
            "support_methods": cert.details.get("methods"),
            "body_name": body.name,
        },
    )
