from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Sequence
import math
import numpy as np

from .witness_net import build_polygon_witness_net_scaffold
from .family import body_from_state, quick_witness_net_metrics
from ...core.support import ConvexBody2D


@dataclass(slots=True)
class NerveComplex:
    """Sampled co-failure nerve for a finite witness family.

    This is a diagnostic object only. It records which witnesses are observed to
    fail together across a *sampled* family of candidate containers. It does not
    certify finite-witness completeness.
    """

    vertices: list[str]
    edges: list[tuple[int, int]]
    triangles: list[tuple[int, int, int]]
    betti_0: int
    betti_1: int
    euler_characteristic: int
    sample_count: int
    nonempty_failure_samples: int
    max_failure_cardinality: int
    witness_failure_counts: dict[str, int] = field(default_factory=dict)
    details: dict = field(default_factory=dict)


@dataclass(slots=True)
class WidthHardnessSummary:
    """Width-based diagnostic for witness hardness.

    The intent is practical rather than theorem-heavy: bodies with very small
    width spread are harder to distinguish using width-driven prescreens.
    """

    min_width: float
    max_width: float
    width_spread: float
    thin_direction_count: int
    thin_direction_clusters: tuple[float, ...]
    nearly_constant_width: bool
    details: dict = field(default_factory=dict)



def _gf2_rank(matrix: np.ndarray) -> int:
    mat = np.asarray(matrix, dtype=np.uint8).copy() % 2
    rows, cols = mat.shape
    rank = 0
    pivot_row = 0
    for col in range(cols):
        if pivot_row >= rows:
            break
        pivot = None
        for r in range(pivot_row, rows):
            if mat[r, col]:
                pivot = r
                break
        if pivot is None:
            continue
        if pivot != pivot_row:
            mat[[pivot_row, pivot]] = mat[[pivot, pivot_row]]
        for r in range(rows):
            if r != pivot_row and mat[r, col]:
                mat[r, :] ^= mat[pivot_row, :]
        rank += 1
        pivot_row += 1
    return int(rank)



def nerve_complex_from_failure_sets(
    vertices: Sequence[str],
    failure_sets: Iterable[Iterable[int]],
    *,
    sample_details: dict | None = None,
) -> NerveComplex:
    failure_list = [tuple(sorted({int(i) for i in failures})) for failures in failure_sets]
    vertex_names = [str(v) for v in vertices]
    edge_set: set[tuple[int, int]] = set()
    triangle_set: set[tuple[int, int, int]] = set()
    witness_failure_counts = {name: 0 for name in vertex_names}
    nonempty_failure_samples = 0
    max_failure_cardinality = 0

    for failures in failure_list:
        if failures:
            nonempty_failure_samples += 1
        max_failure_cardinality = max(max_failure_cardinality, len(failures))
        for i in failures:
            if 0 <= i < len(vertex_names):
                witness_failure_counts[vertex_names[i]] += 1
        for a in range(len(failures)):
            for b in range(a + 1, len(failures)):
                edge_set.add((failures[a], failures[b]))
        for a in range(len(failures)):
            for b in range(a + 1, len(failures)):
                for c in range(b + 1, len(failures)):
                    triangle_set.add((failures[a], failures[b], failures[c]))

    edges = sorted(edge_set)
    triangles = sorted(triangle_set)
    n_vertices = len(vertex_names)
    n_edges = len(edges)
    n_triangles = len(triangles)

    if n_edges == 0:
        betti_0 = n_vertices
        betti_1 = 0
    else:
        d1 = np.zeros((n_vertices, n_edges), dtype=np.uint8)
        edge_index = {edge: idx for idx, edge in enumerate(edges)}
        for j, (a, b) in enumerate(edges):
            d1[a, j] = 1
            d1[b, j] = 1
        d2 = np.zeros((n_edges, n_triangles), dtype=np.uint8)
        for k, (a, b, c) in enumerate(triangles):
            for edge in ((a, b), (a, c), (b, c)):
                idx = edge_index.get(tuple(sorted(edge)))
                if idx is not None:
                    d2[idx, k] = 1
        rank_d1 = _gf2_rank(d1)
        rank_d2 = _gf2_rank(d2) if n_triangles > 0 else 0
        betti_0 = max(0, n_vertices - rank_d1)
        betti_1 = max(0, n_edges - rank_d1 - rank_d2)

    return NerveComplex(
        vertices=vertex_names,
        edges=edges,
        triangles=triangles,
        betti_0=int(betti_0),
        betti_1=int(betti_1),
        euler_characteristic=int(n_vertices - n_edges + n_triangles),
        sample_count=int(len(failure_list)),
        nonempty_failure_samples=int(nonempty_failure_samples),
        max_failure_cardinality=int(max_failure_cardinality),
        witness_failure_counts=witness_failure_counts,
        details=dict(sample_details or {}),
    )



def compute_state_witness_cofailure_nerve(
    states: Sequence[dict],
    *,
    net=None,
    max_vertices: int = 4,
    include_reduced_family: bool = False,
    fit_kwargs: dict | None = None,
    tol: float = 1.0e-9,
) -> NerveComplex:
    if net is None:
        net = build_polygon_witness_net_scaffold(max_vertices=max_vertices, include_reduced_family=include_reduced_family)
    labels = [str(label) for label, _poly in net.witnesses]
    label_to_idx = {label: idx for idx, label in enumerate(labels)}
    failure_sets: list[tuple[int, ...]] = []
    state_rows: list[dict] = []
    for state_index, state in enumerate(states):
        metrics = quick_witness_net_metrics(
            state,
            net=net,
            max_vertices=max_vertices,
            include_reduced_family=include_reduced_family,
            fit_kwargs=fit_kwargs,
            tol=tol,
        )
        failed_labels = tuple(str(x) for x in metrics.get("failed_labels", ()))
        failure_sets.append(tuple(sorted(label_to_idx[label] for label in failed_labels if label in label_to_idx)))
        state_rows.append({
            "state_index": int(state_index),
            "failed_labels": failed_labels,
            "failed_count": int(len(failed_labels)),
            "passed_count": int(metrics.get("passed_witness_count", 0)),
            "all_passed": bool(metrics.get("all_passed", False)),
            "min_margin_bucket": int(metrics.get("min_margin_bucket", 0)),
        })
    return nerve_complex_from_failure_sets(
        labels,
        failure_sets,
        sample_details={
            "mode": "sampled-state-cofailure-nerve",
            "state_rows": state_rows,
            "coverage_certificate": dict(getattr(net, "coverage_certificate", {}) or {}),
            "hausdorff_resolution": float(getattr(net, "hausdorff_resolution", 0.0)),
        },
    )



def analyze_width_hardness(
    body: ConvexBody2D,
    *,
    n_samples: int = 360,
    cluster_tolerance: float = 3.0 * math.pi / 180.0,
    nearly_constant_threshold: float = 0.01,
) -> WidthHardnessSummary:
    angles = np.linspace(0.0, math.pi, max(16, int(n_samples)), endpoint=False)
    widths = np.array([float(body.width(float(theta))) for theta in angles], dtype=float)
    if widths.size == 0:
        return WidthHardnessSummary(0.0, 0.0, 0.0, 0, tuple(), True, details={"mode": "empty"})
    min_width = float(np.min(widths))
    max_width = float(np.max(widths))
    width_spread = float(max_width - min_width)
    tol = max(1.0e-9, 0.05 * max(width_spread, 1.0e-9))
    thin_angles = [float(angles[i]) for i, value in enumerate(widths) if value <= min_width + tol]
    clusters: list[float] = []
    for theta in thin_angles:
        if not clusters:
            clusters.append(theta)
            continue
        if abs(theta - clusters[-1]) <= float(cluster_tolerance):
            continue
        clusters.append(theta)
    return WidthHardnessSummary(
        min_width=min_width,
        max_width=max_width,
        width_spread=width_spread,
        thin_direction_count=int(len(thin_angles)),
        thin_direction_clusters=tuple(float(x) for x in clusters),
        nearly_constant_width=bool(width_spread <= float(nearly_constant_threshold)),
        details={
            "mode": "sampled-width-hardness",
            "n_samples": int(n_samples),
            "cluster_tolerance": float(cluster_tolerance),
            "nearly_constant_threshold": float(nearly_constant_threshold),
        },
    )


__all__ = [
    "NerveComplex",
    "WidthHardnessSummary",
    "nerve_complex_from_failure_sets",
    "compute_state_witness_cofailure_nerve",
    "analyze_width_hardness",
]
