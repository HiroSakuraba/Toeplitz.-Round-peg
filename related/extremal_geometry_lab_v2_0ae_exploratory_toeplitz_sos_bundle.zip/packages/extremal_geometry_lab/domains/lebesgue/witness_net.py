from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import math
import numpy as np

from ...core.geometry_types import ConvexPolygon2D
from ...core.support import body_from_polygon, ConvexBody2D
from ...certificates import export_witness_family_bundle, write_certificate_bundle
from ...certificates.formats import select_joint_feasible_box, rigid_motion_box_payload, coexistence_product_payload
from .family import regular_hexagon_circumradius, body_from_state
from .witnesses import reduced_witness_family


@dataclass(slots=True)
class WitnessNet:
    witnesses: list[tuple[str, ConvexPolygon2D]]
    hausdorff_resolution: float
    diameter_class: float
    coverage_certificate: dict = field(default_factory=dict)


def _normalize_polygon_to_diameter(poly: ConvexPolygon2D, *, target_diameter: float = 1.0, n: int = 256) -> ConvexPolygon2D:
    body = body_from_polygon(poly)
    prof = body.sample_support(n=int(n))
    vals = np.asarray(prof.values, dtype=float)
    half = len(vals) // 2
    if half <= 0:
        diam = 1.0
    else:
        diam = max(float(vals[i] + vals[(i + half) % len(vals)]) for i in range(half))
    scale = float(target_diameter) / max(float(diam), 1.0e-12)
    return ConvexPolygon2D(poly.vertices * scale, name=f"{poly.name}-diam{target_diameter:g}", metadata={**(poly.metadata or {}), "diameter_scale": scale})


def regular_ngon_diameter_one(n_sides: int) -> ConvexPolygon2D:
    theta = np.linspace(0.0, 2.0 * math.pi, int(n_sides), endpoint=False)
    verts = np.stack([0.5 * np.cos(theta), 0.5 * np.sin(theta)], axis=1)
    poly = ConvexPolygon2D(verts, name=f"regular-{int(n_sides)}-gon")
    return _normalize_polygon_to_diameter(poly, target_diameter=1.0)


def build_polygon_witness_net_scaffold(
    *,
    max_vertices: int = 9,
    include_reduced_family: bool = True,
) -> WitnessNet:
    witnesses: list[tuple[str, ConvexPolygon2D]] = []
    seen_names: set[str] = set()

    if include_reduced_family:
        for label, poly in reduced_witness_family():
            norm = _normalize_polygon_to_diameter(poly, target_diameter=1.0)
            if label not in seen_names:
                witnesses.append((label, norm))
                seen_names.add(label)

    for n_sides in range(3, max(3, int(max_vertices)) + 1):
        label = f"regular-{int(n_sides)}-gon"
        if label in seen_names:
            continue
        witnesses.append((label, regular_ngon_diameter_one(n_sides)))
        seen_names.add(label)

    pal = _normalize_polygon_to_diameter(regular_hexagon_circumradius(1.0), target_diameter=1.0)
    if "pal-seed" not in seen_names:
        witnesses.append(("pal-seed", pal))
        seen_names.add("pal-seed")

    resolution = (1.0 / math.sqrt(3.0)) * (1.0 - math.cos(math.pi / max(3, int(max_vertices))))
    return WitnessNet(
        witnesses=witnesses,
        hausdorff_resolution=float(resolution),
        diameter_class=1.0,
        coverage_certificate={
            "mode": "scaffold",
            "status": "incomplete-family",
            "method": "jung-plus-regular-polygon-scaffold",
            "max_vertices": int(max_vertices),
            "reduced_family_included": bool(include_reduced_family),
            "resolution_formula": "(1/sqrt(3)) * (1 - cos(pi / max_vertices))",
            "warning": "This is a finite witness-net scaffold, not a full epsilon-net theorem certificate.",
        },
    )


@dataclass(slots=True)
class WitnessNetScreenResult:
    passed: bool
    reason: str
    witness_count: int
    passed_witness_count: int
    failed_witness_count: int
    net: WitnessNet
    details: dict = field(default_factory=dict)
    witness_ledger: list[dict] = field(default_factory=list)


@dataclass(slots=True)
class WitnessNetMetrics:
    witness_count: int
    passed_witness_count: int
    failed_witness_count: int
    joint_certified: bool
    all_refinements_classified: bool
    net: WitnessNet
    witness_entries: list[dict] = field(default_factory=list)
    details: dict = field(default_factory=dict)


def _named_body(label: str, poly: ConvexPolygon2D) -> ConvexBody2D:
    body = body_from_polygon(poly)
    body.name = str(label)
    return body


def _normalize_refine_kwargs(refine_kwargs: dict | None) -> dict:
    out = dict(refine_kwargs or {})
    if 'initial_intervals' in out and 'initial_theta_intervals' not in out:
        out['initial_theta_intervals'] = out.pop('initial_intervals')
    return out


def witness_bodies_from_net(net: WitnessNet) -> list[ConvexBody2D]:
    return [_named_body(label, poly) for label, poly in net.witnesses]


def witness_net_metrics_for_state(
    state: dict,
    *,
    net: WitnessNet | None = None,
    max_vertices: int = 9,
    include_reduced_family: bool = True,
    refine_kwargs: dict | None = None,
) -> WitnessNetMetrics:
    from ...core.rigid_fit import refine_body_in_body_support_rigid_2d

    if net is None:
        net = build_polygon_witness_net_scaffold(
            max_vertices=max_vertices,
            include_reduced_family=include_reduced_family,
        )
    container = body_from_state(state)
    refine_kwargs = _normalize_refine_kwargs(refine_kwargs)
    witness_entries: list[dict] = []
    for idx, (label, poly) in enumerate(net.witnesses):
        witness = _named_body(label, poly)
        refinement = refine_body_in_body_support_rigid_2d(container, witness, **refine_kwargs)
        selected_box_index, selected_box = select_joint_feasible_box(refinement)
        witness_entries.append({
            "index": int(idx),
            "name": str(label),
            "has_certified_feasible_box": bool(refinement.has_certified_feasible_box),
            "classification_complete": bool(refinement.all_boxes_classified),
            "counts": {
                "certified_feasible_boxes": len(refinement.certified_feasible_boxes),
                "certified_infeasible_boxes": len(refinement.certified_infeasible_boxes),
                "unresolved_boxes": len(refinement.unresolved_boxes),
                "explored_boxes": len(refinement.explored_boxes),
            },
            "selected_box_index": None if selected_box_index is None else int(selected_box_index),
            "selected_box": None if selected_box is None else rigid_motion_box_payload(selected_box, index=selected_box_index),
            "bundle_path": f"witness_{idx:02d}.json",
        })
    coexistence = coexistence_product_payload(
        container_name=getattr(container, "name", "container"),
        witness_entries=witness_entries,
    )
    passed = sum(1 for rec in witness_entries if rec["has_certified_feasible_box"])
    total = len(witness_entries)
    failed = total - passed
    return WitnessNetMetrics(
        witness_count=int(total),
        passed_witness_count=int(passed),
        failed_witness_count=int(failed),
        joint_certified=bool(coexistence["joint_certified"]),
        all_refinements_classified=bool(coexistence["all_refinements_classified"]),
        net=net,
        witness_entries=witness_entries,
        details={
            "coverage_certificate": dict(net.coverage_certificate),
            "hausdorff_resolution": float(net.hausdorff_resolution),
            "diameter_class": float(net.diameter_class),
            "failed_labels": [rec["name"] for rec in witness_entries if not rec["has_certified_feasible_box"]],
            "passed_labels": [rec["name"] for rec in witness_entries if rec["has_certified_feasible_box"]],
            "coexistence": coexistence,
        },
    )


def witness_net_key_from_metrics(metrics: WitnessNetMetrics, *, max_failed_labels: int = 3) -> tuple:
    failed = tuple(sorted(str(x) for x in metrics.details.get("failed_labels", ()))[: max(0, int(max_failed_labels))])
    return (
        "witness-net",
        int(metrics.witness_count),
        int(metrics.passed_witness_count),
        int(metrics.joint_certified),
        int(metrics.all_refinements_classified),
        *failed,
    )


def witness_net_key_for_state(
    state: dict,
    *,
    net: WitnessNet | None = None,
    max_vertices: int = 9,
    include_reduced_family: bool = True,
    refine_kwargs: dict | None = None,
    max_failed_labels: int = 3,
) -> tuple:
    metrics = witness_net_metrics_for_state(
        state,
        net=net,
        max_vertices=max_vertices,
        include_reduced_family=include_reduced_family,
        refine_kwargs=refine_kwargs,
    )
    return witness_net_key_from_metrics(metrics, max_failed_labels=max_failed_labels)


def screen_candidate_state_against_witness_net(
    state: dict,
    *,
    net: WitnessNet | None = None,
    max_vertices: int = 9,
    include_reduced_family: bool = True,
    refine_kwargs: dict | None = None,
) -> WitnessNetScreenResult:
    metrics = witness_net_metrics_for_state(
        state,
        net=net,
        max_vertices=max_vertices,
        include_reduced_family=include_reduced_family,
        refine_kwargs=refine_kwargs,
    )
    ledger = []
    for rec in metrics.witness_entries:
        ledger.append({
            'index': int(rec['index']),
            'label': str(rec['name']),
            'polygon_name': str(rec['name']),
            'passed': bool(rec['has_certified_feasible_box']),
            'classification_complete': bool(rec['classification_complete']),
            'selected_box_index': rec['selected_box_index'],
            'counts': dict(rec['counts']),
        })
    return WitnessNetScreenResult(
        passed=bool(metrics.failed_witness_count == 0),
        reason='witness-net-pass' if metrics.failed_witness_count == 0 else 'witness-net-fail',
        witness_count=int(metrics.witness_count),
        passed_witness_count=int(metrics.passed_witness_count),
        failed_witness_count=int(metrics.failed_witness_count),
        net=metrics.net,
        witness_ledger=ledger,
        details={
            'coverage_certificate': dict(metrics.net.coverage_certificate),
            'hausdorff_resolution': float(metrics.net.hausdorff_resolution),
            'diameter_class': float(metrics.net.diameter_class),
            'passed_labels': list(metrics.details.get('passed_labels', ())),
            'failed_labels': list(metrics.details.get('failed_labels', ())),
            'joint_certified': bool(metrics.joint_certified),
            'all_refinements_classified': bool(metrics.all_refinements_classified),
        },
    )


def predicate_from_witness_net_scaffold(*, net: WitnessNet | None = None, max_vertices: int = 9, include_reduced_family: bool = True, refine_kwargs: dict | None = None):
    def _pred(candidate: dict):
        res = screen_candidate_state_against_witness_net(
            candidate,
            net=net,
            max_vertices=max_vertices,
            include_reduced_family=include_reduced_family,
            refine_kwargs=refine_kwargs,
        )
        return res.passed, res.reason, {
            'witness_count': int(res.witness_count),
            'passed_witness_count': int(res.passed_witness_count),
            'failed_witness_count': int(res.failed_witness_count),
            'hausdorff_resolution': float(res.net.hausdorff_resolution),
            'coverage_status': res.net.coverage_certificate.get('status'),
            'failed_labels': list(res.details.get('failed_labels', ())),
            'joint_certified': bool(res.details.get('joint_certified', False)),
            'all_refinements_classified': bool(res.details.get('all_refinements_classified', False)),
        }
    return _pred


def export_candidate_witness_net_bundle(
    base_dir: str | Path,
    *,
    state: dict,
    net: WitnessNet | None = None,
    max_vertices: int = 9,
    include_reduced_family: bool = True,
    refine_kwargs: dict | None = None,
    state_name: str = 'candidate',
) -> dict:
    base_dir = Path(base_dir)
    if net is None:
        net = build_polygon_witness_net_scaffold(
            max_vertices=max_vertices,
            include_reduced_family=include_reduced_family,
        )
    container = body_from_state(state)
    witnesses = witness_bodies_from_net(net)
    family_dir = base_dir / 'witness_family'
    summary = export_witness_family_bundle(
        family_dir,
        container=container,
        witnesses=witnesses,
        refine_kwargs=_normalize_refine_kwargs(refine_kwargs),
        per_witness_support_audit=True,
    )
    coexistence = family_dir / 'coexistence.json'
    machine = {
        'schema_version': 'lebesgue-witness-net-bridge.v1',
        'state_name': str(state_name),
        'container_name': container.name,
        'witness_count': int(len(witnesses)),
        'joint_certified': bool(summary['joint_certified']),
        'passed_witness_count': int(sum(1 for rec in summary['witnesses'] if rec['has_certified_feasible_box'])),
        'failed_witness_count': int(sum(1 for rec in summary['witnesses'] if not rec['has_certified_feasible_box'])),
        'coverage_certificate': dict(net.coverage_certificate),
        'hausdorff_resolution': float(net.hausdorff_resolution),
        'diameter_class': float(net.diameter_class),
        'witnesses': [
            {
                'index': int(rec['index']),
                'label': str(rec['name']),
                'has_certified_feasible_box': bool(rec['has_certified_feasible_box']),
                'classification_complete': bool(rec['classification_complete']),
                'bundle_path': str(rec['bundle_path']),
                'selected_box_index': rec['selected_box_index'],
            }
            for rec in summary['witnesses']
        ],
        'joint_coexistence_path': str(coexistence.relative_to(base_dir)),
        'warning': 'Finite normalized witness family screen only; incomplete-family witness-net scaffold.',
    }
    lines = [
        f'# Lebesgue witness-net bridge: {state_name}',
        '',
        f"- container: `{container.name}`",
        f"- witness count: `{len(witnesses)}`",
        f"- joint certified: `{summary['joint_certified']}`",
        f"- passed witnesses: `{sum(1 for rec in summary['witnesses'] if rec['has_certified_feasible_box'])}`",
        f"- failed witnesses: `{sum(1 for rec in summary['witnesses'] if not rec['has_certified_feasible_box'])}`",
        f"- Hausdorff resolution note: `{net.hausdorff_resolution}`",
        f"- coverage status: `{net.coverage_certificate.get('status')}`",
        '',
        'This is a finite normalized witness-family bridge from search to exact-screening. It is not a full epsilon-net theorem certificate.',
        '',
        '## Witness ledger',
        '',
    ]
    for rec in machine['witnesses']:
        lines.append(f"- {rec['index']:02d} `{rec['label']}`: feasible `{rec['has_certified_feasible_box']}`, complete `{rec['classification_complete']}`, bundle `{rec['bundle_path']}`")
    write_certificate_bundle(base_dir / 'summary', machine=machine, human_markdown='\n'.join(lines))
    return machine
