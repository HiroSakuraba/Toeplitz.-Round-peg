
"""Lebesgue witness families."""
from __future__ import annotations
import math
import numpy as np

from ...core.geometry_types import ConvexPolygon2D
from ...core.minkowski import centered_segment, sampled_disk


def segment_witness() -> ConvexPolygon2D:
    pts = centered_segment(1.0, 2)
    eps = 1e-6
    verts = np.array([[pts[0,0], -eps], [pts[1,0], -eps], [pts[1,0], eps], [pts[0,0], eps]], dtype=float)
    return ConvexPolygon2D(verts, name="unit-segment")


def orbiform_stub(n: int = 16) -> ConvexPolygon2D:
    theta = np.linspace(0, 2 * math.pi, n, endpoint=False)
    pts = np.stack([0.5 * np.cos(theta), 0.5 * np.sin(theta)], axis=1)
    return ConvexPolygon2D(pts, name="orbiform-stub")


def reduced_witness_family() -> list[tuple[str, ConvexPolygon2D]]:
    return probe_witness_library()


def probe_witness_library() -> list[tuple[str, ConvexPolygon2D]]:
    """Small contact-probe library for structure-aware search signals."""
    return [("segment", segment_witness()), ("orbiform-stub", orbiform_stub()), ("disk-half", sampled_disk(0.5, 24))]
