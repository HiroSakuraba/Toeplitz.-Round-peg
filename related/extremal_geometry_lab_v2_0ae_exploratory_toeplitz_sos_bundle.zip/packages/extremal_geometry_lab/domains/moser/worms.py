
"""Hard-worm generators and convex-cover witness helpers."""
from __future__ import annotations
import numpy as np

from ...core.geometry_types import Polyline2D, ConvexPolygon2D
from ...core.minkowski import polyline, polyline_tube, sampled_disk, minkowski_sum_polygons


def straight_worm() -> Polyline2D:
    return polyline([(-0.5, 0.0), (0.5, 0.0)])


def hook_worm() -> Polyline2D:
    return polyline([(-0.4, 0.0), (0.0, 0.0), (0.0, 0.6)])


def broken_worm() -> Polyline2D:
    return polyline([(-0.3, -0.1), (0.0, 0.0), (0.35, 0.15), (0.5, 0.4)])


def thickened_worm(worm: Polyline2D, radius: float = 0.02) -> ConvexPolygon2D:
    return polyline_tube(worm, radius)


def composite_hard_worm(radius: float = 0.02) -> ConvexPolygon2D:
    hook = thickened_worm(hook_worm(), radius)
    cap = sampled_disk(radius * 1.5, 24)
    return minkowski_sum_polygons(hook, cap)


def reduced_worm_family() -> list[tuple[str, Polyline2D | ConvexPolygon2D]]:
    return [
        ("straight", straight_worm()),
        ("hook", hook_worm()),
        ("broken", broken_worm()),
        ("composite", composite_hard_worm()),
    ]
