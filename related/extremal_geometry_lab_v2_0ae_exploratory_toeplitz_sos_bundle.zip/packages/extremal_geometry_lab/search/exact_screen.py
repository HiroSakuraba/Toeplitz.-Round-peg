
"""Family-aware exact screening."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class ScreenResult:
    family: str
    passed: bool
    reason: str
    details: dict | None = None


def exact_family_screen(candidate: dict, family_name: str, predicate) -> ScreenResult:
    ok, reason, *rest = predicate(candidate)
    details = rest[0] if rest else None
    return ScreenResult(family=family_name, passed=bool(ok), reason=str(reason), details=details)


def hybrid_family_screen(candidate: dict, family_bundle: dict[str, callable]) -> list[ScreenResult]:
    out = []
    for name, pred in family_bundle.items():
        out.append(exact_family_screen(candidate, name, pred))
    return out


def predicate_from_width_prescreen(width_screen):
    def _pred(candidate: dict):
        res = width_screen(candidate)
        return res.passed, res.reason, {
            "required_width": res.width_certificate.required_width,
            "certified_lower_width": res.width_certificate.certified_lower_width,
            **res.details,
        }
    return _pred
