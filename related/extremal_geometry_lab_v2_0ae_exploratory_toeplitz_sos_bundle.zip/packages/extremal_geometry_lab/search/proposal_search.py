"""Bounded move-sequence proposal search with lightweight canonicalization hooks."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Iterable, Any


def _screen_slack(details: dict | None) -> float:
    if not details:
        return 0.0
    try:
        if "certified_lower_width" in details and "required_width" in details:
            return float(details["certified_lower_width"]) - float(details["required_width"])
    except Exception:
        pass
    return 0.0


def _proposal_priority_tuple(proposal: "Proposal") -> tuple[float, float, float]:
    slack = _screen_slack(proposal.screen_details)
    score = float(proposal.score)
    return (slack, score, -float(len(proposal.move_history)))


def _normalize_screen_result(result: Any) -> tuple[bool, str, dict | None]:
    if hasattr(result, "passed") and hasattr(result, "reason"):
        return bool(result.passed), str(result.reason), getattr(result, "details", None)
    if isinstance(result, tuple):
        if len(result) == 0:
            return True, "ok", None
        if len(result) == 1:
            return bool(result[0]), "ok" if bool(result[0]) else "rejected", None
        if len(result) == 2:
            return bool(result[0]), str(result[1]), None
        return bool(result[0]), str(result[1]), result[2]
    return bool(result), "ok" if bool(result) else "rejected", None


@dataclass
class Proposal:
    state: dict
    move_history: list[str] = field(default_factory=list)
    score: float = 0.0
    canonical_key: Any = None
    screen_passed: bool | None = None
    screen_reason: str | None = None
    screen_details: dict | None = None
    annotations: dict = field(default_factory=dict)
    priority: tuple[Any, ...] = field(default_factory=lambda: (0.0, 0.0, 0.0))


def _apply_beam_policy(
    frontier: list[Proposal],
    *,
    beam_width: int | None,
    priority_key: Callable[[Proposal], Any],
    beam_policy: str = "greedy",
    beam_diversity_key: Callable[[Proposal], Any] | None = None,
    beam_diversity_keys: tuple[Callable[[Proposal], Any], ...] | None = None,
    beam_diversity_reserve: int = 0,
    deduplicate_before_screen: bool = False,
) -> list[Proposal]:
    ordered = sorted(frontier, key=priority_key, reverse=True)
    if beam_width is None or len(ordered) <= beam_width:
        return ordered
    key_fns: tuple[Callable[[Proposal], Any], ...]
    if beam_diversity_keys:
        key_fns = tuple(beam_diversity_keys)
    elif beam_diversity_key is not None:
        key_fns = (beam_diversity_key,)
    else:
        key_fns = tuple()

    if beam_policy != "diversified" or not key_fns or beam_width <= 1:
        return ordered[:beam_width]

    reserve = max(0, min(int(beam_diversity_reserve), beam_width - 1))
    selected: list[Proposal] = [ordered[0]]
    used_keys = [set([fn(ordered[0])]) for fn in key_fns]

    if reserve > 0 and len(key_fns) > 1:
        for fn_idx, fn in enumerate(key_fns):
            if len(selected) >= 1 + reserve:
                break
            for prop in ordered[1:]:
                if any(id(prop) == id(p) for p in selected):
                    continue
                key = fn(prop)
                if key in used_keys[fn_idx]:
                    continue
                selected.append(prop)
                for inner_fn, used in zip(key_fns, used_keys):
                    used.add(inner_fn(prop))
                break

    for prop in ordered[1:]:
        if len(selected) >= 1 + reserve:
            break
        novelties = [fn(prop) not in used for fn, used in zip(key_fns, used_keys)]
        if not any(novelties):
            continue
        selected.append(prop)
        for fn, used in zip(key_fns, used_keys):
            used.add(fn(prop))

    selected_ids = {id(p) for p in selected}
    for prop in ordered[1:]:
        if len(selected) >= beam_width:
            break
        if id(prop) in selected_ids:
            continue
        selected.append(prop)
        selected_ids.add(id(prop))
    return selected


def bounded_search(
    seed_state: dict,
    move_generator: Callable[[dict], Iterable[tuple[str, dict]]],
    proxy_score: Callable[[dict], float],
    proposal_move_generator: Callable[[Proposal], Iterable[tuple[str, dict]]] | None = None,
    depth: int = 2,
    canonicalize: Callable[[dict], Any] | None = None,
    screen: Callable[[dict], Any] | None = None,
    include_rejected: bool = False,
    priority_key: Callable[[Proposal], Any] | None = None,
    annotate: Callable[[Proposal], dict | None] | None = None,
    beam_width: int | None = None,
    beam_policy: str = "greedy",
    beam_diversity_key: Callable[[Proposal], Any] | None = None,
    beam_diversity_keys: tuple[Callable[[Proposal], Any], ...] | None = None,
    beam_diversity_reserve: int = 0,
    deduplicate_before_screen: bool = False,
) -> list[Proposal]:
    seen = set()
    if priority_key is None:
        priority_key = _proposal_priority_tuple
    if beam_width is not None:
        beam_width = max(1, int(beam_width))

    seed_ok, seed_reason, seed_details = (True, "ok", None) if screen is None else _normalize_screen_result(screen(seed_state))
    seed_prop = Proposal(
        state=seed_state,
        move_history=[],
        score=proxy_score(seed_state) if seed_ok else float("-inf"),
        canonical_key=canonicalize(seed_state) if canonicalize and seed_ok else None,
        screen_passed=seed_ok,
        screen_reason=seed_reason,
        screen_details=seed_details,
    )
    if seed_ok and annotate is not None:
        ann = annotate(seed_prop)
        if ann:
            seed_prop.annotations.update(ann)
    seed_prop.priority = tuple(priority_key(seed_prop))
    frontier = [seed_prop] if seed_ok else []
    if seed_prop.canonical_key is not None:
        seen.add(seed_prop.canonical_key)
    all_props = [seed_prop] if (seed_ok or include_rejected) else []

    for _ in range(depth):
        next_frontier: list[Proposal] = []
        pending_keys: set[Any] = set()
        for prop in frontier:
            child_iter = proposal_move_generator(prop) if proposal_move_generator is not None else move_generator(prop.state)
            for label, child in child_iter:
                key = None
                if deduplicate_before_screen and canonicalize is not None and not include_rejected:
                    key = canonicalize(child)
                    if key in seen or key in pending_keys:
                        continue
                ok, reason, details = (True, "ok", None) if screen is None else _normalize_screen_result(screen(child))
                if not ok:
                    if include_rejected:
                        rej = Proposal(
                            state=child,
                            move_history=prop.move_history + [label],
                            score=float("-inf"),
                            canonical_key=None,
                            screen_passed=False,
                            screen_reason=reason,
                            screen_details=details,
                        )
                        if annotate is not None:
                            ann = annotate(rej)
                            if ann:
                                rej.annotations.update(ann)
                        rej.priority = tuple(priority_key(rej))
                        all_props.append(rej)
                    continue
                if key is None:
                    key = canonicalize(child) if canonicalize else None
                if key is not None and (key in seen or key in pending_keys):
                    continue
                if key is not None:
                    pending_keys.add(key)
                child_prop = Proposal(
                    state=child,
                    move_history=prop.move_history + [label],
                    score=proxy_score(child),
                    canonical_key=key,
                    screen_passed=True,
                    screen_reason=reason,
                    screen_details=details,
                )
                if annotate is not None:
                    ann = annotate(child_prop)
                    if ann:
                        child_prop.annotations.update(ann)
                child_prop.priority = tuple(priority_key(child_prop))
                next_frontier.append(child_prop)
        if pending_keys:
            seen.update(pending_keys)
        frontier = _apply_beam_policy(
            next_frontier,
            beam_width=beam_width,
            priority_key=priority_key,
            beam_policy=beam_policy,
            beam_diversity_key=beam_diversity_key,
            beam_diversity_keys=beam_diversity_keys,
            beam_diversity_reserve=beam_diversity_reserve,
        )
        all_props.extend(frontier)
    return sorted(all_props, key=priority_key, reverse=True)
