
"""Search-only proxy scoring."""

def area_minus_penalty(area: float, penalty: float) -> float:
    return -(area + penalty)


def area_margin_score(area: float, worst_margin: float, penalty: float = 0.0) -> float:
    return -(area + penalty) + 10.0 * worst_margin
