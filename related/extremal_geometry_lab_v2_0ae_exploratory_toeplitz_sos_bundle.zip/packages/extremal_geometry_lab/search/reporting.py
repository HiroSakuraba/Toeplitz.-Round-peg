from __future__ import annotations

from typing import Iterable

from .proposal_search import Proposal


def accepted_descendants(props: Iterable[Proposal]) -> list[Proposal]:
    """Return non-seed proposals that passed screening.

    This intentionally excludes the seed and any rejected proposal even when the
    caller obtained proposals with include_rejected=True.
    """
    return [p for p in props if bool(p.screen_passed) and len(p.move_history) > 0]


def proposals_at_depth(props: Iterable[Proposal], depth: int) -> list[Proposal]:
    """Return screen-passed proposals exactly at the requested move depth."""
    return [p for p in props if bool(p.screen_passed) and len(p.move_history) == depth]


def targeted_proposals(props: Iterable[Proposal]) -> list[Proposal]:
    """Return screen-passed non-seed proposals with at least one targeted move."""
    return [
        p
        for p in accepted_descendants(props)
        if any(str(move).startswith("targeted-") for move in p.move_history)
    ]


def targeted_labels(props: Iterable[Proposal]) -> list[str]:
    labels = {
        str(move)
        for p in props
        for move in p.move_history
        if str(move).startswith("targeted-")
    }
    return sorted(labels)


def distinct_target_signatures(props: Iterable[Proposal]) -> list[tuple]:
    sigs = {tuple((p.annotations or {}).get("witness_target_score_signature", ())) for p in props}
    return sorted(sigs)
