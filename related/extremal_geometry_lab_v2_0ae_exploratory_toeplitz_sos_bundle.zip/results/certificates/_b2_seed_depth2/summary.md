# Lebesgue witness-net bridge: seed-depth2

- container: `pal-seed`
- witness count: `6`
- joint certified: `False`
- passed witnesses: `0`
- failed witnesses: `6`
- Hausdorff resolution note: `0.16910197872576274`
- coverage status: `incomplete-family`

This is a finite normalized witness-family bridge from search to exact-screening. It is not a full epsilon-net theorem certificate.

## Witness ledger

- 00 `segment`: feasible `False`, complete `False`, bundle `00_segment/bundle.json`
- 01 `orbiform-stub`: feasible `False`, complete `False`, bundle `01_orbiform-stub/bundle.json`
- 02 `disk-half`: feasible `False`, complete `False`, bundle `02_disk-half/bundle.json`
- 03 `regular-3-gon`: feasible `False`, complete `True`, bundle `03_regular-3-gon/bundle.json`
- 04 `regular-4-gon`: feasible `False`, complete `False`, bundle `04_regular-4-gon/bundle.json`
- 05 `pal-seed`: feasible `False`, complete `False`, bundle `05_pal-seed/bundle.json`