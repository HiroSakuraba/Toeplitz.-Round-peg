# Rigid-motion certificate bundle: orbiform-stub in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `80`
- unresolved boxes: `32`
- explored boxes: `160`

## Best midpoint pose found during refinement
- rotation: `3.5342917352885173`
- translation: `(-0.0, -0.004939311588785364)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `-0.22480593166963292`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042772`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.042230485593073`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163082`
- midpoint sampled max violation: `0.23570655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 7
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299187`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849428`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365332`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365327`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849429`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 13
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.501448387504277`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.042230485593073`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 26
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299191`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 27
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299187`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 28
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849428`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365332`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365327`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299186`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 32
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849429`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 35
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365325`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.501448387504277`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.042230485593073`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 46
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299191`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 47
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299187`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 48
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849428`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 49
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365332`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365327`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299186`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 52
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849429`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 53
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 54
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 55
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365325`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.501448387504277`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042772`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 64
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 65
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 66
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 67
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.933115662729919`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 68
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849428`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 69
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365332`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5856594138365327`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299186`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 72
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849429`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 73
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8548219753849431`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 74
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.9331156627299189`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 75
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.585659413836533`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 76
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 77
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5014483875042777`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 78
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.501448387504277`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 79
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0422304855930733`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516489`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066729`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066726`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516488`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516489`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066729`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516484`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066726`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516488`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516489`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066729`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516484`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066726`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516489`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066729`
- midpoint sampled margin: `-0.04820655332163082`
- midpoint sampled max violation: `0.04820655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516484`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066726`
- midpoint sampled margin: `-0.04820655332163093`
- midpoint sampled max violation: `0.04820655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.6265364395066728`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7048301268516486`
- midpoint sampled margin: `-0.04820655332163104`
- midpoint sampled max violation: `0.04820655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 12, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
