# Rigid-motion certificate bundle: regular-3-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `-0.18041428571446483`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5964446357278506`
- midpoint sampled margin: `-0.7252355885716434`
- midpoint sampled max violation: `0.7252355885716434`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.4876277496099513`
- midpoint sampled margin: `-0.7793653723122373`
- midpoint sampled max violation: `0.7793653723122373`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.0739163048553944`
- midpoint sampled margin: `-1.3076775358252046`
- midpoint sampled max violation: `1.3076775358252046`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7664510337061852`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252051`
- certified upper violation: `1.0834383318139655`
- midpoint sampled margin: `-0.23032726663557945`
- midpoint sampled max violation: `0.23032726663557945`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `0.9107886010035914`
- midpoint sampled margin: `-0.23032726663557923`
- midpoint sampled max violation: `0.23032726663557923`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.5938013028958116`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7381388701932172`
- midpoint sampled margin: `-0.7788387679126024`
- midpoint sampled max violation: `0.7788387679126024`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.0551261683009976`
- midpoint sampled margin: `-0.08598969933817313`
- midpoint sampled max violation: `0.08598969933817313`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.0091726192691892`
- midpoint sampled margin: `-0.09635267042001816`
- midpoint sampled max violation: `0.09635267042001816`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6921853211614082`
- midpoint sampled margin: `-0.763910723166456`
- midpoint sampled max violation: `0.763910723166456`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.2182538721528005`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.667541649638837`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6769785288174144`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.190119068794268`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.2182538721528013`
- midpoint sampled margin: `-1.1582482904638631`
- midpoint sampled max violation: `1.1582482904638631`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.667541649638837`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.676978528817414`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.190119068794269`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7381388701932174`
- midpoint sampled margin: `-0.7788387679126029`
- midpoint sampled max violation: `0.7788387679126029`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252051`
- certified upper violation: `1.0551261683009978`
- midpoint sampled margin: `-0.08598969933817291`
- midpoint sampled max violation: `0.08598969933817291`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.0091726192691888`
- midpoint sampled margin: `-0.09635267042001816`
- midpoint sampled max violation: `0.09635267042001816`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.6921853211614084`
- midpoint sampled margin: `-0.7639107231664563`
- midpoint sampled max violation: `0.7639107231664563`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7664510337061854`
- midpoint sampled margin: `-0.9133399685277988`
- midpoint sampled max violation: `0.9133399685277988`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.0834383318139655`
- midpoint sampled margin: `-0.23032726663557934`
- midpoint sampled max violation: `0.23032726663557934`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `0.9107886010035917`
- midpoint sampled margin: `-0.23032726663557967`
- midpoint sampled max violation: `0.23032726663557967`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.593801302895811`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.5964446357278503`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.4876277496099517`
- midpoint sampled margin: `-0.7793653723122373`
- midpoint sampled max violation: `0.7793653723122373`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.073916304855395`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.1901190687942678`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.676978528817414`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.667541649638837`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.218253872152801`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6921853211614082`
- midpoint sampled margin: `-0.7639107231664563`
- midpoint sampled max violation: `0.7639107231664563`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252051`
- certified upper violation: `1.0091726192691888`
- midpoint sampled margin: `-0.09635267042001816`
- midpoint sampled max violation: `0.09635267042001816`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.055126168300998`
- midpoint sampled margin: `-0.08598969933817302`
- midpoint sampled max violation: `0.08598969933817302`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.738138870193218`
- midpoint sampled margin: `-0.7788387679126025`
- midpoint sampled max violation: `0.7788387679126025`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5938013028958107`
- midpoint sampled margin: `-0.913339968527799`
- midpoint sampled max violation: `0.913339968527799`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `0.910788601003591`
- midpoint sampled margin: `-0.23032726663557934`
- midpoint sampled max violation: `0.23032726663557934`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.083438331813966`
- midpoint sampled margin: `-0.23032726663557945`
- midpoint sampled max violation: `0.23032726663557945`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7664510337061852`
- midpoint sampled margin: `-0.9133399685277984`
- midpoint sampled max violation: `0.9133399685277984`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.073916304855394`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.4876277496099513`
- midpoint sampled margin: `-0.7793653723122373`
- midpoint sampled max violation: `0.7793653723122373`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5964446357278508`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.073916304855395`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.4876277496099513`
- midpoint sampled margin: `-0.7793653723122373`
- midpoint sampled max violation: `0.7793653723122373`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5964446357278503`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.246566035665769`
- midpoint sampled margin: `-1.3076775358252046`
- midpoint sampled max violation: `1.3076775358252046`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.593801302895811`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252051`
- certified upper violation: `0.9107886010035913`
- midpoint sampled margin: `-0.23032726663557945`
- midpoint sampled max violation: `0.23032726663557945`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.0834383318139658`
- midpoint sampled margin: `-0.23032726663557923`
- midpoint sampled max violation: `0.23032726663557923`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.7664510337061858`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.692185321161408`
- midpoint sampled margin: `-0.7639107231664566`
- midpoint sampled max violation: `0.7639107231664566`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.0091726192691883`
- midpoint sampled margin: `-0.09635267042001816`
- midpoint sampled max violation: `0.09635267042001816`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.0551261683009983`
- midpoint sampled margin: `-0.08598969933817291`
- midpoint sampled max violation: `0.08598969933817291`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7381388701932174`
- midpoint sampled margin: `-0.7788387679126029`
- midpoint sampled max violation: `0.7788387679126029`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.190119068794268`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.676978528817414`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6675416496388369`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.2182538721528013`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `5.551115123125783e-17`
