# Rigid-motion certificate bundle: segment in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.4330122018922194`
- sampled max violation: `-0.4330122018922194`
- certified upper violation: `-0.3562235554504763`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455964`
- midpoint sampled margin: `-0.8001636639511663`
- midpoint sampled max violation: `0.8001636639511663`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105852`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650918`
- midpoint sampled margin: `-0.6508110720925875`
- midpoint sampled max violation: `0.6508110720925875`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787807`
- midpoint sampled margin: `-1.153716347437658`
- midpoint sampled max violation: `1.153716347437658`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887512`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219363`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.425920671421936`
- midpoint sampled margin: `-0.7787163474374086`
- midpoint sampled max violation: `0.7787163474374086`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887512`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787807`
- midpoint sampled margin: `-1.1537163474376584`
- midpoint sampled max violation: `1.1537163474376584`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650922`
- midpoint sampled margin: `-0.6508110720925872`
- midpoint sampled max violation: `0.6508110720925872`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.289352559110585`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455964`
- midpoint sampled margin: `-0.8001636639511661`
- midpoint sampled max violation: `0.8001636639511661`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787809`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650918`
- midpoint sampled margin: `-0.6508110720925876`
- midpoint sampled max violation: `0.6508110720925876`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105857`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455961`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219357`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887518`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887514`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219357`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455961`
- midpoint sampled margin: `-0.800163663951166`
- midpoint sampled max violation: `0.800163663951166`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105857`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650922`
- midpoint sampled margin: `-0.6508110720925872`
- midpoint sampled max violation: `0.6508110720925872`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787809`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455964`
- midpoint sampled margin: `-0.8001636639511661`
- midpoint sampled max violation: `0.8001636639511661`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105852`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650918`
- midpoint sampled margin: `-0.6508110720925875`
- midpoint sampled max violation: `0.6508110720925875`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787807`
- midpoint sampled margin: `-1.153716347437658`
- midpoint sampled max violation: `1.153716347437658`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887512`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219363`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.425920671421936`
- midpoint sampled margin: `-0.7787163474374086`
- midpoint sampled max violation: `0.7787163474374086`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887512`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787807`
- midpoint sampled margin: `-1.1537163474376584`
- midpoint sampled max violation: `1.1537163474376584`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650922`
- midpoint sampled margin: `-0.6508110720925874`
- midpoint sampled max violation: `0.6508110720925874`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.289352559110585`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455964`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787809`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650918`
- midpoint sampled margin: `-0.6508110720925874`
- midpoint sampled max violation: `0.6508110720925874`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105857`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455961`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219357`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887518`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3589335072887514`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.4259206714219357`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8155045790455961`
- midpoint sampled margin: `-0.800163663951166`
- midpoint sampled max violation: `0.800163663951166`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2893525591105857`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3194785064650922`
- midpoint sampled margin: `-0.6508110720925872`
- midpoint sampled max violation: `0.6508110720925872`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.8824917431787809`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545503`
- midpoint sampled margin: `0.02908525484511304`
- midpoint sampled max violation: `-0.02908525484511304`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948508`
- midpoint sampled margin: `0.04938436950723213`
- midpoint sampled max violation: `-0.04938436950723213`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700788`
- midpoint sampled margin: `-0.04291140154211359`
- midpoint sampled max violation: `0.04291140154211359`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.776401361319199`
- midpoint sampled margin: `-0.1419566838481644`
- midpoint sampled max violation: `0.1419566838481644`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700789`
- midpoint sampled margin: `-0.042911401542113925`
- midpoint sampled max violation: `0.042911401542113925`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191989`
- midpoint sampled margin: `-0.14195668384816473`
- midpoint sampled max violation: `0.14195668384816473`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545499`
- midpoint sampled margin: `0.02908525484511315`
- midpoint sampled max violation: `-0.02908525484511315`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948508`
- midpoint sampled margin: `0.04938436950723235`
- midpoint sampled max violation: `-0.04938436950723235`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191991`
- midpoint sampled margin: `-0.14195668384816484`
- midpoint sampled max violation: `0.14195668384816484`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700792`
- midpoint sampled margin: `-0.042911401542114036`
- midpoint sampled max violation: `0.042911401542114036`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948509`
- midpoint sampled margin: `0.04938436950723235`
- midpoint sampled max violation: `-0.04938436950723235`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545499`
- midpoint sampled margin: `0.02908525484511293`
- midpoint sampled max violation: `-0.02908525484511293`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948506`
- midpoint sampled margin: `0.04938436950723235`
- midpoint sampled max violation: `-0.04938436950723235`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545499`
- midpoint sampled margin: `0.029085254845112818`
- midpoint sampled max violation: `-0.029085254845112818`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191991`
- midpoint sampled margin: `-0.14195668384816484`
- midpoint sampled max violation: `0.14195668384816484`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700792`
- midpoint sampled margin: `-0.042911401542114036`
- midpoint sampled max violation: `0.042911401542114036`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545506`
- midpoint sampled margin: `0.02908525484511293`
- midpoint sampled max violation: `-0.02908525484511293`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948508`
- midpoint sampled margin: `0.04938436950723202`
- midpoint sampled max violation: `-0.04938436950723202`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700788`
- midpoint sampled margin: `-0.04291140154211337`
- midpoint sampled max violation: `0.04291140154211337`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.776401361319199`
- midpoint sampled margin: `-0.1419566838481644`
- midpoint sampled max violation: `0.1419566838481644`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700789`
- midpoint sampled margin: `-0.0429114015421137`
- midpoint sampled max violation: `0.0429114015421137`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191989`
- midpoint sampled margin: `-0.14195668384816473`
- midpoint sampled max violation: `0.14195668384816473`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545499`
- midpoint sampled margin: `0.02908525484511293`
- midpoint sampled max violation: `-0.02908525484511293`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948508`
- midpoint sampled margin: `0.04938436950723213`
- midpoint sampled max violation: `-0.04938436950723213`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191991`
- midpoint sampled margin: `-0.14195668384816484`
- midpoint sampled max violation: `0.14195668384816484`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700792`
- midpoint sampled margin: `-0.042911401542114036`
- midpoint sampled max violation: `0.042911401542114036`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948509`
- midpoint sampled margin: `0.04938436950723213`
- midpoint sampled max violation: `-0.04938436950723213`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545497`
- midpoint sampled margin: `0.02908525484511293`
- midpoint sampled max violation: `-0.02908525484511293`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7094144458948506`
- midpoint sampled margin: `0.04938436950723213`
- midpoint sampled max violation: `-0.04938436950723213`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7500000000005, 0.0] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.6052696110545499`
- midpoint sampled margin: `0.02908525484511293`
- midpoint sampled max violation: `-0.02908525484511293`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7764013613191991`
- midpoint sampled margin: `-0.14195668384816484`
- midpoint sampled max violation: `0.14195668384816484`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7500000000005, 0.0] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `0.7721240492700792`
- midpoint sampled margin: `-0.04291140154211415`
- midpoint sampled max violation: `0.04291140154211415`
- pose drift bound: `0.726679626740019`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`
