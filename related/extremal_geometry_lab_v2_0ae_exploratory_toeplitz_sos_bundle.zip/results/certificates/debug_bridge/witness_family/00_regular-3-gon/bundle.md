# Rigid-motion certificate bundle: regular-3-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `16`
- unresolved boxes: `0`
- explored boxes: `16`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `-0.18041428571446483`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-0.7690024012303923`
- midpoint sampled max violation: `0.7690024012303923`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.0739163048553944`
- midpoint sampled margin: `-0.7690024012303919`
- midpoint sampled max violation: `0.7690024012303919`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2182538721528005`
- midpoint sampled margin: `-0.61957315586905`
- midpoint sampled max violation: `0.61957315586905`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.190119068794268`
- midpoint sampled margin: `-0.6494292453613423`
- midpoint sampled max violation: `0.6494292453613423`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2182538721528013`
- midpoint sampled margin: `-0.6195731558690504`
- midpoint sampled max violation: `0.6195731558690504`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.190119068794269`
- midpoint sampled margin: `-0.6494292453613423`
- midpoint sampled max violation: `0.6494292453613423`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-0.7690024012303922`
- midpoint sampled max violation: `0.7690024012303922`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.073916304855395`
- midpoint sampled margin: `-0.7690024012303925`
- midpoint sampled max violation: `0.7690024012303925`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.1901190687942678`
- midpoint sampled margin: `-0.6494292453613423`
- midpoint sampled max violation: `0.6494292453613423`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.218253872152801`
- midpoint sampled margin: `-0.6195731558690499`
- midpoint sampled max violation: `0.6195731558690499`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.073916304855394`
- midpoint sampled margin: `-0.7690024012303924`
- midpoint sampled max violation: `0.7690024012303924`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2465660356657686`
- midpoint sampled margin: `-0.7690024012303923`
- midpoint sampled max violation: `0.7690024012303923`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.073916304855395`
- midpoint sampled margin: `-0.7690024012303925`
- midpoint sampled max violation: `0.7690024012303925`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.246566035665769`
- midpoint sampled margin: `-0.7690024012303919`
- midpoint sampled max violation: `0.7690024012303919`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.190119068794268`
- midpoint sampled margin: `-0.6494292453613423`
- midpoint sampled max violation: `0.6494292453613423`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2182538721528013`
- midpoint sampled margin: `-0.6195731558690502`
- midpoint sampled max violation: `0.6195731558690502`
- pose drift bound: `1.5688049127089652`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 12, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`
