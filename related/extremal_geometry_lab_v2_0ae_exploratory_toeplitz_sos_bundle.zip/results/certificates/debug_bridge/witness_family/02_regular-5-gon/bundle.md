# Rigid-motion certificate bundle: regular-5-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `16`
- unresolved boxes: `4`
- explored boxes: `24`

## Best midpoint pose found during refinement
- rotation: `3.141592653589793`
- translation: `(0.03396335653261888, -0.0)`
- sampled margin: `0.3687644561003019`
- sampled max violation: `-0.3687644561003019`
- certified upper violation: `-0.19661971808983258`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 1.5257311121191335] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0977983817645898`
- midpoint sampled margin: `-0.6169835358526045`
- midpoint sampled max violation: `0.6169835358526045`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7628655560595667, 1.5257311121191335] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `2.015911332506997`
- midpoint sampled margin: `-0.9083738053884799`
- midpoint sampled max violation: `0.9083738053884799`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5257311121191335, 0.0] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.113380754004162`
- midpoint sampled margin: `-0.6668806013401001`
- midpoint sampled max violation: `0.6668806013401001`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5257311121191335, 0.0] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.061133138062135`
- midpoint sampled margin: `-0.7010789413666064`
- midpoint sampled max violation: `0.7010789413666064`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.5257311121191335] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.1133807540041625`
- midpoint sampled margin: `-0.6668806013401004`
- midpoint sampled max violation: `0.6668806013401004`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.5257311121191335] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0611331380621345`
- midpoint sampled margin: `-0.701078941366606`
- midpoint sampled max violation: `0.701078941366606`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5257311121191335, 0.0] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0977983817645893`
- midpoint sampled margin: `-0.6169835358526046`
- midpoint sampled max violation: `0.6169835358526046`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5257311121191335, -0.7628655560595667] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `2.015911332506997`
- midpoint sampled margin: `-0.9083738053884803`
- midpoint sampled max violation: `0.9083738053884803`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.5257311121191335] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.061133138062135`
- midpoint sampled margin: `-0.7010789413666064`
- midpoint sampled max violation: `0.7010789413666064`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.5257311121191335] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.113380754004162`
- midpoint sampled margin: `-0.6668806013401`
- midpoint sampled max violation: `0.6668806013401`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5257311121191335, -0.7628655560595667] x [0.0, 1.5257311121191335]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `2.015911332506997`
- midpoint sampled margin: `-0.9083738053884799`
- midpoint sampled max violation: `0.9083738053884799`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5257311121191335, 0.0] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0977983817645898`
- midpoint sampled margin: `-0.6169835358526047`
- midpoint sampled max violation: `0.6169835358526047`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7628655560595667, 1.5257311121191335] x [0.0, 1.5257311121191335]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `2.015911332506997`
- midpoint sampled margin: `-0.9083738053884799`
- midpoint sampled max violation: `0.9083738053884799`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 1.5257311121191335] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0977983817645893`
- midpoint sampled margin: `-0.6169835358526038`
- midpoint sampled max violation: `0.6169835358526038`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5257311121191335, 0.0] x [0.0, 1.5257311121191335]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.0611331380621345`
- midpoint sampled margin: `-0.7010789413666063`
- midpoint sampled max violation: `0.7010789413666063`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5257311121191335, 0.0] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `1.078854815646732`
- certified upper violation: `2.1133807540041625`
- midpoint sampled margin: `-0.6668806013401002`
- midpoint sampled max violation: `0.6668806013401002`
- pose drift bound: `1.4917630655459975`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7628655560595667] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `1.5515082064586436`
- midpoint sampled margin: `-0.49316919532972425`
- midpoint sampled max violation: `0.49316919532972425`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7628655560595667, 0.0] x [-1.5257311121191335, 0.0]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `1.5515082064586425`
- midpoint sampled margin: `-0.4931691953297245`
- midpoint sampled max violation: `0.4931691953297245`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7628655560595667, 0.0] x [0.0, 1.5257311121191335]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `1.5515082064586427`
- midpoint sampled margin: `-0.4931691953297246`
- midpoint sampled max violation: `0.4931691953297246`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7628655560595667] x [0.0, 1.5257311121191335]`
- l2 translation radius: `0.8529096205211839`
- certified upper violation: `1.551508206458643`
- midpoint sampled margin: `-0.4931691953297245`
- midpoint sampled max violation: `0.4931691953297245`
- pose drift bound: `1.2658178704204495`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
