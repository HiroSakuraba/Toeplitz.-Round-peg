# Rigid-motion certificate bundle: pal-seed in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `16`
- unresolved boxes: `16`
- explored boxes: `48`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.43301270189221935`
- sampled max violation: `-0.43301270189221935`
- certified upper violation: `-0.2674006532374622`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.0074908771519024`
- midpoint sampled margin: `-0.8598993884357081`
- midpoint sampled max violation: `0.8598993884357081`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357081`
- midpoint sampled max violation: `0.8598993884357081`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-0.8598993884357083`
- midpoint sampled max violation: `0.8598993884357083`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-0.8322414924020276`
- midpoint sampled max violation: `0.8322414924020276`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

## Unresolved boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.575438858233691`
- midpoint sampled margin: `-0.4539565621984242`
- midpoint sampled max violation: `0.4539565621984242`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336905`
- midpoint sampled margin: `-0.4539565621984243`
- midpoint sampled max violation: `0.4539565621984243`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.4539565621984246`
- midpoint sampled max violation: `0.4539565621984246`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.550919805395362`
- midpoint sampled margin: `-0.4539565621984242`
- midpoint sampled max violation: `0.4539565621984242`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953615`
- midpoint sampled margin: `-0.4539565621984245`
- midpoint sampled max violation: `0.4539565621984245`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.575438858233691`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336905`
- midpoint sampled margin: `-0.4539565621984243`
- midpoint sampled max violation: `0.4539565621984243`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.4539565621984246`
- midpoint sampled max violation: `0.4539565621984246`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.550919805395362`
- midpoint sampled margin: `-0.4539565621984242`
- midpoint sampled max violation: `0.4539565621984242`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.0, 1.5]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5509198053953615`
- midpoint sampled margin: `-0.4539565621984243`
- midpoint sampled max violation: `0.4539565621984243`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, 0.0]`
- l2 translation radius: `0.8385254915624212`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.4539565621984244`
- midpoint sampled max violation: `0.4539565621984244`
- pose drift bound: `1.2312245732611453`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 4, 12]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
