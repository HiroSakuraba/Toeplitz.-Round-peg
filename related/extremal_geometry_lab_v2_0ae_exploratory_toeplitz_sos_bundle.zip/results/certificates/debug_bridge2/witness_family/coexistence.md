# Witness-family coexistence certificate: pal-seed

- schema: `witness-family-coexistence.v1`
- certificate kind: `product-space-feasibility-region`
- joint certified: `False`
- witness count: `4`
- joint pose dimension: `12`
- all refinements classified: `False`

## Interpretation
- Every tuple of poses chosen independently from the selected per-witness rigid-motion boxes is certified feasible for the corresponding witness in the common container.
- This does not certify disjointness or non-overlap among witnesses, and it does not force a single shared pose variable across different witnesses.

## Selected product region

- none

## Missing witnesses

- 00 `regular-3-gon`: no certified feasible rigid-motion box exported
- 01 `regular-4-gon`: no certified feasible rigid-motion box exported
- 02 `regular-5-gon`: no certified feasible rigid-motion box exported
- 03 `pal-seed`: no certified feasible rigid-motion box exported
