# Witness-family bundle: pal-seed

- schema: `witness-family-bundle.v2`
- witness count: `4`
- joint coexistence path: `coexistence.json`
- joint certified: `False`

## Witness status

- 00 `regular-3-gon`: feasible `False`, complete `True`, selected box `None`, bundle `00_regular-3-gon/bundle.json`
- 01 `regular-4-gon`: feasible `False`, complete `False`, selected box `None`, bundle `01_regular-4-gon/bundle.json`
- 02 `regular-5-gon`: feasible `False`, complete `False`, selected box `None`, bundle `02_regular-5-gon/bundle.json`
- 03 `pal-seed`: feasible `False`, complete `False`, selected box `None`, bundle `03_pal-seed/bundle.json`