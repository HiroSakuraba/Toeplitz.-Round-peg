# Rigid-motion certificate bundle: regular-3-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `12`
- unresolved boxes: `0`
- explored boxes: `12`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `-0.15225547142632778`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.1887902047863905, 0.0]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.380239621436674`
- midpoint sampled margin: `-0.7886751345948128`
- midpoint sampled max violation: `0.7886751345948128`
- pose drift bound: `1.7199548597284835`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.1887902047863905, 0.0]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.1695328316537608`
- midpoint sampled margin: `-0.7886751345948125`
- midpoint sampled max violation: `0.7886751345948125`
- pose drift bound: `1.7199548597284835`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.1887902047863905, 0.0]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.3638206102034824`
- midpoint sampled margin: `-0.5773502691896264`
- midpoint sampled max violation: `0.5773502691896264`
- pose drift bound: `1.7199548597284835`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.1887902047863905, 0.0]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2963067076960666`
- midpoint sampled margin: `-0.5773502691896255`
- midpoint sampled max violation: `0.5773502691896255`
- pose drift bound: `1.7199548597284835`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[2.0943951023931953, 4.1887902047863905]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.380857697058948`
- midpoint sampled margin: `-0.7886751345948128`
- midpoint sampled max violation: `0.7886751345948128`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[2.0943951023931953, 4.1887902047863905]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.380857697058948`
- midpoint sampled margin: `-0.7886751345948125`
- midpoint sampled max violation: `0.7886751345948125`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[2.0943951023931953, 4.1887902047863905]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.219860309642869`
- midpoint sampled margin: `-0.577350269189626`
- midpoint sampled max violation: `0.577350269189626`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[2.0943951023931953, 4.1887902047863905]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2198603096428693`
- midpoint sampled margin: `-0.5773502691896257`
- midpoint sampled max violation: `0.5773502691896257`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[0.0, 2.0943951023931953]`
- translation box: `[0.0, 1.5773502691896257] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.1695328316537608`
- midpoint sampled margin: `-0.7886751345948128`
- midpoint sampled max violation: `0.7886751345948128`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[0.0, 2.0943951023931953]`
- translation box: `[0.0, 1.5773502691896257] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.380239621436674`
- midpoint sampled margin: `-0.7886751345948125`
- midpoint sampled max violation: `0.7886751345948125`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[0.0, 2.0943951023931953]`
- translation box: `[-1.5773502691896257, 0.0] x [0.0, 1.5773502691896257]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.2963067076960666`
- midpoint sampled margin: `-0.577350269189626`
- midpoint sampled max violation: `0.577350269189626`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[0.0, 2.0943951023931953]`
- translation box: `[-1.5773502691896257, 0.0] x [-1.5773502691896257, 0.0]`
- l2 translation radius: `1.1153550716504106`
- certified upper violation: `2.363820610203482`
- midpoint sampled margin: `-0.5773502691896257`
- midpoint sampled max violation: `0.5773502691896257`
- pose drift bound: `1.7199548597284833`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 12, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`
