
# Placeholder certificate bundle

This is a dummy human-readable certificate bundle showing the intended format.

- Candidate family: Pál-descended cover family
- Witness family: segment, orbiform stub, half-disk stub
- Search layer: bounded move sequence with canonical polygon signatures
- Proof layer: sample-based containment and area certificates

This file should eventually be paired with an interval-certified JSON bundle.
