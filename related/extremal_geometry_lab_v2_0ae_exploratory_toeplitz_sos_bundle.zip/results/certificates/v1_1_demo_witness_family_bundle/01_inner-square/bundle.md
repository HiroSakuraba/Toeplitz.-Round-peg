# Rigid-motion certificate bundle: inner-square in outer-square

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `0`
- unresolved boxes: `64`
- explored boxes: `120`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `1.4`
- sampled max violation: `-1.4`
- certified upper violation: `-1.1649510589657184`

## Certified feasible boxes

- none

## Certified infeasible boxes

- none

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280902`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.1224453888380288`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280902`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.1224453888380288`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280835`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802836`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.0829031855323148`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280835`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802836`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.0829031855323148`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802925`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741743`
- midpoint sampled max violation: `-0.4660622210741743`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231568`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741743`
- midpoint sampled max violation: `-0.4660622210741743`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802925`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231568`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231457`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802814`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231457`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802814`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280902`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.1224453888380288`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280902`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.1224453888380288`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280835`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802836`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280835`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802836`
- midpoint sampled margin: `0.7160622210741747`
- midpoint sampled max violation: `-0.7160622210741747`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.46606222107417405`
- midpoint sampled max violation: `-0.46606222107417405`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 47
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231524`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802925`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231568`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 51
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 52
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802925`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 53
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 54
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231568`
- midpoint sampled margin: `0.716062221074174`
- midpoint sampled max violation: `-0.716062221074174`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231457`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741747`
- midpoint sampled max violation: `-0.4660622210741747`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802858`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.08290318553231457`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 61
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280924`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.12244538883802858`
- midpoint sampled margin: `0.7160622210741745`
- midpoint sampled max violation: `-0.7160622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.17145395900280858`
- midpoint sampled margin: `0.4660622210741745`
- midpoint sampled max violation: `-0.4660622210741745`
- pose drift bound: `0.8922332147368249`
- certification method: `interval`
- depth: `3`
