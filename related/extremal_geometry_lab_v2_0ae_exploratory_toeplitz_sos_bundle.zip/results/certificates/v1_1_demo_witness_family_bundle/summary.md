# Witness-family bundle: outer-square

- schema: `witness-family-bundle.v1`
- witness count: `2`

## Witness status

- 00 `inner-triangle`: feasible `True`, complete `True`, bundle `00_inner-triangle/bundle.json`
- 01 `inner-square`: feasible `False`, complete `False`, bundle `01_inner-square/bundle.json`