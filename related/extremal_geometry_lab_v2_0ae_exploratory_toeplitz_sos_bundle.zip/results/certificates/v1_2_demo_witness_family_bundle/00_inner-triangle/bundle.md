# Rigid-motion certificate bundle: inner-triangle in outer-square

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `22`
- certified infeasible boxes: `0`
- unresolved boxes: `0`
- explored boxes: `36`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.3000000000000004, 0.09999999999999953)`
- sampled margin: `1.5`
- sampled max violation: `-1.5`
- certified upper violation: `-1.2830588224708492`

## Certified feasible boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187689`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.02164163489617832`
- midpoint sampled margin: `0.7226280307544617`
- midpoint sampled max violation: `-0.7226280307544617`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 2
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.09235231301483293`
- midpoint sampled margin: `1.0050252531694168`
- midpoint sampled max violation: `-1.0050252531694168`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.22666688806559554`
- midpoint sampled margin: `1.0222089669662462`
- midpoint sampled max violation: `-1.0222089669662462`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.01505126767855991`
- midpoint sampled margin: `0.7226280307544617`
- midpoint sampled max violation: `-0.7226280307544617`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 5
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187755`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.02164163489617854`
- midpoint sampled margin: `0.7226280307544621`
- midpoint sampled max violation: `-0.7226280307544621`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 7
- theta interval: `[3.141592653589793, 0.0]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187667`
- midpoint sampled margin: `1.1`
- midpoint sampled max violation: `-1.1`
- pose drift bound: `1.9735232668566534`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.0923523130148336`
- midpoint sampled margin: `0.9343145750507622`
- midpoint sampled max violation: `-0.9343145750507622`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.22666688806559554`
- midpoint sampled margin: `1.0222089669662464`
- midpoint sampled max violation: `-1.0222089669662464`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.01505126767855991`
- midpoint sampled margin: `0.7226280307544619`
- midpoint sampled max violation: `-0.7226280307544619`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.09235231301483293`
- midpoint sampled margin: `0.934314575050762`
- midpoint sampled max violation: `-0.934314575050762`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.22666688806559487`
- midpoint sampled margin: `1.022208966966246`
- midpoint sampled max violation: `-1.022208966966246`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 13
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.015051267678559244`
- midpoint sampled margin: `0.7226280307544615`
- midpoint sampled max violation: `-0.7226280307544615`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 14
- theta interval: `[0.0, 3.141592653589793]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187733`
- midpoint sampled margin: `1.1000000000000005`
- midpoint sampled max violation: `-1.1000000000000005`
- pose drift bound: `1.9735232668566534`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.22666688806559487`
- midpoint sampled margin: `1.0222089669662462`
- midpoint sampled max violation: `-1.0222089669662462`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 16
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.015051267678559244`
- midpoint sampled margin: `0.7226280307544619`
- midpoint sampled max violation: `-0.7226280307544619`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187689`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 18
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.021641634896178097`
- midpoint sampled margin: `0.7226280307544617`
- midpoint sampled max violation: `-0.7226280307544617`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.08255059898187755`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 20
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.021641634896178097`
- midpoint sampled margin: `0.7226280307544621`
- midpoint sampled max violation: `-0.7226280307544621`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.09235231301483271`
- midpoint sampled margin: `1.005025253169417`
- midpoint sampled max violation: `-1.005025253169417`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

## Certified infeasible boxes

- none

## Unresolved boxes

- none

## Support-cell audit for exported box
- schema: `support-cell-bounds.v1`
- support cells: `64`
- cell width: `0.09817477042468103`
- max cell upper violation: `-0.2266668880655951`

### Worst cells

- cell 63: upper violation `-0.2266668880655951`, direction interval `[6.1850105367549055, 6.283185307179586]`, container method `interval`, witness method `interval`
- cell 48: upper violation `-0.2285460409971909`, direction interval `[4.71238898038469, 4.81056375080937]`, container method `interval`, witness method `interval`
- cell 49: upper violation `-0.26941108006128855`, direction interval `[4.81056375080937, 4.908738521234052]`, container method `interval`, witness method `interval`
- cell 0: upper violation `-0.2719610906542036`, direction interval `[0.0, 0.09817477042468103]`, container method `interval`, witness method `interval`
- cell 50: upper violation `-0.3076815431493225`, direction interval `[4.908738521234052, 5.006913291658733]`, container method `interval`, witness method `interval`
- cell 62: upper violation `-0.32831172837403044`, direction interval `[6.086835766330224, 6.1850105367549055]`, container method `interval`, witness method `interval`
- cell 51: upper violation `-0.3429888647809838`, direction interval `[5.006913291658733, 5.105088062083414]`, container method `interval`, witness method `interval`
- cell 47: upper violation `-0.3661053846324651`, direction interval `[4.614214209960009, 4.71238898038469]`, container method `interval`, witness method `interval`
- cell 61: upper violation `-0.3749344223880895`, direction interval `[5.988660995905543, 6.086835766330224]`, container method `interval`, witness method `interval`
- cell 52: upper violation `-0.3749930161480224`, direction interval `[5.105088062083414, 5.203262832508095]`, container method `interval`, witness method `interval`
