# Witness-family coexistence certificate: outer-square

- schema: `witness-family-coexistence.v1`
- certificate kind: `product-space-feasibility-region`
- joint certified: `False`
- witness count: `2`
- joint pose dimension: `6`
- all refinements classified: `False`

## Interpretation
- Every tuple of poses chosen independently from the selected per-witness rigid-motion boxes is certified feasible for the corresponding witness in the common container.
- This does not certify disjointness or non-overlap among witnesses, and it does not force a single shared pose variable across different witnesses.

## Selected product region

### 00 `inner-triangle`
- bundle: `00_inner-triangle/bundle.json`
- selected box index: `3`
- theta audit interval: `[5.497787143782137, 6.283185307179586]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- certified upper violation: `-0.22666688806559554`

## Missing witnesses

- 01 `inner-square`: no certified feasible rigid-motion box exported
