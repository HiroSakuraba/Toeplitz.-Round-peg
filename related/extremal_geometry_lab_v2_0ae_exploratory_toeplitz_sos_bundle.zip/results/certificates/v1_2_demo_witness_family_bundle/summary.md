# Witness-family bundle: outer-square

- schema: `witness-family-bundle.v2`
- witness count: `2`
- joint coexistence path: `coexistence.json`
- joint certified: `False`

## Witness status

- 00 `inner-triangle`: feasible `True`, complete `True`, selected box `3`, bundle `00_inner-triangle/bundle.json`
- 01 `inner-square`: feasible `False`, complete `False`, selected box `None`, bundle `01_inner-square/bundle.json`