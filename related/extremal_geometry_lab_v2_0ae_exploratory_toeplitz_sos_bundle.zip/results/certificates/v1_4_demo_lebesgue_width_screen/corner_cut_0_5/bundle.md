# Width prescreen certificate: corner_cut_0_5

- schema: `width-prescreen.v1`
- family: `pal-descended`
- passed: `False`
- reason: `width-violated`
- required width: `1.0`
- certified lower width: `0.8639728561215865`

## Details
- worst cell: `[1.043106935762236, 1.055378782065321]`
- cell width: `0.01227184630308513`
- support methods: `['interval']`
