# Width prescreen certificate: pal_seed

- schema: `width-prescreen.v1`
- family: `pal-descended`
- passed: `True`
- reason: `width-ok`
- required width: `1.0`
- certified lower width: `1.7279457122431732`

## Details
- worst cell: `[1.043106935762236, 1.055378782065321]`
- cell width: `0.01227184630308513`
- support methods: `['interval']`
