# Lebesgue width-screen demo

This demo exercises the v1.4 width prescreen through the family-screen API.

## States

### pal_seed
- family: `pal-descended`
- passed: `True`
- reason: `width-ok`
- certified lower width: `1.7279457122431732`

### corner_cut_0_5
- family: `pal-descended`
- passed: `False`
- reason: `width-violated`
- certified lower width: `0.8639728561215865`
