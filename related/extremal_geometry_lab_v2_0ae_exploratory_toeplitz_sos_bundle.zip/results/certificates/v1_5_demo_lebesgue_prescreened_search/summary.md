# Lebesgue prescreened search demo

This demo runs bounded search in the Pál-descended Lebesgue family with the width prescreen active during proposal generation.

- proposals: `3`
- accepted: `2`
- rejected: `1`

## Proposals

### pal-seed-cut
- move history: `['small-corner-cut']`
- score: `-2.495192393383725`
- screen passed: `True`
- screen reason: `width-ok`
- corner cuts: `[0.02]`
- arc replacements: `[]`

### pal-seed
- move history: `[]`
- score: `-2.598076211353316`
- screen passed: `True`
- screen reason: `width-ok`
- corner cuts: `[]`
- arc replacements: `[]`

### pal-seed-cut
- move history: `['aggressive-corner-cut']`
- score: `-inf`
- screen passed: `False`
- screen reason: `width-violated`
- corner cuts: `[0.5]`
- arc replacements: `[]`
