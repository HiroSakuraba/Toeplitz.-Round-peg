# Lebesgue ranked sweep demo

This demo runs bounded search in the Pál-descended family with width-prescreen pruning and screen-slack-aware proposal ordering.

- depth: `2`
- proposals: `9`
- accepted: `6`
- rejected: `3`

## Seed

- polygon: `pal-seed`
- width slack: `0.7279457122431732`
- score: `-2.598076211353316`

## Accepted descendants (ordered)

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`
- score: `-2.5721604011450667`
- priority: `[0.7193059836819573, -2.5721604011450667, -1.0]`
- corner cuts: `[0.005]`
- arc replacements: `[]`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- width slack: `0.7107094537635477`
- score: `-2.546503101143645`
- priority: `[0.7107094537635477, -2.546503101143645, -2.0]`
- corner cuts: `[0.005, 0.005]`
- arc replacements: `[]`

### 3. pal-seed-cut
- move history: `['small-corner-cut']`
- width slack: `0.6933867979983097`
- score: `-2.495192393383725`
- priority: `[0.6933867979983097, -2.495192393383725, -1.0]`
- corner cuts: `[0.02]`
- arc replacements: `[]`

### 4. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'small-corner-cut']`
- width slack: `0.6849198640083181`
- score: `-2.4703028492597214`
- priority: `[0.6849198640083181, -2.4703028492597214, -2.0]`
- corner cuts: `[0.005, 0.02]`
- arc replacements: `[]`

### 5. pal-seed-cut-cut
- move history: `['small-corner-cut', 'small-corner-cut']`
- width slack: `0.6595190620383433`
- score: `-2.396382774605729`
- priority: `[0.6595190620383433, -2.396382774605729, -2.0]`
- corner cuts: `[0.02, 0.02]`
- arc replacements: `[]`

## Rejected descendants

### 1. pal-seed-cut
- move history: `['aggressive-corner-cut']`
- screen reason: `width-violated`
- width slack: `-0.13602714387841353`
- score: `-inf`
- priority: `[-0.13602714387841353, -inf, -1.0]`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'aggressive-corner-cut']`
- screen reason: `width-violated`
- width slack: `-0.14034700815902135`
- score: `-inf`
- priority: `[-0.14034700815902135, -inf, -2.0]`

### 3. pal-seed-cut-cut
- move history: `['small-corner-cut', 'aggressive-corner-cut']`
- screen reason: `width-violated`
- width slack: `-0.15330660100084514`
- score: `-inf`
- priority: `[-0.15330660100084514, -inf, -2.0]`
