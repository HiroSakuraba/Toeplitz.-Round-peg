# Beam width = 1 sweep

This demo compares width-prescreened Lebesgue bounded search with slack-aware ordering under a beam cap.

- depth: `2`
- beam width: `1`
- proposals: `5`
- accepted: `3`
- rejected: `2`

## Accepted descendants

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`
- score: `-2.5721604011450667`
- priority: `[0.7193059836819573, -2.5721604011450667, -1.0]`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- width slack: `0.7107094537635477`
- score: `-2.546503101143645`
- priority: `[0.7107094537635477, -2.546503101143645, -2.0]`

## Rejected descendants

### 1. pal-seed-cut
- move history: `['aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.13602714387841353`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.14034700815902135`
