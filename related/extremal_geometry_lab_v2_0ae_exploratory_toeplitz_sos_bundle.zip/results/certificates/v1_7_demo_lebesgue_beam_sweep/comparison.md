# Lebesgue beam sweep comparison

This comparison shows how beam truncation changes which width-screened descendants survive expansion.

- uncapped accepted descendants: `5`
- beam=1 accepted descendants: `2`

## Top uncapped descendant
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`

## Beam=1 surviving descendant
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`