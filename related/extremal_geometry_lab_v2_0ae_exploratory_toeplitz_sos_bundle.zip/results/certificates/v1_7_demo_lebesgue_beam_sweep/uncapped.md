# Uncapped sweep

This demo compares width-prescreened Lebesgue bounded search with slack-aware ordering under a beam cap.

- depth: `2`
- beam width: `None`
- proposals: `9`
- accepted: `6`
- rejected: `3`

## Accepted descendants

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`
- score: `-2.5721604011450667`
- priority: `[0.7193059836819573, -2.5721604011450667, -1.0]`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- width slack: `0.7107094537635477`
- score: `-2.546503101143645`
- priority: `[0.7107094537635477, -2.546503101143645, -2.0]`

### 3. pal-seed-cut
- move history: `['small-corner-cut']`
- width slack: `0.6933867979983097`
- score: `-2.495192393383725`
- priority: `[0.6933867979983097, -2.495192393383725, -1.0]`

### 4. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'small-corner-cut']`
- width slack: `0.6849198640083181`
- score: `-2.4703028492597214`
- priority: `[0.6849198640083181, -2.4703028492597214, -2.0]`

### 5. pal-seed-cut-cut
- move history: `['small-corner-cut', 'small-corner-cut']`
- width slack: `0.6595190620383433`
- score: `-2.396382774605729`
- priority: `[0.6595190620383433, -2.396382774605729, -2.0]`

## Rejected descendants

### 1. pal-seed-cut
- move history: `['aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.13602714387841353`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.14034700815902135`

### 3. pal-seed-cut-cut
- move history: `['small-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.15330660100084514`
