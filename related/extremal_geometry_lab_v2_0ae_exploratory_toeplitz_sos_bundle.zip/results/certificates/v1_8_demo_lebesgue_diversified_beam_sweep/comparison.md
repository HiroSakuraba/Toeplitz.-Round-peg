# Diversified beam comparison

This comparison shows how reserving diversified beam slots for distinct trim-parameter regions keeps search diversity under the Lebesgue width prescreen.

- greedy accepted descendants: `6`
- diversified accepted descendants: `6`
- greedy diversity families: `[('trim-region', 'heavy', 0), ('trim-region', 'light', 0), ('trim-region', 'moderate', 0)]`
- diversified diversity families: `[('trim-region', 'heavy', 0), ('trim-region', 'light', 0), ('trim-region', 'moderate', 0)]`