# Diversified beam width = 2

This demo compares greedy and diversified beam policies under the Lebesgue width prescreen.

- depth: `2`
- beam width: `3`
- beam policy: `diversified`
- beam diversity reserve: `2`
- proposals: `11`
- accepted: `7`
- rejected: `4`

## Accepted descendants

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- diversity family: `['trim-region', 'light', 0]`
- width slack: `0.7193059836819573`
- score: `-2.5721604011450667`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- diversity family: `['trim-region', 'light', 0]`
- width slack: `0.7107094537635477`
- score: `-2.546503101143645`

### 3. pal-seed-cut
- move history: `['small-corner-cut']`
- diversity family: `['trim-region', 'moderate', 0]`
- width slack: `0.6933867979983097`
- score: `-2.495192393383725`

### 4. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'small-corner-cut']`
- diversity family: `['trim-region', 'moderate', 0]`
- width slack: `0.6849198640083181`
- score: `-2.4703028492597214`

### 5. pal-seed-cut
- move history: `['medium-corner-cut']`
- diversity family: `['trim-region', 'heavy', 0]`
- width slack: `0.5897100552637193`
- score: `-2.199011705289447`

### 6. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'medium-corner-cut']`
- diversity family: `['trim-region', 'heavy', 0]`
- width slack: `0.5817615049874008`
- score: `-2.1770765635291847`

## Rejected descendants

### 1. pal-seed-cut
- move history: `['aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.13602714387841353`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.14034700815902135`

### 3. pal-seed-cut-cut
- move history: `['small-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.15330660100084514`

### 4. pal-seed-cut-cut
- move history: `['medium-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.20514497236814033`
