# Analytic interval-support demo

- container: `disk(2.0)`
- witness: `capsule(1.0,0.4)`
- passed: `True`
- certified upper violation: `-1.1`
- method: `interval-support-hook`
- body methods: `{'container': 'support-hook', 'target': 'support-hook'}`
- sample arc bounds: `[0.8844562108553224, 0.9]`
