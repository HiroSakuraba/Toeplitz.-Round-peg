# Extremal Geometry Lab v2.0aa — shadow spectral verifier demo

This demo runs the repaired cascade lane first, then attaches the fixed-theta shadow spectral verifier to the best pose and first feasible motion-box centers.

## `orbiform-stub`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.366025`
  - pose 0: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.366025`, truncated_gap_margin=`0.375694`, tail_sup_proxy=`0.009872`, shadow_lower_margin=`0.365822`
  - pose 1: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.366025`, truncated_gap_margin=`0.375694`, tail_sup_proxy=`0.009872`, shadow_lower_margin=`0.365822`
  - pose 2: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.366025`, truncated_gap_margin=`0.375694`, tail_sup_proxy=`0.009872`, shadow_lower_margin=`0.365822`

## `disk-half`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.370303`
  - pose 0: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.370303`, truncated_gap_margin=`0.378780`, tail_sup_proxy=`0.008477`, shadow_lower_margin=`0.370303`
  - pose 1: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.366025`, truncated_gap_margin=`0.375309`, tail_sup_proxy=`0.009283`, shadow_lower_margin=`0.366025`
  - pose 2: shadow=`shadow-truncation-positive`, sampled_gap_margin=`0.366025`, truncated_gap_margin=`0.375309`, tail_sup_proxy=`0.009283`, shadow_lower_margin=`0.366025`

## Summary
- lane_a_by_witness: `{'orbiform-stub': 'certified_feasible', 'disk-half': 'certified_feasible'}`
- lane_b_by_witness: `{'orbiform-stub': 'shadow-supportive', 'disk-half': 'shadow-supportive'}`