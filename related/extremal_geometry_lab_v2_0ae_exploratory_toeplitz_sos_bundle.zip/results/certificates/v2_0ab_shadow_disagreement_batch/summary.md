# Extremal Geometry Lab v2.0ab — shadow disagreement batch

This batch extends the shadow spectral lane from a focused demo into a disagreement detector over repaired cascade outputs.

Lane A remains the proof-facing interval/cascade certifier. Lane B remains fixed-theta shadow-only, but now logs width, Helly/LP, sampled-gap, truncation-proxy, and contact-direction comparison signals for the same sampled structures.

## `pal-seed`

### `orbiform-stub`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.366025`
- max shadow lower margin: `0.364450`
- max sampled gap margin: `0.366025`
- min LP margin: `0.366025`
- max contact overlap ratio: `0.500`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.009879`
- pose0 contact overlap ratio: `0.500`

### `disk-half`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.370303`
- max shadow lower margin: `0.370303`
- max sampled gap margin: `0.370303`
- min LP margin: `0.366025`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `segment`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.433012`
- max shadow lower margin: `0.429169`
- max sampled gap margin: `0.433012`
- min LP margin: `0.433012`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-3-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.366025`
- max shadow lower margin: `0.359818`
- max sampled gap margin: `0.366025`
- min LP margin: `0.288675`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-4-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.383062`
- max shadow lower margin: `0.382149`
- max sampled gap margin: `0.383062`
- min LP margin: `0.366025`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

## `small-cut`

### `orbiform-stub`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.348705`
- max shadow lower margin: `0.347130`
- max sampled gap margin: `0.348705`
- min LP margin: `0.348705`
- max contact overlap ratio: `0.500`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.009879`
- pose0 contact overlap ratio: `0.500`

### `disk-half`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.352982`
- max shadow lower margin: `0.352982`
- max sampled gap margin: `0.352982`
- min LP margin: `0.348705`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `segment`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.415692`
- max shadow lower margin: `0.411767`
- max sampled gap margin: `0.415692`
- min LP margin: `0.415692`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-3-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.348705`
- max shadow lower margin: `0.342165`
- max sampled gap margin: `0.348705`
- min LP margin: `0.271355`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-4-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.365742`
- max shadow lower margin: `0.364808`
- max sampled gap margin: `0.365742`
- min LP margin: `0.348705`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

## `moderate-cut`

### `orbiform-stub`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.296743`
- max shadow lower margin: `0.295168`
- max sampled gap margin: `0.296743`
- min LP margin: `0.296743`
- max contact overlap ratio: `0.500`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.009879`
- pose0 contact overlap ratio: `0.500`

### `disk-half`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.301021`
- max shadow lower margin: `0.301021`
- max sampled gap margin: `0.301021`
- min LP margin: `0.296743`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `segment`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.363730`
- max shadow lower margin: `0.359563`
- max sampled gap margin: `0.363730`
- min LP margin: `0.363730`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-3-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `8` / `0` / `0` / `8`
- best sampled margin: `0.296743`
- max shadow lower margin: `0.289204`
- max sampled gap margin: `0.296743`
- min LP margin: `0.224332`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-4-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.313780`
- max shadow lower margin: `0.312785`
- max sampled gap margin: `0.313780`
- min LP margin: `0.296743`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

## `small-arc-rounding`

### `orbiform-stub`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.358705`
- max shadow lower margin: `0.357130`
- max sampled gap margin: `0.358705`
- min LP margin: `0.358705`
- max contact overlap ratio: `0.500`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.009879`
- pose0 contact overlap ratio: `0.500`

### `disk-half`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.362982`
- max shadow lower margin: `0.362982`
- max sampled gap margin: `0.362982`
- min LP margin: `0.358705`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `segment`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.425692`
- max shadow lower margin: `0.421767`
- max sampled gap margin: `0.425692`
- min LP margin: `0.425692`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-3-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.358705`
- max shadow lower margin: `0.352165`
- max sampled gap margin: `0.358705`
- min LP margin: `0.281355`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

### `regular-4-gon`
- lane A: `certified_feasible`
- lane B: `shadow-supportive`
- disagreement taxon: `agreement-feasible`
- feasible / infeasible / unresolved / explored: `4` / `0` / `0` / `4`
- best sampled margin: `0.375742`
- max shadow lower margin: `0.374808`
- max sampled gap margin: `0.375742`
- min LP margin: `0.358705`
- max contact overlap ratio: `1.000`
- pose0 shadow / Helly: `shadow-truncation-positive` / `lp-feasible-margin-positive`
- pose0 width_passed: `True`
- pose0 LP shift norm: `0.000000`
- pose0 contact overlap ratio: `1.000`

## Summary
- lane_a_matrix: `{'pal-seed': {'orbiform-stub': 'certified_feasible', 'disk-half': 'certified_feasible', 'segment': 'certified_feasible', 'regular-3-gon': 'certified_feasible', 'regular-4-gon': 'certified_feasible'}, 'small-cut': {'orbiform-stub': 'certified_feasible', 'disk-half': 'certified_feasible', 'segment': 'certified_feasible', 'regular-3-gon': 'certified_feasible', 'regular-4-gon': 'certified_feasible'}, 'moderate-cut': {'orbiform-stub': 'certified_feasible', 'disk-half': 'certified_feasible', 'segment': 'certified_feasible', 'regular-3-gon': 'certified_feasible', 'regular-4-gon': 'certified_feasible'}, 'small-arc-rounding': {'orbiform-stub': 'certified_feasible', 'disk-half': 'certified_feasible', 'segment': 'certified_feasible', 'regular-3-gon': 'certified_feasible', 'regular-4-gon': 'certified_feasible'}}`
- lane_b_matrix: `{'pal-seed': {'orbiform-stub': 'shadow-supportive', 'disk-half': 'shadow-supportive', 'segment': 'shadow-supportive', 'regular-3-gon': 'shadow-supportive', 'regular-4-gon': 'shadow-supportive'}, 'small-cut': {'orbiform-stub': 'shadow-supportive', 'disk-half': 'shadow-supportive', 'segment': 'shadow-supportive', 'regular-3-gon': 'shadow-supportive', 'regular-4-gon': 'shadow-supportive'}, 'moderate-cut': {'orbiform-stub': 'shadow-supportive', 'disk-half': 'shadow-supportive', 'segment': 'shadow-supportive', 'regular-3-gon': 'shadow-supportive', 'regular-4-gon': 'shadow-supportive'}, 'small-arc-rounding': {'orbiform-stub': 'shadow-supportive', 'disk-half': 'shadow-supportive', 'segment': 'shadow-supportive', 'regular-3-gon': 'shadow-supportive', 'regular-4-gon': 'shadow-supportive'}}`
- disagreement_counts: `{'agreement-feasible': 20}`
- non_agreement_case_count: `0`
- total_runtime_sec: `39.946`

## Disagreement ledger
- no non-agreement cases in this batch