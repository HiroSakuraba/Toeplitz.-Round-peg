# Extremal Geometry Lab v2.0ac — shadow tension batch

This batch keeps Lane A as the global certifier for the seed pose, then constructs two translation-tension descendants of that pose: a near-boundary feasible sample and an explicit negative control. Lane B is then run on all three poses using the first real truncation module.

## `pal-seed`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.366025`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.366025`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.323231`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036603`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.006192`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037603`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.080397`, trunc_module=`empirical-k2-tail-envelope`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.370303`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.370303`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.343905`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.037030`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.010632`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.038030`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.064428`, trunc_module=`empirical-k2-tail-envelope`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.433012`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.433523`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.426478`, trunc_module=`observed-tail-plus-grid`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.043352`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.036865`, trunc_module=`observed-tail-plus-grid`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.044352`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.050759`, trunc_module=`observed-tail-plus-grid`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.366025`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.366025`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.306402`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036603`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.022128`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037603`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.096132`, trunc_module=`empirical-k2-tail-envelope`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.383062`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.384349`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.351623`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.038435`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.005909`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.039435`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.071924`, trunc_module=`empirical-k2-tail-envelope`

## `small-cut`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.348705`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.348705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.306408`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.034870`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.007426`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.035870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.078167`, trunc_module=`empirical-k2-tail-envelope`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.352982`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.352982`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.327099`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035298`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.009415`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036298`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.062182`, trunc_module=`empirical-k2-tail-envelope`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.415692`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.416182`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.408942`, trunc_module=`observed-tail-plus-grid`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.041618`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.034950`, trunc_module=`observed-tail-plus-grid`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.042618`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.049191`, trunc_module=`observed-tail-plus-grid`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.348705`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.348705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.289345`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.034870`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.023590`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.035870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.094140`, trunc_module=`empirical-k2-tail-envelope`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.365742`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.367008`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.334751`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036701`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.004669`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037701`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.069697`, trunc_module=`empirical-k2-tail-envelope`

## `moderate-cut`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.296743`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.296743`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.255940`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.029674`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.011129`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.030674`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.071478`, trunc_module=`empirical-k2-tail-envelope`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.301021`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.301021`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.276681`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.030102`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.005762`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.031102`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.055442`, trunc_module=`empirical-k2-tail-envelope`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.363730`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.364159`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.356335`, trunc_module=`observed-tail-plus-grid`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036416`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.029091`, trunc_module=`observed-tail-plus-grid`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037416`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.044628`, trunc_module=`observed-tail-plus-grid`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.296743`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.296743`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.238111`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.029674`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.027978`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.030674`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.088163`, trunc_module=`empirical-k2-tail-envelope`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.313780`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.314985`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.284134`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.031499`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.000909`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.032499`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.063029`, trunc_module=`empirical-k2-tail-envelope`

## `small-arc-rounding`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.358705`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.358705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.316408`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035870`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.006426`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.079167`, trunc_module=`empirical-k2-tail-envelope`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.362982`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.362982`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.337099`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036298`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.010415`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037298`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.063182`, trunc_module=`empirical-k2-tail-envelope`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.425692`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.426182`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.418942`, trunc_module=`observed-tail-plus-grid`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.042618`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.035963`, trunc_module=`observed-tail-plus-grid`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.043618`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.050180`, trunc_module=`observed-tail-plus-grid`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.358705`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.358705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.299345`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035870`, shadow=`sampled-feasible-with-helly`, shadow_lower_margin=`-0.022566`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.095110`, trunc_module=`empirical-k2-tail-envelope`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.375742`
- base truncation module: `empirical-k2-tail-envelope`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.377008`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.344751`, trunc_module=`empirical-k2-tail-envelope`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.037701`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.005673`, trunc_module=`empirical-k2-tail-envelope`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.038701`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.070692`, trunc_module=`empirical-k2-tail-envelope`

## Summary
- base_case_count: `20`
- base_agreement_feasible_count: `20`
- tension_pose_count: `60`
- truncation_module_counts: `{'empirical-k2-tail-envelope': 48, 'observed-tail-plus-grid': 12}`
- tension_shadow_status_counts: `{'certified-seed-pose': {'shadow-truncation-positive': 20}, 'near-boundary-feasible': {'sampled-feasible-with-helly': 8, 'shadow-truncation-positive': 12}, 'negative-control': {'shadow-inconclusive': 20}}`
- runtime_sec: `55.467`