# Extremal Geometry Lab v2.0ad — shadow tension batch (Fix 1: high-k tail-fit envelope)

This batch keeps Lane A as the global certifier for the seed pose, then constructs two translation-tension descendants of that pose: a near-boundary feasible sample and an explicit negative control. Lane B is then run on all three poses using the same batch harness as v2.0ac, but with the all-k tail envelope replaced by a high-k tail-fit envelope with a conservative monotone cap.

## `pal-seed`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.366025`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.366025`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.338729`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.063009`, new_tail=`0.047511`, tail_ratio=`0.13`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036603`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.009306`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.063009`, new_tail=`0.047511`, tail_ratio=`1.298`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037603`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.064899`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.063009`, new_tail=`0.047511`, tail_ratio=`-1.264`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.370303`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.370303`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.344680`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.044470`, new_tail=`0.043694`, tail_ratio=`0.118`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.037030`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.011408`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.044470`, new_tail=`0.043694`, tail_ratio=`1.18`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.038030`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.063653`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.044470`, new_tail=`0.043694`, tail_ratio=`-1.149`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.433012`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.433523`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.426497`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019996`, new_tail=`0.019977`, tail_ratio=`0.046`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.043352`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.036884`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019996`, new_tail=`0.019977`, tail_ratio=`0.461`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.044352`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.050740`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019996`, new_tail=`0.019977`, tail_ratio=`-0.45`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.366025`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.366025`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.337444`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.070163`, new_tail=`0.039121`, tail_ratio=`0.107`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036603`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.008914`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.070163`, new_tail=`0.039121`, tail_ratio=`1.069`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037603`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.065090`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.070163`, new_tail=`0.039121`, tail_ratio=`-1.04`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.383062`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.384349`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.366649`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.049883`, new_tail=`0.034857`, tail_ratio=`0.091`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.038435`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.020935`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.049883`, new_tail=`0.034857`, tail_ratio=`0.907`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.039435`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.056898`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.049883`, new_tail=`0.034857`, tail_ratio=`-0.884`

## `small-cut`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.348705`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.348705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.321907`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`0.134`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.034870`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.008073`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`1.336`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.035870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.062668`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`-1.299`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.352982`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.352982`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.327859`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`0.121`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035298`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.010175`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`1.212`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036298`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.061422`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`-1.178`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.415692`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.416182`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.408960`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`0.047`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.041618`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.034968`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`0.472`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.042618`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.049172`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`-0.461`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.348705`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.348705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.319774`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`0.111`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.034870`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.006838`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`1.113`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.035870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.063711`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`-1.082`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.365742`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.367008`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.349761`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`0.092`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036701`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.019679`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`0.925`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037701`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.054688`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`-0.9`

## `moderate-cut`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.296743`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.296743`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.271442`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.059345`, new_tail=`0.043843`, tail_ratio=`0.148`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.029674`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.004373`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.059345`, new_tail=`0.043843`, tail_ratio=`1.477`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.030674`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.055975`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.059345`, new_tail=`0.043843`, tail_ratio=`-1.429`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.301021`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.301021`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.277395`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.040739`, new_tail=`0.040025`, tail_ratio=`0.133`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.030102`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.006476`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.040739`, new_tail=`0.040025`, tail_ratio=`1.33`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.031102`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.054728`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.040739`, new_tail=`0.040025`, tail_ratio=`-1.287`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.363730`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.364159`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.356351`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.018680`, new_tail=`0.018663`, tail_ratio=`0.051`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036416`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.029107`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.018680`, new_tail=`0.018663`, tail_ratio=`0.513`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037416`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.044612`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.018680`, new_tail=`0.018663`, tail_ratio=`-0.499`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.296743`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.296743`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.266700`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.066432`, new_tail=`0.037842`, tail_ratio=`0.128`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.029674`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.000611`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.066432`, new_tail=`0.037842`, tail_ratio=`1.275`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.030674`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.059574`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.066432`, new_tail=`0.037842`, tail_ratio=`-1.234`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.313780`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.314985`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.298278`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.046153`, new_tail=`0.032009`, tail_ratio=`0.102`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.031499`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.015053`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.046153`, new_tail=`0.032009`, tail_ratio=`1.016`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.032499`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.048885`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.046153`, new_tail=`0.032009`, tail_ratio=`-0.985`

## `small-arc-rounding`

### `orbiform-stub`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.358705`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.358705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.331907`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`0.13`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035870`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.009073`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`1.299`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.063668`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.062093`, new_tail=`0.046594`, tail_ratio=`-1.264`

### `disk-half`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.362982`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.362982`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.337859`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`0.118`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.036298`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.011175`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`1.178`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.037298`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.062422`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.043537`, new_tail=`0.042777`, tail_ratio=`-1.147`

### `segment`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.425692`
- base truncation module: `observed-tail-plus-grid`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.426182`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.418960`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`0.046`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.042618`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.035982`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`0.461`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.043618`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.050162`, trunc_module=`observed-tail-plus-grid`, prior_tail=`0.019667`, new_tail=`0.019649`, tail_ratio=`-0.45`

### `regular-3-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.358705`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.358705`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.329774`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`0.108`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.035870`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.007863`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`1.082`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.036870`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.064681`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.069230`, new_tail=`0.038801`, tail_ratio=`-1.052`

### `regular-4-gon`
- base lane A / lane B / disagreement: `certified_feasible` / `shadow-supportive` / `agreement-feasible`
- base sampled margin: `0.375742`
- base truncation module: `high-k-k2-tail-envelope-monotone-cap`
  - `certified-seed-pose`: sampled_status=`sampled-feasible`, sampled_margin=`0.377008`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.359761`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`0.09`
  - `near-boundary-feasible`: sampled_status=`sampled-feasible`, sampled_margin=`0.037701`, shadow=`shadow-truncation-positive`, shadow_lower_margin=`0.020683`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`0.9`
  - `negative-control`: sampled_status=`sampled-infeasible`, sampled_margin=`-0.038701`, shadow=`shadow-inconclusive`, shadow_lower_margin=`-0.055682`, trunc_module=`high-k-k2-tail-envelope-monotone-cap`, prior_tail=`0.048951`, new_tail=`0.033941`, tail_ratio=`-0.877`

## Summary
- base_case_count: `20`
- base_agreement_feasible_count: `20`
- tension_pose_count: `60`
- truncation_module_counts: `{'high-k-k2-tail-envelope-monotone-cap': 48, 'observed-tail-plus-grid': 12}`
- tension_shadow_status_counts: `{'certified-seed-pose': {'shadow-truncation-positive': 20}, 'near-boundary-feasible': {'shadow-truncation-positive': 20}, 'negative-control': {'shadow-inconclusive': 20}}`
- delta_vs_v2_0ac: `{'compared_case_count': 60, 'tail_delta_min': -0.03104202663170247, 'tail_delta_max': -1.6162379707983926e-05, 'tail_delta_mean': -0.012237873364367722}`
- unresolved_near_boundary_holdouts: `[]`
- runtime_sec: `50.756`