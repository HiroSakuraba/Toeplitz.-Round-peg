# Extremal Geometry Lab v2.0ae — exploratory fixed-theta Toeplitz SOS lane

This is a restricted fixed-\(	heta\) SOS experiment on the formerly truncation-limited witness/state pairs. Instead of a full SDP solve, it uses the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of this matrix is a sufficient certificate for nonnegativity of the truncated polynomial, but failure is only a failure of this restricted ansatz, not of the full SDP problem.

## `pal-seed`

### `orbiform-stub`

- `near-boundary-feasible`: sampled_margin=`0.036603`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`2.883829e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`0.009306`
- `negative-control`: sampled_margin=`-0.037603`, status=`toeplitz-gram-indefinite`, min_eig=`-1.638433e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`-0.064899`

### `regular-3-gon`

- `near-boundary-feasible`: sampled_margin=`0.036603`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`1.964597e-03`, coeff_resid=`5.551e-16`, shadow_lower_margin=`0.008914`
- `negative-control`: sampled_margin=`-0.037603`, status=`toeplitz-gram-indefinite`, min_eig=`-2.557032e-03`, coeff_resid=`5.551e-16`, shadow_lower_margin=`-0.065090`

## `small-cut`

### `orbiform-stub`

- `near-boundary-feasible`: sampled_margin=`0.034870`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`2.787821e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`0.008073`
- `negative-control`: sampled_margin=`-0.035870`, status=`toeplitz-gram-indefinite`, min_eig=`-1.521734e-03`, coeff_resid=`3.331e-16`, shadow_lower_margin=`-0.062668`

### `regular-3-gon`

- `near-boundary-feasible`: sampled_margin=`0.034870`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`1.854063e-03`, coeff_resid=`6.106e-16`, shadow_lower_margin=`0.006838`
- `negative-control`: sampled_margin=`-0.035870`, status=`toeplitz-gram-indefinite`, min_eig=`-2.455071e-03`, coeff_resid=`6.661e-16`, shadow_lower_margin=`-0.063711`

## `moderate-cut`

### `orbiform-stub`

- `near-boundary-feasible`: sampled_margin=`0.029674`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`2.497958e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`0.004373`
- `negative-control`: sampled_margin=`-0.030674`, status=`toeplitz-gram-indefinite`, min_eig=`-1.173428e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`-0.055975`

### `regular-3-gon`

- `near-boundary-feasible`: sampled_margin=`0.029674`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`1.517110e-03`, coeff_resid=`5.551e-16`, shadow_lower_margin=`0.000544`
- `negative-control`: sampled_margin=`-0.030674`, status=`toeplitz-gram-indefinite`, min_eig=`-2.154647e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`-0.059613`

## `small-arc-rounding`

### `orbiform-stub`

- `near-boundary-feasible`: sampled_margin=`0.035870`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`2.828372e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`0.009073`
- `negative-control`: sampled_margin=`-0.036870`, status=`toeplitz-gram-indefinite`, min_eig=`-1.604468e-03`, coeff_resid=`4.441e-16`, shadow_lower_margin=`-0.063668`

### `regular-3-gon`

- `near-boundary-feasible`: sampled_margin=`0.035870`, status=`toeplitz-gram-psd-shadow-positive`, min_eig=`1.894520e-03`, coeff_resid=`5.551e-16`, shadow_lower_margin=`0.007863`
- `negative-control`: sampled_margin=`-0.036870`, status=`toeplitz-gram-indefinite`, min_eig=`-2.537521e-03`, coeff_resid=`6.661e-16`, shadow_lower_margin=`-0.064681`

## Summary
- case_count: `16`
- status_counts: `{'toeplitz-gram-psd-shadow-positive': 8, 'toeplitz-gram-indefinite': 8}`
- pose_label_status_counts: `{'near-boundary-feasible': {'toeplitz-gram-psd-shadow-positive': 8}, 'negative-control': {'toeplitz-gram-indefinite': 8}}`
- runtime_sec: `14.432`