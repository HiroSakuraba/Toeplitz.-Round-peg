# Lebesgue arc/segment candidate demo

This demo runs the Lebesgue search lane after wiring in actual rounded arc/segment candidates.

- proposals: `7`
- accepted: `6`
- rejected: `1`
- arc candidates: `2`

## Arc candidates

### ['small-arc-rounding']
- passed: `True`
- reason: `width-ok`
- score: `-2.5543065806887224`
- polygon surrogate: `recon[pal-seed-cut+arc(0.01)]`
- support methods: `['analytic-interval']`
- body name: `pal-seed-cut+arc(0.01)`
- certified lower width: `1.7133867979983097`
- arc replacements: `[{'type': 'rounded-minkowski', 'cut': 0.02, 'radius': 0.01}]`

### ['heavy-arc-rounding']
- passed: `True`
- reason: `width-ok`
- score: `-2.282518626725694`
- polygon surrogate: `recon[pal-seed-cut+arc(0.015)]`
- support methods: `['analytic-interval']`
- body name: `pal-seed-cut+arc(0.015)`
- certified lower width: `1.6197100552637194`
- arc replacements: `[{'type': 'rounded-minkowski', 'cut': 0.08, 'radius': 0.015}]`
