# Support-signature beam comparison

This comparison shows how reserving diversified beam slots for distinct support-signature buckets preserves geometrically different Lebesgue descendants.

- greedy accepted descendants: `6`
- diversified accepted descendants: `6`
- greedy diversity keys: `[('support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6)]`
- diversified diversity keys: `[('support-signature', 46, 652, 5, 5, 5, 6, 5, 5, 5, 6), ('support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6), ('support-signature', 49, 653, 5, 5, 5, 6, 5, 5, 5, 6)]`