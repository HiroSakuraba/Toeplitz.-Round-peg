# Diversified beam width = 3

This demo compares greedy and diversified beam policies using support-signature geometric diversity.

- depth: `2`
- beam width: `3`
- beam policy: `diversified`
- beam diversity reserve: `2`
- proposals: `11`
- accepted: `7`
- rejected: `4`

## Accepted descendants

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- diameter: `1.99`
- shape ratio: `0.649519052838329`
- width slack: `0.7193059836819573`
- score: `-2.5721604011450667`

### 2. recon[pal-seed-cut+arc(0.01)]
- move history: `['small-arc-rounding']`
- diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- diameter: `1.98`
- shape ratio: `0.6515423376922566`
- width slack: `0.7133867979983097`
- score: `-2.5543065806887224`

### 3. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- diameter: `1.98005`
- shape ratio: `0.649519052838329`
- width slack: `0.7107094537635477`
- score: `-2.546503101143645`

### 4. recon[pal-seed-cut-cut+arc(0.01)]
- move history: `['tiny-corner-cut', 'small-arc-rounding']`
- diversity key: `['support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6]`
- diameter: `1.9702`
- shape ratio: `0.651552368583623`
- width slack: `0.7049198640083181`
- score: `-2.529123036564721`

### 5. recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]
- move history: `['small-arc-rounding', 'small-arc-rounding']`
- diversity key: `['support-signature', 49, 653, 5, 5, 5, 6, 5, 5, 5, 6]`
- diameter: `1.9604`
- shape ratio: `0.6535519472341392`
- width slack: `0.6990162676355665`
- score: `-2.511710034516244`

### 6. recon[pal-seed-cut+arc(0.015)]
- move history: `['heavy-arc-rounding']`
- diversity key: `['support-signature', 46, 652, 5, 5, 5, 6, 5, 5, 5, 6]`
- diameter: `1.87`
- shape ratio: `0.6527263080802121`
- width slack: `0.6197100552637194`
- score: `-2.282518626725694`

## Rejected descendants

### 1. pal-seed-cut
- move history: `['aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.13602714387841353`

### 2. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.14034700815902135`

### 3. recon[pal-seed-cut+arc(0.01)]-cut
- move history: `['small-arc-rounding', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.14335904712471093`

### 4. recon[pal-seed-cut+arc(0.015)]-cut
- move history: `['heavy-arc-rounding', 'aggressive-corner-cut']`
- reason: `width-violated`
- width slack: `-0.19022364155393912`
