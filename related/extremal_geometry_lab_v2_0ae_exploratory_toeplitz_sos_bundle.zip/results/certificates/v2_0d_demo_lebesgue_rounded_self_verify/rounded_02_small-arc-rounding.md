# Rounded candidate certificate: rounded_02_small-arc-rounding

- schema: `rounded-candidate-self-verify.v1`
- family: `lebesgue-rounded`
- claim: `width-prescreen-pass`
- required width: `1.0`
- certified lower width: `1.7133867979983097`
- support methods: `['analytic-interval']`

## Construction
- kind: `rounded-minkowski`
- base polygon: `pal-seed-cut`
- rounded radius: `0.01`
- arc replacements: `[{'type': 'rounded-minkowski', 'cut': 0.02, 'radius': 0.01}]`

## Independent verification
Replay the rounded candidate as a Minkowski sum of the stored base polygon and a disk of the stored rounding radius. For each angular cell [theta_j, theta_{j+1}], lower-bound the width by combining a lower bound for the base polygon support on that cell and on the antipodal cell, then add 2*r for the disk summand. The minimum over cells is the certified lower width. If it is at least the required width, the candidate passes the width prescreen.
