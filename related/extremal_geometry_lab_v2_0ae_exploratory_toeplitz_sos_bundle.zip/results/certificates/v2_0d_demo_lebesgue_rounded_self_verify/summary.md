# Rounded candidate self-verifying bundle demo

- bundle count: `2`

## rounded_02_small-arc-rounding
- move history: `['small-arc-rounding']`
- claim: `width-prescreen-pass`
- certified lower width: `1.7133867979983097`
- support methods: `['analytic-interval']`
- rounded radius: `0.01`

## rounded_04_heavy-arc-rounding
- move history: `['heavy-arc-rounding']`
- claim: `width-prescreen-pass`
- certified lower width: `1.6197100552637194`
- support methods: `['analytic-interval']`
- rounded radius: `0.015`
