# Helly-style pruning demo

- container: `disk(1.0)`
- witness: `disk(1.3)`
- certified infeasible boxes: `1`
- Helly-pruned boxes: `1`

## Helly-pruned box 0
- theta width: `6.283185307179586`
- certified upper violation: `0.6700293086373212`
- center sampled max violation: `0.30000000000000004`
- pose drift bound: `0.3535533905932738`
- infeasible reason: `helly`
