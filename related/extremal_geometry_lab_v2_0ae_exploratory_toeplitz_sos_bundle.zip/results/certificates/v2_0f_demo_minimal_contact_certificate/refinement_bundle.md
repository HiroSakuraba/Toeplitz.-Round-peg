# Rigid-motion certificate bundle: inner-triangle in outer-square

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `22`
- certified infeasible boxes: `0`
- unresolved boxes: `8`
- explored boxes: `52`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.3000000000000004, 0.09999999999999953)`
- sampled margin: `1.5`
- sampled max violation: `-1.5`
- certified upper violation: `-1.2900260435657231`

## Certified feasible boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.039310911305563856`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.34382009730547924`
- midpoint sampled margin: `0.9726280307544617`
- midpoint sampled max violation: `-0.9726280307544617`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.052363530527569146`
- midpoint sampled margin: `1.0050252531694168`
- midpoint sampled max violation: `-1.0050252531694168`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.17635152635282791`
- midpoint sampled margin: `1.0222089669662462`
- midpoint sampled max violation: `-1.0222089669662462`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.17620527040028522`
- midpoint sampled margin: `0.8691355940202106`
- midpoint sampled max violation: `-0.8691355940202106`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.03931091130556319`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.046915948518939876`
- midpoint sampled margin: `0.7226280307544621`
- midpoint sampled max violation: `-0.7226280307544621`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[3.141592653589793, 0.0]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.039310911305563856`
- midpoint sampled margin: `1.1`
- midpoint sampled max violation: `-1.1`
- pose drift bound: `1.9735232668566534`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.05236353052756848`
- midpoint sampled margin: `0.9343145750507622`
- midpoint sampled max violation: `-0.9343145750507622`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.17635152635282814`
- midpoint sampled margin: `1.0222089669662464`
- midpoint sampled max violation: `-1.0222089669662464`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.038291292608471084`
- midpoint sampled margin: `0.7226280307544619`
- midpoint sampled max violation: `-0.7226280307544619`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.052363530527569146`
- midpoint sampled margin: `0.934314575050762`
- midpoint sampled max violation: `-0.934314575050762`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.17635152635282814`
- midpoint sampled margin: `1.022208966966246`
- midpoint sampled max violation: `-1.022208966966246`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 13
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.03829129260847175`
- midpoint sampled margin: `0.7226280307544615`
- midpoint sampled max violation: `-0.7226280307544615`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[0.0, 3.141592653589793]`
- translation box: `[0.0, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.039310911305563634`
- midpoint sampled margin: `1.1000000000000005`
- midpoint sampled max violation: `-1.1000000000000005`
- pose drift bound: `1.9735232668566534`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.17635152635282814`
- midpoint sampled margin: `1.0222089669662462`
- midpoint sampled max violation: `-1.0222089669662462`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 16
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.17620527040028522`
- midpoint sampled margin: `0.8691355940202099`
- midpoint sampled max violation: `-0.8691355940202099`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-1.0, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.039310911305563634`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 18
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.5, 0.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.0469159485189401`
- midpoint sampled margin: `0.7226280307544615`
- midpoint sampled max violation: `-0.7226280307544615`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.03931091130556319`
- midpoint sampled margin: `0.7991647172274798`
- midpoint sampled max violation: `-0.7991647172274798`
- pose drift bound: `1.023710902604074`
- certification method: `interval`
- depth: `2`

### Box 20
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.5, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `-0.34382009730547813`
- midpoint sampled margin: `0.9726280307544621`
- midpoint sampled max violation: `-0.9726280307544621`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.0, 0.0] x [-1.0, 0.0]`
- l2 translation radius: `0.7071067811865476`
- certified upper violation: `-0.052363530527569146`
- midpoint sampled margin: `1.005025253169417`
- midpoint sampled max violation: `-1.005025253169417`
- pose drift bound: `1.3403150240216004`
- certification method: `interval`
- depth: `1`

## Certified infeasible boxes

- none

## Unresolved boxes

### Box 0
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.01834714759108569`
- midpoint sampled margin: `0.4726280307544617`
- midpoint sampled max violation: `-0.4726280307544617`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.026971803501555147`
- midpoint sampled margin: `0.4726280307544617`
- midpoint sampled max violation: `-0.4726280307544617`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.5, 1.0] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.01834714759108569`
- midpoint sampled margin: `0.7226280307544621`
- midpoint sampled max violation: `-0.7226280307544621`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.026971803501555147`
- midpoint sampled margin: `0.6191355940202103`
- midpoint sampled max violation: `-0.6191355940202103`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.5, 1.0] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.02697180350155426`
- midpoint sampled margin: `0.6191355940202099`
- midpoint sampled max violation: `-0.6191355940202099`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.026971803501554925`
- midpoint sampled margin: `0.4726280307544619`
- midpoint sampled max violation: `-0.4726280307544619`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-1.0, -0.5] x [0.0, 1.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.018347147591085466`
- midpoint sampled margin: `0.7226280307544617`
- midpoint sampled max violation: `-0.7226280307544617`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.0, -0.5] x [-1.0, 0.0]`
- l2 translation radius: `0.5590169943749475`
- certified upper violation: `0.018347147591085466`
- midpoint sampled margin: `0.47262803075446214`
- midpoint sampled max violation: `-0.47262803075446214`
- pose drift bound: `0.8756211157924738`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[12, 24, 36]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`

## Support-cell audit for exported box
- schema: `support-cell-bounds.v1`
- support cells: `48`
- cell width: `0.1308996938995747`
- max cell upper violation: `-0.039310911305563856`

### Worst cells

- cell 11: upper violation `-0.039310911305563856`, direction interval `[1.4398966328953218, 1.5707963267948966]`, container method `interval`, witness method `interval`
- cell 10: upper violation `-0.11675822603165642`, direction interval `[1.308996938995747, 1.4398966328953218]`, container method `interval`, witness method `interval`
- cell 0: upper violation `-0.11768085829458053`, direction interval `[0.0, 0.1308996938995747]`, container method `interval`, witness method `interval`
- cell 1: upper violation `-0.1506753213769758`, direction interval `[0.1308996938995747, 0.2617993877991494]`, container method `interval`, witness method `interval`
- cell 9: upper violation `-0.1785195533369479`, direction interval `[1.1780972450961724, 1.308996938995747]`, container method `interval`, witness method `interval`
- cell 2: upper violation `-0.18109168793552`, direction interval `[0.2617993877991494, 0.39269908169872414]`, container method `interval`, witness method `interval`
- cell 12: upper violation `-0.1828897227476205`, direction interval `[1.5707963267948966, 1.7016960206944711]`, container method `interval`, witness method `interval`
- cell 3: upper violation `-0.20840952550538638`, direction interval `[0.39269908169872414, 0.5235987755982988]`, container method `interval`, witness method `interval`
- cell 8: upper violation `-0.22353813978776937`, direction interval `[1.0471975511965976, 1.1780972450961724]`, container method `interval`, witness method `interval`
- cell 4: upper violation `-0.23216141831181858`, direction interval `[0.5235987755982988, 0.6544984694978735]`, container method `interval`, witness method `interval`

## Independent verification
- the machine payload includes `self_verifying_certificate` with the exact box, geometry payload when available, and a replay algorithm summary.
