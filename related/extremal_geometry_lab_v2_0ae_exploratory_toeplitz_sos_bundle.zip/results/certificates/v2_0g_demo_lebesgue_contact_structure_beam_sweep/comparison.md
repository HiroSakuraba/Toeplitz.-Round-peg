# Contact-structure beam comparison

This comparison shows how a search signal built from minimal active-contact certificates changes which Lebesgue descendants survive diversified beam truncation.

- support-only descendants: `[('heavy-arc-rounding',)]`
- contact-only descendants: `[('small-corner-cut',)]`