# Support-signature diversified beam

This demo compares the existing support-signature search policy with the new contact-structure search signal.

- structure signal: `None`
- proposals: `11`
- accepted: `7`
- rejected: `4`

## Accepted descendants

### 1. pal-seed-cut
- move history: `['tiny-corner-cut']`
- width slack: `0.7193059836819573`
- priority: `[0.7193059836819573, -2.5721604011450667, -1.0]`
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`

### 2. recon[pal-seed-cut+arc(0.01)]
- move history: `['small-arc-rounding']`
- width slack: `0.7133867979983097`
- priority: `[0.7133867979983097, -2.5543065806887237, -1.0]`
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`

### 3. pal-seed-cut-cut
- move history: `['tiny-corner-cut', 'tiny-corner-cut']`
- width slack: `0.7107094537635477`
- priority: `[0.7107094537635477, -2.546503101143645, -2.0]`
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`

### 4. recon[pal-seed-cut-cut+arc(0.01)]
- move history: `['tiny-corner-cut', 'small-arc-rounding']`
- width slack: `0.7049198640083181`
- priority: `[0.7049198640083181, -2.529123036564718, -2.0]`
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`

### 5. recon[pal-seed-cut+arc(0.01)]-cut
- move history: `['small-arc-rounding', 'tiny-corner-cut']`
- width slack: `0.7047154962218252`
- priority: `[0.7047154962218252, -2.528827372546354, -2.0]`
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`

### 6. recon[pal-seed-cut+arc(0.015)]
- move history: `['heavy-arc-rounding']`
- width slack: `0.6197100552637194`
- priority: `[0.6197100552637194, -2.282518626725693, -1.0]`
- support diversity key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `None`
- contact cardinality: `None`
- contact gap signature: `None`
- contact verification method: `None`
