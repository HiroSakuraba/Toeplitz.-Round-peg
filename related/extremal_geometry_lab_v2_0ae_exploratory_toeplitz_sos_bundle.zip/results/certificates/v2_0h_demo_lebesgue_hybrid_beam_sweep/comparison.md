# Hybrid beam comparison

- support descendants: **6**
- contact descendants: **6**
- hybrid descendants: **6**

- hybrid unique support keys: `[('support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6), ('support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6), ('support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6)]`
- hybrid unique contact keys: `[('contact-signature', 'segment', 3, 2, 18, 4), ('contact-signature', 'segment', 3, 4, 8, 12), ('contact-signature', 'segment', 3, 4, 12, 8)]`