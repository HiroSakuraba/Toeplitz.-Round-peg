# Hybrid diversified beam

- structure signal: `hybrid`
- accepted descendants: **6**

## tiny-corner-cut
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 4, 12, 8]`

## small-arc-rounding
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 4, 12, 8]`

## tiny-corner-cut -> tiny-corner-cut
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 4, 8, 12]`

## tiny-corner-cut -> small-arc-rounding
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 4, 12, 8]`

## small-arc-rounding -> tiny-corner-cut
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 2, 18, 4]`

## heavy-arc-rounding
- support diversity key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `['contact-signature', 'segment', 3, 4, 12, 8]`
