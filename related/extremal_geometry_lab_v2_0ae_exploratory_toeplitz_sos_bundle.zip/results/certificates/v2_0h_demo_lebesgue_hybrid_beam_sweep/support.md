# Support-signature diversified beam

- structure signal: `None`
- accepted descendants: **6**

## tiny-corner-cut
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`

## small-arc-rounding
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`

## tiny-corner-cut -> tiny-corner-cut
- support diversity key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`

## tiny-corner-cut -> small-arc-rounding
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `None`

## small-arc-rounding -> tiny-corner-cut
- support diversity key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- contact diversity key: `None`

## heavy-arc-rounding
- support diversity key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- contact diversity key: `None`
