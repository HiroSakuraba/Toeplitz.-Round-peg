# Lebesgue witness-net scaffold demo

- witnesses: **11**
- scaffold Hausdorff resolution note: `0.03481848162337661`
- coverage mode: `incomplete-family`

This is a finite witness-net scaffold for the Lebesgue lane. It is not exported as a full epsilon-net theorem certificate.

## segment
- vertex count: `4`
- normalized diameter: `1.0`

## orbiform-stub
- vertex count: `16`
- normalized diameter: `1.0`

## disk-half
- vertex count: `24`
- normalized diameter: `1.0`

## regular-3-gon
- vertex count: `3`
- normalized diameter: `1.0`

## regular-4-gon
- vertex count: `4`
- normalized diameter: `1.0`

## regular-5-gon
- vertex count: `5`
- normalized diameter: `0.9999999999999999`

## regular-6-gon
- vertex count: `6`
- normalized diameter: `1.0`

## regular-7-gon
- vertex count: `7`
- normalized diameter: `1.0`

## regular-8-gon
- vertex count: `8`
- normalized diameter: `1.0`

## regular-9-gon
- vertex count: `9`
- normalized diameter: `1.0`

## pal-seed
- vertex count: `6`
- normalized diameter: `1.0`
