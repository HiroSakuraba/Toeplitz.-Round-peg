# Probe-library contact sweep comparison

- segment-only unique contact keys: **1**
- probe-library unique contact keys: **2**