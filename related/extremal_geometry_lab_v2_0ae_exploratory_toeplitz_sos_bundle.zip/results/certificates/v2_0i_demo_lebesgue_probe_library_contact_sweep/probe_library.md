# Probe-library contact signal

- contact probe names: `['segment', 'orbiform-stub', 'disk-half']`
- accepted descendants: **3**
- unique contact keys: **2**

## tiny-corner-cut
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8), ('orbiform-stub', 3, 4, 4, 16), ('disk-half', 3, 2, 2, 20)]`
- contact probe library: `['segment', 'orbiform-stub', 'disk-half']`
- contact probe signature: `[['segment', 3, 4, 12, 8], ['orbiform-stub', 3, 4, 4, 16], ['disk-half', 3, 2, 2, 20]]`

## small-arc-rounding
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8), ('orbiform-stub', 3, 4, 4, 16), ('disk-half', 3, 4, 8, 12)]`
- contact probe library: `['segment', 'orbiform-stub', 'disk-half']`
- contact probe signature: `[['segment', 3, 4, 12, 8], ['orbiform-stub', 3, 4, 4, 16], ['disk-half', 3, 4, 8, 12]]`

## small-corner-cut
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8), ('orbiform-stub', 3, 4, 4, 16), ('disk-half', 3, 4, 8, 12)]`
- contact probe library: `['segment', 'orbiform-stub', 'disk-half']`
- contact probe signature: `[['segment', 3, 4, 12, 8], ['orbiform-stub', 3, 4, 4, 16], ['disk-half', 3, 4, 8, 12]]`
