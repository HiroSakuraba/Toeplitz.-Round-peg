# Segment-only contact signal

- contact probe names: `['segment']`
- accepted descendants: **3**
- unique contact keys: **1**

## tiny-corner-cut
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8)]`
- contact probe library: `['segment']`
- contact probe signature: `[['segment', 3, 4, 12, 8]]`

## small-arc-rounding
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8)]`
- contact probe library: `['segment']`
- contact probe signature: `[['segment', 3, 4, 12, 8]]`

## small-corner-cut
- contact signature key: `['contact-probe-library', ('segment', 3, 4, 12, 8)]`
- contact probe library: `['segment']`
- contact probe signature: `[['segment', 3, 4, 12, 8]]`
