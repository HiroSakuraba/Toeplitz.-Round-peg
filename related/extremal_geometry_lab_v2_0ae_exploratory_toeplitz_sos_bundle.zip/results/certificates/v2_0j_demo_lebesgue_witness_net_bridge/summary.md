# Lebesgue witness-net bridge: pal-seed

- container: `pal-seed`
- witness count: `4`
- joint certified: `False`
- passed witnesses: `0`
- failed witnesses: `4`
- Hausdorff resolution note: `0.11026408970826791`
- coverage status: `incomplete-family`

This is a finite normalized witness-family bridge from search to exact-screening. It is not a full epsilon-net theorem certificate.

## Witness ledger

- 00 `regular-3-gon`: feasible `False`, complete `True`, bundle `00_regular-3-gon/bundle.json`
- 01 `regular-4-gon`: feasible `False`, complete `False`, bundle `01_regular-4-gon/bundle.json`
- 02 `regular-5-gon`: feasible `False`, complete `False`, bundle `02_regular-5-gon/bundle.json`
- 03 `pal-seed`: feasible `False`, complete `False`, bundle `03_pal-seed/bundle.json`