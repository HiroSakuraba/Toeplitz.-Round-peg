# Witness-net search signal comparison

- support descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['small-arc-rounding', 'tiny-corner-cut'], ['heavy-arc-rounding']]`
- witness-net descendants: `[['tiny-corner-cut'], ['tiny-corner-cut', 'tiny-corner-cut'], ['small-corner-cut'], ['heavy-arc-rounding'], ['tiny-corner-cut', 'heavy-arc-rounding'], ['heavy-arc-rounding', 'heavy-arc-rounding']]`
- hybrid witness-net descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['small-corner-cut'], ['tiny-corner-cut', 'heavy-arc-rounding']]`

- witness-net unique keys: **5**
- hybrid unique witness-net keys: **3**