# Support-signature diversified beam

- structure signal: `None`
- accepted descendants: **6**

## tiny-corner-cut
- support key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`

## small-arc-rounding
- support key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`

## tiny-corner-cut -> tiny-corner-cut
- support key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`

## tiny-corner-cut -> small-arc-rounding
- support key: `['support-signature', 49, 651, 5, 5, 5, 5, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`

## small-arc-rounding -> tiny-corner-cut
- support key: `['support-signature', 49, 651, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`

## heavy-arc-rounding
- support key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- witness-net key: `None`
- witness pass/fail: `None` / `None`
- all passed: `None`
- failed labels: `[]`
