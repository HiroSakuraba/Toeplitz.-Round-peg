# Witness-net diversified beam

- structure signal: `witness-net`
- accepted descendants: **6**

## tiny-corner-cut
- support key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 7, 7, 8, 9]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`

## tiny-corner-cut -> tiny-corner-cut
- support key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 7, 7, 7, 8]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`

## small-corner-cut
- support key: `['support-signature', 49, 649, 5, 5, 5, 6, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 7, 7, 7, 8]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`

## heavy-arc-rounding
- support key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 6, 6, 7, 8]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`

## tiny-corner-cut -> heavy-arc-rounding
- support key: `['support-signature', 46, 652, 5, 5, 5, 5, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 6, 6, 6, 7]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`

## heavy-arc-rounding -> heavy-arc-rounding
- support key: `['support-signature', 43, 656, 5, 5, 5, 5, 5, 5, 5, 6]`
- witness-net key: `['witness-net-quick', 3, 3, 1, 5, 5, 6, 7]`
- witness pass/fail: `3` / `0`
- all passed: `True`
- failed labels: `[]`
