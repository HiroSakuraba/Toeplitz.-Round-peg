# Witness-net beam with targeted follow-up moves

- targeted moves enabled: `True`
- accepted descendants: **8**

## tiny-corner-cut
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'regular-3-gon']`

## small-arc-rounding
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'regular-3-gon']`

## tiny-corner-cut -> tiny-corner-cut
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'disk-half']`

## tiny-corner-cut -> small-arc-rounding
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'regular-3-gon']`

## targeted-triangle-rounding
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'disk-half']`

## tiny-corner-cut -> targeted-triangle-cut
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'regular-3-gon']`

## heavy-arc-rounding
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-8-gon', 'orbiform-stub', 'disk-half']`

## tiny-corner-cut -> heavy-arc-rounding
- witness pass/fail: `10` / `0`
- failed labels: `[]`
- weakest labels: `['regular-3-gon', 'regular-8-gon', 'orbiform-stub']`
