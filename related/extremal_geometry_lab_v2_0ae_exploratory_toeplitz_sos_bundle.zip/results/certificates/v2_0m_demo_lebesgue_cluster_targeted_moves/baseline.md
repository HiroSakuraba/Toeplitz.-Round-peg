# Cluster-aware witness-net beam without targeted follow-up moves

- targeted moves enabled: `False`
- accepted descendants: **8**

## tiny-corner-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## small-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> tiny-corner-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> small-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## small-corner-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## heavy-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> heavy-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## heavy-arc-rounding -> heavy-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`
