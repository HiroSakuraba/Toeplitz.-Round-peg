# Cluster-aware witness-targeted move comparison

- baseline descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['small-corner-cut'], ['heavy-arc-rounding'], ['tiny-corner-cut', 'heavy-arc-rounding'], ['heavy-arc-rounding', 'heavy-arc-rounding']]`
- guided descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['targeted-triangle-rounding'], ['tiny-corner-cut', 'targeted-triangle-cut'], ['heavy-arc-rounding'], ['tiny-corner-cut', 'heavy-arc-rounding']]`
- introduced descendants: `[['targeted-triangle-rounding'], ['tiny-corner-cut', 'targeted-triangle-cut']]`
- introduced targeted descendants: `[['targeted-triangle-rounding'], ['tiny-corner-cut', 'targeted-triangle-cut']]`