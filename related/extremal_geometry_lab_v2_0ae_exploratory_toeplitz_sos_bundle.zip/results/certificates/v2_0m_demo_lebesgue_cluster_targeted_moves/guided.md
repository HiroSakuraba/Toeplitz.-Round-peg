# Cluster-aware witness-net beam with targeted follow-up moves

- targeted moves enabled: `True`
- accepted descendants: **8**

## tiny-corner-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## small-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> tiny-corner-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> small-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## targeted-triangle-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> targeted-triangle-cut
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## heavy-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`

## tiny-corner-cut -> heavy-arc-rounding
- low-margin clusters: `['round']`
- weakest clusters: `['round']`
- contact summary: `locked`
- failed labels: `[]`
