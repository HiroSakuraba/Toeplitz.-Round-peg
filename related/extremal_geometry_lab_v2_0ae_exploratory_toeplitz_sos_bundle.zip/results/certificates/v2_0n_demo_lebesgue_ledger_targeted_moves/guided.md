# Witness-net beam with ledger-derived targeted follow-up moves

- targeted moves enabled: `True`
- accepted descendants: **8**

## targeted-triangle-rounding
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## tiny-corner-cut
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## targeted-triangle-rounding -> targeted-triangle-rounding
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## tiny-corner-cut -> targeted-triangle-rounding
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## tiny-corner-cut -> tiny-corner-cut
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## small-corner-cut
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## small-corner-cut -> targeted-square-rounding
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`

## heavy-arc-rounding
- low-margin clusters: `['round']`
- failed clusters: `[]`
- contact summary: `locked`
- ledger-derived move specs: `[{'label': 'targeted-square-rounding', 'target': 'square', 'cluster': 'round', 'severity': 'safe', 'cut': 0.05, 'radius': 0.016}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'round', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}, {'label': 'targeted-triangle-rounding', 'target': 'triangle', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.02, 'radius': 0.014}, {'label': 'targeted-net-heavy-rounding', 'target': 'net-heavy', 'cluster': 'needle', 'severity': 'safe', 'cut': 0.1, 'radius': 0.016}]`
