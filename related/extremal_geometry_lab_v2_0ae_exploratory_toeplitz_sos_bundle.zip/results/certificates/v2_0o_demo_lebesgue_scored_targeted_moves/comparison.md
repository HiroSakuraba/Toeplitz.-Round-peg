# Scored witness-targeted move comparison

- limit 1 descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['small-corner-cut'], ['heavy-arc-rounding'], ['tiny-corner-cut', 'heavy-arc-rounding'], ['heavy-arc-rounding', 'heavy-arc-rounding']]`
- limit 3 descendants: `[['tiny-corner-cut'], ['small-arc-rounding'], ['tiny-corner-cut', 'tiny-corner-cut'], ['tiny-corner-cut', 'small-arc-rounding'], ['small-corner-cut'], ['small-corner-cut', 'targeted-square-rounding'], ['heavy-arc-rounding'], ['tiny-corner-cut', 'heavy-arc-rounding']]`
- introduced when widened: `[['small-corner-cut', 'targeted-square-rounding']]`