# Scored witness-targeted moves with limit 1

- targeted move limit: `1`
- accepted descendants: **8**

## tiny-corner-cut
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## small-arc-rounding
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## tiny-corner-cut -> tiny-corner-cut
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## tiny-corner-cut -> small-arc-rounding
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## small-corner-cut
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## heavy-arc-rounding
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## tiny-corner-cut -> heavy-arc-rounding
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`

## heavy-arc-rounding -> heavy-arc-rounding
- suggested labels: `['targeted-net-heavy-rounding']`
- scored move specs: `[{'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-net-heavy-rounding', 'score': 0.714, 'cluster': 'needle', 'severity': 'safe'}, {'label': 'targeted-square-rounding', 'score': 0.41400000000000003, 'cluster': 'round', 'severity': 'safe'}, {'label': 'targeted-triangle-rounding', 'score': 0.346, 'cluster': 'needle', 'severity': 'safe'}]`
