# Witness-net beam with target-score signal

- accepted descendants: **8**

## tiny-corner-cut
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## small-arc-rounding
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## tiny-corner-cut -> tiny-corner-cut
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## tiny-corner-cut -> small-arc-rounding
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## small-corner-cut
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## tiny-corner-cut -> heavy-arc-rounding
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## targeted-net-heavy-rounding
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`

## tiny-corner-cut -> targeted-net-heavy-rounding
- witness pass/fail: `10` / `0`
- target max score: `0.714`
- target total score: `2.1879999999999997`
- target score bucket: `7`
- suggested labels: `['targeted-net-heavy-rounding', 'targeted-net-heavy-rounding']`
- suggested targets: `['net-heavy', 'net-heavy']`
