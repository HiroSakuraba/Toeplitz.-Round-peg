# Witness co-failure nerve demo

- vertices: `3`
- edges: `0`
- triangles: `0`
- betti_0: `3`
- betti_1: `0`
- sampled states: `5`
- nonempty failure samples: `0`

This is a sampled co-failure diagnostic only. It is not a finite-witness completeness proof.