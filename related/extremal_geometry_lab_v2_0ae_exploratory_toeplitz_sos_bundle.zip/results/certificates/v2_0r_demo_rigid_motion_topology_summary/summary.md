# Rigid-motion BnB topology summary

- feasible components: `1`
- infeasible components: `0`
- unresolved boxes: `8`
- unresolved fraction: `0.333333`
- unresolved bridge-risk boxes: `0`
- topological completeness proved: `False`

This is a conservative topology diagnostic for the classified box union, not a proof shortcut.