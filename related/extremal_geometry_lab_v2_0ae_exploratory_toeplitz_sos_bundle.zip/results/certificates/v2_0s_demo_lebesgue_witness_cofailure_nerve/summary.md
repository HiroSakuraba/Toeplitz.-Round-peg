# Witness co-failure nerve demo

- vertices: `10`
- edges: `28`
- triangles: `56`
- betti_0: `3`
- betti_1: `0`
- sampled states: `4`
- nonempty failure samples: `3`
- max failure cardinality: `8`

The later demo states are deliberately undersized stress states so the sampled nerve is nontrivial.
This is a sampled co-failure diagnostic only. It is not a finite-witness completeness proof.