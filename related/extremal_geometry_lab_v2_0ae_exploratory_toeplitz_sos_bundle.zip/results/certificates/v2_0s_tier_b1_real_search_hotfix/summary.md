# Extremal Geometry Lab v2.0s — Tier B1 real search run

Parameters:
- depth: `3`
- beam_width: `6`
- beam_policy: `diversified`
- beam_diversity_reserve: `2`
- prescreen_n: `512`
- targeted_move_limit: `2`
- adaptive_quick_fit: `12->24`
- passed_proposal_count_rule: `screen_passed == True and len(move_history) > 0 (seed excluded)`

## Tier B1 first pass (`witness-net`)
- runtime: `52.922` s
- total passed proposals: `18`
- final frontier count: `6`
- targeted proposals total: `5`
- targeted proposals in final frontier: `2`
- distinct target signatures (total/final): `1` / `1`
- target score buckets in final frontier: `[7]`
- targeted labels in final frontier: `['targeted-net-heavy-rounding', 'targeted-square-rounding']`
- average final screen slack: `0.668156`
- top final move histories:
  - `['tiny-corner-cut', 'tiny-corner-cut', 'tiny-corner-cut']`
  - `['tiny-corner-cut', 'tiny-corner-cut', 'small-arc-rounding']`
  - `['tiny-corner-cut', 'small-arc-rounding', 'tiny-corner-cut']`
  - `['small-arc-rounding', 'tiny-corner-cut', 'tiny-corner-cut']`
  - `['small-arc-rounding', 'small-arc-rounding', 'targeted-square-rounding']`
  - `['tiny-corner-cut', 'tiny-corner-cut', 'targeted-net-heavy-rounding']`

## Tier B1 second pass (`hybrid-witness-net`)
- runtime: `49.954` s
- total passed proposals: `18`
- final frontier count: `6`
- targeted proposals total: `3`
- targeted proposals in final frontier: `1`
- distinct target signatures (total/final): `1` / `1`
- target score buckets in final frontier: `[7]`
- targeted labels in final frontier: `['targeted-square-rounding']`
- average final screen slack: `0.688012`
- top final move histories:
  - `['tiny-corner-cut', 'tiny-corner-cut', 'tiny-corner-cut']`
  - `['tiny-corner-cut', 'tiny-corner-cut', 'small-arc-rounding']`
  - `['tiny-corner-cut', 'small-arc-rounding', 'tiny-corner-cut']`
  - `['small-arc-rounding', 'tiny-corner-cut', 'tiny-corner-cut']`
  - `['tiny-corner-cut', 'small-arc-rounding', 'small-arc-rounding']`
  - `['small-arc-rounding', 'small-arc-rounding', 'targeted-square-rounding']`

## Comparison
- runtime_ratio_hybrid_vs_witness_net: `0.944`
- targeted_final_delta: `-1`
- final_frontier_delta: `0`


## Correction note
- The original `19` count was a summary-accounting issue that included the seed. The corrected passed-proposal count is `18` for both runs.
