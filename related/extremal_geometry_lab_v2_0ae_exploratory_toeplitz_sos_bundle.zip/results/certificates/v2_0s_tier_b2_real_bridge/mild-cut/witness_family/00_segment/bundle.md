# Rigid-motion certificate bundle: segment in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.41569169381653065`
- sampled max violation: `-0.41569169381653065`
- certified upper violation: `-0.3396297680097195`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.8026026298304898`
- midpoint sampled margin: `-0.7969937909700882`
- midpoint sampled max violation: `0.7969937909700882`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160036`
- midpoint sampled margin: `-0.6148492019920548`
- midpoint sampled max violation: `0.6148492019920548`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.6543466059985202`
- midpoint sampled max violation: `0.6543466059985202`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.869589793963674`
- midpoint sampled margin: `-1.15054647445658`
- midpoint sampled max violation: `1.15054647445658`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637318`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.419106336496917`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.4191063364969165`
- midpoint sampled margin: `-0.7805464744563305`
- midpoint sampled max violation: `0.7805464744563305`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637322`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.869589793963674`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.65434660599852`
- midpoint sampled max violation: `0.65434660599852`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160034`
- midpoint sampled margin: `-0.6148492019920547`
- midpoint sampled max violation: `0.6148492019920547`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.8026026298304902`
- midpoint sampled margin: `-0.7969937909700882`
- midpoint sampled max violation: `0.7969937909700882`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.8695897939636743`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.6543466059985199`
- midpoint sampled max violation: `0.6543466059985199`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2847974616160043`
- midpoint sampled margin: `-0.6148492019920551`
- midpoint sampled max violation: `0.6148492019920551`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.8026026298304896`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.4191063364969163`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637325`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.352119172363732`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.4191063364969168`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.8026026298304896`
- midpoint sampled margin: `-0.796993790970088`
- midpoint sampled max violation: `0.796993790970088`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160034`
- midpoint sampled margin: `-0.614849201992055`
- midpoint sampled max violation: `0.614849201992055`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385173`
- midpoint sampled margin: `-0.6543466059985199`
- midpoint sampled max violation: `0.6543466059985199`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.8695897939636748`
- midpoint sampled margin: `-1.150546474456581`
- midpoint sampled max violation: `1.150546474456581`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.8026026298304898`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160036`
- midpoint sampled margin: `-0.6148492019920548`
- midpoint sampled max violation: `0.6148492019920548`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.6543466059985202`
- midpoint sampled max violation: `0.6543466059985202`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.869589793963674`
- midpoint sampled margin: `-1.15054647445658`
- midpoint sampled max violation: `1.15054647445658`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637318`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.419106336496917`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.4191063364969165`
- midpoint sampled margin: `-0.7805464744563305`
- midpoint sampled max violation: `0.7805464744563305`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637322`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.869589793963674`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.65434660599852`
- midpoint sampled max violation: `0.65434660599852`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160034`
- midpoint sampled margin: `-0.614849201992055`
- midpoint sampled max violation: `0.614849201992055`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.8026026298304902`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.8695897939636743`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385168`
- midpoint sampled margin: `-0.6543466059985199`
- midpoint sampled max violation: `0.6543466059985199`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2847974616160038`
- midpoint sampled margin: `-0.6148492019920551`
- midpoint sampled max violation: `0.6148492019920551`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.8026026298304896`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.4191063364969163`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3521191723637325`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.352119172363732`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.4191063364969168`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.8026026298304896`
- midpoint sampled margin: `-0.796993790970088`
- midpoint sampled max violation: `0.796993790970088`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2847974616160034`
- midpoint sampled margin: `-0.6148492019920547`
- midpoint sampled max violation: `0.6148492019920547`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3148277501385173`
- midpoint sampled margin: `-0.6543466059985199`
- midpoint sampled max violation: `0.6543466059985199`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.8695897939636748`
- midpoint sampled margin: `-1.150546474456581`
- midpoint sampled max violation: `1.150546474456581`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.6086000728437749`
- midpoint sampled margin: `0.01676474676942441`
- midpoint sampled max violation: `-0.01676474676942441`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7112603650076758`
- midpoint sampled margin: `0.038893988450465766`
- midpoint sampled max violation: `-0.038893988450465766`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.773969968382904`
- midpoint sampled margin: `-0.053401782598879954`
- midpoint sampled max violation: `0.053401782598879954`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320242`
- midpoint sampled margin: `-0.15244706490493098`
- midpoint sampled max violation: `0.15244706490493098`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7739699683829038`
- midpoint sampled margin: `-0.0534017825988804`
- midpoint sampled max violation: `0.0534017825988804`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320237`
- midpoint sampled margin: `-0.1524470649049311`
- midpoint sampled max violation: `0.1524470649049311`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.608600072843775`
- midpoint sampled margin: `0.01676474676942441`
- midpoint sampled max violation: `-0.01676474676942441`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076761`
- midpoint sampled margin: `0.038893988450465766`
- midpoint sampled max violation: `-0.038893988450465766`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7782472804320241`
- midpoint sampled margin: `-0.1524470649049312`
- midpoint sampled max violation: `0.1524470649049312`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7739699683829041`
- midpoint sampled margin: `-0.0534017825988804`
- midpoint sampled max violation: `0.0534017825988804`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076761`
- midpoint sampled margin: `0.03889398845046588`
- midpoint sampled max violation: `-0.03889398845046588`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.6086000728437754`
- midpoint sampled margin: `0.0167647467694243`
- midpoint sampled max violation: `-0.0167647467694243`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076754`
- midpoint sampled margin: `0.03889398845046588`
- midpoint sampled max violation: `-0.03889398845046588`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.6086000728437753`
- midpoint sampled margin: `0.016764746769424188`
- midpoint sampled max violation: `-0.016764746769424188`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320244`
- midpoint sampled margin: `-0.1524470649049312`
- midpoint sampled max violation: `0.1524470649049312`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7739699683829044`
- midpoint sampled margin: `-0.05340178259888062`
- midpoint sampled max violation: `0.05340178259888062`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.6086000728437749`
- midpoint sampled margin: `0.0167647467694243`
- midpoint sampled max violation: `-0.0167647467694243`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7112603650076758`
- midpoint sampled margin: `0.038893988450465655`
- midpoint sampled max violation: `-0.038893988450465655`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.773969968382904`
- midpoint sampled margin: `-0.05340178259887984`
- midpoint sampled max violation: `0.05340178259887984`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320242`
- midpoint sampled margin: `-0.15244706490493098`
- midpoint sampled max violation: `0.15244706490493098`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7739699683829036`
- midpoint sampled margin: `-0.05340178259888029`
- midpoint sampled max violation: `0.05340178259888029`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320237`
- midpoint sampled margin: `-0.1524470649049311`
- midpoint sampled max violation: `0.1524470649049311`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.608600072843775`
- midpoint sampled margin: `0.01676474676942441`
- midpoint sampled max violation: `-0.01676474676942441`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076759`
- midpoint sampled margin: `0.038893988450465766`
- midpoint sampled max violation: `-0.038893988450465766`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7782472804320241`
- midpoint sampled margin: `-0.1524470649049312`
- midpoint sampled max violation: `0.1524470649049312`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783986`
- certified upper violation: `0.7739699683829041`
- midpoint sampled margin: `-0.0534017825988804`
- midpoint sampled max violation: `0.0534017825988804`
- pose drift bound: `0.7196085589281533`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076761`
- midpoint sampled margin: `0.038893988450465655`
- midpoint sampled max violation: `-0.038893988450465655`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.6086000728437752`
- midpoint sampled margin: `0.0167647467694243`
- midpoint sampled max violation: `-0.0167647467694243`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7112603650076754`
- midpoint sampled margin: `0.038893988450465655`
- midpoint sampled max violation: `-0.038893988450465655`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7400000000005, 0.0] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.6086000728437753`
- midpoint sampled margin: `0.016764746769424188`
- midpoint sampled max violation: `-0.016764746769424188`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7782472804320244`
- midpoint sampled margin: `-0.1524470649049312`
- midpoint sampled max violation: `0.1524470649049312`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7400000000005, 0.0] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `0.7739699683829044`
- midpoint sampled margin: `-0.05340178259888062`
- midpoint sampled max violation: `0.05340178259888062`
- pose drift bound: `0.7196085589281535`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
