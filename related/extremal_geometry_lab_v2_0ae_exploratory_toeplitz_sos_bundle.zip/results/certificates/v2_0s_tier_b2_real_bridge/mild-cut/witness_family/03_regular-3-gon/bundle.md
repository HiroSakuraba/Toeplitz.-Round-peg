# Rigid-motion certificate bundle: regular-3-gon in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.34870489570874985`
- sampled max violation: `-0.34870489570874985`
- certified upper violation: `-0.16382049827370804`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.2336640864506623`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5918415641141643`
- midpoint sampled margin: `-0.7275560966473325`
- midpoint sampled max violation: `0.7275560966473325`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.4829769932833767`
- midpoint sampled margin: `-0.7838749912554711`
- midpoint sampled max violation: `0.7838749912554711`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.061014355640288`
- midpoint sampled margin: `-1.304507662844127`
- midpoint sampled max violation: `1.304507662844127`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.7596366987811662`
- midpoint sampled margin: `-0.9151700955467215`
- midpoint sampled max violation: `0.9151700955467215`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0852842509267915`
- midpoint sampled margin: `-0.24081764769234626`
- midpoint sampled max violation: `0.24081764769234626`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `0.912634520116417`
- midpoint sampled margin: `-0.24081764769234582`
- midpoint sampled max violation: `0.24081764769234582`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5869869679707926`
- midpoint sampled margin: `-0.9151700955467212`
- midpoint sampled max violation: `0.9151700955467212`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.7313245352681983`
- midpoint sampled margin: `-0.7823743018185355`
- midpoint sampled max violation: `0.7823743018185355`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.056972087413823`
- midpoint sampled margin: `-0.09831020741386187`
- midpoint sampled max violation: `0.09831020741386187`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0110185383820143`
- midpoint sampled margin: `-0.1095225434010959`
- midpoint sampled max violation: `0.1095225434010959`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6853709862363893`
- midpoint sampled margin: `-0.7657408501853786`
- midpoint sampled max violation: `0.7657408501853786`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.2053519229376946`
- midpoint sampled margin: `-1.1550784174827853`
- midpoint sampled max violation: `1.1550784174827853`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6629865521442557`
- midpoint sampled margin: `-0.876985342008675`
- midpoint sampled max violation: `0.876985342008675`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6723277724908399`
- midpoint sampled margin: `-0.876985342008675`
- midpoint sampled max violation: `0.876985342008675`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.177724991423892`
- midpoint sampled margin: `-1.2052120942767321`
- midpoint sampled max violation: `1.2052120942767321`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.2053519229376946`
- midpoint sampled margin: `-1.1550784174827857`
- midpoint sampled max violation: `1.1550784174827857`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6629865521442555`
- midpoint sampled margin: `-0.8769853420086748`
- midpoint sampled max violation: `0.8769853420086748`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6723277724908394`
- midpoint sampled margin: `-0.8769853420086748`
- midpoint sampled max violation: `0.8769853420086748`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.1777249914238928`
- midpoint sampled margin: `-1.205212094276733`
- midpoint sampled max violation: `1.205212094276733`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.7313245352681985`
- midpoint sampled margin: `-0.782374301818536`
- midpoint sampled max violation: `0.782374301818536`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0569720874138238`
- midpoint sampled margin: `-0.09831020741386187`
- midpoint sampled max violation: `0.09831020741386187`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0110185383820143`
- midpoint sampled margin: `-0.10952254340109635`
- midpoint sampled max violation: `0.10952254340109635`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6853709862363895`
- midpoint sampled margin: `-0.7657408501853789`
- midpoint sampled max violation: `0.7657408501853789`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.759636698781166`
- midpoint sampled margin: `-0.9151700955467211`
- midpoint sampled max violation: `0.9151700955467211`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.085284250926791`
- midpoint sampled margin: `-0.24081764769234615`
- midpoint sampled max violation: `0.24081764769234615`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `0.9126345201164168`
- midpoint sampled margin: `-0.24081764769234626`
- midpoint sampled max violation: `0.24081764769234626`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.586986967970792`
- midpoint sampled margin: `-0.915170095546721`
- midpoint sampled max violation: `0.915170095546721`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.233664086450662`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5918415641141637`
- midpoint sampled margin: `-0.7275560966473326`
- midpoint sampled max violation: `0.7275560966473326`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.4829769932833767`
- midpoint sampled margin: `-0.7838749912554713`
- midpoint sampled max violation: `0.7838749912554713`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.061014355640288`
- midpoint sampled margin: `-1.3045076628441281`
- midpoint sampled max violation: `1.3045076628441281`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.177724991423891`
- midpoint sampled margin: `-1.2052120942767324`
- midpoint sampled max violation: `1.2052120942767324`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6723277724908394`
- midpoint sampled margin: `-0.8769853420086751`
- midpoint sampled max violation: `0.8769853420086751`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6629865521442562`
- midpoint sampled margin: `-0.8769853420086751`
- midpoint sampled max violation: `0.8769853420086751`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.2053519229376954`
- midpoint sampled margin: `-1.155078417482785`
- midpoint sampled max violation: `1.155078417482785`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6853709862363897`
- midpoint sampled margin: `-0.7657408501853789`
- midpoint sampled max violation: `0.7657408501853789`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0110185383820145`
- midpoint sampled margin: `-0.10952254340109613`
- midpoint sampled max violation: `0.10952254340109613`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0569720874138238`
- midpoint sampled margin: `-0.09831020741386198`
- midpoint sampled max violation: `0.09831020741386198`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.7313245352681992`
- midpoint sampled margin: `-0.7823743018185356`
- midpoint sampled max violation: `0.7823743018185356`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.5869869679707918`
- midpoint sampled margin: `-0.9151700955467214`
- midpoint sampled max violation: `0.9151700955467214`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `0.9126345201164165`
- midpoint sampled margin: `-0.24081764769234615`
- midpoint sampled max violation: `0.24081764769234615`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.085284250926791`
- midpoint sampled margin: `-0.24081764769234626`
- midpoint sampled max violation: `0.24081764769234626`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.7596366987811662`
- midpoint sampled margin: `-0.915170095546721`
- midpoint sampled max violation: `0.915170095546721`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.061014355640288`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.4829769932833767`
- midpoint sampled margin: `-0.7838749912554709`
- midpoint sampled max violation: `0.7838749912554709`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5918415641141634`
- midpoint sampled margin: `-0.7275560966473326`
- midpoint sampled max violation: `0.7275560966473326`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.2336640864506623`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.061014355640288`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.4829769932833767`
- midpoint sampled margin: `-0.7838749912554713`
- midpoint sampled max violation: `0.7838749912554713`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.5918415641141639`
- midpoint sampled margin: `-0.7275560966473327`
- midpoint sampled max violation: `0.7275560966473327`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.2336640864506627`
- midpoint sampled margin: `-1.304507662844127`
- midpoint sampled max violation: `1.304507662844127`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.586986967970792`
- midpoint sampled margin: `-0.9151700955467215`
- midpoint sampled max violation: `0.9151700955467215`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `0.9126345201164173`
- midpoint sampled margin: `-0.24081764769234626`
- midpoint sampled max violation: `0.24081764769234626`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0852842509267915`
- midpoint sampled margin: `-0.24081764769234582`
- midpoint sampled max violation: `0.24081764769234582`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.759636698781167`
- midpoint sampled margin: `-0.9151700955467212`
- midpoint sampled max violation: `0.9151700955467212`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6853709862363886`
- midpoint sampled margin: `-0.765740850185379`
- midpoint sampled max violation: `0.765740850185379`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0110185383820138`
- midpoint sampled margin: `-0.10952254340109613`
- midpoint sampled max violation: `0.10952254340109613`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.0569720874138233`
- midpoint sampled margin: `-0.09831020741386165`
- midpoint sampled max violation: `0.09831020741386165`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.731324535268198`
- midpoint sampled margin: `-0.782374301818536`
- midpoint sampled max violation: `0.782374301818536`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.177724991423892`
- midpoint sampled margin: `-1.2052120942767328`
- midpoint sampled max violation: `1.2052120942767328`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6723277724908394`
- midpoint sampled margin: `-0.8769853420086747`
- midpoint sampled max violation: `0.8769853420086747`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6629865521442548`
- midpoint sampled margin: `-0.8769853420086747`
- midpoint sampled max violation: `0.8769853420086747`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.2053519229376946`
- midpoint sampled margin: `-1.1550784174827857`
- midpoint sampled max violation: `1.1550784174827857`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
