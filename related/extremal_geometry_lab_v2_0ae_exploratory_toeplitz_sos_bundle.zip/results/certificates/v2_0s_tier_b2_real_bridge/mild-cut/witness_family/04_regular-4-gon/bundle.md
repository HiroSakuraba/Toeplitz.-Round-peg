# Rigid-motion certificate bundle: regular-4-gon in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3657419825642158`
- sampled max violation: `-0.3657419825642158`
- certified upper violation: `-0.31309558459708`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4191054704703425`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.419105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367954`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977306`
- midpoint sampled max violation: `0.6543461059977306`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4191054704703425`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.419105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.780546215636511`
- midpoint sampled max violation: `0.780546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367954`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977305`
- midpoint sampled max violation: `0.6543461059977305`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4191054704703425`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.419105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.780546215636511`
- midpoint sampled max violation: `0.780546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367954`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977305`
- midpoint sampled max violation: `0.6543461059977305`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.419105470470343`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.419105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4191054704703423`
- midpoint sampled margin: `-0.780546215636511`
- midpoint sampled max violation: `0.780546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367954`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977308`
- midpoint sampled max violation: `0.6543461059977308`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.3148268262578107`
- midpoint sampled margin: `-0.6543461059977307`
- midpoint sampled max violation: `0.6543461059977307`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.8695889279367957`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7782466716698574`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7739691023567626`
- midpoint sampled margin: `-0.05340117383710985`
- midpoint sampled max violation: `0.05340117383710985`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.05340117383710952`
- midpoint sampled max violation: `0.05340117383710952`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7739691023567625`
- midpoint sampled margin: `-0.05340117383710996`
- midpoint sampled max violation: `0.05340117383710996`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698573`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.05340117383711007`
- midpoint sampled max violation: `0.05340117383711007`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7782466716698574`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7739691023567626`
- midpoint sampled margin: `-0.05340117383710963`
- midpoint sampled max violation: `0.05340117383710963`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.053401173837109406`
- midpoint sampled max violation: `0.053401173837109406`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7739691023567625`
- midpoint sampled margin: `-0.05340117383710996`
- midpoint sampled max violation: `0.05340117383710996`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698573`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.05340117383711007`
- midpoint sampled max violation: `0.05340117383711007`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7782466716698574`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7739691023567626`
- midpoint sampled margin: `-0.05340117383710963`
- midpoint sampled max violation: `0.05340117383710963`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.053401173837109406`
- midpoint sampled max violation: `0.053401173837109406`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7739691023567625`
- midpoint sampled margin: `-0.05340117383710974`
- midpoint sampled max violation: `0.05340117383710974`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698573`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.05340117383711007`
- midpoint sampled max violation: `0.05340117383711007`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7782466716698574`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.7739691023567626`
- midpoint sampled margin: `-0.05340117383710985`
- midpoint sampled max violation: `0.05340117383710985`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.053401173837109406`
- midpoint sampled max violation: `0.053401173837109406`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7739691023567625`
- midpoint sampled margin: `-0.05340117383710974`
- midpoint sampled max violation: `0.05340117383710974`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.7782466716698573`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.7782466716698577`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.773969102356763`
- midpoint sampled margin: `-0.05340117383711007`
- midpoint sampled max violation: `0.05340117383711007`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
