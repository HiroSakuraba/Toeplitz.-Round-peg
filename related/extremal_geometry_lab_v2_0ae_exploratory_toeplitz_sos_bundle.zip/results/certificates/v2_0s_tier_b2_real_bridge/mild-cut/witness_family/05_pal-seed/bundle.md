# Rigid-motion certificate bundle: pal-seed in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.4156921938165306`
- sampled max violation: `-0.4156921938165306`
- certified upper violation: `-0.2508068657967054`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9945889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4700917003392162`
- midpoint sampled margin: `-0.744258017435784`
- midpoint sampled max violation: `0.744258017435784`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778514`
- midpoint sampled margin: `-0.744258017435784`
- midpoint sampled max violation: `0.744258017435784`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.019107980775125`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5441054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.568624523308672`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.568624523308671`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5441054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.019107980775124`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4788094112778518`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.470091700339216`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `2.0191079807751247`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778514`
- midpoint sampled margin: `-0.7442580174357842`
- midpoint sampled max violation: `0.7442580174357842`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4700917003392164`
- midpoint sampled margin: `-0.7442580174357842`
- midpoint sampled max violation: `0.7442580174357842`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5686245233086713`
- midpoint sampled margin: `-0.780546215636511`
- midpoint sampled max violation: `0.780546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.544105470470343`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.544105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5686245233086713`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367954`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.470091700339216`
- midpoint sampled margin: `-0.7442580174357841`
- midpoint sampled max violation: `0.7442580174357841`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778518`
- midpoint sampled margin: `-0.7442580174357841`
- midpoint sampled max violation: `0.7442580174357841`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.0191079807751247`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9945889279367957`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4700917003392162`
- midpoint sampled margin: `-0.744258017435784`
- midpoint sampled max violation: `0.744258017435784`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778514`
- midpoint sampled margin: `-0.744258017435784`
- midpoint sampled max violation: `0.744258017435784`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.019107980775125`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5441054704703423`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.568624523308672`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.568624523308671`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5441054704703423`
- midpoint sampled margin: `-0.780546215636511`
- midpoint sampled max violation: `0.780546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.019107980775124`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4788094112778518`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.470091700339216`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367957`
- midpoint sampled margin: `-1.1505462156365112`
- midpoint sampled max violation: `1.1505462156365112`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `2.0191079807751247`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778518`
- midpoint sampled margin: `-0.7442580174357842`
- midpoint sampled max violation: `0.7442580174357842`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4700917003392164`
- midpoint sampled margin: `-0.7442580174357842`
- midpoint sampled max violation: `0.7442580174357842`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367959`
- midpoint sampled margin: `-1.1505462156365103`
- midpoint sampled max violation: `1.1505462156365103`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5686245233086713`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.544105470470343`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.544105470470342`
- midpoint sampled margin: `-0.7805462156365109`
- midpoint sampled max violation: `0.7805462156365109`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5686245233086713`
- midpoint sampled margin: `-0.7805462156365108`
- midpoint sampled max violation: `0.7805462156365108`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9945889279367954`
- midpoint sampled margin: `-1.1505462156365107`
- midpoint sampled max violation: `1.1505462156365107`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.470091700339216`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4788094112778518`
- midpoint sampled margin: `-0.7442580174357839`
- midpoint sampled max violation: `0.7442580174357839`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `2.0191079807751247`
- midpoint sampled margin: `-1.150546215636511`
- midpoint sampled max violation: `1.150546215636511`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.8054544761321322`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.9011078870133101`
- midpoint sampled margin: `-0.11866426994713553`
- midpoint sampled max violation: `0.11866426994713553`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.924061240816598`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.863449730814257`
- midpoint sampled margin: `-0.11866426994713519`
- midpoint sampled max violation: `0.11866426994713519`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.9240612408165976`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8634497308142568`
- midpoint sampled margin: `-0.11866426994713553`
- midpoint sampled max violation: `0.11866426994713553`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.8054544761321321`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.9011078870133105`
- midpoint sampled margin: `-0.11866426994713564`
- midpoint sampled max violation: `0.11866426994713564`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.8634497308142569`
- midpoint sampled margin: `-0.11866426994713541`
- midpoint sampled max violation: `0.11866426994713541`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.9240612408165975`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.9011078870133105`
- midpoint sampled margin: `-0.1186642699471353`
- midpoint sampled max violation: `0.1186642699471353`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8054544761321324`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.9011078870133098`
- midpoint sampled margin: `-0.11866426994713541`
- midpoint sampled max violation: `0.11866426994713541`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8054544761321323`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.8634497308142572`
- midpoint sampled margin: `-0.11866426994713564`
- midpoint sampled max violation: `0.11866426994713564`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.9240612408165978`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.8054544761321322`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.9011078870133101`
- midpoint sampled margin: `-0.11866426994713564`
- midpoint sampled max violation: `0.11866426994713564`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.924061240816598`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.863449730814257`
- midpoint sampled margin: `-0.11866426994713519`
- midpoint sampled max violation: `0.11866426994713519`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.9240612408165976`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8634497308142566`
- midpoint sampled margin: `-0.11866426994713553`
- midpoint sampled max violation: `0.11866426994713553`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.8054544761321323`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.9011078870133105`
- midpoint sampled margin: `-0.11866426994713564`
- midpoint sampled max violation: `0.11866426994713564`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.8634497308142569`
- midpoint sampled margin: `-0.11866426994713541`
- midpoint sampled max violation: `0.11866426994713541`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.523259018078045`
- certified upper violation: `0.9240612408165975`
- midpoint sampled margin: `-0.1524469343783974`
- midpoint sampled max violation: `0.1524469343783974`
- pose drift bound: `0.719608558927407`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.9011078870133105`
- midpoint sampled margin: `-0.11866426994713541`
- midpoint sampled max violation: `0.11866426994713541`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8054544761321324`
- midpoint sampled margin: `-0.15244693437839718`
- midpoint sampled max violation: `0.15244693437839718`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.90110788701331`
- midpoint sampled margin: `-0.11866426994713553`
- midpoint sampled max violation: `0.11866426994713553`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, 0.0] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `0.8054544761321323`
- midpoint sampled margin: `-0.15244693437839751`
- midpoint sampled max violation: `0.15244693437839751`
- pose drift bound: `0.7196085589274072`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.8634497308142572`
- midpoint sampled margin: `-0.11866426994713586`
- midpoint sampled max violation: `0.11866426994713586`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, 0.0] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `0.9240612408165978`
- midpoint sampled margin: `-0.15244693437839762`
- midpoint sampled max violation: `0.15244693437839762`
- pose drift bound: `0.7196085589274073`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
