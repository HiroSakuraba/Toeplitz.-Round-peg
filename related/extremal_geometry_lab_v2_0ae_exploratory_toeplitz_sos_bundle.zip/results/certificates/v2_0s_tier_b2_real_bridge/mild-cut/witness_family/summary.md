# Witness-family bundle: pal-seed-cut

- schema: `witness-family-bundle.v2`
- witness count: `6`
- joint coexistence path: `coexistence.json`
- joint certified: `False`

## Witness status

- 00 `segment`: feasible `False`, complete `False`, selected box `None`, bundle `00_segment/bundle.json`
- 01 `orbiform-stub`: feasible `False`, complete `False`, selected box `None`, bundle `01_orbiform-stub/bundle.json`
- 02 `disk-half`: feasible `False`, complete `False`, selected box `None`, bundle `02_disk-half/bundle.json`
- 03 `regular-3-gon`: feasible `False`, complete `True`, selected box `None`, bundle `03_regular-3-gon/bundle.json`
- 04 `regular-4-gon`: feasible `False`, complete `False`, selected box `None`, bundle `04_regular-4-gon/bundle.json`
- 05 `pal-seed`: feasible `False`, complete `False`, selected box `None`, bundle `05_pal-seed/bundle.json`