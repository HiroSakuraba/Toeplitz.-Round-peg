# Rigid-motion certificate bundle: segment in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3637301695894643`
- sampled max violation: `-0.3637301695894643`
- certified upper violation: `-0.28984840568744935`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851703`
- midpoint sampled margin: `-0.7874841720268548`
- midpoint sampled max violation: `0.7874841720268548`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191213`
- midpoint sampled max violation: `0.6218107262191213`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000005, 1.420000000001] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587924`
- midpoint sampled margin: `-0.6649532077163183`
- midpoint sampled max violation: `0.6649532077163183`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000005, 1.420000000001] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183548`
- midpoint sampled margin: `-1.1410368555133468`
- midpoint sampled max violation: `1.1410368555133468`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411612`
- midpoint sampled margin: `-0.49855409770080505`
- midpoint sampled max violation: `0.49855409770080505`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218593`
- midpoint sampled margin: `-0.7860368555130972`
- midpoint sampled max violation: `0.7860368555130972`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000005, 0.0] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.398663331721859`
- midpoint sampled margin: `-0.7860368555130973`
- midpoint sampled max violation: `0.7860368555130973`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000005, 0.0] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411612`
- midpoint sampled margin: `-0.49855409770080505`
- midpoint sampled max violation: `0.49855409770080505`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183546`
- midpoint sampled margin: `-1.141036855513347`
- midpoint sampled max violation: `1.141036855513347`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587928`
- midpoint sampled margin: `-0.6649532077163182`
- midpoint sampled max violation: `0.6649532077163182`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191211`
- midpoint sampled max violation: `0.6218107262191211`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851708`
- midpoint sampled margin: `-0.7874841720268547`
- midpoint sampled max violation: `0.7874841720268547`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183548`
- midpoint sampled margin: `-1.1410368555133472`
- midpoint sampled max violation: `1.1410368555133472`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587924`
- midpoint sampled margin: `-0.6649532077163184`
- midpoint sampled max violation: `0.6649532077163184`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000005, 1.420000000001] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322586`
- midpoint sampled margin: `-0.6218107262191215`
- midpoint sampled max violation: `0.6218107262191215`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000005, 1.420000000001] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851703`
- midpoint sampled margin: `-0.7874841720268546`
- midpoint sampled max violation: `0.7874841720268546`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218589`
- midpoint sampled margin: `-0.7860368555130972`
- midpoint sampled max violation: `0.7860368555130972`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411607`
- midpoint sampled margin: `-0.49855409770080505`
- midpoint sampled max violation: `0.49855409770080505`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000005, 0.0] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411614`
- midpoint sampled margin: `-0.49855409770080483`
- midpoint sampled max violation: `0.49855409770080483`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000005, 0.0] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218589`
- midpoint sampled margin: `-0.7860368555130971`
- midpoint sampled max violation: `0.7860368555130971`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.76389678218517`
- midpoint sampled margin: `-0.7874841720268547`
- midpoint sampled max violation: `0.7874841720268547`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191214`
- midpoint sampled max violation: `0.6218107262191214`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587926`
- midpoint sampled margin: `-0.664953207716318`
- midpoint sampled max violation: `0.664953207716318`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183553`
- midpoint sampled margin: `-1.1410368555133474`
- midpoint sampled max violation: `1.1410368555133474`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851703`
- midpoint sampled margin: `-0.7874841720268546`
- midpoint sampled max violation: `0.7874841720268546`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191213`
- midpoint sampled max violation: `0.6218107262191213`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000005, 1.420000000001] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587924`
- midpoint sampled margin: `-0.6649532077163183`
- midpoint sampled max violation: `0.6649532077163183`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000005, 1.420000000001] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183548`
- midpoint sampled margin: `-1.1410368555133468`
- midpoint sampled max violation: `1.1410368555133468`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411612`
- midpoint sampled margin: `-0.49855409770080505`
- midpoint sampled max violation: `0.49855409770080505`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218593`
- midpoint sampled margin: `-0.7860368555130972`
- midpoint sampled max violation: `0.7860368555130972`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000005, 0.0] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.398663331721859`
- midpoint sampled margin: `-0.7860368555130973`
- midpoint sampled max violation: `0.7860368555130973`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000005, 0.0] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411612`
- midpoint sampled margin: `-0.49855409770080483`
- midpoint sampled max violation: `0.49855409770080483`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183546`
- midpoint sampled margin: `-1.141036855513347`
- midpoint sampled max violation: `1.141036855513347`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587928`
- midpoint sampled margin: `-0.6649532077163182`
- midpoint sampled max violation: `0.6649532077163182`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191214`
- midpoint sampled max violation: `0.6218107262191214`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851708`
- midpoint sampled margin: `-0.7874841720268545`
- midpoint sampled max violation: `0.7874841720268545`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183548`
- midpoint sampled margin: `-1.1410368555133472`
- midpoint sampled max violation: `1.1410368555133472`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000005, 1.420000000001] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587924`
- midpoint sampled margin: `-0.6649532077163182`
- midpoint sampled max violation: `0.6649532077163182`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000005, 1.420000000001] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191215`
- midpoint sampled max violation: `0.6218107262191215`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000005, 1.420000000001] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.7638967821851703`
- midpoint sampled margin: `-0.7874841720268546`
- midpoint sampled max violation: `0.7874841720268546`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218589`
- midpoint sampled margin: `-0.7860368555130972`
- midpoint sampled max violation: `0.7860368555130972`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411607`
- midpoint sampled margin: `-0.49855409770080505`
- midpoint sampled max violation: `0.49855409770080505`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000005, 0.0] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3321063309411614`
- midpoint sampled margin: `-0.49855409770080483`
- midpoint sampled max violation: `0.49855409770080483`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000005, 0.0] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3986633317218589`
- midpoint sampled margin: `-0.7860368555130971`
- midpoint sampled max violation: `0.7860368555130971`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.7100000000005, 1.420000000001]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.76389678218517`
- midpoint sampled margin: `-0.7874841720268547`
- midpoint sampled max violation: `0.7874841720268547`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.420000000001, -0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.2711321691322581`
- midpoint sampled margin: `-0.6218107262191211`
- midpoint sampled max violation: `0.6218107262191211`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.3008754811587926`
- midpoint sampled margin: `-0.664953207716318`
- midpoint sampled max violation: `0.664953207716318`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.420000000001, -0.7100000000005] x [-1.420000000001, -0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `1.8308839463183553`
- midpoint sampled margin: `-1.1410368555133474`
- midpoint sampled max violation: `1.1410368555133474`
- pose drift bound: `0.8947448963423118`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114511`
- midpoint sampled margin: `-0.020196777457642034`
- midpoint sampled max violation: `0.020196777457642034`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461513`
- midpoint sampled margin: `0.007422845280165902`
- midpoint sampled max violation: `-0.007422845280165902`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213797`
- midpoint sampled margin: `-0.08487292576917982`
- midpoint sampled max violation: `0.08487292576917982`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704997`
- midpoint sampled margin: `-0.18391820807523085`
- midpoint sampled max violation: `0.18391820807523085`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213794`
- midpoint sampled margin: `-0.08487292576918026`
- midpoint sampled max violation: `0.08487292576918026`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704993`
- midpoint sampled margin: `-0.18391820807523096`
- midpoint sampled max violation: `0.18391820807523096`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114509`
- midpoint sampled margin: `-0.020196777457641812`
- midpoint sampled max violation: `0.020196777457641812`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461514`
- midpoint sampled margin: `0.007422845280166124`
- midpoint sampled max violation: `-0.007422845280166124`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704996`
- midpoint sampled margin: `-0.18391820807523107`
- midpoint sampled max violation: `0.18391820807523107`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213796`
- midpoint sampled margin: `-0.08487292576918026`
- midpoint sampled max violation: `0.08487292576918026`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461516`
- midpoint sampled margin: `0.007422845280166013`
- midpoint sampled max violation: `-0.007422845280166013`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114509`
- midpoint sampled margin: `-0.020196777457642145`
- midpoint sampled max violation: `0.020196777457642145`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.716798122346151`
- midpoint sampled margin: `0.007422845280166013`
- midpoint sampled max violation: `-0.007422845280166013`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114511`
- midpoint sampled margin: `-0.020196777457642145`
- midpoint sampled max violation: `0.020196777457642145`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704997`
- midpoint sampled margin: `-0.18391820807523096`
- midpoint sampled max violation: `0.18391820807523096`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213797`
- midpoint sampled margin: `-0.08487292576918026`
- midpoint sampled max violation: `0.08487292576918026`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114513`
- midpoint sampled margin: `-0.020196777457642145`
- midpoint sampled max violation: `0.020196777457642145`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461513`
- midpoint sampled margin: `0.007422845280165791`
- midpoint sampled max violation: `-0.007422845280165791`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213797`
- midpoint sampled margin: `-0.08487292576917971`
- midpoint sampled max violation: `0.08487292576917971`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704997`
- midpoint sampled margin: `-0.18391820807523085`
- midpoint sampled max violation: `0.18391820807523085`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213794`
- midpoint sampled margin: `-0.08487292576918015`
- midpoint sampled max violation: `0.08487292576918015`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704993`
- midpoint sampled margin: `-0.18391820807523096`
- midpoint sampled max violation: `0.18391820807523096`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114509`
- midpoint sampled margin: `-0.020196777457642034`
- midpoint sampled max violation: `0.020196777457642034`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461511`
- midpoint sampled margin: `0.007422845280166013`
- midpoint sampled max violation: `-0.007422845280166013`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704996`
- midpoint sampled margin: `-0.18391820807523107`
- midpoint sampled max violation: `0.18391820807523107`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7100000000005] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213796`
- midpoint sampled margin: `-0.08487292576918026`
- midpoint sampled max violation: `0.08487292576918026`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7167981223461516`
- midpoint sampled margin: `0.007422845280165791`
- midpoint sampled max violation: `-0.007422845280165791`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7100000000005] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114507`
- midpoint sampled margin: `-0.020196777457642145`
- midpoint sampled max violation: `0.020196777457642145`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.716798122346151`
- midpoint sampled margin: `0.007422845280165791`
- midpoint sampled max violation: `-0.007422845280165791`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7100000000005, 0.0] x [0.0, 0.7100000000005]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.6185914582114509`
- midpoint sampled margin: `-0.020196777457642034`
- midpoint sampled max violation: `0.020196777457642034`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7837850377704997`
- midpoint sampled margin: `-0.18391820807523096`
- midpoint sampled max violation: `0.18391820807523096`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7100000000005, 0.0] x [-0.7100000000005, 0.0]`
- l2 translation radius: `0.5020458146428023`
- certified upper violation: `0.7795077257213797`
- midpoint sampled margin: `-0.08487292576918037`
- midpoint sampled max violation: `0.08487292576918037`
- pose drift bound: `0.698395355492557`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
