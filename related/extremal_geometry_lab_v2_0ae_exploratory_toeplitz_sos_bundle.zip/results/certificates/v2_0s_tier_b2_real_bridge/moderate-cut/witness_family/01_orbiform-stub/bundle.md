# Rigid-motion certificate bundle: orbiform-stub in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `3.9269908169872414`
- translation: `(-0.0, -0.004939311588785303)`
- sampled margin: `0.2967433714816836`
- sampled max violation: `-0.2967433714816836`
- certified upper violation: `-0.1782211126508807`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.153796114235649`
- midpoint sampled max violation: `1.153796114235649`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356485`
- midpoint sampled max violation: `1.1537961142356485`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9435240374495046`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364562`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364555`
- midpoint sampled margin: `-0.7987961142356489`
- midpoint sampled max violation: `0.7987961142356489`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495042`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869727`
- midpoint sampled max violation: `0.18391807754869727`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.7987961142356484`
- midpoint sampled max violation: `0.7987961142356484`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326472`
- midpoint sampled margin: `-1.1537961142356488`
- midpoint sampled max violation: `1.1537961142356488`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259501`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356488`
- midpoint sampled max violation: `1.1537961142356488`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.153796114235649`
- midpoint sampled max violation: `1.153796114235649`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356485`
- midpoint sampled max violation: `1.1537961142356485`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9435240374495046`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869716`
- midpoint sampled max violation: `0.18391807754869716`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364562`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364555`
- midpoint sampled margin: `-0.7987961142356489`
- midpoint sampled max violation: `0.7987961142356489`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495042`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.7987961142356487`
- midpoint sampled max violation: `0.7987961142356487`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326472`
- midpoint sampled margin: `-1.1537961142356488`
- midpoint sampled max violation: `1.1537961142356488`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259501`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356492`
- midpoint sampled max violation: `1.1537961142356492`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.153796114235649`
- midpoint sampled max violation: `1.153796114235649`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356485`
- midpoint sampled max violation: `1.1537961142356485`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9435240374495046`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364562`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364555`
- midpoint sampled margin: `-0.7987961142356489`
- midpoint sampled max violation: `0.7987961142356489`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495042`
- midpoint sampled margin: `-0.18391807754869727`
- midpoint sampled max violation: `0.18391807754869727`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.7987961142356487`
- midpoint sampled max violation: `0.7987961142356487`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326472`
- midpoint sampled margin: `-1.1537961142356488`
- midpoint sampled max violation: `1.1537961142356488`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259501`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356492`
- midpoint sampled max violation: `1.1537961142356492`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.153796114235649`
- midpoint sampled max violation: `1.153796114235649`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183166`
- midpoint sampled max violation: `0.7682566285183166`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356485`
- midpoint sampled max violation: `1.1537961142356485`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9435240374495046`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495045`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364562`
- midpoint sampled margin: `-0.798796114235649`
- midpoint sampled max violation: `0.798796114235649`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364555`
- midpoint sampled margin: `-0.7987961142356489`
- midpoint sampled max violation: `0.7987961142356489`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495042`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9435240374495043`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5584020741364557`
- midpoint sampled margin: `-0.7987961142356487`
- midpoint sampled max violation: `0.7987961142356487`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326472`
- midpoint sampled margin: `-1.1537961142356488`
- midpoint sampled max violation: `1.1537961142356488`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259506`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4832279975259501`
- midpoint sampled margin: `-0.7682566285183164`
- midpoint sampled max violation: `0.7682566285183164`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9906226887326475`
- midpoint sampled margin: `-1.1537961142356492`
- midpoint sampled max violation: `1.1537961142356492`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
