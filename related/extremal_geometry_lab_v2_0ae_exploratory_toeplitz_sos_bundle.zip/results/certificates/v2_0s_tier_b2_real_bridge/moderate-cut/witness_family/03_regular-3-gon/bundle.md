# Rigid-motion certificate bundle: regular-3-gon in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.2967433714816836`
- sampled max violation: `-0.2967433714816836`
- certified upper violation: `-0.11403913595143778`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1949582388053432`
- midpoint sampled margin: `-1.2949980439008943`
- midpoint sampled max violation: `1.2949980439008943`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5780323492731028`
- midpoint sampled margin: `-0.7345176208743989`
- midpoint sampled max violation: `0.7345176208743989`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.4690247243036523`
- midpoint sampled margin: `-0.7974038480851714`
- midpoint sampled max violation: `0.7974038480851714`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.0223085079949685`
- midpoint sampled margin: `-1.2949980439008941`
- midpoint sampled max violation: `1.2949980439008941`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7391936940061083`
- midpoint sampled margin: `-0.9206604766034878`
- midpoint sampled max violation: `0.9206604766034878`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0908220082652667`
- midpoint sampled margin: `-0.2722887908626459`
- midpoint sampled max violation: `0.2722887908626459`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `0.9181722774548923`
- midpoint sampled margin: `-0.2722887908626457`
- midpoint sampled max violation: `0.2722887908626457`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5665439631957345`
- midpoint sampled margin: `-0.9206604766034878`
- midpoint sampled max violation: `0.9206604766034878`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.748675134594813, 0.0] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7115803633707405`
- midpoint sampled margin: `-0.7929809035363338`
- midpoint sampled max violation: `0.7929809035363338`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.748675134594813, 0.0] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.062509844752299`
- midpoint sampled margin: `-0.13527173164092832`
- midpoint sampled max violation: `0.13527173164092832`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.748675134594813, 0.0] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0171855759112332`
- midpoint sampled margin: `-0.14903216234432937`
- midpoint sampled max violation: `0.14903216234432937`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.748675134594813, 0.0] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6649279814613318`
- midpoint sampled margin: `-0.7712312312421451`
- midpoint sampled max violation: `0.7712312312421451`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.166646075292375`
- midpoint sampled margin: `-1.1455687985395517`
- midpoint sampled max violation: `1.1455687985395517`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6493212596605105`
- midpoint sampled margin: `-0.8839468662357414`
- midpoint sampled max violation: `0.8839468662357414`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6583755035111156`
- midpoint sampled margin: `-0.8839468662357414`
- midpoint sampled max violation: `0.8839468662357414`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.140542759312762`
- midpoint sampled margin: `-1.1995280335472875`
- midpoint sampled max violation: `1.1995280335472875`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1666460752923755`
- midpoint sampled margin: `-1.1455687985395524`
- midpoint sampled max violation: `1.1455687985395524`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6493212596605105`
- midpoint sampled margin: `-0.8839468662357413`
- midpoint sampled max violation: `0.8839468662357413`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.658375503511115`
- midpoint sampled margin: `-0.8839468662357413`
- midpoint sampled max violation: `0.8839468662357413`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1405427593127624`
- midpoint sampled margin: `-1.1995280335472875`
- midpoint sampled max violation: `1.1995280335472875`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7115803633707407`
- midpoint sampled margin: `-0.792980903536334`
- midpoint sampled max violation: `0.792980903536334`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0625098447522991`
- midpoint sampled margin: `-0.1352717316409282`
- midpoint sampled max violation: `0.1352717316409282`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0171855759112334`
- midpoint sampled margin: `-0.14903216234432948`
- midpoint sampled max violation: `0.14903216234432948`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6649279814613318`
- midpoint sampled margin: `-0.7712312312421454`
- midpoint sampled max violation: `0.7712312312421454`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.748675134594813, 0.0] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7391936940061086`
- midpoint sampled margin: `-0.9206604766034879`
- midpoint sampled max violation: `0.9206604766034879`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.748675134594813, 0.0] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0908220082652667`
- midpoint sampled margin: `-0.2722887908626458`
- midpoint sampled max violation: `0.2722887908626458`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.748675134594813, 0.0] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `0.9181722774548925`
- midpoint sampled margin: `-0.272288790862646`
- midpoint sampled max violation: `0.272288790862646`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.748675134594813, 0.0] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5665439631957345`
- midpoint sampled margin: `-0.9206604766034877`
- midpoint sampled max violation: `0.9206604766034877`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1949582388053432`
- midpoint sampled margin: `-1.2949980439008941`
- midpoint sampled max violation: `1.2949980439008941`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5780323492731028`
- midpoint sampled margin: `-0.734517620874399`
- midpoint sampled max violation: `0.734517620874399`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.4690247243036525`
- midpoint sampled margin: `-0.7974038480851717`
- midpoint sampled max violation: `0.7974038480851717`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.0223085079949694`
- midpoint sampled margin: `-1.2949980439008946`
- midpoint sampled max violation: `1.2949980439008946`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.140542759312761`
- midpoint sampled margin: `-1.1995280335472875`
- midpoint sampled max violation: `1.1995280335472875`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.658375503511115`
- midpoint sampled margin: `-0.8839468662357415`
- midpoint sampled max violation: `0.8839468662357415`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6493212596605105`
- midpoint sampled margin: `-0.8839468662357415`
- midpoint sampled max violation: `0.8839468662357415`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1666460752923755`
- midpoint sampled margin: `-1.1455687985395517`
- midpoint sampled max violation: `1.1455687985395517`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6649279814613318`
- midpoint sampled margin: `-0.7712312312421454`
- midpoint sampled max violation: `0.7712312312421454`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0171855759112325`
- midpoint sampled margin: `-0.14903216234432948`
- midpoint sampled max violation: `0.14903216234432948`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0625098447522991`
- midpoint sampled margin: `-0.13527173164092832`
- midpoint sampled max violation: `0.13527173164092832`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7115803633707403`
- midpoint sampled margin: `-0.7929809035363338`
- midpoint sampled max violation: `0.7929809035363338`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.748675134594813, 0.0] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5665439631957343`
- midpoint sampled margin: `-0.9206604766034882`
- midpoint sampled max violation: `0.9206604766034882`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.748675134594813, 0.0] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `0.9181722774548924`
- midpoint sampled margin: `-0.2722887908626458`
- midpoint sampled max violation: `0.2722887908626458`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.748675134594813, 0.0] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0908220082652669`
- midpoint sampled margin: `-0.2722887908626458`
- midpoint sampled max violation: `0.2722887908626458`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.748675134594813, 0.0] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7391936940061083`
- midpoint sampled margin: `-0.9206604766034875`
- midpoint sampled max violation: `0.9206604766034875`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.0223085079949685`
- midpoint sampled margin: `-1.2949980439008941`
- midpoint sampled max violation: `1.2949980439008941`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.4690247243036527`
- midpoint sampled margin: `-0.7974038480851713`
- midpoint sampled max violation: `0.7974038480851713`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5780323492731025`
- midpoint sampled margin: `-0.734517620874399`
- midpoint sampled max violation: `0.734517620874399`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.1949582388053437`
- midpoint sampled margin: `-1.2949980439008941`
- midpoint sampled max violation: `1.2949980439008941`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.022308507994969`
- midpoint sampled margin: `-1.2949980439008943`
- midpoint sampled max violation: `1.2949980439008943`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.748675134594813, 1.497350269189626] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.4690247243036523`
- midpoint sampled margin: `-0.7974038480851714`
- midpoint sampled max violation: `0.7974038480851714`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5780323492731023`
- midpoint sampled margin: `-0.7345176208743991`
- midpoint sampled max violation: `0.7345176208743991`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.748675134594813, 1.497350269189626] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.194958238805343`
- midpoint sampled margin: `-1.2949980439008941`
- midpoint sampled max violation: `1.2949980439008941`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.5665439631957345`
- midpoint sampled margin: `-0.9206604766034878`
- midpoint sampled max violation: `0.9206604766034878`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `0.9181722774548926`
- midpoint sampled margin: `-0.2722887908626459`
- midpoint sampled max violation: `0.2722887908626459`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0908220082652669`
- midpoint sampled margin: `-0.2722887908626457`
- midpoint sampled max violation: `0.2722887908626457`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7391936940061092`
- midpoint sampled margin: `-0.9206604766034878`
- midpoint sampled max violation: `0.9206604766034878`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.748675134594813, 0.0] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6649279814613316`
- midpoint sampled margin: `-0.7712312312421458`
- midpoint sampled max violation: `0.7712312312421458`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.748675134594813, 0.0] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.017185575911233`
- midpoint sampled margin: `-0.1490321623443296`
- midpoint sampled max violation: `0.1490321623443296`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.748675134594813, 0.0] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.0625098447522991`
- midpoint sampled margin: `-0.1352717316409281`
- midpoint sampled max violation: `0.1352717316409281`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.748675134594813, 0.0] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.7115803633707407`
- midpoint sampled margin: `-0.792980903536334`
- midpoint sampled max violation: `0.792980903536334`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.748675134594813, 1.497350269189626]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.140542759312762`
- midpoint sampled margin: `-1.1995280335472875`
- midpoint sampled max violation: `1.1995280335472875`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [0.0, 0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6583755035111154`
- midpoint sampled margin: `-0.8839468662357411`
- midpoint sampled max violation: `0.8839468662357411`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-0.748675134594813, 0.0]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `1.6493212596605105`
- midpoint sampled margin: `-0.8839468662357411`
- midpoint sampled max violation: `0.8839468662357411`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.497350269189626, -0.748675134594813] x [-1.497350269189626, -0.748675134594813]`
- l2 translation radius: `0.5293932645777435`
- certified upper violation: `2.166646075292376`
- midpoint sampled margin: `-1.1455687985395522`
- midpoint sampled max violation: `1.1455687985395522`
- pose drift bound: `0.9828431056362981`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
