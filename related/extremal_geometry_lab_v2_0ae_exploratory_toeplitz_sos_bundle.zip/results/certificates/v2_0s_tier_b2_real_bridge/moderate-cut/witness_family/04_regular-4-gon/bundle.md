# Rigid-motion certificate bundle: regular-4-gon in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3137804583371495`
- sampled max violation: `-0.3137804583371495`
- certified upper violation: `-0.26331422227480983`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932775`
- midpoint sampled max violation: `0.7860365966932775`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.830883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780867`
- midpoint sampled margin: `-0.6649527077155292`
- midpoint sampled max violation: `0.6649527077155292`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780864`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.830883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780867`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780864`
- midpoint sampled margin: `-0.6649527077155291`
- midpoint sampled max violation: `0.6649527077155291`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.830883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780867`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780864`
- midpoint sampled margin: `-0.6649527077155291`
- midpoint sampled max violation: `0.6649527077155291`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780862`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3986624656952849`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.830883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780867`
- midpoint sampled margin: `-0.6649527077155294`
- midpoint sampled max violation: `0.6649527077155294`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.3008745572780864`
- midpoint sampled margin: `-0.6649527077155293`
- midpoint sampled max violation: `0.6649527077155293`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.8308830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7837844290083336`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7795068596952388`
- midpoint sampled margin: `-0.08487231700740994`
- midpoint sampled max violation: `0.08487231700740994`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740949`
- midpoint sampled max violation: `0.08487231700740949`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952384`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083331`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083334`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7837844290083336`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7795068596952388`
- midpoint sampled margin: `-0.08487231700740971`
- midpoint sampled max violation: `0.08487231700740971`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740938`
- midpoint sampled max violation: `0.08487231700740938`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869716`
- midpoint sampled max violation: `0.18391807754869716`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952384`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083331`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7837844290083336`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7795068596952388`
- midpoint sampled margin: `-0.08487231700740971`
- midpoint sampled max violation: `0.08487231700740971`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740927`
- midpoint sampled max violation: `0.08487231700740927`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952384`
- midpoint sampled margin: `-0.0848723170074096`
- midpoint sampled max violation: `0.0848723170074096`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083331`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7837844290083336`
- midpoint sampled margin: `-0.1839180775486975`
- midpoint sampled max violation: `0.1839180775486975`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.7795068596952388`
- midpoint sampled margin: `-0.08487231700740994`
- midpoint sampled max violation: `0.08487231700740994`
- pose drift bound: `0.698395355491811`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740927`
- midpoint sampled max violation: `0.08487231700740927`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869705`
- midpoint sampled max violation: `0.18391807754869705`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952384`
- midpoint sampled margin: `-0.0848723170074096`
- midpoint sampled max violation: `0.0848723170074096`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083331`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7837844290083332`
- midpoint sampled margin: `-0.18391807754869738`
- midpoint sampled max violation: `0.18391807754869738`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.7795068596952385`
- midpoint sampled margin: `-0.08487231700740983`
- midpoint sampled max violation: `0.08487231700740983`
- pose drift bound: `0.6983953554918109`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `5.551115123125783e-17`
