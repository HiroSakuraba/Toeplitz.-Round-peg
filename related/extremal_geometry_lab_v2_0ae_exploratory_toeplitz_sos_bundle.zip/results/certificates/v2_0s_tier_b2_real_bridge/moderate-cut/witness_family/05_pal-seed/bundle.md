# Rigid-motion certificate bundle: pal-seed in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.36373066958946426`
- sampled max violation: `-0.36373066958946426`
- certified upper violation: `-0.20102550347443526`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9558830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554707`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.464857142298127`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9804021331298052`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9087844290083336`
- midpoint sampled margin: `-0.17115856000632634`
- midpoint sampled max violation: `0.17115856000632634`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9333034818466622`
- midpoint sampled margin: `-0.171158560006326`
- midpoint sampled max violation: `0.171158560006326`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336143`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336136`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9333034818466623`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083332`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952849`
- midpoint sampled margin: `-0.7860365966932775`
- midpoint sampled max violation: `0.7860365966932775`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.980402133129805`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981278`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554707`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9558830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9804021331298056`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981274`
- midpoint sampled margin: `-0.7512195416628509`
- midpoint sampled max violation: `0.7512195416628509`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554712`
- midpoint sampled margin: `-0.7512195416628509`
- midpoint sampled max violation: `0.7512195416628509`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9558830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336139`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9333034818466626`
- midpoint sampled margin: `-0.17115856000632645`
- midpoint sampled max violation: `0.17115856000632645`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083334`
- midpoint sampled margin: `-0.1711585600063259`
- midpoint sampled max violation: `0.1711585600063259`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083331`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9333034818466622`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336139`
- midpoint sampled margin: `-0.7860365966932775`
- midpoint sampled max violation: `0.7860365966932775`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.955883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554712`
- midpoint sampled margin: `-0.7512195416628508`
- midpoint sampled max violation: `0.7512195416628508`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981276`
- midpoint sampled margin: `-0.7512195416628508`
- midpoint sampled max violation: `0.7512195416628508`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9804021331298056`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9558830802914766`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554707`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.464857142298127`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9804021331298052`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952849`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9087844290083336`
- midpoint sampled margin: `-0.17115856000632634`
- midpoint sampled max violation: `0.17115856000632634`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9333034818466622`
- midpoint sampled margin: `-0.171158560006326`
- midpoint sampled max violation: `0.171158560006326`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336143`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336136`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9333034818466621`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083332`
- midpoint sampled margin: `-0.17115856000632634`
- midpoint sampled max violation: `0.17115856000632634`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952849`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.980402133129805`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981278`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554707`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9558830802914766`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424487`
- certified upper violation: `1.9804021331298056`
- midpoint sampled margin: `-1.1410365966932778`
- midpoint sampled max violation: `1.1410365966932778`
- pose drift bound: `0.8947448963411728`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981274`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554712`
- midpoint sampled margin: `-0.7512195416628507`
- midpoint sampled max violation: `0.7512195416628507`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7100000000000002, 1.4200000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9558830802914762`
- midpoint sampled margin: `-1.1410365966932774`
- midpoint sampled max violation: `1.1410365966932774`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336139`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424489`
- certified upper violation: `0.9333034818466626`
- midpoint sampled margin: `-0.17115856000632634`
- midpoint sampled max violation: `0.17115856000632634`
- pose drift bound: `0.894744896341173`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083332`
- midpoint sampled margin: `-0.1711585600063259`
- midpoint sampled max violation: `0.1711585600063259`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7100000000000002] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952853`
- midpoint sampled margin: `-0.7860365966932779`
- midpoint sampled max violation: `0.7860365966932779`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5236624656952846`
- midpoint sampled margin: `-0.7860365966932777`
- midpoint sampled max violation: `0.7860365966932777`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.9087844290083333`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `0.933303481846662`
- midpoint sampled margin: `-0.17115856000632623`
- midpoint sampled max violation: `0.17115856000632623`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7100000000000001, 0.0] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.5481815185336139`
- midpoint sampled margin: `-0.7860365966932775`
- midpoint sampled max violation: `0.7860365966932775`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.7100000000000002, 1.4200000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.955883080291476`
- midpoint sampled margin: `-1.1410365966932776`
- midpoint sampled max violation: `1.1410365966932776`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [0.0, 0.7100000000000002]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4564264078554712`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-0.7100000000000001, 0.0]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.4648571422981276`
- midpoint sampled margin: `-0.7512195416628505`
- midpoint sampled max violation: `0.7512195416628505`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4200000000000002, -0.7100000000000001] x [-1.4200000000000002, -0.7100000000000001]`
- l2 translation radius: `0.5020458146424488`
- certified upper violation: `1.9804021331298056`
- midpoint sampled margin: `-1.141036596693278`
- midpoint sampled max violation: `1.141036596693278`
- pose drift bound: `0.8947448963411729`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 4, 12]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
