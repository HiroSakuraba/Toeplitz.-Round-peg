# Rigid-motion certificate bundle: segment in pal-seed-cut+arc(0.01)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.42569169381653066`
- sampled max violation: `-0.42569169381653066`
- certified upper violation: `-0.3496297680097195`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584216`
- midpoint sampled margin: `-0.7972389814984715`
- midpoint sampled max violation: `0.7972389814984715`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920549`
- midpoint sampled max violation: `0.6123492019920549`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.3165665454636302`
- midpoint sampled margin: `-0.6522380973084446`
- midpoint sampled max violation: `0.6522380973084446`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916061`
- midpoint sampled margin: `-1.1507916649849634`
- midpoint sampled max violation: `1.1507916649849634`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000004999] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.35382323354662`
- midpoint sampled margin: `-0.4810540977008051`
- midpoint sampled max violation: `0.4810540977008051`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000004999] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.420810397679805`
- midpoint sampled margin: `-0.7782916649847138`
- midpoint sampled max violation: `0.7782916649847138`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000005, 0.0] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.4208103976798045`
- midpoint sampled margin: `-0.7782916649847139`
- midpoint sampled max violation: `0.7782916649847139`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000005, 0.0] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3538232335466198`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916057`
- midpoint sampled margin: `-1.1507916649849639`
- midpoint sampled max violation: `1.1507916649849639`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3165665454636302`
- midpoint sampled margin: `-0.6522380973084442`
- midpoint sampled max violation: `0.6522380973084442`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.2863701370407192`
- midpoint sampled margin: `-0.6123492019920548`
- midpoint sampled max violation: `0.6123492019920548`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.8073504981584214`
- midpoint sampled margin: `-0.7972389814984715`
- midpoint sampled max violation: `0.7972389814984715`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916061`
- midpoint sampled margin: `-1.150791664984964`
- midpoint sampled max violation: `1.150791664984964`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.31656654546363`
- midpoint sampled margin: `-0.6522380973084445`
- midpoint sampled max violation: `0.6522380973084445`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920551`
- midpoint sampled max violation: `0.6123492019920551`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584216`
- midpoint sampled margin: `-0.7972389814984713`
- midpoint sampled max violation: `0.7972389814984713`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000004999] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.4208103976798045`
- midpoint sampled margin: `-0.7782916649847138`
- midpoint sampled max violation: `0.7782916649847138`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000004999] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3538232335466205`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000005, 0.0] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.35382323354662`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000005, 0.0] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.4208103976798043`
- midpoint sampled margin: `-0.778291664984714`
- midpoint sampled max violation: `0.778291664984714`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584212`
- midpoint sampled margin: `-0.7972389814984714`
- midpoint sampled max violation: `0.7972389814984714`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920548`
- midpoint sampled max violation: `0.6123492019920548`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.31656654546363`
- midpoint sampled margin: `-0.6522380973084443`
- midpoint sampled max violation: `0.6522380973084443`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.874337662291606`
- midpoint sampled margin: `-1.150791664984964`
- midpoint sampled max violation: `1.150791664984964`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584216`
- midpoint sampled margin: `-0.7972389814984713`
- midpoint sampled max violation: `0.7972389814984713`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920549`
- midpoint sampled max violation: `0.6123492019920549`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.3165665454636302`
- midpoint sampled margin: `-0.6522380973084446`
- midpoint sampled max violation: `0.6522380973084446`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916061`
- midpoint sampled margin: `-1.1507916649849634`
- midpoint sampled max violation: `1.1507916649849634`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000004999] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.35382323354662`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000004999] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.420810397679805`
- midpoint sampled margin: `-0.7782916649847138`
- midpoint sampled max violation: `0.7782916649847138`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000005, 0.0] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.4208103976798045`
- midpoint sampled margin: `-0.7782916649847139`
- midpoint sampled max violation: `0.7782916649847139`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000005, 0.0] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3538232335466198`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916057`
- midpoint sampled margin: `-1.1507916649849639`
- midpoint sampled max violation: `1.1507916649849639`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3165665454636302`
- midpoint sampled margin: `-0.6522380973084442`
- midpoint sampled max violation: `0.6522380973084442`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.2863701370407192`
- midpoint sampled margin: `-0.6123492019920548`
- midpoint sampled max violation: `0.6123492019920548`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.8073504981584214`
- midpoint sampled margin: `-0.7972389814984713`
- midpoint sampled max violation: `0.7972389814984713`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8743376622916061`
- midpoint sampled margin: `-1.150791664984964`
- midpoint sampled max violation: `1.150791664984964`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000004999, 1.490000000001] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.31656654546363`
- midpoint sampled margin: `-0.6522380973084445`
- midpoint sampled max violation: `0.6522380973084445`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920549`
- midpoint sampled max violation: `0.6123492019920549`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000004999, 1.490000000001] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584216`
- midpoint sampled margin: `-0.7972389814984713`
- midpoint sampled max violation: `0.7972389814984713`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000004999] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.4208103976798045`
- midpoint sampled margin: `-0.7782916649847138`
- midpoint sampled max violation: `0.7782916649847138`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000004999] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.3538232335466205`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000005, 0.0] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.35382323354662`
- midpoint sampled margin: `-0.4810540977008049`
- midpoint sampled max violation: `0.4810540977008049`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000005, 0.0] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.4208103976798043`
- midpoint sampled margin: `-0.778291664984714`
- midpoint sampled max violation: `0.778291664984714`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.7450000000004999, 1.490000000001]`
- l2 translation radius: `0.5267945519843316`
- certified upper violation: `1.8073504981584212`
- midpoint sampled margin: `-0.7972389814984714`
- midpoint sampled max violation: `0.7972389814984714`
- pose drift bound: `0.9194936336838411`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.490000000001, -0.7450000000005] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.28637013704072`
- midpoint sampled margin: `-0.6123492019920548`
- midpoint sampled max violation: `0.6123492019920548`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.31656654546363`
- midpoint sampled margin: `-0.6522380973084443`
- midpoint sampled max violation: `0.6522380973084443`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.490000000001, -0.7450000000005] x [-1.490000000001, -0.7450000000005]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `1.874337662291606`
- midpoint sampled margin: `-1.150791664984964`
- midpoint sampled max violation: `1.150791664984964`
- pose drift bound: `0.919493633683841`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.606102373451164`
- midpoint sampled margin: `0.02426474676942436`
- midpoint sampled max violation: `-0.02426474676942436`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716416`
- midpoint sampled margin: `0.045478924941004695`
- midpoint sampled max violation: `-0.045478924941004695`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77134390254687`
- midpoint sampled margin: `-0.04681684610834114`
- midpoint sampled max violation: `0.04681684610834114`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77562121459599`
- midpoint sampled margin: `-0.14586212841439217`
- midpoint sampled max violation: `0.14586212841439217`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7713439025468698`
- midpoint sampled margin: `-0.04681684610834158`
- midpoint sampled max violation: `0.04681684610834158`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7756212145959898`
- midpoint sampled margin: `-0.14586212841439228`
- midpoint sampled max violation: `0.14586212841439228`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511639`
- midpoint sampled margin: `0.024264746769424472`
- midpoint sampled max violation: `-0.024264746769424472`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716417`
- midpoint sampled margin: `0.045478924941004584`
- midpoint sampled max violation: `-0.045478924941004584`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7756212145959899`
- midpoint sampled margin: `-0.1458621284143924`
- midpoint sampled max violation: `0.1458621284143924`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7713439025468699`
- midpoint sampled margin: `-0.04681684610834136`
- midpoint sampled max violation: `0.04681684610834136`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716419`
- midpoint sampled margin: `0.045478924941004695`
- midpoint sampled max violation: `-0.045478924941004695`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511642`
- midpoint sampled margin: `0.02426474676942414`
- midpoint sampled max violation: `-0.02426474676942414`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716414`
- midpoint sampled margin: `0.045478924941004695`
- midpoint sampled max violation: `-0.045478924941004695`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511641`
- midpoint sampled margin: `0.02426474676942425`
- midpoint sampled max violation: `-0.02426474676942425`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77562121459599`
- midpoint sampled margin: `-0.1458621284143924`
- midpoint sampled max violation: `0.1458621284143924`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77134390254687`
- midpoint sampled margin: `-0.0468168461083418`
- midpoint sampled max violation: `0.0468168461083418`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511642`
- midpoint sampled margin: `0.02426474676942425`
- midpoint sampled max violation: `-0.02426474676942425`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716416`
- midpoint sampled margin: `0.045478924941004584`
- midpoint sampled max violation: `-0.045478924941004584`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77134390254687`
- midpoint sampled margin: `-0.046816846108341026`
- midpoint sampled max violation: `0.046816846108341026`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77562121459599`
- midpoint sampled margin: `-0.14586212841439217`
- midpoint sampled max violation: `0.14586212841439217`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7713439025468696`
- midpoint sampled margin: `-0.04681684610834147`
- midpoint sampled max violation: `0.04681684610834147`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7756212145959898`
- midpoint sampled margin: `-0.14586212841439228`
- midpoint sampled max violation: `0.14586212841439228`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511639`
- midpoint sampled margin: `0.02426474676942436`
- midpoint sampled max violation: `-0.02426474676942436`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716414`
- midpoint sampled margin: `0.045478924941004584`
- midpoint sampled max violation: `-0.045478924941004584`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7756212145959899`
- midpoint sampled margin: `-0.1458621284143924`
- midpoint sampled max violation: `0.1458621284143924`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000004999] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7713439025468699`
- midpoint sampled margin: `-0.04681684610834147`
- midpoint sampled max violation: `0.04681684610834147`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716419`
- midpoint sampled margin: `0.04547892494100447`
- midpoint sampled max violation: `-0.04547892494100447`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000004999] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.606102373451164`
- midpoint sampled margin: `0.02426474676942425`
- midpoint sampled max violation: `-0.02426474676942425`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.7086342991716414`
- midpoint sampled margin: `0.04547892494100447`
- midpoint sampled max violation: `-0.04547892494100447`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000005, 0.0] x [0.0, 0.7450000000004999]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.6061023734511641`
- midpoint sampled margin: `0.02426474676942425`
- midpoint sampled max violation: `-0.02426474676942425`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77562121459599`
- midpoint sampled margin: `-0.1458621284143924`
- midpoint sampled max violation: `0.1458621284143924`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000005, 0.0] x [-0.7450000000005, 0.0]`
- l2 translation radius: `0.5267945519843314`
- certified upper violation: `0.77134390254687`
- midpoint sampled margin: `-0.0468168461083418`
- midpoint sampled max violation: `0.0468168461083418`
- pose drift bound: `0.7231440928340862`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`
