# Rigid-motion certificate bundle: disk-half in pal-seed-cut+arc(0.01)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.105088062083414`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3629824650218448`
- sampled max violation: `-0.3629824650218448`
- certified upper violation: `-0.2224897135419709`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058992`
- midpoint sampled margin: `-1.1678284930203604`
- midpoint sampled max violation: `1.1678284930203604`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058983`
- midpoint sampled margin: `-1.1678284930203597`
- midpoint sampled max violation: `1.1678284930203597`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944014`
- midpoint sampled margin: `-0.7953284930203605`
- midpoint sampled max violation: `0.7953284930203605`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944016`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705898`
- midpoint sampled margin: `-1.1678284930203602`
- midpoint sampled max violation: `1.1678284930203602`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344124`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344117`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705899`
- midpoint sampled margin: `-1.1678284930203608`
- midpoint sampled max violation: `1.1678284930203608`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058992`
- midpoint sampled margin: `-1.1678284930203604`
- midpoint sampled max violation: `1.1678284930203604`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058983`
- midpoint sampled margin: `-1.1678284930203597`
- midpoint sampled max violation: `1.1678284930203597`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944014`
- midpoint sampled margin: `-0.7953284930203607`
- midpoint sampled max violation: `0.7953284930203607`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944016`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705898`
- midpoint sampled margin: `-1.1678284930203602`
- midpoint sampled max violation: `1.1678284930203602`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344124`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344117`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705899`
- midpoint sampled margin: `-1.1678284930203608`
- midpoint sampled max violation: `1.1678284930203608`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058992`
- midpoint sampled margin: `-1.1678284930203604`
- midpoint sampled max violation: `1.1678284930203604`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058983`
- midpoint sampled margin: `-1.1678284930203597`
- midpoint sampled max violation: `1.1678284930203597`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944014`
- midpoint sampled margin: `-0.7953284930203605`
- midpoint sampled max violation: `0.7953284930203605`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944016`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705898`
- midpoint sampled margin: `-1.1678284930203602`
- midpoint sampled max violation: `1.1678284930203602`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344124`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344117`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705899`
- midpoint sampled margin: `-1.1678284930203608`
- midpoint sampled max violation: `1.1678284930203608`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058992`
- midpoint sampled margin: `-1.1678284930203604`
- midpoint sampled max violation: `1.1678284930203604`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.498465965434412`
- midpoint sampled margin: `-0.7587951042912502`
- midpoint sampled max violation: `0.7587951042912502`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0340764047058983`
- midpoint sampled margin: `-1.1678284930203597`
- midpoint sampled max violation: `1.1678284930203597`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944018`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944014`
- midpoint sampled margin: `-0.7953284930203605`
- midpoint sampled max violation: `0.7953284930203605`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5805491400944016`
- midpoint sampled margin: `-0.7953284930203603`
- midpoint sampled max violation: `0.7953284930203603`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705898`
- midpoint sampled margin: `-1.1678284930203602`
- midpoint sampled max violation: `1.1678284930203602`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344124`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4984659654344117`
- midpoint sampled margin: `-0.7587951042912501`
- midpoint sampled max violation: `0.7587951042912501`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.034076404705899`
- midpoint sampled margin: `-1.1678284930203608`
- midpoint sampled max violation: `1.1678284930203608`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.93233551600671`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067097`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782228`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.93233551600671`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067095`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782226`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067103`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067095`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782226`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.93233551600671`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.14586199788785836`
- midpoint sampled max violation: `0.14586199788785836`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067095`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782226`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9323355160067099`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
