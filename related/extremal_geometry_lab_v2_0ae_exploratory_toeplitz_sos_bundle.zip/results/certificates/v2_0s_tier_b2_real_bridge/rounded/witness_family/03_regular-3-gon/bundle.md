# Rigid-motion certificate bundle: regular-3-gon in pal-seed-cut+arc(0.01)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.35870489570874986`
- sampled max violation: `-0.35870489570874986`
- certified upper violation: `-0.17382049827370805`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192728`
- certified upper violation: `2.238411954778594`
- midpoint sampled margin: `-1.3047528533725108`
- midpoint sampled max violation: `1.3047528533725108`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.5933106314230088`
- midpoint sampled margin: `-0.7250560966473323`
- midpoint sampled max violation: `0.7250560966473323`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.4847157886084896`
- midpoint sampled margin: `-0.7816201817838543`
- midpoint sampled max violation: `0.7816201817838543`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.0657622239682194`
- midpoint sampled margin: `-1.3047528533725101`
- midpoint sampled max violation: `1.3047528533725101`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7836751345948128] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.7613407599640545`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7836751345948128] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192724`
- certified upper violation: `1.0826581850907568`
- midpoint sampled margin: `-0.23423271120180722`
- midpoint sampled max violation: `0.23423271120180722`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7836751345948128] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `0.9100084542803826`
- midpoint sampled margin: `-0.23423271120180678`
- midpoint sampled max violation: `0.23423271120180678`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7836751345948128] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.5886910291536802`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.783675134594813, 0.0] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.7330285964510863`
- midpoint sampled margin: `-0.7802657931284597`
- midpoint sampled max violation: `0.7802657931284597`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.783675134594813, 0.0] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0543460215777887`
- midpoint sampled margin: `-0.09081020741386181`
- midpoint sampled max violation: `0.09081020741386181`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.783675134594813, 0.0] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0083924725459803`
- midpoint sampled margin: `-0.10293760691055687`
- midpoint sampled max violation: `0.10293760691055687`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.783675134594813, 0.0] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6870750474192773`
- midpoint sampled margin: `-0.7634860407137618`
- midpoint sampled max violation: `0.7634860407137618`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.210099791265626`
- midpoint sampled margin: `-1.1553236080111682`
- midpoint sampled max violation: `1.1553236080111682`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6645592275689713`
- midpoint sampled margin: `-0.8744853420086748`
- midpoint sampled max violation: `0.8744853420086748`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6740665678159525`
- midpoint sampled margin: `-0.8744853420086748`
- midpoint sampled max violation: `0.8744853420086748`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `2.18272959263867`
- midpoint sampled margin: `-1.2058186959945307`
- midpoint sampled max violation: `1.2058186959945307`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192728`
- certified upper violation: `2.2100997912656264`
- midpoint sampled margin: `-1.1553236080111688`
- midpoint sampled max violation: `1.1553236080111688`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6645592275689713`
- midpoint sampled margin: `-0.8744853420086747`
- midpoint sampled max violation: `0.8744853420086747`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.6740665678159523`
- midpoint sampled margin: `-0.8744853420086747`
- midpoint sampled max violation: `0.8744853420086747`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.1827295926386703`
- midpoint sampled margin: `-1.2058186959945307`
- midpoint sampled max violation: `1.2058186959945307`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7836751345948128] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.7330285964510868`
- midpoint sampled margin: `-0.7802657931284601`
- midpoint sampled max violation: `0.7802657931284601`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7836751345948128] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192724`
- certified upper violation: `1.0543460215777891`
- midpoint sampled margin: `-0.0908102074138617`
- midpoint sampled max violation: `0.0908102074138617`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7836751345948128] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0083924725459799`
- midpoint sampled margin: `-0.10293760691055709`
- midpoint sampled max violation: `0.10293760691055709`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7836751345948128] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6870750474192775`
- midpoint sampled margin: `-0.7634860407137618`
- midpoint sampled max violation: `0.7634860407137618`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.783675134594813, 0.0] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.761340759964054`
- midpoint sampled margin: `-0.9129152860751043`
- midpoint sampled max violation: `0.9129152860751043`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.783675134594813, 0.0] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0826581850907566`
- midpoint sampled margin: `-0.2342327112018069`
- midpoint sampled max violation: `0.2342327112018069`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.783675134594813, 0.0] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `0.9100084542803828`
- midpoint sampled margin: `-0.23423271120180744`
- midpoint sampled max violation: `0.23423271120180744`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.783675134594813, 0.0] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.58869102915368`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.238411954778594`
- midpoint sampled margin: `-1.3047528533725106`
- midpoint sampled max violation: `1.3047528533725106`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.5933106314230083`
- midpoint sampled margin: `-0.7250560966473324`
- midpoint sampled max violation: `0.7250560966473324`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.4847157886084899`
- midpoint sampled margin: `-0.7816201817838545`
- midpoint sampled max violation: `0.7816201817838545`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `2.0657622239682203`
- midpoint sampled margin: `-1.3047528533725112`
- midpoint sampled max violation: `1.3047528533725112`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192728`
- certified upper violation: `2.182729592638669`
- midpoint sampled margin: `-1.2058186959945303`
- midpoint sampled max violation: `1.2058186959945303`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.674066567815952`
- midpoint sampled margin: `-0.8744853420086749`
- midpoint sampled max violation: `0.8744853420086749`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.6645592275689722`
- midpoint sampled margin: `-0.8744853420086749`
- midpoint sampled max violation: `0.8744853420086749`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.2100997912656264`
- midpoint sampled margin: `-1.1553236080111682`
- midpoint sampled max violation: `1.1553236080111682`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7836751345948128] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6870750474192775`
- midpoint sampled margin: `-0.7634860407137618`
- midpoint sampled max violation: `0.7634860407137618`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7836751345948128] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192724`
- certified upper violation: `1.0083924725459799`
- midpoint sampled margin: `-0.10293760691055687`
- midpoint sampled max violation: `0.10293760691055687`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7836751345948128] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0543460215777893`
- midpoint sampled margin: `-0.09081020741386181`
- midpoint sampled max violation: `0.09081020741386181`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7836751345948128] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.7330285964510872`
- midpoint sampled margin: `-0.7802657931284598`
- midpoint sampled max violation: `0.7802657931284598`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.783675134594813, 0.0] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.5886910291536798`
- midpoint sampled margin: `-0.9129152860751045`
- midpoint sampled max violation: `0.9129152860751045`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.783675134594813, 0.0] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `0.9100084542803821`
- midpoint sampled margin: `-0.2342327112018071`
- midpoint sampled max violation: `0.2342327112018071`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.783675134594813, 0.0] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.082658185090757`
- midpoint sampled margin: `-0.23423271120180722`
- midpoint sampled max violation: `0.23423271120180722`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.783675134594813, 0.0] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.7613407599640543`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.0657622239682194`
- midpoint sampled margin: `-1.3047528533725106`
- midpoint sampled max violation: `1.3047528533725106`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.4847157886084896`
- midpoint sampled margin: `-0.7816201817838541`
- midpoint sampled max violation: `0.7816201817838541`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.5933106314230085`
- midpoint sampled margin: `-0.7250560966473324`
- midpoint sampled max violation: `0.7250560966473324`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `2.238411954778594`
- midpoint sampled margin: `-1.3047528533725112`
- midpoint sampled max violation: `1.3047528533725112`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192728`
- certified upper violation: `2.06576222396822`
- midpoint sampled margin: `-1.3047528533725108`
- midpoint sampled max violation: `1.3047528533725108`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.4847157886084894`
- midpoint sampled margin: `-0.7816201817838541`
- midpoint sampled max violation: `0.7816201817838541`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.5933106314230083`
- midpoint sampled margin: `-0.7250560966473325`
- midpoint sampled max violation: `0.7250560966473325`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7836751345948128, 1.567350269189626] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.2384119547785937`
- midpoint sampled margin: `-1.3047528533725101`
- midpoint sampled max violation: `1.3047528533725101`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7836751345948128] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.5886910291536802`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7836751345948128] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192724`
- certified upper violation: `0.9100084542803825`
- midpoint sampled margin: `-0.23423271120180722`
- midpoint sampled max violation: `0.23423271120180722`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7836751345948128] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.082658185090757`
- midpoint sampled margin: `-0.23423271120180678`
- midpoint sampled max violation: `0.23423271120180678`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7836751345948128] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.7613407599640545`
- midpoint sampled margin: `-0.9129152860751042`
- midpoint sampled max violation: `0.9129152860751042`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.783675134594813, 0.0] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `1.6870750474192766`
- midpoint sampled margin: `-0.7634860407137621`
- midpoint sampled max violation: `0.7634860407137621`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.783675134594813, 0.0] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0083924725459794`
- midpoint sampled margin: `-0.10293760691055731`
- midpoint sampled max violation: `0.10293760691055731`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.783675134594813, 0.0] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.0543460215777893`
- midpoint sampled margin: `-0.09081020741386159`
- midpoint sampled max violation: `0.09081020741386159`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.783675134594813, 0.0] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.733028596451086`
- midpoint sampled margin: `-0.7802657931284601`
- midpoint sampled max violation: `0.7802657931284601`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.7836751345948128, 1.567350269189626]`
- l2 translation radius: `0.5541420019192727`
- certified upper violation: `2.1827295926386694`
- midpoint sampled margin: `-1.2058186959945307`
- midpoint sampled max violation: `1.2058186959945307`
- pose drift bound: `1.0075918429778272`
- certification method: `mixed`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [0.0, 0.7836751345948128]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6740665678159523`
- midpoint sampled margin: `-0.8744853420086746`
- midpoint sampled max violation: `0.8744853420086746`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-0.783675134594813, 0.0]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `1.6645592275689711`
- midpoint sampled margin: `-0.8744853420086746`
- midpoint sampled max violation: `0.8744853420086746`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.567350269189626, -0.783675134594813] x [-1.567350269189626, -0.783675134594813]`
- l2 translation radius: `0.5541420019192725`
- certified upper violation: `2.210099791265627`
- midpoint sampled margin: `-1.1553236080111688`
- midpoint sampled max violation: `1.1553236080111688`
- pose drift bound: `1.007591842977827`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
