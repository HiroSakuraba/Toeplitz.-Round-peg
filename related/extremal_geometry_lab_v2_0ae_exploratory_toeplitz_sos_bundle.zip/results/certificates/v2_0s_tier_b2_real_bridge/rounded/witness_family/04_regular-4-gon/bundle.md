# Rigid-motion certificate bundle: regular-4-gon in pal-seed-cut+arc(0.01)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3757419825642158`
- sampled max violation: `-0.3757419825642158`
- certified upper violation: `-0.32309558459708`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829236`
- midpoint sampled margin: `-0.6522375973076556`
- midpoint sampled max violation: `0.6522375973076556`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647275`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.42080953165323`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4208095316532308`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.316565621582924`
- midpoint sampled margin: `-0.6522375973076554`
- midpoint sampled max violation: `0.6522375973076554`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829236`
- midpoint sampled margin: `-0.6522375973076558`
- midpoint sampled max violation: `0.6522375973076558`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647275`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4208095316532305`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4208095316532303`
- midpoint sampled margin: `-0.7782914061648947`
- midpoint sampled max violation: `0.7782914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.316565621582924`
- midpoint sampled margin: `-0.6522375973076554`
- midpoint sampled max violation: `0.6522375973076554`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829236`
- midpoint sampled margin: `-0.6522375973076556`
- midpoint sampled max violation: `0.6522375973076556`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647275`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.42080953165323`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4208095316532303`
- midpoint sampled margin: `-0.7782914061648947`
- midpoint sampled max violation: `0.7782914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.316565621582924`
- midpoint sampled margin: `-0.6522375973076556`
- midpoint sampled max violation: `0.6522375973076556`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829236`
- midpoint sampled margin: `-0.6522375973076556`
- midpoint sampled max violation: `0.6522375973076556`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647275`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.420809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.42080953165323`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4208095316532303`
- midpoint sampled margin: `-0.7782914061648947`
- midpoint sampled max violation: `0.7782914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.874336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.316565621582924`
- midpoint sampled margin: `-0.6522375973076556`
- midpoint sampled max violation: `0.6522375973076556`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.3165656215829238`
- midpoint sampled margin: `-0.6522375973076553`
- midpoint sampled max violation: `0.6522375973076553`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.8743367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338239`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207291`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.04681623734657081`
- midpoint sampled max violation: `0.04681623734657081`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207286`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338233`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338239`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207291`
- midpoint sampled margin: `-0.04681623734657103`
- midpoint sampled max violation: `0.04681623734657103`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.04681623734657081`
- midpoint sampled max violation: `0.04681623734657081`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207286`
- midpoint sampled margin: `-0.04681623734657114`
- midpoint sampled max violation: `0.04681623734657114`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338233`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338239`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207291`
- midpoint sampled margin: `-0.04681623734657103`
- midpoint sampled max violation: `0.04681623734657103`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.0468162373465707`
- midpoint sampled max violation: `0.0468162373465707`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207286`
- midpoint sampled margin: `-0.04681623734657103`
- midpoint sampled max violation: `0.04681623734657103`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338233`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338239`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207291`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.04681623734657059`
- midpoint sampled max violation: `0.04681623734657059`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7713430365207286`
- midpoint sampled margin: `-0.04681623734657103`
- midpoint sampled max violation: `0.04681623734657103`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338233`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.7756206058338238`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.771343036520729`
- midpoint sampled margin: `-0.046816237346571254`
- midpoint sampled max violation: `0.046816237346571254`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
