# Rigid-motion certificate bundle: pal-seed in pal-seed-cut+arc(0.01)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.4256921938165306`
- sampled max violation: `-0.4256921938165306`
- certified upper violation: `-0.2608068657967054`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.999336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639325`
- midpoint sampled margin: `-0.7417580174357843`
- midpoint sampled max violation: `0.7417580174357843`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4805482066029647`
- midpoint sampled margin: `-0.7417580174357843`
- midpoint sampled max violation: `0.7417580174357843`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0238558491030565`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.545809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.57032858449156`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5703285844915595`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5458095316532303`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.023855849103056`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4805482066029647`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639323`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.9993367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.023855849103057`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.480548206602965`
- midpoint sampled margin: `-0.7417580174357845`
- midpoint sampled max violation: `0.7417580174357845`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639325`
- midpoint sampled margin: `-0.7417580174357845`
- midpoint sampled max violation: `0.7417580174357845`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.999336796264728`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.57032858449156`
- midpoint sampled margin: `-0.7782914061648947`
- midpoint sampled max violation: `0.7782914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5458095316532314`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.54580953165323`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5703285844915593`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.999336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.471664375763933`
- midpoint sampled margin: `-0.7417580174357844`
- midpoint sampled max violation: `0.7417580174357844`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.480548206602965`
- midpoint sampled margin: `-0.7417580174357844`
- midpoint sampled max violation: `0.7417580174357844`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0238558491030565`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.999336796264728`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639325`
- midpoint sampled margin: `-0.7417580174357843`
- midpoint sampled max violation: `0.7417580174357843`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4805482066029647`
- midpoint sampled margin: `-0.7417580174357843`
- midpoint sampled max violation: `0.7417580174357843`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0238558491030565`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.545809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.57032858449156`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.570328584491559`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5458095316532303`
- midpoint sampled margin: `-0.7782914061648947`
- midpoint sampled max violation: `0.7782914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.023855849103056`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4805482066029652`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639323`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.9993367962647277`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.023855849103057`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.480548206602965`
- midpoint sampled margin: `-0.7417580174357845`
- midpoint sampled max violation: `0.7417580174357845`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.4716643757639325`
- midpoint sampled margin: `-0.7417580174357845`
- midpoint sampled max violation: `0.7417580174357845`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7450000000000001, 1.4900000000000002] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.9993367962647275`
- midpoint sampled margin: `-1.150791406164894`
- midpoint sampled max violation: `1.150791406164894`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.57032858449156`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.545809531653231`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5458095316532305`
- midpoint sampled margin: `-0.7782914061648946`
- midpoint sampled max violation: `0.7782914061648946`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.5703285844915593`
- midpoint sampled margin: `-0.7782914061648945`
- midpoint sampled max violation: `0.7782914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.7450000000000001, 1.4900000000000002]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.999336796264727`
- midpoint sampled margin: `-1.1507914061648945`
- midpoint sampled max violation: `1.1507914061648945`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.471664375763933`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `1.480548206602965`
- midpoint sampled margin: `-0.7417580174357842`
- midpoint sampled max violation: `0.7417580174357842`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4900000000000002, -0.7450000000000001] x [-1.4900000000000002, -0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `2.0238558491030565`
- midpoint sampled margin: `-1.1507914061648947`
- midpoint sampled max violation: `1.1507914061648947`
- pose drift bound: `0.9194936336827021`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395217`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772766`
- midpoint sampled margin: `-0.11207933345659693`
- midpoint sampled max violation: `0.11207933345659693`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.921435174980564`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.11207933345659638`
- midpoint sampled max violation: `0.11207933345659638`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805636`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782228`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395214`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772765`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805639`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772765`
- midpoint sampled margin: `-0.1120793334565966`
- midpoint sampled max violation: `0.1120793334565966`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395217`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772758`
- midpoint sampled margin: `-0.11207933345659671`
- midpoint sampled max violation: `0.11207933345659671`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395216`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805638`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395217`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772766`
- midpoint sampled margin: `-0.11207933345659704`
- midpoint sampled max violation: `0.11207933345659704`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.921435174980564`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.860823664978223`
- midpoint sampled margin: `-0.1120793334565966`
- midpoint sampled max violation: `0.1120793334565966`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805636`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782226`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395214`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772765`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782234`
- midpoint sampled margin: `-0.11207933345659682`
- midpoint sampled max violation: `0.11207933345659682`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805639`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8984818211772765`
- midpoint sampled margin: `-0.11207933345659671`
- midpoint sampled max violation: `0.11207933345659671`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7450000000000001] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395217`
- midpoint sampled margin: `-0.14586199788785859`
- midpoint sampled max violation: `0.14586199788785859`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.898481821177276`
- midpoint sampled margin: `-0.11207933345659693`
- midpoint sampled max violation: `0.11207933345659693`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [0.0, 0.7450000000000001]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8029567767395216`
- midpoint sampled margin: `-0.1458619978878587`
- midpoint sampled max violation: `0.1458619978878587`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.8608236649782233`
- midpoint sampled margin: `-0.11207933345659704`
- midpoint sampled max violation: `0.11207933345659704`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7450000000000001, 0.0] x [-0.7450000000000001, 0.0]`
- l2 translation radius: `0.526794551983978`
- certified upper violation: `0.9214351749805638`
- midpoint sampled margin: `-0.1458619978878588`
- midpoint sampled max violation: `0.1458619978878588`
- pose drift bound: `0.72314409283334`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
