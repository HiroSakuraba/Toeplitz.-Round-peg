# Rigid-motion certificate bundle: regular-4-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.38306249063990455`
- sampled max violation: `-0.38306249063990455`
- certified upper violation: `-0.32968937203783677`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917984`
- midpoint sampled max violation: `0.6508105720917984`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917983`
- midpoint sampled max violation: `0.6508105720917983`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.425919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953615`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917979`
- midpoint sampled max violation: `0.6508105720917979`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917982`
- midpoint sampled max violation: `0.6508105720917982`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917984`
- midpoint sampled max violation: `0.6508105720917984`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917985`
- midpoint sampled max violation: `0.6508105720917985`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.425919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953615`
- midpoint sampled margin: `-0.778716088617589`
- midpoint sampled max violation: `0.778716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917982`
- midpoint sampled max violation: `0.6508105720917982`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917979`
- midpoint sampled max violation: `0.6508105720917979`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917984`
- midpoint sampled max violation: `0.6508105720917984`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917983`
- midpoint sampled max violation: `0.6508105720917983`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.425919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953615`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917982`
- midpoint sampled max violation: `0.6508105720917982`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917979`
- midpoint sampled max violation: `0.6508105720917979`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917984`
- midpoint sampled max violation: `0.6508105720917984`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843852`
- midpoint sampled margin: `-0.6508105720917983`
- midpoint sampled max violation: `0.6508105720917983`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.425919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953615`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4259198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.882490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917982`
- midpoint sampled max violation: `0.6508105720917982`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3194775825843856`
- midpoint sampled margin: `-0.6508105720917982`
- midpoint sampled max violation: `0.6508105720917982`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.8824908771519022`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439378`
- midpoint sampled margin: `-0.04291079278034304`
- midpoint sampled max violation: `0.04291079278034304`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570326`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439377`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570324`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.042910792780343265`
- midpoint sampled max violation: `0.042910792780343265`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439378`
- midpoint sampled margin: `-0.04291079278034304`
- midpoint sampled max violation: `0.04291079278034304`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570326`
- midpoint sampled margin: `-0.14195655332163082`
- midpoint sampled max violation: `0.14195655332163082`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439377`
- midpoint sampled margin: `-0.042910792780343376`
- midpoint sampled max violation: `0.042910792780343376`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570324`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.042910792780343265`
- midpoint sampled max violation: `0.042910792780343265`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439378`
- midpoint sampled margin: `-0.04291079278034293`
- midpoint sampled max violation: `0.04291079278034293`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570326`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439377`
- midpoint sampled margin: `-0.042910792780343265`
- midpoint sampled max violation: `0.042910792780343265`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570324`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439378`
- midpoint sampled margin: `-0.04291079278034282`
- midpoint sampled max violation: `0.04291079278034282`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570326`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439377`
- midpoint sampled margin: `-0.042910792780343265`
- midpoint sampled max violation: `0.042910792780343265`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570324`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7764007525570327`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.7721231832439379`
- midpoint sampled margin: `-0.04291079278034349`
- midpoint sampled max violation: `0.04291079278034349`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
