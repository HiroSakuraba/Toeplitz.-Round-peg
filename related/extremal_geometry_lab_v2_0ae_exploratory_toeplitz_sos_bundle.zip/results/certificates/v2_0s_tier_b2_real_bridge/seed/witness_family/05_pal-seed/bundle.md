# Rigid-motion certificate bundle: pal-seed in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.43301270189221935`
- sampled max violation: `-0.43301270189221935`
- certified upper violation: `-0.2674006532374622`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337978`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044263`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.575438858233691`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336905`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044263`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337972`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044263`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337983`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.0074908771519024`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.7787160886175891`
- midpoint sampled max violation: `0.7787160886175891`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.550919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953615`
- midpoint sampled margin: `-0.778716088617589`
- midpoint sampled max violation: `0.778716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337983`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044268`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337978`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044263`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.575438858233691`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336905`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953617`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044268`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337976`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044263`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337983`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.550919805395362`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5509198053953615`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5754388582336907`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.007490877151902`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4746467978337983`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4834601676044268`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `2.032009929990231`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004854`
- midpoint sampled margin: `-0.10817388889036916`
- midpoint sampled max violation: `0.10817388889036916`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037729`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014319`
- midpoint sampled margin: `-0.10817388889036861`
- midpoint sampled max violation: `0.10817388889036861`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037727`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.861603811701432`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004854`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014322`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037727`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004853`
- midpoint sampled margin: `-0.10817388889036883`
- midpoint sampled max violation: `0.10817388889036883`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429071`
- midpoint sampled margin: `-0.14195655332163082`
- midpoint sampled max violation: `0.14195655332163082`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.899261967900485`
- midpoint sampled margin: `-0.10817388889036894`
- midpoint sampled max violation: `0.10817388889036894`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014322`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037727`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004854`
- midpoint sampled margin: `-0.10817388889036927`
- midpoint sampled max violation: `0.10817388889036927`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037729`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014319`
- midpoint sampled margin: `-0.10817388889036883`
- midpoint sampled max violation: `0.10817388889036883`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037725`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.861603811701432`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004854`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014322`
- midpoint sampled margin: `-0.10817388889036905`
- midpoint sampled max violation: `0.10817388889036905`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037727`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004853`
- midpoint sampled margin: `-0.10817388889036894`
- midpoint sampled max violation: `0.10817388889036894`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429071`
- midpoint sampled margin: `-0.1419565533216306`
- midpoint sampled max violation: `0.1419565533216306`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8992619679004852`
- midpoint sampled margin: `-0.10817388889036916`
- midpoint sampled max violation: `0.10817388889036916`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, 0.0] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8021240143429074`
- midpoint sampled margin: `-0.14195655332163093`
- midpoint sampled max violation: `0.14195655332163093`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.8616038117014322`
- midpoint sampled margin: `-0.10817388889036927`
- midpoint sampled max violation: `0.10817388889036927`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, 0.0] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `0.9222153217037727`
- midpoint sampled margin: `-0.14195655332163104`
- midpoint sampled max violation: `0.14195655332163104`
- pose drift bound: `0.7266796267392727`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 4, 12]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
