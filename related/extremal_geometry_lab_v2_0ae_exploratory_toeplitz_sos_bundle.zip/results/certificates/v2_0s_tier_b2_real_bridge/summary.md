# Extremal Geometry Lab v2.0s — Tier B2 real bridge/export run

Representative states:
- `seed`
- `mild-cut`
- `moderate-cut`
- `rounded`
- `targeted-descendant`

- max_vertices: `4`
- refine_kwargs: `{'angle_steps': 24, 'cert_n': 48, 'initial_theta_intervals': 4, 'initial_translation_intervals': 4, 'max_depth': 1}`

## seed
- runtime: `42.983` s
- move_history: `None`
- joint_certified: `False`
- passed_witness_count: `0` / `6`
- failed_witness_count: `6`
- classification_incomplete_count: `5`
- selected_box_count: `0`
- output_dir: `results/certificates/v2_0s_tier_b2_real_bridge/seed`

## mild-cut
- runtime: `43.248` s
- move_history: `['small-corner-cut']`
- joint_certified: `False`
- passed_witness_count: `0` / `6`
- failed_witness_count: `6`
- classification_incomplete_count: `5`
- selected_box_count: `0`
- output_dir: `results/certificates/v2_0s_tier_b2_real_bridge/mild-cut`

## moderate-cut
- runtime: `20.479` s
- move_history: `['medium-corner-cut']`
- joint_certified: `False`
- passed_witness_count: `0` / `6`
- failed_witness_count: `6`
- classification_incomplete_count: `2`
- selected_box_count: `0`
- output_dir: `results/certificates/v2_0s_tier_b2_real_bridge/moderate-cut`

## rounded
- runtime: `43.519` s
- move_history: `['small-arc-rounding']`
- joint_certified: `False`
- passed_witness_count: `0` / `6`
- failed_witness_count: `6`
- classification_incomplete_count: `5`
- selected_box_count: `0`
- output_dir: `results/certificates/v2_0s_tier_b2_real_bridge/rounded`

## targeted-descendant
- runtime: `34.473` s
- move_history: `['small-arc-rounding', 'small-arc-rounding', 'targeted-square-rounding']`
- joint_certified: `False`
- passed_witness_count: `0` / `6`
- failed_witness_count: `6`
- classification_incomplete_count: `3`
- selected_box_count: `0`
- output_dir: `results/certificates/v2_0s_tier_b2_real_bridge/targeted-descendant`

## Batch result
- all_exports_completed: `True`
- all_joint_certified: `False`
- total_runtime_sec: `184.702`