# Rigid-motion certificate bundle: segment in recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]-cut+arc(0.016)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3919410560126269`
- sampled max violation: `-0.3919410560126269`
- certified upper violation: `-0.31716701602485137`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503665`
- midpoint sampled max violation: `0.7871299586503665`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959587`
- midpoint sampled max violation: `0.6139923397959587`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000005, 1.447190000001] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865512`
- midpoint sampled margin: `-0.6589605273843252`
- midpoint sampled max violation: `0.6589605273843252`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000005, 1.447190000001] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.8436647899645988`
- midpoint sampled margin: `-1.1406826421368583`
- midpoint sampled max violation: `1.1406826421368583`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.49175659770080493`
- midpoint sampled max violation: `0.49175659770080493`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407298`
- midpoint sampled margin: `-0.7788851421366089`
- midpoint sampled max violation: `0.7788851421366089`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000005, 0.0] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366088`
- midpoint sampled max violation: `0.7788851421366088`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000005, 0.0] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008048`
- midpoint sampled max violation: `0.4917565977008048`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368585`
- midpoint sampled max violation: `1.1406826421368585`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865516`
- midpoint sampled margin: `-0.6589605273843249`
- midpoint sampled max violation: `0.6589605273843249`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.275631752320637`
- midpoint sampled margin: `-0.6139923397959586`
- midpoint sampled max violation: `0.6139923397959586`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503665`
- midpoint sampled max violation: `0.7871299586503665`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368588`
- midpoint sampled max violation: `1.1406826421368588`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.306154873886551`
- midpoint sampled margin: `-0.6589605273843253`
- midpoint sampled max violation: `0.6589605273843253`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000005, 1.447190000001] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959589`
- midpoint sampled max violation: `0.6139923397959589`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000005, 1.447190000001] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314143`
- midpoint sampled margin: `-0.7871299586503661`
- midpoint sampled max violation: `0.7871299586503661`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366089`
- midpoint sampled max violation: `0.7788851421366089`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008048`
- midpoint sampled max violation: `0.4917565977008048`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000005, 0.0] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3368118133684463`
- midpoint sampled margin: `-0.4917565977008047`
- midpoint sampled max violation: `0.4917565977008047`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000005, 0.0] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366086`
- midpoint sampled max violation: `0.7788851421366086`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503662`
- midpoint sampled max violation: `0.7871299586503662`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959586`
- midpoint sampled max violation: `0.6139923397959586`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865514`
- midpoint sampled margin: `-0.658960527384325`
- midpoint sampled max violation: `0.658960527384325`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368592`
- midpoint sampled max violation: `1.1406826421368592`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503663`
- midpoint sampled max violation: `0.7871299586503663`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959587`
- midpoint sampled max violation: `0.6139923397959587`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000005, 1.447190000001] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865512`
- midpoint sampled margin: `-0.6589605273843252`
- midpoint sampled max violation: `0.6589605273843252`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000005, 1.447190000001] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.8436647899645988`
- midpoint sampled margin: `-1.1406826421368583`
- midpoint sampled max violation: `1.1406826421368583`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008047`
- midpoint sampled max violation: `0.4917565977008047`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407298`
- midpoint sampled margin: `-0.7788851421366089`
- midpoint sampled max violation: `0.7788851421366089`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000005, 0.0] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366088`
- midpoint sampled max violation: `0.7788851421366088`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000005, 0.0] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008048`
- midpoint sampled max violation: `0.4917565977008048`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368585`
- midpoint sampled max violation: `1.1406826421368585`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865516`
- midpoint sampled margin: `-0.6589605273843251`
- midpoint sampled max violation: `0.6589605273843251`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.275631752320637`
- midpoint sampled margin: `-0.6139923397959586`
- midpoint sampled max violation: `0.6139923397959586`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503663`
- midpoint sampled max violation: `0.7871299586503663`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368588`
- midpoint sampled max violation: `1.1406826421368588`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000005, 1.447190000001] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.306154873886551`
- midpoint sampled margin: `-0.6589605273843253`
- midpoint sampled max violation: `0.6589605273843253`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000005, 1.447190000001] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959587`
- midpoint sampled max violation: `0.6139923397959587`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000005, 1.447190000001] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314143`
- midpoint sampled margin: `-0.7871299586503661`
- midpoint sampled max violation: `0.7871299586503661`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366089`
- midpoint sampled max violation: `0.7788851421366089`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008048`
- midpoint sampled max violation: `0.4917565977008048`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000005, 0.0] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.336811813368446`
- midpoint sampled margin: `-0.4917565977008047`
- midpoint sampled max violation: `0.4917565977008047`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000005, 0.0] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.4031680637407296`
- midpoint sampled margin: `-0.7788851421366086`
- midpoint sampled max violation: `0.7788851421366086`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.7235950000005, 1.447190000001]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.7766776258314145`
- midpoint sampled margin: `-0.7871299586503662`
- midpoint sampled max violation: `0.7871299586503662`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.447190000001, -0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.2756317523206375`
- midpoint sampled margin: `-0.6139923397959586`
- midpoint sampled max violation: `0.6139923397959586`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.3061548738865514`
- midpoint sampled margin: `-0.658960527384325`
- midpoint sampled max violation: `0.658960527384325`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.447190000001, -0.7235950000005] x [-1.447190000001, -0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `1.843664789964599`
- midpoint sampled margin: `-1.1406826421368592`
- midpoint sampled max violation: `1.1406826421368592`
- pose drift bound: `0.9043580130325429`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899799`
- midpoint sampled margin: `0.0012166089655205603`
- midpoint sampled max violation: `-0.0012166089655205603`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005723`
- midpoint sampled margin: `0.026348174021103787`
- midpoint sampled max violation: `-0.026348174021103787`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758006`
- midpoint sampled margin: `-0.06594759702824204`
- midpoint sampled max violation: `0.06594759702824204`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249206`
- midpoint sampled margin: `-0.16499287933429285`
- midpoint sampled max violation: `0.16499287933429285`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758005`
- midpoint sampled margin: `-0.06594759702824216`
- midpoint sampled max violation: `0.06594759702824216`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249205`
- midpoint sampled margin: `-0.16499287933429296`
- midpoint sampled max violation: `0.16499287933429296`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899798`
- midpoint sampled margin: `0.0012166089655207823`
- midpoint sampled max violation: `-0.0012166089655207823`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005722`
- midpoint sampled margin: `0.0263481740211039`
- midpoint sampled max violation: `-0.0263481740211039`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249206`
- midpoint sampled margin: `-0.1649928793342933`
- midpoint sampled max violation: `0.1649928793342933`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758006`
- midpoint sampled margin: `-0.06594759702824227`
- midpoint sampled max violation: `0.06594759702824227`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005725`
- midpoint sampled margin: `0.0263481740211039`
- midpoint sampled max violation: `-0.0263481740211039`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899797`
- midpoint sampled margin: `0.0012166089655204493`
- midpoint sampled max violation: `-0.0012166089655204493`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005722`
- midpoint sampled margin: `0.02634817402110412`
- midpoint sampled max violation: `-0.02634817402110412`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899797`
- midpoint sampled margin: `0.0012166089655204493`
- midpoint sampled max violation: `-0.0012166089655204493`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249205`
- midpoint sampled margin: `-0.1649928793342933`
- midpoint sampled max violation: `0.1649928793342933`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758005`
- midpoint sampled margin: `-0.06594759702824249`
- midpoint sampled max violation: `0.06594759702824249`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899802`
- midpoint sampled margin: `0.0012166089655204493`
- midpoint sampled max violation: `-0.0012166089655204493`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005723`
- midpoint sampled margin: `0.026348174021103676`
- midpoint sampled max violation: `-0.026348174021103676`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758006`
- midpoint sampled margin: `-0.06594759702824182`
- midpoint sampled max violation: `0.06594759702824182`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249206`
- midpoint sampled margin: `-0.16499287933429285`
- midpoint sampled max violation: `0.16499287933429285`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758003`
- midpoint sampled margin: `-0.06594759702824193`
- midpoint sampled max violation: `0.06594759702824193`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249205`
- midpoint sampled margin: `-0.16499287933429296`
- midpoint sampled max violation: `0.16499287933429296`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899798`
- midpoint sampled margin: `0.0012166089655205603`
- midpoint sampled max violation: `-0.0012166089655205603`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.709529239000572`
- midpoint sampled margin: `0.026348174021103787`
- midpoint sampled max violation: `-0.026348174021103787`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249206`
- midpoint sampled margin: `-0.1649928793342933`
- midpoint sampled max violation: `0.1649928793342933`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000005] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758006`
- midpoint sampled margin: `-0.06594759702824238`
- midpoint sampled max violation: `0.06594759702824238`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005725`
- midpoint sampled margin: `0.026348174021103676`
- midpoint sampled max violation: `-0.026348174021103676`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000005] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899797`
- midpoint sampled margin: `0.0012166089655204493`
- midpoint sampled max violation: `-0.0012166089655204493`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7095292390005722`
- midpoint sampled margin: `0.0263481740211039`
- midpoint sampled max violation: `-0.0263481740211039`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000005, 0.0] x [0.0, 0.7235950000005]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.6124232265899797`
- midpoint sampled margin: `0.0012166089655205603`
- midpoint sampled max violation: `-0.0012166089655205603`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7765161544249205`
- midpoint sampled margin: `-0.1649928793342933`
- midpoint sampled max violation: `0.1649928793342933`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000005, 0.0] x [-0.7235950000005, 0.0]`
- l2 translation radius: `0.5116589313330334`
- certified upper violation: `0.7722388423758005`
- midpoint sampled margin: `-0.06594759702824249`
- midpoint sampled max violation: `0.06594759702824249`
- pose drift bound: `0.7080084721827882`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
