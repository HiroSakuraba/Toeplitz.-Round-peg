# Rigid-motion certificate bundle: disk-half in recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]-cut+arc(0.016)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `5.105088062083414`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.32923182721794103`
- sampled max violation: `-0.32923182721794103`
- certified upper violation: `-0.19002696155710286`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722546`
- midpoint sampled max violation: `1.1577194701722546`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5629068061553264`
- midpoint sampled margin: `-0.7959219701722554`
- midpoint sampled max violation: `0.7959219701722554`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314042`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155327`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722551`
- midpoint sampled max violation: `0.7959219701722551`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039253`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.157719470172255`
- midpoint sampled max violation: `1.157719470172255`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.003403532378892`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722546`
- midpoint sampled max violation: `1.1577194701722546`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5629068061553264`
- midpoint sampled margin: `-0.7959219701722554`
- midpoint sampled max violation: `0.7959219701722554`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314042`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155327`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722551`
- midpoint sampled max violation: `0.7959219701722551`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085414`
- midpoint sampled max violation: `0.16927031812085414`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.1577194701722553`
- midpoint sampled max violation: `1.1577194701722553`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722546`
- midpoint sampled max violation: `1.1577194701722546`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5629068061553264`
- midpoint sampled margin: `-0.7959219701722554`
- midpoint sampled max violation: `0.7959219701722554`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314042`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155327`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722551`
- midpoint sampled max violation: `0.7959219701722551`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.157719470172255`
- midpoint sampled max violation: `1.157719470172255`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.760438242095154`
- midpoint sampled max violation: `0.760438242095154`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722546`
- midpoint sampled max violation: `1.1577194701722546`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5629068061553264`
- midpoint sampled margin: `-0.7959219701722554`
- midpoint sampled max violation: `0.7959219701722554`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314042`
- certification method: `mixed`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039255`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155327`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722551`
- midpoint sampled max violation: `0.7959219701722551`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085402`
- midpoint sampled max violation: `0.16927031812085402`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9362551541039251`
- midpoint sampled margin: `-0.16927031812085436`
- midpoint sampled max violation: `0.16927031812085436`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.562906806155326`
- midpoint sampled margin: `-0.7959219701722552`
- midpoint sampled max violation: `0.7959219701722552`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788912`
- midpoint sampled margin: `-1.157719470172255`
- midpoint sampled max violation: `1.157719470172255`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4877275807143295`
- midpoint sampled margin: `-0.7604382420951539`
- midpoint sampled max violation: `0.7604382420951539`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `2.0034035323788917`
- midpoint sampled margin: `-1.1577194701722555`
- midpoint sampled max violation: `1.1577194701722555`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
