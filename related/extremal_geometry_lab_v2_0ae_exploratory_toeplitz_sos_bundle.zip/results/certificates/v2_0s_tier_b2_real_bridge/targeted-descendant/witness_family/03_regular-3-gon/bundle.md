# Rigid-motion certificate bundle: regular-3-gon in recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]-cut+arc(0.016)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `64`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3249542579048461`
- sampled max violation: `-0.3249542579048461`
- certified upper violation: `-0.1413577462888399`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.2077390824515875`
- midpoint sampled margin: `-1.294643830524406`
- midpoint sampled max violation: `1.294643830524406`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5826497563128914`
- midpoint sampled margin: `-0.7266992344512363`
- midpoint sampled max violation: `0.7266992344512363`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.474304117031411`
- midpoint sampled margin: `-0.7912730211318456`
- midpoint sampled max violation: `0.7912730211318456`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.035089351641213`
- midpoint sampled margin: `-1.2946438305244055`
- midpoint sampled max violation: `1.2946438305244055`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.743698426024979`
- midpoint sampled margin: `-0.9135087632269997`
- midpoint sampled max violation: `0.9135087632269997`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0835531249196877`
- midpoint sampled margin: `-0.25336346212170835`
- midpoint sampled max violation: `0.25336346212170835`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `0.9109033941093136`
- midpoint sampled margin: `-0.2533634621217077`
- midpoint sampled max violation: `0.2533634621217077`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5710486952146054`
- midpoint sampled margin: `-0.9135087632269995`
- midpoint sampled max violation: `0.9135087632269995`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7622701345948131, 0.0] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.716285845798026`
- midpoint sampled margin: `-0.7869882232043409`
- midpoint sampled max violation: `0.7869882232043409`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7622701345948131, 0.0] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.05524096140672`
- midpoint sampled margin: `-0.11385834521776572`
- midpoint sampled max violation: `0.11385834521776572`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7622701345948131, 0.0] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0107430479327837`
- midpoint sampled margin: `-0.13112772002655393`
- midpoint sampled max violation: `0.13112772002655393`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7622701345948131, 0.0] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.669432713480202`
- midpoint sampled margin: `-0.7640795178656569`
- midpoint sampled max violation: `0.7640795178656569`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1794269189386197`
- midpoint sampled margin: `-1.1452145851630633`
- midpoint sampled max violation: `1.1452145851630633`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6538208428488899`
- midpoint sampled margin: `-0.8761284798125786`
- midpoint sampled max violation: `0.8761284798125786`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.663654896238874`
- midpoint sampled margin: `-0.8761284798125786`
- midpoint sampled max violation: `0.8761284798125786`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.154498986685803`
- midpoint sampled margin: `-1.2009177384143035`
- midpoint sampled max violation: `1.2009177384143035`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1794269189386197`
- midpoint sampled margin: `-1.145214585163064`
- midpoint sampled max violation: `1.145214585163064`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6538208428488899`
- midpoint sampled margin: `-0.8761284798125787`
- midpoint sampled max violation: `0.8761284798125787`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6636548962388737`
- midpoint sampled margin: `-0.8761284798125787`
- midpoint sampled max violation: `0.8761284798125787`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1544989866858035`
- midpoint sampled margin: `-1.2009177384143037`
- midpoint sampled max violation: `1.2009177384143037`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.716285845798026`
- midpoint sampled margin: `-0.786988223204341`
- midpoint sampled max violation: `0.786988223204341`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.05524096140672`
- midpoint sampled margin: `-0.11385834521776561`
- midpoint sampled max violation: `0.11385834521776561`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0107430479327844`
- midpoint sampled margin: `-0.13112772002655448`
- midpoint sampled max violation: `0.13112772002655448`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6694327134802023`
- midpoint sampled margin: `-0.7640795178656571`
- midpoint sampled max violation: `0.7640795178656571`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7622701345948131, 0.0] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.7436984260249795`
- midpoint sampled margin: `-0.9135087632269991`
- midpoint sampled max violation: `0.9135087632269991`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7622701345948131, 0.0] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0835531249196877`
- midpoint sampled margin: `-0.25336346212170757`
- midpoint sampled max violation: `0.25336346212170757`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7622701345948131, 0.0] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `0.9109033941093133`
- midpoint sampled margin: `-0.25336346212170835`
- midpoint sampled max violation: `0.25336346212170835`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7622701345948131, 0.0] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5710486952146048`
- midpoint sampled margin: `-0.9135087632269993`
- midpoint sampled max violation: `0.9135087632269993`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.2077390824515875`
- midpoint sampled margin: `-1.2946438305244057`
- midpoint sampled max violation: `1.2946438305244057`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5826497563128905`
- midpoint sampled margin: `-0.7266992344512364`
- midpoint sampled max violation: `0.7266992344512364`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.4743041170314113`
- midpoint sampled margin: `-0.7912730211318457`
- midpoint sampled max violation: `0.7912730211318457`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.035089351641213`
- midpoint sampled margin: `-1.2946438305244063`
- midpoint sampled max violation: `1.2946438305244063`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1544989866858018`
- midpoint sampled margin: `-1.2009177384143037`
- midpoint sampled max violation: `1.2009177384143037`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.663654896238874`
- midpoint sampled margin: `-0.8761284798125787`
- midpoint sampled max violation: `0.8761284798125787`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6538208428488899`
- midpoint sampled margin: `-0.8761284798125787`
- midpoint sampled max violation: `0.8761284798125787`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1794269189386197`
- midpoint sampled margin: `-1.1452145851630635`
- midpoint sampled max violation: `1.1452145851630635`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.669432713480202`
- midpoint sampled margin: `-0.7640795178656571`
- midpoint sampled max violation: `0.7640795178656571`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.010743047932783`
- midpoint sampled margin: `-0.13112772002655415`
- midpoint sampled max violation: `0.13112772002655415`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0552409614067202`
- midpoint sampled margin: `-0.11385834521776572`
- midpoint sampled max violation: `0.11385834521776572`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.7162858457980255`
- midpoint sampled margin: `-0.7869882232043409`
- midpoint sampled max violation: `0.7869882232043409`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7622701345948131, 0.0] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5710486952146048`
- midpoint sampled margin: `-0.9135087632269994`
- midpoint sampled max violation: `0.9135087632269994`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7622701345948131, 0.0] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `0.9109033941093133`
- midpoint sampled margin: `-0.2533634621217078`
- midpoint sampled max violation: `0.2533634621217078`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7622701345948131, 0.0] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0835531249196877`
- midpoint sampled margin: `-0.2533634621217081`
- midpoint sampled max violation: `0.2533634621217081`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7622701345948131, 0.0] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.7436984260249786`
- midpoint sampled margin: `-0.9135087632269993`
- midpoint sampled max violation: `0.9135087632269993`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.035089351641213`
- midpoint sampled margin: `-1.2946438305244057`
- midpoint sampled max violation: `1.2946438305244057`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.474304117031411`
- midpoint sampled margin: `-0.7912730211318458`
- midpoint sampled max violation: `0.7912730211318458`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.582649756312891`
- midpoint sampled margin: `-0.7266992344512364`
- midpoint sampled max violation: `0.7266992344512364`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.2077390824515875`
- midpoint sampled margin: `-1.294643830524406`
- midpoint sampled max violation: `1.294643830524406`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 48
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.035089351641213`
- midpoint sampled margin: `-1.294643830524406`
- midpoint sampled max violation: `1.294643830524406`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 49
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.4743041170314108`
- midpoint sampled margin: `-0.7912730211318459`
- midpoint sampled max violation: `0.7912730211318459`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 50
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.582649756312891`
- midpoint sampled margin: `-0.7266992344512365`
- midpoint sampled max violation: `0.7266992344512365`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 51
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7622701345948131, 1.5245402691896262] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.207739082451588`
- midpoint sampled margin: `-1.2946438305244055`
- midpoint sampled max violation: `1.2946438305244055`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 52
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.5710486952146048`
- midpoint sampled margin: `-0.9135087632269997`
- midpoint sampled max violation: `0.9135087632269997`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 53
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `0.9109033941093134`
- midpoint sampled margin: `-0.25336346212170835`
- midpoint sampled max violation: `0.25336346212170835`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 54
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.083553124919688`
- midpoint sampled margin: `-0.2533634621217077`
- midpoint sampled max violation: `0.2533634621217077`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 55
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.7436984260249797`
- midpoint sampled margin: `-0.9135087632269995`
- midpoint sampled max violation: `0.9135087632269995`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 56
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7622701345948131, 0.0] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.669432713480202`
- midpoint sampled margin: `-0.764079517865657`
- midpoint sampled max violation: `0.764079517865657`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 57
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7622701345948131, 0.0] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.0107430479327837`
- midpoint sampled margin: `-0.13112772002655448`
- midpoint sampled max violation: `0.13112772002655448`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 58
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7622701345948131, 0.0] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.05524096140672`
- midpoint sampled margin: `-0.1138583452177655`
- midpoint sampled max violation: `0.1138583452177655`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 59
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7622701345948131, 0.0] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.716285845798026`
- midpoint sampled margin: `-0.786988223204341`
- midpoint sampled max violation: `0.786988223204341`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 60
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.7622701345948131, 1.5245402691896262]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.154498986685803`
- midpoint sampled margin: `-1.2009177384143035`
- midpoint sampled max violation: `1.2009177384143035`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 61
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [0.0, 0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6636548962388737`
- midpoint sampled margin: `-0.8761284798125786`
- midpoint sampled max violation: `0.8761284798125786`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 62
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-0.7622701345948131, 0.0]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `1.6538208428488894`
- midpoint sampled margin: `-0.8761284798125786`
- midpoint sampled max violation: `0.8761284798125786`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

### Box 63
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5245402691896262, -0.7622701345948131] x [-1.5245402691896262, -0.7622701345948131]`
- l2 translation radius: `0.5390063812679746`
- certified upper violation: `2.1794269189386197`
- midpoint sampled margin: `-1.145214585163064`
- midpoint sampled max violation: `1.145214585163064`
- pose drift bound: `0.9924562223265292`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
