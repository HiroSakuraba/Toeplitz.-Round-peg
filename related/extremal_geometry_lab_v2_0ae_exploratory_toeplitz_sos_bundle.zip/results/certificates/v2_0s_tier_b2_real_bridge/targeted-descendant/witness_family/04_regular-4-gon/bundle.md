# Rigid-motion certificate bundle: regular-4-gon in recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]-cut+arc(0.016)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.34199134476031207`
- sampled max violation: `-0.34199134476031207`
- certified upper violation: `-0.29063283261221184`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.6589600273835363`
- midpoint sampled max violation: `0.6589600273835363`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.306153950005845`
- midpoint sampled margin: `-0.6589600273835362`
- midpoint sampled max violation: `0.6589600273835362`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377206`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058454`
- midpoint sampled margin: `-0.6589600273835359`
- midpoint sampled max violation: `0.6589600273835359`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.658960027383536`
- midpoint sampled max violation: `0.658960027383536`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.6589600273835363`
- midpoint sampled max violation: `0.6589600273835363`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.306153950005845`
- midpoint sampled margin: `-0.6589600273835364`
- midpoint sampled max violation: `0.6589600273835364`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377206`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167894`
- midpoint sampled max violation: `0.7788848833167894`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058454`
- midpoint sampled margin: `-0.6589600273835359`
- midpoint sampled max violation: `0.6589600273835359`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.658960027383536`
- midpoint sampled max violation: `0.658960027383536`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.6589600273835363`
- midpoint sampled max violation: `0.6589600273835363`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.306153950005845`
- midpoint sampled margin: `-0.6589600273835362`
- midpoint sampled max violation: `0.6589600273835362`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377206`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058454`
- midpoint sampled margin: `-0.6589600273835361`
- midpoint sampled max violation: `0.6589600273835361`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.658960027383536`
- midpoint sampled max violation: `0.658960027383536`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.6589600273835363`
- midpoint sampled max violation: `0.6589600273835363`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.306153950005845`
- midpoint sampled margin: `-0.6589600273835362`
- midpoint sampled max violation: `0.6589600273835362`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377206`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4031671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.403167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058454`
- midpoint sampled margin: `-0.6589600273835361`
- midpoint sampled max violation: `0.6589600273835361`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.3061539500058448`
- midpoint sampled margin: `-0.658960027383536`
- midpoint sampled max violation: `0.658960027383536`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.8436639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.06594698826647205`
- midpoint sampled max violation: `0.06594698826647205`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.0659469882664715`
- midpoint sampled max violation: `0.0659469882664715`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496593`
- midpoint sampled margin: `-0.06594698826647183`
- midpoint sampled max violation: `0.06594698826647183`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.776515545662754`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627543`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496595`
- midpoint sampled margin: `-0.06594698826647216`
- midpoint sampled max violation: `0.06594698826647216`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.06594698826647194`
- midpoint sampled max violation: `0.06594698826647194`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.0659469882664715`
- midpoint sampled max violation: `0.0659469882664715`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496593`
- midpoint sampled margin: `-0.06594698826647183`
- midpoint sampled max violation: `0.06594698826647183`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.776515545662754`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627543`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496595`
- midpoint sampled margin: `-0.06594698826647205`
- midpoint sampled max violation: `0.06594698826647205`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.06594698826647194`
- midpoint sampled max violation: `0.06594698826647194`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.0659469882664715`
- midpoint sampled max violation: `0.0659469882664715`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496593`
- midpoint sampled margin: `-0.0659469882664716`
- midpoint sampled max violation: `0.0659469882664716`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.776515545662754`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627543`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496595`
- midpoint sampled margin: `-0.06594698826647205`
- midpoint sampled max violation: `0.06594698826647205`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.06594698826647194`
- midpoint sampled max violation: `0.06594698826647194`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496596`
- midpoint sampled margin: `-0.06594698826647138`
- midpoint sampled max violation: `0.06594698826647138`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627544`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496593`
- midpoint sampled margin: `-0.0659469882664716`
- midpoint sampled max violation: `0.0659469882664716`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.776515545662754`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7765155456627543`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.7722379763496595`
- midpoint sampled margin: `-0.06594698826647205`
- midpoint sampled max violation: `0.06594698826647205`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
