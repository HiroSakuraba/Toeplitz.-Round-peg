# Rigid-motion certificate bundle: pal-seed in recon[recon[pal-seed-cut+arc(0.01)]-cut+arc(0.01)]-cut+arc(0.016)

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `48`
- unresolved boxes: `32`
- explored boxes: `96`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.39194155601262687`
- sampled max violation: `-0.39194155601262687`
- certified upper violation: `-0.2283441138118374`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.9686639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.7434011552396881`
- midpoint sampled max violation: `0.7434011552396881`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4701365350258857`
- midpoint sampled margin: `-0.7434011552396881`
- midpoint sampled max violation: `0.7434011552396881`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760496`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5281671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5526862505524848`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.552686250552484`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.528167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 8
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760494`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 9
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4701365350258861`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9686639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 12
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.9931829767760494`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 13
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.470136535025886`
- midpoint sampled margin: `-0.7434011552396883`
- midpoint sampled max violation: `0.7434011552396883`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 14
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.7434011552396883`
- midpoint sampled max violation: `0.7434011552396883`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 15
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.968663923937721`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 16
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5526862505524845`
- midpoint sampled margin: `-0.7788848833167897`
- midpoint sampled max violation: `0.7788848833167897`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 17
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5281671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 18
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.528167197714155`
- midpoint sampled margin: `-0.7788848833167894`
- midpoint sampled max violation: `0.7788848833167894`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 19
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.552686250552484`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 20
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9686639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 21
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.7434011552396882`
- midpoint sampled max violation: `0.7434011552396882`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 22
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.470136535025886`
- midpoint sampled margin: `-0.7434011552396882`
- midpoint sampled max violation: `0.7434011552396882`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760498`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 24
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.9686639239377204`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 25
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.7434011552396881`
- midpoint sampled max violation: `0.7434011552396881`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 26
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4701365350258857`
- midpoint sampled margin: `-0.7434011552396881`
- midpoint sampled max violation: `0.7434011552396881`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 27
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760496`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 28
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5281671977141555`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 29
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5526862505524848`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 30
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.552686250552484`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 31
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.528167197714155`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 32
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760494`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 33
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4701365350258861`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 34
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 35
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9686639239377208`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 36
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326798`
- certified upper violation: `1.9931829767760494`
- midpoint sampled margin: `-1.1406823833167894`
- midpoint sampled max violation: `1.1406823833167894`
- pose drift bound: `0.904358013031404`
- certification method: `mixed`
- depth: `0`

### Box 37
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.470136535025886`
- midpoint sampled margin: `-0.7434011552396883`
- midpoint sampled max violation: `0.7434011552396883`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 38
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.7434011552396883`
- midpoint sampled max violation: `0.7434011552396883`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 39
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7235950000000002, 1.4471900000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9686639239377206`
- midpoint sampled margin: `-1.140682383316789`
- midpoint sampled max violation: `1.140682383316789`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 40
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5526862505524845`
- midpoint sampled margin: `-0.7788848833167895`
- midpoint sampled max violation: `0.7788848833167895`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 41
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.5281671977141558`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 42
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.528167197714155`
- midpoint sampled margin: `-0.7788848833167892`
- midpoint sampled max violation: `0.7788848833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 43
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.552686250552484`
- midpoint sampled margin: `-0.7788848833167893`
- midpoint sampled max violation: `0.7788848833167893`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 44
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.7235950000000002, 1.4471900000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9686639239377204`
- midpoint sampled margin: `-1.1406823833167892`
- midpoint sampled max violation: `1.1406823833167892`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 45
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.4609259910438501`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 46
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.470136535025886`
- midpoint sampled margin: `-0.743401155239688`
- midpoint sampled max violation: `0.743401155239688`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

### Box 47
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.4471900000000002, -0.7235950000000001] x [-1.4471900000000002, -0.7235950000000001]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `1.9931829767760498`
- midpoint sampled margin: `-1.1406823833167898`
- midpoint sampled max violation: `1.1406823833167898`
- pose drift bound: `0.9043580130314041`
- certification method: `mixed`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8092776298783374`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8993767610062071`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094947`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071537`
- midpoint sampled margin: `-0.13121008437649717`
- midpoint sampled max violation: `0.13121008437649717`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094943`
- midpoint sampled margin: `-0.16499274880775938`
- midpoint sampled max violation: `0.16499274880775938`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071536`
- midpoint sampled margin: `-0.1312100843764974`
- midpoint sampled max violation: `0.1312100843764974`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783368`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.899376761006207`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8617186048071539`
- midpoint sampled margin: `-0.13121008437649762`
- midpoint sampled max violation: `0.13121008437649762`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9223301148094945`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8993767610062071`
- midpoint sampled margin: `-0.13121008437649728`
- midpoint sampled max violation: `0.13121008437649728`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783376`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8993767610062066`
- midpoint sampled margin: `-0.13121008437649728`
- midpoint sampled max violation: `0.13121008437649728`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783372`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071538`
- midpoint sampled margin: `-0.1312100843764975`
- midpoint sampled max violation: `0.1312100843764975`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094943`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8092776298783374`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8993767610062071`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094947`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071537`
- midpoint sampled margin: `-0.13121008437649728`
- midpoint sampled max violation: `0.13121008437649728`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094943`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071533`
- midpoint sampled margin: `-0.1312100843764974`
- midpoint sampled max violation: `0.1312100843764974`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783371`
- midpoint sampled margin: `-0.1649927488077595`
- midpoint sampled max violation: `0.1649927488077595`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.899376761006207`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.8617186048071539`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000000002] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.51165893133268`
- certified upper violation: `0.9223301148094945`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.7080084721820421`
- certification method: `mixed`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8993767610062071`
- midpoint sampled margin: `-0.1312100843764975`
- midpoint sampled max violation: `0.1312100843764975`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7235950000000002] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783376`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8993767610062068`
- midpoint sampled margin: `-0.1312100843764974`
- midpoint sampled max violation: `0.1312100843764974`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000000001, 0.0] x [0.0, 0.7235950000000002]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8092776298783372`
- midpoint sampled margin: `-0.16499274880775927`
- midpoint sampled max violation: `0.16499274880775927`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.8617186048071538`
- midpoint sampled margin: `-0.13121008437649773`
- midpoint sampled max violation: `0.13121008437649773`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7235950000000001, 0.0] x [-0.7235950000000001, 0.0]`
- l2 translation radius: `0.5116589313326799`
- certified upper violation: `0.9223301148094943`
- midpoint sampled margin: `-0.1649927488077596`
- midpoint sampled max violation: `0.1649927488077596`
- pose drift bound: `0.708008472182042`
- certification method: `mixed`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
