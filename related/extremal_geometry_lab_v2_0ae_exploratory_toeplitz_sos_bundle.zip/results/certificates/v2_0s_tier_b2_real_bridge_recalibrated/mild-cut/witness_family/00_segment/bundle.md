# Rigid-motion certificate bundle: segment in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `96`
- unresolved boxes: `64`
- explored boxes: `256`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.41569169381653065`
- sampled max violation: `-0.41569169381653065`
- certified upper violation: `-0.3583067860282875`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.7052026864809997`
- midpoint sampled margin: `-0.7969937909700882`
- midpoint sampled max violation: `0.7969937909700882`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809694`
- midpoint sampled margin: `-0.6148492019920548`
- midpoint sampled max violation: `0.6148492019920548`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2459410943340288`
- midpoint sampled margin: `-0.6574233358561418`
- midpoint sampled max violation: `0.6574233358561418`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.7721898506141844`
- midpoint sampled margin: `-1.15054647445658`
- midpoint sampled max violation: `1.15054647445658`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271198`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.4136725758377405`
- certified upper violation: `0.5359544900555244`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.6532218960305787`
- midpoint sampled margin: `-0.21382071124982605`
- midpoint sampled max violation: `0.21382071124982605`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4173121115431866`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7106017195800985`
- midpoint sampled margin: `-0.21361648229910957`
- midpoint sampled max violation: `0.21361648229910957`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7202087689233126`
- midpoint sampled margin: `-0.3126617646051604`
- midpoint sampled max violation: `0.3126617646051604`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794014`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.3610678781794006`
- midpoint sampled margin: `-0.7805464744563305`
- midpoint sampled max violation: `0.7805464744563305`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.505040733362706`
- midpoint sampled margin: `-0.12111648229904737`
- midpoint sampled max violation: `0.12111648229904737`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7106017195800978`
- midpoint sampled margin: `-0.1827300463729553`
- midpoint sampled max violation: `0.1827300463729553`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5146477827059202`
- midpoint sampled margin: `-0.22016176460509806`
- midpoint sampled max violation: `0.22016176460509806`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.7202087689233116`
- midpoint sampled margin: `-0.4051617646052229`
- midpoint sampled max violation: `0.4051617646052229`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.41367257583774064`
- certified upper violation: `0.5359544900555246`
- midpoint sampled margin: `-0.16823525323070043`
- midpoint sampled max violation: `0.16823525323070043`
- pose drift bound: `0.6100221166874954`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305791`
- midpoint sampled margin: `-0.21382071124982605`
- midpoint sampled max violation: `0.21382071124982605`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271206`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.7721898506141835`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340283`
- midpoint sampled margin: `-0.6574233358561417`
- midpoint sampled max violation: `0.6574233358561417`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809694`
- midpoint sampled margin: `-0.6148492019920547`
- midpoint sampled max violation: `0.6148492019920547`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.7052026864810002`
- midpoint sampled margin: `-0.7969937909700882`
- midpoint sampled max violation: `0.7969937909700882`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.7721898506141842`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340283`
- midpoint sampled margin: `-0.6574233358561417`
- midpoint sampled max violation: `0.6574233358561417`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2199137714809698`
- midpoint sampled margin: `-0.6148492019920551`
- midpoint sampled max violation: `0.6148492019920551`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.705202686481`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794003`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.7202087689233119`
- midpoint sampled margin: `-0.405161764605223`
- midpoint sampled max violation: `0.405161764605223`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.5146477827059202`
- midpoint sampled margin: `-0.22016176460509818`
- midpoint sampled max violation: `0.22016176460509818`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.4136725758377405`
- certified upper violation: `0.710601719580098`
- midpoint sampled margin: `-0.1827300463729551`
- midpoint sampled max violation: `0.1827300463729551`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.505040733362706`
- midpoint sampled margin: `-0.12111648229904715`
- midpoint sampled max violation: `0.12111648229904715`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305795`
- midpoint sampled margin: `-0.21382071124982605`
- midpoint sampled max violation: `0.21382071124982605`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.41731215627621276`
- midpoint sampled margin: `-0.16823525323070077`
- midpoint sampled max violation: `0.16823525323070077`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5359544900555243`
- midpoint sampled margin: `-0.16823525323070077`
- midpoint sampled max violation: `0.16823525323070077`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271193`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.29710413252712`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305785`
- midpoint sampled margin: `-0.21382071124982593`
- midpoint sampled max violation: `0.21382071124982593`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.5359544900555249`
- midpoint sampled margin: `-0.16823525323070065`
- midpoint sampled max violation: `0.16823525323070065`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 39
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5146477827059204`
- midpoint sampled margin: `-0.22016176460509795`
- midpoint sampled max violation: `0.22016176460509795`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.7202087689233123`
- midpoint sampled margin: `-0.40516176460522324`
- midpoint sampled max violation: `0.40516176460522324`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5050407333627065`
- midpoint sampled margin: `-0.12111648229904737`
- midpoint sampled max violation: `0.12111648229904737`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.41367257583774064`
- certified upper violation: `0.7106017195800984`
- midpoint sampled margin: `-0.18273004637295498`
- midpoint sampled max violation: `0.18273004637295498`
- pose drift bound: `0.6100221166874954`
- certification method: `interval`
- depth: `2`

### Box 43
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794008`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.705202686480999`
- midpoint sampled margin: `-0.796993790970088`
- midpoint sampled max violation: `0.796993790970088`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809698`
- midpoint sampled margin: `-0.614849201992055`
- midpoint sampled max violation: `0.614849201992055`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340288`
- midpoint sampled margin: `-0.6574233358561415`
- midpoint sampled max violation: `0.6574233358561415`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.7721898506141847`
- midpoint sampled margin: `-1.150546474456581`
- midpoint sampled max violation: `1.150546474456581`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.7052026864809997`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809694`
- midpoint sampled margin: `-0.6148492019920548`
- midpoint sampled max violation: `0.6148492019920548`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2459410943340288`
- midpoint sampled margin: `-0.6574233358561418`
- midpoint sampled max violation: `0.6574233358561418`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.7721898506141844`
- midpoint sampled margin: `-1.15054647445658`
- midpoint sampled max violation: `1.15054647445658`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271198`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.4136725758377405`
- certified upper violation: `0.5359544900555244`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 54
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.6532218960305787`
- midpoint sampled margin: `-0.21382071124982627`
- midpoint sampled max violation: `0.21382071124982627`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4173121115431866`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7106017195800985`
- midpoint sampled margin: `-0.21361648229910934`
- midpoint sampled max violation: `0.21361648229910934`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 57
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7202087689233126`
- midpoint sampled margin: `-0.3126617646051604`
- midpoint sampled max violation: `0.3126617646051604`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794014`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.3610678781794006`
- midpoint sampled margin: `-0.7805464744563305`
- midpoint sampled max violation: `0.7805464744563305`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.505040733362706`
- midpoint sampled margin: `-0.12111648229904726`
- midpoint sampled max violation: `0.12111648229904726`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.7106017195800978`
- midpoint sampled margin: `-0.1827300463729553`
- midpoint sampled max violation: `0.1827300463729553`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5146477827059202`
- midpoint sampled margin: `-0.22016176460509806`
- midpoint sampled max violation: `0.22016176460509806`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.7202087689233116`
- midpoint sampled margin: `-0.4051617646052229`
- midpoint sampled max violation: `0.4051617646052229`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 64
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.41367257583774064`
- certified upper violation: `0.5359544900555249`
- midpoint sampled margin: `-0.16823525323070065`
- midpoint sampled max violation: `0.16823525323070065`
- pose drift bound: `0.6100221166874954`
- certification method: `interval`
- depth: `2`

### Box 65
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305791`
- midpoint sampled margin: `-0.21382071124982627`
- midpoint sampled max violation: `0.21382071124982627`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 66
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271206`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 67
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.7721898506141835`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 68
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340283`
- midpoint sampled margin: `-0.6574233358561417`
- midpoint sampled max violation: `0.6574233358561417`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809694`
- midpoint sampled margin: `-0.614849201992055`
- midpoint sampled max violation: `0.614849201992055`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.7052026864810002`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783989`
- certified upper violation: `1.7721898506141842`
- midpoint sampled margin: `-1.1505464744565805`
- midpoint sampled max violation: `1.1505464744565805`
- pose drift bound: `0.9159580997779084`
- certification method: `interval`
- depth: `0`

### Box 72
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340283`
- midpoint sampled margin: `-0.6574233358561417`
- midpoint sampled max violation: `0.6574233358561417`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 73
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.2199137714809694`
- midpoint sampled margin: `-0.6148492019920551`
- midpoint sampled max violation: `0.6148492019920551`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 74
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7400000000004998, 1.480000000001] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.705202686481`
- midpoint sampled margin: `-0.7969937909700879`
- midpoint sampled max violation: `0.7969937909700879`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 75
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794003`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 76
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.7202087689233119`
- midpoint sampled margin: `-0.405161764605223`
- midpoint sampled max violation: `0.405161764605223`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 77
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.5146477827059202`
- midpoint sampled margin: `-0.22016176460509818`
- midpoint sampled max violation: `0.22016176460509818`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.4136725758377405`
- certified upper violation: `0.710601719580098`
- midpoint sampled margin: `-0.1827300463729551`
- midpoint sampled max violation: `0.1827300463729551`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 79
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.505040733362706`
- midpoint sampled margin: `-0.12111648229904726`
- midpoint sampled max violation: `0.12111648229904726`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 80
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305795`
- midpoint sampled margin: `-0.21382071124982605`
- midpoint sampled max violation: `0.21382071124982605`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 81
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.41731215627621276`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 82
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5359544900555243`
- midpoint sampled margin: `-0.16823525323070054`
- midpoint sampled max violation: `0.16823525323070054`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 83
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7400000000004998] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2971041325271193`
- midpoint sampled margin: `-0.48355409770080504`
- midpoint sampled max violation: `0.48355409770080504`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.29710413252712`
- midpoint sampled margin: `-0.4835540977008048`
- midpoint sampled max violation: `0.4835540977008048`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.6532218960305785`
- midpoint sampled margin: `-0.21382071124982616`
- midpoint sampled max violation: `0.21382071124982616`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 86
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.41367257583774053`
- certified upper violation: `0.5359544900555249`
- midpoint sampled margin: `-0.16823525323070065`
- midpoint sampled max violation: `0.16823525323070065`
- pose drift bound: `0.6100221166874953`
- certification method: `interval`
- depth: `2`

### Box 87
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5146477827059204`
- midpoint sampled margin: `-0.22016176460509795`
- midpoint sampled max violation: `0.22016176460509795`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 88
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.7202087689233123`
- midpoint sampled margin: `-0.40516176460522324`
- midpoint sampled max violation: `0.40516176460522324`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 89
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.5050407333627065`
- midpoint sampled margin: `-0.12111648229904737`
- midpoint sampled max violation: `0.12111648229904737`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 90
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.41367257583774064`
- certified upper violation: `0.7106017195800984`
- midpoint sampled margin: `-0.18273004637295498`
- midpoint sampled max violation: `0.18273004637295498`
- pose drift bound: `0.6100221166874954`
- certification method: `interval`
- depth: `2`

### Box 91
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7400000000005, 0.0] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.3610678781794008`
- midpoint sampled margin: `-0.7805464744563304`
- midpoint sampled max violation: `0.7805464744563304`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 92
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.7400000000004998, 1.480000000001]`
- l2 translation radius: `0.5232590180783988`
- certified upper violation: `1.705202686480999`
- midpoint sampled margin: `-0.796993790970088`
- midpoint sampled max violation: `0.796993790970088`
- pose drift bound: `0.9159580997779083`
- certification method: `interval`
- depth: `0`

### Box 93
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [0.0, 0.7400000000004998]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2199137714809698`
- midpoint sampled margin: `-0.6148492019920547`
- midpoint sampled max violation: `0.6148492019920547`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 94
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-0.7400000000005, 0.0]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.2459410943340288`
- midpoint sampled margin: `-0.6574233358561415`
- midpoint sampled max violation: `0.6574233358561415`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

### Box 95
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.480000000001, -0.7400000000005] x [-1.480000000001, -0.7400000000005]`
- l2 translation radius: `0.5232590180783987`
- certified upper violation: `1.7721898506141847`
- midpoint sampled margin: `-1.150546474456581`
- midpoint sampled max violation: `1.150546474456581`
- pose drift bound: `0.9159580997779082`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.29947974714531433`
- midpoint sampled margin: `0.06388351770107759`
- midpoint sampled max violation: `-0.06388351770107759`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.04731215627596219`
- midpoint sampled margin: `0.20176474676954936`
- midpoint sampled max violation: `-0.20176474676954936`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.3327924966301199`
- midpoint sampled margin: `0.10236225564629753`
- midpoint sampled max violation: `-0.10236225564629753`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.4484182697181833`
- midpoint sampled margin: `-0.0374517603193556`
- midpoint sampled max violation: `0.0374517603193556`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.12723151041272818`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224783`
- midpoint sampled margin: `0.19931291710141186`
- midpoint sampled max violation: `-0.19931291710141186`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.3997793695228534`
- midpoint sampled margin: `-0.0847323652047638`
- midpoint sampled max violation: `0.0847323652047638`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.19421838330546193`
- midpoint sampled margin: `0.10026763479536083`
- midpoint sampled max violation: `-0.10026763479536083`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224727`
- midpoint sampled margin: `0.19931291710141152`
- midpoint sampled max violation: `-0.19931291710141152`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.19421838330546137`
- midpoint sampled margin: `0.10026763479536072`
- midpoint sampled max violation: `-0.10026763479536072`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.39977936952285287`
- midpoint sampled margin: `-0.08473236520476413`
- midpoint sampled max violation: `0.08473236520476413`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596219`
- midpoint sampled margin: `0.20176474676954947`
- midpoint sampled max violation: `-0.20176474676954947`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531533`
- midpoint sampled margin: `0.06388351770107759`
- midpoint sampled max violation: `-0.06388351770107759`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.1272315104127284`
- midpoint sampled margin: `0.28526763479548556`
- midpoint sampled max violation: `-0.28526763479548556`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.44841826971818377`
- midpoint sampled margin: `-0.0374517603193556`
- midpoint sampled max violation: `0.0374517603193556`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663012034`
- midpoint sampled margin: `0.10236225564629753`
- midpoint sampled max violation: `-0.10236225564629753`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.3997793695228531`
- midpoint sampled margin: `-0.08473236520476435`
- midpoint sampled max violation: `0.08473236520476435`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.1942183833054616`
- midpoint sampled margin: `0.1002676347953606`
- midpoint sampled max violation: `-0.1002676347953606`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.1846113339622475`
- midpoint sampled margin: `0.19931291710141152`
- midpoint sampled max violation: `-0.19931291710141152`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663012045`
- midpoint sampled margin: `0.10236225564629742`
- midpoint sampled max violation: `-0.10236225564629742`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.12723151041272873`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3700000000002499] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4484182697181829`
- midpoint sampled margin: `-0.0374517603193556`
- midpoint sampled max violation: `0.0374517603193556`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596286`
- midpoint sampled margin: `0.20176474676954914`
- midpoint sampled max violation: `-0.20176474676954914`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3700000000002499] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531456`
- midpoint sampled margin: `0.06388351770107781`
- midpoint sampled max violation: `-0.06388351770107781`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4484182697181831`
- midpoint sampled margin: `-0.03745176031935549`
- midpoint sampled max violation: `0.03745176031935549`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.12723151041272796`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663011967`
- midpoint sampled margin: `0.10236225564629742`
- midpoint sampled max violation: `-0.10236225564629742`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531456`
- midpoint sampled margin: `0.06388351770107792`
- midpoint sampled max violation: `-0.06388351770107792`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596275`
- midpoint sampled margin: `0.20176474676954925`
- midpoint sampled max violation: `-0.20176474676954925`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.1942183833054616`
- midpoint sampled margin: `0.1002676347953606`
- midpoint sampled max violation: `-0.1002676347953606`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.39977936952285376`
- midpoint sampled margin: `-0.08473236520476446`
- midpoint sampled max violation: `0.08473236520476446`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224771`
- midpoint sampled margin: `0.1993129171014114`
- midpoint sampled max violation: `-0.1993129171014114`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.29947974714531433`
- midpoint sampled margin: `0.06388351770107781`
- midpoint sampled max violation: `-0.06388351770107781`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.04731215627596219`
- midpoint sampled margin: `0.20176474676954925`
- midpoint sampled max violation: `-0.20176474676954925`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.3327924966301199`
- midpoint sampled margin: `0.10236225564629775`
- midpoint sampled max violation: `-0.10236225564629775`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3700000000002499] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.4484182697181831`
- midpoint sampled margin: `-0.0374517603193556`
- midpoint sampled max violation: `0.0374517603193556`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.12723151041272818`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224783`
- midpoint sampled margin: `0.19931291710141197`
- midpoint sampled max violation: `-0.19931291710141197`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.3997793695228534`
- midpoint sampled margin: `-0.0847323652047638`
- midpoint sampled max violation: `0.0847323652047638`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.19421838330546193`
- midpoint sampled margin: `0.10026763479536083`
- midpoint sampled max violation: `-0.10026763479536083`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224727`
- midpoint sampled margin: `0.19931291710141164`
- midpoint sampled max violation: `-0.19931291710141164`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.19421838330546137`
- midpoint sampled margin: `0.10026763479536072`
- midpoint sampled max violation: `-0.10026763479536072`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.39977936952285287`
- midpoint sampled margin: `-0.08473236520476413`
- midpoint sampled max violation: `0.08473236520476413`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596219`
- midpoint sampled margin: `0.20176474676954936`
- midpoint sampled max violation: `-0.20176474676954936`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531533`
- midpoint sampled margin: `0.0638835177010777`
- midpoint sampled max violation: `-0.0638835177010777`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.1272315104127283`
- midpoint sampled margin: `0.28526763479548556`
- midpoint sampled max violation: `-0.28526763479548556`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37000000000025, 0.0] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.44841826971818377`
- midpoint sampled margin: `-0.03745176031935582`
- midpoint sampled max violation: `0.03745176031935582`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 47
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663012034`
- midpoint sampled margin: `0.10236225564629764`
- midpoint sampled max violation: `-0.10236225564629764`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.3997793695228531`
- midpoint sampled margin: `-0.08473236520476435`
- midpoint sampled max violation: `0.08473236520476435`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.1942183833054616`
- midpoint sampled margin: `0.1002676347953606`
- midpoint sampled max violation: `-0.1002676347953606`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3700000000002499] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.2616295090391993`
- certified upper violation: `0.1846113339622475`
- midpoint sampled margin: `0.1993129171014114`
- midpoint sampled max violation: `-0.1993129171014114`
- pose drift bound: `0.45797904988895405`
- certification method: `interval`
- depth: `3`

### Box 51
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3700000000002499, 0.7400000000004998] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663012045`
- midpoint sampled margin: `0.10236225564629764`
- midpoint sampled max violation: `-0.10236225564629764`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 52
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.12723151041272873`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 53
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3700000000002499] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4484182697181831`
- midpoint sampled margin: `-0.03745176031935582`
- midpoint sampled max violation: `0.03745176031935582`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 54
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3700000000002499] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596286`
- midpoint sampled margin: `0.20176474676954925`
- midpoint sampled max violation: `-0.20176474676954925`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3700000000002499] x [-0.7400000000005, -0.37000000000025]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531456`
- midpoint sampled margin: `0.0638835177010777`
- midpoint sampled max violation: `-0.0638835177010777`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.4484182697181831`
- midpoint sampled margin: `-0.03745176031935571`
- midpoint sampled max violation: `0.03745176031935571`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.12723151041272796`
- midpoint sampled margin: `0.28526763479548567`
- midpoint sampled max violation: `-0.28526763479548567`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.33279249663011967`
- midpoint sampled margin: `0.10236225564629775`
- midpoint sampled max violation: `-0.10236225564629775`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37000000000025, 0.0] x [0.3700000000002499, 0.7400000000004998]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.29947974714531456`
- midpoint sampled margin: `0.06388351770107781`
- midpoint sampled max violation: `-0.06388351770107781`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37000000000025, 0.0] x [0.0, 0.3700000000002499]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.04731215627596275`
- midpoint sampled margin: `0.20176474676954925`
- midpoint sampled max violation: `-0.20176474676954925`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 61
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.1942183833054616`
- midpoint sampled margin: `0.1002676347953606`
- midpoint sampled max violation: `-0.1002676347953606`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7400000000005, -0.37000000000025] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.39977936952285376`
- midpoint sampled margin: `-0.08473236520476446`
- midpoint sampled max violation: `0.08473236520476446`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37000000000025, 0.0] x [-0.37000000000025, 0.0]`
- l2 translation radius: `0.26162950903919935`
- certified upper violation: `0.18461133396224771`
- midpoint sampled margin: `0.1993129171014113`
- midpoint sampled max violation: `-0.1993129171014113`
- pose drift bound: `0.4579790498889541`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[16, 32, 40]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
