# Rigid-motion certificate bundle: orbiform-stub in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `112`
- unresolved boxes: `32`
- explored boxes: `224`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.004939311588785271)`
- sampled margin: `0.34870489570874996`
- sampled max violation: `-0.34870489570874996`
- certified upper violation: `-0.2464095884923776`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285304`
- midpoint sampled margin: `-1.1633057331788816`
- midpoint sampled max violation: `1.1633057331788816`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.7884517414539183`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.5828907552366656`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308021`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.6675934063135494`
- midpoint sampled margin: `-0.2201616340785184`
- midpoint sampled max violation: `0.2201616340785184`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5527249931305603`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308031`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5621458446724887`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453919`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.5208066205940245`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.520806620594024`
- midpoint sampled margin: `-0.7933057331788821`
- midpoint sampled max violation: `0.7933057331788821`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.6675934063135494`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308021`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5828907552366656`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453918`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.582890755236666`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.7884517414539192`
- midpoint sampled margin: `-0.24494693437839765`
- midpoint sampled max violation: `0.24494693437839765`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.6675934063135496`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.8731543925308027`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940243`
- midpoint sampled margin: `-0.7933057331788818`
- midpoint sampled max violation: `0.7933057331788818`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.931928593028529`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285304`
- midpoint sampled margin: `-1.1633057331788816`
- midpoint sampled max violation: `1.1633057331788816`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.7884517414539183`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.5828907552366656`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308023`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 36
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.6675934063135494`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5527249931305603`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308031`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 39
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5621458446724887`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453919`
- midpoint sampled margin: `-0.31266163407851844`
- midpoint sampled max violation: `0.31266163407851844`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 41
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.5208066205940245`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.520806620594024`
- midpoint sampled margin: `-0.7933057331788821`
- midpoint sampled max violation: `0.7933057331788821`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.6675934063135491`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308018`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 45
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5828907552366656`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453918`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 47
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.582890755236666`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.7884517414539192`
- midpoint sampled margin: `-0.24494693437839765`
- midpoint sampled max violation: `0.24494693437839765`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 49
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.6675934063135496`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.8731543925308027`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.931928593028529`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285304`
- midpoint sampled margin: `-1.1633057331788816`
- midpoint sampled max violation: `1.1633057331788816`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.7884517414539185`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.5828907552366658`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308023`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.6675934063135494`
- midpoint sampled margin: `-0.2201616340785184`
- midpoint sampled max violation: `0.2201616340785184`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5527249931305603`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 66
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308031`
- midpoint sampled margin: `-0.31266163407851844`
- midpoint sampled max violation: `0.31266163407851844`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 67
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.562145844672489`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 68
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453919`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.5208066205940245`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.520806620594024`
- midpoint sampled margin: `-0.7933057331788821`
- midpoint sampled max violation: `0.7933057331788821`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.6675934063135491`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 72
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308018`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 73
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5828907552366656`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 74
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453918`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 75
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.582890755236666`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 76
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.7884517414539192`
- midpoint sampled margin: `-0.24494693437839765`
- midpoint sampled max violation: `0.24494693437839765`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.6675934063135496`
- midpoint sampled margin: `-0.2201616340785184`
- midpoint sampled max violation: `0.2201616340785184`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.8731543925308027`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 79
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.931928593028529`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 81
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 82
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 83
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780453`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767695`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.432009599874692`
- midpoint sampled margin: `-0.7612951042912499`
- midpoint sampled max violation: `0.7612951042912499`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 87
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7399999999999998, 1.48] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285304`
- midpoint sampled margin: `-1.1633057331788812`
- midpoint sampled max violation: `1.1633057331788812`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 88
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940238`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.7884517414539185`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 90
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.5828907552366658`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308021`
- midpoint sampled margin: `-0.24494693437839743`
- midpoint sampled max violation: `0.24494693437839743`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 92
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3699999999999999] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.6675934063135494`
- midpoint sampled margin: `-0.2201616340785184`
- midpoint sampled max violation: `0.2201616340785184`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5527249931305606`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 94
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308031`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3699999999999999, 0.7399999999999998] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5621458446724887`
- midpoint sampled margin: `-0.20629510429124975`
- midpoint sampled max violation: `0.20629510429124975`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 96
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.7399999999999998] x [-0.74, -0.37]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453919`
- midpoint sampled margin: `-0.3126616340785182`
- midpoint sampled max violation: `0.3126616340785182`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 97
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7399999999999998] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.520806620594025`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 98
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.520806620594024`
- midpoint sampled margin: `-0.7933057331788821`
- midpoint sampled max violation: `0.7933057331788821`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 99
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.6675934063135491`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 100
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.8731543925308018`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 101
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37, 0.0] x [0.3699999999999999, 0.7399999999999998]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.5828907552366653`
- midpoint sampled margin: `-0.22016163407851852`
- midpoint sampled max violation: `0.22016163407851852`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 102
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, -0.37] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.413672575837461`
- certified upper violation: `0.788451741453918`
- midpoint sampled margin: `-0.24494693437839732`
- midpoint sampled max violation: `0.24494693437839732`
- pose drift bound: `0.610022116686823`
- certification method: `interval`
- depth: `2`

### Box 103
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.582890755236666`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 104
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.7884517414539192`
- midpoint sampled margin: `-0.24494693437839765`
- midpoint sampled max violation: `0.24494693437839765`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 105
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37, 0.0] x [-0.74, -0.37]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.6675934063135496`
- midpoint sampled margin: `-0.22016163407851863`
- midpoint sampled max violation: `0.22016163407851863`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 106
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.74, -0.37] x [-0.74, 0.0]`
- l2 translation radius: `0.4136725758374611`
- certified upper violation: `0.8731543925308027`
- midpoint sampled margin: `-0.24494693437839765`
- midpoint sampled max violation: `0.24494693437839765`
- pose drift bound: `0.6100221166868232`
- certification method: `interval`
- depth: `2`

### Box 107
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.74, 0.0] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.5208066205940243`
- midpoint sampled margin: `-0.793305733178882`
- midpoint sampled max violation: `0.793305733178882`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 108
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.7399999999999998, 1.48]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.931928593028529`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 109
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [0.0, 0.7399999999999998]`
- l2 translation radius: `0.5232590180780451`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767692`
- certification method: `interval`
- depth: `0`

### Box 110
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-0.74, 0.0]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.4320095998746925`
- midpoint sampled margin: `-0.7612951042912498`
- midpoint sampled max violation: `0.7612951042912498`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

### Box 111
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.48, -0.74] x [-1.48, -0.74]`
- l2 translation radius: `0.5232590180780452`
- certified upper violation: `1.9319285930285302`
- midpoint sampled margin: `-1.1633057331788819`
- midpoint sampled max violation: `1.1633057331788819`
- pose drift bound: `0.9159580997767693`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.26246135583642327`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.34716400691330707`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.3471640069133076`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642405`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.34716400691330707`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642305`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.2624613558364237`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.26246135583642327`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.3471640069133076`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.2624613558364238`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.34716400691330684`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642305`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.2624613558364237`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.2624613558364235`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.3471640069133076`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642405`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.34716400691330684`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642305`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.2624613558364237`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.2624613558364235`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3699999999999999] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.2616295090390225`
- certified upper violation: `0.34716400691330707`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838456`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.34716400691330784`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3699999999999999] x [-0.37, 0.0]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.2624613558364238`
- midpoint sampled margin: `0.10026776532172388`
- midpoint sampled max violation: `-0.10026776532172388`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.34716400691330684`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37, 0.0] x [0.0, 0.3699999999999999]`
- l2 translation radius: `0.26162950903902255`
- certified upper violation: `0.26246135583642305`
- midpoint sampled margin: `0.10026776532172377`
- midpoint sampled max violation: `-0.10026776532172377`
- pose drift bound: `0.4579790498883846`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.2624613558364237`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37, 0.0] x [-0.37, 0.0]`
- l2 translation radius: `0.2616295090390226`
- certified upper violation: `0.3471640069133073`
- midpoint sampled margin: `0.10026776532172366`
- midpoint sampled max violation: `-0.10026776532172366`
- pose drift bound: `0.45797904988838467`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 32, 40]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
