# Rigid-motion certificate bundle: regular-3-gon in pal-seed-cut

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `106`
- unresolved boxes: `60`
- explored boxes: `268`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.34870489570874985`
- sampled max violation: `-0.34870489570874985`
- certified upper violation: `-0.20486398470546485`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.1321497897729493`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.502898745690751`
- midpoint sampled margin: `-0.7275560966473325`
- midpoint sampled max violation: `0.7275560966473325`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.4118583448054944`
- midpoint sampled margin: `-0.8611145354220744`
- midpoint sampled max violation: `0.8611145354220744`
- pose drift bound: `0.7773313885426171`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.43529263333569995`
- certified upper violation: `1.2359264110384642`
- midpoint sampled margin: `-0.6707763810939156`
- midpoint sampled max violation: `0.6707763810939156`
- pose drift bound: `0.6620175538649772`
- certification method: `interval`
- depth: `2`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.43529263333569995`
- certified upper violation: `1.3968979367459626`
- midpoint sampled margin: `-0.8266400647427802`
- midpoint sampled max violation: `0.8266400647427802`
- pose drift bound: `0.6620175538649772`
- certification method: `interval`
- depth: `2`

### Box 5
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.9600361556544876`
- midpoint sampled margin: `-1.304696875792807`
- midpoint sampled max violation: `1.304696875792807`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6995410637995387`
- midpoint sampled margin: `-0.9151700955467215`
- midpoint sampled max violation: `0.9151700955467215`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6371279715778135`
- midpoint sampled margin: `-0.21243659658601666`
- midpoint sampled max violation: `0.21243659658601666`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.43529263333570006`
- certified upper violation: `1.0155812561467787`
- midpoint sampled margin: `-0.35288546129233334`
- midpoint sampled max violation: `0.35288546129233334`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7992768931600736`
- midpoint sampled margin: `-0.3268047896072237`
- midpoint sampled max violation: `0.3268047896072237`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6251408986164867`
- midpoint sampled margin: `-0.2124365965860162`
- midpoint sampled max violation: `0.2124365965860162`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8525388851347896`
- midpoint sampled margin: `-0.5214735732559266`
- midpoint sampled max violation: `0.5214735732559266`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5268913329891651`
- midpoint sampled margin: `-0.9151700955467212`
- midpoint sampled max violation: `0.9151700955467212`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6744891824045838`
- midpoint sampled margin: `-0.7823743018185355`
- midpoint sampled max violation: `0.7823743018185355`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.9913296406663967`
- midpoint sampled margin: `-0.3851303206249116`
- midpoint sampled max violation: `0.3851303206249116`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6541534167392089`
- midpoint sampled margin: `-0.19334421981699357`
- midpoint sampled max violation: `0.19334421981699357`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.778675134594813, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.8795312138578464`
- midpoint sampled margin: `-0.2031967987411808`
- midpoint sampled max violation: `0.2031967987411808`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.689493492367711`
- midpoint sampled margin: `-0.3077124128382004`
- midpoint sampled max violation: `0.3077124128382004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7192635647522638`
- midpoint sampled margin: `-0.2877959288005598`
- midpoint sampled max violation: `0.2877959288005598`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.9369480739794078`
- midpoint sampled margin: `-0.3166783942325273`
- midpoint sampled max violation: `0.3166783942325273`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 20
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.7751886159451638`
- midpoint sampled margin: `-0.3077124128382004`
- midpoint sampled max violation: `0.3077124128382004`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6099203755933444`
- midpoint sampled margin: `-0.7657408501853786`
- midpoint sampled max violation: `0.7657408501853786`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.1038376262599807`
- midpoint sampled margin: `-1.1550784174827853`
- midpoint sampled max violation: `1.1550784174827853`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.595734243340012`
- midpoint sampled margin: `-0.876985342008675`
- midpoint sampled max violation: `0.876985342008675`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6044367275749554`
- midpoint sampled margin: `-0.876985342008675`
- midpoint sampled max violation: `0.876985342008675`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.0701426638015614`
- midpoint sampled margin: `-1.2052120942767321`
- midpoint sampled max violation: `1.2052120942767321`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.103837626259981`
- midpoint sampled margin: `-1.1550784174827857`
- midpoint sampled max violation: `1.1550784174827857`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.595734243340012`
- midpoint sampled margin: `-0.8769853420086748`
- midpoint sampled max violation: `0.8769853420086748`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6044367275749558`
- midpoint sampled margin: `-0.8769853420086748`
- midpoint sampled max violation: `0.8769853420086748`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.070142663801561`
- midpoint sampled margin: `-1.205212094276733`
- midpoint sampled max violation: `1.205212094276733`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.674489182404584`
- midpoint sampled margin: `-0.782374301818536`
- midpoint sampled max violation: `0.782374301818536`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.43529263333570006`
- certified upper violation: `0.8795312138578464`
- midpoint sampled margin: `-0.3077124128382005`
- midpoint sampled max violation: `0.3077124128382005`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 32
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6253445040630723`
- midpoint sampled margin: `-0.13213600595852049`
- midpoint sampled max violation: `0.13213600595852049`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.43529263333570006`
- certified upper violation: `0.991329640666397`
- midpoint sampled margin: `-0.3138766004856697`
- midpoint sampled max violation: `0.3138766004856697`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7750252776796918`
- midpoint sampled margin: `-0.28779592880056026`
- midpoint sampled max violation: `0.28779592880056026`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.7751886159451643`
- midpoint sampled margin: `-0.3077124128382005`
- midpoint sampled max violation: `0.3077124128382005`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 36
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.9369480739794076`
- midpoint sampled margin: `-0.3166783942325274`
- midpoint sampled max violation: `0.3166783942325274`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 37
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7192635647522639`
- midpoint sampled margin: `-0.2877959288005598`
- midpoint sampled max violation: `0.2877959288005598`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6099203755933447`
- midpoint sampled margin: `-0.7657408501853789`
- midpoint sampled max violation: `0.7657408501853789`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6995410637995385`
- midpoint sampled margin: `-0.9151700955467211`
- midpoint sampled max violation: `0.9151700955467211`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `1.0155812561467787`
- midpoint sampled margin: `-0.42413918143157525`
- midpoint sampled max violation: `0.42413918143157525`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 41
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6784050322195911`
- midpoint sampled margin: `-0.1842973493287391`
- midpoint sampled max violation: `0.1842973493287391`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3893375672974065, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6371279715778133`
- midpoint sampled margin: `-0.21243659658601632`
- midpoint sampled max violation: `0.21243659658601632`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8525388851347897`
- midpoint sampled margin: `-0.521473573255927`
- midpoint sampled max violation: `0.521473573255927`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6251408986164864`
- midpoint sampled margin: `-0.21243659658601644`
- midpoint sampled max violation: `0.21243659658601644`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5268913329891645`
- midpoint sampled margin: `-0.915170095546721`
- midpoint sampled max violation: `0.915170095546721`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.132149789772949`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.502898745690751`
- midpoint sampled margin: `-0.7275560966473326`
- midpoint sampled max violation: `0.7275560966473326`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.1680127018922195, -0.778675134594813] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8493178284268028`
- midpoint sampled margin: `-0.4761075974452117`
- midpoint sampled max violation: `0.4761075974452117`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.1680127018922195, -0.778675134594813] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `1.0829107457457`
- midpoint sampled margin: `-0.7161423569046304`
- midpoint sampled max violation: `0.7161423569046304`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.557350269189626, -1.1680127018922195] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.43529263333569995`
- certified upper violation: `1.396897936745962`
- midpoint sampled margin: `-0.8654451647426183`
- midpoint sampled max violation: `0.8654451647426183`
- pose drift bound: `0.6620175538649772`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.411858344805494`
- midpoint sampled margin: `-0.8611145354220742`
- midpoint sampled max violation: `0.8611145354220742`
- pose drift bound: `0.7773313885426172`
- certification method: `interval`
- depth: `1`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.9600361556544879`
- midpoint sampled margin: `-1.3046968757928072`
- midpoint sampled max violation: `1.3046968757928072`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.0701426638015605`
- midpoint sampled margin: `-1.2052120942767324`
- midpoint sampled max violation: `1.2052120942767324`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6044367275749556`
- midpoint sampled margin: `-0.8769853420086751`
- midpoint sampled max violation: `0.8769853420086751`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.595734243340012`
- midpoint sampled margin: `-0.8769853420086751`
- midpoint sampled max violation: `0.8769853420086751`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.103837626259982`
- midpoint sampled margin: `-1.155078417482785`
- midpoint sampled max violation: `1.155078417482785`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.609920375593344`
- midpoint sampled margin: `-0.7657408501853789`
- midpoint sampled max violation: `0.7657408501853789`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.43529263333570006`
- certified upper violation: `0.9369480739794085`
- midpoint sampled margin: `-0.3166783942325275`
- midpoint sampled max violation: `0.3166783942325275`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 59
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7192635647522636`
- midpoint sampled margin: `-0.28779592880056004`
- midpoint sampled max violation: `0.28779592880056004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.43529263333570006`
- certified upper violation: `0.7751886159451635`
- midpoint sampled margin: `-0.3077124128382005`
- midpoint sampled max violation: `0.3077124128382005`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.9913296406663973`
- midpoint sampled margin: `-0.313876600485669`
- midpoint sampled max violation: `0.313876600485669`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7750252776796921`
- midpoint sampled margin: `-0.28779592880056004`
- midpoint sampled max violation: `0.28779592880056004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.879531213857847`
- midpoint sampled margin: `-0.3077124128382005`
- midpoint sampled max violation: `0.3077124128382005`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6253445040630728`
- midpoint sampled margin: `-0.13213600595852015`
- midpoint sampled max violation: `0.13213600595852015`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6744891824045836`
- midpoint sampled margin: `-0.7823743018185356`
- midpoint sampled max violation: `0.7823743018185356`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 66
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.5268913329891638`
- midpoint sampled margin: `-0.9151700955467214`
- midpoint sampled max violation: `0.9151700955467214`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 67
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3893375672974065, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6251408986164859`
- midpoint sampled margin: `-0.21243659658601632`
- midpoint sampled max violation: `0.21243659658601632`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 68
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.852538885134789`
- midpoint sampled margin: `-0.5214735732559269`
- midpoint sampled max violation: `0.5214735732559269`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 69
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6371279715778135`
- midpoint sampled margin: `-0.2124365965860162`
- midpoint sampled max violation: `0.2124365965860162`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 70
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7992768931600736`
- midpoint sampled margin: `-0.3268047896072237`
- midpoint sampled max violation: `0.3268047896072237`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 71
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `1.0155812561467792`
- midpoint sampled margin: `-0.35288546129233334`
- midpoint sampled max violation: `0.35288546129233334`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 72
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6995410637995387`
- midpoint sampled margin: `-0.915170095546721`
- midpoint sampled max violation: `0.915170095546721`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 73
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.960036155654488`
- midpoint sampled margin: `-1.3046968757928066`
- midpoint sampled max violation: `1.3046968757928066`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 74
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.411858344805494`
- midpoint sampled margin: `-0.8611145354220743`
- midpoint sampled max violation: `0.8611145354220743`
- pose drift bound: `0.7773313885426172`
- certification method: `interval`
- depth: `1`

### Box 75
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `1.396897936745962`
- midpoint sampled margin: `-0.8266400647427797`
- midpoint sampled max violation: `0.8266400647427797`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 76
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `1.2359264110384636`
- midpoint sampled margin: `-0.6707763810939157`
- midpoint sampled max violation: `0.6707763810939157`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5028987456907508`
- midpoint sampled margin: `-0.7275560966473326`
- midpoint sampled max violation: `0.7275560966473326`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 78
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.1321497897729493`
- midpoint sampled margin: `-1.3045076628441277`
- midpoint sampled max violation: `1.3045076628441277`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 79
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.9600361556544887`
- midpoint sampled margin: `-1.304696875792807`
- midpoint sampled max violation: `1.304696875792807`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.43529263333569995`
- certified upper violation: `1.396897936745962`
- midpoint sampled margin: `-0.8266400647427803`
- midpoint sampled max violation: `0.8266400647427803`
- pose drift bound: `0.6620175538649772`
- certification method: `interval`
- depth: `2`

### Box 81
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.43529263333569995`
- certified upper violation: `1.2359264110384633`
- midpoint sampled margin: `-0.6707763810939154`
- midpoint sampled max violation: `0.6707763810939154`
- pose drift bound: `0.6620175538649772`
- certification method: `interval`
- depth: `2`

### Box 82
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.4118583448054935`
- midpoint sampled margin: `-0.8611145354220742`
- midpoint sampled max violation: `0.8611145354220742`
- pose drift bound: `0.7773313885426172`
- certification method: `interval`
- depth: `1`

### Box 83
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.5028987456907514`
- midpoint sampled margin: `-0.7275560966473327`
- midpoint sampled max violation: `0.7275560966473327`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7786751345948131, 1.557350269189626] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.1321497897729493`
- midpoint sampled margin: `-1.304507662844127`
- midpoint sampled max violation: `1.304507662844127`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.5268913329891645`
- midpoint sampled margin: `-0.9151700955467215`
- midpoint sampled max violation: `0.9151700955467215`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8525388851347893`
- midpoint sampled margin: `-0.521473573255927`
- midpoint sampled max violation: `0.521473573255927`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 87
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6251408986164861`
- midpoint sampled margin: `-0.21243659658601644`
- midpoint sampled max violation: `0.21243659658601644`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 88
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `1.0155812561467794`
- midpoint sampled margin: `-0.35288546129233267`
- midpoint sampled max violation: `0.35288546129233267`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7992768931600743`
- midpoint sampled margin: `-0.3268047896072235`
- midpoint sampled max violation: `0.3268047896072235`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 90
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6371279715778129`
- midpoint sampled margin: `-0.21243659658601644`
- midpoint sampled max violation: `0.21243659658601644`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7786751345948131] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6995410637995394`
- midpoint sampled margin: `-0.9151700955467212`
- midpoint sampled max violation: `0.9151700955467212`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 92
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `1.6099203755933433`
- midpoint sampled margin: `-0.765740850185379`
- midpoint sampled max violation: `0.765740850185379`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7751886159451633`
- midpoint sampled margin: `-0.3077124128382004`
- midpoint sampled max violation: `0.3077124128382004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 94
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6613754216755823`
- midpoint sampled margin: `-0.3077124128382004`
- midpoint sampled max violation: `0.3077124128382004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.778675134594813, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.936948073979408`
- midpoint sampled margin: `-0.3851303206249116`
- midpoint sampled max violation: `0.3851303206249116`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 96
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6831876006896794`
- midpoint sampled margin: `-0.20128559282180147`
- midpoint sampled max violation: `0.20128559282180147`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 97
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6253445040630727`
- midpoint sampled margin: `-0.1321360059585206`
- midpoint sampled max violation: `0.1321360059585206`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 98
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.8795312138578462`
- midpoint sampled margin: `-0.3077124128382004`
- midpoint sampled max violation: `0.3077124128382004`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 99
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.7750252776796918`
- midpoint sampled margin: `-0.28779592880056004`
- midpoint sampled max violation: `0.28779592880056004`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 100
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.4352926333357`
- certified upper violation: `0.9913296406663972`
- midpoint sampled margin: `-0.3138766004856697`
- midpoint sampled max violation: `0.3138766004856697`
- pose drift bound: `0.6620175538649773`
- certification method: `interval`
- depth: `2`

### Box 101
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.778675134594813, 0.0] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6744891824045844`
- midpoint sampled margin: `-0.782374301818536`
- midpoint sampled max violation: `0.782374301818536`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 102
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.7786751345948131, 1.557350269189626]`
- l2 translation radius: `0.5506064680133398`
- certified upper violation: `2.070142663801561`
- midpoint sampled margin: `-1.2052120942767328`
- midpoint sampled max violation: `1.2052120942767328`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 103
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [0.0, 0.7786751345948131]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.6044367275749556`
- midpoint sampled margin: `-0.8769853420086747`
- midpoint sampled max violation: `0.8769853420086747`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 104
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-0.778675134594813, 0.0]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `1.595734243340012`
- midpoint sampled margin: `-0.8769853420086747`
- midpoint sampled max violation: `0.8769853420086747`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

### Box 105
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.557350269189626, -0.778675134594813] x [-1.557350269189626, -0.778675134594813]`
- l2 translation radius: `0.5506064680133399`
- certified upper violation: `2.103837626259982`
- midpoint sampled margin: `-1.1550784174827857`
- midpoint sampled max violation: `1.1550784174827857`
- pose drift bound: `1.0040563090718944`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8499032386258347`
- midpoint sampled margin: `-0.40710538023472`
- midpoint sampled max violation: `0.40710538023472`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332762`
- midpoint sampled margin: `-0.26870355203153684`
- midpoint sampled max violation: `0.26870355203153684`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.29642265171194193`
- midpoint sampled margin: `0.12063401526586981`
- midpoint sampled max violation: `-0.12063401526586981`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.46210066923288595`
- midpoint sampled margin: `0.010371434319963901`
- midpoint sampled max violation: `-0.010371434319963901`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332769`
- midpoint sampled margin: `-0.26870355203153684`
- midpoint sampled max violation: `0.26870355203153684`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8414452616031917`
- midpoint sampled margin: `-0.41344198816545286`
- midpoint sampled max violation: `0.41344198816545286`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.28796467468929887`
- midpoint sampled margin: `0.12063401526586981`
- midpoint sampled max violation: `-0.12063401526586981`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5153626612076022`
- midpoint sampled margin: `-0.18429734932873898`
- midpoint sampled max violation: `0.18429734932873898`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.299058298220897`
- midpoint sampled margin: `0.010371434319964012`
- midpoint sampled max violation: `-0.010371434319964012`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6362345221480846`
- midpoint sampled margin: `-0.3268047896072237`
- midpoint sampled max violation: `0.3268047896072237`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.43784905375250394`
- midpoint sampled margin: `0.04938029512662767`
- midpoint sampled max violation: `-0.04938029512662767`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.31940871548403227`
- midpoint sampled margin: `0.08162515445920604`
- midpoint sampled max violation: `-0.08162515445920604`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.3820873408250762`
- midpoint sampled margin: `0.04938029512662756`
- midpoint sampled max violation: `-0.04938029512662756`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2720378543781753`
- midpoint sampled margin: `0.08162515445920615`
- midpoint sampled max violation: `-0.08162515445920615`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5621461094200741`
- midpoint sampled margin: `-0.13966229226028748`
- midpoint sampled max violation: `0.13966229226028748`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.31940871548403216`
- midpoint sampled margin: `0.08162515445920593`
- midpoint sampled max violation: `-0.08162515445920593`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.43784905375250416`
- midpoint sampled margin: `0.04938029512662734`
- midpoint sampled max violation: `-0.04938029512662734`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.27203785437817607`
- midpoint sampled margin: `0.08162515445920593`
- midpoint sampled max violation: `-0.08162515445920593`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.38933756729740654] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5621461094200735`
- midpoint sampled margin: `-0.13966229226028748`
- midpoint sampled max violation: `0.13966229226028748`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.38208734082507634`
- midpoint sampled margin: `0.04938029512662778`
- midpoint sampled max violation: `-0.04938029512662778`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.46210066923288595`
- midpoint sampled margin: `0.010371434319964012`
- midpoint sampled max violation: `-0.010371434319964012`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8499032386258345`
- midpoint sampled margin: `-0.4071053802347194`
- midpoint sampled max violation: `0.4071053802347194`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2964226517119415`
- midpoint sampled margin: `0.1206340152658697`
- midpoint sampled max violation: `-0.1206340152658697`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332764`
- midpoint sampled margin: `-0.26870355203153673`
- midpoint sampled max violation: `0.26870355203153673`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2990582982208967`
- midpoint sampled margin: `0.010371434319963901`
- midpoint sampled max violation: `-0.010371434319963901`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6362345221480841`
- midpoint sampled margin: `-0.3268047896072237`
- midpoint sampled max violation: `0.3268047896072237`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5153626612076023`
- midpoint sampled margin: `-0.18429734932873965`
- midpoint sampled max violation: `0.18429734932873965`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.28796467468929876`
- midpoint sampled margin: `0.1206340152658697`
- midpoint sampled max violation: `-0.1206340152658697`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332761`
- midpoint sampled margin: `-0.26870355203153673`
- midpoint sampled max violation: `0.26870355203153673`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8414452616031916`
- midpoint sampled margin: `-0.41344198816545297`
- midpoint sampled max violation: `0.41344198816545297`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.3820873408250762`
- midpoint sampled margin: `0.04938029512662756`
- midpoint sampled max violation: `-0.04938029512662756`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5621461094200739`
- midpoint sampled margin: `-0.1396622922602877`
- midpoint sampled max violation: `0.1396622922602877`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2720378543781754`
- midpoint sampled margin: `0.08162515445920615`
- midpoint sampled max violation: `-0.08162515445920615`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.4378490537525045`
- midpoint sampled margin: `0.04938029512662767`
- midpoint sampled max violation: `-0.04938029512662767`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.31940871548403205`
- midpoint sampled margin: `0.08162515445920615`
- midpoint sampled max violation: `-0.08162515445920615`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8414452616031911`
- midpoint sampled margin: `-0.4134419881654524`
- midpoint sampled max violation: `0.4134419881654524`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2879646746892983`
- midpoint sampled margin: `0.1206340152658697`
- midpoint sampled max violation: `-0.1206340152658697`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332764`
- midpoint sampled margin: `-0.26870355203153673`
- midpoint sampled max violation: `0.26870355203153673`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3893375672974065, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6362345221480838`
- midpoint sampled margin: `-0.3268047896072236`
- midpoint sampled max violation: `0.3268047896072236`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.29905829822089647`
- midpoint sampled margin: `0.01037143431996379`
- midpoint sampled max violation: `-0.01037143431996379`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5153626612076014`
- midpoint sampled margin: `-0.1842973493287393`
- midpoint sampled max violation: `0.1842973493287393`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.29642265171194215`
- midpoint sampled margin: `0.12063401526586981`
- midpoint sampled max violation: `-0.12063401526586981`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332761`
- midpoint sampled margin: `-0.26870355203153673`
- midpoint sampled max violation: `0.26870355203153673`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.778675134594813, -0.3893375672974065] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.849903238625835`
- midpoint sampled margin: `-0.40710538023471976`
- midpoint sampled max violation: `0.40710538023471976`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.4621006692328862`
- midpoint sampled margin: `0.010371434319963901`
- midpoint sampled max violation: `-0.010371434319963901`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5153626612076019`
- midpoint sampled margin: `-0.18429734932873965`
- midpoint sampled max violation: `0.18429734932873965`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.38933756729740654] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.6362345221480841`
- midpoint sampled margin: `-0.3268047896072237`
- midpoint sampled max violation: `0.3268047896072237`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 47
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2990582982208967`
- midpoint sampled margin: `0.01037143431996368`
- midpoint sampled max violation: `-0.01037143431996368`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8414452616031913`
- midpoint sampled margin: `-0.41344198816545275`
- midpoint sampled max violation: `0.41344198816545275`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332762`
- midpoint sampled margin: `-0.26870355203153684`
- midpoint sampled max violation: `0.26870355203153684`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.38933756729740654] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.28796467468929854`
- midpoint sampled margin: `0.12063401526586959`
- midpoint sampled max violation: `-0.12063401526586959`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 51
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.4621006692328865`
- midpoint sampled margin: `0.010371434319964123`
- midpoint sampled max violation: `-0.010371434319964123`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 52
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5346015456332769`
- midpoint sampled margin: `-0.26870355203153684`
- midpoint sampled max violation: `0.26870355203153684`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 53
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.38933756729740654, 0.7786751345948131] x [-0.778675134594813, -0.3893375672974065]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.8499032386258351`
- midpoint sampled margin: `-0.4071053802347193`
- midpoint sampled max violation: `0.4071053802347193`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 54
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.38933756729740654] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.2964226517119425`
- midpoint sampled margin: `0.12063401526586959`
- midpoint sampled max violation: `-0.12063401526586959`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3893375672974065, 0.0] x [0.38933756729740654, 0.7786751345948131]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.5621461094200737`
- midpoint sampled margin: `-0.1396622922602876`
- midpoint sampled max violation: `0.1396622922602876`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.27203785437817585`
- midpoint sampled margin: `0.08162515445920604`
- midpoint sampled max violation: `-0.08162515445920604`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.3893375672974065, 0.0] x [0.0, 0.38933756729740654]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.3820873408250758`
- midpoint sampled margin: `0.04938029512662767`
- midpoint sampled max violation: `-0.04938029512662767`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.3194087154840318`
- midpoint sampled margin: `0.08162515445920615`
- midpoint sampled max violation: `-0.08162515445920615`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.3893375672974065, 0.0] x [-0.3893375672974065, 0.0]`
- l2 translation radius: `0.27530323400666995`
- certified upper violation: `0.4378490537525044`
- midpoint sampled margin: `0.04938029512662756`
- midpoint sampled max violation: `-0.04938029512662756`
- pose drift bound: `0.5020281545359472`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 32, 40]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
