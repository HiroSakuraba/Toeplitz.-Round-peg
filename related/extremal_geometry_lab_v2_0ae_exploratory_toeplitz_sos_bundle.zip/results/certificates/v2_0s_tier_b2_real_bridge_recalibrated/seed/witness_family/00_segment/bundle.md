# Rigid-motion certificate bundle: segment in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `96`
- unresolved boxes: `64`
- explored boxes: `256`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.4330122018922194`
- sampled max violation: `-0.4330122018922194`
- certified upper violation: `-0.37528173618915744`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562107`
- midpoint sampled margin: `-0.8001636639511663`
- midpoint sampled max violation: `0.8001636639511663`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002114`
- midpoint sampled margin: `-0.6533660487781604`
- midpoint sampled max violation: `0.6533660487781604`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893959`
- midpoint sampled margin: `-1.153716347437658`
- midpoint sampled max violation: `1.153716347437658`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820854`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010526`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377495`
- midpoint sampled margin: `-0.20674539370252087`
- midpoint sampled max violation: `0.20674539370252087`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872693`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.49950388840477955`
- midpoint sampled margin: `-0.1115411647517418`
- midpoint sampled max violation: `0.1115411647517418`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304831`
- midpoint sampled margin: `-0.3980864470579174`
- midpoint sampled max violation: `0.3980864470579174`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.5091109377479937`
- midpoint sampled margin: `-0.21058644705779261`
- midpoint sampled max violation: `0.21058644705779261`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244165`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244156`
- midpoint sampled margin: `-0.7787163474374086`
- midpoint sampled max violation: `0.7787163474374086`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047789`
- midpoint sampled margin: `-0.11154116475174203`
- midpoint sampled max violation: `0.11154116475174203`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872686`
- midpoint sampled margin: `-0.17174366280113906`
- midpoint sampled max violation: `0.17174366280113906`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 15
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.5091109377479928`
- midpoint sampled margin: `-0.21058644705779272`
- midpoint sampled max violation: `0.21058644705779272`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304827`
- midpoint sampled margin: `-0.39808644705791774`
- midpoint sampled max violation: `0.39808644705791774`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010524`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377497`
- midpoint sampled margin: `-0.20674539370252065`
- midpoint sampled max violation: `0.20674539370252065`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820854`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.783646813189395`
- midpoint sampled margin: `-1.1537163474376584`
- midpoint sampled max violation: `1.1537163474376584`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002118`
- midpoint sampled margin: `-0.6533660487781601`
- midpoint sampled max violation: `0.6533660487781601`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562112`
- midpoint sampled margin: `-0.8001636639511661`
- midpoint sampled max violation: `0.8001636639511661`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893952`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002111`
- midpoint sampled margin: `-0.6533660487781602`
- midpoint sampled max violation: `0.6533660487781602`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562114`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244154`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304829`
- midpoint sampled margin: `-0.39808644705791785`
- midpoint sampled max violation: `0.39808644705791785`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.509110937747993`
- midpoint sampled margin: `-0.21058644705779284`
- midpoint sampled max violation: `0.21058644705779284`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872688`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 32
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047791`
- midpoint sampled margin: `-0.1115411647517418`
- midpoint sampled max violation: `0.1115411647517418`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377502`
- midpoint sampled margin: `-0.20674539370252065`
- midpoint sampled max violation: `0.20674539370252065`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010519`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 35
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820845`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.302721079282085`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377493`
- midpoint sampled margin: `-0.20674539370252054`
- midpoint sampled max violation: `0.20674539370252054`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010524`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 39
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.509110937747993`
- midpoint sampled margin: `-0.21058644705779284`
- midpoint sampled max violation: `0.21058644705779284`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304829`
- midpoint sampled margin: `-0.39808644705791785`
- midpoint sampled max violation: `0.39808644705791785`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047791`
- midpoint sampled margin: `-0.11154116475174203`
- midpoint sampled max violation: `0.11154116475174203`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.707842725787269`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 43
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244158`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562105`
- midpoint sampled margin: `-0.800163663951166`
- midpoint sampled max violation: `0.800163663951166`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002118`
- midpoint sampled margin: `-0.6533660487781602`
- midpoint sampled max violation: `0.6533660487781602`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893957`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562107`
- midpoint sampled margin: `-0.8001636639511661`
- midpoint sampled max violation: `0.8001636639511661`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002114`
- midpoint sampled margin: `-0.6533660487781604`
- midpoint sampled max violation: `0.6533660487781604`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893959`
- midpoint sampled margin: `-1.153716347437658`
- midpoint sampled max violation: `1.153716347437658`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820854`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010526`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 54
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377495`
- midpoint sampled margin: `-0.2067453937025211`
- midpoint sampled max violation: `0.2067453937025211`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872693`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 56
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.49950388840477955`
- midpoint sampled margin: `-0.11154116475174158`
- midpoint sampled max violation: `0.11154116475174158`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304831`
- midpoint sampled margin: `-0.3980864470579174`
- midpoint sampled max violation: `0.3980864470579174`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.5091109377479937`
- midpoint sampled margin: `-0.21058644705779261`
- midpoint sampled max violation: `0.21058644705779261`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244165`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244156`
- midpoint sampled margin: `-0.7787163474374086`
- midpoint sampled max violation: `0.7787163474374086`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047789`
- midpoint sampled margin: `-0.11154116475174192`
- midpoint sampled max violation: `0.11154116475174192`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872686`
- midpoint sampled margin: `-0.17174366280113906`
- midpoint sampled max violation: `0.17174366280113906`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.5091109377479928`
- midpoint sampled margin: `-0.21058644705779272`
- midpoint sampled max violation: `0.21058644705779272`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304827`
- midpoint sampled margin: `-0.39808644705791774`
- midpoint sampled max violation: `0.39808644705791774`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010526`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 66
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377497`
- midpoint sampled margin: `-0.20674539370252087`
- midpoint sampled max violation: `0.20674539370252087`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 67
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820854`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 68
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.783646813189395`
- midpoint sampled margin: `-1.1537163474376584`
- midpoint sampled max violation: `1.1537163474376584`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002118`
- midpoint sampled margin: `-0.6533660487781601`
- midpoint sampled max violation: `0.6533660487781601`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562112`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 72
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893952`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 73
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002111`
- midpoint sampled margin: `-0.6533660487781602`
- midpoint sampled max violation: `0.6533660487781602`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 74
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163664`
- midpoint sampled max violation: `0.6125286939163664`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 75
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7500000000005, 1.500000000001] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562114`
- midpoint sampled margin: `-0.8001636639511659`
- midpoint sampled max violation: `0.8001636639511659`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 76
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244154`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 77
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304829`
- midpoint sampled margin: `-0.39808644705791785`
- midpoint sampled max violation: `0.39808644705791785`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.509110937747993`
- midpoint sampled margin: `-0.21058644705779284`
- midpoint sampled max violation: `0.21058644705779284`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 79
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.7078427257872688`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 80
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047791`
- midpoint sampled margin: `-0.11154116475174192`
- midpoint sampled max violation: `0.11154116475174192`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 81
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377502`
- midpoint sampled margin: `-0.20674539370252087`
- midpoint sampled max violation: `0.20674539370252087`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 82
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010519`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 83
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3027210792820845`
- midpoint sampled margin: `-0.47855409770080515`
- midpoint sampled max violation: `0.47855409770080515`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.302721079282085`
- midpoint sampled margin: `-0.4785540977008049`
- midpoint sampled max violation: `0.4785540977008049`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.6504629022377493`
- midpoint sampled margin: `-0.20674539370252099`
- midpoint sampled max violation: `0.20674539370252099`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 86
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.5310598152010524`
- midpoint sampled margin: `-0.15841474515501208`
- midpoint sampled max violation: `0.15841474515501208`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 87
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.509110937747993`
- midpoint sampled margin: `-0.21058644705779284`
- midpoint sampled max violation: `0.21058644705779284`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 88
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.7174497751304829`
- midpoint sampled margin: `-0.39808644705791785`
- midpoint sampled max violation: `0.39808644705791785`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 89
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4995038884047791`
- midpoint sampled margin: `-0.11154116475174203`
- midpoint sampled max violation: `0.11154116475174203`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 90
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.4192627457814901`
- certified upper violation: `0.707842725787269`
- midpoint sampled margin: `-0.17174366280113917`
- midpoint sampled max violation: `0.17174366280113917`
- pose drift bound: `0.6156122866312448`
- certification method: `interval`
- depth: `2`

### Box 91
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7500000000005, 0.0] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.3669691384244158`
- midpoint sampled margin: `-0.7787163474374085`
- midpoint sampled max violation: `0.7787163474374085`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 92
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.7500000000005, 1.500000000001]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7166596490562105`
- midpoint sampled margin: `-0.800163663951166`
- midpoint sampled max violation: `0.800163663951166`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 93
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [0.0, 0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2234571812537245`
- midpoint sampled margin: `-0.6125286939163662`
- midpoint sampled max violation: `0.6125286939163662`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 94
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-0.7500000000005, 0.0]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.2494804460002118`
- midpoint sampled margin: `-0.65336604877816`
- midpoint sampled max violation: `0.65336604877816`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

### Box 95
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.500000000001, -0.7500000000005] x [-1.500000000001, -0.7500000000005]`
- l2 translation radius: `0.5303300858902642`
- certified upper violation: `1.7836468131893957`
- midpoint sampled margin: `-1.1537163474376588`
- midpoint sampled max violation: `1.1537163474376588`
- pose drift bound: `0.9230291675897737`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.07595883524838287`
- midpoint sampled max violation: `-0.07595883524838287`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.035355748383760766`
- midpoint sampled margin: `0.21658525484523805`
- midpoint sampled max violation: `-0.21658525484523805`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183685`
- midpoint sampled margin: `0.11218276372198621`
- midpoint sampled max violation: `-0.11218276372198621`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578219`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587857`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.17474436198539833`
- midpoint sampled margin: `0.2132183616676394`
- midpoint sampled max violation: `-0.2132183616676394`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111019`
- midpoint sampled margin: `-0.0733269206385363`
- midpoint sampled max violation: `0.0733269206385363`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.18435141132861244`
- midpoint sampled margin: `0.11417307936158849`
- midpoint sampled max violation: `-0.11417307936158849`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.17474436198539767`
- midpoint sampled margin: `0.21321836166763908`
- midpoint sampled max violation: `-0.21321836166763908`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.18435141132861177`
- midpoint sampled margin: `0.11417307936158827`
- midpoint sampled max violation: `-0.11417307936158827`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111015`
- midpoint sampled margin: `-0.07332692063853663`
- midpoint sampled max violation: `0.07332692063853663`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.035355748383760655`
- midpoint sampled margin: `0.21658525484523805`
- midpoint sampled max violation: `-0.21658525484523805`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.29116505102228984`
- midpoint sampled margin: `0.07595883524838298`
- midpoint sampled max violation: `-0.07595883524838298`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1173645384358788`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578219`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183687`
- midpoint sampled margin: `0.1121827637219861`
- midpoint sampled max violation: `-0.1121827637219861`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111017`
- midpoint sampled margin: `-0.07332692063853685`
- midpoint sampled max violation: `0.07332692063853685`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.184351411328612`
- midpoint sampled margin: `0.11417307936158816`
- midpoint sampled max violation: `-0.11417307936158816`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1747443619853979`
- midpoint sampled margin: `0.21321836166763908`
- midpoint sampled max violation: `-0.21321836166763908`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183687`
- midpoint sampled margin: `0.11218276372198599`
- midpoint sampled max violation: `-0.11218276372198599`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587924`
- midpoint sampled margin: `0.3016730793617134`
- midpoint sampled max violation: `-0.3016730793617134`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.44256648905782103`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.03535574838376132`
- midpoint sampled margin: `0.21658525484523794`
- midpoint sampled max violation: `-0.21658525484523794`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.0759588352483832`
- midpoint sampled max violation: `-0.0759588352483832`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578217`
- midpoint sampled margin: `-0.024732384071632807`
- midpoint sampled max violation: `0.024732384071632807`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587846`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.32570337581836806`
- midpoint sampled margin: `0.11218276372198599`
- midpoint sampled max violation: `-0.11218276372198599`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.0759588352483832`
- midpoint sampled max violation: `-0.0759588352483832`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.03535574838376121`
- midpoint sampled margin: `0.21658525484523783`
- midpoint sampled max violation: `-0.21658525484523783`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1843514113286122`
- midpoint sampled margin: `0.11417307936158816`
- midpoint sampled max violation: `-0.11417307936158816`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.39269024871110214`
- midpoint sampled margin: `-0.07332692063853696`
- midpoint sampled max violation: `0.07332692063853696`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1747443619853981`
- midpoint sampled margin: `0.21321836166763897`
- midpoint sampled max violation: `-0.21321836166763897`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.0759588352483831`
- midpoint sampled max violation: `-0.0759588352483831`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.035355748383760766`
- midpoint sampled margin: `0.21658525484523794`
- midpoint sampled max violation: `-0.21658525484523794`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183685`
- midpoint sampled margin: `0.11218276372198632`
- midpoint sampled max violation: `-0.11218276372198632`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.37500000000025] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578217`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587868`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.17474436198539833`
- midpoint sampled margin: `0.21321836166763963`
- midpoint sampled max violation: `-0.21321836166763963`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111019`
- midpoint sampled margin: `-0.0733269206385363`
- midpoint sampled max violation: `0.0733269206385363`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.18435141132861244`
- midpoint sampled margin: `0.11417307936158849`
- midpoint sampled max violation: `-0.11417307936158849`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.17474436198539767`
- midpoint sampled margin: `0.2132183616676393`
- midpoint sampled max violation: `-0.2132183616676393`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.18435141132861177`
- midpoint sampled margin: `0.11417307936158827`
- midpoint sampled max violation: `-0.11417307936158827`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111015`
- midpoint sampled margin: `-0.07332692063853663`
- midpoint sampled max violation: `0.07332692063853663`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.035355748383760655`
- midpoint sampled margin: `0.21658525484523794`
- midpoint sampled max violation: `-0.21658525484523794`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.29116505102228984`
- midpoint sampled margin: `0.0759588352483832`
- midpoint sampled max violation: `-0.0759588352483832`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587868`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.37500000000025, 0.0] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578219`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 47
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183687`
- midpoint sampled margin: `0.11218276372198621`
- midpoint sampled max violation: `-0.11218276372198621`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.37500000000025, 0.7500000000005] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3926902487111017`
- midpoint sampled margin: `-0.07332692063853685`
- midpoint sampled max violation: `0.07332692063853685`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.184351411328612`
- midpoint sampled margin: `0.11417307936158816`
- midpoint sampled max violation: `-0.11417307936158816`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1747443619853979`
- midpoint sampled margin: `0.21321836166763897`
- midpoint sampled max violation: `-0.21321836166763897`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 51
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.37500000000025, 0.7500000000005] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.3257033758183687`
- midpoint sampled margin: `0.11218276372198621`
- midpoint sampled max violation: `-0.11218276372198621`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 52
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587924`
- midpoint sampled margin: `0.3016730793617134`
- midpoint sampled max violation: `-0.3016730793617134`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 53
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.44256648905782126`
- midpoint sampled margin: `-0.024732384071632918`
- midpoint sampled max violation: `0.024732384071632918`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 54
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.03535574838376132`
- midpoint sampled margin: `0.21658525484523794`
- midpoint sampled max violation: `-0.21658525484523794`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.37500000000025] x [-0.7500000000005, -0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.0759588352483832`
- midpoint sampled max violation: `-0.0759588352483832`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.4425664890578217`
- midpoint sampled margin: `-0.02473238407163303`
- midpoint sampled max violation: `0.02473238407163303`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.11736453843587857`
- midpoint sampled margin: `0.3016730793617133`
- midpoint sampled max violation: `-0.3016730793617133`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.32570337581836806`
- midpoint sampled margin: `0.11218276372198632`
- midpoint sampled max violation: `-0.11218276372198632`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37500000000025, 0.0] x [0.37500000000025, 0.7500000000005]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.2911650510222892`
- midpoint sampled margin: `0.0759588352483831`
- midpoint sampled max violation: `-0.0759588352483831`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37500000000025, 0.0] x [0.0, 0.37500000000025]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.03535574838376121`
- midpoint sampled margin: `0.21658525484523794`
- midpoint sampled max violation: `-0.21658525484523794`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 61
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1843514113286122`
- midpoint sampled margin: `0.11417307936158816`
- midpoint sampled max violation: `-0.11417307936158816`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7500000000005, -0.37500000000025] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.39269024871110214`
- midpoint sampled margin: `-0.07332692063853696`
- midpoint sampled max violation: `0.07332692063853696`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.37500000000025, 0.0] x [-0.37500000000025, 0.0]`
- l2 translation radius: `0.2651650429451321`
- certified upper violation: `0.1747443619853981`
- midpoint sampled margin: `0.21321836166763897`
- midpoint sampled max violation: `-0.21321836166763897`
- pose drift bound: `0.46151458379488686`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 32]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`
