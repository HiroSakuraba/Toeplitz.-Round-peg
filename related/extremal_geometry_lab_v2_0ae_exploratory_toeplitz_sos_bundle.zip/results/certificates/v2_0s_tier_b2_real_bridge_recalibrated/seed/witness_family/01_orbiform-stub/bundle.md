# Rigid-motion certificate bundle: orbiform-stub in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `112`
- unresolved boxes: `32`
- explored boxes: `224`

## Best midpoint pose found during refinement
- rotation: `1.9634954084936207`
- translation: `(-0.0, -0.004939311588785329)`
- sampled margin: `0.3660254037844387`
- sampled max violation: `-0.3660254037844387`
- certified upper violation: `-0.2520136843941162`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474471`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037414`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610893`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787384`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379731`
- midpoint sampled margin: `-0.23570655332163082`
- midpoint sampled max violation: `0.23570655332163082`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379736`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556226`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787388`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390395`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.526707880839039`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379729`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787382`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610891`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610898`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.94338555560374`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474476`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474476`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037414`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610893`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787384`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 36
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556224`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379736`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 38
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556226`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 40
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390395`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.526707880839039`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.662056561355622`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379727`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 45
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787382`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610891`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 47
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610898`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 49
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390389`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.94338555560374`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474471`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474476`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037414`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556224`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379736`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 66
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556226`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 67
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 68
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787388`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390395`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.526707880839039`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.662056561355622`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 72
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379727`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 73
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787382`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 74
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610891`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 75
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 76
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610898`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 79
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390389`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.94338555560374`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 81
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474471`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 82
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 83
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474471`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 87
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037414`
- midpoint sampled margin: `-1.1664756061599593`
- midpoint sampled max violation: `1.1664756061599593`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 88
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 90
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379731`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 92
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379736`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 94
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556226`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610895`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 96
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 97
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390395`
- midpoint sampled margin: `-0.79147560615996`
- midpoint sampled max violation: `0.79147560615996`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 98
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.526707880839039`
- midpoint sampled margin: `-0.7914756061599599`
- midpoint sampled max violation: `0.7914756061599599`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 99
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.662056561355622`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 100
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379727`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 101
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787382`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 102
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610889`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 103
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5773539102787386`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 104
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7856927476610898`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 105
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6620565613556222`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 106
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8703953987379733`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 107
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5267078808390393`
- midpoint sampled margin: `-0.7914756061599598`
- midpoint sampled max violation: `0.7914756061599598`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 108
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.94338555560374`
- midpoint sampled margin: `-1.1664756061599602`
- midpoint sampled max violation: `1.1664756061599602`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 109
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474471`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 110
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4355530096474467`
- midpoint sampled margin: `-0.7589745962155613`
- midpoint sampled max violation: `0.7589745962155613`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 111
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9433855556037412`
- midpoint sampled margin: `-1.1664756061599597`
- midpoint sampled max violation: `1.1664756061599597`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595739`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364577`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645813`
- midpoint sampled margin: `0.11417320988795154`
- midpoint sampled max violation: `-0.11417320988795154`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364577`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957367`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957433`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595739`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645813`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645724`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957367`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957433`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645813`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645724`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957367`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957433`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364577`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645813`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2525943838595741`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.33729703493645724`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957367`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25259438385957433`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3372970349364579`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 24, 40]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `5.551115123125783e-17`
