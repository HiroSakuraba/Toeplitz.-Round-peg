# Rigid-motion certificate bundle: regular-3-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `105`
- unresolved boxes: `64`
- explored boxes: `274`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `-0.22183893486633466`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.14360675234816`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5062494089004244`
- midpoint sampled margin: `-0.7252355885716434`
- midpoint sampled max violation: `0.7252355885716434`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.4153976964716766`
- midpoint sampled margin: `-0.8581612486535555`
- midpoint sampled max violation: `0.8581612486535555`
- pose drift bound: `0.7844024563544826`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[1.1830127018922192, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.44088280327944945`
- certified upper violation: `1.400372671017271`
- midpoint sampled margin: `-0.8656246566669298`
- midpoint sampled max violation: `0.8656246566669298`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 4
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.7886751345948126, 1.1830127018922192] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.8460263389793341`
- midpoint sampled margin: `-0.47128708936952324`
- midpoint sampled max violation: `0.47128708936952324`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.7886751345948126, 1.1830127018922192] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `1.0824185038048324`
- midpoint sampled margin: `-0.711567039357324`
- midpoint sampled max violation: `0.711567039357324`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.9712844843701722`
- midpoint sampled margin: `-1.3076775358252046`
- midpoint sampled max violation: `1.3076775358252046`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7054423240445529`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.6312761909174512`
- midpoint sampled margin: `-0.20286127903871087`
- midpoint sampled max violation: `0.20286127903871087`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `1.012822262353949`
- midpoint sampled margin: `-0.3436450802355663`
- midpoint sampled max violation: `0.3436450802355663`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.7937400482021457`
- midpoint sampled margin: `-0.3172294720599179`
- midpoint sampled max violation: `0.3172294720599179`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8497798913419601`
- midpoint sampled margin: `-0.5143982557086207`
- midpoint sampled max violation: `0.5143982557086207`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.5327925932341797`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6801061291595483`
- midpoint sampled margin: `-0.7788387679126024`
- midpoint sampled max violation: `0.7788387679126024`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.7694884327217637`
- midpoint sampled margin: `-0.27822061125325415`
- midpoint sampled max violation: `0.27822061125325415`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9885706468735669`
- midpoint sampled margin: `-0.3046362194289025`
- midpoint sampled max violation: `0.3046362194289025`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 16
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6198076591051445`
- midpoint sampled margin: `-0.12006068841121464`
- midpoint sampled max violation: `0.12006068841121464`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.8749483436646079`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 18
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.7137267197943362`
- midpoint sampled margin: `-0.27822061125325404`
- midpoint sampled max violation: `0.27822061125325404`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.4408828032794494`
- certified upper violation: `0.9337940922819798`
- midpoint sampled margin: `-0.30673328100132313`
- midpoint sampled max violation: `0.30673328100132313`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 20
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.4408828032794494`
- certified upper violation: `0.7724296221523341`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6158216358383586`
- midpoint sampled margin: `-0.763910723166456`
- midpoint sampled max violation: `0.763910723166456`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.1152945888351913`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.5992776531127662`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6079857069316517`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.080830323247894`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.1152945888351917`
- midpoint sampled margin: `-1.1582482904638631`
- midpoint sampled max violation: `1.1582482904638631`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5992776531127662`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6079857069316519`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.080830323247894`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6801061291595492`
- midpoint sampled margin: `-0.7788387679126029`
- midpoint sampled max violation: `0.7788387679126029`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.8749483436646077`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 32
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.6198076591051442`
- midpoint sampled margin: `-0.12006068841121476`
- midpoint sampled max violation: `0.12006068841121476`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9885706468735671`
- midpoint sampled margin: `-0.30463621942890307`
- midpoint sampled max violation: `0.30463621942890307`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.7694884327217639`
- midpoint sampled margin: `-0.2782206112532545`
- midpoint sampled max violation: `0.2782206112532545`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6544190137833804`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.7724296221523343`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6752334412028155`
- midpoint sampled margin: `-0.18985856760594388`
- midpoint sampled max violation: `0.18985856760594388`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9337940922819791`
- midpoint sampled margin: `-0.37680500307760567`
- midpoint sampled max violation: `0.37680500307760567`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 39
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.6158216358383588`
- midpoint sampled margin: `-0.7639107231664563`
- midpoint sampled max violation: `0.7639107231664563`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.705442324044553`
- midpoint sampled margin: `-0.9133399685277988`
- midpoint sampled max violation: `0.9133399685277988`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.7937400482021457`
- midpoint sampled margin: `-0.317229472059918`
- midpoint sampled max violation: `0.317229472059918`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `1.012822262353949`
- midpoint sampled margin: `-0.34364508023556617`
- midpoint sampled max violation: `0.34364508023556617`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 43
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.631276190917451`
- midpoint sampled margin: `-0.20286127903871054`
- midpoint sampled max violation: `0.20286127903871054`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.8497798913419599`
- midpoint sampled margin: `-0.5143982557086214`
- midpoint sampled max violation: `0.5143982557086214`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.532792593234179`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.143606752348159`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.5062494089004241`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.1830127018922192, -0.7886751345948129] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8460263389793341`
- midpoint sampled margin: `-0.471287089369523`
- midpoint sampled max violation: `0.471287089369523`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.1830127018922192, -0.7886751345948129] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `1.0824185038048333`
- midpoint sampled margin: `-0.7115670393573247`
- midpoint sampled max violation: `0.7115670393573247`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -1.1830127018922192] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.44088280327944945`
- certified upper violation: `1.4003726710172704`
- midpoint sampled margin: `-0.8656246566669293`
- midpoint sampled max violation: `0.8656246566669293`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.4153976964716766`
- midpoint sampled margin: `-0.8581612486535556`
- midpoint sampled max violation: `0.8581612486535556`
- pose drift bound: `0.7844024563544826`
- certification method: `interval`
- depth: `1`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.9712844843701725`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `2.0808303232478926`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6079857069316512`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5992776531127662`
- midpoint sampled margin: `-0.874664833932986`
- midpoint sampled max violation: `0.874664833932986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.115294588835193`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6158216358383586`
- midpoint sampled margin: `-0.7639107231664563`
- midpoint sampled max violation: `0.7639107231664563`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9337940922819798`
- midpoint sampled margin: `-0.3067332810013228`
- midpoint sampled max violation: `0.3067332810013228`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 59
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.7137267197943358`
- midpoint sampled margin: `-0.27822061125325404`
- midpoint sampled max violation: `0.27822061125325404`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.7724296221523337`
- midpoint sampled margin: `-0.2978919047625114`
- midpoint sampled max violation: `0.2978919047625114`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6470642959274575`
- midpoint sampled margin: `-0.18352371174130433`
- midpoint sampled max violation: `0.18352371174130433`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9885706468735675`
- midpoint sampled margin: `-0.37680500307760567`
- midpoint sampled max violation: `0.37680500307760567`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6819142111023386`
- midpoint sampled margin: `-0.2978919047625114`
- midpoint sampled max violation: `0.2978919047625114`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.8749483436646082`
- midpoint sampled margin: `-0.19487148119387465`
- midpoint sampled max violation: `0.19487148119387465`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 65
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.6801061291595478`
- midpoint sampled margin: `-0.7788387679126025`
- midpoint sampled max violation: `0.7788387679126025`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 66
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5327925932341788`
- midpoint sampled margin: `-0.913339968527799`
- midpoint sampled max violation: `0.913339968527799`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 67
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8497798913419592`
- midpoint sampled margin: `-0.5143982557086211`
- midpoint sampled max violation: `0.5143982557086211`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 68
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.6312761909174517`
- midpoint sampled margin: `-0.20286127903871065`
- midpoint sampled max violation: `0.20286127903871065`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 69
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.7937400482021462`
- midpoint sampled margin: `-0.3172294720599179`
- midpoint sampled max violation: `0.3172294720599179`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 70
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.4408828032794494`
- certified upper violation: `1.0128222623539493`
- midpoint sampled margin: `-0.3436450802355667`
- midpoint sampled max violation: `0.3436450802355667`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 71
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.7054423240445533`
- midpoint sampled margin: `-0.9133399685277984`
- midpoint sampled max violation: `0.9133399685277984`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 72
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.9712844843701727`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 73
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.4153976964716766`
- midpoint sampled margin: `-0.8581612486535556`
- midpoint sampled max violation: `0.8581612486535556`
- pose drift bound: `0.7844024563544825`
- certification method: `interval`
- depth: `1`

### Box 74
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.1830127018922192, -0.7886751345948129] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `1.082418503804833`
- midpoint sampled margin: `-0.7115670393573241`
- midpoint sampled max violation: `0.7115670393573241`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 75
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.1830127018922192, -0.7886751345948129] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.8460263389793339`
- midpoint sampled margin: `-0.4712870893695237`
- midpoint sampled max violation: `0.4712870893695237`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 76
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-1.5773502691896257, -1.1830127018922192] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.44088280327944934`
- certified upper violation: `1.40037267101727`
- midpoint sampled margin: `-0.86562465666693`
- midpoint sampled max violation: `0.86562465666693`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5062494089004246`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 78
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.14360675234816`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 79
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252054`
- certified upper violation: `1.9712844843701731`
- midpoint sampled margin: `-1.307677535825205`
- midpoint sampled max violation: `1.307677535825205`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[1.1830127018922192, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.44088280327944934`
- certified upper violation: `1.4003726710172708`
- midpoint sampled margin: `-0.8656246566669296`
- midpoint sampled max violation: `0.8656246566669296`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 81
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.1830127018922192] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `1.082418503804833`
- midpoint sampled margin: `-0.7115670393573247`
- midpoint sampled max violation: `0.7115670393573247`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 82
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.1830127018922192] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.8460263389793338`
- midpoint sampled margin: `-0.471287089369523`
- midpoint sampled max violation: `0.471287089369523`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 83
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.415397696471676`
- midpoint sampled margin: `-0.8581612486535553`
- midpoint sampled max violation: `0.8581612486535553`
- pose drift bound: `0.7844024563544826`
- certification method: `interval`
- depth: `1`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5062494089004255`
- midpoint sampled margin: `-0.7252355885716436`
- midpoint sampled max violation: `0.7252355885716436`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.7886751345948126, 1.5773502691896257] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.1436067523481603`
- midpoint sampled margin: `-1.3076775358252046`
- midpoint sampled max violation: `1.3076775358252046`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.532792593234179`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 87
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.8497798913419594`
- midpoint sampled margin: `-0.5143982557086212`
- midpoint sampled max violation: `0.5143982557086212`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 88
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6713159114078397`
- midpoint sampled margin: `-0.17289190476251093`
- midpoint sampled max violation: `0.17289190476251093`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `1.0128222623539496`
- midpoint sampled margin: `-0.41581386388426933`
- midpoint sampled max violation: `0.41581386388426933`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 90
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3943375672974063] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6312761909174508`
- midpoint sampled margin: `-0.20286127903871065`
- midpoint sampled max violation: `0.20286127903871065`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.7886751345948126] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.705442324044554`
- midpoint sampled margin: `-0.9133399685277986`
- midpoint sampled max violation: `0.9133399685277986`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 92
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6158216358383584`
- midpoint sampled margin: `-0.7639107231664566`
- midpoint sampled max violation: `0.7639107231664566`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.7724296221523335`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 94
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.7137267197943356`
- midpoint sampled margin: `-0.27822061125325437`
- midpoint sampled max violation: `0.27822061125325437`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.4408828032794493`
- certified upper violation: `0.9337940922819796`
- midpoint sampled margin: `-0.306733281001323`
- midpoint sampled max violation: `0.306733281001323`
- pose drift bound: `0.6676077238087266`
- certification method: `interval`
- depth: `2`

### Box 96
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.6198076591051451`
- midpoint sampled margin: `-0.12006068841121498`
- midpoint sampled max violation: `0.12006068841121498`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 97
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.4408828032794494`
- certified upper violation: `0.8749483436646079`
- midpoint sampled margin: `-0.2978919047625116`
- midpoint sampled max violation: `0.2978919047625116`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 98
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.7694884327217641`
- midpoint sampled margin: `-0.27822061125325426`
- midpoint sampled max violation: `0.27822061125325426`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 99
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.4408828032794494`
- certified upper violation: `0.9885706468735675`
- midpoint sampled margin: `-0.30463621942890307`
- midpoint sampled max violation: `0.30463621942890307`
- pose drift bound: `0.6676077238087267`
- certification method: `interval`
- depth: `2`

### Box 100
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.7886751345948129, 0.0] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.6801061291595492`
- midpoint sampled margin: `-0.7788387679126029`
- midpoint sampled max violation: `0.7788387679126029`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 101
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.7886751345948126, 1.5773502691896257]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.0808303232478935`
- midpoint sampled margin: `-1.2071067811865475`
- midpoint sampled max violation: `1.2071067811865475`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 102
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [0.0, 0.7886751345948126]`
- l2 translation radius: `0.5576775358252052`
- certified upper violation: `1.6079857069316512`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837596`
- certification method: `interval`
- depth: `0`

### Box 103
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-0.7886751345948129, 0.0]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `1.5992776531127662`
- midpoint sampled margin: `-0.8746648339329858`
- midpoint sampled max violation: `0.8746648339329858`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

### Box 104
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5773502691896257, -0.7886751345948129] x [-1.5773502691896257, -0.7886751345948129]`
- l2 translation radius: `0.5576775358252053`
- certified upper violation: `2.1152945888351926`
- midpoint sampled margin: `-1.1582482904638627`
- midpoint sampled max violation: `1.1582482904638627`
- pose drift bound: `1.0111273768837599`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.8471442448330049`
- midpoint sampled margin: `-0.40003006268741415`
- midpoint sampled max violation: `0.40003006268741415`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.5276451377410742`
- midpoint sampled margin: `-0.2588830439558477`
- midpoint sampled max violation: `0.2588830439558477`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.2865556797350921`
- midpoint sampled margin: `0.1354545233415586`
- midpoint sampled max violation: `-0.1354545233415586`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.4522336972560361`
- midpoint sampled margin: `0.024276878886191677`
- midpoint sampled max violation: `-0.024276878886191677`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5276451377410748`
- midpoint sampled margin: `-0.2588830439558477`
- midpoint sampled max violation: `0.2588830439558477`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.27809770271244894`
- midpoint sampled margin: `0.1354545233415586`
- midpoint sampled max violation: `-0.1354545233415586`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8386862678103619`
- midpoint sampled margin: `-0.40548025828497636`
- midpoint sampled max violation: `0.40548025828497636`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3943375672974063] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6196040536585588`
- midpoint sampled margin: `-0.20286127903871065`
- midpoint sampled max violation: `0.20286127903871065`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.50827354039585`
- midpoint sampled margin: `-0.17289190476251115`
- midpoint sampled max violation: `0.17289190476251115`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.2891913262440471`
- midpoint sampled margin: `0.024276878886191677`
- midpoint sampled max violation: `-0.024276878886191677`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3943375672974063] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6306976771901569`
- midpoint sampled margin: `-0.3172294720599179`
- midpoint sampled max violation: `0.3172294720599179`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.4279820817756541`
- midpoint sampled margin: `0.06328573969285545`
- midpoint sampled max violation: `-0.06328573969285545`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.3069701922895055`
- midpoint sampled margin: `0.09644566253489473`
- midpoint sampled max violation: `-0.09644566253489473`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.3722203688482266`
- midpoint sampled margin: `0.06328573969285534`
- midpoint sampled max violation: `-0.06328573969285534`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.26008144648597353`
- midpoint sampled margin: `0.09644566253489484`
- midpoint sampled max violation: `-0.09644566253489484`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.5562943287597121`
- midpoint sampled margin: `-0.12694291601256458`
- midpoint sampled max violation: `0.12694291601256458`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.3069701922895054`
- midpoint sampled margin: `0.09644566253489473`
- midpoint sampled max violation: `-0.09644566253489473`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.42798208177565433`
- midpoint sampled margin: `0.06328573969285511`
- midpoint sampled max violation: `-0.06328573969285511`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.2600814464859743`
- midpoint sampled margin: `0.09644566253489473`
- midpoint sampled max violation: `-0.09644566253489473`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3943375672974063] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5562943287597112`
- midpoint sampled margin: `-0.12694291601256458`
- midpoint sampled max violation: `0.12694291601256458`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.3722203688482266`
- midpoint sampled margin: `0.06328573969285556`
- midpoint sampled max violation: `-0.06328573969285556`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.4522336972560361`
- midpoint sampled margin: `0.02427687888619179`
- midpoint sampled max violation: `-0.02427687888619179`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.28655567973509166`
- midpoint sampled margin: `0.13545452334155828`
- midpoint sampled max violation: `-0.13545452334155828`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8471442448330047`
- midpoint sampled margin: `-0.4000300626874136`
- midpoint sampled max violation: `0.4000300626874136`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5276451377410749`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.28919132624404686`
- midpoint sampled margin: `0.024276878886191455`
- midpoint sampled max violation: `-0.024276878886191455`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.6306976771901567`
- midpoint sampled margin: `-0.3172294720599179`
- midpoint sampled max violation: `0.3172294720599179`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.5082735403958505`
- midpoint sampled margin: `-0.17289190476251182`
- midpoint sampled max violation: `0.17289190476251182`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.27809770271244916`
- midpoint sampled margin: `0.13545452334155839`
- midpoint sampled max violation: `-0.13545452334155839`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.6196040536585585`
- midpoint sampled margin: `-0.20286127903871087`
- midpoint sampled max violation: `0.20286127903871087`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.5276451377410742`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.8386862678103622`
- midpoint sampled margin: `-0.4054802582849767`
- midpoint sampled max violation: `0.4054802582849767`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.3722203688482264`
- midpoint sampled margin: `0.06328573969285534`
- midpoint sampled max violation: `-0.06328573969285534`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.5562943287597116`
- midpoint sampled margin: `-0.12694291601256458`
- midpoint sampled max violation: `0.12694291601256458`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 34
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.26008144648597353`
- midpoint sampled margin: `0.09644566253489495`
- midpoint sampled max violation: `-0.09644566253489495`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.4279820817756548`
- midpoint sampled margin: `0.06328573969285534`
- midpoint sampled max violation: `-0.06328573969285534`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 36
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.30697019228950506`
- midpoint sampled margin: `0.09644566253489495`
- midpoint sampled max violation: `-0.09644566253489495`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.6196040536585581`
- midpoint sampled margin: `-0.20286127903871076`
- midpoint sampled max violation: `0.20286127903871076`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 38
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.2780977027124485`
- midpoint sampled margin: `0.13545452334155839`
- midpoint sampled max violation: `-0.13545452334155839`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8386862678103613`
- midpoint sampled margin: `-0.40548025828497614`
- midpoint sampled max violation: `0.40548025828497614`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 40
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5276451377410749`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.630697677190156`
- midpoint sampled margin: `-0.317229472059918`
- midpoint sampled max violation: `0.317229472059918`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 42
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.28919132624404664`
- midpoint sampled margin: `0.024276878886191566`
- midpoint sampled max violation: `-0.024276878886191566`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 43
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5082735403958496`
- midpoint sampled margin: `-0.17289190476251148`
- midpoint sampled max violation: `0.17289190476251148`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.28655567973509233`
- midpoint sampled margin: `0.1354545233415585`
- midpoint sampled max violation: `-0.1354545233415585`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 45
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.5276451377410742`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.7886751345948129, -0.39433756729740643] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.8471442448330053`
- midpoint sampled margin: `-0.4000300626874139`
- midpoint sampled max violation: `0.4000300626874139`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 47
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.45223369725603635`
- midpoint sampled margin: `0.024276878886191455`
- midpoint sampled max violation: `-0.024276878886191455`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.50827354039585`
- midpoint sampled margin: `-0.1728919047625116`
- midpoint sampled max violation: `0.1728919047625116`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 49
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.6306976771901562`
- midpoint sampled margin: `-0.31722947205991814`
- midpoint sampled max violation: `0.31722947205991814`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.28919132624404686`
- midpoint sampled margin: `0.024276878886191455`
- midpoint sampled max violation: `-0.024276878886191455`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 51
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.8386862678103615`
- midpoint sampled margin: `-0.40548025828497614`
- midpoint sampled max violation: `0.40548025828497614`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 52
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.5276451377410742`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 53
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3943375672974063] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.6196040536585581`
- midpoint sampled margin: `-0.20286127903871065`
- midpoint sampled max violation: `0.20286127903871065`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 54
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3943375672974063] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.27883876791260254`
- certified upper violation: `0.2780977027124487`
- midpoint sampled margin: `0.1354545233415585`
- midpoint sampled max violation: `-0.1354545233415585`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 55
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.45223369725603657`
- midpoint sampled margin: `0.0242768788861919`
- midpoint sampled max violation: `-0.0242768788861919`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 56
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5276451377410748`
- midpoint sampled margin: `-0.25888304395584794`
- midpoint sampled max violation: `0.25888304395584794`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 57
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3943375672974063] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.28655567973509255`
- midpoint sampled margin: `0.1354545233415585`
- midpoint sampled max violation: `-0.1354545233415585`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 58
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.3943375672974063, 0.7886751345948126] x [-0.7886751345948129, -0.39433756729740643]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.8471442448330055`
- midpoint sampled margin: `-0.4000300626874135`
- midpoint sampled max violation: `0.4000300626874135`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 59
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.39433756729740643, 0.0] x [0.3943375672974063, 0.7886751345948126]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.5562943287597114`
- midpoint sampled margin: `-0.1269429160125647`
- midpoint sampled max violation: `0.1269429160125647`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 60
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.2600814464859742`
- midpoint sampled margin: `0.09644566253489473`
- midpoint sampled max violation: `-0.09644566253489473`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 61
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.39433756729740643, 0.0] x [0.0, 0.3943375672974063]`
- l2 translation radius: `0.2788387679126026`
- certified upper violation: `0.37222036884822596`
- midpoint sampled margin: `0.06328573969285545`
- midpoint sampled max violation: `-0.06328573969285545`
- pose drift bound: `0.5055636884418798`
- certification method: `interval`
- depth: `3`

### Box 62
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.3069701922895053`
- midpoint sampled margin: `0.09644566253489484`
- midpoint sampled max violation: `-0.09644566253489484`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.39433756729740643, 0.0] x [-0.39433756729740643, 0.0]`
- l2 translation radius: `0.27883876791260265`
- certified upper violation: `0.42798208177565455`
- midpoint sampled margin: `0.06328573969285511`
- midpoint sampled max violation: `-0.06328573969285511`
- pose drift bound: `0.5055636884418799`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[16, 32, 40]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `5.551115123125783e-17`
