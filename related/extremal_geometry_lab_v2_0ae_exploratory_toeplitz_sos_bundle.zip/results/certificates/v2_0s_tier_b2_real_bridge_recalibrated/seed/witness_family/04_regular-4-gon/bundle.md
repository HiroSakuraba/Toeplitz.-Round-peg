# Rigid-motion certificate bundle: regular-4-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `112`
- unresolved boxes: `34`
- explored boxes: `228`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.38306249063990455`
- sampled max violation: `-0.38306249063990455`
- certified upper violation: `-0.34874750804349164`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625699`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195334`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.78364594716257`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.717449219559539`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611542`
- midpoint sampled margin: `-0.17174366280069708`
- midpoint sampled max violation: `0.17174366280069708`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992574`
- midpoint sampled max violation: `0.11154055598992574`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611544`
- midpoint sampled margin: `-0.1717436628006973`
- midpoint sampled max violation: `0.1717436628006973`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788035`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978682`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978678`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880306`
- midpoint sampled margin: `-0.11154055598992574`
- midpoint sampled max violation: `0.11154055598992574`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.707841859761154`
- midpoint sampled margin: `-0.17174366280069697`
- midpoint sampled max violation: `0.17174366280069697`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595386`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992574`
- midpoint sampled max violation: `0.11154055598992574`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611547`
- midpoint sampled margin: `-0.17174366280069686`
- midpoint sampled max violation: `0.17174366280069686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195336`
- midpoint sampled margin: `-0.6533656660939391`
- midpoint sampled max violation: `0.6533656660939391`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.653365666093939`
- midpoint sampled max violation: `0.653365666093939`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625699`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195334`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.78364594716257`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.717449219559539`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611542`
- midpoint sampled margin: `-0.17174366280069708`
- midpoint sampled max violation: `0.17174366280069708`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 36
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611544`
- midpoint sampled margin: `-0.1717436628006973`
- midpoint sampled max violation: `0.1717436628006973`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 38
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788035`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 40
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978682`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978678`
- midpoint sampled margin: `-0.778716088617589`
- midpoint sampled max violation: `0.778716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880306`
- midpoint sampled margin: `-0.11154055598992563`
- midpoint sampled max violation: `0.11154055598992563`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611538`
- midpoint sampled margin: `-0.17174366280069697`
- midpoint sampled max violation: `0.17174366280069697`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 45
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595386`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 47
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 49
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992563`
- midpoint sampled max violation: `0.11154055598992563`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611547`
- midpoint sampled margin: `-0.17174366280069686`
- midpoint sampled max violation: `0.17174366280069686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195336`
- midpoint sampled margin: `-0.6533656660939391`
- midpoint sampled max violation: `0.6533656660939391`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.653365666093939`
- midpoint sampled max violation: `0.653365666093939`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625699`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195334`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.78364594716257`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.717449219559539`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611542`
- midpoint sampled margin: `-0.17174366280069708`
- midpoint sampled max violation: `0.17174366280069708`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611544`
- midpoint sampled margin: `-0.1717436628006973`
- midpoint sampled max violation: `0.1717436628006973`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 66
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880373`
- midpoint sampled margin: `-0.1115405559899254`
- midpoint sampled max violation: `0.1115405559899254`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 67
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 68
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978682`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978678`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880306`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 72
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611538`
- midpoint sampled margin: `-0.17174366280069697`
- midpoint sampled max violation: `0.17174366280069697`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 73
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 74
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.7174492195595386`
- midpoint sampled margin: `-0.3980863165312132`
- midpoint sampled max violation: `0.3980863165312132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 75
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 76
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992563`
- midpoint sampled max violation: `0.11154055598992563`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.7078418597611547`
- midpoint sampled margin: `-0.29904055598992574`
- midpoint sampled max violation: `0.29904055598992574`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 79
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 81
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195336`
- midpoint sampled margin: `-0.6533656660939391`
- midpoint sampled max violation: `0.6533656660939391`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 82
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.653365666093939`
- midpoint sampled max violation: `0.653365666093939`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 83
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625699`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195334`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.6533656660939392`
- midpoint sampled max violation: `0.6533656660939392`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 87
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.78364594716257`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 88
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.717449219559539`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 90
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611542`
- midpoint sampled margin: `-0.17174366280069708`
- midpoint sampled max violation: `0.17174366280069708`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 92
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992574`
- midpoint sampled max violation: `0.11154055598992574`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611544`
- midpoint sampled margin: `-0.1717436628006973`
- midpoint sampled max violation: `0.1717436628006973`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 94
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880373`
- midpoint sampled margin: `-0.1115405559899253`
- midpoint sampled max violation: `0.1115405559899253`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 96
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 97
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978687`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 98
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.3669682723978678`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 99
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.49950302237880306`
- midpoint sampled margin: `-0.11154055598992552`
- midpoint sampled max violation: `0.11154055598992552`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 100
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611538`
- midpoint sampled margin: `-0.17174366280069697`
- midpoint sampled max violation: `0.17174366280069697`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 101
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 102
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595386`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 103
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 104
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7174492195595392`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 105
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4995030223788033`
- midpoint sampled margin: `-0.11154055598992563`
- midpoint sampled max violation: `0.11154055598992563`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 106
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7078418597611547`
- midpoint sampled margin: `-0.17174366280069686`
- midpoint sampled max violation: `0.17174366280069686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 107
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.366968272397868`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 108
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 109
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.2494795221195336`
- midpoint sampled margin: `-0.6533656660939391`
- midpoint sampled max violation: `0.6533656660939391`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 110
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.249479522119534`
- midpoint sampled margin: `-0.653365666093939`
- midpoint sampled max violation: `0.653365666093939`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 111
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.7836459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963878`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.2132189704292392`
- midpoint sampled max violation: `-0.2132189704292392`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963856`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963878`
- midpoint sampled margin: `0.21321897042923899`
- midpoint sampled max violation: `-0.21321897042923899`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.2132189704292392`
- midpoint sampled max violation: `-0.2132189704292392`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963856`
- midpoint sampled margin: `0.21321897042923887`
- midpoint sampled max violation: `-0.21321897042923887`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963878`
- midpoint sampled margin: `0.21321897042923899`
- midpoint sampled max violation: `-0.21321897042923899`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.2132189704292392`
- midpoint sampled max violation: `-0.2132189704292392`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963856`
- midpoint sampled margin: `0.21321897042923899`
- midpoint sampled max violation: `-0.21321897042923899`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.41035499654368723`
- midpoint sampled margin: `-0.15841436247120477`
- midpoint sampled max violation: `0.15841436247120477`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.4103549965436868`
- midpoint sampled margin: `-0.15841436247120477`
- midpoint sampled max violation: `0.15841436247120477`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963878`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.21321897042923932`
- midpoint sampled max violation: `-0.21321897042923932`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.17474349595963856`
- midpoint sampled margin: `0.21321897042923899`
- midpoint sampled max violation: `-0.21321897042923899`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 32
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 33
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.174743495959639`
- midpoint sampled margin: `0.21321897042923876`
- midpoint sampled max violation: `-0.21321897042923876`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 32]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
