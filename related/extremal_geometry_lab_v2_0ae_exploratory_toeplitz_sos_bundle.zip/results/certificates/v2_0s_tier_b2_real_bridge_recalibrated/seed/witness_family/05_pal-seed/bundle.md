# Rigid-motion certificate bundle: pal-seed in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `112`
- unresolved boxes: `32`
- explored boxes: `224`

## Best midpoint pose found during refinement
- rotation: `0.0`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.43301270189221935`
- sampled max violation: `-0.43301270189221935`
- certified upper violation: `-0.30582875782181773`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625699`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769677`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396258`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.933165000000899`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791457`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799131`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603466`
- midpoint sampled margin: `-0.20192388889036927`
- midpoint sampled max violation: `0.20192388889036927`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 8
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779957`
- midpoint sampled margin: `-0.17680365209995152`
- midpoint sampled max violation: `0.17680365209995152`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491697`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 10
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668188`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066592`
- midpoint sampled margin: `-0.2019238888903686`
- midpoint sampled max violation: `0.2019238888903686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 12
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5810156423243082`
- midpoint sampled margin: `-0.17680365209995108`
- midpoint sampled max violation: `0.17680365209995108`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5164873252361977`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5164873252361968`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668183`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491693`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 17
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5810156423243078`
- midpoint sampled margin: `-0.1768036520999514`
- midpoint sampled max violation: `0.1768036520999514`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066583`
- midpoint sampled margin: `-0.20192388889036916`
- midpoint sampled max violation: `0.20192388889036916`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 19
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799125`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 21
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779957`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.837645539660347`
- midpoint sampled margin: `-0.20192388889036927`
- midpoint sampled max violation: `0.20192388889036927`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 23
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791461`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008982`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396256`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769673`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008989`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396252`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769677`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.90864594716257`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.516487325236197`
- midpoint sampled margin: `-0.7787160886175891`
- midpoint sampled max violation: `0.7787160886175891`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.789354479706659`
- midpoint sampled margin: `-0.20192388889036905`
- midpoint sampled max violation: `0.20192388889036905`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 34
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.581015642324308`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 35
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491695`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 36
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668186`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 37
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.837645539660347`
- midpoint sampled margin: `-0.2019238888903686`
- midpoint sampled max violation: `0.2019238888903686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 38
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779963`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 39
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799121`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 40
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 41
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791448`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791453`
- midpoint sampled margin: `-0.778716088617589`
- midpoint sampled max violation: `0.778716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779955`
- midpoint sampled margin: `-0.1768036520999512`
- midpoint sampled max violation: `0.1768036520999512`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 44
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603462`
- midpoint sampled margin: `-0.20192388889036894`
- midpoint sampled max violation: `0.20192388889036894`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 45
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 46
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.727720784679913`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 47
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.581015642324308`
- midpoint sampled margin: `-0.17680365209995108`
- midpoint sampled max violation: `0.17680365209995108`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 48
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066592`
- midpoint sampled margin: `-0.20192388889036905`
- midpoint sampled max violation: `0.20192388889036905`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 49
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668186`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 50
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491697`
- midpoint sampled margin: `-0.23570655332163126`
- midpoint sampled max violation: `0.23570655332163126`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 51
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.516487325236197`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769677`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396256`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008993`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625699`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769677`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396258`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.933165000000899`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791457`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799129`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 62
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 63
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603466`
- midpoint sampled margin: `-0.20192388889036927`
- midpoint sampled max violation: `0.20192388889036927`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 64
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779957`
- midpoint sampled margin: `-0.17680365209995152`
- midpoint sampled max violation: `0.17680365209995152`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 65
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491697`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 66
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.650309217366819`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 67
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066592`
- midpoint sampled margin: `-0.2019238888903686`
- midpoint sampled max violation: `0.2019238888903686`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 68
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5810156423243082`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 69
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5164873252361977`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 70
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.5164873252361968`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 71
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668183`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 72
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.858648054749169`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 73
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5810156423243078`
- midpoint sampled margin: `-0.1768036520999514`
- midpoint sampled max violation: `0.1768036520999514`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 74
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066583`
- midpoint sampled margin: `-0.20192388889036916`
- midpoint sampled max violation: `0.20192388889036916`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 75
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771881`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 76
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799127`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 77
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779957`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 78
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603468`
- midpoint sampled margin: `-0.20192388889036927`
- midpoint sampled max violation: `0.20192388889036927`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 79
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791461`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 80
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008982`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 81
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396256`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 82
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769673`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 83
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625703`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 84
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008989`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 85
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396252`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 86
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769673`
- midpoint sampled margin: `-0.7419375093600956`
- midpoint sampled max violation: `0.7419375093600956`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 87
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.75, 1.5] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.90864594716257`
- midpoint sampled margin: `-1.1537160886175881`
- midpoint sampled max violation: `1.1537160886175881`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 88
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.516487325236197`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 89
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.789354479706659`
- midpoint sampled margin: `-0.20192388889036905`
- midpoint sampled max violation: `0.20192388889036905`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 90
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.581015642324308`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 91
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491695`
- midpoint sampled margin: `-0.23570655332163104`
- midpoint sampled max violation: `0.23570655332163104`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 92
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668186`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 93
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603468`
- midpoint sampled margin: `-0.20192388889036883`
- midpoint sampled max violation: `0.20192388889036883`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 94
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779961`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 95
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.375, 0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7277207846799121`
- midpoint sampled margin: `-0.2357065533216306`
- midpoint sampled max violation: `0.2357065533216306`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 96
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771883`
- midpoint sampled margin: `-0.2105863165312133`
- midpoint sampled max violation: `0.2105863165312133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 97
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791448`
- midpoint sampled margin: `-0.7787160886175889`
- midpoint sampled max violation: `0.7787160886175889`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 98
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4926409975791453`
- midpoint sampled margin: `-0.7787160886175888`
- midpoint sampled max violation: `0.7787160886175888`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 99
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6293067022779955`
- midpoint sampled margin: `-0.1768036520999514`
- midpoint sampled max violation: `0.1768036520999514`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 100
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8376455396603464`
- midpoint sampled margin: `-0.20192388889036916`
- midpoint sampled max violation: `0.20192388889036916`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 101
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.375, 0.75]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.5091103821771878`
- midpoint sampled margin: `-0.21058631653121318`
- midpoint sampled max violation: `0.21058631653121318`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 102
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [0.0, 0.75]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.727720784679913`
- midpoint sampled margin: `-0.23570655332163093`
- midpoint sampled max violation: `0.23570655332163093`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 103
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.581015642324308`
- midpoint sampled margin: `-0.1768036520999513`
- midpoint sampled max violation: `0.1768036520999513`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 104
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.7893544797066594`
- midpoint sampled margin: `-0.20192388889036927`
- midpoint sampled max violation: `0.20192388889036927`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 105
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.75, -0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.6503092173668186`
- midpoint sampled margin: `-0.21058631653121307`
- midpoint sampled max violation: `0.21058631653121307`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 106
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.75, -0.375] x [-0.75, 0.0]`
- l2 translation radius: `0.4192627457812106`
- certified upper violation: `0.8586480547491697`
- midpoint sampled margin: `-0.23570655332163126`
- midpoint sampled max violation: `0.23570655332163126`
- pose drift bound: `0.6156122866305727`
- certification method: `interval`
- depth: `2`

### Box 107
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.75, 0.0] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.516487325236197`
- midpoint sampled margin: `-0.7787160886175887`
- midpoint sampled max violation: `0.7787160886175887`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 108
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.75, 1.5]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9086459471625692`
- midpoint sampled margin: `-1.153716088617589`
- midpoint sampled max violation: `1.153716088617589`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 109
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [0.0, 0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4087514199769677`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 110
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-0.75, 0.0]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.4163301249396256`
- midpoint sampled margin: `-0.7419375093600954`
- midpoint sampled max violation: `0.7419375093600954`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

### Box 111
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-1.5, -0.75] x [-1.5, -0.75]`
- l2 translation radius: `0.5303300858899106`
- certified upper violation: `1.9331650000008993`
- midpoint sampled margin: `-1.1537160886175886`
- midpoint sampled max violation: `1.1537160886175886`
- pose drift bound: `0.9230291675886347`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588312`
- midpoint sampled margin: `0.1479558743192131`
- midpoint sampled max violation: `-0.1479558743192131`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3255496909476543`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25625611590514374`
- midpoint sampled margin: `0.14795587431921353`
- midpoint sampled max violation: `-0.14795587431921353`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765385`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2562561159051431`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588314`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2562561159051435`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765407`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588316`
- midpoint sampled margin: `0.14795587431921342`
- midpoint sampled max violation: `-0.14795587431921342`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.30454717585883095`
- midpoint sampled margin: `0.1479558743192133`
- midpoint sampled max violation: `-0.1479558743192133`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2562561159051435`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765407`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588312`
- midpoint sampled margin: `0.14795587431921298`
- midpoint sampled max violation: `-0.14795587431921298`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3255496909476543`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25625611590514374`
- midpoint sampled margin: `0.14795587431921342`
- midpoint sampled max violation: `-0.14795587431921342`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765385`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2562561159051431`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802357`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588312`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.2562561159051435`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765407`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.3045471758588314`
- midpoint sampled margin: `0.1479558743192132`
- midpoint sampled max violation: `-0.1479558743192132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.375] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.1843508557580238`
- midpoint sampled margin: `0.11417320988795143`
- midpoint sampled max violation: `-0.11417320988795143`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.30454717585883095`
- midpoint sampled margin: `0.1479558743192131`
- midpoint sampled max violation: `-0.1479558743192131`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [0.0, 0.375]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.18435085575802335`
- midpoint sampled margin: `0.11417320988795132`
- midpoint sampled max violation: `-0.11417320988795132`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.25625611590514374`
- midpoint sampled margin: `0.14795587431921298`
- midpoint sampled max violation: `-0.14795587431921298`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.375, 0.0] x [-0.375, 0.0]`
- l2 translation radius: `0.2651650429449553`
- certified upper violation: `0.32554969094765407`
- midpoint sampled margin: `0.11417320988795121`
- midpoint sampled max violation: `-0.11417320988795121`
- pose drift bound: `0.46151458379431737`
- certification method: `interval`
- depth: `3`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[0, 8, 24]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `0.0`
