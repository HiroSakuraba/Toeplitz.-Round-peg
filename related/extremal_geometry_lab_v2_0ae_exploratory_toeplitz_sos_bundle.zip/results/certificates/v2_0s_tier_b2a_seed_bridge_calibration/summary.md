# Extremal Geometry Lab v2.0s — Tier B2a seed-only bridge calibration

State: `seed`

Ladder:
- `L1-light`: angle_steps=24, cert_n=48, max_depth=1
- `L2-medium`: angle_steps=48, cert_n=96, max_depth=2
- `L3-real`: angle_steps=48, cert_n=96, max_depth=3
- `L4-stress`: angle_steps=64, cert_n=128, max_depth=4

## 00 `segment`
### L1-light
- runtime: `8.643` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 48, 'unresolved_boxes': 32, 'explored_boxes': 96}`
- best sampled margin: `0.4330122018922194`
- best certified upper violation: `-0.3562235554504763`
- min certified upper violation: `0.6052696110545497`

### L2-medium
- runtime: `17.519` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 64, 'unresolved_boxes': 48, 'explored_boxes': 160}`
- best sampled margin: `0.4330122018922194`
- best certified upper violation: `-0.37528173618915744`
- min certified upper violation: `0.2911650510222892`

### L3-real
- runtime: `29.569` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 96, 'unresolved_boxes': 64, 'explored_boxes': 256}`
- best sampled margin: `0.4330122018922194`
- best certified upper violation: `-0.37528173618915744`
- min certified upper violation: `0.035355748383760655`

### L4-stress
- runtime: `56.659` s
- classification: `certified_feasible`
- has_certified_feasible_box: `True`
- classification_complete: `False`
- selected_box_index: `6`
- counts: `{'certified_feasible_boxes': 16, 'certified_infeasible_boxes': 80, 'unresolved_boxes': 144, 'explored_boxes': 416}`
- best sampled margin: `0.4409601607774406`
- best certified upper violation: `-0.3792577705752126`
- min certified upper violation: `-0.017021994683756092`

## 01 `orbiform-stub`
### L1-light
- runtime: `8.503` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 48, 'unresolved_boxes': 32, 'explored_boxes': 96}`
- best sampled margin: `0.3660254037844386`
- best certified upper violation: `-0.22480593166963292`
- min certified upper violation: `0.8548219753849428`

### L2-medium
- runtime: `16.103` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 80, 'unresolved_boxes': 32, 'explored_boxes': 160}`
- best sampled margin: `0.3660254037844387`
- best certified upper violation: `-0.2520136843941162`
- min certified upper violation: `0.5773539102787382`

### L3-real
- runtime: `22.4` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 112, 'unresolved_boxes': 32, 'explored_boxes': 224}`
- best sampled margin: `0.3660254037844387`
- best certified upper violation: `-0.2520136843941162`
- min certified upper violation: `0.25259438385957367`

### L4-stress
- runtime: `36.036` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 120, 'unresolved_boxes': 64, 'explored_boxes': 304}`
- best sampled margin: `0.3660254037844387`
- best certified upper violation: `-0.26674212311811674`
- min certified upper violation: `0.18326372778582756`

## 02 `disk-half`
### L1-light
- runtime: `8.496` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 48, 'unresolved_boxes': 32, 'explored_boxes': 96}`
- best sampled margin: `0.37030297309753346`
- best certified upper violation: `-0.22908350098272756`
- min certified upper violation: `0.8616038117014319`

### L2-medium
- runtime: `15.94` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 80, 'unresolved_boxes': 32, 'explored_boxes': 160}`
- best sampled margin: `0.37030297309753346`
- best certified upper violation: `-0.2562912537072106`
- min certified upper violation: `0.5810156423243078`

### L3-real
- runtime: `22.674` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 112, 'unresolved_boxes': 32, 'explored_boxes': 224}`
- best sampled margin: `0.37030297309753346`
- best certified upper violation: `-0.2562912537072106`
- min certified upper violation: `0.2562561159051431`

### L4-stress
- runtime: `36.5` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 120, 'unresolved_boxes': 64, 'explored_boxes': 304}`
- best sampled margin: `0.37030297309753335`
- best certified upper violation: `-0.25079373569129915`
- min certified upper violation: `0.18630890783479992`

## 03 `regular-3-gon`
### L1-light
- runtime: `0.873` s
- classification: `certified_infeasible`
- has_certified_feasible_box: `False`
- classification_complete: `True`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 64, 'unresolved_boxes': 0, 'explored_boxes': 64}`
- best sampled margin: `0.3660254037844386`
- best certified upper violation: `-0.18041428571446483`
- min certified upper violation: `0.910788601003591`

### L2-medium
- runtime: `18.675` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 71, 'unresolved_boxes': 49, 'explored_boxes': 176}`
- best sampled margin: `0.3660254037844386`
- best certified upper violation: `-0.22183893486633466`
- min certified upper violation: `0.50827354039585`

### L3-real
- runtime: `29.816` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 105, 'unresolved_boxes': 64, 'explored_boxes': 274}`
- best sampled margin: `0.3660254037844386`
- best certified upper violation: `-0.22183893486633466`
- min certified upper violation: `0.26008144648597353`

### L4-stress
- runtime: `51.381` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 121, 'unresolved_boxes': 120, 'explored_boxes': 418}`
- best sampled margin: `0.3660254037844386`
- best certified upper violation: `-0.24194113837883702`
- min certified upper violation: `0.16287275036263127`

## 04 `regular-4-gon`
### L1-light
- runtime: `8.433` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 48, 'unresolved_boxes': 32, 'explored_boxes': 96}`
- best sampled margin: `0.38306249063990455`
- best certified upper violation: `-0.32968937203783677`
- min certified upper violation: `0.7721231832439377`

### L2-medium
- runtime: `17.036` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 78, 'unresolved_boxes': 34, 'explored_boxes': 160}`
- best sampled margin: `0.38306249063990455`
- best certified upper violation: `-0.34874750804349164`
- min certified upper violation: `0.49950302237880306`

### L3-real
- runtime: `24.396` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 112, 'unresolved_boxes': 34, 'explored_boxes': 228}`
- best sampled margin: `0.38306249063990455`
- best certified upper violation: `-0.34874750804349164`
- min certified upper violation: `0.17474349595963856`

### L4-stress
- runtime: `66.81` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 104, 'unresolved_boxes': 168, 'explored_boxes': 480}`
- best sampled margin: `0.4034510964822505`
- best certified upper violation: `-0.35833088189768575`
- min certified upper violation: `0.1067410253769967`

## 05 `pal-seed`
### L1-light
- runtime: `8.209` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 48, 'unresolved_boxes': 32, 'explored_boxes': 96}`
- best sampled margin: `0.43301270189221935`
- best certified upper violation: `-0.2674006532374622`
- min certified upper violation: `0.8021240143429071`

### L2-medium
- runtime: `15.787` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 80, 'unresolved_boxes': 32, 'explored_boxes': 160}`
- best sampled margin: `0.43301270189221935`
- best certified upper violation: `-0.30582875782181773`
- min certified upper violation: `0.5091103821771878`

### L3-real
- runtime: `22.181` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 112, 'unresolved_boxes': 32, 'explored_boxes': 224}`
- best sampled margin: `0.43301270189221935`
- best certified upper violation: `-0.30582875782181773`
- min certified upper violation: `0.18435085575802335`

### L4-stress
- runtime: `34.694` s
- classification: `incomplete`
- has_certified_feasible_box: `False`
- classification_complete: `False`
- selected_box_index: `None`
- counts: `{'certified_feasible_boxes': 0, 'certified_infeasible_boxes': 112, 'unresolved_boxes': 64, 'explored_boxes': 288}`
- best sampled margin: `0.43301270189221924`
- best certified upper violation: `-0.31165870408526897`
- min certified upper violation: `0.16361447833694787`

## Summary
- witness_count: `6`
- total_refinement_runs: `24`
- any_certified_feasible: `True`
- witnesses_with_any_feasible: `['segment']`
- witnesses_always_incomplete: `['orbiform-stub', 'disk-half', 'regular-4-gon', 'pal-seed']`
- total_runtime_sec: `577.333`