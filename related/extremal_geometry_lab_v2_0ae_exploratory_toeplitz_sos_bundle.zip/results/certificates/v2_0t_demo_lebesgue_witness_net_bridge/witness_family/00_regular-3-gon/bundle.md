# Rigid-motion certificate bundle: regular-3-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `0`
- certified infeasible boxes: `16`
- unresolved boxes: `0`
- explored boxes: `16`

## Best midpoint pose found during refinement
- rotation: `4.71238898038469`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.3660254037844386`
- sampled max violation: `-0.3660254037844386`
- certified upper violation: `None`

## Certified feasible boxes

- none

## Certified infeasible boxes

### Box 0
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.22757216485162535] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.25593106019557443`
- midpoint sampled margin: `0.15291318876846305`
- midpoint sampled max violation: `-0.15291318876846305`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[0.0, 0.22757216485162535] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.08328132938520028`
- midpoint sampled margin: `0.1529131887684635`
- midpoint sampled max violation: `-0.1529131887684635`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.22757216485162535, 0.0] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.2276188966826065`
- midpoint sampled margin: `0.19456178553342063`
- midpoint sampled max violation: `-0.19456178553342063`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[4.71238898038469, 0.0]`
- translation box: `[-0.22757216485162535, 0.0] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.1873349911785338`
- midpoint sampled margin: `0.19456178553342063`
- midpoint sampled max violation: `-0.19456178553342063`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.22757216485162535] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.2276188966826067`
- midpoint sampled margin: `0.19456178553342074`
- midpoint sampled max violation: `-0.19456178553342074`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[0.0, 0.22757216485162535] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.18733499117853425`
- midpoint sampled margin: `0.19456178553342074`
- midpoint sampled max violation: `-0.19456178553342074`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.22757216485162535, 0.0] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.25593106019557443`
- midpoint sampled margin: `0.15291318876846338`
- midpoint sampled max violation: `-0.15291318876846338`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[3.141592653589793, 4.71238898038469]`
- translation box: `[-0.22757216485162535, 0.0] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.08328132938520028`
- midpoint sampled margin: `0.15291318876846305`
- midpoint sampled max violation: `-0.15291318876846305`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.22757216485162535] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.18733499117853403`
- midpoint sampled margin: `0.19456178553342063`
- midpoint sampled max violation: `-0.19456178553342063`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[0.0, 0.22757216485162535] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.22761889668260704`
- midpoint sampled margin: `0.19456178553342063`
- midpoint sampled max violation: `-0.19456178553342063`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.22757216485162535, 0.0] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.08328132938519994`
- midpoint sampled margin: `0.15291318876846327`
- midpoint sampled max violation: `-0.15291318876846327`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[1.5707963267948966, 3.141592653589793]`
- translation box: `[-0.22757216485162535, 0.0] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.25593106019557443`
- midpoint sampled margin: `0.15291318876846327`
- midpoint sampled max violation: `-0.15291318876846327`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.22757216485162535] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.08328132938520028`
- midpoint sampled margin: `0.15291318876846305`
- midpoint sampled max violation: `-0.15291318876846305`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[0.0, 0.22757216485162535] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.25593106019557477`
- midpoint sampled margin: `0.1529131887684635`
- midpoint sampled max violation: `-0.1529131887684635`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.22757216485162535, 0.0] x [0.0, 0.22757216485162535]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.18733499117853392`
- midpoint sampled margin: `0.19456178553342074`
- midpoint sampled max violation: `-0.19456178553342074`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[0.0, 1.5707963267948966]`
- translation box: `[-0.22757216485162535, 0.0] x [-0.22757216485162535, 0.0]`
- l2 translation radius: `0.16091782097588717`
- certified upper violation: `0.2276188966826067`
- midpoint sampled margin: `0.19456178553342074`
- midpoint sampled max violation: `-0.19456178553342074`
- pose drift bound: `0.6143676620344417`
- certification method: `interval`
- depth: `0`

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[8, 16, 20]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `5.551115123125783e-17`
