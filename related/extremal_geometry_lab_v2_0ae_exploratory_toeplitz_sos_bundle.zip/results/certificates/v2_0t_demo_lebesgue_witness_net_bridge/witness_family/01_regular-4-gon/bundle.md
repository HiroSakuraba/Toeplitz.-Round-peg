# Rigid-motion certificate bundle: regular-4-gon in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `False`
- certified feasible boxes: `0`
- certified infeasible boxes: `0`
- unresolved boxes: `32`
- explored boxes: `48`

## Best midpoint pose found during refinement
- rotation: `5.497787143782138`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.38306249063990455`
- sampled max violation: `-0.38306249063990455`
- certified upper violation: `None`

## Certified feasible boxes

- none

## Certified infeasible boxes

- none

## Unresolved boxes

### Box 0
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 1
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 2
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 3
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.14277396335612602`
- midpoint sampled max violation: `-0.14277396335612602`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 4
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.1573222934106877`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 5
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378235`
- midpoint sampled margin: `0.1427739633561259`
- midpoint sampled max violation: `-0.1427739633561259`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 6
- theta interval: `[5.497787143782138, 0.0]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378268`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 7
- theta interval: `[4.71238898038469, 5.497787143782138]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068793`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 8
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 9
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225084`
- midpoint sampled max violation: `-0.23752284220225084`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 10
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 11
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.14277396335612602`
- midpoint sampled max violation: `-0.14277396335612602`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 12
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.1573222934106876`
- midpoint sampled margin: `0.23752284220225106`
- midpoint sampled max violation: `-0.23752284220225106`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 13
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378235`
- midpoint sampled margin: `0.1427739633561259`
- midpoint sampled max violation: `-0.1427739633561259`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 14
- theta interval: `[3.9269908169872414, 4.71238898038469]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378268`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 15
- theta interval: `[3.141592653589793, 3.9269908169872414]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068793`
- midpoint sampled margin: `0.23752284220225084`
- midpoint sampled max violation: `-0.23752284220225084`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 16
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378268`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 17
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225084`
- midpoint sampled max violation: `-0.23752284220225084`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 18
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 19
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.14277396335612602`
- midpoint sampled max violation: `-0.14277396335612602`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 20
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068749`
- midpoint sampled margin: `0.23752284220225084`
- midpoint sampled max violation: `-0.23752284220225084`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 21
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378235`
- midpoint sampled margin: `0.1427739633561259`
- midpoint sampled max violation: `-0.1427739633561259`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 22
- theta interval: `[2.356194490192345, 3.141592653589793]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378268`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 23
- theta interval: `[1.5707963267948966, 2.356194490192345]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068793`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 24
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 25
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3331255906530889] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 26
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068782`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 27
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[0.0, 0.3331255906530889] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378257`
- midpoint sampled margin: `0.14277396335612602`
- midpoint sampled max violation: `-0.14277396335612602`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 28
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068749`
- midpoint sampled margin: `0.23752284220225084`
- midpoint sampled max violation: `-0.23752284220225084`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 29
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.3331255906530889, 0.0] x [0.0, 0.3331255906530889]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378235`
- midpoint sampled margin: `0.1427739633561259`
- midpoint sampled max violation: `-0.1427739633561259`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 30
- theta interval: `[0.7853981633974483, 1.5707963267948966]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.16159986272378268`
- midpoint sampled margin: `0.1427739633561258`
- midpoint sampled max violation: `-0.1427739633561258`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

### Box 31
- theta interval: `[0.0, 0.7853981633974483]`
- translation box: `[-0.3331255906530889, 0.0] x [-0.3331255906530889, 0.0]`
- l2 translation radius: `0.23555536413757314`
- certified upper violation: `0.15732229341068793`
- midpoint sampled margin: `0.23752284220225095`
- midpoint sampled max violation: `-0.23752284220225095`
- pose drift bound: `0.43190490498693523`
- certification method: `interval`
- depth: `1`

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `5.551115123125783e-17`
- max global violation: `0.0`
