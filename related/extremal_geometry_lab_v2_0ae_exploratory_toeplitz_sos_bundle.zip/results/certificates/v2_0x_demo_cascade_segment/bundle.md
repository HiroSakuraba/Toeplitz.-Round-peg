# Rigid-motion certificate bundle: segment in pal-seed

## Summary
- schema: `rigid-motion-refinement.v1`
- classification complete: `True`
- certified feasible boxes: `64`
- certified infeasible boxes: `0`
- unresolved boxes: `0`
- explored boxes: `64`

## Best midpoint pose found during refinement
- rotation: `1.5707963267948966`
- translation: `(-0.0, -0.0)`
- sampled margin: `0.4330122018922194`
- sampled max violation: `-0.4330122018922194`
- certified upper violation: `None`

## Cascade provenance

- stage count: `1`
- priority hypothesis: `sticky=locked-contact-search-side`
- witness priority score: `1.5`

### Stage 0 — light
- seed source: `rotation-refinement`
- input seed boxes: `4`
- input theta seeds: `4`
- output counts: `{'certified_feasible_boxes': 64, 'certified_infeasible_boxes': 0, 'unresolved_boxes': 0, 'explored_boxes': 64}`
- promoted: `False` (final-stage)

## Certified feasible boxes

### Box 0
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874768`
- midpoint sampled margin: `0.32767919606734297`
- midpoint sampled max violation: `-0.32767919606734297`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 1
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.37219816262467453`
- midpoint sampled max violation: `-0.37219816262467453`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 2
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.22258134310607958`
- midpoint sampled margin: `0.3721981626246746`
- midpoint sampled max violation: `-0.3721981626246746`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 3
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.1780623765487479`
- midpoint sampled margin: `0.32767919606734297`
- midpoint sampled max violation: `-0.32767919606734297`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 4
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201353006`
- midpoint sampled margin: `0.35338223339326236`
- midpoint sampled max violation: `-0.35338223339326236`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 5
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2538753785708616`
- midpoint sampled margin: `0.3979011999505939`
- midpoint sampled max violation: `-0.3979011999505939`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 6
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.051406074651838725, 0.0] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25387537857086184`
- midpoint sampled margin: `0.3979011999505939`
- midpoint sampled max violation: `-0.3979011999505939`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 7
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[-0.051406074651838725, 0.0] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201353017`
- midpoint sampled margin: `0.35338223339326236`
- midpoint sampled max violation: `-0.35338223339326236`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 8
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.0, 0.05140607465183873] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.20935641201352984`
- midpoint sampled margin: `0.35338223339326236`
- midpoint sampled max violation: `-0.35338223339326236`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 9
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.0, 0.05140607465183873] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.2538753785708615`
- midpoint sampled margin: `0.397901199950594`
- midpoint sampled max violation: `-0.397901199950594`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 10
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.0, 0.05140607465183873] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.2538753785708616`
- midpoint sampled margin: `0.3979011999505938`
- midpoint sampled max violation: `-0.3979011999505938`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 11
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.0, 0.05140607465183873] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201352995`
- midpoint sampled margin: `0.35338223339326225`
- midpoint sampled max violation: `-0.35338223339326225`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 12
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874757`
- midpoint sampled margin: `0.32767919606734297`
- midpoint sampled max violation: `-0.32767919606734297`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 13
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.37219816262467464`
- midpoint sampled max violation: `-0.37219816262467464`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 14
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.3721981626246745`
- midpoint sampled max violation: `-0.3721981626246745`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 15
- theta interval: `[3.9269908169872414, 5.497787143782138]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874768`
- midpoint sampled margin: `0.32767919606734286`
- midpoint sampled max violation: `-0.32767919606734286`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 16
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670384`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 17
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 18
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.22685890386403573`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 19
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670406`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 20
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2136339727714861`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 21
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2581529393288178`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 22
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.051406074651838725, 0.0] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.258152939328818`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 23
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[-0.051406074651838725, 0.0] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.21363397277148632`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 24
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.0, 0.05140607465183873] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.213633972771486`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 25
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.0, 0.05140607465183873] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25815293932881767`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 26
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.0, 0.05140607465183873] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25815293932881767`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 27
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.0, 0.05140607465183873] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2136339727714861`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 28
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670373`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 29
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 30
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 31
- theta interval: `[2.356194490192345, 3.9269908169872414]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670384`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 32
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874768`
- midpoint sampled margin: `0.32767919606734297`
- midpoint sampled max violation: `-0.32767919606734297`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 33
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.37219816262467464`
- midpoint sampled max violation: `-0.37219816262467464`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 34
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.22258134310607958`
- midpoint sampled margin: `0.37219816262467453`
- midpoint sampled max violation: `-0.37219816262467453`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 35
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.1780623765487479`
- midpoint sampled margin: `0.32767919606734286`
- midpoint sampled max violation: `-0.32767919606734286`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 36
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201353006`
- midpoint sampled margin: `0.35338223339326236`
- midpoint sampled max violation: `-0.35338223339326236`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 37
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2538753785708616`
- midpoint sampled margin: `0.39790119995059403`
- midpoint sampled max violation: `-0.39790119995059403`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 38
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.051406074651838725, 0.0] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25387537857086184`
- midpoint sampled margin: `0.3979011999505939`
- midpoint sampled max violation: `-0.3979011999505939`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 39
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[-0.051406074651838725, 0.0] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201353017`
- midpoint sampled margin: `0.35338223339326225`
- midpoint sampled max violation: `-0.35338223339326225`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 40
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.0, 0.05140607465183873] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.20935641201352984`
- midpoint sampled margin: `0.35338223339326225`
- midpoint sampled max violation: `-0.35338223339326225`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 41
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.0, 0.05140607465183873] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.2538753785708615`
- midpoint sampled margin: `0.3979011999505939`
- midpoint sampled max violation: `-0.3979011999505939`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 42
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.0, 0.05140607465183873] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.2538753785708616`
- midpoint sampled margin: `0.3979011999505939`
- midpoint sampled max violation: `-0.3979011999505939`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 43
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.0, 0.05140607465183873] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.20935641201352995`
- midpoint sampled margin: `0.35338223339326225`
- midpoint sampled max violation: `-0.35338223339326225`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 44
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874757`
- midpoint sampled margin: `0.32767919606734297`
- midpoint sampled max violation: `-0.32767919606734297`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 45
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.3721981626246746`
- midpoint sampled max violation: `-0.3721981626246746`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 46
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.22258134310607924`
- midpoint sampled margin: `0.37219816262467453`
- midpoint sampled max violation: `-0.37219816262467453`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 47
- theta interval: `[0.7853981633974483, 2.356194490192345]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.17806237654874768`
- midpoint sampled margin: `0.32767919606734286`
- midpoint sampled max violation: `-0.32767919606734286`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 48
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670384`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 49
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 50
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.22685890386403573`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 51
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.10281214930367745, -0.051406074651838725] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670406`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 52
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2136339727714861`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 53
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.051406074651838725, 0.0] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2581529393288178`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 54
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.051406074651838725, 0.0] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.258152939328818`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 55
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[-0.051406074651838725, 0.0] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.21363397277148632`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 56
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.0, 0.05140607465183873] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.213633972771486`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 57
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.0, 0.05140607465183873] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25815293932881767`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 58
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.0, 0.05140607465183873] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.036349583980497056`
- certified upper violation: `-0.25815293932881767`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 59
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.0, 0.05140607465183873] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2136339727714861`
- midpoint sampled margin: `0.3403223664585193`
- midpoint sampled max violation: `-0.3403223664585193`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 60
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.10281214930367745, -0.051406074651838725]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670373`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 61
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [-0.051406074651838725, 0.0]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 62
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.0, 0.05140607465183873]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.2268589038640354`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

### Box 63
- theta interval: `[5.497787143782138, 0.7853981633974483]`
- translation box: `[0.05140607465183873, 0.10281214930367745] x [0.05140607465183873, 0.10281214930367745]`
- l2 translation radius: `0.03634958398049705`
- certified upper violation: `-0.18233993730670384`
- midpoint sampled margin: `0.28891629180668066`
- midpoint sampled max violation: `-0.28891629180668066`
- pose drift bound: `0.42904866568000655`
- certification method: `interval`
- depth: `0`

## Certified infeasible boxes

- none

## Unresolved boxes

- none

## Minimal active-contact certificate for best pose

- contact cardinality: `3`
- active indices: `[4, 8, 16]`
- verification method: `algebraic-solve`
- max active equality residual: `0.0`
- max global violation: `1.1102230246251565e-16`

## Support-cell audit for exported box
- schema: `support-cell-bounds.v1`
- support cells: `48`
- cell width: `0.1308996938995747`
- max cell upper violation: `-0.17806237654874768`

### Worst cells

- cell 31: upper violation `-0.17806237654874768`, direction interval `[4.057890510886816, 4.1887902047863905]`, container method `interval`, witness method `interval`
- cell 32: upper violation `-0.21963232277161127`, direction interval `[4.1887902047863905, 4.319689898685965]`, container method `interval`, witness method `interval`
- cell 30: upper violation `-0.22648972292535485`, direction interval `[3.926990816987241, 4.057890510886816]`, container method `interval`, witness method `interval`
- cell 29: upper violation `-0.2624866201665671`, direction interval `[3.7960911230876664, 3.926990816987241]`, container method `interval`, witness method `interval`
- cell 40: upper violation `-0.2663534848042315`, direction interval `[5.235987755982988, 5.3668874498825625]`, container method `interval`, witness method `interval`
- cell 33: upper violation `-0.2852251921786808`, direction interval `[4.319689898685965, 4.45058959258554]`, container method `interval`, witness method `interval`
- cell 28: upper violation `-0.289714712138317`, direction interval `[3.665191429188092, 3.7960911230876664]`, container method `interval`, witness method `interval`
- cell 39: upper violation `-0.29071065051563205`, direction interval `[5.105088062083413, 5.235987755982988]`, container method `interval`, witness method `interval`
- cell 16: upper violation `-0.307883490699708`, direction interval `[2.0943951023931953, 2.22529479629277]`, container method `interval`, witness method `interval`
- cell 27: upper violation `-0.31198568795100967`, direction interval `[3.534291735288517, 3.665191429188092]`, container method `interval`, witness method `interval`

## Independent verification
- the machine payload includes `self_verifying_certificate` with the exact box, geometry payload when available, and a replay algorithm summary.
