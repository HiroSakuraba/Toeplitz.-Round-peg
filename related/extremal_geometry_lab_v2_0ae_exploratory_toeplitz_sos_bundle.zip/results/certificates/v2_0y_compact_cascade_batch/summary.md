# Extremal Geometry Lab v2.0y — compact cascade batch

## Seed witness ladder

### 00 `segment`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.713` s
- first_feasible_stage: `light`

### 01 `orbiform-stub`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.644` s
- first_feasible_stage: `light`

### 02 `disk-half`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.677` s
- first_feasible_stage: `light`

### 03 `regular-3-gon`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.596` s
- first_feasible_stage: `light`

### 04 `regular-4-gon`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.591` s
- first_feasible_stage: `light`

### 05 `pal-seed`
- `light`: class=`certified_feasible`, feasible=`True`, explored=`4`, runtime=`0.605` s
- first_feasible_stage: `light`

## Anisotropic comparisons

### `seed` / `regular-3-gon` / `real`
- off: class=`certified_feasible`, explored=`4`, runtime=`1.392` s
- explicit: class=`certified_feasible`, explored=`4`, runtime=`1.39` s
- explored_box_delta_explicit_minus_off: `0`

### `seed` / `pal-seed` / `real`
- off: class=`certified_feasible`, explored=`4`, runtime=`1.398` s
- explicit: class=`certified_feasible`, explored=`4`, runtime=`1.423` s
- explored_box_delta_explicit_minus_off: `0`

### `moderate-cut` / `segment` / `light`
- off: class=`certified_feasible`, explored=`4`, runtime=`0.606` s
- explicit: class=`certified_feasible`, explored=`4`, runtime=`0.599` s
- explored_box_delta_explicit_minus_off: `0`

## Summary
- first_feasible_stage_by_witness: `{'segment': 'light', 'orbiform-stub': 'light', 'disk-half': 'light', 'regular-3-gon': 'light', 'regular-4-gon': 'light', 'pal-seed': 'light'}`
- total_runtime_sec: `10.634`