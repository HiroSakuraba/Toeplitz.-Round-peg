# Initial Project Note

This scaffold encodes the revised geometry roadmap:

1. Lebesgue first,
2. Moser second,
3. restricted Hadwiger third.

The repository is intentionally split so that theorem-facing claims can only depend on certified outputs and symbolic reductions.
