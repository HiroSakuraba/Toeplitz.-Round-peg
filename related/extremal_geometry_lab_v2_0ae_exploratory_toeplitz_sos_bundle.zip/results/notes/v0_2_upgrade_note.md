
# v0.2 upgrade note

This revision turns the original scaffold into a coherent proof-oriented API.

Highlights:
- added shape algebra types and polygon/polyline support
- added 2D convex Minkowski sum and buffer operations
- added rigid-fit, rigidity, and certificate modules with basic interoperability
- added domain-level witness and candidate family stubs for all three target problems
- added richer smoke tests and unit tests
