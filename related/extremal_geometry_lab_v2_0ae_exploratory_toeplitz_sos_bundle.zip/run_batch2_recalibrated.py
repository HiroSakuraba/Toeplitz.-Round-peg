from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from zipfile import ZipFile

ROOT = Path('/mnt/data/batch2repo')
sys.path.insert(0, str(ROOT / 'packages'))

from extremal_geometry_lab.domains.lebesgue import (
    pal_seed,
    moves,
    build_polygon_witness_net_scaffold,
    export_candidate_witness_net_bundle,
    search_with_width_prescreen,
)
from extremal_geometry_lab.search import proposals_at_depth

OUTDIR = ROOT / 'results/certificates/v2_0s_tier_b2_real_bridge_recalibrated'
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
REFINE_KWARGS = {
    'angle_steps': 48,
    'cert_n': 96,
    'initial_theta_intervals': 4,
    'initial_translation_intervals': 4,
    'max_depth': 3,
}
SEARCH_PARAMS = dict(
    depth=3,
    beam_width=6,
    beam_policy='diversified',
    beam_diversity_reserve=2,
    n=512,
    targeted_move_limit=2,
    include_rejected=True,
)

def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(f'move not available: {label}')


def _targeted_state() -> tuple[str, dict, list[str]]:
    props = search_with_width_prescreen(structure_signal='witness-net', **SEARCH_PARAMS)
    final = proposals_at_depth(props, SEARCH_PARAMS['depth'])
    targeted = [p for p in final if any(str(m).startswith('targeted-') for m in p.move_history)]
    if not targeted:
        raise RuntimeError('no targeted final-state survivor found in Tier B1 witness-net run')
    targeted.sort(key=lambda p: ('targeted-square-rounding' not in p.move_history, tuple(p.move_history)))
    chosen = targeted[0]
    return ('targeted-descendant', chosen.state, list(chosen.move_history))


def _state_specs() -> list[tuple[str, dict, list[str] | None]]:
    seed = pal_seed()
    mild = _apply_move(seed, 'small-corner-cut')
    moderate = _apply_move(seed, 'medium-corner-cut')
    rounded = _apply_move(seed, 'small-arc-rounding')
    targeted_name, targeted_state, targeted_hist = _targeted_state()
    return [
        ('seed', seed, None),
        ('mild-cut', mild, ['small-corner-cut']),
        ('moderate-cut', moderate, ['medium-corner-cut']),
        ('rounded', rounded, ['small-arc-rounding']),
        (targeted_name, targeted_state, targeted_hist),
    ]


def _best_metrics(witnesses: list[dict]) -> tuple[float | None, float | None]:
    upper_vals = []
    margin_vals = []
    for rec in witnesses:
        val = rec.get('best_certified_upper_violation')
        if isinstance(val, (int, float)):
            upper_vals.append(float(val))
        val2 = rec.get('best_margin_estimate')
        if isinstance(val2, (int, float)):
            margin_vals.append(float(val2))
    return (min(upper_vals) if upper_vals else None, max(margin_vals) if margin_vals else None)


def _summarize_state(name: str, state: dict, move_history: list[str] | None) -> dict:
    state_dir = OUTDIR / name
    print(f'[b2-recal] exporting {name}...', flush=True)
    start = time.perf_counter()
    machine = export_candidate_witness_net_bundle(
        state_dir,
        state=state,
        net=NET,
        refine_kwargs=REFINE_KWARGS,
        state_name=name,
    )
    runtime = time.perf_counter() - start
    witnesses = machine.get('witnesses', [])
    passed = int(machine.get('passed_witness_count', 0))
    failed = int(machine.get('failed_witness_count', 0))
    incomplete = sum(1 for rec in witnesses if not rec.get('classification_complete', False))
    selected = sum(1 for rec in witnesses if rec.get('selected_box_index') is not None)
    best_upper, best_margin = _best_metrics(witnesses)
    summary = {
        'state_name': name,
        'runtime_sec': round(runtime, 3),
        'move_history': move_history,
        'joint_certified': bool(machine.get('joint_certified')),
        'passed_witness_count': passed,
        'failed_witness_count': failed,
        'classification_incomplete_count': incomplete,
        'selected_box_count': selected,
        'witness_count': int(machine.get('witness_count', len(witnesses))),
        'min_best_certified_upper_violation': None if best_upper is None else round(best_upper, 9),
        'max_best_margin_estimate': None if best_margin is None else round(best_margin, 9),
        'output_dir': str(state_dir),
    }
    print(
        f"[b2-recal] done {name}: runtime={summary['runtime_sec']}s passed={summary['passed_witness_count']}/{summary['witness_count']} incomplete={summary['classification_incomplete_count']}",
        flush=True,
    )
    return summary


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    specs = _state_specs()
    runs = [_summarize_state(name, state, hist) for name, state, hist in specs]
    payload = {
        'batch': 'Tier B2 real bridge/export pass (recalibrated)',
        'parameters': {
            'representative_states': [name for name, _, _ in specs],
            'max_vertices': 4,
            'refine_kwargs': REFINE_KWARGS,
        },
        'runs': runs,
        'all_joint_certified': all(run['joint_certified'] for run in runs),
        'any_witness_certified': any(run['passed_witness_count'] > 0 for run in runs),
        'all_exports_completed': True,
        'total_runtime_sec': round(sum(run['runtime_sec'] for run in runs), 3),
    }
    lines = [
        '# Extremal Geometry Lab v2.0s — Tier B2 real bridge/export run (recalibrated)',
        '',
        'Representative states:',
    ]
    for name in payload['parameters']['representative_states']:
        lines.append(f'- `{name}`')
    lines += [
        '',
        f"- max_vertices: `{payload['parameters']['max_vertices']}`",
        f"- refine_kwargs: `{payload['parameters']['refine_kwargs']}`",
        '',
    ]
    for run in runs:
        lines.append(f"## {run['state_name']}")
        lines.append(f"- runtime: `{run['runtime_sec']}` s")
        lines.append(f"- move_history: `{run['move_history']}`")
        lines.append(f"- joint_certified: `{run['joint_certified']}`")
        lines.append(f"- passed_witness_count: `{run['passed_witness_count']}` / `{run['witness_count']}`")
        lines.append(f"- failed_witness_count: `{run['failed_witness_count']}`")
        lines.append(f"- classification_incomplete_count: `{run['classification_incomplete_count']}`")
        lines.append(f"- selected_box_count: `{run['selected_box_count']}`")
        lines.append(f"- min_best_certified_upper_violation: `{run['min_best_certified_upper_violation']}`")
        lines.append(f"- max_best_margin_estimate: `{run['max_best_margin_estimate']}`")
        lines.append(f"- output_dir: `{run['output_dir']}`")
        lines.append('')
    lines.append('## Batch result')
    lines.append(f"- all_exports_completed: `{payload['all_exports_completed']}`")
    lines.append(f"- any_witness_certified: `{payload['any_witness_certified']}`")
    lines.append(f"- all_joint_certified: `{payload['all_joint_certified']}`")
    lines.append(f"- total_runtime_sec: `{payload['total_runtime_sec']}`")

    (OUTDIR / 'summary.json').write_text(json.dumps(payload, indent=2))
    (OUTDIR / 'summary.md').write_text('\n'.join(lines))

    md_copy = Path('/mnt/data/extremal_geometry_lab_v2_0s_batch2_run_recalibrated.md')
    json_copy = Path('/mnt/data/extremal_geometry_lab_v2_0s_batch2_run_recalibrated.json')
    zip_copy = Path('/mnt/data/extremal_geometry_lab_v2_0s_batch2_bridge_artifacts_recalibrated.zip')
    md_copy.write_text((OUTDIR / 'summary.md').read_text())
    json_copy.write_text((OUTDIR / 'summary.json').read_text())
    with ZipFile(zip_copy, 'w') as zf:
        for path in sorted(OUTDIR.rglob('*')):
            if path.is_file():
                zf.write(path, path.relative_to(OUTDIR.parent))

if __name__ == '__main__':
    main()
