from __future__ import annotations

import json
import time
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import cascaded_rigid_refinement
    from extremal_geometry_lab.certificates import bridge_cascade
except ModuleNotFoundError:
    import sys
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / 'packages'
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import cascaded_rigid_refinement
    from extremal_geometry_lab.certificates import bridge_cascade

OUTDIR = Path('results/certificates/v2_0y_compact_cascade_batch')
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
LADDER = ['light', 'real', 'confirm']


def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(label)


def _classify(refinement) -> str:
    if len(refinement.certified_feasible_boxes) > 0:
        return 'certified_feasible'
    if len(refinement.unresolved_boxes) == 0:
        return 'certified_infeasible'
    return 'incomplete'


def _run_case(container, witness, *, level: str, anisotropic_policy: str = 'off') -> dict:
    start = time.perf_counter()
    refinement = cascaded_rigid_refinement(
        container,
        witness,
        stages=bridge_cascade(level, anisotropic_policy=anisotropic_policy),
        sticky_locked_priority=True,
    )
    runtime = time.perf_counter() - start
    details = refinement.best_pose.details or {}
    return {
        'level': level,
        'anisotropic_policy': anisotropic_policy,
        'runtime_sec': round(runtime, 3),
        'classification': _classify(refinement),
        'has_certified_feasible_box': bool(len(refinement.certified_feasible_boxes) > 0),
        'counts': {
            'feasible': len(refinement.certified_feasible_boxes),
            'infeasible': len(refinement.certified_infeasible_boxes),
            'unresolved': len(refinement.unresolved_boxes),
            'explored': len(refinement.explored_boxes),
        },
        'cascade_stage_count': int(details.get('cascade_stage_count', 0)),
        'cascade_stage_records': list(details.get('cascade_stage_records', [])),
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    seed_state = pal_seed()
    moderate_state = _apply_move(seed_state, 'medium-corner-cut')
    seed_container = body_from_state(seed_state)
    moderate_container = body_from_state(moderate_state)

    payload: dict = {
        'batch': 'v2.0y compact cascade batch',
        'seed_witnesses': [],
        'anisotropic_comparisons': [],
    }
    lines = [
        '# Extremal Geometry Lab v2.0y — compact cascade batch',
        '',
        '## Seed witness ladder',
        '',
    ]

    for idx, (label, poly) in enumerate(NET.witnesses):
        witness = _named_body(label, poly)
        rec = {'index': idx, 'label': label, 'runs': []}
        lines.append(f'### {idx:02d} `{label}`')
        first_feasible = None
        for level in LADDER:
            print(f'[compact] seed {label} {level} off', flush=True)
            run = _run_case(seed_container, witness, level=level, anisotropic_policy='off')
            rec['runs'].append(run)
            lines.append(f"- `{level}`: class=`{run['classification']}`, feasible=`{run['has_certified_feasible_box']}`, explored=`{run['counts']['explored']}`, runtime=`{run['runtime_sec']}` s")
            if run['has_certified_feasible_box']:
                first_feasible = level
                break
        rec['first_feasible_stage'] = first_feasible
        payload['seed_witnesses'].append(rec)
        lines.append(f"- first_feasible_stage: `{first_feasible}`")
        lines.append('')

    lines += ['## Anisotropic comparisons', '']
    compare_specs = [
        ('seed', seed_container, 'regular-3-gon', 'real'),
        ('seed', seed_container, 'pal-seed', 'real'),
        ('moderate-cut', moderate_container, 'segment', 'light'),
    ]
    witness_map = {label: _named_body(label, poly) for label, poly in NET.witnesses}
    for state_name, container, label, level in compare_specs:
        witness = witness_map[label]
        print(f'[compact] compare {state_name} {label} {level}', flush=True)
        off = _run_case(container, witness, level=level, anisotropic_policy='off')
        on = _run_case(container, witness, level=level, anisotropic_policy='explicit')
        comp = {
            'state': state_name,
            'witness': label,
            'level': level,
            'off': off,
            'explicit': on,
            'explored_box_delta_explicit_minus_off': int(on['counts']['explored'] - off['counts']['explored']),
        }
        payload['anisotropic_comparisons'].append(comp)
        lines.append(f"### `{state_name}` / `{label}` / `{level}`")
        lines.append(f"- off: class=`{off['classification']}`, explored=`{off['counts']['explored']}`, runtime=`{off['runtime_sec']}` s")
        lines.append(f"- explicit: class=`{on['classification']}`, explored=`{on['counts']['explored']}`, runtime=`{on['runtime_sec']}` s")
        lines.append(f"- explored_box_delta_explicit_minus_off: `{comp['explored_box_delta_explicit_minus_off']}`")
        lines.append('')

    payload['summary'] = {
        'first_feasible_stage_by_witness': {rec['label']: rec['first_feasible_stage'] for rec in payload['seed_witnesses']},
        'total_runtime_sec': round(sum(run['runtime_sec'] for rec in payload['seed_witnesses'] for run in rec['runs']) + sum(comp['off']['runtime_sec'] + comp['explicit']['runtime_sec'] for comp in payload['anisotropic_comparisons']), 3),
    }
    lines += ['## Summary', f"- first_feasible_stage_by_witness: `{payload['summary']['first_feasible_stage_by_witness']}`", f"- total_runtime_sec: `{payload['summary']['total_runtime_sec']}`"]

    (OUTDIR / 'summary.json').write_text(json.dumps(payload, indent=2))
    (OUTDIR / 'summary.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    main()
