from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.core import disk_body, capsule_body, certified_support_gap_bound_2d_interval, interval_support_bounds_2d
from extremal_geometry_lab.certificates import write_certificate_bundle


def main() -> None:
    outer = disk_body(2.0)
    inner = capsule_body(segment_length=1.0, radius=0.4, theta=0.0)
    cert = certified_support_gap_bound_2d_interval(outer, inner, n=128, dps=60)
    sample_arc = interval_support_bounds_2d(inner, 0.0, 0.25, dps=60)
    payload = {
        "schema_version": "analytic-interval-support-demo.v1",
        "container": outer.name,
        "witness": inner.name,
        "interval_certificate": {
            "passed": bool(cert.passed),
            "certified_upper_violation": float(cert.certified_upper_violation),
            "details": cert.details,
        },
        "sample_arc": {
            "theta_lo": 0.0,
            "theta_hi": 0.25,
            "support_bounds": None if sample_arc is None else [float(sample_arc[0]), float(sample_arc[1])],
        },
    }
    md = "\n".join([
        "# Analytic interval-support demo",
        "",
        f"- container: `{outer.name}`",
        f"- witness: `{inner.name}`",
        f"- passed: `{cert.passed}`",
        f"- certified upper violation: `{cert.certified_upper_violation}`",
        f"- method: `{cert.details.get('method')}`",
        f"- body methods: `{cert.details.get('body_methods')}`",
        f"- sample arc bounds: `{payload['sample_arc']['support_bounds']}`",
        "",
    ])
    base = Path('results/certificates/v2_0a_demo_analytic_interval_support')
    write_certificate_bundle(base, machine=payload, human_markdown=md)


if __name__ == '__main__':
    main()
