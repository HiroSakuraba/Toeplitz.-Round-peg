from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates import write_certificate_bundle
from extremal_geometry_lab.core import disk_body, refine_body_in_body_support_rigid_2d


def main() -> None:
    container = disk_body(1.0)
    witness = disk_body(1.3)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=64,
        translation_bounds=((-0.25, 0.25), (-0.25, 0.25)),
        initial_theta_intervals=1,
        initial_translation_intervals=1,
        max_depth=0,
        dps=50,
    )
    helly_boxes = [
        {
            "rotation_lo": box.rotation_lo,
            "rotation_hi": box.rotation_hi,
            "translation_box": {
                "tx_lo": box.translation_box.tx_lo,
                "tx_hi": box.translation_box.tx_hi,
                "ty_lo": box.translation_box.ty_lo,
                "ty_hi": box.translation_box.ty_hi,
            },
            "details": box.details,
        }
        for box in ref.certified_infeasible_boxes
        if box.details.get("helly_pruned")
    ]
    machine = {
        "schema_version": "helly-pruning-demo.v1",
        "container": container.name,
        "witness": witness.name,
        "counts": {
            "certified_feasible_boxes": len(ref.certified_feasible_boxes),
            "certified_infeasible_boxes": len(ref.certified_infeasible_boxes),
            "unresolved_boxes": len(ref.unresolved_boxes),
            "helly_pruned_boxes": len(helly_boxes),
        },
        "helly_pruned_boxes": helly_boxes,
    }
    lines = [
        "# Helly-style pruning demo",
        "",
        f"- container: `{container.name}`",
        f"- witness: `{witness.name}`",
        f"- certified infeasible boxes: `{len(ref.certified_infeasible_boxes)}`",
        f"- Helly-pruned boxes: `{len(helly_boxes)}`",
        "",
    ]
    for idx, box in enumerate(helly_boxes):
        d = box["details"]
        lines.extend([
            f"## Helly-pruned box {idx}",
            f"- theta width: `{d.get('theta_width')}`",
            f"- certified upper violation: `{d.get('certified_upper_violation')}`",
            f"- center sampled max violation: `{d.get('center_sampled_max_violation')}`",
            f"- pose drift bound: `{d.get('pose_drift_bound')}`",
            f"- infeasible reason: `{d.get('infeasible_reason')}`",
            "",
        ])
    out = Path("results/certificates/v2_0e_demo_helly_pruning")
    out.mkdir(parents=True, exist_ok=True)
    write_certificate_bundle(out / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
