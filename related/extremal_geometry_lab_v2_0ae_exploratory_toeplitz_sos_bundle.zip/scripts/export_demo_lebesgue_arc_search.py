from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen


def main() -> None:
    props = search_with_width_prescreen(depth=1, n=256, include_rejected=True)
    machine = {
        "schema_version": "lebesgue-arc-search-demo.v1",
        "proposal_count": len(props),
        "accepted_count": sum(1 for p in props if p.screen_passed),
        "rejected_count": sum(1 for p in props if p.screen_passed is False),
        "arc_candidates": [
            {
                "move_history": list(p.move_history),
                "screen_passed": p.screen_passed,
                "screen_reason": p.screen_reason,
                "score": p.score,
                "screen_details": p.screen_details,
                "corner_cuts": list(p.state.get("corner_cuts", [])),
                "arc_replacements": list(p.state.get("arc_replacements", [])),
                "polygon_name": p.state.get("polygon").name if p.state.get("polygon") is not None else None,
            }
            for p in props
            if p.state.get("arc_replacements")
        ],
    }
    lines = [
        "# Lebesgue arc/segment candidate demo",
        "",
        "This demo runs the Lebesgue search lane after wiring in actual rounded arc/segment candidates.",
        "",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        f"- arc candidates: `{len(machine['arc_candidates'])}`",
        "",
        "## Arc candidates",
        "",
    ]
    for rec in machine["arc_candidates"]:
        lines.extend([
            f"### {rec['move_history']}",
            f"- passed: `{rec['screen_passed']}`",
            f"- reason: `{rec['screen_reason']}`",
            f"- score: `{rec['score']}`",
            f"- polygon surrogate: `{rec['polygon_name']}`",
            f"- support methods: `{(rec['screen_details'] or {}).get('support_methods')}`",
            f"- body name: `{(rec['screen_details'] or {}).get('body_name')}`",
            f"- certified lower width: `{(rec['screen_details'] or {}).get('certified_lower_width')}`",
            f"- arc replacements: `{rec['arc_replacements']}`",
            "",
        ])
    out = Path('results/certificates/v2_0b_demo_lebesgue_arc_search/summary')
    write_certificate_bundle(out, machine=machine, human_markdown="\n".join(lines))


if __name__ == '__main__':
    main()
