from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates.formats import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen


def _proposal_record(p):
    details = p.screen_details or {}
    return {
        "move_history": list(p.move_history),
        "depth": len(p.move_history),
        "score": p.score,
        "priority": list(p.priority),
        "screen_passed": p.screen_passed,
        "screen_reason": p.screen_reason,
        "screen_details": details,
        "width_slack": details.get("certified_lower_width", 0.0) - details.get("required_width", 0.0),
        "polygon_name": p.state["polygon"].name,
        "corner_cuts": list(p.state.get("corner_cuts", [])),
        "arc_replacements": list(p.state.get("arc_replacements", [])),
    }


def _run(depth: int, beam_width: int | None):
    props = search_with_width_prescreen(depth=depth, n=256, include_rejected=True, beam_width=beam_width)
    accepted = [p for p in props if p.screen_passed]
    rejected = [p for p in props if p.screen_passed is False]
    descendants = [p for p in accepted if len(p.move_history) >= 1]
    accepted_desc = [_proposal_record(p) for p in descendants]
    rejected_desc = [_proposal_record(p) for p in rejected]
    seed = next(_proposal_record(p) for p in accepted if len(p.move_history) == 0)
    return {
        "schema_version": "lebesgue-beam-sweep.v1",
        "depth": depth,
        "beam_width": beam_width,
        "proposal_count": len(props),
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "seed": seed,
        "accepted_descendants": accepted_desc,
        "rejected_descendants": rejected_desc,
    }


def _markdown(label: str, machine: dict) -> str:
    lines = [
        f"# {label}",
        "",
        "This demo compares width-prescreened Lebesgue bounded search with slack-aware ordering under a beam cap.",
        "",
        f"- depth: `{machine['depth']}`",
        f"- beam width: `{machine['beam_width']}`",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        "",
        "## Accepted descendants",
        "",
    ]
    for idx, rec in enumerate(machine["accepted_descendants"], start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- width slack: `{rec['width_slack']}`",
            f"- score: `{rec['score']}`",
            f"- priority: `{rec['priority']}`",
            "",
        ])
    lines.extend(["## Rejected descendants", ""])
    for idx, rec in enumerate(machine["rejected_descendants"], start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- reason: `{rec['screen_reason']}`",
            f"- width slack: `{rec['width_slack']}`",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    out_dir = Path("results/certificates/v1_7_demo_lebesgue_beam_sweep")
    out_dir.mkdir(parents=True, exist_ok=True)

    uncapped = _run(depth=2, beam_width=None)
    capped = _run(depth=2, beam_width=1)
    comparison = {
        "schema_version": "lebesgue-beam-compare.v1",
        "uncapped": uncapped,
        "beam_width_1": capped,
    }
    comp_lines = [
        "# Lebesgue beam sweep comparison",
        "",
        "This comparison shows how beam truncation changes which width-screened descendants survive expansion.",
        "",
        f"- uncapped accepted descendants: `{len(uncapped['accepted_descendants'])}`",
        f"- beam=1 accepted descendants: `{len(capped['accepted_descendants'])}`",
        "",
        "## Top uncapped descendant",
        f"- move history: `{uncapped['accepted_descendants'][0]['move_history']}`",
        f"- width slack: `{uncapped['accepted_descendants'][0]['width_slack']}`",
        "",
        "## Beam=1 surviving descendant",
        f"- move history: `{capped['accepted_descendants'][0]['move_history']}`",
        f"- width slack: `{capped['accepted_descendants'][0]['width_slack']}`",
    ]

    write_certificate_bundle(out_dir / "uncapped", machine=uncapped, human_markdown=_markdown("Uncapped sweep", uncapped))
    write_certificate_bundle(out_dir / "beam_width_1", machine=capped, human_markdown=_markdown("Beam width = 1 sweep", capped))
    write_certificate_bundle(out_dir / "comparison", machine=comparison, human_markdown="\n".join(comp_lines))


if __name__ == "__main__":
    main()
