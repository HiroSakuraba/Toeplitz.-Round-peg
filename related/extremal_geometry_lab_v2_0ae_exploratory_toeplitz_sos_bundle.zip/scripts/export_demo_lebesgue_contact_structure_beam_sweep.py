from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates.formats import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen
from extremal_geometry_lab.domains.lebesgue.family import proposal_diversity_key, proposal_contact_diversity_key


def _proposal_record(p):
    details = p.screen_details or {}
    ann = p.annotations or {}
    return {
        "move_history": list(p.move_history),
        "depth": len(p.move_history),
        "score": p.score,
        "priority": list(p.priority),
        "screen_passed": p.screen_passed,
        "screen_reason": p.screen_reason,
        "screen_details": details,
        "width_slack": details.get("certified_lower_width", 0.0) - details.get("required_width", 0.0),
        "polygon_name": p.state["polygon"].name,
        "support_diversity_key": list(proposal_diversity_key(p)),
        "contact_diversity_key": list(proposal_contact_diversity_key(p)) if ann else None,
        "annotations": ann,
        "corner_cuts": list(p.state.get("corner_cuts", [])),
        "arc_replacements": list(p.state.get("arc_replacements", [])),
    }


def _run(label: str, *, structure_signal: str | None):
    props = search_with_width_prescreen(
        depth=2,
        n=256,
        include_rejected=True,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal=structure_signal,
    )
    accepted = [p for p in props if p.screen_passed]
    rejected = [p for p in props if p.screen_passed is False]
    descendants = [p for p in accepted if len(p.move_history) >= 1]
    return {
        "schema_version": "lebesgue-contact-structure-beam-sweep.v1",
        "label": label,
        "structure_signal": structure_signal,
        "proposal_count": len(props),
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "accepted_descendants": [_proposal_record(p) for p in descendants],
        "rejected_descendants": [_proposal_record(p) for p in rejected],
    }


def _markdown(machine: dict) -> str:
    lines = [
        f"# {machine['label']}",
        "",
        "This demo compares the existing support-signature search policy with the new contact-structure search signal.",
        "",
        f"- structure signal: `{machine['structure_signal']}`",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        "",
        "## Accepted descendants",
        "",
    ]
    for idx, rec in enumerate(machine["accepted_descendants"], start=1):
        ann = rec.get("annotations") or {}
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- width slack: `{rec['width_slack']}`",
            f"- priority: `{rec['priority']}`",
            f"- support diversity key: `{rec['support_diversity_key']}`",
            f"- contact diversity key: `{rec['contact_diversity_key']}`",
            f"- contact cardinality: `{ann.get('contact_cardinality')}`",
            f"- contact gap signature: `{ann.get('contact_gap_signature')}`",
            f"- contact verification method: `{ann.get('contact_verification_method')}`",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    out_dir = Path("results/certificates/v2_0g_demo_lebesgue_contact_structure_beam_sweep")
    out_dir.mkdir(parents=True, exist_ok=True)

    support_mode = _run("Support-signature diversified beam", structure_signal=None)
    contact_mode = _run("Contact-structure diversified beam", structure_signal="contact")
    comparison = {
        "schema_version": "lebesgue-contact-structure-beam-compare.v1",
        "support_mode": support_mode,
        "contact_mode": contact_mode,
        "support_only": sorted({tuple(rec["move_history"]) for rec in support_mode["accepted_descendants"]} - {tuple(rec["move_history"]) for rec in contact_mode["accepted_descendants"]}),
        "contact_only": sorted({tuple(rec["move_history"]) for rec in contact_mode["accepted_descendants"]} - {tuple(rec["move_history"]) for rec in support_mode["accepted_descendants"]}),
    }
    comp_lines = [
        "# Contact-structure beam comparison",
        "",
        "This comparison shows how a search signal built from minimal active-contact certificates changes which Lebesgue descendants survive diversified beam truncation.",
        "",
        f"- support-only descendants: `{comparison['support_only']}`",
        f"- contact-only descendants: `{comparison['contact_only']}`",
    ]

    write_certificate_bundle(out_dir / "support_signature_mode", machine=support_mode, human_markdown=_markdown(support_mode))
    write_certificate_bundle(out_dir / "contact_structure_mode", machine=contact_mode, human_markdown=_markdown(contact_mode))
    write_certificate_bundle(out_dir / "comparison", machine=comparison, human_markdown="\n".join(comp_lines))


if __name__ == "__main__":
    main()
