from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates.formats import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen, proposal_diversity_key


def _proposal_record(p):
    details = p.screen_details or {}
    return {
        "move_history": list(p.move_history),
        "depth": len(p.move_history),
        "score": p.score,
        "priority": list(p.priority),
        "screen_passed": p.screen_passed,
        "screen_reason": p.screen_reason,
        "screen_details": details,
        "width_slack": details.get("certified_lower_width", 0.0) - details.get("required_width", 0.0),
        "polygon_name": p.state["polygon"].name,
        "diversity_key": list(proposal_diversity_key(p)),
        "corner_cuts": list(p.state.get("corner_cuts", [])),
        "arc_replacements": list(p.state.get("arc_replacements", [])),
    }


def _run(depth: int, beam_width: int, beam_policy: str, beam_diversity_reserve: int = 0):
    props = search_with_width_prescreen(
        depth=depth,
        n=256,
        include_rejected=True,
        beam_width=beam_width,
        beam_policy=beam_policy,
        beam_diversity_reserve=beam_diversity_reserve,
    )
    accepted = [p for p in props if p.screen_passed]
    rejected = [p for p in props if p.screen_passed is False]
    descendants = [p for p in accepted if len(p.move_history) >= 1]
    accepted_desc = [_proposal_record(p) for p in descendants]
    rejected_desc = [_proposal_record(p) for p in rejected]
    seed = next(_proposal_record(p) for p in accepted if len(p.move_history) == 0)
    return {
        "schema_version": "lebesgue-geometric-diversified-beam-sweep.v1",
        "depth": depth,
        "beam_width": beam_width,
        "beam_policy": beam_policy,
        "beam_diversity_reserve": beam_diversity_reserve,
        "proposal_count": len(props),
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "seed": seed,
        "accepted_descendants": accepted_desc,
        "rejected_descendants": rejected_desc,
    }


def _markdown(label: str, machine: dict) -> str:
    lines = [
        f"# {label}",
        "",
        "This demo compares greedy and diversified beam policies under the Lebesgue width prescreen.",
        "",
        f"- depth: `{machine['depth']}`",
        f"- beam width: `{machine['beam_width']}`",
        f"- beam policy: `{machine['beam_policy']}`",
        f"- beam diversity reserve: `{machine['beam_diversity_reserve']}`",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        "",
        "## Accepted descendants",
        "",
    ]
    for idx, rec in enumerate(machine["accepted_descendants"], start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- diversity family: `{rec['diversity_key']}`",
            f"- width slack: `{rec['width_slack']}`",
            f"- score: `{rec['score']}`",
            "",
        ])
    lines.extend(["## Rejected descendants", ""])
    for idx, rec in enumerate(machine["rejected_descendants"], start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- reason: `{rec['screen_reason']}`",
            f"- width slack: `{rec['width_slack']}`",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    out_dir = Path("results/certificates/v1_9_demo_lebesgue_geometric_diversified_beam_sweep")
    out_dir.mkdir(parents=True, exist_ok=True)

    greedy = _run(depth=2, beam_width=3, beam_policy="greedy")
    diversified = _run(depth=2, beam_width=3, beam_policy="diversified", beam_diversity_reserve=2)
    comparison = {
        "schema_version": "lebesgue-geometric-diversified-beam-compare.v1",
        "greedy": greedy,
        "diversified": diversified,
    }
    comp_lines = [
        "# Geometric diversified beam comparison",
        "",
        "This comparison shows how reserving diversified beam slots for distinct trim-parameter regions keeps search diversity under the Lebesgue width prescreen.",
        "",
        f"- greedy accepted descendants: `{len(greedy['accepted_descendants'])}`",
        f"- diversified accepted descendants: `{len(diversified['accepted_descendants'])}`",
        f"- greedy diversity families: `{sorted({tuple(rec['diversity_key']) for rec in greedy['accepted_descendants']})}`",
        f"- diversified diversity families: `{sorted({tuple(rec['diversity_key']) for rec in diversified['accepted_descendants']})}`",
    ]

    write_certificate_bundle(out_dir / "greedy_beam_width_3", machine=greedy, human_markdown=_markdown("Greedy beam width = 2", greedy))
    write_certificate_bundle(out_dir / "diversified_beam_width_3", machine=diversified, human_markdown=_markdown("Diversified beam width = 2", diversified))
    write_certificate_bundle(out_dir / "comparison", machine=comparison, human_markdown="\n".join(comp_lines))


if __name__ == "__main__":
    main()
