from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen
from extremal_geometry_lab.domains.lebesgue.family import proposal_diversity_key, proposal_contact_diversity_key


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "screen_details": p.screen_details,
        "support_diversity_key": list(proposal_diversity_key(p)),
        "contact_diversity_key": list(proposal_contact_diversity_key(p)) if ann else None,
        "annotations": ann,
    }


def _run(label: str, *, structure_signal: str | None):
    props = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal=structure_signal,
    )
    accepted_desc = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    machine = {
        "label": label,
        "structure_signal": structure_signal,
        "accepted_descendants": accepted_desc,
    }
    lines = [
        f"# {label}",
        "",
        f"- structure signal: `{structure_signal}`",
        f"- accepted descendants: **{len(accepted_desc)}**",
        "",
    ]
    for rec in accepted_desc:
        lines.extend([
            f"## {' -> '.join(rec['moves']) if rec['moves'] else 'seed'}",
            f"- support diversity key: `{rec['support_diversity_key']}`",
            f"- contact diversity key: `{rec['contact_diversity_key']}`",
            "",
        ])
    return machine, "\n".join(lines)


def main() -> None:
    support_mode = _run("Support-signature diversified beam", structure_signal=None)
    contact_mode = _run("Contact-structure diversified beam", structure_signal="contact")
    hybrid_mode = _run("Hybrid diversified beam", structure_signal="hybrid")
    outdir = Path("results/certificates/v2_0h_demo_lebesgue_hybrid_beam_sweep")
    outdir.mkdir(parents=True, exist_ok=True)
    for stem, pair in [("support", support_mode), ("contact", contact_mode), ("hybrid", hybrid_mode)]:
        machine, text = pair
        (outdir / f"{stem}.json").write_text(json.dumps(machine, indent=2))
        (outdir / f"{stem}.md").write_text(text)
    comparison = {
        "support_count": len(support_mode[0]["accepted_descendants"]),
        "contact_count": len(contact_mode[0]["accepted_descendants"]),
        "hybrid_count": len(hybrid_mode[0]["accepted_descendants"]),
        "support_unique_support_keys": sorted({tuple(r["support_diversity_key"]) for r in support_mode[0]["accepted_descendants"]}),
        "contact_unique_contact_keys": sorted({tuple(r["contact_diversity_key"] or []) for r in contact_mode[0]["accepted_descendants"]}),
        "hybrid_unique_support_keys": sorted({tuple(r["support_diversity_key"]) for r in hybrid_mode[0]["accepted_descendants"]}),
        "hybrid_unique_contact_keys": sorted({tuple(r["contact_diversity_key"] or []) for r in hybrid_mode[0]["accepted_descendants"]}),
    }
    (outdir / "comparison.json").write_text(json.dumps(comparison, indent=2))
    (outdir / "comparison.md").write_text(
        "\n".join([
            "# Hybrid beam comparison",
            "",
            f"- support descendants: **{comparison['support_count']}**",
            f"- contact descendants: **{comparison['contact_count']}**",
            f"- hybrid descendants: **{comparison['hybrid_count']}**",
            "",
            f"- hybrid unique support keys: `{comparison['hybrid_unique_support_keys']}`",
            f"- hybrid unique contact keys: `{comparison['hybrid_unique_contact_keys']}`",
        ])
    )


if __name__ == "__main__":
    main()
