from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates.formats import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen


def main() -> None:
    out_dir = Path("results/certificates/v1_5_demo_lebesgue_prescreened_search")
    out_dir.mkdir(parents=True, exist_ok=True)

    props = search_with_width_prescreen(depth=1, n=256, include_rejected=True)
    machine = {
        "schema_version": "lebesgue-prescreened-search.v1",
        "proposal_count": len(props),
        "accepted_count": sum(1 for p in props if p.screen_passed),
        "rejected_count": sum(1 for p in props if p.screen_passed is False),
        "proposals": [
            {
                "move_history": list(p.move_history),
                "score": p.score,
                "screen_passed": p.screen_passed,
                "screen_reason": p.screen_reason,
                "screen_details": p.screen_details,
                "polygon_name": p.state["polygon"].name,
                "corner_cuts": list(p.state.get("corner_cuts", [])),
                "arc_replacements": list(p.state.get("arc_replacements", [])),
            }
            for p in props
        ],
    }
    lines = [
        "# Lebesgue prescreened search demo",
        "",
        "This demo runs bounded search in the Pál-descended Lebesgue family with the width prescreen active during proposal generation.",
        "",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        "",
        "## Proposals",
        "",
    ]
    for rec in machine["proposals"]:
        lines.extend([
            f"### {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- score: `{rec['score']}`",
            f"- screen passed: `{rec['screen_passed']}`",
            f"- screen reason: `{rec['screen_reason']}`",
            f"- corner cuts: `{rec['corner_cuts']}`",
            f"- arc replacements: `{rec['arc_replacements']}`",
            "",
        ])
    write_certificate_bundle(out_dir / "summary", machine=machine, human_markdown="\n".join(lines))

if __name__ == "__main__":
    main()
