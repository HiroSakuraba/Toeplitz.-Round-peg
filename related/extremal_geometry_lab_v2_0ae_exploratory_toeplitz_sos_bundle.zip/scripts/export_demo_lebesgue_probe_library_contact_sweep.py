from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "contact_signature_key": list(ann.get("contact_signature_key", ())),
        "contact_probe_library": list(ann.get("contact_probe_library", ())),
        "contact_probe_signature": [list(x) if isinstance(x, tuple) else x for x in ann.get("contact_probe_signature", ())],
        "contact_cardinality": ann.get("contact_cardinality"),
    }


def _run(label: str, *, contact_probe_names):
    props = search_with_width_prescreen(
        depth=1,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="contact",
        contact_probe_names=contact_probe_names,
    )
    descendants = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    return {
        "label": label,
        "contact_probe_names": list(contact_probe_names),
        "accepted_descendants": descendants,
        "unique_contact_keys": sorted({tuple(rec["contact_signature_key"]) for rec in descendants}),
    }


def _md(machine: dict) -> str:
    lines = [
        f"# {machine['label']}",
        "",
        f"- contact probe names: `{machine['contact_probe_names']}`",
        f"- accepted descendants: **{len(machine['accepted_descendants'])}**",
        f"- unique contact keys: **{len(machine['unique_contact_keys'])}**",
        "",
    ]
    for rec in machine["accepted_descendants"]:
        lines.extend([
            f"## {' -> '.join(rec['moves'])}",
            f"- contact signature key: `{rec['contact_signature_key']}`",
            f"- contact probe library: `{rec['contact_probe_library']}`",
            f"- contact probe signature: `{rec['contact_probe_signature']}`",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    outdir = Path("results/certificates/v2_0i_demo_lebesgue_probe_library_contact_sweep")
    outdir.mkdir(parents=True, exist_ok=True)
    segment = _run("Segment-only contact signal", contact_probe_names=("segment",))
    multi = _run("Probe-library contact signal", contact_probe_names=("segment", "orbiform-stub", "disk-half"))
    (outdir / "segment_only.json").write_text(json.dumps(segment, indent=2))
    (outdir / "segment_only.md").write_text(_md(segment))
    (outdir / "probe_library.json").write_text(json.dumps(multi, indent=2))
    (outdir / "probe_library.md").write_text(_md(multi))
    comp = {
        "segment_unique_contact_keys": len(segment["unique_contact_keys"]),
        "probe_library_unique_contact_keys": len(multi["unique_contact_keys"]),
        "segment_moves": [rec["moves"] for rec in segment["accepted_descendants"]],
        "probe_library_moves": [rec["moves"] for rec in multi["accepted_descendants"]],
    }
    (outdir / "comparison.json").write_text(json.dumps(comp, indent=2))
    (outdir / "comparison.md").write_text(
        "\n".join([
            "# Probe-library contact sweep comparison",
            "",
            f"- segment-only unique contact keys: **{comp['segment_unique_contact_keys']}**",
            f"- probe-library unique contact keys: **{comp['probe_library_unique_contact_keys']}**",
        ])
    )


if __name__ == "__main__":
    main()
