from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates.formats import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen


def _proposal_record(p):
    details = p.screen_details or {}
    return {
        "move_history": list(p.move_history),
        "depth": len(p.move_history),
        "score": p.score,
        "priority": list(p.priority),
        "screen_passed": p.screen_passed,
        "screen_reason": p.screen_reason,
        "screen_details": details,
        "width_slack": details.get("certified_lower_width", 0.0) - details.get("required_width", 0.0),
        "polygon_name": p.state["polygon"].name,
        "corner_cuts": list(p.state.get("corner_cuts", [])),
        "arc_replacements": list(p.state.get("arc_replacements", [])),
    }


def main() -> None:
    out_dir = Path("results/certificates/v1_6_demo_lebesgue_ranked_sweep")
    out_dir.mkdir(parents=True, exist_ok=True)

    props = search_with_width_prescreen(depth=2, n=256, include_rejected=True)
    accepted = [p for p in props if p.screen_passed]
    rejected = [p for p in props if p.screen_passed is False]
    descendants = [p for p in accepted if len(p.move_history) >= 1]
    accepted_desc = [_proposal_record(p) for p in descendants]
    rejected_desc = [_proposal_record(p) for p in rejected]
    seed = next(_proposal_record(p) for p in accepted if len(p.move_history) == 0)

    machine = {
        "schema_version": "lebesgue-ranked-sweep.v1",
        "depth": 2,
        "proposal_count": len(props),
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "seed": seed,
        "accepted_descendants": accepted_desc,
        "rejected_descendants": rejected_desc,
    }

    lines = [
        "# Lebesgue ranked sweep demo",
        "",
        "This demo runs bounded search in the Pál-descended family with width-prescreen pruning and screen-slack-aware proposal ordering.",
        "",
        f"- depth: `{machine['depth']}`",
        f"- proposals: `{machine['proposal_count']}`",
        f"- accepted: `{machine['accepted_count']}`",
        f"- rejected: `{machine['rejected_count']}`",
        "",
        "## Seed",
        "",
        f"- polygon: `{seed['polygon_name']}`",
        f"- width slack: `{seed['width_slack']}`",
        f"- score: `{seed['score']}`",
        "",
        "## Accepted descendants (ordered)",
        "",
    ]
    for idx, rec in enumerate(accepted_desc, start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- width slack: `{rec['width_slack']}`",
            f"- score: `{rec['score']}`",
            f"- priority: `{rec['priority']}`",
            f"- corner cuts: `{rec['corner_cuts']}`",
            f"- arc replacements: `{rec['arc_replacements']}`",
            "",
        ])
    lines.extend(["## Rejected descendants", ""])
    for idx, rec in enumerate(rejected_desc, start=1):
        lines.extend([
            f"### {idx}. {rec['polygon_name']}",
            f"- move history: `{rec['move_history']}`",
            f"- screen reason: `{rec['screen_reason']}`",
            f"- width slack: `{rec['width_slack']}`",
            f"- score: `{rec['score']}`",
            f"- priority: `{rec['priority']}`",
            "",
        ])

    write_certificate_bundle(out_dir / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
