from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates import export_rounded_candidate_bundle, write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen, prescreen_candidate_state


def main() -> None:
    props = search_with_width_prescreen(depth=1, n=256, include_rejected=True)
    out_dir = Path("results/certificates/v2_0d_demo_lebesgue_rounded_self_verify")
    out_dir.mkdir(parents=True, exist_ok=True)

    entries = []
    for idx, prop in enumerate(props):
        if not prop.state.get("arc_replacements"):
            continue
        name = f"rounded_{idx:02d}_{'_'.join(prop.move_history) if prop.move_history else 'seed'}"
        result = prescreen_candidate_state(prop.state, width_lb=1.0, n=256)
        payload = export_rounded_candidate_bundle(
            out_dir / name,
            family="lebesgue-rounded",
            state_name=name,
            state=prop.state,
            result=result,
        )
        entries.append({
            "name": name,
            "move_history": list(prop.move_history),
            "claim": payload["claim"],
            "certified_lower_width": payload["certified_lower_width"],
            "support_methods": payload.get("support_methods"),
            "rounded_radius": (payload.get("construction") or {}).get("rounded_radius"),
        })

    machine = {
        "schema_version": "lebesgue-rounded-self-verify-demo.v1",
        "bundle_count": len(entries),
        "entries": entries,
    }
    lines = [
        "# Rounded candidate self-verifying bundle demo",
        "",
        f"- bundle count: `{len(entries)}`",
        "",
    ]
    for rec in entries:
        lines.extend([
            f"## {rec['name']}",
            f"- move history: `{rec['move_history']}`",
            f"- claim: `{rec['claim']}`",
            f"- certified lower width: `{rec['certified_lower_width']}`",
            f"- support methods: `{rec['support_methods']}`",
            f"- rounded radius: `{rec['rounded_radius']}`",
            "",
        ])
    write_certificate_bundle(out_dir / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
