from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen

REFINE_KWARGS = {"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False}


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "suggested_labels": list(ann.get("witness_target_suggested_labels", ())),
        "move_limit": ann.get("witness_target_move_limit"),
        "witness_target_move_specs": [
            {
                "label": spec.get("label"),
                "score": spec.get("score"),
                "cluster": spec.get("cluster"),
                "severity": spec.get("severity"),
            }
            for spec in ann.get("witness_target_move_specs", ())
        ],
    }


def _run(label: str, *, targeted_move_limit: int):
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs=REFINE_KWARGS,
        enable_witness_targeted_moves=True,
        targeted_move_limit=targeted_move_limit,
    )
    accepted_desc = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    machine = {
        "label": label,
        "targeted_move_limit": int(targeted_move_limit),
        "accepted_descendants": accepted_desc,
    }
    lines = [
        f"# {label}",
        "",
        f"- targeted move limit: `{targeted_move_limit}`",
        f"- accepted descendants: **{len(accepted_desc)}**",
        "",
    ]
    for rec in accepted_desc:
        lines.extend([
            f"## {' -> '.join(rec['moves'])}",
            f"- suggested labels: `{rec['suggested_labels']}`",
            f"- scored move specs: `{rec['witness_target_move_specs']}`",
            "",
        ])
    return machine, "\n".join(lines)


def main() -> None:
    limited = _run("Scored witness-targeted moves with limit 1", targeted_move_limit=1)
    wider = _run("Scored witness-targeted moves with limit 3", targeted_move_limit=3)
    outdir = Path("results/certificates/v2_0o_demo_lebesgue_scored_targeted_moves")
    outdir.mkdir(parents=True, exist_ok=True)
    for stem, pair in [("limit_1", limited), ("limit_3", wider)]:
        machine, text = pair
        (outdir / f"{stem}.json").write_text(json.dumps(machine, indent=2))
        (outdir / f"{stem}.md").write_text(text)
    limited_desc = [rec["moves"] for rec in limited[0]["accepted_descendants"]]
    wider_desc = [rec["moves"] for rec in wider[0]["accepted_descendants"]]
    comparison = {
        "limit_1_descendants": limited_desc,
        "limit_3_descendants": wider_desc,
        "introduced_when_widened": [moves for moves in wider_desc if moves not in limited_desc],
    }
    (outdir / "comparison.json").write_text(json.dumps(comparison, indent=2))
    (outdir / "comparison.md").write_text("\n".join([
        "# Scored witness-targeted move comparison",
        "",
        f"- limit 1 descendants: `{comparison['limit_1_descendants']}`",
        f"- limit 3 descendants: `{comparison['limit_3_descendants']}`",
        f"- introduced when widened: `{comparison['introduced_when_widened']}`",
    ]))


if __name__ == "__main__":
    main()
