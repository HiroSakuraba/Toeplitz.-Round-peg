from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen

REFINE_KWARGS = {"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False}


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "witness_net_passed_witness_count": int(ann.get("witness_net_passed_witness_count", 0)),
        "witness_net_failed_witness_count": int(ann.get("witness_net_failed_witness_count", 0)),
        "witness_target_max_score": float(ann.get("witness_target_max_score", 0.0)),
        "witness_target_total_score": float(ann.get("witness_target_total_score", 0.0)),
        "witness_target_score_bucket": int(ann.get("witness_target_score_bucket", 0)),
        "witness_target_suggested_labels": list(ann.get("witness_target_suggested_labels", ())),
        "witness_target_suggested_targets": list(ann.get("witness_target_suggested_targets", ())),
    }


def main() -> None:
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs=REFINE_KWARGS,
        enable_witness_targeted_moves=True,
        targeted_move_limit=2,
    )
    accepted = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    machine = {
        "label": "Witness-net beam with target-score signal",
        "accepted_descendants": accepted,
        "sorted_by_target_score": [rec["moves"] for rec in sorted(accepted, key=lambda r: (r["witness_target_max_score"], r["witness_target_total_score"], r["score"]), reverse=True)],
    }
    lines = [
        "# Witness-net beam with target-score signal",
        "",
        f"- accepted descendants: **{len(accepted)}**",
        "",
    ]
    for rec in accepted:
        lines.extend([
            f"## {' -> '.join(rec['moves'])}",
            f"- witness pass/fail: `{rec['witness_net_passed_witness_count']}` / `{rec['witness_net_failed_witness_count']}`",
            f"- target max score: `{rec['witness_target_max_score']}`",
            f"- target total score: `{rec['witness_target_total_score']}`",
            f"- target score bucket: `{rec['witness_target_score_bucket']}`",
            f"- suggested labels: `{rec['witness_target_suggested_labels']}`",
            f"- suggested targets: `{rec['witness_target_suggested_targets']}`",
            "",
        ])
    outdir = Path("results/certificates/v2_0p_demo_lebesgue_target_score_beam_signal")
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "summary.json").write_text(json.dumps(machine, indent=2))
    (outdir / "summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
