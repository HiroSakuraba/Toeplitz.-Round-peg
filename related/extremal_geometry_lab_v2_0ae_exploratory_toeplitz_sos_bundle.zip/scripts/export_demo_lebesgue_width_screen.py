from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.certificates.formats import export_width_prescreen_bundle, write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import pal_seed
from extremal_geometry_lab.domains.lebesgue.family import apply_corner_cut
from extremal_geometry_lab.domains.lebesgue.prescreen import prescreen_candidate_state
from extremal_geometry_lab.search.exact_screen import exact_family_screen, predicate_from_width_prescreen


def main() -> None:
    out_dir = Path("results/certificates/v1_4_demo_lebesgue_width_screen")
    out_dir.mkdir(parents=True, exist_ok=True)

    seed = pal_seed()
    failing = {**seed, "polygon": apply_corner_cut(seed["polygon"], 0.5), "corner_cuts": [0.5]}

    def width_screen(state: dict):
        return prescreen_candidate_state(state, width_lb=1.0, n=256, dps=60)

    pred = predicate_from_width_prescreen(width_screen)
    states = [("pal_seed", seed), ("corner_cut_0_5", failing)]
    summary_rows = []
    for name, state in states:
        result = width_screen(state)
        export_width_prescreen_bundle(out_dir / name / "bundle", family=state.get("family", "unknown"), state_name=name, result=result)
        screen = exact_family_screen(state, state.get("family", "unknown"), pred)
        summary_rows.append({
            "state_name": name,
            "family": screen.family,
            "passed": bool(screen.passed),
            "reason": screen.reason,
            "details": screen.details,
        })

    machine = {
        "schema_version": "lebesgue-width-screen-demo.v1",
        "states": summary_rows,
    }
    lines = [
        "# Lebesgue width-screen demo",
        "",
        "This demo exercises the v1.4 width prescreen through the family-screen API.",
        "",
        "## States",
        "",
    ]
    for row in summary_rows:
        lines.extend([
            f"### {row['state_name']}",
            f"- family: `{row['family']}`",
            f"- passed: `{row['passed']}`",
            f"- reason: `{row['reason']}`",
            f"- certified lower width: `{row['details'].get('certified_lower_width')}`",
            "",
        ])
    write_certificate_bundle(out_dir / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
