from __future__ import annotations

from pathlib import Path
import json

from extremal_geometry_lab.certificates import write_certificate_bundle
from extremal_geometry_lab.domains.lebesgue import (
    pal_seed,
    compute_state_witness_cofailure_nerve,
    build_polygon_witness_net_scaffold,
)
from extremal_geometry_lab.domains.lebesgue.family import body_from_polygon
from extremal_geometry_lab.core.geometry_types import ConvexPolygon2D
    

def _scaled_state(base: dict, scale: float, label: str) -> dict:
    poly = base["polygon"]
    scaled = ConvexPolygon2D(poly.vertices * float(scale), name=f"{poly.name}-scaled-{scale:g}")
    return {
        **base,
        "polygon": scaled,
        "body": body_from_polygon(scaled),
        "label": label,
        "stress_kind": "deliberately-undersized-demo-state",
        "scale_factor": float(scale),
    }


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    out = root / "results" / "certificates" / "v2_0s_demo_lebesgue_witness_cofailure_nerve"
    base = pal_seed()
    states = [
        {**base, "label": "pal-seed"},
        _scaled_state(base, 0.57, "scaled-057"),
        _scaled_state(base, 0.55, "scaled-055"),
        _scaled_state(base, 0.50, "scaled-050"),
    ]
    net = build_polygon_witness_net_scaffold(max_vertices=8, include_reduced_family=True)
    nerve = compute_state_witness_cofailure_nerve(
        states,
        net=net,
        fit_kwargs={"angle_steps": 12, "adaptive_angle_steps": 24, "adaptive_margin_threshold": 0.12, "cert_n": 24, "use_interval_refinement": False},
    )
    machine = {
        "schema_version": "witness-cofailure-nerve.v2",
        "vertex_count": len(nerve.vertices),
        "edge_count": len(nerve.edges),
        "triangle_count": len(nerve.triangles),
        "betti_0": nerve.betti_0,
        "betti_1": nerve.betti_1,
        "sample_count": nerve.sample_count,
        "nonempty_failure_samples": nerve.nonempty_failure_samples,
        "max_failure_cardinality": nerve.max_failure_cardinality,
        "witness_failure_counts": nerve.witness_failure_counts,
        "details": {
            **nerve.details,
            "demo_note": "Includes deliberately undersized stress states so the sampled nerve is nontrivial.",
        },
    }
    lines = [
        "# Witness co-failure nerve demo",
        "",
        f"- vertices: `{len(nerve.vertices)}`",
        f"- edges: `{len(nerve.edges)}`",
        f"- triangles: `{len(nerve.triangles)}`",
        f"- betti_0: `{nerve.betti_0}`",
        f"- betti_1: `{nerve.betti_1}`",
        f"- sampled states: `{nerve.sample_count}`",
        f"- nonempty failure samples: `{nerve.nonempty_failure_samples}`",
        f"- max failure cardinality: `{nerve.max_failure_cardinality}`",
        "",
        "The later demo states are deliberately undersized stress states so the sampled nerve is nontrivial.",
        "This is a sampled co-failure diagnostic only. It is not a finite-witness completeness proof.",
    ]
    write_certificate_bundle(out / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
