from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import (
    pal_seed,
    build_polygon_witness_net_scaffold,
    export_candidate_witness_net_bundle,
)
from extremal_geometry_lab.certificates import bridge_refine_kwargs


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    out = root / "results" / "certificates" / "v2_0t_demo_lebesgue_witness_net_bridge"
    net = build_polygon_witness_net_scaffold(max_vertices=5, include_reduced_family=False)
    bridge_level = "light"
    refine_kwargs = bridge_refine_kwargs(bridge_level)
    refine_kwargs["initial_intervals"] = refine_kwargs.pop("initial_theta_intervals")
    refine_kwargs.pop("initial_translation_intervals", None)
    export_candidate_witness_net_bundle(
        out,
        state=pal_seed(),
        net=net,
        refine_kwargs=refine_kwargs,
        state_name=f"pal-seed-{bridge_level}",
    )


if __name__ == "__main__":
    main()
