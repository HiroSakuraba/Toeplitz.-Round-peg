from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue.witness_net import build_polygon_witness_net_scaffold
from extremal_geometry_lab.core.support import body_from_polygon


def _diameter(poly) -> float:
    vals = body_from_polygon(poly).sample_support(n=256).values
    half = len(vals) // 2
    return max(float(vals[i] + vals[(i + half) % len(vals)]) for i in range(half)) if half > 0 else 0.0


def main() -> None:
    net = build_polygon_witness_net_scaffold(max_vertices=9, include_reduced_family=True)
    rows = []
    for label, poly in net.witnesses:
        rows.append({
            "label": label,
            "vertex_count": int(len(poly.vertices)),
            "diameter": _diameter(poly),
            "name": poly.name,
        })
    machine = {
        "kind": "lebesgue-witness-net-scaffold",
        "hausdorff_resolution": net.hausdorff_resolution,
        "diameter_class": net.diameter_class,
        "coverage_certificate": net.coverage_certificate,
        "witnesses": rows,
    }
    lines = [
        "# Lebesgue witness-net scaffold demo",
        "",
        f"- witnesses: **{len(rows)}**",
        f"- scaffold Hausdorff resolution note: `{net.hausdorff_resolution}`",
        f"- coverage mode: `{net.coverage_certificate['status']}`",
        "",
        "This is a finite witness-net scaffold for the Lebesgue lane. It is not exported as a full epsilon-net theorem certificate.",
        "",
    ]
    for row in rows:
        lines.extend([
            f"## {row['label']}",
            f"- vertex count: `{row['vertex_count']}`",
            f"- normalized diameter: `{row['diameter']}`",
            "",
        ])
    outdir = Path("results/certificates/v2_0h_demo_lebesgue_witness_net_scaffold")
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "summary.json").write_text(json.dumps(machine, indent=2))
    (outdir / "summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
