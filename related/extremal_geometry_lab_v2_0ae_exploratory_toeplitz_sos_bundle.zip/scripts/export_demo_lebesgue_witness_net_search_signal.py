from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen
from extremal_geometry_lab.domains.lebesgue.family import proposal_diversity_key, proposal_witness_net_diversity_key

REFINE_KWARGS = {"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False}


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "screen_details": p.screen_details,
        "support_diversity_key": list(proposal_diversity_key(p)),
        "witness_net_diversity_key": list(proposal_witness_net_diversity_key(p)) if ann else None,
        "witness_net_passed_witness_count": ann.get("witness_net_passed_witness_count"),
        "witness_net_failed_witness_count": ann.get("witness_net_failed_witness_count"),
        "witness_net_all_passed": ann.get("witness_net_all_passed"),
        "witness_net_failed_labels": list(ann.get("witness_net_failed_labels", ())),
    }


def _run(label: str, *, structure_signal: str | None):
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal=structure_signal,
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs=REFINE_KWARGS,
    )
    accepted_desc = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    machine = {
        "label": label,
        "structure_signal": structure_signal,
        "accepted_descendants": accepted_desc,
    }
    lines = [
        f"# {label}",
        "",
        f"- structure signal: `{structure_signal}`",
        f"- accepted descendants: **{len(accepted_desc)}**",
        "",
    ]
    for rec in accepted_desc:
        lines.extend([
            f"## {' -> '.join(rec['moves'])}",
            f"- support key: `{rec['support_diversity_key']}`",
            f"- witness-net key: `{rec['witness_net_diversity_key']}`",
            f"- witness pass/fail: `{rec['witness_net_passed_witness_count']}` / `{rec['witness_net_failed_witness_count']}`",
            f"- all passed: `{rec['witness_net_all_passed']}`",
            f"- failed labels: `{rec['witness_net_failed_labels']}`",
            "",
        ])
    return machine, "\n".join(lines)


def main() -> None:
    baseline = _run("Support-signature diversified beam", structure_signal=None)
    net_mode = _run("Witness-net diversified beam", structure_signal="witness-net")
    hybrid = _run("Hybrid witness-net diversified beam", structure_signal="hybrid-witness-net")
    outdir = Path("results/certificates/v2_0k_demo_lebesgue_witness_net_search_signal")
    outdir.mkdir(parents=True, exist_ok=True)
    for stem, pair in [("support", baseline), ("witness_net", net_mode), ("hybrid_witness_net", hybrid)]:
        machine, text = pair
        (outdir / f"{stem}.json").write_text(json.dumps(machine, indent=2))
        (outdir / f"{stem}.md").write_text(text)
    comparison = {
        "support_descendants": [rec["moves"] for rec in baseline[0]["accepted_descendants"]],
        "witness_net_descendants": [rec["moves"] for rec in net_mode[0]["accepted_descendants"]],
        "hybrid_witness_net_descendants": [rec["moves"] for rec in hybrid[0]["accepted_descendants"]],
        "support_unique_support_keys": len({tuple(rec["support_diversity_key"]) for rec in baseline[0]["accepted_descendants"]}),
        "witness_net_unique_keys": len({tuple(rec["witness_net_diversity_key"] or []) for rec in net_mode[0]["accepted_descendants"]}),
        "hybrid_unique_support_keys": len({tuple(rec["support_diversity_key"]) for rec in hybrid[0]["accepted_descendants"]}),
        "hybrid_unique_witness_net_keys": len({tuple(rec["witness_net_diversity_key"] or []) for rec in hybrid[0]["accepted_descendants"]}),
    }
    (outdir / "comparison.json").write_text(json.dumps(comparison, indent=2))
    (outdir / "comparison.md").write_text(
        "\n".join([
            "# Witness-net search signal comparison",
            "",
            f"- support descendants: `{comparison['support_descendants']}`",
            f"- witness-net descendants: `{comparison['witness_net_descendants']}`",
            f"- hybrid witness-net descendants: `{comparison['hybrid_witness_net_descendants']}`",
            "",
            f"- witness-net unique keys: **{comparison['witness_net_unique_keys']}**",
            f"- hybrid unique witness-net keys: **{comparison['hybrid_unique_witness_net_keys']}**",
        ])
    )


if __name__ == "__main__":
    main()
