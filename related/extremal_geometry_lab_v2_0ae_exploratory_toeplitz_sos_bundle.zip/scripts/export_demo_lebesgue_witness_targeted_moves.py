from __future__ import annotations

import json
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen

REFINE_KWARGS = {"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False}


def _rec(p):
    ann = p.annotations or {}
    return {
        "moves": list(p.move_history),
        "score": float(p.score),
        "witness_net_failed_labels": list(ann.get("witness_net_failed_labels", ())),
        "witness_net_weakest_labels": list(ann.get("witness_net_weakest_labels", ())),
        "witness_net_passed_witness_count": ann.get("witness_net_passed_witness_count"),
        "witness_net_failed_witness_count": ann.get("witness_net_failed_witness_count"),
    }


def _run(label: str, *, enable_witness_targeted_moves: bool):
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs=REFINE_KWARGS,
        enable_witness_targeted_moves=enable_witness_targeted_moves,
    )
    accepted_desc = [_rec(p) for p in props if p.screen_passed and len(p.move_history) >= 1]
    machine = {
        "label": label,
        "enable_witness_targeted_moves": bool(enable_witness_targeted_moves),
        "accepted_descendants": accepted_desc,
    }
    lines = [
        f"# {label}",
        "",
        f"- targeted moves enabled: `{enable_witness_targeted_moves}`",
        f"- accepted descendants: **{len(accepted_desc)}**",
        "",
    ]
    for rec in accepted_desc:
        lines.extend([
            f"## {' -> '.join(rec['moves'])}",
            f"- witness pass/fail: `{rec['witness_net_passed_witness_count']}` / `{rec['witness_net_failed_witness_count']}`",
            f"- failed labels: `{rec['witness_net_failed_labels']}`",
            f"- weakest labels: `{rec['witness_net_weakest_labels']}`",
            "",
        ])
    return machine, "\n".join(lines)


def main() -> None:
    base = _run("Witness-net beam without targeted follow-up moves", enable_witness_targeted_moves=False)
    guided = _run("Witness-net beam with targeted follow-up moves", enable_witness_targeted_moves=True)
    outdir = Path("results/certificates/v2_0l_demo_lebesgue_witness_targeted_moves")
    outdir.mkdir(parents=True, exist_ok=True)
    for stem, pair in [("baseline", base), ("guided", guided)]:
        machine, text = pair
        (outdir / f"{stem}.json").write_text(json.dumps(machine, indent=2))
        (outdir / f"{stem}.md").write_text(text)
    base_desc = [rec["moves"] for rec in base[0]["accepted_descendants"]]
    guided_desc = [rec["moves"] for rec in guided[0]["accepted_descendants"]]
    comparison = {
        "baseline_descendants": base_desc,
        "guided_descendants": guided_desc,
        "introduced_descendants": [moves for moves in guided_desc if moves not in base_desc],
        "introduced_targeted_descendants": [moves for moves in guided_desc if moves not in base_desc and any(step.startswith("targeted-") for step in moves)],
    }
    (outdir / "comparison.json").write_text(json.dumps(comparison, indent=2))
    (outdir / "comparison.md").write_text(
        "\n".join([
            "# Witness-targeted move comparison",
            "",
            f"- baseline descendants: `{comparison['baseline_descendants']}`",
            f"- guided descendants: `{comparison['guided_descendants']}`",
            f"- introduced descendants: `{comparison['introduced_descendants']}`",
            f"- introduced targeted descendants: `{comparison['introduced_targeted_descendants']}`",
        ])
    )


if __name__ == "__main__":
    main()
