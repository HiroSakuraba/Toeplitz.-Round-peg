from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.core import ConvexPolygon2D, body_from_polygon, refine_body_in_body_support_rigid_2d
from extremal_geometry_lab.certificates import export_rigid_motion_refinement_bundle


def main() -> None:
    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    witness = body_from_polygon(ConvexPolygon2D([
        [-0.4, -0.2],
        [0.6, -0.2],
        [0.1, 0.8],
    ], name="inner-triangle"))
    refinement = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=48,
        translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=3,
        dps=50,
    )
    base = Path("results/certificates/v2_0f_demo_minimal_contact_certificate/refinement_bundle")
    export_rigid_motion_refinement_bundle(base, container=container, witness=witness, refinement=refinement, support_box_index=0, dps=50)


if __name__ == "__main__":
    main()
