"""Export a small proof-facing rigid-motion certificate bundle.

This script is intentionally tiny and deterministic so another AI can run it
without guessing the workflow. It builds a simple nested polygon instance,
runs the native joint interval rigid-motion refinement, and exports a stable
JSON/markdown certificate bundle under ``results/certificates/``.
"""
from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.core import ConvexPolygon2D, body_from_polygon, refine_body_in_body_support_rigid_2d
from extremal_geometry_lab.certificates import export_rigid_motion_refinement_bundle


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    witness = body_from_polygon(ConvexPolygon2D([
        [-0.4, -0.2],
        [0.6, -0.2],
        [0.1, 0.8],
    ], name="inner-triangle"))
    refinement = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=64,
        translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=3,
        dps=50,
    )
    export_rigid_motion_refinement_bundle(
        root / "results" / "certificates" / "v1_0_demo_rigid_motion_bundle",
        container=container,
        witness=witness,
        refinement=refinement,
        support_box_index=0,
        support_cell_count=None,
        dps=50,
    )


if __name__ == "__main__":
    main()
