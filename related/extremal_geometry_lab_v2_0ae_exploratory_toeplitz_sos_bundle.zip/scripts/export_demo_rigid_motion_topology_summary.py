from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.certificates import write_certificate_bundle
from extremal_geometry_lab.core import (
    body_from_polygon,
    ConvexPolygon2D,
    refine_body_in_body_support_rigid_2d,
    analyze_rigid_motion_refinement_topology,
)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    out = root / "results" / "certificates" / "v2_0r_demo_rigid_motion_topology_summary"
    outer = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    inner = body_from_polygon(ConvexPolygon2D([
        [-0.4, -0.2],
        [0.6, -0.2],
        [0.1, 0.8],
    ], name="inner-tri"))
    refinement = refine_body_in_body_support_rigid_2d(
        outer,
        inner,
        angle_steps=36,
        cert_n=48,
        translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=2,
        dps=50,
    )
    summary = analyze_rigid_motion_refinement_topology(refinement)
    machine = {
        "schema_version": "rigid-motion-bnb-topology-summary.v1",
        "feasible_components": summary.feasible_components,
        "infeasible_components": summary.infeasible_components,
        "feasible_component_sizes": list(summary.feasible_component_sizes),
        "unresolved_count": summary.unresolved_count,
        "unresolved_fraction": summary.unresolved_fraction,
        "unresolved_touching_feasible_count": summary.unresolved_touching_feasible_count,
        "unresolved_bridge_risk_count": summary.unresolved_bridge_risk_count,
        "topological_completeness_proved": summary.topological_completeness_proved,
        "details": summary.details,
    }
    lines = [
        "# Rigid-motion BnB topology summary",
        "",
        f"- feasible components: `{summary.feasible_components}`",
        f"- infeasible components: `{summary.infeasible_components}`",
        f"- unresolved boxes: `{summary.unresolved_count}`",
        f"- unresolved fraction: `{summary.unresolved_fraction:.6f}`",
        f"- unresolved bridge-risk boxes: `{summary.unresolved_bridge_risk_count}`",
        f"- topological completeness proved: `{summary.topological_completeness_proved}`",
        "",
        "This is a conservative topology diagnostic for the classified box union, not a proof shortcut.",
    ]
    write_certificate_bundle(out / "summary", machine=machine, human_markdown="\n".join(lines))


if __name__ == "__main__":
    main()
