from __future__ import annotations

import json
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, probe_witness_library
    from extremal_geometry_lab.core import body_from_polygon, cascaded_rigid_refinement, shadow_spectral_crosscheck_from_refinement_2d
    from extremal_geometry_lab.certificates import bridge_cascade
except ModuleNotFoundError:
    import sys
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / 'packages'
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, probe_witness_library
    from extremal_geometry_lab.core import body_from_polygon, cascaded_rigid_refinement, shadow_spectral_crosscheck_from_refinement_2d
    from extremal_geometry_lab.certificates import bridge_cascade


OUTDIR = Path('results/certificates/v2_0aa_demo_shadow_spectral_verifier')
WITNESS_NAMES = ('orbiform-stub', 'disk-half')


def _body_for_label(label: str):
    for name, poly in probe_witness_library():
        if name == label:
            body = body_from_polygon(poly)
            body.name = label
            return body
    raise KeyError(label)


def _pose_payload(rep) -> dict:
    return {
        'theta': float(rep.theta),
        'translation': [float(rep.translation[0]), float(rep.translation[1])],
        'lp_margin': float(rep.lp_margin),
        'sampled_gap_margin': float(rep.sampled_gap_margin),
        'truncated_gap_margin': float(rep.truncated_gap_margin),
        'tail_sup_proxy': float(rep.tail_sup_proxy),
        'shadow_lower_margin': float(rep.shadow_lower_margin),
        'shadow_status': str(rep.shadow_status),
        'width_certificate': None if rep.width_certificate is None else {
            'required_width': float(rep.width_certificate.required_width),
            'certified_lower_width': float(rep.width_certificate.certified_lower_width),
            'passed': bool(rep.width_certificate.passed),
            'details': dict(rep.width_certificate.details or {}),
        },
        'support_series': {
            'order': int(rep.support_series.order),
            'sample_count': int(rep.support_series.sample_count),
            'a0': float(rep.support_series.a0),
            'cos_coeffs': [float(x) for x in rep.support_series.cos_coeffs],
            'sin_coeffs': [float(x) for x in rep.support_series.sin_coeffs],
            'source': str(rep.support_series.source),
            'details': dict(rep.support_series.details or {}),
        },
        'details': dict(rep.details or {}),
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    container = body_from_state(pal_seed())
    payload = {
        'schema_version': 'shadow-spectral-crosscheck.v1',
        'state': 'pal-seed',
        'bridge_level': 'real',
        'cases': [],
    }
    lines = [
        '# Extremal Geometry Lab v2.0aa — shadow spectral verifier demo',
        '',
        'This demo runs the repaired cascade lane first, then attaches the fixed-theta shadow spectral verifier to the best pose and first feasible motion-box centers.',
        '',
    ]
    for label in WITNESS_NAMES:
        witness = _body_for_label(label)
        refinement = cascaded_rigid_refinement(
            container,
            witness,
            stages=bridge_cascade('real'),
            sticky_locked_priority=True,
        )
        cross = shadow_spectral_crosscheck_from_refinement_2d(
            container,
            witness,
            refinement,
            spectral_order=32,
            direction_count=128,
            gap_sample_count=1024,
            pose_limit=2,
        )
        rec = {
            'witness': label,
            'lane_a_status': str(cross.lane_a_status),
            'lane_b_status': str(cross.lane_b_status),
            'crosscheck_details': dict(cross.details or {}),
            'pose_reports': [_pose_payload(rep) for rep in cross.pose_reports],
            'cascade_best_pose': {
                'rotation': float(refinement.best_pose.rotation),
                'translation': [float(refinement.best_pose.translation[0]), float(refinement.best_pose.translation[1])],
                'sampled_margin': float(refinement.best_pose.sampled_margin),
                'sampled_max_violation': float(refinement.best_pose.sampled_max_violation),
                'certified_upper_violation': None if refinement.best_pose.certified_upper_violation is None else float(refinement.best_pose.certified_upper_violation),
            },
            'counts': {
                'feasible_boxes': int(len(refinement.certified_feasible_boxes)),
                'infeasible_boxes': int(len(refinement.certified_infeasible_boxes)),
                'unresolved_boxes': int(len(refinement.unresolved_boxes)),
                'explored_boxes': int(len(refinement.explored_boxes)),
            },
        }
        payload['cases'].append(rec)

        lines.append(f'## `{label}`')
        lines.append(f"- lane A: `{rec['lane_a_status']}`")
        lines.append(f"- lane B: `{rec['lane_b_status']}`")
        lines.append(f"- feasible / infeasible / unresolved / explored: `{rec['counts']['feasible_boxes']}` / `{rec['counts']['infeasible_boxes']}` / `{rec['counts']['unresolved_boxes']}` / `{rec['counts']['explored_boxes']}`")
        lines.append(f"- best sampled margin: `{rec['cascade_best_pose']['sampled_margin']:.6f}`")
        for idx, pose in enumerate(rec['pose_reports']):
            lines.append(f"  - pose {idx}: shadow=`{pose['shadow_status']}`, sampled_gap_margin=`{pose['sampled_gap_margin']:.6f}`, truncated_gap_margin=`{pose['truncated_gap_margin']:.6f}`, tail_sup_proxy=`{pose['tail_sup_proxy']:.6f}`, shadow_lower_margin=`{pose['shadow_lower_margin']:.6f}`")
        lines.append('')

    payload['summary'] = {
        'lane_a_by_witness': {rec['witness']: rec['lane_a_status'] for rec in payload['cases']},
        'lane_b_by_witness': {rec['witness']: rec['lane_b_status'] for rec in payload['cases']},
    }
    lines += [
        '## Summary',
        f"- lane_a_by_witness: `{payload['summary']['lane_a_by_witness']}`",
        f"- lane_b_by_witness: `{payload['summary']['lane_b_by_witness']}`",
    ]

    (OUTDIR / 'summary.json').write_text(json.dumps(payload, indent=2))
    (OUTDIR / 'summary.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    main()
