"""Export a small witness-family coexistence bundle.

This writes per-witness rigid-motion certificate bundles plus a top-level
product-space coexistence certificate.
"""

from __future__ import annotations

from pathlib import Path

from extremal_geometry_lab.core import ConvexPolygon2D, body_from_polygon
from extremal_geometry_lab.certificates import export_witness_family_bundle


def main() -> None:
    root = Path(__file__).resolve().parents[1]

    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))

    witnesses = [
        body_from_polygon(ConvexPolygon2D([
            [-0.4, -0.2],
            [0.6, -0.2],
            [0.1, 0.8],
        ], name="inner-triangle")),
        body_from_polygon(ConvexPolygon2D([
            [-0.6, -0.6],
            [0.6, -0.6],
            [0.6, 0.6],
            [-0.6, 0.6],
        ], name="inner-square")),
    ]

    export_witness_family_bundle(
        root / "results" / "certificates" / "v1_2_demo_witness_family_bundle",
        container=container,
        witnesses=witnesses,
        refine_kwargs=dict(
            angle_steps=48,
            cert_n=64,
            translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
            initial_theta_intervals=2,
            initial_translation_intervals=2,
            max_depth=3,
            dps=50,
        ),
    )


if __name__ == "__main__":
    main()
