from __future__ import annotations

import json
import time
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import (
        build_translation_tension_poses_2d,
        cascaded_rigid_refinement,
        fixed_theta_toeplitz_gram_certificate_2d,
    )
    from extremal_geometry_lab.certificates import bridge_cascade
    from extremal_geometry_lab.certificates import bridge_cascade
except ModuleNotFoundError:
    import sys
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / 'packages'
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import (
        build_translation_tension_poses_2d,
        cascaded_rigid_refinement,
        fixed_theta_toeplitz_gram_certificate_2d,
    )
    from extremal_geometry_lab.certificates import bridge_cascade

OUTDIR = Path('results/certificates/v2_0ae_exploratory_toeplitz_sos')
STATE_MOVE = {
    'pal-seed': None,
    'small-cut': 'small-corner-cut',
    'moderate-cut': 'medium-corner-cut',
    'small-arc-rounding': 'small-arc-rounding',
}
WITNESS_NAMES = ('orbiform-stub', 'regular-3-gon')
TENSION_LABELS = ('near-boundary-feasible', 'negative-control')
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
WITNESS_POLYS = {label: poly for label, poly in NET.witnesses}


def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(label)


def _state_for_label(label: str) -> dict:
    seed = pal_seed()
    move_label = STATE_MOVE[label]
    return seed if move_label is None else _apply_move(seed, move_label)


def _cert_payload(cert) -> dict:
    return {
        'order': int(cert.order),
        'theta': float(cert.theta),
        'translation': [float(cert.translation[0]), float(cert.translation[1])],
        'matrix_size': int(cert.matrix_size),
        'min_eigenvalue': float(cert.min_eigenvalue),
        'max_coefficient_residual': float(cert.max_coefficient_residual),
        'truncated_gap_margin': float(cert.truncated_gap_margin),
        'tail_sup_proxy': float(cert.tail_sup_proxy),
        'shadow_lower_margin': float(cert.shadow_lower_margin),
        'status': str(cert.status),
        'details': dict(cert.details or {}),
    }


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    summary = {
        'schema_version': 'exploratory-toeplitz-sos.v1',
        'cases': [],
        'summary': {},
    }
    lines = [
        '# Extremal Geometry Lab v2.0ae — exploratory fixed-theta Toeplitz SOS lane',
        '',
        'This is a restricted fixed-\(\theta\) SOS experiment on the formerly truncation-limited witness/state pairs. Instead of a full SDP solve, it uses the canonical Hermitian Toeplitz Gram candidate whose diagonal sums reproduce the truncated trigonometric gap polynomial. PSD of this matrix is a sufficient certificate for nonnegativity of the truncated polynomial, but failure is only a failure of this restricted ansatz, not of the full SDP problem.',
        '',
    ]
    t0 = time.perf_counter()
    status_counts = {}
    pose_label_counts = {}
    for state_label in STATE_MOVE:
        state = _state_for_label(state_label)
        container = body_from_state(state)
        lines.append(f'## `{state_label}`')
        lines.append('')
        for witness_label in WITNESS_NAMES:
            witness = _named_body(witness_label, WITNESS_POLYS[witness_label])
            refinement = cascaded_rigid_refinement(container, witness, stages=bridge_cascade('real'), sticky_locked_priority=True)
            best = refinement.best_pose
            poses = build_translation_tension_poses_2d(
                container,
                witness,
                theta=float(best.rotation),
                translation=(float(best.translation[0]), float(best.translation[1])),
                sample_count=1024,
            )
            pose_map = {p.label: p for p in poses}
            lines.append(f'### `{witness_label}`')
            lines.append('')
            for label in TENSION_LABELS:
                pose = pose_map[label]
                cert = fixed_theta_toeplitz_gram_certificate_2d(
                    container,
                    witness,
                    theta=float(pose.theta),
                    translation=(float(pose.translation[0]), float(pose.translation[1])),
                    spectral_order=16,
                    gap_sample_count=512,
                    truncation_sample_count=1024,
                    truncation_extended_order=64,
                    gram_sample_count=1024,
                )
                rec = {
                    'state': state_label,
                    'witness': witness_label,
                    'pose_label': label,
                    'sampled_gap_margin_seeded': float(pose.sampled_gap_margin),
                    'imposed_shift': float(pose.imposed_shift),
                    'certificate': _cert_payload(cert),
                }
                summary['cases'].append(rec)
                status_counts[cert.status] = status_counts.get(cert.status, 0) + 1
                bucket = pose_label_counts.setdefault(label, {})
                bucket[cert.status] = bucket.get(cert.status, 0) + 1
                lines.append(
                    f"- `{label}`: sampled_margin=`{pose.sampled_gap_margin:.6f}`, status=`{cert.status}`, min_eig=`{cert.min_eigenvalue:.6e}`, coeff_resid=`{cert.max_coefficient_residual:.3e}`, shadow_lower_margin=`{cert.shadow_lower_margin:.6f}`"
                )
            lines.append('')
    runtime = time.perf_counter() - t0
    summary['summary'] = {
        'case_count': len(summary['cases']),
        'status_counts': status_counts,
        'pose_label_status_counts': pose_label_counts,
        'runtime_sec': round(runtime, 3),
    }
    lines += [
        '## Summary',
        f"- case_count: `{summary['summary']['case_count']}`",
        f"- status_counts: `{summary['summary']['status_counts']}`",
        f"- pose_label_status_counts: `{summary['summary']['pose_label_status_counts']}`",
        f"- runtime_sec: `{summary['summary']['runtime_sec']}`",
    ]
    (OUTDIR/'summary.json').write_text(json.dumps(summary, indent=2))
    (OUTDIR/'summary.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    main()
