from __future__ import annotations

import json
import time
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import (
        build_translation_tension_poses_2d,
        cascaded_rigid_refinement,
        shadow_spectral_crosscheck_from_refinement_2d,
        shadow_spectral_verify_pose_2d,
    )
    from extremal_geometry_lab.certificates import bridge_cascade
except ModuleNotFoundError:
    import sys
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / 'packages'
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import (
        build_translation_tension_poses_2d,
        cascaded_rigid_refinement,
        shadow_spectral_crosscheck_from_refinement_2d,
        shadow_spectral_verify_pose_2d,
    )
    from extremal_geometry_lab.certificates import bridge_cascade

OUTDIR = Path('results/certificates/v2_0ad_shadow_tension_batch_fix1')
PRIOR_SUMMARY = Path('results/certificates/v2_0ac_shadow_tension_batch/summary.json')
STATE_MOVE = {
    'pal-seed': None,
    'small-cut': 'small-corner-cut',
    'moderate-cut': 'medium-corner-cut',
    'small-arc-rounding': 'small-arc-rounding',
}
WITNESS_NAMES = ('orbiform-stub', 'disk-half', 'segment', 'regular-3-gon', 'regular-4-gon')
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
WITNESS_POLYS = {label: poly for label, poly in NET.witnesses}


def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(label)


def _state_for_label(label: str) -> dict:
    seed = pal_seed()
    move_label = STATE_MOVE[label]
    return seed if move_label is None else _apply_move(seed, move_label)


def _pose_payload(rep) -> dict:
    cmp = rep.contact_direction_comparison
    return {
        'theta': float(rep.theta),
        'translation': [float(rep.translation[0]), float(rep.translation[1])],
        'lp_translation': [float(rep.lp_translation[0]), float(rep.lp_translation[1])],
        'lp_margin': float(rep.lp_margin),
        'helly_lp_status': str(rep.helly_lp_status),
        'sampled_gap_margin': float(rep.sampled_gap_margin),
        'sampled_gap_margin_lp_translation': float(rep.sampled_gap_margin_lp_translation),
        'truncated_gap_margin': float(rep.truncated_gap_margin),
        'tail_sup_proxy': float(rep.tail_sup_proxy),
        'shadow_lower_margin': float(rep.shadow_lower_margin),
        'shadow_status': str(rep.shadow_status),
        'lp_translation_shift_norm': float(rep.lp_translation_shift_norm),
        'width_passed': None if rep.width_certificate is None else bool(rep.width_certificate.passed),
        'truncation_module': str(rep.truncation_module),
        'truncation_details': dict(rep.truncation_details or {}),
        'contact_direction_comparison': None if cmp is None else {
            'lane_a_angles': [float(x) for x in cmp.lane_a_angles],
            'lane_b_angles': [float(x) for x in cmp.lane_b_angles],
            'overlap_count': int(cmp.overlap_count),
            'overlap_ratio': float(cmp.overlap_ratio),
            'angle_tolerance': float(cmp.angle_tolerance),
            'details': dict(cmp.details or {}),
        },
        'details': dict(rep.details or {}),
    }


def _tension_payload(pose, rep, prior_shadow_report=None) -> dict:
    payload = {
        'label': str(pose.label),
        'theta': float(pose.theta),
        'translation': [float(pose.translation[0]), float(pose.translation[1])],
        'min_gap_angle': float(pose.min_gap_angle),
        'sampled_gap_margin_seeded': float(pose.sampled_gap_margin),
        'imposed_shift': float(pose.imposed_shift),
        'shift_direction': [float(pose.shift_direction[0]), float(pose.shift_direction[1])],
        'ground_truth_sampled_status': 'sampled-feasible' if float(pose.sampled_gap_margin) >= 0.0 else 'sampled-infeasible',
        'shadow_report': _pose_payload(rep),
        'details': dict(pose.details or {}),
    }
    if prior_shadow_report is not None:
        prior_tail = float(prior_shadow_report.get('tail_sup_proxy', 0.0))
        new_tail = float(payload['shadow_report']['tail_sup_proxy'])
        sampled_margin = float(payload['sampled_gap_margin_seeded'])
        payload['delta_vs_v2_0ac'] = {
            'prior_tail_sup_proxy': prior_tail,
            'new_tail_sup_proxy': new_tail,
            'tail_delta': new_tail - prior_tail,
            'prior_tail_to_margin_ratio': None if abs(sampled_margin) < 1.0e-15 else prior_tail / sampled_margin,
            'new_tail_to_margin_ratio': None if abs(sampled_margin) < 1.0e-15 else new_tail / sampled_margin,
            'prior_shadow_status': str(prior_shadow_report.get('shadow_status', 'unknown')),
            'new_shadow_status': str(payload['shadow_report']['shadow_status']),
        }
    return payload


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    prior_summary = json.loads(PRIOR_SUMMARY.read_text()) if PRIOR_SUMMARY.exists() else None
    prior_lookup = {}
    if prior_summary is not None:
        for st in prior_summary.get('states', []):
            for case in st.get('cases', []):
                for tension in case.get('tension_poses', []):
                    prior_lookup[(st.get('state'), case.get('witness'), tension.get('label'))] = tension.get('shadow_report', {})
    summary = {
        'schema_version': 'shadow-tension-batch.v2',
        'states': [],
        'summary': {},
    }
    lines = [
        '# Extremal Geometry Lab v2.0ad — shadow tension batch (Fix 1: high-k tail-fit envelope)',
        '',
        'This batch keeps Lane A as the global certifier for the seed pose, then constructs two translation-tension descendants of that pose: a near-boundary feasible sample and an explicit negative control. Lane B is then run on all three poses using the same batch harness as v2.0ac, but with the all-k tail envelope replaced by a high-k tail-fit envelope with a conservative monotone cap.',
        '',
    ]
    t0 = time.perf_counter()
    module_counts: dict[str, int] = {}
    tension_status_counts: dict[str, dict[str, int]] = {}
    base_agreement = 0
    for state_label in STATE_MOVE:
        state = _state_for_label(state_label)
        container = body_from_state(state)
        state_rec = {'state': state_label, 'cases': []}
        lines.append(f'## `{state_label}`')
        lines.append('')
        for witness_label in WITNESS_NAMES:
            witness = _named_body(witness_label, WITNESS_POLYS[witness_label])
            refinement = cascaded_rigid_refinement(
                container,
                witness,
                stages=bridge_cascade('real'),
                sticky_locked_priority=True,
            )
            cross = shadow_spectral_crosscheck_from_refinement_2d(
                container,
                witness,
                refinement,
                spectral_order=16,
                direction_count=64,
                gap_sample_count=512,
                truncation_sample_count=1024,
                truncation_extended_order=64,
                pose_limit=1,
            )
            if cross.lane_a_status == 'certified_feasible' and cross.lane_b_status == 'shadow-supportive':
                base_agreement += 1
            best = refinement.best_pose
            tension_poses = build_translation_tension_poses_2d(
                container,
                witness,
                theta=float(best.rotation),
                translation=(float(best.translation[0]), float(best.translation[1])),
                sample_count=1024,
            )
            tension_records = []
            for pose in tension_poses:
                rep = shadow_spectral_verify_pose_2d(
                    container,
                    witness,
                    theta=float(pose.theta),
                    translation=(float(pose.translation[0]), float(pose.translation[1])),
                    spectral_order=16,
                    direction_count=64,
                    gap_sample_count=512,
                    truncation_sample_count=1024,
                    truncation_extended_order=64,
                )
                prior_report = prior_lookup.get((state_label, witness_label, pose.label))
                tension_records.append(_tension_payload(pose, rep, prior_report))
                module_counts[rep.truncation_module] = module_counts.get(rep.truncation_module, 0) + 1
                bucket = tension_status_counts.setdefault(pose.label, {})
                bucket[rep.shadow_status] = bucket.get(rep.shadow_status, 0) + 1

            case = {
                'witness': witness_label,
                'lane_a_status': str(cross.lane_a_status),
                'lane_b_status': str(cross.lane_b_status),
                'disagreement_taxon': str(cross.disagreement_taxon),
                'base_best_pose': {
                    'rotation': float(best.rotation),
                    'translation': [float(best.translation[0]), float(best.translation[1])],
                    'sampled_margin': float(best.sampled_margin),
                    'sampled_max_violation': float(best.sampled_max_violation),
                    'certified_upper_violation': None if best.certified_upper_violation is None else float(best.certified_upper_violation),
                },
                'base_shadow_pose_report': _pose_payload(cross.pose_reports[0]),
                'counts': {
                    'feasible': int(len(refinement.certified_feasible_boxes)),
                    'infeasible': int(len(refinement.certified_infeasible_boxes)),
                    'unresolved': int(len(refinement.unresolved_boxes)),
                    'explored': int(len(refinement.explored_boxes)),
                },
                'tension_poses': tension_records,
            }
            state_rec['cases'].append(case)

            lines.append(f'### `{witness_label}`')
            lines.append(f"- base lane A / lane B / disagreement: `{case['lane_a_status']}` / `{case['lane_b_status']}` / `{case['disagreement_taxon']}`")
            lines.append(f"- base sampled margin: `{case['base_best_pose']['sampled_margin']:.6f}`")
            lines.append(f"- base truncation module: `{case['base_shadow_pose_report']['truncation_module']}`")
            for tension in tension_records:
                sr = tension['shadow_report']
                delta = tension.get('delta_vs_v2_0ac')
                delta_text = '' if delta is None else f", prior_tail=`{delta['prior_tail_sup_proxy']:.6f}`, new_tail=`{delta['new_tail_sup_proxy']:.6f}`, tail_ratio=`{delta['new_tail_to_margin_ratio'] if delta['new_tail_to_margin_ratio'] is None else round(delta['new_tail_to_margin_ratio'], 3)}`"
                lines.append(
                    f"  - `{tension['label']}`: sampled_status=`{tension['ground_truth_sampled_status']}`, sampled_margin=`{tension['sampled_gap_margin_seeded']:.6f}`, shadow=`{sr['shadow_status']}`, shadow_lower_margin=`{sr['shadow_lower_margin']:.6f}`, trunc_module=`{sr['truncation_module']}`{delta_text}"
                )
            lines.append('')
        summary['states'].append(state_rec)

    runtime = time.perf_counter() - t0
    delta_records = [
        tension.get('delta_vs_v2_0ac')
        for st in summary['states']
        for case in st['cases']
        for tension in case['tension_poses']
        if tension.get('delta_vs_v2_0ac') is not None
    ]
    unresolved_holdouts = [
        {
            'state': st['state'],
            'witness': case['witness'],
            'label': tension['label'],
            'shadow_status': tension['shadow_report']['shadow_status'],
            'tail_sup_proxy': tension['shadow_report']['tail_sup_proxy'],
            'sampled_gap_margin_seeded': tension['sampled_gap_margin_seeded'],
        }
        for st in summary['states']
        for case in st['cases']
        for tension in case['tension_poses']
        if tension['label'] == 'near-boundary-feasible' and tension['shadow_report']['shadow_status'] != 'shadow-truncation-positive'
    ]
    summary['summary'] = {
        'state_count': len(summary['states']),
        'witness_count': len(WITNESS_NAMES),
        'base_case_count': sum(len(st['cases']) for st in summary['states']),
        'base_agreement_feasible_count': int(base_agreement),
        'tension_pose_count': sum(len(case['tension_poses']) for st in summary['states'] for case in st['cases']),
        'truncation_module_counts': module_counts,
        'tension_shadow_status_counts': tension_status_counts,
        'delta_vs_v2_0ac': {
            'compared_case_count': len(delta_records),
            'tail_delta_min': None if not delta_records else min(float(rec['tail_delta']) for rec in delta_records),
            'tail_delta_max': None if not delta_records else max(float(rec['tail_delta']) for rec in delta_records),
            'tail_delta_mean': None if not delta_records else sum(float(rec['tail_delta']) for rec in delta_records) / len(delta_records),
        },
        'unresolved_near_boundary_holdouts': unresolved_holdouts,
        'runtime_sec': round(runtime, 3),
    }
    lines += [
        '## Summary',
        f"- base_case_count: `{summary['summary']['base_case_count']}`",
        f"- base_agreement_feasible_count: `{summary['summary']['base_agreement_feasible_count']}`",
        f"- tension_pose_count: `{summary['summary']['tension_pose_count']}`",
        f"- truncation_module_counts: `{summary['summary']['truncation_module_counts']}`",
        f"- tension_shadow_status_counts: `{summary['summary']['tension_shadow_status_counts']}`",
        f"- delta_vs_v2_0ac: `{summary['summary']['delta_vs_v2_0ac']}`",
        f"- unresolved_near_boundary_holdouts: `{summary['summary']['unresolved_near_boundary_holdouts']}`",
        f"- runtime_sec: `{summary['summary']['runtime_sec']}`",
    ]
    (OUTDIR / 'summary.json').write_text(json.dumps(summary, indent=2))
    (OUTDIR / 'summary.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    main()
