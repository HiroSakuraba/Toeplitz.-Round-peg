from __future__ import annotations

import json
import statistics
import time
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen
from extremal_geometry_lab.search import (
    accepted_descendants,
    distinct_target_signatures,
    proposals_at_depth,
    targeted_labels,
    targeted_proposals,
)

OUTDIR = Path("results/certificates/v2_0s_tier_b1_real_search")
PARAMS = dict(
    depth=3,
    beam_width=6,
    beam_policy="diversified",
    beam_diversity_reserve=2,
    n=512,
    targeted_move_limit=2,
    include_rejected=True,
)


def _screen_slack(prop) -> float | None:
    details = prop.screen_details or {}
    lower = details.get("certified_lower_width")
    req = details.get("required_width")
    if lower is None or req is None:
        return None
    return float(lower) - float(req)


def _summarize(label: str, structure_signal: str) -> dict:
    start = time.perf_counter()
    props = search_with_width_prescreen(structure_signal=structure_signal, **PARAMS)
    runtime = time.perf_counter() - start
    accepted = accepted_descendants(props)
    final = proposals_at_depth(props, PARAMS["depth"])
    targeted = targeted_proposals(props)
    targeted_final = [p for p in final if any(str(m).startswith("targeted-") for m in p.move_history)]
    slacks = [s for s in (_screen_slack(p) for p in final) if s is not None]
    final_buckets = sorted({int((p.annotations or {}).get("witness_target_score_bucket", -1)) for p in final if "witness_target_score_bucket" in (p.annotations or {})})
    return {
        "label": label,
        "structure_signal": structure_signal,
        "runtime_sec": round(runtime, 3),
        "total_passed_props": len(accepted),
        "max_depth": max((len(p.move_history) for p in accepted), default=0),
        "final_frontier_count": len(final),
        "targeted_total_count": len(targeted),
        "targeted_final_count": len(targeted_final),
        "distinct_target_signatures_total": len(distinct_target_signatures(targeted)),
        "distinct_target_signatures_final": len(distinct_target_signatures(targeted_final)),
        "target_score_buckets_final": final_buckets,
        "targeted_labels_final": targeted_labels(targeted_final),
        "avg_final_screen_slack": round(statistics.mean(slacks), 6) if slacks else None,
        "top_final_move_histories": [list(p.move_history) for p in final],
    }


def main() -> None:
    runs = [
        _summarize("Tier B1 first pass", "witness-net"),
        _summarize("Tier B1 second pass", "hybrid-witness-net"),
    ]
    comparison = {
        "runtime_ratio_hybrid_vs_witness_net": round(runs[1]["runtime_sec"] / runs[0]["runtime_sec"], 3) if runs[0]["runtime_sec"] else None,
        "targeted_final_delta": runs[1]["targeted_final_count"] - runs[0]["targeted_final_count"],
        "final_frontier_delta": runs[1]["final_frontier_count"] - runs[0]["final_frontier_count"],
    }
    payload = {
        "batch": "Tier B1 real Lebesgue search",
        "parameters": {
            "depth": PARAMS["depth"],
            "beam_width": PARAMS["beam_width"],
            "beam_policy": PARAMS["beam_policy"],
            "beam_diversity_reserve": PARAMS["beam_diversity_reserve"],
            "prescreen_n": PARAMS["n"],
            "targeted_move_limit": PARAMS["targeted_move_limit"],
            "adaptive_quick_fit": "12->24",
            "passed_proposal_count_rule": "screen_passed == True and len(move_history) > 0 (seed excluded)",
        },
        "runs": runs,
        "comparison": comparison,
    }
    lines = [
        "# Extremal Geometry Lab v2.0s — Tier B1 real search run",
        "",
        "Parameters:",
    ]
    for key, value in payload["parameters"].items():
        lines.append(f"- {key}: `{value}`")
    lines.append("")
    for run in runs:
        lines.append(f"## {run['label']} (`{run['structure_signal']}`)")
        lines.append(f"- runtime: `{run['runtime_sec']}` s")
        lines.append(f"- total passed proposals: `{run['total_passed_props']}`")
        lines.append(f"- final frontier count: `{run['final_frontier_count']}`")
        lines.append(f"- targeted proposals total: `{run['targeted_total_count']}`")
        lines.append(f"- targeted proposals in final frontier: `{run['targeted_final_count']}`")
        lines.append(f"- distinct target signatures (total/final): `{run['distinct_target_signatures_total']}` / `{run['distinct_target_signatures_final']}`")
        lines.append(f"- target score buckets in final frontier: `{run['target_score_buckets_final']}`")
        lines.append(f"- targeted labels in final frontier: `{run['targeted_labels_final']}`")
        lines.append(f"- average final screen slack: `{run['avg_final_screen_slack']}`")
        lines.append("- top final move histories:")
        for hist in run["top_final_move_histories"]:
            lines.append(f"  - `{hist}`")
        lines.append("")
    lines.append("## Comparison")
    for key, value in comparison.items():
        lines.append(f"- {key}: `{value}`")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    (OUTDIR / "summary.json").write_text(json.dumps(payload, indent=2))
    (OUTDIR / "summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
