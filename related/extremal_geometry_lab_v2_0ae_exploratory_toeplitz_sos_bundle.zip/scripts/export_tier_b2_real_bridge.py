from __future__ import annotations

import json
import time
from pathlib import Path

from extremal_geometry_lab.domains.lebesgue import (
    pal_seed,
    moves,
    build_polygon_witness_net_scaffold,
    export_candidate_witness_net_bundle,
    search_with_width_prescreen,
)
from extremal_geometry_lab.search import proposals_at_depth
from extremal_geometry_lab.certificates import bridge_cascade

OUTDIR = Path("results/certificates/v2_0t_tier_b2_real_bridge")
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
BRIDGE_LEVEL = "real"
REFINE_KWARGS = {
    'cascade_stages': bridge_cascade(BRIDGE_LEVEL),
    'sticky_locked_priority': True,
}
SEARCH_PARAMS = dict(
    depth=3,
    beam_width=6,
    beam_policy="diversified",
    beam_diversity_reserve=2,
    n=512,
    targeted_move_limit=2,
    include_rejected=True,
)


def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(f"move not available: {label}")


def _targeted_state() -> tuple[str, dict, list[str]]:
    props = search_with_width_prescreen(structure_signal="witness-net", **SEARCH_PARAMS)
    final = proposals_at_depth(props, SEARCH_PARAMS["depth"])
    targeted = [p for p in final if any(str(m).startswith("targeted-") for m in p.move_history)]
    if not targeted:
        raise RuntimeError("no targeted final-state survivor found in Tier B1 witness-net run")
    # Prefer the targeted-square-rounding survivor since it appears in both witness-net and hybrid runs.
    targeted.sort(key=lambda p: ("targeted-square-rounding" not in p.move_history, tuple(p.move_history)))
    chosen = targeted[0]
    return ("targeted-descendant", chosen.state, list(chosen.move_history))


def _state_specs() -> list[tuple[str, dict, list[str] | None]]:
    seed = pal_seed()
    mild = _apply_move(seed, "small-corner-cut")
    moderate = _apply_move(seed, "medium-corner-cut")
    rounded = _apply_move(seed, "small-arc-rounding")
    targeted_name, targeted_state, targeted_hist = _targeted_state()
    return [
        ("seed", seed, None),
        ("mild-cut", mild, ["small-corner-cut"]),
        ("moderate-cut", moderate, ["medium-corner-cut"]),
        ("rounded", rounded, ["small-arc-rounding"]),
        (targeted_name, targeted_state, targeted_hist),
    ]


def _summarize_state(name: str, state: dict, move_history: list[str] | None) -> dict:
    state_dir = OUTDIR / name
    print(f"[b2] exporting {name}...", flush=True)
    start = time.perf_counter()
    machine = export_candidate_witness_net_bundle(
        state_dir,
        state=state,
        net=NET,
        refine_kwargs=REFINE_KWARGS,
        state_name=name,
    )
    runtime = time.perf_counter() - start
    witnesses = machine.get("witnesses", [])
    joint = bool(machine.get("joint_certified"))
    passed = int(machine.get("passed_witness_count", 0))
    failed = int(machine.get("failed_witness_count", 0))
    incomplete = sum(1 for rec in witnesses if not rec.get("classification_complete", False))
    selected = sum(1 for rec in witnesses if rec.get("selected_box_index") is not None)
    summary = {
        "state_name": name,
        "runtime_sec": round(runtime, 3),
        "move_history": move_history,
        "joint_certified": joint,
        "passed_witness_count": passed,
        "failed_witness_count": failed,
        "classification_incomplete_count": incomplete,
        "selected_box_count": selected,
        "witness_count": int(machine.get("witness_count", len(witnesses))),
        "output_dir": str(state_dir),
    }
    print(f"[b2] done {name}: runtime={summary['runtime_sec']}s joint={summary['joint_certified']} passed={summary['passed_witness_count']}/{summary['witness_count']}", flush=True)
    return summary


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    specs = _state_specs()
    runs = [_summarize_state(name, state, hist) for name, state, hist in specs]
    payload = {
        "batch": "Tier B2 real bridge/export pass",
        "parameters": {
            "representative_states": [name for name, _, _ in specs],
            "max_vertices": 4,
            "bridge_level": BRIDGE_LEVEL,
            "refine_kwargs": REFINE_KWARGS,
        },
        "runs": runs,
        "all_joint_certified": all(run["joint_certified"] for run in runs),
        "all_exports_completed": True,
        "total_runtime_sec": round(sum(run["runtime_sec"] for run in runs), 3),
    }
    lines = [
        "# Extremal Geometry Lab v2.0s — Tier B2 real bridge/export run",
        "",
        "Representative states:",
    ]
    for name in payload["parameters"]["representative_states"]:
        lines.append(f"- `{name}`")
    lines += [
        "",
        f"- max_vertices: `{payload['parameters']['max_vertices']}`",
        f"- bridge_level: `{payload['parameters']['bridge_level']}`",
        f"- refine_kwargs: `{payload['parameters']['refine_kwargs']}`",
        "",
    ]
    for run in runs:
        lines.append(f"## {run['state_name']}")
        lines.append(f"- runtime: `{run['runtime_sec']}` s")
        lines.append(f"- move_history: `{run['move_history']}`")
        lines.append(f"- joint_certified: `{run['joint_certified']}`")
        lines.append(f"- passed_witness_count: `{run['passed_witness_count']}` / `{run['witness_count']}`")
        lines.append(f"- failed_witness_count: `{run['failed_witness_count']}`")
        lines.append(f"- classification_incomplete_count: `{run['classification_incomplete_count']}`")
        lines.append(f"- selected_box_count: `{run['selected_box_count']}`")
        lines.append(f"- output_dir: `{run['output_dir']}`")
        lines.append("")
    lines.append("## Batch result")
    lines.append(f"- all_exports_completed: `{payload['all_exports_completed']}`")
    lines.append(f"- all_joint_certified: `{payload['all_joint_certified']}`")
    lines.append(f"- total_runtime_sec: `{payload['total_runtime_sec']}`")

    (OUTDIR / "summary.json").write_text(json.dumps(payload, indent=2))
    (OUTDIR / "summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
