from __future__ import annotations

import json
import time
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core.rigid_fit import cascaded_rigid_refinement
    from extremal_geometry_lab.certificates.formats import select_joint_feasible_box
    from extremal_geometry_lab.certificates import bridge_ladder_sequence, bridge_cascade
except ModuleNotFoundError:
    import sys
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / "packages"
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core.rigid_fit import cascaded_rigid_refinement
    from extremal_geometry_lab.certificates.formats import select_joint_feasible_box
    from extremal_geometry_lab.certificates import bridge_ladder_sequence, bridge_cascade

OUTDIR = Path("results/certificates/v2_0t_tier_b2a_seed_bridge_calibration")
LADDER = bridge_ladder_sequence(["light", "real", "confirm"])


def _classify(refinement) -> str:
    feasible = len(refinement.certified_feasible_boxes)
    unresolved = len(refinement.unresolved_boxes)
    if feasible > 0:
        return "certified_feasible"
    if unresolved == 0:
        return "certified_infeasible"
    return "incomplete"


def _min_upper(refinement) -> float | None:
    vals = []
    for box in list(refinement.certified_feasible_boxes) + list(refinement.certified_infeasible_boxes) + list(refinement.unresolved_boxes):
        details = getattr(box, "details", {}) or {}
        v = details.get("certified_upper_violation")
        if v is not None:
            vals.append(float(v))
    return None if not vals else min(vals)


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    payload: dict = {
        "batch": "Tier B2a seed-only bridge calibration",
        "state": "seed",
        "witnesses": [],
        "ladder": LADDER,
    }

    lines = [
        "# Extremal Geometry Lab v2.0s — Tier B2a seed-only bridge calibration",
        "",
        "State: `seed`",
        "",
        "Ladder:",
    ]
    for step in LADDER:
        lines.append(f"- `{step['name']}`: angle_steps={step['angle_steps']}, cert_n={step['cert_n']}, max_depth={step['max_depth']}")
    lines.append("")

    for idx, (label, poly) in enumerate(net.witnesses):
        witness = _named_body(label, poly)
        witness_rec: dict = {"index": idx, "label": label, "runs": []}
        lines.append(f"## {idx:02d} `{label}`")
        found = False
        for step in LADDER:
            kwargs = {'cascade_stages': bridge_cascade(step["name"]), 'sticky_locked_priority': True}
            print(f"[b2a] {label} {step['name']} ...", flush=True)
            start = time.perf_counter()
            refinement = cascaded_rigid_refinement(container, witness, stages=bridge_cascade(step["name"]), sticky_locked_priority=True)
            runtime = time.perf_counter() - start
            sel_idx, _ = select_joint_feasible_box(refinement)
            rec = {
                "step": step["name"],
                "refine_kwargs": kwargs,
                "runtime_sec": round(runtime, 3),
                "classification": _classify(refinement),
                "has_certified_feasible_box": bool(len(refinement.certified_feasible_boxes) > 0),
                "classification_complete": bool(len(refinement.unresolved_boxes) == 0),
                "selected_box_index": None if sel_idx is None else int(sel_idx),
                "counts": {
                    "certified_feasible_boxes": len(refinement.certified_feasible_boxes),
                    "certified_infeasible_boxes": len(refinement.certified_infeasible_boxes),
                    "unresolved_boxes": len(refinement.unresolved_boxes),
                    "explored_boxes": len(refinement.explored_boxes),
                },
                "best_pose": {
                    "rotation": float(refinement.best_pose.rotation),
                    "translation": [float(refinement.best_pose.translation[0]), float(refinement.best_pose.translation[1])],
                    "sampled_margin": float(refinement.best_pose.sampled_margin),
                    "certified_upper_violation": None if refinement.best_pose.certified_upper_violation is None else float(refinement.best_pose.certified_upper_violation),
                },
                "min_certified_upper_violation": _min_upper(refinement),
            }
            witness_rec["runs"].append(rec)
            lines.extend([
                f"### {step['name']}",
                f"- runtime: `{rec['runtime_sec']}` s",
                f"- classification: `{rec['classification']}`",
                f"- has_certified_feasible_box: `{rec['has_certified_feasible_box']}`",
                f"- classification_complete: `{rec['classification_complete']}`",
                f"- selected_box_index: `{rec['selected_box_index']}`",
                f"- counts: `{rec['counts']}`",
                f"- best sampled margin: `{rec['best_pose']['sampled_margin']}`",
                f"- best certified upper violation: `{rec['best_pose']['certified_upper_violation']}`",
                f"- min certified upper violation: `{rec['min_certified_upper_violation']}`",
                "",
            ])
            if rec["has_certified_feasible_box"]:
                found = True
                break
        witness_rec["stopped_after_first_feasible"] = bool(found)
        payload["witnesses"].append(witness_rec)

    total_runs = sum(len(w["runs"]) for w in payload["witnesses"])
    any_feasible = any(any(r["has_certified_feasible_box"] for r in w["runs"]) for w in payload["witnesses"])
    payload["summary"] = {
        "witness_count": len(payload["witnesses"]),
        "total_refinement_runs": total_runs,
        "any_certified_feasible": bool(any_feasible),
        "witnesses_with_any_feasible": [w["label"] for w in payload["witnesses"] if any(r["has_certified_feasible_box"] for r in w["runs"])],
        "witnesses_always_incomplete": [w["label"] for w in payload["witnesses"] if all(r["classification"] == "incomplete" for r in w["runs"])],
        "total_runtime_sec": round(sum(r["runtime_sec"] for w in payload["witnesses"] for r in w["runs"]), 3),
    }
    lines += [
        "## Summary",
        f"- witness_count: `{payload['summary']['witness_count']}`",
        f"- total_refinement_runs: `{payload['summary']['total_refinement_runs']}`",
        f"- any_certified_feasible: `{payload['summary']['any_certified_feasible']}`",
        f"- witnesses_with_any_feasible: `{payload['summary']['witnesses_with_any_feasible']}`",
        f"- witnesses_always_incomplete: `{payload['summary']['witnesses_always_incomplete']}`",
        f"- total_runtime_sec: `{payload['summary']['total_runtime_sec']}`",
    ]

    (OUTDIR / "summary.json").write_text(json.dumps(payload, indent=2))
    (OUTDIR / "summary.md").write_text("\n".join(lines))


if __name__ == "__main__":
    main()
