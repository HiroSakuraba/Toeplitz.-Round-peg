from __future__ import annotations
from pathlib import Path
_REAL_PKG = Path(__file__).resolve().parents[2] / 'packages' / 'extremal_geometry_lab'
__path__ = [str(_REAL_PKG)] if _REAL_PKG.is_dir() else []
