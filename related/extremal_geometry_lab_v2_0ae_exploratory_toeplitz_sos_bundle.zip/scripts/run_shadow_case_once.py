from __future__ import annotations

import json
import sys
import time
from pathlib import Path

try:
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import shadow_spectral_crosscheck_from_refinement_2d, cascaded_rigid_refinement
    from extremal_geometry_lab.certificates import bridge_cascade
except ModuleNotFoundError:
    ROOT = Path(__file__).resolve().parents[1]
    PKG = ROOT / 'packages'
    if str(PKG) not in sys.path:
        sys.path.insert(0, str(PKG))
    from extremal_geometry_lab.domains.lebesgue import pal_seed, moves, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body
    from extremal_geometry_lab.core import shadow_spectral_crosscheck_from_refinement_2d, cascaded_rigid_refinement
    from extremal_geometry_lab.certificates import bridge_cascade

STATE_MOVE = {
    'pal-seed': None,
    'small-cut': 'small-corner-cut',
    'moderate-cut': 'medium-corner-cut',
    'small-arc-rounding': 'small-arc-rounding',
}
NET = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
WITNESS_POLYS = {label: poly for label, poly in NET.witnesses}


def _apply_move(state: dict, label: str) -> dict:
    for move_label, child in moves(state):
        if move_label == label:
            return child
    raise KeyError(label)


def _state_for_label(label: str) -> dict:
    seed = pal_seed()
    move_label = STATE_MOVE[label]
    return seed if move_label is None else _apply_move(seed, move_label)


def _pose_digest(rep) -> dict:
    cmp = rep.contact_direction_comparison
    return {
        'theta': float(rep.theta),
        'translation': [float(rep.translation[0]), float(rep.translation[1])],
        'lp_translation': [float(rep.lp_translation[0]), float(rep.lp_translation[1])],
        'lp_margin': float(rep.lp_margin),
        'helly_lp_status': str(rep.helly_lp_status),
        'sampled_gap_margin': float(rep.sampled_gap_margin),
        'sampled_gap_margin_lp_translation': float(rep.sampled_gap_margin_lp_translation),
        'truncated_gap_margin': float(rep.truncated_gap_margin),
        'tail_sup_proxy': float(rep.tail_sup_proxy),
        'shadow_lower_margin': float(rep.shadow_lower_margin),
        'shadow_status': str(rep.shadow_status),
        'lp_translation_shift_norm': float(rep.lp_translation_shift_norm),
        'width_passed': None if rep.width_certificate is None else bool(rep.width_certificate.passed),
        'contact_direction_comparison': None if cmp is None else {
            'lane_a_angles': [float(x) for x in cmp.lane_a_angles],
            'lane_b_angles': [float(x) for x in cmp.lane_b_angles],
            'overlap_count': int(cmp.overlap_count),
            'overlap_ratio': float(cmp.overlap_ratio),
            'angle_tolerance': float(cmp.angle_tolerance),
            'details': dict(cmp.details or {}),
        },
        'details': dict(rep.details or {}),
    }


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print('usage: run_shadow_case_once.py <state-label> <witness-label>', file=sys.stderr)
        return 2
    state_label, witness_label = argv[1], argv[2]
    state = _state_for_label(state_label)
    container = body_from_state(state)
    witness = _named_body(witness_label, WITNESS_POLYS[witness_label])
    start = time.perf_counter()
    refinement = cascaded_rigid_refinement(
        container,
        witness,
        stages=bridge_cascade('real'),
        sticky_locked_priority=True,
    )
    cross = shadow_spectral_crosscheck_from_refinement_2d(
        container,
        witness,
        refinement,
        spectral_order=24,
        direction_count=96,
        gap_sample_count=768,
        pose_limit=2,
    )
    runtime = time.perf_counter() - start
    disagreement = dict((cross.details or {}).get('disagreement_summary', {}))
    payload = {
        'state': state_label,
        'witness': witness_label,
        'runtime_sec': round(runtime, 3),
        'lane_a_status': str(cross.lane_a_status),
        'lane_b_status': str(cross.lane_b_status),
        'disagreement_taxon': str(cross.disagreement_taxon),
        'disagreement_summary': disagreement,
        'counts': {
            'feasible': int(len(refinement.certified_feasible_boxes)),
            'infeasible': int(len(refinement.certified_infeasible_boxes)),
            'unresolved': int(len(refinement.unresolved_boxes)),
            'explored': int(len(refinement.explored_boxes)),
        },
        'best_pose': {
            'rotation': float(refinement.best_pose.rotation),
            'translation': [float(refinement.best_pose.translation[0]), float(refinement.best_pose.translation[1])],
            'sampled_margin': float(refinement.best_pose.sampled_margin),
            'sampled_max_violation': float(refinement.best_pose.sampled_max_violation),
            'certified_upper_violation': None if refinement.best_pose.certified_upper_violation is None else float(refinement.best_pose.certified_upper_violation),
        },
        'pose_reports': [_pose_digest(rep) for rep in cross.pose_reports],
    }
    print(json.dumps(payload))
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
