
from __future__ import annotations
import json
import numpy as np

from extremal_geometry_lab.core import (
    ConvexPolygon2D,
    buffer_polygon,
    certified_area_polygon,
    certified_contains_polygon,
    certified_universal_cover,
)
from extremal_geometry_lab.domains.lebesgue import pal_seed, reduced_witness_family
from extremal_geometry_lab.domains.moser import straight_worm, composite_hard_worm
from extremal_geometry_lab.domains.hadwiger3d import fibonacci_sphere, certified_illumination_cover


def main() -> None:
    seed = pal_seed()
    poly = seed["polygon"]
    buffered = buffer_polygon(poly, 0.05)
    area_cert = certified_area_polygon(buffered)
    family = reduced_witness_family()
    cover_cert = certified_universal_cover(buffered, family)
    normals = fibonacci_sphere(24)
    dirs = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float)
    illum = certified_illumination_cover(normals, dirs)
    payload = {
        "area": area_cert.details,
        "cover_passed": cover_cert.passed,
        "cover_margin": cover_cert.lower_margin,
        "illumination": illum,
        "worm_points": straight_worm().points.tolist(),
        "composite_vertices": composite_hard_worm().vertices[:4].tolist(),
    }
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
