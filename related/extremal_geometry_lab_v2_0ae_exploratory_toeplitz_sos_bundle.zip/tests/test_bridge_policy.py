from extremal_geometry_lab.certificates import BRIDGE_LADDER_LEVELS, BRIDGE_CASCADE_LEVELS, bridge_refine_kwargs, bridge_ladder_sequence, bridge_cascade, sticky_locked_priority_score


def test_bridge_refine_kwargs_real_level_is_explicit_and_seeded():
    kwargs = bridge_refine_kwargs("real")
    assert kwargs["angle_steps"] == 48
    assert kwargs["cert_n"] == 96
    assert kwargs["max_depth"] == 2
    assert kwargs["use_rotation_seed_translation_bounds"] is True
    assert kwargs["localized_deepening"] is True
    assert kwargs["localized_far_box_depth_penalty"] == 1


def test_bridge_ladder_sequence_orders_light_real_confirm():
    ladder = bridge_ladder_sequence(["light", "real", "confirm"])
    assert [step["name"] for step in ladder] == ["light", "real", "confirm"]
    assert ladder[0]["max_depth"] < ladder[1]["max_depth"] < ladder[2]["max_depth"]
    assert set(BRIDGE_LADDER_LEVELS) >= {"light", "real", "confirm"}


def test_bridge_cascade_real_contains_light_then_real():
    cascade = bridge_cascade("real")
    assert [stage["name"] for stage in cascade] == ["light", "real"]
    assert set(BRIDGE_CASCADE_LEVELS) >= {"light", "real", "confirm"}


def test_sticky_locked_priority_score_prefers_triangle_over_segment():
    tri = sticky_locked_priority_score(witness_name="regular-3-gon", width_spread=0.2, thin_direction_count=3)
    seg = sticky_locked_priority_score(witness_name="segment", width_spread=0.4, thin_direction_count=2)
    assert tri > seg


def test_bridge_cascade_defaults_anisotropic_off():
    cascade = bridge_cascade("confirm")
    assert all(stage["anisotropic_policy"] == "off" for stage in cascade)


def test_bridge_cascade_can_enable_priority_anisotropic():
    cascade = bridge_cascade("real", anisotropic_policy="priority")
    assert all(stage["anisotropic_policy"] == "priority" for stage in cascade)
