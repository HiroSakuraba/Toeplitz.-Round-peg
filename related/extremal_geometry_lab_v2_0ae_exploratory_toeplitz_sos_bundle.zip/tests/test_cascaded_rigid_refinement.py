from extremal_geometry_lab.core import (
    disk_body,
    cascaded_rigid_refinement,
    refine_body_in_body_support_rigid_2d,
)
from extremal_geometry_lab.certificates import bridge_cascade
from extremal_geometry_lab.certificates.formats import refinement_bundle_payload


def test_refine_body_in_body_support_rigid_records_explicit_theta_seed_boxes():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        translation_bounds=((-0.5, 0.5), (-0.5, 0.5)),
        initial_theta_boxes=[(-0.1, 0.1), (0.2, 0.4)],
        initial_translation_intervals=2,
        max_depth=1,
        anisotropic_seed_spans=(0.2, 1.0, 1.0),
    )
    details = ref.best_pose.details
    assert details["theta_seed_source"] == "explicit-seed-boxes"
    assert details["theta_seed_box_count"] == 2
    assert details["anisotropic_seed_spans"] == [0.2, 1.0, 1.0]


def test_cascaded_rigid_refinement_records_stage_provenance_and_exports_it():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = cascaded_rigid_refinement(
        container,
        witness,
        stages=bridge_cascade("real"),
        sticky_locked_priority=False,
    )
    details = ref.best_pose.details
    assert details["cascaded_refinement"] is True
    assert details["cascade_stage_count"] == 2
    assert [rec["stage_name"] for rec in details["cascade_stage_records"]] == ["light", "real"]
    payload = refinement_bundle_payload(ref, container_name="outer", witness_name="inner", container=container, witness=witness)
    assert payload["cascaded_refinement"] is True
    assert payload["cascade_stage_count"] == 2
    assert len(payload["cascade_stage_records"]) == 2


def test_refine_body_in_body_support_rigid_can_disable_anisotropic_splitting():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        translation_bounds=((-0.5, 0.5), (-0.5, 0.5)),
        initial_theta_boxes=[(-0.1, 0.1), (0.2, 0.4)],
        initial_translation_intervals=2,
        max_depth=1,
        anisotropic_seed_spans=(0.2, 1.0, 1.0),
        use_anisotropic_splitting=False,
    )
    details = ref.best_pose.details
    assert details["use_anisotropic_splitting"] is False
    assert details["anisotropic_seed_spans"] == [0.2, 1.0, 1.0]


def test_cascaded_rigid_refinement_records_anisotropic_policy():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = cascaded_rigid_refinement(
        container,
        witness,
        stages=bridge_cascade("real", anisotropic_policy="priority"),
        sticky_locked_priority=False,
    )
    records = ref.best_pose.details["cascade_stage_records"]
    assert all(rec["anisotropic_policy"] == "priority" for rec in records)
    assert all(rec["anisotropic_enabled"] is False for rec in records)
