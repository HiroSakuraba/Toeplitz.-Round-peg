import json
from pathlib import Path

from extremal_geometry_lab.core import ConvexPolygon2D, body_from_polygon, refine_body_in_body_support_rigid_2d
from extremal_geometry_lab.certificates import export_rigid_motion_refinement_bundle, support_cell_bounds_payload, self_verifying_box_payload, rounded_candidate_self_verify_payload, export_rounded_candidate_bundle


def _make_instance():
    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    witness = body_from_polygon(ConvexPolygon2D([
        [-0.4, -0.2],
        [0.6, -0.2],
        [0.1, 0.8],
    ], name="inner-triangle"))
    refinement = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=48,
        translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=3,
        dps=50,
    )
    return container, witness, refinement


def test_support_cell_bounds_payload_tracks_box_upper_violation():
    container, witness, refinement = _make_instance()
    assert refinement.certified_feasible_boxes
    box = refinement.certified_feasible_boxes[0]
    payload = support_cell_bounds_payload(container, witness, box=box, n=box.details["cert_n"], dps=box.details["dps"])
    assert payload["schema_version"] == "support-cell-bounds.v1"
    assert payload["support_cell_count"] == box.details["cert_n"]
    assert payload["max_cell_upper_violation"] <= box.details["certified_upper_violation"] + 1e-9
    assert len(payload["cells"]) == box.details["cert_n"]


def test_self_verifying_box_payload_contains_recipe_and_vertices():
    container, witness, refinement = _make_instance()
    assert refinement.certified_feasible_boxes
    box = refinement.certified_feasible_boxes[0]
    payload = self_verifying_box_payload(container, witness, box=box, n=64, dps=50)
    assert payload["schema_version"] == "rigid-motion-self-verify.v1"
    assert payload["claim"] == "feasible"
    assert "verification_algorithm" in payload
    assert len(payload["container_vertices"]) == 4
    assert len(payload["witness_vertices"]) == 3


def test_export_rigid_motion_refinement_bundle_writes_json_and_markdown(tmp_path: Path):
    container, witness, refinement = _make_instance()
    base = tmp_path / "demo_bundle"
    payload = export_rigid_motion_refinement_bundle(
        base,
        container=container,
        witness=witness,
        refinement=refinement,
        support_box_index=0,
        support_cell_count=None,
        dps=50,
    )
    assert base.with_suffix(".json").exists()
    assert base.with_suffix(".md").exists()
    data = json.loads(base.with_suffix(".json").read_text(encoding="utf-8"))
    assert data["schema_version"] == "rigid-motion-refinement.v1"
    assert data["container"] == "outer-square"
    assert data["witness"] == "inner-triangle"
    assert "support_cell_bounds" in data
    assert data["support_cell_bounds"]["schema_version"] == "support-cell-bounds.v1"
    assert data["self_verifying_certificate"]["schema_version"] == "rigid-motion-self-verify.v1"
    assert payload["counts"]["explored_boxes"] >= 1
    md = base.with_suffix(".md").read_text(encoding="utf-8")
    assert "Rigid-motion certificate bundle" in md
    assert "Support-cell audit for exported box" in md



def test_rounded_candidate_self_verify_payload_contains_construction_recipe():
    from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen, prescreen_candidate_state

    props = search_with_width_prescreen(depth=1, n=128, include_rejected=True)
    rounded = next(p for p in props if p.state.get("arc_replacements"))
    result = prescreen_candidate_state(rounded.state, width_lb=1.0, n=128)
    payload = rounded_candidate_self_verify_payload(
        family="lebesgue-rounded",
        state_name="rounded-demo",
        state=rounded.state,
        result=result,
    )
    assert payload["schema_version"] == "rounded-candidate-self-verify.v1"
    assert payload["construction"]["kind"] == "rounded-minkowski"
    assert payload["construction"]["rounded_radius"] > 0.0
    assert len(payload["base_polygon_vertices"]) >= 3
    assert "Support-sum rule" in payload["theorems_used"][0]
    assert "Minkowski sum" in payload["verification_algorithm"] or "support-sum" in payload["verification_algorithm"]


def test_export_rounded_candidate_bundle_writes_files(tmp_path: Path):
    from extremal_geometry_lab.domains.lebesgue import search_with_width_prescreen, prescreen_candidate_state

    props = search_with_width_prescreen(depth=1, n=128, include_rejected=True)
    rounded = next(p for p in props if p.state.get("arc_replacements"))
    result = prescreen_candidate_state(rounded.state, width_lb=1.0, n=128)
    base = tmp_path / "rounded_bundle"
    payload = export_rounded_candidate_bundle(
        base,
        family="lebesgue-rounded",
        state_name="rounded-demo",
        state=rounded.state,
        result=result,
    )
    assert base.with_suffix('.json').exists()
    assert base.with_suffix('.md').exists()
    data = json.loads(base.with_suffix('.json').read_text(encoding='utf-8'))
    assert data["schema_version"] == "rounded-candidate-self-verify.v1"
    assert data["construction"]["kind"] == "rounded-minkowski"
    assert payload["claim"] in {"width-prescreen-pass", "width-prescreen-fail"}



def test_minimal_contact_certificate_payload_uses_at_most_three_contacts():
    from extremal_geometry_lab.certificates import minimal_contact_certificate_payload
    container, witness, refinement = _make_instance()
    payload = minimal_contact_certificate_payload(container, witness, refinement.best_pose)
    assert payload["schema_version"] == "minimal-contact-certificate.v1"
    assert payload["contact_cardinality"] <= 3
    assert len(payload["active_indices"]) == payload["contact_cardinality"]
    assert payload["max_global_violation"] <= 1e-6


def test_export_bundle_includes_minimal_contact_certificate(tmp_path: Path):
    container, witness, refinement = _make_instance()
    base = tmp_path / "demo_bundle_min_contacts"
    payload = export_rigid_motion_refinement_bundle(
        base,
        container=container,
        witness=witness,
        refinement=refinement,
        support_box_index=0,
        support_cell_count=None,
        dps=50,
    )
    data = json.loads(base.with_suffix(".json").read_text(encoding="utf-8"))
    assert "best_pose_minimal_contact_certificate" in data
    mc = data["best_pose_minimal_contact_certificate"]
    assert mc["schema_version"] == "minimal-contact-certificate.v1"
    assert mc["contact_cardinality"] <= 3
    md = base.with_suffix(".md").read_text(encoding="utf-8")
    assert "Minimal active-contact certificate for best pose" in md
