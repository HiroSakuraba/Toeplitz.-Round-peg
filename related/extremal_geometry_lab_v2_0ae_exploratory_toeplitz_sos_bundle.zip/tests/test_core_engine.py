
from __future__ import annotations
import numpy as np

from extremal_geometry_lab.core import ConvexPolygon2D
from extremal_geometry_lab.core.minkowski import sampled_disk, minkowski_sum_polygons, difference_body_polygon, buffer_polygon
from extremal_geometry_lab.core.support import body_from_polygon, constant_width_residual
from extremal_geometry_lab.core.canonicalize import canonical_polygon_signature
from extremal_geometry_lab.core.certify import certified_area_polygon
from extremal_geometry_lab.domains.lebesgue import pal_seed, reduced_witness_family
from extremal_geometry_lab.domains.hadwiger3d import fibonacci_sphere, certified_illumination_cover


def square() -> ConvexPolygon2D:
    return ConvexPolygon2D(np.array([[-1,-1],[1,-1],[1,1],[-1,1]], dtype=float), name="square")


def test_polygon_minkowski_sum_and_area_positive():
    poly = minkowski_sum_polygons(square(), sampled_disk(0.1, 16))
    cert = certified_area_polygon(poly)
    assert cert.passed
    assert cert.details["area"] > 0.0


def test_difference_body_nonempty():
    diff = difference_body_polygon(square())
    assert diff.vertices.shape[0] >= 4


def test_constant_width_residual_for_disk_like_polygon_small():
    body = body_from_polygon(sampled_disk(1.0, 128))
    assert constant_width_residual(body, 2.0, n=128) < 0.1


def test_canonical_signature_dihedral_stable():
    sig1 = canonical_polygon_signature(square())
    sig2 = canonical_polygon_signature(square().rotated(np.pi / 2.0))
    assert sig1 == sig2


def test_lebesgue_seed_and_witness_family_present():
    seed = pal_seed()
    family = reduced_witness_family()
    assert seed["family"] == "pal-descended"
    assert len(family) >= 2


def test_hadwiger_sphere_cover_runs():
    normals = fibonacci_sphere(32)
    dirs = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float)
    result = certified_illumination_cover(normals, dirs)
    assert result["total"] == 32
