
from __future__ import annotations

from extremal_geometry_lab.domains.moser import reduced_worm_family, composite_hard_worm
from extremal_geometry_lab.domains.hadwiger3d import constant_width_residual_3d
from extremal_geometry_lab.core.geometry_types import SupportFunction3D
import numpy as np


def test_moser_family_nonempty():
    fam = reduced_worm_family()
    assert len(fam) >= 4
    assert composite_hard_worm().vertices.shape[0] >= 3


def test_constant_width_residual_3d_runs():
    ball = SupportFunction3D(lambda u: 1.0, name="unit-ball")
    res = constant_width_residual_3d(ball, 2.0)
    assert res < 1e-9
