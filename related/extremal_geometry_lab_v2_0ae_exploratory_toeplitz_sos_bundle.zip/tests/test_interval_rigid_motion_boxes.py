import math

from extremal_geometry_lab.core import disk_body, segment_body, refine_body_in_body_support_rotation_2d


def test_feasible_motion_boxes_exist_for_nested_disks():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = refine_body_in_body_support_rotation_2d(container, witness, angle_steps=64, cert_n=256, initial_intervals=8, max_depth=2)
    assert ref.has_certified_feasible_interval
    assert len(ref.certified_feasible_motion_boxes) >= 1
    box = ref.certified_feasible_motion_boxes[0]
    assert box.translation_box.l2_radius > 0.0


def test_segment_witness_produces_interval_box():
    container = disk_body(2.0)
    witness = segment_body(1.0)
    ref = refine_body_in_body_support_rotation_2d(container, witness, angle_steps=64, cert_n=256, initial_intervals=8, max_depth=3)
    assert len(ref.certified_feasible_motion_boxes) >= 1
    for box in ref.certified_feasible_motion_boxes:
        assert box.certified_feasible
        assert not box.certified_infeasible
