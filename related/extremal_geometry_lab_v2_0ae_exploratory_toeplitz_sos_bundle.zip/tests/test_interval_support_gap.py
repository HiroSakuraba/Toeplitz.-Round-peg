import math

from extremal_geometry_lab.core import (
    body_from_polygon,
    ConvexPolygon2D,
    certified_support_gap_bound_2d,
    certified_support_gap_bound_2d_interval,
    interval_support_bounds_2d,
    segment_body,
    capsule_body,
    disk_body,
)


def test_interval_support_bounds_exist_for_polygon_body():
    square = body_from_polygon(ConvexPolygon2D([
        [-1.0, -1.0],
        [1.0, -1.0],
        [1.0, 1.0],
        [-1.0, 1.0],
    ], name="square"))
    bounds = interval_support_bounds_2d(square, 0.0, math.pi / 8.0, dps=60)
    assert bounds is not None
    lo, hi = bounds
    assert lo <= hi
    assert hi > 0.0


def test_interval_certificate_passes_for_nested_polygons():
    outer = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer"))
    inner = body_from_polygon(ConvexPolygon2D([
        [-0.5, -0.25],
        [0.75, -0.25],
        [0.2, 0.8],
    ], name="inner"))
    cert = certified_support_gap_bound_2d_interval(outer, inner, n=128, dps=60)
    assert cert.passed
    assert cert.certified_upper_violation <= 0.0
    assert cert.details["method"] == "interval-polygon-support"


def test_interval_support_bounds_exist_for_analytic_segment_body():
    seg = segment_body(2.0, theta=0.0)
    bounds = interval_support_bounds_2d(seg, 0.0, math.pi / 4.0, dps=60)
    assert bounds is not None
    lo, hi = bounds
    assert 0.70 <= lo <= 1.0
    assert abs(hi - 1.0) < 1e-12


def test_interval_certificate_passes_for_nested_analytic_bodies():
    outer = disk_body(2.0)
    inner = capsule_body(segment_length=1.0, radius=0.4, theta=0.0)
    cert = certified_support_gap_bound_2d_interval(outer, inner, n=128, dps=60)
    assert cert.passed
    assert cert.certified_upper_violation <= 0.0
    assert cert.details["method"] == "interval-support-hook"
    assert cert.details["body_methods"]["container"] == "support-hook"
    assert cert.details["body_methods"]["target"] == "support-hook"


def test_interval_certificate_is_no_looser_than_lipschitz_for_polygons():
    outer = body_from_polygon(ConvexPolygon2D([
        [-2.0, -1.0],
        [2.0, -1.0],
        [2.0, 1.0],
        [-2.0, 1.0],
    ], name="outer-rect"))
    inner = body_from_polygon(ConvexPolygon2D([
        [-1.0, -0.5],
        [1.0, -0.5],
        [1.0, 0.5],
        [-1.0, 0.5],
    ], name="inner-rect"))
    interval_cert = certified_support_gap_bound_2d_interval(outer, inner, n=128, dps=60)
    lipschitz_cert = certified_support_gap_bound_2d(outer, inner, n=128)
    assert interval_cert.certified_upper_violation <= lipschitz_cert.certified_upper_violation + 1e-9
