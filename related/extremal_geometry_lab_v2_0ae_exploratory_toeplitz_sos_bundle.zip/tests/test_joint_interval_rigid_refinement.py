import math

from extremal_geometry_lab.core import (
    disk_body,
    body_from_polygon,
    ConvexPolygon2D,
    refine_body_in_body_support_rigid_2d,
    derive_rigid_seed_from_rotation_fit,
    SupportRigidPlacement2D,
)
from extremal_geometry_lab.core.rigid_fit import _helly_infeasibility_check


def test_joint_interval_refinement_finds_feasible_boxes_for_nested_disks():
    container = disk_body(2.0)
    witness = disk_body(0.5)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=64,
        cert_n=96,
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=4,
    )
    assert ref.has_certified_feasible_box
    assert len(ref.certified_feasible_boxes) >= 1
    assert ref.best_pose.details["joint_interval_refinement"]


def test_joint_interval_refinement_produces_infeasible_boxes_for_too_large_disk():
    container = disk_body(1.0)
    witness = disk_body(1.8)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=64,
        cert_n=64,
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=3,
    )
    assert len(ref.certified_feasible_boxes) == 0
    assert len(ref.certified_infeasible_boxes) >= 1


def test_joint_interval_refinement_handles_polygon_proxy_path():
    outer = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    inner = body_from_polygon(ConvexPolygon2D([
        [-0.4, -0.2],
        [0.6, -0.2],
        [0.1, 0.8],
    ], name="inner-tri"))
    ref = refine_body_in_body_support_rigid_2d(
        outer,
        inner,
        angle_steps=48,
        cert_n=48,
        translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        initial_theta_intervals=2,
        initial_translation_intervals=2,
        max_depth=3,
        dps=50,
    )
    assert ref.has_certified_feasible_box
    assert any(box.details["cert_method"] in {"interval", "mixed"} for box in ref.certified_feasible_boxes)


def test_helly_infeasibility_check_detects_impossible_large_disk_box():
    container = disk_body(1.0)
    witness = disk_body(1.3)
    from extremal_geometry_lab.core import TranslationIntervalBox2D
    tbox = TranslationIntervalBox2D(-0.25, 0.25, -0.25, 0.25)
    assert _helly_infeasibility_check(
        container, witness, theta_lo=0.0, theta_hi=2.0 * math.pi, translation_box=tbox, n=32, dps=50
    )


def test_joint_interval_refinement_records_helly_pruning_on_impossible_box():
    container = disk_body(1.0)
    witness = disk_body(1.3)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=64,
        translation_bounds=((-0.25, 0.25), (-0.25, 0.25)),
        initial_theta_intervals=1,
        initial_translation_intervals=1,
        max_depth=0,
        dps=50,
    )
    assert len(ref.certified_feasible_boxes) == 0
    assert len(ref.certified_infeasible_boxes) >= 1
    assert any(box.details.get("helly_pruned") for box in ref.certified_infeasible_boxes)


def test_joint_interval_refinement_does_not_expose_rotation_seed_certification_as_rigid_best_pose():
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body

    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    label, poly = next((lab, poly) for lab, poly in net.witnesses if lab == "regular-3-gon")
    witness = _named_body(label, poly)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        initial_theta_intervals=4,
        initial_translation_intervals=4,
        max_depth=1,
    )
    assert ref.has_certified_feasible_box
    assert ref.best_pose.certified_upper_violation is None
    assert ref.best_pose.details["rotation_fit_seed_certified_contains"] is True
    assert ref.best_pose.details["rigid_best_pose_certified"] is False
    assert ref.best_pose.details["best_certified_pose_exists"] is True



def test_joint_interval_refinement_warm_starts_from_rotation_seed_box_for_seed_triangle():
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body

    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    label, poly = next((lab, poly) for lab, poly in net.witnesses if lab == "regular-3-gon")
    witness = _named_body(label, poly)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        initial_theta_intervals=4,
        initial_translation_intervals=4,
        max_depth=1,
    )
    details = ref.best_pose.details
    assert ref.has_certified_feasible_box
    assert details["translation_bounds_source"] == "rotation-fit-seed-box"
    warm = details["translation_bounds"]
    auto = details["auto_translation_bounds"]
    assert warm["tx_hi"] - warm["tx_lo"] < auto["tx_hi"] - auto["tx_lo"]
    assert warm["ty_hi"] - warm["ty_lo"] < auto["ty_hi"] - auto["ty_lo"]


def test_joint_interval_refinement_preserves_explicit_translation_bounds_source():
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body

    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    label, poly = next((lab, poly) for lab, poly in net.witnesses if lab == "regular-3-gon")
    witness = _named_body(label, poly)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        translation_bounds=((-1.58, 1.58), (-1.58, 1.58)),
        initial_theta_intervals=4,
        initial_translation_intervals=4,
        max_depth=1,
    )
    details = ref.best_pose.details
    assert details["translation_bounds_source"] == "explicit"


def test_derive_rigid_seed_from_rotation_fit_uses_best_pose_neighborhood_when_box_missing():
    pose = SupportRigidPlacement2D(
        rotation=0.0,
        translation=(0.2, -0.1),
        sampled_margin=0.12,
        sampled_max_violation=0.0,
        certified_upper_violation=None,
        certified_translation_box=None,
        active_indices=(),
        details={"feasible_motion_box_count": 0},
    )
    seed = derive_rigid_seed_from_rotation_fit(
        pose,
        auto_translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
        rotation_seed_translation_pad=0.05,
        best_pose_neighborhood_min_half_extent=0.03,
        best_pose_neighborhood_margin_scale=1.0,
    )
    assert seed.translation_bounds_source == "rotation-fit-best-pose-neighborhood"
    assert seed.rotation_seed_kind == "best-pose-neighborhood"
    assert seed.rotation_seed_available is True
    assert seed.rotation_seed_center is not None
    assert seed.translation_bounds[0][0] < 0.2 < seed.translation_bounds[0][1]
    assert seed.translation_bounds[1][0] < -0.1 < seed.translation_bounds[1][1]


def test_derive_rigid_seed_from_rotation_fit_can_disable_rotation_seed_consumption():
    pose = SupportRigidPlacement2D(
        rotation=0.0,
        translation=(0.2, -0.1),
        sampled_margin=0.12,
        sampled_max_violation=0.0,
        certified_upper_violation=None,
        certified_translation_box=None,
        active_indices=(),
        details={},
    )
    seed = derive_rigid_seed_from_rotation_fit(
        pose,
        auto_translation_bounds=((-1.0, 1.0), (-2.0, 2.0)),
        use_rotation_seed_translation_bounds=False,
    )
    assert seed.translation_bounds_source == "auto"
    assert seed.rotation_seed_kind == "global-auto-bounds"
    assert seed.rotation_seed_available is False
    assert seed.translation_bounds == ((-1.0, 1.0), (-2.0, 2.0))


def test_joint_interval_refinement_records_localized_deepening_metadata_on_explicit_wide_bounds():
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body

    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    label, poly = next((lab, poly) for lab, poly in net.witnesses if lab == "regular-3-gon")
    witness = _named_body(label, poly)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        translation_bounds=((-1.58, 1.58), (-1.58, 1.58)),
        initial_theta_intervals=4,
        initial_translation_intervals=4,
        max_depth=1,
        localized_deepening=True,
        localized_deepening_pad=0.05,
        localized_far_box_depth_penalty=1,
    )
    details = ref.best_pose.details
    assert details["localized_deepening"] is True
    assert details["seed_focus_box"] is not None
    assert any(box.details.get("localized_near_seed") for box in ref.explored_boxes)
    assert any(not box.details.get("localized_near_seed") for box in ref.explored_boxes)
    assert any(box.details.get("localized_effective_max_depth") == 0 for box in ref.explored_boxes if not box.details.get("localized_near_seed"))


def test_joint_interval_refinement_can_disable_localized_deepening_metadata():
    from extremal_geometry_lab.domains.lebesgue import pal_seed, body_from_state, build_polygon_witness_net_scaffold
    from extremal_geometry_lab.domains.lebesgue.witness_net import _named_body

    container = body_from_state(pal_seed())
    net = build_polygon_witness_net_scaffold(max_vertices=4, include_reduced_family=True)
    label, poly = next((lab, poly) for lab, poly in net.witnesses if lab == "regular-3-gon")
    witness = _named_body(label, poly)
    ref = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        angle_steps=24,
        cert_n=48,
        translation_bounds=((-1.58, 1.58), (-1.58, 1.58)),
        initial_theta_intervals=4,
        initial_translation_intervals=4,
        max_depth=1,
        localized_deepening=False,
    )
    details = ref.best_pose.details
    assert details["localized_deepening"] is False
    assert details["seed_focus_box"] is None
