from extremal_geometry_lab.domains.lebesgue import pal_seed, search_with_width_prescreen
from extremal_geometry_lab.domains.lebesgue.family import proposal_diversity_key, support_signature_metrics, contact_probe_library_metrics, witness_targeted_moves, proposal_witness_net_priority_key, proposal_hybrid_witness_net_priority_key, proposal_witness_target_diversity_key, make_contact_structure_annotator
import extremal_geometry_lab.domains.lebesgue.family as lebesgue_family
from extremal_geometry_lab.domains.lebesgue.family import apply_corner_cut
from extremal_geometry_lab.search.proposal_search import bounded_search, Proposal


def test_bounded_search_screen_prunes_width_violations():
    seed = pal_seed()

    def move_generator(state):
        yield ("bad-cut", {**state, "polygon": apply_corner_cut(state["polygon"], 0.5), "corner_cuts": state["corner_cuts"] + [0.5]})

    props = bounded_search(
        seed,
        move_generator,
        lambda st: 0.0,
        depth=1,
        screen=lambda st: (st["polygon"].name == "pal-seed", "width-violated", {"demo": True}) if st["polygon"].name != "pal-seed" else (True, "width-ok", {"demo": True}),
        include_rejected=True,
    )
    assert len(props) == 2
    rejected = [p for p in props if p.screen_passed is False]
    assert len(rejected) == 1
    assert rejected[0].screen_reason == "width-violated"


def test_lebesgue_search_with_width_prescreen_filters_corner_cut_branch():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=True)
    accepted = [p for p in props if p.screen_passed]
    rejected = [p for p in props if p.screen_passed is False]
    assert len(accepted) >= 1
    assert len(rejected) >= 1
    assert any(p.screen_reason == "width-violated" for p in rejected)
    assert all(p.screen_passed is not False for p in accepted)


def test_lebesgue_search_orders_children_by_width_slack_then_score():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False)
    children = [p for p in props if len(p.move_history) == 1 and p.screen_passed]
    labels = [p.move_history[-1] for p in children]
    assert "tiny-corner-cut" in labels
    assert "small-corner-cut" in labels
    by_label = {p.move_history[-1]: p for p in children}
    assert by_label["tiny-corner-cut"].screen_details["certified_lower_width"] >= by_label["small-corner-cut"].screen_details["certified_lower_width"]
    assert labels.index("tiny-corner-cut") < labels.index("small-corner-cut")


def test_beam_width_truncates_frontier_by_screen_priority():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False, beam_width=1)
    children = [p for p in props if len(p.move_history) == 1 and p.screen_passed]
    assert len(children) == 1
    assert children[0].move_history[-1] == "tiny-corner-cut"


def test_beam_width_changes_depth_two_survivors():
    uncapped = search_with_width_prescreen(depth=2, n=128, include_rejected=False, beam_width=None)
    capped = search_with_width_prescreen(depth=2, n=128, include_rejected=False, beam_width=1)
    uncapped_children = [tuple(p.move_history) for p in uncapped if len(p.move_history) == 2 and p.screen_passed]
    capped_children = [tuple(p.move_history) for p in capped if len(p.move_history) == 2 and p.screen_passed]
    assert len(capped_children) == 1
    assert capped_children[0] == ("tiny-corner-cut", "tiny-corner-cut")
    assert len(uncapped_children) > len(capped_children)


def test_support_signature_key_distinguishes_polygon_and_rounded_candidates():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False)
    by_label = {p.move_history[-1]: p for p in props if len(p.move_history) == 1 and p.screen_passed}
    assert proposal_diversity_key(by_label["tiny-corner-cut"]) != proposal_diversity_key(by_label["small-arc-rounding"])


def test_diversified_beam_preserves_support_signature_families():
    diversified = search_with_width_prescreen(
        depth=1,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
    )
    children = [p for p in diversified if len(p.move_history) == 1 and p.screen_passed]
    assert len(children) == 3
    labels = [p.move_history[-1] for p in children]
    assert labels[0] == "tiny-corner-cut"
    assert "small-arc-rounding" in labels
    assert "heavy-arc-rounding" in labels
    keys = {proposal_diversity_key(p) for p in children}
    assert len(keys) == 3


def test_diversified_beam_keeps_distinct_support_signature_buckets_at_depth_two():
    diversified = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
    )
    depth2 = [p for p in diversified if len(p.move_history) == 2 and p.screen_passed]
    assert len(depth2) >= 2
    metrics = [support_signature_metrics(p.state) for p in depth2]
    shape_buckets = {m["shape_bucket"] for m in metrics}
    assert len(shape_buckets) >= 2


def test_arc_rounding_candidates_use_support_hook_in_prescreen():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False)
    arc_props = [p for p in props if p.move_history and p.move_history[-1] == "small-arc-rounding" and p.screen_passed]
    assert len(arc_props) == 1
    methods = arc_props[0].screen_details.get("support_methods") or []
    assert "analytic-interval" in methods or "interval" in methods
    assert arc_props[0].screen_details.get("body_name", "").endswith("+arc(0.01)")


def test_contact_structure_signal_adds_annotations():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False, structure_signal="contact")
    children = [p for p in props if len(p.move_history) == 1 and p.screen_passed]
    assert len(children) >= 1
    ann = children[0].annotations
    assert "contact_signature_key" in ann
    assert ann.get("contact_cardinality", 0) >= 1


def test_contact_structure_signal_changes_diversified_beam_survivors():
    support_mode = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal=None,
    )
    contact_mode = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="contact",
    )
    support_desc = {tuple(p.move_history) for p in support_mode if len(p.move_history) >= 1 and p.screen_passed}
    contact_desc = {tuple(p.move_history) for p in contact_mode if len(p.move_history) >= 1 and p.screen_passed}
    assert support_desc != contact_desc
    assert ("heavy-arc-rounding",) in support_desc
    assert ("heavy-arc-rounding",) not in contact_desc
    assert ("small-corner-cut",) in contact_desc


def test_contact_structure_signal_uses_multiple_contact_signatures():
    props = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="contact",
    )
    desc = [p for p in props if len(p.move_history) >= 1 and p.screen_passed]
    keys = {tuple(p.annotations.get("contact_signature_key", ())) for p in desc}
    assert len(keys) >= 2


def test_hybrid_structure_signal_blends_support_and_contact_diversity():
    hybrid = search_with_width_prescreen(
        depth=2,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="hybrid",
    )
    desc = [p for p in hybrid if len(p.move_history) >= 1 and p.screen_passed]
    support_keys = {proposal_diversity_key(p) for p in desc}
    contact_keys = {tuple(p.annotations.get("contact_signature_key", ())) for p in desc}
    assert len(support_keys) >= 3
    assert len(contact_keys) >= 2
    labels = {tuple(p.move_history) for p in desc}
    assert ("small-arc-rounding",) in labels
    assert any(hist and hist[-1].endswith("arc-rounding") for hist in labels)
    assert any(hist and "corner-cut" in hist[-1] for hist in labels)


def test_contact_probe_library_metrics_uses_multiple_witnesses():
    metrics = contact_probe_library_metrics(pal_seed())
    assert tuple(metrics["witness_names"]) == ("segment", "orbiform-stub", "disk-half")
    assert len(metrics["per_probe"]) == 3
    assert metrics["probe_key_count"] >= 1


def test_contact_probe_library_annotation_tracks_probe_metadata():
    props = search_with_width_prescreen(depth=1, n=128, include_rejected=False, structure_signal="contact")
    children = [p for p in props if len(p.move_history) == 1 and p.screen_passed]
    assert len(children) >= 1
    ann = children[0].annotations
    assert tuple(ann.get("contact_probe_library", ())) == ("segment", "orbiform-stub", "disk-half")
    assert len(tuple(ann.get("contact_probe_signature", ()))) == 3


def test_contact_probe_library_creates_more_contact_key_variety_than_segment_only():
    multi = search_with_width_prescreen(
        depth=1,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="contact",
    )
    segment_only = search_with_width_prescreen(
        depth=1,
        n=128,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="contact",
        contact_probe_names=("segment",),
    )
    multi_keys = {tuple(p.annotations.get("contact_signature_key", ())) for p in multi if p.screen_passed and len(p.move_history) >= 1}
    seg_keys = {tuple(p.annotations.get("contact_signature_key", ())) for p in segment_only if p.screen_passed and len(p.move_history) >= 1}
    assert len(multi_keys) > len(seg_keys)


def test_witness_net_structure_signal_adds_annotations():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    children = [p for p in props if len(p.move_history) == 1 and p.screen_passed]
    assert len(children) >= 1
    ann = children[0].annotations
    assert "witness_net_key" in ann
    assert ann.get("witness_net_witness_count", 0) >= 1


def test_witness_net_structure_signal_exposes_pass_counts():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    desc = [p for p in props if len(p.move_history) >= 1 and p.screen_passed]
    assert len(desc) >= 1
    counts = {int(p.annotations.get("witness_net_passed_witness_count", 0)) for p in desc}
    assert max(counts) >= min(counts)
    assert all("witness_net_all_passed" in p.annotations for p in desc)


def test_hybrid_witness_net_signal_blends_support_and_net_diversity():
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="hybrid-witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    desc = [p for p in props if len(p.move_history) >= 1 and p.screen_passed]
    support_keys = {proposal_diversity_key(p) for p in desc}
    net_keys = {tuple(p.annotations.get("witness_net_key", ())) for p in desc}
    assert len(support_keys) >= 2
    assert len(net_keys) >= 1


def test_witness_targeted_moves_introduce_targeted_descendants():
    props = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
        enable_witness_targeted_moves=True,
    )
    desc = [p for p in props if p.screen_passed and len(p.move_history) >= 1]
    assert any(any(step.startswith("targeted-") for step in p.move_history) for p in desc)


def test_witness_targeted_moves_change_frontier_relative_to_baseline():
    base = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
        enable_witness_targeted_moves=False,
    )
    guided = search_with_width_prescreen(
        depth=2,
        n=96,
        include_rejected=False,
        beam_width=4,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=8,
        witness_net_include_reduced_family=True,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
        enable_witness_targeted_moves=True,
    )
    base_desc = {tuple(p.move_history) for p in base if p.screen_passed and len(p.move_history) >= 1}
    guided_desc = {tuple(p.move_history) for p in guided if p.screen_passed and len(p.move_history) >= 1}
    assert base_desc != guided_desc
    assert any(hist and hist[0].startswith("targeted-") for hist in guided_desc - base_desc)


def test_witness_net_structure_signal_adds_cluster_annotations():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    child = next(p for p in props if p.screen_passed and len(p.move_history) >= 1)
    ann = child.annotations
    assert "witness_net_low_margin_clusters" in ann
    assert "witness_target_contact_summary" in ann
    assert isinstance(ann["witness_net_low_margin_clusters"], tuple)


def test_witness_targeted_moves_can_use_clusters_without_raw_labels():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_net_failed_labels": tuple(),
            "witness_net_weakest_labels": tuple(),
            "witness_net_low_margin_clusters": ("pointy",),
            "witness_target_contact_summary": "sparse",
        },
    )
    labels = [label for label, _ in witness_targeted_moves(prop)]
    assert "targeted-triangle-rounding" in labels
    assert "targeted-triangle-cut" in labels


def test_witness_targeted_moves_can_use_contact_summary_without_labels():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_net_failed_labels": tuple(),
            "witness_net_weakest_labels": tuple(),
            "witness_net_low_margin_clusters": tuple(),
            "witness_target_contact_summary": "mixed",
        },
    )
    labels = [label for label, _ in witness_targeted_moves(prop)]
    assert "targeted-net-heavy-rounding" in labels


def test_witness_targeted_moves_flag_deprecated_fallback_path_in_child_state():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_net_failed_labels": tuple(),
            "witness_net_weakest_labels": tuple(),
            "witness_net_low_margin_clusters": ("pointy",),
            "witness_target_contact_summary": "sparse",
        },
    )
    targeted = {label: child for label, child in witness_targeted_moves(prop) if label.startswith("targeted-")}
    assert targeted["targeted-triangle-cut"]["target_annotation_path"] == "deprecated-cluster-contact-fallback"
    assert targeted["targeted-triangle-cut"]["target_source"] == "deprecated-cluster-contact-fallback"


def test_witness_net_structure_signal_adds_ledger_move_specs():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    child = next(p for p in props if p.screen_passed and len(p.move_history) >= 1)
    ann = child.annotations
    assert "witness_net_cluster_stats" in ann
    assert "witness_target_move_specs" in ann
    assert ann["witness_target_move_source"] == "witness-ledger"
    assert isinstance(ann["witness_target_move_specs"], tuple)


def test_witness_net_structure_signal_exposes_annotation_path_and_heuristic_parameters():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
    )
    child = next(p for p in props if p.screen_passed and len(p.move_history) >= 1)
    ann = child.annotations
    assert ann["witness_target_annotation_path"] == "ledger-specs"
    assert ann["witness_target_parameter_policy"] == "empirical-defaults"
    thresholds = ann["witness_target_cluster_thresholds"]
    assert thresholds["needle_area_ratio_max"] == 0.14
    assert thresholds["round_min_vertices"] == 8
    assert ann["witness_net_base_angle_steps"] == 12
    assert ann["witness_net_adaptive_angle_steps"] >= 24



def test_witness_targeted_moves_can_use_ledger_specs_without_labels_or_clusters():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_target_move_specs": (
                {
                    "label": "targeted-triangle-rounding",
                    "kind": "rounding",
                    "target": "triangle",
                    "cluster": "pointy",
                    "severity": "moderate",
                    "cut": 0.041,
                    "radius": 0.017,
                    "source": "witness-ledger",
                },
            ),
        },
    )
    labels = [label for label, _ in witness_targeted_moves(prop)]
    assert "targeted-triangle-rounding" in labels


def test_witness_net_structure_signal_adds_scored_move_specs_and_suggestions():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
        targeted_move_limit=2,
    )
    child = next(p for p in props if p.screen_passed and len(p.move_history) >= 1)
    ann = child.annotations
    specs = ann["witness_target_move_specs"]
    assert specs
    assert all("score" in spec for spec in specs)
    scores = [float(spec["score"]) for spec in specs]
    assert scores == sorted(scores, reverse=True)
    assert len(ann["witness_target_suggested_labels"]) <= 2


def test_witness_targeted_moves_respect_scored_limit():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_target_move_limit": 1,
            "witness_target_move_specs": (
                {"label": "targeted-net-heavy-rounding", "kind": "rounding", "target": "net-heavy", "cluster": "round", "severity": "mild", "cut": 0.10, "radius": 0.02, "score": 0.5},
                {"label": "targeted-triangle-rounding", "kind": "rounding", "target": "triangle", "cluster": "pointy", "severity": "moderate", "cut": 0.04, "radius": 0.018, "score": 2.0},
                {"label": "targeted-square-rounding", "kind": "rounding", "target": "square", "cluster": "broad", "severity": "moderate", "cut": 0.06, "radius": 0.012, "score": 1.0},
            ),
        },
    )
    labels = [label for label, _ in witness_targeted_moves(prop) if label.startswith("targeted-")]
    assert labels == ["targeted-triangle-rounding"]


def test_witness_net_structure_signal_adds_target_score_annotations():
    props = search_with_width_prescreen(
        depth=1,
        n=96,
        include_rejected=False,
        beam_width=3,
        beam_policy="diversified",
        beam_diversity_reserve=2,
        structure_signal="witness-net",
        witness_net_max_vertices=4,
        witness_net_include_reduced_family=False,
        witness_net_refine_kwargs={"angle_steps": 12, "cert_n": 24, "use_interval_refinement": False},
        targeted_move_limit=2,
    )
    child = next(p for p in props if p.screen_passed and len(p.move_history) >= 1)
    ann = child.annotations
    assert "witness_target_max_score" in ann
    assert "witness_target_score_bucket" in ann
    assert "witness_target_score_signature" in ann
    assert ann["witness_target_max_score"] >= 0.0


def test_witness_net_priority_key_uses_target_score_signal():
    low = Proposal(state=pal_seed(), move_history=["a"], score=-1.0, screen_passed=True, annotations={
        "witness_net_passed_witness_count": 2,
        "witness_net_all_passed": False,
        "witness_net_failed_witness_count": 1,
        "witness_net_min_margin_bucket": 3,
        "witness_target_max_score": 0.5,
        "witness_target_total_score": 0.7,
    }, screen_details={"certified_lower_width": 1.1, "required_width": 1.0})
    high = Proposal(state=pal_seed(), move_history=["b"], score=-1.0, screen_passed=True, annotations={
        "witness_net_passed_witness_count": 2,
        "witness_net_all_passed": False,
        "witness_net_failed_witness_count": 1,
        "witness_net_min_margin_bucket": 3,
        "witness_target_max_score": 1.5,
        "witness_target_total_score": 2.0,
    }, screen_details={"certified_lower_width": 1.1, "required_width": 1.0})
    assert proposal_witness_net_priority_key(high) > proposal_witness_net_priority_key(low)
    assert proposal_hybrid_witness_net_priority_key(high) > proposal_hybrid_witness_net_priority_key(low)


def test_witness_target_diversity_key_uses_suggestion_score_and_labels():
    prop = Proposal(state=pal_seed(), move_history=[], screen_passed=True, annotations={
        "witness_target_score_bucket": 17,
        "witness_target_score_signature": (17, 12),
        "witness_target_suggested_targets": ("triangle", "square"),
        "witness_target_suggested_labels": ("targeted-triangle-rounding", "targeted-square-rounding"),
    })
    key = proposal_witness_target_diversity_key(prop)
    assert key[:2] == ("witness-target-signal", 17)
    assert "triangle" in key
    assert "targeted-triangle-rounding" in key


def test_bounded_search_can_deduplicate_before_screen():
    seed = {"k": "seed"}
    calls = {"count": 0}

    def move_generator(state):
        yield ("first", {"k": "dup"})
        yield ("second", {"k": "dup"})

    def screen(state):
        calls["count"] += 1
        return True, "ok", {"k": state["k"]}

    props = bounded_search(
        seed,
        move_generator,
        lambda st: 0.0,
        depth=1,
        canonicalize=lambda st: st["k"],
        screen=screen,
        deduplicate_before_screen=True,
    )
    children = [p for p in props if p.screen_passed and len(p.move_history) == 1]
    assert len(children) == 1
    assert calls["count"] == 2


def test_contact_structure_annotator_reuses_computed_metrics(monkeypatch):
    counts = {"primary": 0, "probe": 0}

    def fake_contact_signature_metrics(*args, **kwargs):
        counts["primary"] += 1
        return {
            "witness_name": kwargs.get("witness_name", "segment"),
            "contact_cardinality": 2,
            "gap_signature": (1, 3),
            "direction_buckets": (0, 2),
            "margin": 0.1,
            "verification_method": "pose-replay",
            "lp_method": "demo",
        }

    def fake_contact_probe_library_metrics(*args, **kwargs):
        counts["probe"] += 1
        return {
            "witness_names": tuple(kwargs.get("witness_names", ("segment",))),
            "per_probe": tuple(),
            "probe_signature": (("segment", 2, 1, 3),),
            "probe_key_count": 1,
            "total_contact_cardinality": 2,
            "algebraic_probe_count": 0,
        }

    monkeypatch.setattr(lebesgue_family, "contact_signature_metrics", fake_contact_signature_metrics)
    monkeypatch.setattr(lebesgue_family, "contact_probe_library_metrics", fake_contact_probe_library_metrics)
    annotator = make_contact_structure_annotator(witness_name="segment", witness_names=("segment",))
    ann = annotator(Proposal(state=pal_seed(), move_history=[], screen_passed=True))
    assert ann["contact_primary_signature_key"] == ("contact-signature", "segment", 2, 1, 3)
    assert ann["contact_signature_key"] == ("contact-probe-library", ("segment", 2, 1, 3))
    assert counts == {"primary": 1, "probe": 1}


def test_witness_targeted_moves_deduplicate_geometrically_identical_specs():
    prop = Proposal(
        state=pal_seed(),
        move_history=[],
        screen_passed=True,
        annotations={
            "witness_target_move_specs": (
                {"label": "targeted-a", "kind": "rounding", "target": "triangle", "cluster": "pointy", "severity": "mild", "cut": 0.04, "radius": 0.016},
                {"label": "targeted-b", "kind": "rounding", "target": "triangle", "cluster": "pointy", "severity": "mild", "cut": 0.04, "radius": 0.016},
            ),
            "witness_target_move_limit": 2,
        },
    )
    targeted = [label for label, _ in witness_targeted_moves(prop) if label.startswith("targeted-")]
    assert targeted == ["targeted-a"]


def test_quick_witness_net_metrics_adapts_angle_steps_near_margin(monkeypatch):
    from types import SimpleNamespace

    calls = []

    def fake_fit(*args, **kwargs):
        calls.append((int(kwargs.get("angle_steps", 0)), int(kwargs.get("cert_n", 0))))
        if len(calls) == 1:
            return SimpleNamespace(sampled_margin=0.05, rotation=0.0)
        return SimpleNamespace(sampled_margin=0.04, rotation=0.0)

    witness_poly = apply_corner_cut(pal_seed()["polygon"], 0.05)
    net = SimpleNamespace(
        witnesses=(("demo-witness", witness_poly),),
        hausdorff_resolution=0.0,
        coverage_certificate={"status": "demo"},
    )
    monkeypatch.setattr(lebesgue_family, "fit_body_in_body_support_2d", fake_fit)
    metrics = lebesgue_family.quick_witness_net_metrics(
        pal_seed(),
        net=net,
        fit_kwargs={"angle_steps": 12, "adaptive_angle_steps": 24, "adaptive_margin_threshold": 0.12, "cert_n": 24, "use_interval_refinement": False},
    )
    assert calls == [(12, 24), (24, 48)]
    assert metrics["adaptive_refit_count"] == 1
    assert metrics["max_angle_steps_used"] == 24
    assert metrics["witness_results"][0]["adaptive_refit"] is True
    assert metrics["witness_results"][0]["angle_steps_used"] == 24
