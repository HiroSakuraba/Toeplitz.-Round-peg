from extremal_geometry_lab.search import Proposal, accepted_descendants


def test_accepted_descendants_excludes_seed_and_rejected() -> None:
    seed = Proposal(state=None, move_history=[], score=0.0, screen_passed=True)
    accepted_child = Proposal(state=None, move_history=["a"], score=0.0, screen_passed=True)
    rejected_child = Proposal(state=None, move_history=["b"], score=0.0, screen_passed=False)
    undecided_child = Proposal(state=None, move_history=["c"], score=0.0, screen_passed=None)
    got = accepted_descendants([seed, accepted_child, rejected_child, undecided_child])
    assert got == [accepted_child]
