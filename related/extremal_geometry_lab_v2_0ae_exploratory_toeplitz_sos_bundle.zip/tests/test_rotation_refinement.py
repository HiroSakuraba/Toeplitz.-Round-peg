from __future__ import annotations
import math

from extremal_geometry_lab.core.support import disk_body, regular_ngon_body
from extremal_geometry_lab.core.rigid_fit import refine_body_in_body_support_rotation_2d, fit_body_in_body_support_2d


def test_interval_refinement_classifies_full_rotation_for_nested_disks():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=72,
        cert_n=180,
        initial_intervals=8,
        max_depth=2,
    )
    assert refinement.has_certified_feasible_interval
    assert refinement.all_intervals_classified
    assert len(refinement.certified_feasible_intervals) == 8
    assert len(refinement.unresolved_intervals) == 0


def test_interval_refinement_certifies_infeasible_rotation_family_for_too_large_disk():
    container = disk_body(1.0)
    witness = disk_body(1.1)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=72,
        cert_n=180,
        initial_intervals=8,
        max_depth=2,
    )
    assert not refinement.has_certified_feasible_interval
    assert refinement.all_intervals_classified
    assert len(refinement.certified_infeasible_intervals) == 8


def test_fit_body_support_uses_interval_refinement_metadata():
    container = disk_body(2.0)
    witness = regular_ngon_body(4, radius=0.5)
    fit = fit_body_in_body_support_2d(
        container,
        witness,
        angle_steps=72,
        cert_n=180,
        use_interval_refinement=True,
        initial_intervals=12,
        max_depth=3,
    )
    assert fit.details is not None
    assert fit.details.get("interval_refinement") is True
    assert fit.details.get("feasible_interval_count", 0) >= 1
    assert fit.sampled_margin > 1.0


def test_rotation_refinement_can_leave_unresolved_intervals_when_budget_small():
    container = regular_ngon_body(6, radius=1.5)
    witness = regular_ngon_body(3, radius=0.9)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=120,
        initial_intervals=2,
        max_depth=0,
    )
    assert len(refinement.explored_intervals) == 2
    assert len(refinement.unresolved_intervals) >= 0


import pytest


@pytest.mark.skipif(__import__("importlib").util.find_spec("cvxpy") is None, reason="cvxpy not installed")
def test_rotation_refinement_robust_interval_lp_for_nested_disks():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=128,
        initial_intervals=8,
        max_depth=2,
        lp_mode="robust-interval",
        lp_solver="cvxpy-clarabel",
    )
    assert refinement.has_certified_feasible_interval
    assert refinement.all_intervals_classified
    assert len(refinement.certified_feasible_intervals) == 8


def test_rotation_refinement_sampled_mode_still_works_without_optional_backend():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=128,
        initial_intervals=8,
        max_depth=2,
        lp_mode="sampled",
    )
    assert refinement.has_certified_feasible_interval


def test_rotation_refinement_robust_interval_lp_auto_backend_exercises_fallback_path():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    refinement = refine_body_in_body_support_rotation_2d(
        container,
        witness,
        angle_steps=48,
        cert_n=128,
        initial_intervals=8,
        max_depth=2,
        lp_mode="robust-interval",
        lp_solver="auto",
    )
    assert refinement.has_certified_feasible_interval
    assert refinement.all_intervals_classified
    assert len(refinement.certified_feasible_intervals) == 8
    methods = {iv.notes.get("lp_method_cert") for iv in refinement.explored_intervals}
    assert methods <= {"cvxpy-clarabel", "scipy-highs", "flat-rhs", "vertex-enumeration", "vertex-fallback"}
    assert {iv.notes.get("lp_mode") for iv in refinement.explored_intervals} == {"robust-interval"}
