import numpy as np
from extremal_geometry_lab.core.rigidity import assess_rigidity
from extremal_geometry_lab.core.certify import certify_sample_margin

def test_rigidity_report_shape():
    normals = np.array([[1.0, 0.0], [0.0, 1.0]])
    report = assess_rigidity(normals, ambient_dof=2)
    assert report.rank >= 1

def test_certificate():
    cert = certify_sample_margin("demo", np.array([0.1, 0.2]))
    assert cert.passed
