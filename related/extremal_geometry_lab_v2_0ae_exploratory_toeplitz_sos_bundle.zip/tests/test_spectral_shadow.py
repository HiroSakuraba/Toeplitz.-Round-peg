import math

from extremal_geometry_lab.core import (
    ContactDirectionComparison2D,
    ShadowSpectralPoseReport2D,
    SupportFourierSeries2D,
    WidthCertificate2D,
    build_translation_tension_poses_2d,
    compare_contact_directions_2d,
    disk_body,
    empirical_gap_truncation_bound_2d,
    sampled_support_fourier_2d,
    shadow_spectral_verify_pose_2d,
    shadow_spectral_crosscheck_from_refinement_2d,
    refine_body_in_body_support_rigid_2d,
    summarize_shadow_disagreement_2d,
)


def test_sampled_support_fourier_for_disk_is_constant_to_tolerance():
    body = disk_body(1.0)
    series = sampled_support_fourier_2d(body, order=8, sample_count=512)
    assert abs(series.a0 - 1.0) < 1e-8
    assert max(abs(x) for x in series.cos_coeffs) < 1e-8
    assert max(abs(x) for x in series.sin_coeffs) < 1e-8


def test_empirical_truncation_bound_for_nested_disks_is_tiny():
    container = disk_body(1.0)
    witness = disk_body(0.5)
    bound = empirical_gap_truncation_bound_2d(
        container,
        witness,
        theta=0.0,
        translation=(0.0, 0.0),
        order=8,
        sample_count=1024,
        extended_order=24,
    )
    assert bound.sup_bound < 1e-6
    assert bound.observed_grid_tail < 1e-6



def test_shadow_spectral_verify_pose_for_nested_disks_is_supportive():
    container = disk_body(1.0)
    witness = disk_body(0.5)
    report = shadow_spectral_verify_pose_2d(
        container,
        witness,
        theta=0.0,
        translation=(0.0, 0.0),
        spectral_order=12,
        direction_count=64,
        gap_sample_count=512,
        truncation_sample_count=2048,
        truncation_extended_order=40,
    )
    assert report.shadow_status == "shadow-truncation-positive"
    assert report.helly_lp_status == "lp-feasible-margin-positive"
    assert report.shadow_lower_margin > 0.49
    assert report.sampled_gap_margin_lp_translation > 0.49
    assert report.width_certificate is not None
    assert report.width_certificate.passed
    assert report.contact_direction_comparison is not None
    assert report.contact_direction_comparison.overlap_ratio >= 0.99
    assert report.truncation_module in {"high-k-k2-tail-envelope-monotone-cap", "observed-tail-plus-grid"}



def test_shadow_spectral_crosscheck_from_refinement_records_supportive_lane():
    container = disk_body(1.0)
    witness = disk_body(0.5)
    refinement = refine_body_in_body_support_rigid_2d(
        container,
        witness,
        initial_theta_intervals=4,
        max_depth=1,
        angle_steps=16,
        cert_n=32,
    )
    cross = shadow_spectral_crosscheck_from_refinement_2d(
        container,
        witness,
        refinement,
        spectral_order=12,
        direction_count=64,
        gap_sample_count=512,
        truncation_sample_count=2048,
        truncation_extended_order=40,
        pose_limit=1,
    )
    assert cross.lane_a_status in {"certified_feasible", "incomplete"}
    assert cross.lane_b_status == "shadow-supportive"
    assert cross.disagreement_taxon in {"agreement-feasible", "true-unresolved-case"}
    assert len(cross.pose_reports) >= 1
    assert math.isfinite(cross.pose_reports[0].shadow_lower_margin)



def test_compare_contact_directions_detects_overlap():
    cmp = compare_contact_directions_2d(
        [0.0, math.pi / 2.0, math.pi],
        [0.01, math.pi / 2.0 + 0.01, 1.7],
        angle_tolerance=0.05,
    )
    assert isinstance(cmp, ContactDirectionComparison2D)
    assert cmp.overlap_count == 2
    assert cmp.overlap_ratio == 2 / 3



def test_translation_tension_poses_cross_boundary():
    container = disk_body(1.0)
    witness = disk_body(0.5)
    poses = build_translation_tension_poses_2d(
        container,
        witness,
        theta=0.0,
        translation=(0.0, 0.0),
        sample_count=1024,
        near_boundary_fraction=0.9,
        negative_fraction=1.1,
        absolute_buffer=1e-3,
    )
    by_label = {pose.label: pose for pose in poses}
    assert by_label["certified-seed-pose"].sampled_gap_margin > 0.49
    assert 0.0 < by_label["near-boundary-feasible"].sampled_gap_margin < 0.1
    assert by_label["negative-control"].sampled_gap_margin < 0.0



def test_disagreement_summary_marks_truncation_too_loose_when_sampled_pose_is_supportive():
    dummy_series = SupportFourierSeries2D(
        order=4,
        sample_count=64,
        a0=0.0,
        cos_coeffs=(0.0, 0.0, 0.0, 0.0),
        sin_coeffs=(0.0, 0.0, 0.0, 0.0),
    )
    width = WidthCertificate2D(
        statement='ok',
        required_width=1.0,
        certified_lower_width=1.0,
        passed=True,
    )
    report = ShadowSpectralPoseReport2D(
        theta=0.0,
        translation=(0.0, 0.0),
        lp_margin=0.01,
        sampled_gap_margin=0.02,
        sampled_gap_margin_lp_translation=0.02,
        truncated_gap_margin=-0.01,
        tail_sup_proxy=0.02,
        shadow_lower_margin=-0.03,
        shadow_status='sampled-feasible-with-helly',
        helly_lp_status='lp-feasible-margin-positive',
        lp_translation=(0.0, 0.0),
        lp_translation_shift_norm=0.0,
        support_series=dummy_series,
        width_certificate=width,
        contact_direction_comparison=ContactDirectionComparison2D(
            lane_a_angles=(0.0,),
            lane_b_angles=(0.0,),
            overlap_count=1,
            overlap_ratio=1.0,
            angle_tolerance=0.1,
        ),
    )
    summary = summarize_shadow_disagreement_2d(
        'certified_feasible',
        'sampled-supportive-only',
        [report],
    )
    assert summary.disagreement_taxon == 'truncation-too-loose'
