from __future__ import annotations

from extremal_geometry_lab.core.spectral_shadow import SupportFourierSeries2D
from extremal_geometry_lab.core.spectral_sos import toeplitz_gram_certificate_from_series


def _series(a0: float, coeffs: list[tuple[float, float]]) -> SupportFourierSeries2D:
    return SupportFourierSeries2D(
        order=len(coeffs),
        sample_count=256,
        a0=float(a0),
        cos_coeffs=tuple(float(a) for a, _ in coeffs),
        sin_coeffs=tuple(float(b) for _, b in coeffs),
    )


def test_toeplitz_gram_certificate_positive_series():
    series = _series(1.0, [(0.5, 0.0)])
    cert = toeplitz_gram_certificate_from_series(
        series,
        theta=0.0,
        translation=(0.0, 0.0),
        tail_sup_proxy=0.1,
        sample_count=256,
    )
    assert cert.status == 'toeplitz-gram-psd-shadow-positive'
    assert cert.min_eigenvalue > 0.0
    assert cert.max_coefficient_residual < 1.0e-10


def test_toeplitz_gram_certificate_indefinite_series():
    series = _series(1.0, [(-3.0, 0.0)])
    cert = toeplitz_gram_certificate_from_series(
        series,
        theta=0.0,
        translation=(0.0, 0.0),
        tail_sup_proxy=0.0,
        sample_count=256,
    )
    assert cert.status == 'toeplitz-gram-indefinite'
    assert cert.min_eigenvalue < 0.0
