from __future__ import annotations
import math
import numpy as np

from extremal_geometry_lab.core.support import disk_body, ball_body_3d, regular_ngon_body
from extremal_geometry_lab.core.rigid_fit import fit_body_in_body_support_2d
from extremal_geometry_lab.core.certify import certified_support_gap_bound_2d, certified_support_gap_bound_3d
from extremal_geometry_lab.core.geometry_types import SphericalDirectionSet


def test_support_fit_nested_disks_finds_centered_pose():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    fit = fit_body_in_body_support_2d(container, witness, angle_steps=180, fit_angle_grid=[0.0])
    assert abs(fit.translation[0]) < 1e-6
    assert abs(fit.translation[1]) < 1e-6
    assert abs(fit.sampled_margin - 1.0) < 5e-3
    cert = certified_support_gap_bound_2d(container, witness.translate(np.array(fit.translation)), n=720)
    assert cert.passed
    assert cert.certified_upper_violation <= 0.0


def test_support_gap_certificate_detects_failure():
    container = disk_body(1.0)
    target = disk_body(1.5)
    cert = certified_support_gap_bound_2d(container, target, n=720)
    assert not cert.passed
    assert cert.certified_upper_violation > 0.0


def test_support_fit_polygonal_body_inside_disk():
    container = disk_body(2.0)
    witness = regular_ngon_body(4, radius=0.5)
    fit = fit_body_in_body_support_2d(container, witness, angle_steps=180, fit_angle_grid=np.linspace(0.0, math.pi / 2.0, 7))
    translated = witness.rotate(fit.rotation).translate(np.array(fit.translation))
    cert = certified_support_gap_bound_2d(container, translated, n=720)
    assert cert.passed
    assert fit.sampled_margin > 1.0


def test_support_gap_certificate_3d_for_nested_balls():
    container = ball_body_3d(2.0)
    target = ball_body_3d(1.0)
    dirs = SphericalDirectionSet(np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float), name='axes')
    cert = certified_support_gap_bound_3d(container, target, dirs, covering_radius=0.0)
    assert cert.passed
    assert cert.certified_upper_violation <= 0.0
