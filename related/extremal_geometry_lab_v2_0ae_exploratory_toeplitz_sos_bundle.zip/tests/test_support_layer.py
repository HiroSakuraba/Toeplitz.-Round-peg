
from __future__ import annotations
import math
import numpy as np

from extremal_geometry_lab.core.support import (
    disk_body,
    ball_body_3d,
    segment_body,
    ellipse_body,
    capsule_body,
    regular_ngon_body,
    zonotope_body_2d,
    body_from_polygon,
    minkowski_sum_bodies_2d,
    difference_body_support_2d,
    reconstruct_polygon_from_support,
    PiecewiseSupportFamily2D,
    SampledSupportFamily3D,
    constant_width_residual,
    constant_width_residual_3d,
    origin_symmetry_residual_2d,
    origin_symmetry_residual_3d,
    sampled_contains_body_2d,
    sampled_contains_body_3d,
    support_distance_2d,
)
from extremal_geometry_lab.core.geometry_types import ConvexPolygon2D, SphericalDirectionSet


def square() -> ConvexPolygon2D:
    return ConvexPolygon2D(np.array([[-1,-1],[1,-1],[1,1],[-1,1]], dtype=float), name="square")


def test_disk_body_constant_width_exact():
    body = disk_body(1.0)
    assert constant_width_residual(body, 2.0, n=256) < 1e-12


def test_segment_width_matches_directional_formula():
    seg = segment_body(2.0, theta=0.0)
    assert abs(seg.support_value(np.array([1.0, 0.0])) - 1.0) < 1e-12
    assert abs(seg.width(0.0) - 2.0) < 1e-12
    assert abs(seg.width(math.pi / 2.0)) < 1e-9


def test_body_translation_changes_support_by_dot_product():
    body = disk_body(1.0)
    shifted = body.translate(np.array([2.0, 0.0]))
    assert abs(shifted.support_value(np.array([1.0, 0.0])) - 3.0) < 1e-12
    assert abs(shifted.support_value(np.array([-1.0, 0.0])) + 1.0) < 1e-12


def test_minkowski_sum_bodies_matches_polygon_proxy_area_growth():
    a = body_from_polygon(square())
    b = disk_body(0.25)
    s = minkowski_sum_bodies_2d(a, b)
    poly = reconstruct_polygon_from_support(s, 256)
    assert poly.vertices.shape[0] >= 8


def test_difference_body_support_for_square_has_width_four_along_axis():
    body = body_from_polygon(square())
    diff = difference_body_support_2d(body)
    assert abs(diff.width(0.0) - 4.0) < 1e-6


def test_piecewise_support_family_runs_and_convexity_proxy_finite():
    angles = np.linspace(0.0, 2.0 * math.pi, 8, endpoint=False)
    values = np.ones_like(angles)
    fam = PiecewiseSupportFamily2D(angles=angles, values=values, metadata={"name": "circle-ish"})
    body = fam.to_body()
    assert abs(body.width(0.0) - 2.0) < 1e-6
    assert math.isfinite(fam.convexity_residual())


def test_sampled_support_family_3d_and_ball_width():
    dirs = np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float)
    vals = np.ones(6)
    fam = SampledSupportFamily3D(directions=dirs, values=vals, metadata={"name": "cube-proxy-ball"})
    body = fam.to_body()
    assert abs(body.width_value(np.array([1.0, 0.0, 0.0])) - 2.0) < 1e-12
    actual_ball = ball_body_3d(1.0)
    assert abs(actual_ball.width_value(np.array([1.0,0.0,0.0])) - 2.0) < 1e-12


def test_ellipse_support_matches_axes():
    e = ellipse_body(2.0, 1.0, theta=0.0)
    assert abs(e.support_value(np.array([1.0, 0.0])) - 2.0) < 1e-12
    assert abs(e.support_value(np.array([0.0, 1.0])) - 1.0) < 1e-12


def test_capsule_body_matches_segment_plus_disk_axes():
    cap = capsule_body(segment_length=2.0, radius=0.5, theta=0.0)
    assert abs(cap.support_value(np.array([1.0, 0.0])) - 1.5) < 1e-12
    assert abs(cap.support_value(np.array([0.0, 1.0])) - 0.5) < 1e-12


def test_transformed_analytic_body_keeps_interval_hook():
    e = ellipse_body(2.0, 1.0, theta=0.0).rotate(math.pi / 4.0).translate(np.array([0.5, -0.25]))
    bounds = e.support_interval(0.1, 0.3)
    assert bounds is not None
    lo, hi = bounds
    assert lo <= hi
    vals = [e.h(t) for t in np.linspace(0.1, 0.3, 9)]
    assert lo <= min(vals) + 1e-9
    assert hi >= max(vals) - 1e-9


def test_regular_ngon_polygon_proxy_present():
    body = regular_ngon_body(6, radius=1.0)
    assert body.polygon_proxy is not None
    assert body.polygon_proxy.vertices.shape[0] == 6


def test_zonotope_support_and_origin_symmetry():
    gens = np.array([[1.0, 0.0], [0.0, 2.0]], dtype=float)
    z = zonotope_body_2d(gens)
    assert abs(z.support_value(np.array([1.0, 0.0])) - 1.0) < 1e-12
    assert abs(z.support_value(np.array([0.0, 1.0])) - 2.0) < 1e-12
    assert origin_symmetry_residual_2d(z, n=256) < 1e-12


def test_sampled_support_contains_nested_disks():
    big = disk_body(2.0)
    small = disk_body(1.0)
    assert sampled_contains_body_2d(big, small, n=256)
    assert not sampled_contains_body_2d(small, big, n=256)
    assert abs(support_distance_2d(big, small, n=256) - 1.0) < 1e-6


def test_3d_constant_width_and_contains_ball():
    dirs = SphericalDirectionSet(np.array([[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]], dtype=float), name="axes")
    big = ball_body_3d(2.0)
    small = ball_body_3d(1.0)
    assert constant_width_residual_3d(big, 4.0, dirs) < 1e-12
    assert origin_symmetry_residual_3d(big, dirs) < 1e-12
    assert sampled_contains_body_3d(big, small, dirs)


def test_support_line_reconstruction_contains_square_proxy_scale():
    body = body_from_polygon(square())
    recon = reconstruct_polygon_from_support(body, 64)
    # Reconstruction is an outer approximation with positive area.
    assert recon.vertices.shape[0] >= 4
    xs = recon.vertices[:, 0]
    ys = recon.vertices[:, 1]
    assert xs.max() >= 0.99 and xs.min() <= -0.99
    assert ys.max() >= 0.99 and ys.min() <= -0.99
