import numpy as np

from extremal_geometry_lab.core.support import disk_body
from extremal_geometry_lab.core.support_lp import robust_interval_rhs_2d, solve_support_lp_2d


def test_robust_interval_rhs_for_nested_disks_is_constant():
    container = disk_body(2.0)
    witness = disk_body(1.0)
    angles = np.linspace(0.0, 2.0 * np.pi, 32, endpoint=False)
    dirs = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    rhs, details = robust_interval_rhs_2d(container, witness, dirs, theta_lo=0.0, theta_hi=0.3)
    assert np.max(np.abs(rhs - 1.0)) < 1e-9
    assert details["rhs_method"] == "interval-arc-upper"


def test_sampled_lp_solver_recovers_center_for_nested_disks():
    angles = np.linspace(0.0, 2.0 * np.pi, 32, endpoint=False)
    dirs = np.stack([np.cos(angles), np.sin(angles)], axis=1)
    rhs = np.ones(len(dirs))
    res = solve_support_lp_2d(dirs, rhs)
    assert abs(res.translation[0]) < 1e-8
    assert abs(res.translation[1]) < 1e-8
    assert abs(res.margin - 1.0) < 1e-8
