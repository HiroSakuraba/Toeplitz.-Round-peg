import math

from extremal_geometry_lab.core import (
    BnBTopologySummary,
    TranslationIntervalBox2D,
    RigidMotionBox2D,
    SupportRigidMotionRefinement2D,
    disk_body,
    analyze_rigid_motion_refinement_topology,
    boxes_share_face,
)
from extremal_geometry_lab.certificates import CertificateChain, CertificateChainLink
from extremal_geometry_lab.domains.lebesgue import (
    NerveComplex,
    nerve_complex_from_failure_sets,
    analyze_width_hardness,
)


def test_nerve_complex_from_failure_sets_detects_cycle_without_triangle_fill():
    complex_ = nerve_complex_from_failure_sets(
        ["a", "b", "c"],
        [
            (0, 1),
            (1, 2),
            (0, 2),
        ],
    )
    assert isinstance(complex_, NerveComplex)
    assert complex_.betti_0 == 1
    assert complex_.betti_1 == 1
    assert len(complex_.triangles) == 0



def test_nerve_complex_triangle_fill_kills_cycle():
    complex_ = nerve_complex_from_failure_sets(
        ["a", "b", "c"],
        [
            (0, 1, 2),
        ],
    )
    assert complex_.betti_0 == 1
    assert complex_.betti_1 == 0
    assert len(complex_.triangles) == 1



def test_width_hardness_marks_disk_nearly_constant_width():
    summary = analyze_width_hardness(disk_body(1.0), n_samples=120, nearly_constant_threshold=1.0e-4)
    assert summary.nearly_constant_width
    assert summary.width_spread < 1.0e-6
    assert summary.min_width == summary.max_width



def _box(theta_lo, theta_hi, tx_lo, tx_hi, ty_lo, ty_hi, *, feasible=False, infeasible=False):
    return RigidMotionBox2D(
        rotation_lo=theta_lo,
        rotation_hi=theta_hi,
        translation_box=TranslationIntervalBox2D(tx_lo, tx_hi, ty_lo, ty_hi),
        certified_feasible=feasible,
        certified_infeasible=infeasible,
        details={},
    )



def test_boxes_share_face_detects_adjacent_tx_face():
    a = _box(0.0, 0.5, 0.0, 1.0, 0.0, 1.0, feasible=True)
    b = _box(0.0, 0.5, 1.0, 2.0, 0.0, 1.0, feasible=True)
    assert boxes_share_face(a, b)



def test_analyze_rigid_motion_refinement_topology_counts_components_and_bridge_risk():
    f0 = _box(0.0, 0.5, 0.0, 1.0, 0.0, 1.0, feasible=True)
    f1 = _box(0.0, 0.5, 2.0, 3.0, 0.0, 1.0, feasible=True)
    u0 = _box(0.0, 0.5, 1.0, 2.0, 0.0, 1.0)
    refinement = SupportRigidMotionRefinement2D(
        best_pose=None,
        certified_feasible_boxes=(f0, f1),
        certified_infeasible_boxes=(),
        unresolved_boxes=(u0,),
        explored_boxes=(f0, f1, u0),
    )
    summary = analyze_rigid_motion_refinement_topology(refinement)
    assert isinstance(summary, BnBTopologySummary)
    assert summary.feasible_components == 2
    assert summary.unresolved_bridge_risk_count == 1
    assert not summary.topological_completeness_proved



def test_certificate_chain_verifies_composition_and_reports_weakest_link():
    chain = CertificateChain(
        links=(
            CertificateChainLink(
                claim="seed fit",
                method="sample-fit",
                inputs=(),
                output="fit0",
                bound=0.2,
                depth=0,
            ),
            CertificateChainLink(
                claim="refined box",
                method="interval-refine",
                inputs=("fit0",),
                output="fit1",
                bound=0.05,
                depth=1,
            ),
        )
    )
    assert chain.verify_composition()
    weakest = chain.weakest_link()
    assert weakest is not None
    assert weakest.output == "fit0"
    payload = chain.to_payload()
    assert payload["compositional"] is True
    assert payload["weakest_link"] == "fit0"
