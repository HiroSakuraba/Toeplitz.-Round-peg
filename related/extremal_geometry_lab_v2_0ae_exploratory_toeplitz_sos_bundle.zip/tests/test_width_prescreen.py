from extremal_geometry_lab.core.support import disk_body
from extremal_geometry_lab.core.prescreen import certified_width_prescreen_2d
from extremal_geometry_lab.domains.lebesgue import pal_seed, prescreen_candidate_state
from extremal_geometry_lab.search.exact_screen import exact_family_screen, predicate_from_width_prescreen


def test_width_prescreen_accepts_unit_diameter_disk():
    body = disk_body(0.5)
    cert = certified_width_prescreen_2d(body, width_lb=1.0, n=128)
    assert cert.passed
    assert cert.certified_lower_width >= 1.0 - 1e-6


def test_width_prescreen_rejects_too_narrow_disk():
    body = disk_body(0.49)
    cert = certified_width_prescreen_2d(body, width_lb=1.0, n=128)
    assert not cert.passed
    assert cert.certified_lower_width < 1.0


def test_lebesgue_state_prescreen_runs():
    state = pal_seed()
    res = prescreen_candidate_state(state, width_lb=1.0, n=128)
    assert res.reason in {"width-ok", "width-violated"}
    assert res.width_certificate.required_width == 1.0


def test_width_prescreen_predicate_wrapper_integrates_with_exact_screen():
    pred = predicate_from_width_prescreen(lambda cand: prescreen_candidate_state(cand, width_lb=1.0, n=64))
    result = exact_family_screen(pal_seed(), "lebesgue-width", pred)
    assert result.family == "lebesgue-width"
    assert isinstance(result.passed, bool)
    assert result.details is not None
    assert "certified_lower_width" in result.details


from pathlib import Path

from extremal_geometry_lab.search.exact_screen import exact_family_screen, predicate_from_width_prescreen
from extremal_geometry_lab.certificates.formats import export_width_prescreen_bundle
from extremal_geometry_lab.domains.lebesgue.family import apply_corner_cut


def test_width_prescreen_integrates_with_exact_family_screen(tmp_path: Path):
    seed = pal_seed()
    pred = predicate_from_width_prescreen(lambda state: prescreen_candidate_state(state, width_lb=1.0, n=128))
    ok = exact_family_screen(seed, seed["family"], pred)
    assert ok.passed
    bad_poly = apply_corner_cut(seed["polygon"], 0.5)
    bad_state = {**seed, "polygon": bad_poly, "body": None, "corner_cuts": [0.5], "arc_replacements": []}
    bad = exact_family_screen(bad_state, bad_state["family"], pred)
    assert not bad.passed
    assert bad.reason == "width-violated"


def test_width_prescreen_bundle_export(tmp_path: Path):
    seed = pal_seed()
    result = prescreen_candidate_state(seed, width_lb=1.0, n=128)
    payload = export_width_prescreen_bundle(tmp_path / "seed" / "bundle", family=seed["family"], state_name="seed", result=result)
    assert payload["passed"]
    assert (tmp_path / "seed" / "bundle.json").exists()
    assert (tmp_path / "seed" / "bundle.md").exists()
