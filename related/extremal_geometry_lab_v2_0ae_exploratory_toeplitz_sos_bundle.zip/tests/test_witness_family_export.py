import json
from pathlib import Path

from extremal_geometry_lab.core import ConvexPolygon2D, body_from_polygon
from extremal_geometry_lab.certificates import export_witness_family_bundle


def test_export_witness_family_bundle_writes_joint_coexistence_and_per_witness_bundles(tmp_path: Path):
    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="outer-square"))
    witnesses = [
        body_from_polygon(ConvexPolygon2D([
            [-0.4, -0.2],
            [0.6, -0.2],
            [0.1, 0.8],
        ], name="inner-triangle")),
        body_from_polygon(ConvexPolygon2D([
            [-0.3, -0.3],
            [0.3, -0.3],
            [0.3, 0.3],
            [-0.3, 0.3],
        ], name="inner-square")),
    ]

    summary = export_witness_family_bundle(
        tmp_path / "bundle",
        container=container,
        witnesses=witnesses,
        refine_kwargs=dict(
            angle_steps=32,
            cert_n=48,
            translation_bounds=((-1.0, 1.0), (-1.0, 1.0)),
            initial_theta_intervals=1,
            initial_translation_intervals=2,
            max_depth=2,
            dps=40,
        ),
    )

    summary_json = tmp_path / "bundle" / "summary.json"
    summary_md = tmp_path / "bundle" / "summary.md"
    coexistence_json = tmp_path / "bundle" / "coexistence.json"
    coexistence_md = tmp_path / "bundle" / "coexistence.md"
    assert summary_json.exists()
    assert summary_md.exists()
    assert coexistence_json.exists()
    assert coexistence_md.exists()

    data = json.loads(summary_json.read_text(encoding="utf-8"))
    assert data["schema_version"] == "witness-family-bundle.v2"
    assert data["container"] == "outer-square"
    assert data["witness_count"] == 2
    assert data["joint_coexistence_path"] == "coexistence.json"
    assert len(data["witnesses"]) == 2
    assert summary["joint_certified"] is True

    coexistence = json.loads(coexistence_json.read_text(encoding="utf-8"))
    assert coexistence["schema_version"] == "witness-family-coexistence.v1"
    assert coexistence["joint_certified"] is True
    assert coexistence["certificate_kind"] == "product-space-feasibility-region"
    assert coexistence["joint_pose_dimension"] == 6
    assert len(coexistence["selected_product_region"]) == 2
    assert coexistence["missing_witnesses"] == []

    # per-witness bundle exists
    for entry in data["witnesses"]:
        path = tmp_path / "bundle" / entry["bundle_path"]
        assert path.exists()
        assert entry["selected_box_index"] is not None


def test_export_witness_family_bundle_marks_joint_failure_when_one_witness_has_no_feasible_box(tmp_path: Path):
    container = body_from_polygon(ConvexPolygon2D([
        [-2.0, -2.0],
        [2.0, -2.0],
        [2.0, 2.0],
        [-2.0, 2.0],
    ], name="small-square"))
    witnesses = [
        body_from_polygon(ConvexPolygon2D([
            [-0.4, -0.2],
            [0.6, -0.2],
            [0.1, 0.8],
        ], name="fits")),
        body_from_polygon(ConvexPolygon2D([
            [-3.0, -3.0],
            [3.0, -3.0],
            [3.0, 3.0],
            [-3.0, 3.0],
        ], name="too-large")),
    ]

    export_witness_family_bundle(
        tmp_path / "bundle",
        container=container,
        witnesses=witnesses,
        refine_kwargs=dict(
            angle_steps=24,
            cert_n=32,
            translation_bounds=((-0.5, 0.5), (-0.5, 0.5)),
            initial_theta_intervals=1,
            initial_translation_intervals=1,
            max_depth=1,
            dps=40,
        ),
    )

    coexistence_json = tmp_path / "bundle" / "coexistence.json"
    coexistence = json.loads(coexistence_json.read_text(encoding="utf-8"))
    assert coexistence["joint_certified"] is False
    assert len(coexistence["selected_product_region"]) == 1
    assert len(coexistence["missing_witnesses"]) == 1
    assert coexistence["missing_witnesses"][0]["name"] == "too-large"
