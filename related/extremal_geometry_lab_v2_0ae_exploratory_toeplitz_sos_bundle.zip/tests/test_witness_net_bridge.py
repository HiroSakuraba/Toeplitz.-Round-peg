from pathlib import Path
import json

from extremal_geometry_lab.domains.lebesgue import (
    pal_seed,
    build_polygon_witness_net_scaffold,
    screen_candidate_state_against_witness_net,
    predicate_from_witness_net_scaffold,
    export_candidate_witness_net_bundle,
)
from extremal_geometry_lab.search.exact_screen import exact_family_screen


REFINE_KWARGS = {
    "angle_steps": 24,
    "cert_n": 48,
    "initial_intervals": 4,
    "max_depth": 1,
}


def test_witness_net_screen_candidate_state_returns_ledger():
    net = build_polygon_witness_net_scaffold(max_vertices=5, include_reduced_family=False)
    res = screen_candidate_state_against_witness_net(
        pal_seed(),
        net=net,
        refine_kwargs=REFINE_KWARGS,
    )
    assert res.witness_count == len(net.witnesses)
    assert len(res.witness_ledger) == len(net.witnesses)
    assert res.passed_witness_count + res.failed_witness_count == res.witness_count
    assert res.reason in {"witness-net-pass", "witness-net-fail"}


def test_exact_family_screen_accepts_witness_net_predicate():
    net = build_polygon_witness_net_scaffold(max_vertices=5, include_reduced_family=False)
    pred = predicate_from_witness_net_scaffold(net=net, refine_kwargs=REFINE_KWARGS)
    sr = exact_family_screen(pal_seed(), "witness-net-scaffold", pred)
    assert sr.family == "witness-net-scaffold"
    assert sr.reason in {"witness-net-pass", "witness-net-fail"}
    assert sr.details["witness_count"] == len(net.witnesses)


def test_export_candidate_witness_net_bundle_writes_summary_and_coexistence(tmp_path: Path):
    net = build_polygon_witness_net_scaffold(max_vertices=5, include_reduced_family=False)
    out = export_candidate_witness_net_bundle(
        tmp_path / "bundle",
        state=pal_seed(),
        net=net,
        refine_kwargs=REFINE_KWARGS,
        state_name="pal-seed",
    )
    assert out["schema_version"] == "lebesgue-witness-net-bridge.v1"
    assert (tmp_path / "bundle" / "summary.json").exists()
    assert (tmp_path / "bundle" / "summary.md").exists()
    assert (tmp_path / "bundle" / "witness_family" / "coexistence.json").exists()
    data = json.loads((tmp_path / "bundle" / "summary.json").read_text())
    assert data["joint_coexistence_path"] == "witness_family/coexistence.json"
    assert data["witness_count"] == len(net.witnesses)
