from extremal_geometry_lab.domains.lebesgue.witness_net import build_polygon_witness_net_scaffold
from extremal_geometry_lab.core.support import body_from_polygon


def test_build_polygon_witness_net_scaffold_produces_normalized_witnesses():
    net = build_polygon_witness_net_scaffold(max_vertices=8, include_reduced_family=True)
    assert len(net.witnesses) >= 5
    assert net.diameter_class == 1.0
    assert net.coverage_certificate["status"] == "incomplete-family"
    for _label, poly in net.witnesses[:4]:
        vals = body_from_polygon(poly).sample_support(n=128).values
        half = len(vals) // 2
        diam = max(float(vals[i] + vals[(i + half) % len(vals)]) for i in range(half))
        assert abs(diam - 1.0) < 5.0e-3


def test_witness_net_scaffold_resolution_decreases_with_more_vertices():
    coarse = build_polygon_witness_net_scaffold(max_vertices=6, include_reduced_family=False)
    fine = build_polygon_witness_net_scaffold(max_vertices=10, include_reduced_family=False)
    assert fine.hausdorff_resolution < coarse.hausdorff_resolution
